/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0529;

import java.io.File;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import com.bytel.spirit.tesla.processes.PE0529.structs.ProvisioningVDR;
import com.bytel.spirit.tesla.processes.PE0529.structs.ProvisioningVDRMigration;
import com.bytel.spirit.tesla.processes.PE0529.structs.ProvisioningVDRModification;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit.BL4600_CreerErreurSpiritBuilder;
import com.bytel.spirit.common.activities.shared.BL850_ObtenirTicket;
import com.bytel.spirit.common.activities.shared.BL850_ObtenirTicket.BL850_ObtenirTicketBuilder;
import com.bytel.spirit.common.activities.shared.BL851_LibererTicket;
import com.bytel.spirit.common.activities.shared.BL851_LibererTicket.BL851_LibererTicketBuilder;
import com.bytel.spirit.common.connectors.air.AIRProxy;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.stark.STARKProxy;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.res.BoitierPM;
import com.bytel.spirit.common.shared.saab.res.CartePON;
import com.bytel.spirit.common.shared.saab.res.LienPortPMPon;
import com.bytel.spirit.common.shared.saab.res.ListeTechnologieAutorisee;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.PanneauPM;
import com.bytel.spirit.common.shared.saab.res.PortPM;
import com.bytel.spirit.common.shared.saab.res.PortPON;
import com.bytel.spirit.common.shared.saab.res.PortPonId;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;
import com.bytel.spirit.common.shared.saab.res.TypeIdentifiant;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacte;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacteStatutProvisionning;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseauStatut;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeFax;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.types.json.Suivi;
import com.bytel.spirit.tesla.processes.PE0529.AbstractOperationVieReseau.IMessage;
import com.bytel.spirit.tesla.processes.PE0529.AbstractOperationVieReseau.State;
import com.bytel.spirit.tesla.processes.PE0529.config.ConfigurationPE0529;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.BoitierPm;
import com.bytel.spirit.tesla.shared.types.PE0529.CartePon;
import com.bytel.spirit.tesla.shared.types.PE0529.LienPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.MigrationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.ModificationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.ModificationPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.PanneauPm;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.SuppressionPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.SuppressionPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PostRequest;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PutRequest;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * Classe de test pour le processus {@link PE0529_OperationVieReseau} requete PUT
 *
 * @author jchevron
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml") //$NON-NLS-1$
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" }) //$NON-NLS-1$ //$NON-NLS-2$
@PrepareForTest({ PE0529_OperationVieReseau.class, REXProxy.class, RESProxy.class, BL4600_CreerErreurSpiritBuilder.class, BL4600_CreerErreurSpirit.class, AIRProxy.class, RPGProxy.class, STARKProxy.class, BL850_ObtenirTicket.class, BL850_ObtenirTicketBuilder.class, BL851_LibererTicket.class, BL851_LibererTicketBuilder.class })
public class PE0529_PutOperationVieReseauTest
{
  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0529_OperationVieReseau"; //$NON-NLS-1$

  /**
   * FILE_PATH
   */
  private static final String PARAM_FILE_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * FILE_PATH
   */
  private static final String CONFIG_FILE = "/PE0529/ConfigurationPE0529.xml"; //$NON-NLS-1$

  /**
   * FILE_PATH_HUAWEI
   */
  private static final String CONFIG_FILE_HUAWEI = "/PE0529/ConfigurationPE0529_Huawei.xml"; //$NON-NLS-1$

  /**
   * bean Factory generation
   */
  private static final PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  @MockStrict
  protected REXProxy _rexProxyMock;

  @MockStrict
  protected RESProxy _resProxyMock;

  @MockStrict
  protected AIRProxy _airProxyMock;

  @MockStrict
  protected RPGProxy _rpgProxyMock;

  @MockStrict
  protected STARKProxy _starkProxy;

  @MockStrict
  protected BL4600_CreerErreurSpirit _bl4600Mock;

  @MockNice
  protected BL4600_CreerErreurSpiritBuilder _bl4600BuilderMock;

  @MockStrict
  protected BL850_ObtenirTicket _bl850Mock;

  @MockNice
  protected BL850_ObtenirTicketBuilder _bl850BuilderMock;

  @MockStrict
  protected BL851_LibererTicket _bl851Mock;

  @MockNice
  protected BL851_LibererTicketBuilder _bl851BuilderMock;

  /**
   * Instance to evaluate
   */
  private PE0529_OperationVieReseau _processInstance;

  /**
   * Tracabilite
   */
  Tracabilite _tracabilite;

  /**
   * <b>Cas de test:</b> Headers tous null<br/>
   * <b>Entrées:</b> Header null ou vide<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Header HTTP obligatoire manquant: Authorization<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL001_KO_001() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders(null, null, null, null, null, null);
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);
    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le entête \"X-Source\" est vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Header null<br/>
   * <b>Entrées:</b> Un header null ou vide<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Header HTTP obligatoire manquant: Authorization<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL001_KO_002() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", null, "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le entête \"X-Source\" est vide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Request body null<br/>
   * <b>Entrées:</b> Requête avec body null<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Non respect du format d'entrée de la STI<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL001_KO_003() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    PE0529_PutRequest modificationRequest = null;
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPostProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le corps de la requête ne respecte pas le format demandé.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> PE0529_PutRequest avec champs obligatoires vides (<br/>
   * <b>Entrées:</b> Requête avec body mais valeurs obligatoire vides<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Attribut obligatoire manquant<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL001_KO_004() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(StringConstants.EMPTY_STRING);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Attribut obligatoire manquant {_action}.Format d'attribut non respecté {_action}."); //$NON-NLS-1$
    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(retourExpected.getLibelle(), reponseactual.getErrorDescription());
    Assert.assertEquals(retourExpected.getDiagnostic(), reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> PE0529_PutRequest avec champs action incorrect (<br/>
   * <b>Entrées:</b> Requête avec body mais valeurs obligatoire incorrecte<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Format d'attribut non respecté<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL001_KO_005() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "unknown"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Format d'attribut non respecté {_action}."); //$NON-NLS-1$
    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(retourExpected.getLibelle(), reponseactual.getErrorDescription());
    Assert.assertEquals(retourExpected.getDiagnostic(), reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> PE0529_PutRequest avec parametre URL vide (<br/>
   * <b>Entrées:</b> Requête avec body mais valeurs obligatoire vides<br/>
   * <b>Attendu:</b> ResponseErreur 400 - Paramètre manquant en entrée: idOperationVieReseau<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL001_KO_006() throws Throwable
  {
    // Préparation de la requête
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, null);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals("Le paramètre \"idOperationVieReseau\", dans la requête, avec le valeur \"null\" est vide ou invalide.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Retour NOK en entree et sortie (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL005_KO_001() throws Throwable
  {
    Retour retourIn = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Erreur"); //$NON-NLS-1$
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "Erreur"); //$NON-NLS-1$
    _processInstance.getProcessContext().setProcessRetour(retourIn);

    mockBL4600(retourIn, retourExpected);

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL005_GererErreurPROSPERModification", retourIn, _tracabilite); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, retourExpected);
  }

  /**
   * <b>Cas de test:</b> Retour NOK en entree (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL005_OK_001() throws Throwable
  {
    Retour retourIn = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Erreur"); //$NON-NLS-1$
    _processInstance.getProcessContext().setProcessRetour(retourIn);

    mockBL4600(retourIn, RetourFactoryForTU.createOkRetour());

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL005_GererErreurPROSPERModification", retourIn, _tracabilite); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, RetourFactoryForTU.createOkRetour());
  }

  /**
   * <b>Cas de test:</b> Retour OK en entree (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL005_OK_002() throws Throwable
  {
    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    _processInstance.getProcessContext().setProcessRetour(retourExpected);

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL005_GererErreurPROSPERModification", retourExpected, _tracabilite); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, retourExpected);
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauLireUn retour NOK CAT-2 (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_KO_001() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(retour, null, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in REX", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauLireUn retour OperationVieReseau null (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 404 - DONNEE_INCONNUE - L'objet OperationVieReseau {idOperationViereseau} n'existe pas
   * dans le referentiel SPIRIT<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_KO_002() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), null, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    String expectedDesc = "L'objet OperationVieReseau " + idOperationVieReseau + " n'existe pas dans le referentiel SPIRIT."; //$NON-NLS-1$//$NON-NLS-2$
    Assert.assertEquals(expectedDesc, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauLireUn retour null <br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 500 - TRAITEMENT_ARRETE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_KO_003() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(1);
    EasyMock.expect(_rexProxyMock.operationVieReseauLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idOperationVieReseau))) //
            .andReturn(null);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauLireUn throws exception <br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 500 - TRAITEMENT_ARRETE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_KO_004() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    RavelException ravelException = new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception"); //$NON-NLS-1$
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).anyTimes();
    EasyMock.expect(_rexProxyMock.operationVieReseauLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idOperationVieReseau))) //
            .andThrow(ravelException);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("Exception", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> OperationVieReseau statut ACQUITTE avec mise à jour statut NOK (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 500 - TRAITEMENT_ARRETE<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_KO_005() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau ovr = new OperationVieReseau(idOperationVieReseau, "PON128", OperationVieReseauStatut.ACQUITTE.name(), null); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, StringConstants.EMPTY_STRING);
    mockREX_OperationVieReseauModifierStatut(retour, idOperationVieReseau, OperationVieReseauStatut.OBSOLETE.name(), null, null);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(StringConstants.EMPTY_STRING, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> OperationVieReseau statut EN_COURS_MAJ_REFERENTIEL avec mise à jour statut NOK (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 500 - TRAITEMENT_ARRETE - Operation annulee pendant la mise a jour referentiel
   * SPIRIT<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_KO_006() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau ovr = new OperationVieReseau(idOperationVieReseau, "PON128", OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, IMessage.OPERATION_ANNULEE_MAJ_REFERENTIEL);
    mockREX_OperationVieReseauModifierStatut(retour, idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, IMessage.OPERATION_ANNULEE_MAJ_REFERENTIEL);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(IMessage.OPERATION_ANNULEE_MAJ_REFERENTIEL, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> OperationVieReseau statut EN_COURS_PROVISIONING avec mise à jour statut NOK (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 500 - TRAITEMENT_ARRETE - Operation annulee pendant le provisioning des client
   * SPIRIT<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_KO_007() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau ovr = new OperationVieReseau(idOperationVieReseau, "PON128", OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, IMessage.OPERATION_ANNULEE_PROV_CLIENT);
    mockREX_OperationVieReseauModifierStatut(retour, idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, IMessage.OPERATION_ANNULEE_PROV_CLIENT);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals("Operation annulée pendant le provisioning des clients.", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.TRAITEMENT_ARRETE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> OperationVieReseau statut OBSOLETE<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - Operation {idOperationVieReseau} est en etat final OBSOLETE
   * SPIRIT<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_KO_008() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau ovr = new OperationVieReseau(idOperationVieReseau, "PON128", OperationVieReseauStatut.OBSOLETE.name(), null); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    String expectedDesc = MessageFormat.format(IMessage.OPERATION_ETAT_FINAL, idOperationVieReseau, OperationVieReseauStatut.OBSOLETE.name());
    Assert.assertEquals(expectedDesc, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> OperationVieReseau statut TRAITE_NOK<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - Operation {idOperationVieReseau} est en etat final TRAITE_NOK
   * SPIRIT<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_KO_009() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau ovr = new OperationVieReseau(idOperationVieReseau, "PON128", OperationVieReseauStatut.TRAITE_NOK.name(), null); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    String expectedDesc = MessageFormat.format(IMessage.OPERATION_ETAT_FINAL, idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name());
    Assert.assertEquals(expectedDesc, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> OperationVieReseau statut TRAITE_OK<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - Operation {idOperationVieReseau} est en etat final TRAITE_OK
   * SPIRIT<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_KO_010() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau ovr = new OperationVieReseau(idOperationVieReseau, "PON128", OperationVieReseauStatut.TRAITE_OK.name(), null); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    String expectedDesc = MessageFormat.format(IMessage.OPERATION_ETAT_FINAL, idOperationVieReseau, OperationVieReseauStatut.TRAITE_OK.name());
    Assert.assertEquals(expectedDesc, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> OperationVieReseau statut ACQUITTE OK (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> Response 202<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL100_OK_001() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "annuler"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau ovr = new OperationVieReseau(idOperationVieReseau, "PON128", OperationVieReseauStatut.ACQUITTE.name(), null); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), ovr, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.OBSOLETE.name(), null, null);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Tests de retours
    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauLireUn retour NOK CAT-2 <br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 404 - DONNEE_INCONNUE - L'objet OperationVieReseau {idOperationViereseau} n'existe pas
   * dans le referentiel SPIRIT<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_001() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(retour, null, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    String expectedDesc = MessageFormat.format(IMessage.OPERATION_VIE_RESEAU_INCONNUE, idOperationVieReseau);
    Assert.assertEquals(expectedDesc, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauLireUn retour operationVieReseau non ACQUITTE (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - Operation ne peut etre executee ou deja en execution
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_002() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseau(idOperationVieReseau, typeOperation, OperationVieReseauStatut.OBSOLETE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(IMessage.OPERATION_VIE_RESEAU_NON_ACQUITTE, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauCompositeLireTousParCleRecherche CAT-2(<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_003() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseau(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(retour, null, typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in REX", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Une autre opération en cours sur un portPM <br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - Impossible d'executer, une autre operation VDR est en cours sur
   * un PM impacte<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_004() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseau(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche
    OperationVieReseau operation2 = new OperationVieReseau("idOperationVieReseau", null, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(MessageFormat.format(IMessage.EXECUTION_IMPOSSIBLE_SUR, "idOperationVieReseau", "PM"), reponseactual.getErrorDescription()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Une autre opération en cours sur OLT (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - Impossible d'executer, une autre operation VDR est en cours sur
   * un OLT impacte<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_005() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseau(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI893"); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI892"); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI891"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau("idOperationVieReseau", null, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(MessageFormat.format(IMessage.EXECUTION_IMPOSSIBLE_SUR, "idOperationVieReseau", "OLT"), reponseactual.getErrorDescription()); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauModifierStatut CAT-2 (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_006() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseau(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI893"); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI892"); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI891"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierStatut(retour, idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in REX", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> RES.pmCompositeLireUnParReferencePmBytel CAT-2 (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_009() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseau(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI893"); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI892"); //$NON-NLS-1$
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI891"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_PmCompositeLireUnParReferencePmBytel(retour, null, "GHYUI890"); //$NON-NLS-1$

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur de lecture de PMComposite GHYUI890."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> RES.oltLireUn CAT-2 - Modification (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_010() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositeLireUn(retour, null, "OLT2000"); //$NON-NLS-1$

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur de lecture de OLTComposite OLT2000."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauModifierListeClientImpacte CAT-2 - getProvisioning ressourceLireUn NOK - Aucun client (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_011() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Retour retourRes = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_RessourceLireUn(retourRes, null, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    mockRES_RessourceLireUn(retourRes, null, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur de lecture de RessourcePortPM GHYUI890||BOITIER_A||PANNEAU_A||1."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> getProvisioning RessourcePortPm LIBRE - Aucun client (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 202
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_OK_006() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource = new RessourcePortPM("LIBRE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // Construction PM mis à jour
    //  - Add
    PortPonId portPonIdAdd = new PortPonId("OLT2000", 1, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPonAdd = new LienPortPMPon("OPERATIONNEL", portPonIdAdd); //$NON-NLS-1$
    String cleAdd = "OLT2000_1_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiensAdd = new HashMap<>();
    mapLiensAdd.put(cleAdd, lienPortPMPonAdd);
    Map<Integer, PortPM> mapPortPanneauBB = new HashMap<>();
    mapPortPanneauBB.put(2, new PortPM(2, "OPERATIONNEL", mapLiensAdd)); //$NON-NLS-1$
    PanneauPM panneauB_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBB); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> mapPanneauBoitierB = new HashMap<>();
    mapPanneauBoitierB.put("PANNEAU_B", panneauB_B); //$NON-NLS-1$
    BoitierPM boitierB = new BoitierPM("BOITIER_B", "OPERATIONNEL", mapPanneauBoitierB); //$NON-NLS-1$ //$NON-NLS-2$
    pmCompositeRES.getListeBoitierPM().put("BOITIER_B", boitierB); //$NON-NLS-1$
    //  - Modif
    pmCompositeRES.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().remove("OLT2000_1_1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    pmCompositeRES.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().put(cleAdd, lienPortPMPonAdd); //$NON-NLS-1$ //$NON-NLS-2$

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeRES);

    // Construction PM mis à jour avec
    PMComposite pmCompositeRESSupp = createDefaultPMComposite();
    //  - Add
    pmCompositeRESSupp.getListeBoitierPM().put("BOITIER_B", boitierB); //$NON-NLS-1$
    //  - Modif
    pmCompositeRESSupp.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().remove("OLT2000_1_1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    pmCompositeRESSupp.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().put(cleAdd, lienPortPMPonAdd); //$NON-NLS-1$ //$NON-NLS-2$
    //  - Supp
    pmCompositeRESSupp.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_B").getListePortPM().get(1).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$


    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeRESSupp);

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    mockRES_OltCompositeGererImport(RetourFactoryForTU.createOkRetour(), oltCompositeTransforme);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.oltCompositemodifierSurchargeDateDebutQuarantaineOLT
    mockRES_OltCompositemodifierSurchargeDateDebutQuarantaineOLT(RetourFactoryForTU.createOkRetour(), null, "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Test de retours
    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
    Assert.assertEquals(new ArrayList<>(), _processInstance.getProcessContext().getListeProvisioning());
  }

  /**
   * <b>Cas de test:</b> ressourcePortPmGererMigrationPortPm NOK (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 202
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_OK_007() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport

    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    Retour retourRes = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_RessourcePortPmGererMigrationPortPm(retourRes, null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Construction PM mis à jour avec suppression
    PMComposite pmCompositeTransformeSupp = createUpdatedPMCompositeWithDelete();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransformeSupp);

    Set<ClientImpacte> listeClientImpacte = new HashSet<>();
    ClientImpacte clientImpacte1 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    clientImpacte1.setErreurProvisioning("Migration PortPm en echec : Error in RES"); //$NON-NLS-1$
    clientImpacte1.setStatutProvisioning("NOK");
    listeClientImpacte.add(clientImpacte1);
    ClientImpacte clientImpacte2 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte2);

    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, listeClientImpacte);

    // MOCK RES.oltCompositeLireUn - Cached

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    mockRES_OltCompositeGererImport(RetourFactoryForTU.createOkRetour(), oltCompositeTransforme);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.oltCompositemodifierSurchargeDateDebutQuarantaineOLT
    mockRES_OltCompositemodifierSurchargeDateDebutQuarantaineOLT(RetourFactoryForTU.createOkRetour(), null, "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$

    ProvisioningVDR prov1 = new ProvisioningVDRMigration(clientImpacte1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    prov1.setRessourcePortPM((RessourcePortPM)  ressource);
    ProvisioningVDR prov2 = new ProvisioningVDRModification(clientImpacte2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    prov2.setRessourcePortPM((RessourcePortPM)  ressource2);
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov2, prov1));

    // Test de retours
    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
    Assert.assertEquals(listeProvisioning.get(0), _processInstance._processContext.getListeProvisioning().get(0));
    Assert.assertEquals(listeProvisioning.get(1), _processInstance._processContext.getListeProvisioning().get(1));
  }

  /**
   * <b>Cas de test:</b> Verif lienPortPon false - Aucun client (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 202
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_OK_008() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);

    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 1, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 1, 1); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));


    PE0529_PostRequest creationRequest = new PE0529_PostRequest(typeOperation, Arrays.asList("PM")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));

    String donneesBrutes = RavelJsonTools.getInstance().toJson(creationRequest, PE0529_PostRequest.class);
    OperationVieReseau operation =  new OperationVieReseau(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name(), donneesBrutes);

    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PortPonId portPonId = new PortPonId("OLT2000", 1, 1); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", portPonId); //$NON-NLS-1$
    String cle = "OLT2000_1_1"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens = new HashMap<>();
    mapLiens.put(cle, lienPortPMPon);

    PortPonId portPonId2 = new PortPonId("OLT2000", 2, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon2 = new LienPortPMPon("OPERATIONNEL", portPonId2); //$NON-NLS-1$
    String cle2 = "OLT2000_2_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens2 = new HashMap<>();
    mapLiens2.put(cle2, lienPortPMPon2);

    Map<Integer, PortPM> mapPortPanneauAA = new HashMap<>();
    mapPortPanneauAA.put(1, new PortPM(1, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    mapPortPanneauAA.put(2, new PortPM(2, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    Map<Integer, PortPM> mapPortPanneauBA = new HashMap<>();
    mapPortPanneauBA.put(1, new PortPM(1, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    mapPortPanneauBA.put(2, new PortPM(2, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$

    PanneauPM panneauA_A = new PanneauPM("PANNEAU_A", "OPERATIONNEL", mapPortPanneauAA); //$NON-NLS-1$ //$NON-NLS-2$
    PanneauPM panneauA_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBA); //$NON-NLS-1$ //$NON-NLS-2$

    Map<String, PanneauPM> mapPanneauBoitierA = new HashMap<>();
    mapPanneauBoitierA.put("PANNEAU_A", panneauA_A); //$NON-NLS-1$
    mapPanneauBoitierA.put("PANNEAU_B", panneauA_B); //$NON-NLS-1$

    BoitierPM boitierA = new BoitierPM("BOITIER_A", "OPERATIONNEL", mapPanneauBoitierA); //$NON-NLS-1$ //$NON-NLS-2$

    PMComposite pmComposite = new PMComposite("GHYUI890", null, "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$
    pmComposite.getListeBoitierPM().put("BOITIER_A", boitierA); //$NON-NLS-1$

    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmComposite);

    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // MOCK RES.oltCompositeLireUn - Cached

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Test de retours
    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
    Assert.assertEquals(new ArrayList<>(), _processInstance._processContext.getListeProvisioning());
  }

  /**
   * <b>Cas de test:</b> ressourcePortPmGererMigrationPortPm NOK mais pas de modif port pon(<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 202
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_OK_009() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);

    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 1, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 1, 1); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));


    PE0529_PostRequest creationRequest = new PE0529_PostRequest(typeOperation, Arrays.asList("PM")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));

    String donneesBrutes = RavelJsonTools.getInstance().toJson(creationRequest, PE0529_PostRequest.class);
    OperationVieReseau operation =  new OperationVieReseau(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name(), donneesBrutes);

    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PortPonId portPonId = new PortPonId("OLT2000", 1, 1); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", portPonId); //$NON-NLS-1$
    String cle = "OLT2000_1_1"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens = new HashMap<>();
    mapLiens.put(cle, lienPortPMPon);

    PortPonId portPonId2 = new PortPonId("OLT2000", 2, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon2 = new LienPortPMPon("OPERATIONNEL", portPonId2); //$NON-NLS-1$
    String cle2 = "OLT2000_2_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens2 = new HashMap<>();
    mapLiens2.put(cle2, lienPortPMPon2);

    Map<Integer, PortPM> mapPortPanneauAA = new HashMap<>();
    mapPortPanneauAA.put(1, new PortPM(1, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    mapPortPanneauAA.put(2, new PortPM(2, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    Map<Integer, PortPM> mapPortPanneauBA = new HashMap<>();
    mapPortPanneauBA.put(1, new PortPM(1, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    mapPortPanneauBA.put(2, new PortPM(2, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$

    PanneauPM panneauA_A = new PanneauPM("PANNEAU_A", "OPERATIONNEL", mapPortPanneauAA); //$NON-NLS-1$ //$NON-NLS-2$
    PanneauPM panneauA_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBA); //$NON-NLS-1$ //$NON-NLS-2$

    Map<String, PanneauPM> mapPanneauBoitierA = new HashMap<>();
    mapPanneauBoitierA.put("PANNEAU_A", panneauA_A); //$NON-NLS-1$
    mapPanneauBoitierA.put("PANNEAU_B", panneauA_B); //$NON-NLS-1$

    BoitierPM boitierA = new BoitierPM("BOITIER_A", "OPERATIONNEL", mapPanneauBoitierA); //$NON-NLS-1$ //$NON-NLS-2$

    PMComposite pmComposite = new PMComposite("GHYUI890", null, "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$
    pmComposite.getListeBoitierPM().put("BOITIER_A", boitierA); //$NON-NLS-1$

    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmComposite, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmComposite);

    Retour retourRes = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_RessourcePortPmGererMigrationPortPm(retourRes, null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // MOCK RES.oltCompositeLireUn - Cached

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Test de retours
    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
    Assert.assertEquals(new ArrayList<>(), _processInstance._processContext.getListeProvisioning());
  }

  /**
   * <b>Cas de test:</b> RES.pmCompositeGererImport CAT-2 (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_012() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_PmCompositeGererImport(retour, pmCompositeTransforme);

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur dans gererImport de PMComposite GHYUI890."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> 2nd RES.pmCompositeGererImport CAT-2 (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_013() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Construction PM mis à jour avec suppression
    PMComposite pmCompositeTransformeSupp = createUpdatedPMCompositeWithDelete();

    // MOCK RES.pmCompositeGererImport
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_PmCompositeGererImport(retour, pmCompositeTransformeSupp);

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur dans gererImport de PMComposite GHYUI890."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauModifierListeClientImpacte CAT-2 (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_014() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    // MOCK RES.ressourceLireUn (PM) - Migration
    //mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Construction PM mis à jour avec suppression
    PMComposite pmCompositeTransformeSupp = createUpdatedPMCompositeWithDelete();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransformeSupp);

    Set<ClientImpacte> listeClientImpacte = new HashSet<>();
    ClientImpacte clientImpacte1 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte1);
    ClientImpacte clientImpacte2 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte2);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(retour, idOperationVieReseau, listeClientImpacte);

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur de modifierListeClientImpacte."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in REX", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> RES.oltCompositeGererImport CAT-2 (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_016() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    // MOCK RES.ressourceLireUn (PM) - Migration
    //mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Construction PM mis à jour avec suppression
    PMComposite pmCompositeTransformeSupp = createUpdatedPMCompositeWithDelete();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransformeSupp);

    Set<ClientImpacte> listeClientImpacte = new HashSet<>();
    ClientImpacte clientImpacte1 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte1);
    ClientImpacte clientImpacte2 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte2);

    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, listeClientImpacte);

    // MOCK RES.oltCompositeLireUn - Cached

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositeGererImport(retour, oltCompositeTransforme);

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur dans gererImport de OLTComposite OLT2000."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> RES.pmCompositeModifierSurchargeDateDebutQuarantainePM CAT-2 (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_017() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    // MOCK RES.ressourceLireUn (PM) - Migration
    //mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Construction PM mis à jour avec suppression
    PMComposite pmCompositeTransformeSupp = createUpdatedPMCompositeWithDelete();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransformeSupp);

    Set<ClientImpacte> listeClientImpacte = new HashSet<>();
    ClientImpacte clientImpacte1 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte1);
    ClientImpacte clientImpacte2 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte2);

    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, listeClientImpacte);

    // MOCK RES.oltCompositeLireUn - Cached

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    mockRES_OltCompositeGererImport(RetourFactoryForTU.createOkRetour(), oltCompositeTransforme);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(retour, "GHYUI890"); //$NON-NLS-1$

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur dans modifierSurchargeDateDebutQuarantainePM."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> RES.oltCompositemodifierSurchargeDateDebutQuarantaineOLT CAT-2 (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_018() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    // MOCK RES.ressourceLireUn (PM) - Migration
    //mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Construction PM mis à jour avec suppression
    PMComposite pmCompositeTransformeSupp = createUpdatedPMCompositeWithDelete();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransformeSupp);

    Set<ClientImpacte> listeClientImpacte = new HashSet<>();
    ClientImpacte clientImpacte1 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte1);
    ClientImpacte clientImpacte2 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte2);

    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, listeClientImpacte);

    // MOCK RES.oltCompositeLireUn - Cached

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    mockRES_OltCompositeGererImport(RetourFactoryForTU.createOkRetour(), oltCompositeTransforme);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.oltCompositemodifierSurchargeDateDebutQuarantaineOLT
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_OltCompositemodifierSurchargeDateDebutQuarantaineOLT(retour, null, "OLT2000"); //$NON-NLS-1$

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur dans modifierSurchargeDateDebutQuarantaineOLT."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> RES.operationVieReseauLireUn final CAT-2 (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 503 - SERVICE_TIERS_INDISPONIBLE
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_019() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    // MOCK RES.ressourceLireUn (PM) - Migration
    //mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Construction PM mis à jour avec suppression
    PMComposite pmCompositeTransformeSupp = createUpdatedPMCompositeWithDelete();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransformeSupp);

    Set<ClientImpacte> listeClientImpacte = new HashSet<>();
    ClientImpacte clientImpacte1 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte1);
    ClientImpacte clientImpacte2 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte2);

    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, listeClientImpacte);

    // MOCK RES.oltCompositeLireUn - Cached

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    mockRES_OltCompositeGererImport(RetourFactoryForTU.createOkRetour(), oltCompositeTransforme);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.oltCompositemodifierSurchargeDateDebutQuarantaineOLT
    mockRES_OltCompositemodifierSurchargeDateDebutQuarantaineOLT(RetourFactoryForTU.createOkRetour(), null, "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(retour, null, idOperationVieReseau);

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", MessageFormat.format("Erreur de lecture de OperationVieReseau {0}.", idOperationVieReseau)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in REX", reponseactual.getErrorDescription()); //$NON-NLS-1$
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> Statut final TRAITE_NOK (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> ResponseErreur 403 - ACCES_REFUSE - Operation annulee pendant le traitement mise a jour referentiel
   * topologie
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_020() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    // MOCK RES.ressourceLireUn (PM) - Migration
    //mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Construction PM mis à jour avec suppression
    PMComposite pmCompositeTransformeSupp = createUpdatedPMCompositeWithDelete();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransformeSupp);

    Set<ClientImpacte> listeClientImpacte = new HashSet<>();
    ClientImpacte clientImpacte1 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte1);
    ClientImpacte clientImpacte2 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte2);

    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, listeClientImpacte);

    // MOCK RES.oltCompositeLireUn - Cached

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    mockRES_OltCompositeGererImport(RetourFactoryForTU.createOkRetour(), oltCompositeTransforme);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.oltCompositemodifierSurchargeDateDebutQuarantaineOLT
    mockRES_OltCompositemodifierSurchargeDateDebutQuarantaineOLT(RetourFactoryForTU.createOkRetour(), null, "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    operation2.setStatut(OperationVieReseauStatut.TRAITE_NOK.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(IMessage.OPERATION_ANNULEE_TRAITEMENT_TOPO, reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.ACCES_REFUSE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> RES.ressourceLireUn (PORT_PM) CAT-2 ==> OVR TRAITE_NOK(<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> Response 202
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_KO_021() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("LIBRE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in RES"); //$NON-NLS-1$
    mockRES_RessourceLireUn(retour, null, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur de lecture de RessourcePortPM GHYUI890||BOITIER_A||PANNEAU_A||1."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Récupération du résultat de la requête
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    // Tests de retours
    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals("Error in RES", reponseactual.getErrorDescription());
    Assert.assertEquals(IMegSpiritConsts.SERVICE_INDISPONIBLE, reponseactual.getError());
  }

  /**
   * <b>Cas de test:</b> BL200 OK (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> Response 202
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_OK_001() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    // MOCK RES.ressourceLireUn (PM) - Migration
    //mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Construction PM mis à jour avec suppression
    PMComposite pmCompositeTransformeSupp = createUpdatedPMCompositeWithDelete();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransformeSupp);

    Set<ClientImpacte> listeClientImpacte = new HashSet<>();
    ClientImpacte clientImpacte1 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte1);
    ClientImpacte clientImpacte2 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte2);

    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, listeClientImpacte);

    // MOCK RES.oltCompositeLireUn - Cached

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    mockRES_OltCompositeGererImport(RetourFactoryForTU.createOkRetour(), oltCompositeTransforme);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.oltCompositemodifierSurchargeDateDebutQuarantaineOLT
    mockRES_OltCompositemodifierSurchargeDateDebutQuarantaineOLT(RetourFactoryForTU.createOkRetour(), null, "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$


    ProvisioningVDR prov1 = new ProvisioningVDRMigration(clientImpacte1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    prov1.setRessourcePortPM((RessourcePortPM)  ressource);
    ProvisioningVDR prov2 = new ProvisioningVDRModification(clientImpacte2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    prov2.setRessourcePortPM((RessourcePortPM)  ressource2);
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov2, prov1));

    // Test de retours
    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
    Assert.assertEquals(listeProvisioning.get(0), _processInstance._processContext.getListeProvisioning().get(0));
    Assert.assertEquals(listeProvisioning.get(1), _processInstance._processContext.getListeProvisioning().get(1));
  }

  /**
   * <b>Cas de test:</b> RES.ressourceLireUn (PORT_PM) CAT-4 DONNEE_INCONNUE(<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> Response 202
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_OK_002() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Donnee inconnue"); //$NON-NLS-1$
    mockRES_RessourceLireUn(retour, null, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    mockRES_RessourceLireUn(retour, null, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // Construction PM mis à jour
   //$NON-NLS-3$
    //  - Add
    PortPonId portPonId = new PortPonId("OLT2000", 1, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", portPonId); //$NON-NLS-1$
    String cle = "OLT2000_1_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens = new HashMap<>();
    mapLiens.put(cle, lienPortPMPon);
    Map<Integer, PortPM> mapPortPanneauBB = new HashMap<>();
    mapPortPanneauBB.put(2, new PortPM(2, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    PanneauPM panneauB_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBB); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> mapPanneauBoitierB = new HashMap<>();
    mapPanneauBoitierB.put("PANNEAU_B", panneauB_B); //$NON-NLS-1$
    BoitierPM boitierB = new BoitierPM("BOITIER_B", "OPERATIONNEL", mapPanneauBoitierB); //$NON-NLS-1$ //$NON-NLS-2$
    pmCompositeRES.getListeBoitierPM().put("BOITIER_B", boitierB); //$NON-NLS-1$
    //  - Modif
    pmCompositeRES.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().remove("OLT2000_1_1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    pmCompositeRES.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().put(cle, lienPortPMPon); //$NON-NLS-1$ //$NON-NLS-2$

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeRES);

    //  - Supp
    pmCompositeRES.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_B").getListePortPM().get(1).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$ //$NON-NLS-2$

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeRES);

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    mockRES_OltCompositeGererImport(RetourFactoryForTU.createOkRetour(), oltCompositeTransforme);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.oltCompositemodifierSurchargeDateDebutQuarantaineOLT
    mockRES_OltCompositemodifierSurchargeDateDebutQuarantaineOLT(RetourFactoryForTU.createOkRetour(), null, "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Test de retours
    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
    Assert.assertEquals(new ArrayList<>(), _processInstance._processContext.getListeProvisioning());
  }

  /**
   * <b>Cas de test:</b> RES.ressourceLireUn (PORT_PM) statut non ALLOUE (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> Response 202
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_OK_003() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource = new RessourcePortPM("GELE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // Construction PM mis à jour
    //  - Add
    PortPonId portPonIdAdd = new PortPonId("OLT2000", 1, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPonAdd = new LienPortPMPon("OPERATIONNEL", portPonIdAdd); //$NON-NLS-1$
    String cleAdd = "OLT2000_1_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiensAdd = new HashMap<>();
    mapLiensAdd.put(cleAdd, lienPortPMPonAdd);
    Map<Integer, PortPM> mapPortPanneauBB = new HashMap<>();
    mapPortPanneauBB.put(2, new PortPM(2, "OPERATIONNEL", mapLiensAdd)); //$NON-NLS-1$
    PanneauPM panneauB_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBB); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> mapPanneauBoitierB = new HashMap<>();
    mapPanneauBoitierB.put("PANNEAU_B", panneauB_B); //$NON-NLS-1$
    BoitierPM boitierB = new BoitierPM("BOITIER_B", "OPERATIONNEL", mapPanneauBoitierB); //$NON-NLS-1$ //$NON-NLS-2$
    pmCompositeRES.getListeBoitierPM().put("BOITIER_B", boitierB); //$NON-NLS-1$
    //  - Modif
    pmCompositeRES.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().remove("OLT2000_1_1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    pmCompositeRES.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().put(cleAdd, lienPortPMPonAdd); //$NON-NLS-1$ //$NON-NLS-2$

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeRES);

    // Construction PM mis à jour avec
    //  - Supp
    pmCompositeRES.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_B").getListePortPM().get(1).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$


    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeRES);

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    mockRES_OltCompositeGererImport(RetourFactoryForTU.createOkRetour(), oltCompositeTransforme);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.oltCompositemodifierSurchargeDateDebutQuarantaineOLT
    mockRES_OltCompositemodifierSurchargeDateDebutQuarantaineOLT(RetourFactoryForTU.createOkRetour(), null, "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    // Test de retours
    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
    Assert.assertEquals(new ArrayList<>(), _processInstance.getProcessContext().getListeProvisioning());
  }

  /**
   * <b>Cas de test:</b> BL200 OK (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> Response 202
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_OK_004_SPIRIT3127() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);
    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 1, 2); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_B"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_B", null); //$NON-NLS-1$
    PositionPortPm posPortPmAjout = new PositionPortPm(2, "PANNEAU_B", "BOITIER_B", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmAjout, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);
    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 1, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 1, 2); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));
    PE0529_PostRequest creationRequest = new PE0529_PostRequest(typeOperation, Arrays.asList("PM")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    String donneesBrutes = RavelJsonTools.getInstance().toJson(creationRequest, PE0529_PostRequest.class);
    OperationVieReseau operation = new OperationVieReseau(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name(), donneesBrutes);

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM Transformé
    PMComposite pmCompositeTransforme = createDefaultPMComposite();
    //  - Add
    PortPonId portPonId = new PortPonId("OLT2000", 1, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", portPonId); //$NON-NLS-1$
    String cle = "OLT2000_1_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens = new HashMap<>();
    mapLiens.put(cle, lienPortPMPon);
    Map<Integer, PortPM> mapPortPanneauBB = new HashMap<>();
    mapPortPanneauBB.put(2, new PortPM(2, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    PanneauPM panneauB_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBB); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> mapPanneauBoitierB = new HashMap<>();
    mapPanneauBoitierB.put("PANNEAU_B", panneauB_B); //$NON-NLS-1$
    BoitierPM boitierB = new BoitierPM("BOITIER_B", "OPERATIONNEL", mapPanneauBoitierB); //$NON-NLS-1$ //$NON-NLS-2$
    pmCompositeTransforme.getListeBoitierPM().put("BOITIER_B", boitierB); //$NON-NLS-1$
    //  - Modif
    pmCompositeTransforme.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().remove("OLT2000_1_1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    pmCompositeTransforme.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().put(cle, lienPortPMPon); //$NON-NLS-1$ //$NON-NLS-2$
    //  - Migr
    PortPM portPM = pmCompositeTransforme.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(1); //$NON-NLS-1$ //$NON-NLS-2$
    PortPM newPortPm = new PortPM(2, "OPERATIONNEL", portPM.getListeLienPortPMPon()); //$NON-NLS-1$
    newPortPm.setIdRessourceRaccordement(portPM.getIdRessourceRaccordement());
    newPortPm.setSurchargePortPM(portPM.getSurchargePortPM());
    newPortPm.setNomCoupleur(portPM.getNomCoupleur());
    newPortPm.setDateCreation(portPM.getDateCreation());
    newPortPm.setDateModification(portPM.getDateModification());
    pmCompositeTransforme.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_B").getListePortPM().put(2, newPortPm); //$NON-NLS-1$ //$NON-NLS-2$

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    // MOCK RES.ressourcePortPmGererMigrationPortPm
    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$


    // Construction PM Transformé
    PMComposite pmCompositeTransformeSupp = createDefaultPMComposite();
    //  - Add
    pmCompositeTransformeSupp.getListeBoitierPM().put("BOITIER_B", boitierB); //$NON-NLS-1$
    //  - Modif
    pmCompositeTransformeSupp.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().remove("OLT2000_1_1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    pmCompositeTransformeSupp.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().put(cle, lienPortPMPon); //$NON-NLS-1$ //$NON-NLS-2$
    //  - Migr
    pmCompositeTransformeSupp.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_B").getListePortPM().put(2, newPortPm); //$NON-NLS-1$ //$NON-NLS-2$
    //  - Supp
    pmCompositeTransformeSupp.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_B").getListePortPM().get(1).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransformeSupp);

    Set<ClientImpacte> listeClientImpacte = new HashSet<>();
    ClientImpacte clientImpacte1 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte1);
    ClientImpacte clientImpacte2 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte2);

    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, listeClientImpacte);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    ProvisioningVDR prov1 = new ProvisioningVDRMigration(clientImpacte1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(clientImpacte2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov2, prov1));

    // Test de retours
    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
    Assert.assertEquals(listeProvisioning, _processInstance._processContext.getListeProvisioning());
  }

  /**
   * <b>Cas de test:</b> BL200 OK - NOKIA False (<br/>
   * <b>Entrées:</b> Requête avec body OK<br/>
   * <b>Attendu:</b> Response 202
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL200_OK_005() throws Throwable
  {
    // Préparation de la requête
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String action = "executer"; //$NON-NLS-1$
    PE0529_PutRequest modificationRequest = new PE0529_PutRequest(action);
    List<RequestHeader> headers = addXHeaders("REQUEST_ID", "PROCESS", "SOURCE", "MESSAGE", "ACTION", "AUTHORIZATION"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
    Request request = preparePutRequest(modificationRequest, headers, idOperationVieReseau);

    // Preparation de la configuration
    ProcessManager.getInstance().getProcessParams().clear();
    Map<String, String> map = new ConcurrentHashMap<>();
    File classpath = new File(PE0529_PutOperationVieReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    map.put(PARAM_FILE_PATH, classpath + CONFIG_FILE_HUAWEI);
    ProcessManager.getInstance().getProcessParams().put(StringConstants.EMPTY_STRING, map);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.ACQUITTE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche PM
    OperationVieReseau operation2 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation2), typeOperation, TypeIdentifiant.PM.name(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauCompositeLireTousParCleRecherche OLT
    OperationVieReseau operation3 = new OperationVieReseau(null, null, OperationVieReseauStatut.OBSOLETE.name(), null);
    mockREX_OperationVieReseauCompositeLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(operation3), typeOperation, TypeIdentifiant.OLT.name(), "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    // MOCK RES.pmCompositeLireUnParReferencePmBytel
    PMComposite pmCompositeRES = createDefaultPMComposite();
    mockRES_PmCompositeLireUnParReferencePmBytel(RetourFactoryForTU.createOkRetour(), pmCompositeRES, "GHYUI890"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Modification
    Ressource ressource2 = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 2); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource2.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource2, "GHYUI890||BOITIER_A||PANNEAU_A||2", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Modification
    OltComposite oltComposite = createDefaultOLTComposite();
    mockRES_OltCompositeLireUn(RetourFactoryForTU.createOkRetour(), oltComposite, "OLT2000"); //$NON-NLS-1$

    // MOCK RES.ressourceLireUn (PM) - Migration
    Ressource ressource = new RessourcePortPM("ALLOUE", "GHYUI890", "PANNEAU_A", "PANNEAU_A", 1); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    ressource.setIdRessourceLie("idRessourceLie"); //$NON-NLS-1$
    mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    // MOCK RES.oltCompositeLireUn - Migration - Cached

    // Construction PM mis à jour
    PMComposite pmCompositeTransforme = createUpdatedPMComposite();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransforme);

    // MOCK RES.ressourceLireUn (PM) - Migration
    //mockRES_RessourceLireUn(RetourFactoryForTU.createOkRetour(), ressource, "GHYUI890||BOITIER_A||PANNEAU_A||1", TypeRessource.PORT_PM.name()); //$NON-NLS-1$

    mockRES_RessourcePortPmGererMigrationPortPm(RetourFactoryForTU.createOkRetour(), null, "GHYUI890||BOITIER_A||PANNEAU_A||1", "PHYSIQUE", "GHYUI890", null, "BOITIER_A", null, "PANNEAU_B", 2, null, "idRessourceLie"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$

    // Construction PM mis à jour avec suppression
    PMComposite pmCompositeTransformeSupp = createUpdatedPMCompositeWithDelete();

    // MOCK RES.pmCompositeGererImport
    mockRES_PmCompositeGererImport(RetourFactoryForTU.createOkRetour(), pmCompositeTransformeSupp);

    Set<ClientImpacte> listeClientImpacte = new HashSet<>();
    ClientImpacte clientImpacte1 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte1);
    ClientImpacte clientImpacte2 = new ClientImpacte("idRessourceLie", "ID_RACCORDEMENT");  //$NON-NLS-1$ //$NON-NLS-2$
    clientImpacte2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    listeClientImpacte.add(clientImpacte2);

    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, listeClientImpacte);

    // MOCK RES.oltCompositeLireUn - Cached

    // Construction OLT transformé
    OltComposite oltCompositeTransforme = createDefaultOLTComposite();
    //  - Supp
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(3).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$
    //  - Add
    CartePON cartePON = new CartePON(2, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    cartePON.getListePortPON().put(1, portPON);
    oltCompositeTransforme.getListeCartePON().put(2, cartePON);
    //  - Modif
    oltCompositeTransforme.getListeCartePON().get(1).getListePortPON().get(1).setSfpListeTechnologieCompatible(new HashSet<>(Collections.singletonList("XGPON"))); //$NON-NLS-1$

    // MOCK RES.oltCompositeGererImport
    mockRES_OltCompositeGererImport(RetourFactoryForTU.createOkRetour(), oltCompositeTransforme);

    // MOCK REX.pmCompositeModifierSurchargeDateDebutQuarantainePM
    mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(RetourFactoryForTU.createOkRetour(), "GHYUI890"); //$NON-NLS-1$

    // MOCK REX.oltCompositemodifierSurchargeDateDebutQuarantaineOLT
    mockRES_OltCompositemodifierSurchargeDateDebutQuarantaineOLT(RetourFactoryForTU.createOkRetour(), null, "OLT2000"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Lancement de la requête
    PowerMock.replayAll();
    request.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.startPutProcess(request, _tracabilite);
    Response response = (Response) request.getResponse();
    PowerMock.verifyAll();

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$


    ProvisioningVDR prov1 = new ProvisioningVDRMigration(clientImpacte1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.setRessourcePortPM((RessourcePortPM)  ressource);
    ProvisioningVDR prov2 = new ProvisioningVDRModification(clientImpacte2, posPortPmModif);
    prov2.setRessourcePortPM((RessourcePortPM)  ressource2);
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov2, prov1));

    // Test de retours
    Assert.assertEquals(ErrorCode.OK_00202, response.getErrorCode());
    Assert.assertEquals(listeProvisioning.get(0), _processInstance._processContext.getListeProvisioning().get(0));
    Assert.assertEquals(listeProvisioning.get(1), _processInstance._processContext.getListeProvisioning().get(1));
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauLireUn NOK (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL400_KO_001() throws Throwable
  {
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(retourExpected, null, idOperationVieReseau);

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", MessageFormat.format("Erreur de lecture de OperationVieReseau {0}.", idOperationVieReseau)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL400_Provisioning", _tracabilite, idOperationVieReseau); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourExpected, retourActual);
  }

  /**
   * <b>Cas de test:</b> OperationVieReseau au statut TRAITE_NOK (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL400_KO_002() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.TRAITE_NOK.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, IMessage.OPERATION_ANNULEE_TRAITEMENT_TOPO);

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL400_Provisioning", _tracabilite, idOperationVieReseau); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, retourExpected);
  }

  /**
   * <b>Cas de test:</b> OperationVieReseau au statut different de EN_COURS_MAJ_REFERENTIEL (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL400_KO_003() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.OBSOLETE.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, IMessage.ERREUR_STATUT);

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL400_Provisioning", _tracabilite, idOperationVieReseau); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, retourExpected);
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauModifierStatut > EN_COURS_PROVISIONING CAT2 (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL400_KO_004() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierStatut(retourExpected, idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur de modifierStatut d'Operation début provisioning."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL400_Provisioning", _tracabilite, idOperationVieReseau); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, retourExpected);
  }

  /**
   * <b>Cas de test:</b> REX.OpertionVieReseauLireUn NOK - provisioning (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL400_KO_005() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauLireUn(retourExpected, null, idOperationVieReseau);

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", MessageFormat.format("Erreur de lecture de OperationVieReseau {0}.", idOperationVieReseau)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL400_Provisioning", _tracabilite, idOperationVieReseau); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, retourExpected);
  }

  /**
   * <b>Cas de test:</b> REX.operationVieReseauModifierListeClientImpacte après creation Action Corrective (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL400_KO_006() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(retourExpected, idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur de modifierListeClientImpacte."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL400_Provisioning", _tracabilite, idOperationVieReseau); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, retourExpected);
  }

  /**
   * <b>Cas de test:</b> Suivi statut invalide et REX.operationVieReseauModifierListeClientImpacte CAT2 (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL400_KO_007() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock GET
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(200, null);
    Suivi suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.INVALIDE.name());
    suivi.setLibelleErreur("Erreur"); //$NON-NLS-1$
    starkResponseGET.setResponse(suivi);
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET);

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Error in REX"); //$NON-NLS-1$
    ClientImpacte c4 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c4.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c4.setStatutProvisioning(ClientImpacteStatutProvisionning.NOK.name());
    c4.setErreurProvisioning("Erreur"); //$NON-NLS-1$
    c4.setIdCommande(idActionCorrective);
    mockREX_OperationVieReseauModifierListeClientImpacte(retourExpected, idOperationVieReseau, new HashSet<>(Collections.singletonList(c4)));

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Erreur de modifierListeClientImpacte."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL400_Provisioning", _tracabilite, idOperationVieReseau); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, retourExpected);
  }

  /**
   * <b>Cas de test:</b> Suivi statut invalide et REX.operationVieReseauModifierStatut CAT2 (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL400_KO_008() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock GET
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(200, null);
    Suivi suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.INVALIDE.name());
    suivi.setLibelleErreur("Erreur"); //$NON-NLS-1$
    starkResponseGET.setResponse(suivi);
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET);

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c2 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c2.setStatutProvisioning(ClientImpacteStatutProvisionning.NOK.name());
    c2.setErreurProvisioning("Erreur"); //$NON-NLS-1$
    c2.setIdCommande(idActionCorrective);
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Collections.singletonList(c2)));

    // MOCK REX.operationVieReseauModifierStatut
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierStatut(retourExpected, idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL400_Provisioning", _tracabilite, idOperationVieReseau); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, retourExpected);
  }

  /**
   * <b>Cas de test:</b> Suivi statut traite et REX.operationVieReseauModifierStatut CAT2 (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_BL400_KO_009() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock GET
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(200, null);
    Suivi suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE.name());
    starkResponseGET.setResponse(suivi);
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET);

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c2 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c2.setStatutProvisioning(ClientImpacteStatutProvisionning.TRAITE_OK.name());
    c2.setIdCommande(idActionCorrective);
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Collections.singletonList(c2)));

    // MOCK REX.operationVieReseauModifierStatut
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in REX"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierStatut(retourExpected, idOperationVieReseau, OperationVieReseauStatut.TRAITE_OK.name(), null, null);

    // Lancement de la requête
    PowerMock.replayAll();
    Retour retourActual = Whitebox.invokeMethod(_processInstance, "PE0529_BL400_Provisioning", _tracabilite, idOperationVieReseau); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(retourActual, retourExpected);
  }

  /**
   * <b>Cas de test:</b> BL002 retour non null (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_KO_001() throws Throwable
  {
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, "The body request is empty.")); //$NON-NLS-1$
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);

    // MOCK BL4600
    mockBL4600(bl002Return._first, RetourFactoryForTU.createOkRetour());

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(bl002Return._first, _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> Exception pendant BL400 (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_KO_002() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    // MOCK REX.operationVieReseauLireUn
    RavelException ravelException = new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception"); //$NON-NLS-1$
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(1);
    EasyMock.expect(_rexProxyMock.operationVieReseauLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idOperationVieReseau))).andThrow(ravelException);

    // MOCK BL4600
    mockBL4600(null, RetourFactory.createOkRetour());

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(IMegConsts.CAT10, _processInstance.getRetour().getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, _processInstance.getRetour().getDiagnostic());
    Assert.assertEquals("Exception", _processInstance.getRetour().getLibelle()); //$NON-NLS-1$
  }

  /**
   * <b>Cas de test:</b> listePortPmImpacte vide et REX.operationVieReseauModifierStatut OK (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_001() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_OK.name(), null, null);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> Nominal OK - Traite_Ok (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_002() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock GET -  DEMARRE 5 fois
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(200, null);
    Suivi suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.DEMARRE.name());
    starkResponseGET.setResponse(suivi);
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(5);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET).times(5);

    // Mock GET -  TRAITE
    starkResponseGET = new STARKResponse<>(200, null);
    suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE.name());
    starkResponseGET.setResponse(suivi);
    connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET);

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c4 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c4.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c4.setStatutProvisioning(ClientImpacteStatutProvisionning.TRAITE_OK.name());
    c4.setIdCommande(idActionCorrective);
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c4)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_OK.name(), null, null);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> Nominal OK -  1 Traite_NOK BL200 et 1 Traite_OK (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_002b() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte(null, "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c2.setStatutProvisioning("NOK"); //$NON-NLS-1$
    c2.setErreurProvisioning("Erreur"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c2, c3)));

    // Mock GET -  DEMARRE 5 fois
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(200, null);
    Suivi suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.DEMARRE.name());
    starkResponseGET.setResponse(suivi);
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(5);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET).times(5);

    // Mock GET -  TRAITE
    starkResponseGET = new STARKResponse<>(200, null);
    suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE.name());
    starkResponseGET.setResponse(suivi);
    connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET);

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c4 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c4.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c4.setStatutProvisioning(ClientImpacteStatutProvisionning.TRAITE_OK.name());
    c4.setIdCommande(idActionCorrective);
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c2, c4)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), "COMMANDE_TRAITEE_NOK", "Au moins un provisioning a terminé avec NOK."); //$NON-NLS-1$ //$NON-NLS-2$

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> Nominal OK - Traite_Nok (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_003() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock GET -  DEMARRE 5 fois
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(200, null);
    Suivi suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.DEMARRE.name());
    starkResponseGET.setResponse(suivi);
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(5);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET).times(5);

    // Mock GET -  INVALIDE
    starkResponseGET = new STARKResponse<>(200, null);
    suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.INVALIDE.name());
    suivi.setLibelleErreur("Erreur"); //$NON-NLS-1$
    starkResponseGET.setResponse(suivi);
    connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET);

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c2 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c2.setStatutProvisioning(ClientImpacteStatutProvisionning.NOK.name());
    c2.setIdCommande(idActionCorrective);
    c2.setErreurProvisioning("Erreur"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Collections.singletonList(c2)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> AIR.indexRechercherPfiLireTousParCleRecherche DONNEE_INCONNUE (<br/>
   * Aucun noClient, ClientImpacte NOK, Operation NOK, Processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_004() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INCONNUE, "Error in AIR"); //$NON-NLS-1$
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(retourExpected, null, "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(retourExpected, null, "ID_RACCORDEMENT", c2.getIdentifiantClient()); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c3.setStatutProvisioning("NOK");
    c3.setErreurProvisioning("NoClient associe au port GHYUI890/BOITIER_A/PANNEAU_B/2 non trouve."); //$NON-NLS-1$
    ClientImpacte c4 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c4.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c4.setStatutProvisioning("NOK");
    c4.setErreurProvisioning("NoClient associe au port GHYUI890/BOITIER_A/PANNEAU_A/2 non trouve."); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3, c4)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> RPG.pfiLireUn NOK (<br/>
   * Aucun noClient, ClientImpacte NOK, Operation NOK, Processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_005() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in RPG"); //$NON-NLS-1$
    mockRPG_PfiLireUn(retour, null, clientOperation, noCompte);

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c2.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    mockRPG_PfiLireUn(retour, null, clientOperation, noCompte);

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c5 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c5.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c5.setStatutProvisioning("NOK");
    c5.setErreurProvisioning("noCompte n'existe pas"); //$NON-NLS-1$
    ClientImpacte c6 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c6.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c6.setStatutProvisioning("NOK");
    c6.setErreurProvisioning("noCompte n'existe pas"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c5, c6)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> Operation vie reseau au mauvais statut pour effectuer le provisionning (<br/>
   * Provisioning annulé, OVR au statut NOK, Processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_006() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock the update to the statut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, "TRAITE_NOK", "TRAITEMENT_ARRETE", "Operation annulée."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> Nominal OK - Traite_Ok - Lissage de charge false(<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_007() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(false);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock GET -  DEMARRE 5 fois
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(200, null);
    Suivi suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.DEMARRE.name());
    starkResponseGET.setResponse(suivi);
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(5);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET).times(5);

    // Mock GET -  TRAITE
    starkResponseGET = new STARKResponse<>(200, null);
    suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE.name());
    starkResponseGET.setResponse(suivi);
    connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET);

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c2 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c2.setStatutProvisioning(ClientImpacteStatutProvisionning.TRAITE_OK.name());
    c2.setIdCommande(idActionCorrective);
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Collections.singletonList(c2)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_OK.name(), null, null);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> Deux clients : Un BL850 NOK, un BL850 OK  (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_008() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in BL850"); //$NON-NLS-1$
    mockBL850(retourExpected, "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c2.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c5 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c5.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c5.setIdCommande(idActionCorrective);
    ClientImpacte c6 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c6.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c6.setIdCommande(idActionCorrective);
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c5, c6)));

    // Mock GET -  TRAITE 1 fois pour chaque client
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(200, null);
    Suivi suivi = new Suivi(com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE.name());
    starkResponseGET.setResponse(suivi);
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(2);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET).times(2);

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c7 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c7.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c7.setStatutProvisioning(ClientImpacteStatutProvisionning.TRAITE_OK.name());
    c7.setIdCommande(idActionCorrective);
    ClientImpacte c8 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c8.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c8.setStatutProvisioning(ClientImpacteStatutProvisionning.TRAITE_OK.name());
    c8.setIdCommande(idActionCorrective);
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c7,c8)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_OK.name(), null, null);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 POST NOK (<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_009() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in POST"); //$NON-NLS-1$
    STARKResponse<ReponseErreur> starkResponse = new STARKResponse<>(500, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = new ConnectorResponse<>(retourExpected, starkResponse);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c2.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c5 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c5.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c5.setStatutProvisioning("NOK");
    c5.setErreurProvisioning("POST ActionCorrective en echec : Error in POST"); //$NON-NLS-1$
    ClientImpacte c6 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c6.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c6.setStatutProvisioning("NOK");
    c6.setErreurProvisioning("POST ActionCorrective en echec : Error in POST"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c6, c5)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 POST OK mais ResonseErreur (<br/>
   * Clients impactes NOK, Operation NOK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_010() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    STARKResponse<ReponseErreur> starkResponse = new STARKResponse<>(500, null);
    starkResponse.setReponseErreur(new ReponseErreur("Erreur", "ErreurDesc")); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponse);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c2.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c5 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c5.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c5.setStatutProvisioning("NOK");
    c5.setErreurProvisioning("POST ActionCorrective en echec : Erreur : ErreurDesc"); //$NON-NLS-1$
     ClientImpacte c6 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c6.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c6.setStatutProvisioning("NOK");
    c6.setErreurProvisioning("POST ActionCorrective en echec : Erreur : ErreurDesc"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c5, c6)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 POST throws exception (<br/>
   * Clients impactes NOK, Operation NOK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_011() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    RavelException ravelException = new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception"); //$NON-NLS-1$
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andThrow(ravelException);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c2.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andThrow(ravelException);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c5 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c5.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c5.setStatutProvisioning("NOK");
    c5.setErreurProvisioning("POST ActionCorrective en echec : Exception"); //$NON-NLS-1$
    ClientImpacte c6 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c6.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c6.setStatutProvisioning("NOK");
    c6.setErreurProvisioning("POST ActionCorrective en echec : Exception"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c5, c6)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 POST mais reponseHeaders vides (<br/>
   * Clients impactes NOK, Operation NOK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_012() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    STARKResponse<ReponseErreur> starkResponse = new STARKResponse<>(201, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponse);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c2.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponse);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c5 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$  //$NON-NLS-2$
    c5.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c5.setStatutProvisioning("NOK");
    c5.setErreurProvisioning("POST ActionCorrective en echec : Erreur lors de la récupération de l'identifiant de l'action corrective."); //$NON-NLS-1$
    ClientImpacte c6 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$  //$NON-NLS-2$
    c6.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c6.setStatutProvisioning("NOK");
    c6.setErreurProvisioning("POST ActionCorrective en echec : Erreur lors de la récupération de l'identifiant de l'action corrective."); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c5, c6)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 PUT NOK (<br/>
   * Clients impactes NOK, Operation NOK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_013() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in PUT"); //$NON-NLS-1$
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(500, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(retour, starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c2.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c5 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c5.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c5.setStatutProvisioning("NOK");
    c5.setErreurProvisioning("PUT ActionCorrective en echec : Error in PUT"); //$NON-NLS-1$
    ClientImpacte c6 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c6.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c6.setStatutProvisioning("NOK");
    c6.setErreurProvisioning("PUT ActionCorrective en echec : Error in PUT"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c5, c6)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 PUT avec ReponseErreur non vide (<br/>
   * Clients impactes NOK, Operation NOK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_014() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(500, null);
    starkResponsePUT.setReponseErreur(new ReponseErreur("Erreur", "ErreurDesc")); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c2.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c5 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c5.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c5.setStatutProvisioning("NOK");
    c5.setErreurProvisioning("PUT ActionCorrective en echec : Erreur : ErreurDesc"); //$NON-NLS-1$
    ClientImpacte c6 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c6.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c6.setStatutProvisioning("NOK");
    c6.setErreurProvisioning("PUT ActionCorrective en echec : Erreur : ErreurDesc"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c5, c6)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 PUT throws exception (<br/>
   * Clients impactes NOK, Operation NOK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_015() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ClientImpacte c2 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    ProvisioningVDR prov2 = new ProvisioningVDRModification(c2, posPortPmModif);
    prov2.addCleSequencement("OLT200011"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1, prov2));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    RavelException ravelException = new RavelException(ExceptionType.UNDEFINED, ErrorCode.CNCTOR_00010, "Exception"); //$NON-NLS-1$
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andThrow(ravelException);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK REX.operationVieReseauLireUn
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c2.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andThrow(ravelException);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c5 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c5.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c5.setStatutProvisioning("NOK");
    c5.setErreurProvisioning("PUT ActionCorrective en echec : Exception"); //$NON-NLS-1$
    ClientImpacte c6 = new ClientImpacte("IDClient2", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c6.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||2"); //$NON-NLS-1$
    c6.setStatutProvisioning("NOK");
    c6.setErreurProvisioning("PUT ActionCorrective en echec : Exception"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c5, c6)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 GET NOK (<br/>
   * Clients impactes NOK, Operation NOK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_016() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock GET
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "Error in GET"); //$NON-NLS-1$
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(500, null);
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(retour, starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET).once();
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, "Error in GET"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c2 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c2.setStatutProvisioning(ClientImpacteStatutProvisionning.TRAITE_OK.name());
    c2.setIdCommande(idActionCorrective);
    c2.setStatutProvisioning("NOK");
    c2.setErreurProvisioning("GET ActionCorrective en echec : Error in GET"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Collections.singletonList(c2)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 GET mais ReponseErreur non vide (<br/>
   * Clients impactes NOK, Operation NOK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_017() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock GET
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(500, null);
    starkResponseGET.setReponseErreur(new ReponseErreur("Erreur", "ErreurDesc")); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET);
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "Erreur : ErreurDesc"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c2 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c2.setStatutProvisioning(ClientImpacteStatutProvisionning.TRAITE_OK.name());
    c2.setIdCommande(idActionCorrective);
    c2.setStatutProvisioning("NOK");
    c2.setErreurProvisioning("GET ActionCorrective en echec : Erreur : ErreurDesc"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Collections.singletonList(c2)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 GET throws exception (<br/>
   * Clients impactes NOK, Operation NOK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_018() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock GET
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(500, null);
    starkResponseGET.setReponseErreur(new ReponseErreur("Erreur", "ErreurDesc")); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET);
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "Erreur : ErreurDesc"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c2 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c2.setStatutProvisioning(ClientImpacteStatutProvisionning.TRAITE_OK.name());
    c2.setIdCommande(idActionCorrective);
    c2.setStatutProvisioning("NOK");
    c2.setErreurProvisioning("GET ActionCorrective en echec : Erreur : ErreurDesc"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Collections.singletonList(c2)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> PEI0229 GET mais Suivi vide (<br/>
   * Clients impactes NOK, Operation NOK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_019() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ClientImpacte c1 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c1.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    ProvisioningVDR prov1 = new ProvisioningVDRMigration(c1, posPortPmMigreSrc, posPortPmMigreCible);
    prov1.addCleSequencement("OLT200022"); //$NON-NLS-1$
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>(Arrays.asList(prov1));
    _processInstance.getProcessContext().setListeProvisioning(listeProvisioning);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation2 = createDefaultOperationVieReseauSimple(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_PROVISIONING.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation2, idOperationVieReseau);

    // Mock AIR.indexRechercherPfiLireTousParCleRecherche
    IndexRecherchePfi index = new IndexRecherchePfi(clientOperation, noCompte);
    mockAIR_IndexRechercherPfiLireTousParCleRecherche(RetourFactoryForTU.createOkRetour(), Collections.singletonList(index), "ID_RACCORDEMENT", c1.getIdentifiantClient()); //$NON-NLS-1$

    // Mock RPG.pfiLireUn
    PFI pfi = new PFI();
    PA pa = new PA("id", TypePA.FAX.name(), com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF, LocalDateTime.now(), LocalDateTime.now()); //$NON-NLS-1$
    pa.setPaTypeFax(new PaTypeFax("0200000000")); //$NON-NLS-1$
    pfi.setPa(Collections.singletonList(pa));
    mockRPG_PfiLireUn(RetourFactoryForTU.createOkRetour(), pfi, clientOperation, noCompte);

    mockBL850(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // Mock POST
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.LOCATION, idActionCorrective);
    STARKResponse<ReponseErreur> starkResponsePOST = new STARKResponse<>(201, headers);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePOST = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePOST);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).once();
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePOST);

    // Mock PUT
    STARKResponse<ReponseErreur> starkResponsePUT = new STARKResponse<>(202, null);
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponsePUT = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponsePUT);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(ReponseErreur.class))).andReturn(connectorResponsePUT);

    mockBL851(RetourFactoryForTU.createOkRetour(), "LISSAGE_CHARGE_VDR"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c3 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$
    c3.setIdCommande(idActionCorrective);
    c3.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Arrays.asList(c3)));

    // Mock GET
    STARKResponse<Suivi> starkResponseGET = new STARKResponse<>(500, null);
    starkResponseGET.setReponseErreur(new ReponseErreur("Erreur", "ErreurDesc")); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponseGET = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), starkResponseGET);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxy).times(1);
    EasyMock.expect(_starkProxy.sendRequest(EasyMock.anyObject(), EasyMock.eq(Suivi.class))).andReturn(connectorResponseGET);
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "Erreur : ErreurDesc"); //$NON-NLS-1$

    // MOCK RES.operationVieReseauModifierListeClientImpacte
    ClientImpacte c2 = new ClientImpacte("IDClient1", "ID_RACCORDEMENT"); //$NON-NLS-1$ //$NON-NLS-2$
    c2.setIdRessource("GHYUI890||BOITIER_A||PANNEAU_A||1"); //$NON-NLS-1$
    c2.setStatutProvisioning(ClientImpacteStatutProvisionning.TRAITE_OK.name());
    c2.setIdCommande(idActionCorrective);
    c2.setStatutProvisioning("NOK");
    c2.setErreurProvisioning("GET ActionCorrective en echec : Erreur : ErreurDesc"); //$NON-NLS-1$
    mockREX_OperationVieReseauModifierListeClientImpacte(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, new HashSet<>(Collections.singletonList(c2)));

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, IMessage.PROVISIONNING_NOK);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   * <b>Cas de test:</b> Aucun client impacte (<br/>
   * Operation OK, processus OK
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0529_Test_PUT_ContinueProcess_OK_020() throws Throwable
  {
    String idOperationVieReseau = __podam.manufacturePojoWithFullData(String.class);
    String clientOperation = __podam.manufacturePojoWithFullData(String.class);
    String noCompte = __podam.manufacturePojoWithFullData(String.class);
    String typeOperation = "PON1283"; //$NON-NLS-1$
    String idActionCorrective = __podam.manufacturePojoWithFullData(String.class);
    Pair<Retour, ReponseErreur> bl002Return = createBL002Retour(RetourFactory.createOkRetour());
    _processInstance.getProcessContext().setState(State.PE0529_CONTINUE);
    _processInstance.getProcessContext().setBl002Return(bl002Return);
    _processInstance.getProcessContext().setProcessRetour(bl002Return._first);
    _processInstance.getProcessContext().setIdOperationVieReseau(idOperationVieReseau);

    ConfigurationPE0529 config = new ConfigurationPE0529();
    config.setSequencerOltHuawei(true);
    config.setSequencerOltNokia(true);
    config.setLissageDeCharge(true);
    _processInstance.getProcessContext().setConfigurationPE0529(config);

    // MOCK REX.operationVieReseauLireUn
    OperationVieReseau operation = createDefaultOperationVieReseauMigration(idOperationVieReseau, typeOperation, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name());
    mockREX_OperationVieReseauLireUn(RetourFactoryForTU.createOkRetour(), operation, idOperationVieReseau);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), null, null);

    // MOCK REX.operationVieReseauModifierStatut
    mockREX_OperationVieReseauModifierStatut(RetourFactoryForTU.createOkRetour(), idOperationVieReseau, OperationVieReseauStatut.TRAITE_OK.name(), null, null);

    // Lancement de la requête
    PowerMock.replayAll();
    _processInstance.continuePutProcess(_tracabilite);
    PowerMock.verifyAll();

    Assert.assertEquals(State.PE0529_END, _processInstance.getProcessContext().getState());
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _processInstance.getRetour());
  }

  /**
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _processInstance = new PE0529_OperationVieReseau();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(REXProxy.class);
    PowerMock.mockStaticStrict(RESProxy.class);
    PowerMock.mockStaticStrict(AIRProxy.class);
    PowerMock.mockStaticStrict(RPGProxy.class);
    PowerMock.mockStaticStrict(STARKProxy.class);
    PowerMock.mockStaticStrict(BL4600_CreerErreurSpiritBuilder.class);
    PowerMock.mockStaticStrict(BL4600_CreerErreurSpirit.class);

    ProcessManager.getInstance().getProcessParams().clear();
    Map<String, String> map = new ConcurrentHashMap<>();
    File classpath = new File(PE0529_PutOperationVieReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    map.put(PARAM_FILE_PATH, classpath + CONFIG_FILE);
    ProcessManager.getInstance().getProcessParams().put(StringConstants.EMPTY_STRING, map);
  }

  /**
   * Method that does the needed clean up.<br/>
   *
   * <b>Entrées:</b> N/A for this test method. <br/>
   * <b>Attendu:</b> Clean up of some of our data.
   *
   */
  @After
  public void tearDown()
  {
    _processInstance = null;
  }

  /**
   * Add custom headers
   *
   * @param requestId_p
   *          {@link String}
   * @param process_p
   *          {@link String}
   * @param source_p
   *          {@link String}
   * @param messageId_p
   *          {@link String}
   * @param actionId_p
   *          {@link String}
   * @param authorization_p
   *          {@link String}
   * @return {@link List}
   */
  private List<RequestHeader> addXHeaders(String requestId_p, String process_p, String source_p, String messageId_p, String actionId_p, String authorization_p)
  {
    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader hdr = new RequestHeader();

    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    headers.add(hdr);

    if (requestId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
      hdr.setValue(requestId_p);
      headers.add(hdr);
    }

    if (source_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_SOURCE);
      hdr.setValue(source_p);
      headers.add(hdr);
    }

    if (process_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_PROCESS);
      hdr.setValue(process_p);
      headers.add(hdr);
    }

    if (messageId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
      hdr.setValue(messageId_p);
      headers.add(hdr);
    }

    if (actionId_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
      hdr.setValue(actionId_p);
      headers.add(hdr);
    }

    if (authorization_p != null)
    {
      hdr = new RequestHeader();
      hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
      hdr.setValue(authorization_p);
      headers.add(hdr);
    }

    return headers;
  }

  /**
   * @param retour_p
   *          {@link Retour}
   * @return {@link Pair}
   */
  private Pair<Retour, ReponseErreur> createBL002Retour(Retour retour_p)
  {
    ReponseErreur reponseErreur = null;

    if (RetourFactory.isRetourNOK(retour_p))
    {
      reponseErreur = new ReponseErreur();
      reponseErreur.setError(retour_p.getDiagnostic());
      reponseErreur.setErrorDescription(retour_p.getLibelle());
    }

    return new Pair<>(retour_p, reponseErreur);
  }

  /**
   * Creation d'un OLT Composite
   *
   * @return {@link OltComposite}
   */
  private OltComposite createDefaultOLTComposite()
  {
    OltComposite oltComposite = new OltComposite("OLT2000", null, "NOKIA", null, "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    CartePON carteA = new CartePON(1, null, "OPERATIONNEL"); //$NON-NLS-1$
    PortPON portPON1 = new PortPON(1, "OPERATIONNEL", new HashSet<>(Collections.singletonList("GPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    PortPON portPON2 = new PortPON(2, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    PortPON portPON3 = new PortPON(3, "OPERATIONNEL", new HashSet<>(Collections.singletonList("XGPON")), 0); //$NON-NLS-1$ //$NON-NLS-2$
    carteA.getListePortPON().put(1, portPON1);
    carteA.getListePortPON().put(2, portPON2);
    carteA.getListePortPON().put(3, portPON3);
    oltComposite.getListeCartePON().put(1, carteA);

    return oltComposite;
  }

  /**
   * Creation d'une operation vie reseau simple
   *
   * @param idOperationVieReseau_p
   *          identifiant de l'operation
   * @param typeOperationVieReseau_p
   *          type de l'operation
   * @param statut_p
   *          Statut de l'operation
   * @return {@link OperationVieReseau}
   * @throws RavelException
   *           on error.
   */
  private OperationVieReseau createDefaultOperationVieReseau(String idOperationVieReseau_p, String typeOperationVieReseau_p, String statut_p) throws RavelException
  {
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(1, "PANNEAU_B", "BOITIER_B", "GHYUI891"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);

    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_D"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_D", "ABCD123"); //$NON-NLS-1$ //$NON-NLS-2$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmMigreCible, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);

    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_E", "BOITIER_E", "GHYUI892"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));

    PositionPortPm posPortPmModif = new PositionPortPm(1, "PANNEAU_F", "BOITIER_F", "GHYUI893"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 2, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 2, 3); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));

    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("XGPON")); //$NON-NLS-1$

    PE0529_PostRequest creationRequest = new PE0529_PostRequest(typeOperationVieReseau_p, Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));

    String donneesBrutes = RavelJsonTools.getInstance().toJson(creationRequest, PE0529_PostRequest.class);
    return new OperationVieReseau(idOperationVieReseau_p, typeOperationVieReseau_p, statut_p, donneesBrutes);
  }

  /**
   * Creation d'une operation vie reseau
   *
   * @param idOperationVieReseau_p
   *          identifiant de l'operation
   * @param typeOperationVieReseau_p
   *          type de l'operation
   * @param statut_p
   *          Statut de l'operation
   * @return {@link OperationVieReseau}
   * @throws RavelException
   *           on error.
   */
  private OperationVieReseau createDefaultOperationVieReseauMigration(String idOperationVieReseau_p, String typeOperationVieReseau_p, String statut_p) throws RavelException
  {
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);

    PE0529_PostRequest creationRequest = new PE0529_PostRequest(typeOperationVieReseau_p, Collections.singletonList("PM")); //$NON-NLS-1$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));

    String donneesBrutes = RavelJsonTools.getInstance().toJson(creationRequest, PE0529_PostRequest.class);
    return new OperationVieReseau(idOperationVieReseau_p, typeOperationVieReseau_p, statut_p, donneesBrutes);
  }

  /**
   * Creation d'une operation vie reseau
   *
   * @param idOperationVieReseau_p
   *          identifiant de l'operation
   * @param typeOperationVieReseau_p
   *          type de l'operation
   * @param statut_p
   *          Statut de l'operation
   * @return {@link OperationVieReseau}
   * @throws RavelException
   *           on error.
   */
  private OperationVieReseau createDefaultOperationVieReseauSimple(String idOperationVieReseau_p, String typeOperationVieReseau_p, String statut_p) throws RavelException
  {
    PositionPortPm posPortPmMigreSrc = new PositionPortPm(1, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PositionPortPm posPortPmMigreCible = new PositionPortPm(2, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    MigrationPortPm migrationPortPm = new MigrationPortPm(posPortPmMigreSrc, posPortPmMigreCible);

    LienPortPon lienPortPonAjout = new LienPortPon("OLT2000", 1, 2); //$NON-NLS-1$
    PanneauPm panneauPm = new PanneauPm("PANNEAU_B"); //$NON-NLS-1$
    BoitierPm boitierPm = new BoitierPm("BOITIER_B", null); //$NON-NLS-1$
    PositionPortPm posPortPmAjout = new PositionPortPm(2, "PANNEAU_B", "BOITIER_B", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    AjoutPortPm ajoutPortPm = new AjoutPortPm(posPortPmAjout, Collections.singletonList(lienPortPonAjout), panneauPm, boitierPm);

    PositionPortPm posPortPmSupp = new PositionPortPm(1, "PANNEAU_B", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    SuppressionPortPm suppPortPm = new SuppressionPortPm(Collections.singletonList(posPortPmSupp));

    PositionPortPm posPortPmModif = new PositionPortPm(2, "PANNEAU_A", "BOITIER_A", "GHYUI890"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    LienPortPon lienPortPonModifSrc = new LienPortPon("OLT2000", 1, 1); //$NON-NLS-1$
    LienPortPon lienPortPonModifCible = new LienPortPon("OLT2000", 1, 2); //$NON-NLS-1$
    ModificationPortPm modifPortPm = new ModificationPortPm(posPortPmModif, Collections.singletonList(lienPortPonModifSrc), Collections.singletonList(lienPortPonModifCible));

    PositionPortPon posPortPonModif = new PositionPortPon(1, 1, "OLT2000"); //$NON-NLS-1$
    ModificationPortPon modifPortPon = new ModificationPortPon(posPortPonModif, Collections.singletonList("XGPON")); //$NON-NLS-1$

    CartePon cartePonAjout = new CartePon("2", null); //$NON-NLS-1$
    PositionPortPon posPortPonAjout = new PositionPortPon(1, 2, "OLT2000"); //$NON-NLS-1$
    AjoutPortPon ajoutPortPon = new AjoutPortPon(posPortPonAjout, Collections.singletonList("XGPON"), 0, cartePonAjout); //$NON-NLS-1$

    PositionPortPon posPortPonSupp = new PositionPortPon(3, 1, "OLT2000"); //$NON-NLS-1$
    SuppressionPortPon suppPortPon = new SuppressionPortPon(posPortPonSupp);

    PE0529_PostRequest creationRequest = new PE0529_PostRequest(typeOperationVieReseau_p, Arrays.asList("PM", "OLT")); //$NON-NLS-1$ //$NON-NLS-2$
    creationRequest.setNumeroGCR("GCR-12345678"); //$NON-NLS-1$
    creationRequest.setMigrationsPortsPm(Collections.singletonList(migrationPortPm));
    creationRequest.setAjoutsPortsPm(Collections.singletonList(ajoutPortPm));
    creationRequest.setSuppressionsPortsPm(Collections.singletonList(suppPortPm));
    creationRequest.setModificationsPortsPm(Collections.singletonList(modifPortPm));
    creationRequest.setAjoutsPortsPon(Collections.singletonList(ajoutPortPon));
    creationRequest.setModificationsPortsPon(Collections.singletonList(modifPortPon));
    creationRequest.setSuppressionsPortsPon(Collections.singletonList(suppPortPon));

    String donneesBrutes = RavelJsonTools.getInstance().toJson(creationRequest, PE0529_PostRequest.class);
    return new OperationVieReseau(idOperationVieReseau_p, typeOperationVieReseau_p, statut_p, donneesBrutes);
  }

  /**
   * Creation d'un PM Composite par défaut
   *
   * @return {@link PMComposite}
   */
  private PMComposite createDefaultPMComposite()
  {
    PortPonId portPonId = new PortPonId("OLT2000", 1, 1); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", portPonId); //$NON-NLS-1$
    String cle = "OLT2000_1_1"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens = new HashMap<>();
    mapLiens.put(cle, lienPortPMPon);

    PortPonId portPonId2 = new PortPonId("OLT2000", 2, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon2 = new LienPortPMPon("OPERATIONNEL", portPonId2); //$NON-NLS-1$
    String cle2 = "OLT2000_2_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens2 = new HashMap<>();
    mapLiens2.put(cle2, lienPortPMPon2);

    Map<Integer, PortPM> mapPortPanneauAA = new HashMap<>();
    mapPortPanneauAA.put(1, new PortPM(1, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    mapPortPanneauAA.put(2, new PortPM(2, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    Map<Integer, PortPM> mapPortPanneauBA = new HashMap<>();
    mapPortPanneauBA.put(1, new PortPM(1, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    mapPortPanneauBA.put(2, new PortPM(2, "OPERATIONNEL", mapLiens2)); //$NON-NLS-1$

    PanneauPM panneauA_A = new PanneauPM("PANNEAU_A", "OPERATIONNEL", mapPortPanneauAA); //$NON-NLS-1$ //$NON-NLS-2$
    PanneauPM panneauA_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBA); //$NON-NLS-1$ //$NON-NLS-2$

    Map<String, PanneauPM> mapPanneauBoitierA = new HashMap<>();
    mapPanneauBoitierA.put("PANNEAU_A", panneauA_A); //$NON-NLS-1$
    mapPanneauBoitierA.put("PANNEAU_B", panneauA_B); //$NON-NLS-1$

    BoitierPM boitierA = new BoitierPM("BOITIER_A", "OPERATIONNEL", mapPanneauBoitierA); //$NON-NLS-1$ //$NON-NLS-2$

    PMComposite pmComposite = new PMComposite("GHYUI890", null, "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$
    pmComposite.getListeBoitierPM().put("BOITIER_A", boitierA); //$NON-NLS-1$

    return pmComposite;
  }

  /**
   * Creation d'un PM Composite par défaut
   *
   * @return {@link PMComposite}
   */
  private PMComposite createUpdatedPMComposite()
  {
    PortPonId portPonId = new PortPonId("OLT2000", 1, 1); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", portPonId); //$NON-NLS-1$
    String cle = "OLT2000_1_1"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens = new HashMap<>();
    mapLiens.put(cle, lienPortPMPon);

    PortPonId portPonId2 = new PortPonId("OLT2000", 2, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon2 = new LienPortPMPon("OPERATIONNEL", portPonId2); //$NON-NLS-1$
    String cle2 = "OLT2000_2_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens2 = new HashMap<>();
    mapLiens2.put(cle2, lienPortPMPon2);

    Map<Integer, PortPM> mapPortPanneauAA = new HashMap<>();
    mapPortPanneauAA.put(1, new PortPM(1, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    mapPortPanneauAA.put(2, new PortPM(2, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    Map<Integer, PortPM> mapPortPanneauBA = new HashMap<>();
    mapPortPanneauBA.put(1, new PortPM(1, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    mapPortPanneauBA.put(2, new PortPM(2, "OPERATIONNEL", mapLiens2)); //$NON-NLS-1$

    PanneauPM panneauA_A = new PanneauPM("PANNEAU_A", "OPERATIONNEL", mapPortPanneauAA); //$NON-NLS-1$ //$NON-NLS-2$
    PanneauPM panneauA_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBA); //$NON-NLS-1$ //$NON-NLS-2$

    Map<String, PanneauPM> mapPanneauBoitierA = new HashMap<>();
    mapPanneauBoitierA.put("PANNEAU_A", panneauA_A); //$NON-NLS-1$
    mapPanneauBoitierA.put("PANNEAU_B", panneauA_B); //$NON-NLS-1$

    BoitierPM boitierA = new BoitierPM("BOITIER_A", "OPERATIONNEL", mapPanneauBoitierA); //$NON-NLS-1$ //$NON-NLS-2$

    PMComposite pmComposite = new PMComposite("GHYUI890", null, "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$
    pmComposite.getListeBoitierPM().put("BOITIER_A", boitierA); //$NON-NLS-1$

    //  - Add
    PortPonId portPonIdAdd = new PortPonId("OLT2000", 1, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPonAdd = new LienPortPMPon("OPERATIONNEL", portPonIdAdd); //$NON-NLS-1$
    String cleAdd = "OLT2000_1_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiensAdd = new HashMap<>();
    mapLiensAdd.put(cleAdd, lienPortPMPonAdd);
    Map<Integer, PortPM> mapPortPanneauBB = new HashMap<>();
    mapPortPanneauBB.put(2, new PortPM(2, "OPERATIONNEL", mapLiensAdd)); //$NON-NLS-1$
    PanneauPM panneauB_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBB); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> mapPanneauBoitierB = new HashMap<>();
    mapPanneauBoitierB.put("PANNEAU_B", panneauB_B); //$NON-NLS-1$
    BoitierPM boitierB = new BoitierPM("BOITIER_B", "OPERATIONNEL", mapPanneauBoitierB); //$NON-NLS-1$ //$NON-NLS-2$
    pmComposite.getListeBoitierPM().put("BOITIER_B", boitierB); //$NON-NLS-1$
    //  - Modif
    pmComposite.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().remove("OLT2000_1_1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    pmComposite.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().put(cleAdd, lienPortPMPonAdd); //$NON-NLS-1$ //$NON-NLS-2$
    //  - Migr
    PortPM portPM = pmComposite.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(1); //$NON-NLS-1$ //$NON-NLS-2$
    PortPM newPortPm = new PortPM(2, "OPERATIONNEL", portPM.getListeLienPortPMPon()); //$NON-NLS-1$
    newPortPm.setIdRessourceRaccordement(portPM.getIdRessourceRaccordement());
    newPortPm.setSurchargePortPM(portPM.getSurchargePortPM());
    newPortPm.setNomCoupleur(portPM.getNomCoupleur());
    newPortPm.setDateCreation(portPM.getDateCreation());
    newPortPm.setDateModification(portPM.getDateModification());
    pmComposite.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_B").getListePortPM().put(2, newPortPm); //$NON-NLS-1$ //$NON-NLS-2$

    return pmComposite;
  }

  /**
   * Creation d'un PM Composite par défaut
   *
   * @return {@link PMComposite}
   */
  private PMComposite createUpdatedPMCompositeWithDelete()
  {
    PortPonId portPonId = new PortPonId("OLT2000", 1, 1); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon = new LienPortPMPon("OPERATIONNEL", portPonId); //$NON-NLS-1$
    String cle = "OLT2000_1_1"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens = new HashMap<>();
    mapLiens.put(cle, lienPortPMPon);

    PortPonId portPonId2 = new PortPonId("OLT2000", 2, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPon2 = new LienPortPMPon("OPERATIONNEL", portPonId2); //$NON-NLS-1$
    String cle2 = "OLT2000_2_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiens2 = new HashMap<>();
    mapLiens2.put(cle2, lienPortPMPon2);

    Map<Integer, PortPM> mapPortPanneauAA = new HashMap<>();
    mapPortPanneauAA.put(1, new PortPM(1, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    mapPortPanneauAA.put(2, new PortPM(2, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    Map<Integer, PortPM> mapPortPanneauBA = new HashMap<>();
    mapPortPanneauBA.put(1, new PortPM(1, "OPERATIONNEL", mapLiens)); //$NON-NLS-1$
    mapPortPanneauBA.put(2, new PortPM(2, "OPERATIONNEL", mapLiens2)); //$NON-NLS-1$

    PanneauPM panneauA_A = new PanneauPM("PANNEAU_A", "OPERATIONNEL", mapPortPanneauAA); //$NON-NLS-1$ //$NON-NLS-2$
    PanneauPM panneauA_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBA); //$NON-NLS-1$ //$NON-NLS-2$

    Map<String, PanneauPM> mapPanneauBoitierA = new HashMap<>();
    mapPanneauBoitierA.put("PANNEAU_A", panneauA_A); //$NON-NLS-1$
    mapPanneauBoitierA.put("PANNEAU_B", panneauA_B); //$NON-NLS-1$

    BoitierPM boitierA = new BoitierPM("BOITIER_A", "OPERATIONNEL", mapPanneauBoitierA); //$NON-NLS-1$ //$NON-NLS-2$

    PMComposite pmComposite = new PMComposite("GHYUI890", null, "OPERATIONNEL"); //$NON-NLS-1$ //$NON-NLS-2$
    pmComposite.getListeBoitierPM().put("BOITIER_A", boitierA); //$NON-NLS-1$

    //  - Add
    PortPonId portPonIdAdd = new PortPonId("OLT2000", 1, 2); //$NON-NLS-1$
    LienPortPMPon lienPortPMPonAdd = new LienPortPMPon("OPERATIONNEL", portPonIdAdd); //$NON-NLS-1$
    String cleAdd = "OLT2000_1_2"; //$NON-NLS-1$
    Map<String, LienPortPMPon> mapLiensAdd = new HashMap<>();
    mapLiensAdd.put(cleAdd, lienPortPMPonAdd);
    Map<Integer, PortPM> mapPortPanneauBB = new HashMap<>();
    mapPortPanneauBB.put(2, new PortPM(2, "OPERATIONNEL", mapLiensAdd)); //$NON-NLS-1$
    PanneauPM panneauB_B = new PanneauPM("PANNEAU_B", "OPERATIONNEL", mapPortPanneauBB); //$NON-NLS-1$ //$NON-NLS-2$
    Map<String, PanneauPM> mapPanneauBoitierB = new HashMap<>();
    mapPanneauBoitierB.put("PANNEAU_B", panneauB_B); //$NON-NLS-1$
    BoitierPM boitierB = new BoitierPM("BOITIER_B", "OPERATIONNEL", mapPanneauBoitierB); //$NON-NLS-1$ //$NON-NLS-2$
    pmComposite.getListeBoitierPM().put("BOITIER_B", boitierB); //$NON-NLS-1$
    //  - Modif
    pmComposite.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().remove("OLT2000_1_1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    pmComposite.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(2).getListeLienPortPMPon().put(cleAdd, lienPortPMPonAdd); //$NON-NLS-1$ //$NON-NLS-2$
    //  - Migr
    PortPM portPM = pmComposite.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_A").getListePortPM().get(1); //$NON-NLS-1$ //$NON-NLS-2$
    PortPM newPortPm = new PortPM(2, "OPERATIONNEL", portPM.getListeLienPortPMPon()); //$NON-NLS-1$
    newPortPm.setIdRessourceRaccordement(portPM.getIdRessourceRaccordement());
    newPortPm.setSurchargePortPM(portPM.getSurchargePortPM());
    newPortPm.setNomCoupleur(portPM.getNomCoupleur());
    newPortPm.setDateCreation(portPM.getDateCreation());
    newPortPm.setDateModification(portPM.getDateModification());
    pmComposite.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_B").getListePortPM().put(2, newPortPm); //$NON-NLS-1$ //$NON-NLS-2$

    //  - Supp
    pmComposite.getListeBoitierPM().get("BOITIER_A").getListePanneauPM().get("PANNEAU_B").getListePortPM().get(1).setStatutTechnique("SUPPRIME"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    return pmComposite;
  }

  /**
   * Mock pour AIR.indexRechercherPfiLireTousParCleRecherche
   *
   * @param retour_p
   *          Retour attendu
   * @param listeIndex_p
   *          Liste index pfi attendu
   * @param type_p
   *          Type en paramètre
   * @param valeur_p
   *          Valeur en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockAIR_IndexRechercherPfiLireTousParCleRecherche(Retour retour_p, List<IndexRecherchePfi> listeIndex_p, String type_p, String valeur_p) throws Exception
  {
    ConnectorResponse<Retour, List<IndexRecherchePfi>> connectorResponse = new ConnectorResponse<>(retour_p, listeIndex_p);
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxyMock).times(1);
    EasyMock.expect(_airProxyMock.indexRechercherPfiLireTousParCleRecherche( //
        EasyMock.anyObject(Tracabilite.class), //
        EasyMock.eq(type_p), //
        EasyMock.eq(valeur_p) //
    )).andReturn(connectorResponse);
  }

  /**
   * Mock pour BL4600
   *
   * @param retourIn_p
   *          {@link Retour}
   * @param retourOut_p
   *          {@link Retour}
   * @throws Exception
   *           if error
   */
  private void mockBL4600(Retour retourIn_p, Retour retourOut_p) throws Exception
  {
    PowerMock.expectNew(BL4600_CreerErreurSpiritBuilder.class).andReturn(_bl4600BuilderMock);
    EasyMock.expect(_bl4600BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4600BuilderMock);
    if (retourIn_p == null)
    {
      EasyMock.expect(_bl4600BuilderMock.retour(EasyMock.anyObject(Retour.class))).andReturn(_bl4600BuilderMock);
    }
    else
    {
      EasyMock.expect(_bl4600BuilderMock.retour(EasyMock.eq(retourIn_p))).andReturn(_bl4600BuilderMock);
    }
    EasyMock.expect(_bl4600BuilderMock.build()).andReturn(_bl4600Mock);
    EasyMock.expect(_bl4600Mock.execute(_processInstance)).andReturn(null).once();
    EasyMock.expect(_bl4600Mock.getRetour()).andReturn(retourOut_p).once();
  }

  /**
   * Mock pour BL850
   *
   * @param retour_p
   *          {@link Retour}
   * @param type_p
   *          Type en parametre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockBL850(Retour retour_p, String type_p) throws Exception
  {
    PowerMock.expectNew(BL850_ObtenirTicketBuilder.class).andReturn(_bl850BuilderMock).once();
    EasyMock.expect(_bl850BuilderMock.tracabilite(_tracabilite)).andReturn(_bl850BuilderMock).once();
    EasyMock.expect(_bl850BuilderMock.type(type_p)).andReturn(_bl850BuilderMock).once();
    EasyMock.expect(_bl850BuilderMock.build()).andReturn(_bl850Mock).once();
    EasyMock.expect(_bl850Mock.execute(_processInstance)).andReturn(null).once();
    EasyMock.expect(_bl850Mock.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * Mock pour BL851
   *
   * @param retour_p
   *          {@link Retour}
   * @param type_p
   *          Type en parametre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockBL851(Retour retour_p, String type_p) throws Exception
  {
    PowerMock.expectNew(BL851_LibererTicketBuilder.class).andReturn(_bl851BuilderMock).once();
    EasyMock.expect(_bl851BuilderMock.tracabilite(_tracabilite)).andReturn(_bl851BuilderMock).once();
    EasyMock.expect(_bl851BuilderMock.type(type_p)).andReturn(_bl851BuilderMock).once();
    EasyMock.expect(_bl851BuilderMock.build()).andReturn(_bl851Mock).once();
    EasyMock.expect(_bl851Mock.execute(_processInstance)).andReturn(null).once();
    EasyMock.expect(_bl851Mock.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * Mock pour RES.oltCompositeGererImport
   *
   * @param retour_p
   *          Retour attendu
   * @param oltComposite_p
   *          OLTComposite en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRES_OltCompositeGererImport(Retour retour_p, OltComposite oltComposite_p) throws Exception
  {
    ConnectorResponse<Retour, Nothing> connectorResponse = new ConnectorResponse<>(retour_p, null);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.oltCompositeGererImport(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(oltComposite_p))).andReturn(connectorResponse);
  }

  /**
   * Mock pour RES.oltCompositeLireUn
   *
   * @param retour_p
   *          Retour attendu
   * @param oltComposite_p
   *          OltComposite attendue
   * @param nomOlt_p
   *          Nom de l'olt en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRES_OltCompositeLireUn(Retour retour_p, OltComposite oltComposite_p, String nomOlt_p) throws Exception
  {
    ConnectorResponse<Retour, OltComposite> connectorResponse = new ConnectorResponse<>(retour_p, oltComposite_p);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).once();
    EasyMock.expect(_resProxyMock.oltCompositeLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(nomOlt_p))).andReturn(connectorResponse).once();
  }

  /**
   * Mock pour RES.oltCompositemodifierSurchargeDateDebutQuarantaineOLT
   *
   * @param retour_p
   *          Retour attendu
   * @param listTechnoAutorisee_p
   *          Liste des technologies autorisées en paramètre
   * @param nomOlt_p
   *          Nom de l'olt en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRES_OltCompositemodifierSurchargeDateDebutQuarantaineOLT(Retour retour_p, ListeTechnologieAutorisee listTechnoAutorisee_p, String nomOlt_p) throws Exception
  {
    ConnectorResponse<Retour, Nothing> connectorResponse = new ConnectorResponse<>(retour_p, null);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.oltCompositemodifierSurchargeDateDebutQuarantaineOLT( //
        EasyMock.anyObject(Tracabilite.class), //
        EasyMock.eq(listTechnoAutorisee_p), //
        EasyMock.eq(nomOlt_p) //
    )).andReturn(connectorResponse);
  }

  /**
   * Mock pour RES.pmCompositeGererImport
   *
   * @param retour_p
   *          Retour attendu
   * @param pmComposite_p
   *          PMComposite en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRES_PmCompositeGererImport(Retour retour_p, PMComposite pmComposite_p) throws Exception
  {
    ConnectorResponse<Retour, Nothing> connectorResponse = new ConnectorResponse<>(retour_p, null);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.pmCompositeGererImport(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(pmComposite_p), EasyMock.eq("VIE_DE_RESEAU"))).andReturn(connectorResponse); //$NON-NLS-1$
  }

  /**
   * Mock pour RES.pmCompositeLireUnParReferencePmBytel
   *
   * @param retour_p
   *          Retour attendu
   * @param pmComposite_p
   *          PMComposite attendue
   * @param referenceBytel_p
   *          Reference Bytel en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRES_PmCompositeLireUnParReferencePmBytel(Retour retour_p, PMComposite pmComposite_p, String referenceBytel_p) throws Exception
  {
    ConnectorResponse<Retour, PMComposite> connectorResponse = new ConnectorResponse<>(retour_p, pmComposite_p);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.pmCompositeLireUnParReferencePmBytel(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(referenceBytel_p))).andReturn(connectorResponse);
  }

  /**
   * Mock pour RES.pmCompositeModifierSurchargeDateDebutQuarantainePM
   *
   * @param retour_p
   *          Retour attendu
   * @param referenceBytel_p
   *          Reference Bytel en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRES_PmCompositeModifierSurchargeDateDebutQuarantainePM(Retour retour_p, String referenceBytel_p) throws Exception
  {
    ConnectorResponse<Retour, Nothing> connectorResponse = new ConnectorResponse<>(retour_p, null);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.pmCompositeModifierSurchargeDateDebutQuarantainePM( //
        EasyMock.anyObject(Tracabilite.class), //
        EasyMock.eq(referenceBytel_p)//
    )).andReturn(connectorResponse);
  }

  /**
   * Mock pour RES.ressourceLireUn
   *
   * @param retour_p
   *          Retour attendu
   * @param ressource_p
   *          Ressource attendue
   * @param idRessource_p
   *          IdRessource en paramètre
   * @param typeRessource_p
   *          type de ressource en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRES_RessourceLireUn(Retour retour_p, Ressource ressource_p, String idRessource_p, String typeRessource_p) throws Exception
  {
    ConnectorResponse<Retour, Ressource> connectorResponse = new ConnectorResponse<>(retour_p, ressource_p);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idRessource_p), EasyMock.eq(typeRessource_p))).andReturn(connectorResponse);
  }

  /**
   * Mock pour RES.ressourcePortPmGererMigrationPortPm
   *
   * @param retour_p
   *          Retour attendu
   * @param ressource_p
   *          Objet ressourcePM
   * @param idRessource_p
   *          Identifiant de la ressource du portPM
   * @param motifMigration_p
   *          Motif de migration (ex : PHYSIQUE)
   * @param referencePmBytel_p
   *          Reference PM Bytel
   * @param referencePmOi_p
   *          Reference PM OI
   * @param referenceBoitierPm_p
   *          Reference du boitier PM associé au port
   * @param nomPmTechnique_p
   *          Nom pm technique
   * @param nomPanneauPm_p
   *          Nom du panneau associé au port
   * @param positionPortPm_p
   *          Position du port PM
   * @param technologiePON_p
   *          Technologies des ports PON
   * @param idRessourceLie_p
   *          Identifiant de ressource lie
   * @throws Exception
   *           en cas d'erreur
   */
  private void mockRES_RessourcePortPmGererMigrationPortPm(Retour retour_p, RessourcePortPM ressource_p, String idRessource_p, String motifMigration_p, String referencePmBytel_p, String referencePmOi_p, String referenceBoitierPm_p, String nomPmTechnique_p, String nomPanneauPm_p, Integer positionPortPm_p, String technologiePON_p, String idRessourceLie_p) throws Exception
  {
    ConnectorResponse<Retour, RessourcePortPM> connectorResponse = new ConnectorResponse<>(retour_p, ressource_p);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock).times(1);
    EasyMock.expect(_resProxyMock.ressourcePortPmGererMigrationPortPm( //
        EasyMock.anyObject(Tracabilite.class), //
        EasyMock.eq(idRessource_p), //
        EasyMock.eq(motifMigration_p), //
        EasyMock.eq(referencePmBytel_p), //
        EasyMock.eq(referencePmOi_p), //
        EasyMock.eq(referenceBoitierPm_p), //
        EasyMock.eq(nomPmTechnique_p), //
        EasyMock.eq(nomPanneauPm_p), //
        EasyMock.eq(positionPortPm_p), //
        EasyMock.eq(technologiePON_p), //
        EasyMock.eq(idRessourceLie_p) //
    )).andReturn(connectorResponse);
  }

  /**
   * Mock pour REX.operationVieReseauCompositeLireTousParCleRecherche
   *
   * @param retour_p
   *          Retour attendu
   * @param liste_p
   *          Liste d'operation attendue
   * @param typeOperationVieReseau_p
   *          type d'opération en paramètre
   * @param typeCle_p
   *          type de clé en paramètre
   * @param valeurCle_p
   *          valeur de la clé en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockREX_OperationVieReseauCompositeLireTousParCleRecherche(Retour retour_p, List<OperationVieReseau> liste_p, String typeOperationVieReseau_p, String typeCle_p, String valeurCle_p) throws Exception
  {
    ConnectorResponse<Retour, List<OperationVieReseau>> connectorResponse = new ConnectorResponse<>(retour_p, liste_p);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(1);
    EasyMock.expect(_rexProxyMock.operationVieReseauCompositeLireTousParCleRecherche( //
        EasyMock.anyObject(Tracabilite.class), //
        EasyMock.eq(typeOperationVieReseau_p), //
        EasyMock.eq(typeCle_p), //
        EasyMock.eq(valeurCle_p) //
    )).andReturn(connectorResponse);
  }

  /**
   * Mock pour REX.operationVieReseauLireUn
   *
   * @param retour_p
   *          Retour attendu
   * @param operation_p
   *          Operation attendue
   * @param idOperation_p
   *          ID de l'operation en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockREX_OperationVieReseauLireUn(Retour retour_p, OperationVieReseau operation_p, String idOperation_p) throws Exception
  {
    ConnectorResponse<Retour, OperationVieReseau> connectorResponse = new ConnectorResponse<>(retour_p, operation_p);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(1);
    EasyMock.expect(_rexProxyMock.operationVieReseauLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idOperation_p))).andReturn(connectorResponse);
  }

  /**
   * Mock pour REX.operationVieReseauModifierListeClientImpacte
   *
   * @param retour_p
   *          Retour attendu
   * @param idOperation_p
   *          ID de l'operation en paramètre
   * @param listeClientImpact_p
   *          Liste des clients impactes en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockREX_OperationVieReseauModifierListeClientImpacte(Retour retour_p, String idOperation_p, Set<ClientImpacte> listeClientImpact_p) throws Exception
  {
    ConnectorResponse<Retour, Nothing> connectorResponse = new ConnectorResponse<>(retour_p, null);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(1);
    EasyMock.expect(_rexProxyMock.operationVieReseauModifierListeClientImpacte( //
        EasyMock.anyObject(Tracabilite.class), //
        EasyMock.eq(idOperation_p), //
        EasyMock.eq(listeClientImpact_p) //
    )).andReturn(connectorResponse);
  }

  /**
   * Mock pour REX.operationVieReseauModifierStatut
   *
   * @param retour_p
   *          Retour attendu
   * @param idOperation_p
   *          ID de l'operation en paramètre
   * @param statut_p
   *          Statut en paramètre
   * @param codeErreur_p
   *          code erreur en paramètre
   * @param libelleErreur_p
   *          libelle erreur en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockREX_OperationVieReseauModifierStatut(Retour retour_p, String idOperation_p, String statut_p, String codeErreur_p, String libelleErreur_p) throws Exception
  {
    ConnectorResponse<Retour, Nothing> connectorResponse = new ConnectorResponse<>(retour_p, null);
    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxyMock).times(1);
    EasyMock.expect(_rexProxyMock.operationVieReseauModifierStatut( //
        EasyMock.anyObject(Tracabilite.class), //
        EasyMock.eq(idOperation_p), //
        EasyMock.eq(statut_p), //
        EasyMock.eq(codeErreur_p), //
        EasyMock.eq(libelleErreur_p) //
    )).andReturn(connectorResponse);
  }

  /**
   * Mock pour RPG.pfiLireUn
   *
   * @param retour_p
   *          Retour attendu
   * @param pfi_p
   *          pfi attendu
   * @param clientOperateur_p
   *          Client operateur en paramètre
   * @param noCompte_p
   *          No Compte en paramètre
   * @throws Exception
   *           en cas d'exception
   */
  private void mockRPG_PfiLireUn(Retour retour_p, PFI pfi_p, String clientOperateur_p, String noCompte_p) throws Exception
  {
    ConnectorResponse<Retour, PFI> connectorResponse = new ConnectorResponse<>(retour_p, pfi_p);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock).times(1);
    EasyMock.expect(_rpgProxyMock.pfiLireUn( //
        EasyMock.anyObject(Tracabilite.class), //
        EasyMock.eq(clientOperateur_p), //
        EasyMock.eq(noCompte_p) //
    )).andReturn(connectorResponse);
  }

  /**
   * Prepare the config file
   *
   * @param fileName_p
   *          config file name
   */
  private void prepareConfig(String fileName_p)
  {
    File classpath = new File(PE0529_PutOperationVieReseauTest.class.getResource("/").getFile()); //$NON-NLS-1$
    ProcessManager.getInstance().getProcessParams().get(StringConstants.EMPTY_STRING).replace(PARAM_FILE_PATH, classpath + fileName_p); //$NON-NLS-1$
  }

  /**
   * prepare PUT Request
   *
   * @param modficationRequest_p
   *          {@link PE0529_PutRequest}
   * @param headers_p
   *          {@link List}
   * @param idOperation_p
   *          IdOperationVieReseau à mettre en urlDynamicParam
   * @return {@link Request}
   * @throws RavelException
   *           on error.
   */
  private Request preparePutRequest(PE0529_PutRequest modficationRequest_p, List<RequestHeader> headers_p, String idOperation_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.PUT);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    String payload = RavelJsonTools.getInstance().toJson(modficationRequest_p, PE0529_PutRequest.class);
    request.setPayload(payload);
    request.setRequestHeader(headers_p);
    request.setUrlDynamicParameters(idOperation_p);

    return request;
  }
}
