/*******************************************************************************
* $Id: ConfigurationPE0396.java 31784 2020-02-26 15:33:06Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0396.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections4.collection.UnmodifiableCollection;

/**
 *
 * @author jiantila
 * @version ($Revision: 31784 $ $Date: 2020-02-26 16:33:06 +0100 (mer. 26 févr. 2020) $)
 */
public class ConfigurationPE0396 implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -5338448677826935855L;

  /**
   * mes Alarme Direct
   */
  private boolean _mesAlarmeDirecte;

  /**
   * slid filtre liste
   */
  private List<String> _slidFiltreListe;

  /**
   * slid filtre flag
   */
  private String _slidFiltreFlag;

  /**
   * slid prefix huawei
   */
  private String _slidPrefixHuawei;

  /**
   * slid prefix Nokia
   */
  private String _slidPrefixNokia;

  /**
   * @return the slidFiltreFlag
   */
  public String getSlidFiltreFlag()
  {
    return _slidFiltreFlag;
  }

  /**
   * @return the slidFiltreListe
   */
  public List<String> getSlidFiltreListe()
  {
    return _slidFiltreListe == null ? null : Collections.unmodifiableList(_slidFiltreListe);

  }

  /**
   * @return the slidPrefixHuawei
   */
  public String getSlidPrefixHuawei()
  {
    return _slidPrefixHuawei;
  }

  /**
   * @return the slidPrefixNokia
   */
  public String getSlidPrefixNokia()
  {
    return _slidPrefixNokia;
  }

  /**
   * @return the mesAlarmeDirecte
   */
  public boolean isMesAlarmeDirecte()
  {
    return _mesAlarmeDirecte;
  }

  /**
   * @param mesAlarmeDirecte_p
   *          the mesAlarmeDirecte to set
   */
  public void setMesAlarmeDirecte(boolean mesAlarmeDirecte_p)
  {
    _mesAlarmeDirecte = mesAlarmeDirecte_p;
  }

  /**
   * @param slidFiltreFlag_p
   *          the slidFiltreFlag to set
   */
  public void setSlidFiltreFlag(String slidFiltreFlag_p)
  {
    _slidFiltreFlag = slidFiltreFlag_p;
  }

  /**
   * @param slidFiltreListe_p
   *          the slidFiltreListe to set
   */
  public void setSlidFiltreListe(List<String> slidFiltreListe_p)
  {
    _slidFiltreListe = slidFiltreListe_p == null ? null : new ArrayList<>(UnmodifiableCollection.unmodifiableCollection(slidFiltreListe_p));

  }

  /**
   * @param slidPrefixHuawei_p
   *          the slidPrefixHuawei to set
   */
  public void setSlidPrefixHuawei(String slidPrefixHuawei_p)
  {
    _slidPrefixHuawei = slidPrefixHuawei_p;
  }

  /**
   * @param slidPrefixNokia_p
   *          the slidPrefixNokia to set
   */
  public void setSlidPrefixNokia(String slidPrefixNokia_p)
  {
    _slidPrefixNokia = slidPrefixNokia_p;
  }

}
