/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0529;

import static com.bytel.ravel.common.utils.RetourFactory.isRetourNOK;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.isBlank;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringJoiner;
import java.util.UUID;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.connectors.stark.STARKProxy;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.BoitierPM;
import com.bytel.spirit.common.shared.saab.res.CartePON;
import com.bytel.spirit.common.shared.saab.res.LienPortPMPon;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.PanneauPM;
import com.bytel.spirit.common.shared.saab.res.PortPM;
import com.bytel.spirit.common.shared.saab.res.PortPON;
import com.bytel.spirit.common.shared.saab.res.PortPonId;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;
import com.bytel.spirit.common.shared.saab.res.Statut;
import com.bytel.spirit.common.shared.saab.res.StatutTechniqueOlt;
import com.bytel.spirit.common.shared.saab.res.StatutTechniquePM;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.common.shared.saab.res.TypeTechnologiePON;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacte;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacteStatutProvisionning;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseauStatut;
import com.bytel.spirit.common.shared.types.json.Suivi;
import com.bytel.spirit.tesla.processes.Messages;
import com.bytel.spirit.tesla.processes.PE0529.config.ConfigurationPE0529;
import com.bytel.spirit.tesla.processes.PE0529.structs.ProvisioningVDR;
import com.bytel.spirit.tesla.processes.PE0529.structs.ProvisioningVDRMigration;
import com.bytel.spirit.tesla.processes.PE0529.structs.ProvisioningVDRModification;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.LienPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.MigrationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.ModificationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.ModificationPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.SuppressionPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PostRequest;
import com.bytel.spirit.tesla.shared.types.PE0529.response.PE0529_GetResponse;
import com.bytel.spirit.tesla.shared.types.PE0529.response.PE0529_PostResponse;

/**
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public abstract class AbstractOperationVieReseau extends SpiritRestApiProcessSkeleton
{

  /**
   * Messages d'erreur du processus.
   *
   * @author JCHEVRON
   * @version ($Revision$ $Date$)
   */
  public interface IMessage
  {
    String INVALID_REQUEST_BODY_FORMAT = Messages.getString("Validation.InvalidRequestBodyFormat"); //$NON-NLS-1$
    String INVALID_QUERY_PARAMETER = Messages.getString("Validation.InvalidQueryParameter"); //$NON-NLS-1$
    String INVALID_HEADER = Messages.getString("Validation.InvalidHeader"); //$NON-NLS-1$
    String PORTPM_ALLOUE = Messages.getString("PE0529.PortPMAlloue"); //$NON-NLS-1$
    String PORTPM_SOURCE_INEXISTANT = Messages.getString("PE0529.PortPMSourceInexistant"); //$NON-NLS-1$
    String PORTPM_CIBLE_INEXISTANT = Messages.getString("PE0529.PortPMCibleInexistant"); //$NON-NLS-1$
    String LIEN_PORT_PON_INEXISTANT = Messages.getString("PE0529.LienPortPonInexistant"); //$NON-NLS-1$
    String PORT_PON_INEXISTANT = Messages.getString("PE0529.PortPonInexistant"); //$NON-NLS-1$
    String STPFTECHNOCOMPATIBLE_NON_MODIFIABLE = Messages.getString("PE0529.SfpTechnologieCompatibleNonModifiable"); //$NON-NLS-1$
    String OPERATION_VIE_RESEAU_INCONNUE = Messages.getString("PE0529.OperationVieReseauInconnue"); //$NON-NLS-1$
    String OPERATION_VIE_RESEAU_NON_ACQUITTE = Messages.getString("PE0529.OperationVieReseauNonAcquitte"); //$NON-NLS-1$
    String EXECUTION_IMPOSSIBLE_SUR = Messages.getString("PE0529.ExecutionImpossibleSur"); //$NON-NLS-1$
    String OPERATION_ANNULEE_MAJ_REFERENTIEL = Messages.getString("PE0529.OperationAnnuleeMAJReferentiel"); //$NON-NLS-1$
    String OPERATION_ANNULEE_PROV_CLIENT = Messages.getString("PE0529.OperationAnnuleeProvClient"); //$NON-NLS-1$
    String OPERATION_ANNULEE_TRAITEMENT_TOPO = Messages.getString("PE0529.OperationAnnuleeTraitementTopologie"); //$NON-NLS-1$
    String OPERATION_ANNULEE_TRAITEMENT = Messages.getString("PE0529.OperationAnnuleeTraitement"); //$NON-NLS-1$
    String OPERATION_ETAT_FINAL = Messages.getString("PE0529.OperationEtatFinal"); //$NON-NLS-1$
    String OPERATION_MAUVAIS_ETAT = Messages.getString("PE0529.OperationMauvaisEtat"); //$NON-NLS-1$
    String PROVISIONNING_NOK = Messages.getString("PE0529.ProvisionningNOK"); //$NON-NLS-1$
    String PFI_NON_TROUVE = Messages.getString("PE0529.AucunPfiTrouve"); //$NON-NLS-1$
    String ERREUR_ID_ACTION_CORRECTIVE = Messages.getString("PE0529.ErreurIdActionCorrective"); //$NON-NLS-1$
    String PORTPM_MODIFICATION_INEXISTANT = Messages.getString("PE0529.PortPmModificationInexistant"); //$NON-NLS-1$
    String MODIFICATION_TECHNO_IMPOSSIBLE = Messages.getString("PE0529.ModificationTechnoImpossible"); //$NON-NLS-1$
    String SUPPRESSION_PORT_PON_IMPOSSIBLE_ONTID = Messages.getString("PE0529.SuppressionPortPonImpossibleOntidAlloue"); //$NON-NLS-1$
    String ERREUR_STATUT = Messages.getString("PE0529.ErreurStatutOperation"); //$NON-NLS-1$
    String ERREUR_DONNEE_BRUTE = Messages.getString("PE0529.ErreurDonneeBrute"); //$NON-NLS-1$
    String ERREUR_LECTURE = Messages.getString("PE0529.ErreurLecture"); //$NON-NLS-1$
    String ERREUR_IMPORT = Messages.getString("PE0529.ErreurImport"); //$NON-NLS-1$
    String ERREUR_MODIFIER_QUARANTAINE = Messages.getString("PE0529.ErreurModifierQuarantaine"); //$NON-NLS-1$
    String ERREUR_MODIFIER_LISTE = Messages.getString("PE0529.ErreurModifierListe"); //$NON-NLS-1$
    String ERREUR_MODIFIER_STATUT = Messages.getString("PE0529.ErreurModifierStatut"); //$NON-NLS-1$
    String OPERATION_ANNULEE = Messages.getString("PE0529.OperationAnnulee"); //$NON-NLS-1$
    String NOCLIENT_NON_TROUVE = Messages.getString("PE0529.NoClientNonTrouve"); //$NON-NLS-1$
    String NO_PARAM = Messages.getString("PE0529.NoParam"); //$NON-NLS-1$
    String FILE_ERROR = Messages.getString("PE0529.FileError"); //$NON-NLS-1$
    String NOCOMPTE_INCONNU = Messages.getString("PE0529.NoCompteInconnu"); //$NON-NLS-1$
    String ERREUR_MIGRATION_PORT_PM = Messages.getString("PE0529.ErreurMigrationPortPm"); //$NON-NLS-1$
    String ERREUR_ACTION_CORRECTIVE = Messages.getString("PE0529.ErreurActionCorrective"); //$NON-NLS-1$

  }

  /**
   * URL des processus Stark.
   *
   * @author JCHEVRON
   * @version ($Revision$ $Date$)
   */
  public interface IStarkURI
  {
    /** URI du processus PEI0229_CommandeActionCorrective */
    String PEI0229 = "/actions-correctives/"; //$NON-NLS-1$
  }

  /**
   * Actions lors d'une requête PUT
   *
   * @author JCHEVRON
   * @version ($Revision$ $Date$)
   */
  public enum Action
  {
    /** Action d'annulation d'une Operation Vie de Reseau */
    annuler,
    /** Action d'execution d'une Operation Vie de Reseau */
    executer
  }

  /**
   * Enumeration des paramètres URL.
   *
   * @author JCHEVRON
   * @version ($Revision$ $Date$)
   */
  public enum ParameterUrl
  {
    idOperationVieReseau, action
  }

  /**
   * Etats du processus
   *
   * @author JCHEVRON
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    PE0529_START(MandatoryProcessState.PRC_START), //
    PE0529_BL001(MandatoryProcessState.PRC_RUNNING), //
    PE0529_BL100(MandatoryProcessState.PRC_RUNNING), //
    PE0529_BL200(MandatoryProcessState.PRC_RUNNING), //
    PE0529_BL002(MandatoryProcessState.PRC_RUNNING), //
    PE0529_CONTINUE(MandatoryProcessState.PRC_RUNNING, true, true), //
    PE0529_BL400(MandatoryProcessState.PRC_RUNNING, true, true), //
    PE0529_BL005(MandatoryProcessState.PRC_RUNNING, true, true), //
    PE0529_END(MandatoryProcessState.PRC_STOP);

    /**
     * Etat technique associé
     */
    protected MandatoryProcessState _technicalState;

    /**
     * Etat asynchrone
     */
    protected boolean _asynchronousState;

    /**
     * Etat rejouable
     */
    protected boolean _replayableState;

    /**
     * Constructeur.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      this(technicalState_p, false, false);
    }

    /**
     * Constructeur.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayableState_p
     *          True si rejouable
     * @param asynchronousState_p
     *          True si asynchrone
     */
    State(final MandatoryProcessState technicalState_p, boolean replayableState_p, boolean asynchronousState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayableState_p;
      _asynchronousState = asynchronousState_p;
    }
  }

  /**
   * Contexte du processus {@link PE0529_OperationVieReseau}
   *
   * @author JCHEVRON
   * @version ($Revision$ $Date$)
   */
  public static final class OperationVieReseauContext extends Context
  {
    private static final long serialVersionUID = -7885731635699349292L;

    /** Cache des PMComposits. */
    protected final Map<String, PMComposite> _cachePMComposite = new HashMap<>();

    /** Cache des OltComposites. */
    protected final Map<String, OltComposite> _cacheOltComposite = new HashMap<>();

    /**
     * Identifiant de requête sur le SI<br />
     * (identifiant unique généré lors de l'appel à chaque ressource<br />
     * si non présent en entrée et fourni à chaque service appelé en synchrone)
     */
    private String _xRequestId = null;

    /**
     * Unique pour chaque interaction entre ST<br />
     * (il peut permettre de gérer l'anti-rejeu sur des alimentations par exemple)
     */
    private String _xMessageId = null;

    /**
     * La requête va être appliquée sur le SI<br />
     * avec potentiellement un ensemble de traitements synchrones décorrélés dans le temps : les actions<br />
     * (identifiant unique généré lors du démarrage d'un nouveau traitement asynchrone ou<br />
     * si non présent en entrée et fourni à chaque service appelé en synchrone)
     */
    private String _xActionId = null;

    /**
     * Prochain état à executer. Initialisé sur le premier état
     */
    private State _state = State.PE0529_START;

    /**
     * Retour du processus
     */
    private Retour _processRetour;

    /**
     * GET Response for consultation
     */
    private PE0529_GetResponse _consultationResponse;

    /**
     * bl002_Return
     */
    private Pair<Retour, ReponseErreur> _bl002Return;

    /**
     * identifiant de la ressource Operation vie reseau de REX
     */
    private String _idOperationVieReseau;

    /**
     * Objet de l'operation vie reseau en cours de traitement
     */
    private OperationVieReseau _operationVieReseau;

    /**
     * Configuration du processus
     */
    private ConfigurationPE0529 _configurationPE0529;

    /**
     * Liste des provisioning clients (listePairMigration & listePairModification)
     */
    private List<ProvisioningVDR> _listeProvisioning;

    /**
     * @return the bl002Return
     */
    public Pair<Retour, ReponseErreur> getBl002Return()
    {
      return _bl002Return;
    }

    /**
     * @return value of _configurationPE0529.
     */
    public ConfigurationPE0529 getConfigurationPE0529()
    {
      return _configurationPE0529;
    }

    /**
     * @return the consultationRequest
     */
    public PE0529_GetResponse getConsultationResponse()
    {
      return _consultationResponse;
    }

    /**
     * @return the idOperationVieReseau
     */
    public String getIdOperationVieReseau()
    {
      return _idOperationVieReseau;
    }

    /**
     * @return value of _listeProvisioning.
     */
    public List<ProvisioningVDR> getListeProvisioning()
    {
      return _listeProvisioning == null ? new ArrayList<>() : new ArrayList<>(_listeProvisioning);
    }

    /**
     * @return the operationVieReseau
     */
    public OperationVieReseau getOperationVieReseau()
    {
      return _operationVieReseau;
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the xActionId
     */
    public String getxActionId()
    {
      return _xActionId;
    }

    /**
     * @return the xMessageId
     */
    public String getxMessageId()
    {
      return _xMessageId;
    }

    /**
     * @return the xRequestId
     */
    public String getxRequestId()
    {
      return _xRequestId;
    }

    /**
     * @param bl002Return_p
     *          the bl002Return to set
     */
    public void setBl002Return(Pair<Retour, ReponseErreur> bl002Return_p)
    {
      _bl002Return = bl002Return_p;
    }

    /**
     * @param configurationPE0529_p
     *          the _configurationPE0529 to set.
     */
    public void setConfigurationPE0529(ConfigurationPE0529 configurationPE0529_p)
    {
      _configurationPE0529 = configurationPE0529_p;
    }

    /**
     * @param consultationResponse_p
     *          the consultationRequest to set
     */
    public void setConsultationResponse(PE0529_GetResponse consultationResponse_p)
    {
      _consultationResponse = consultationResponse_p;
    }

    /**
     * @param idOperationVieReseau_p
     *          the idOperationVieReseau to set
     */
    public void setIdOperationVieReseau(String idOperationVieReseau_p)
    {
      _idOperationVieReseau = idOperationVieReseau_p;
    }

    /**
     * @param listeProvisioning_p
     *          the _listeProvisioning to set.
     */
    public void setListeProvisioning(List<ProvisioningVDR> listeProvisioning_p)
    {
      _listeProvisioning = (listeProvisioning_p == null) ? null : new ArrayList<>(listeProvisioning_p);
    }

    /**
     * @param operationVieReseau_p
     *          the operationVieReseau to set
     */
    public void setOperationVieReseau(OperationVieReseau operationVieReseau_p)
    {
      _operationVieReseau = operationVieReseau_p;
    }

    /**
     * @param processRetour_p
     *          the processRetour to set
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param xActionId_p
     *          the xActionId to set
     */
    public void setxActionId(String xActionId_p)
    {
      _xActionId = xActionId_p;
    }

    /**
     * @param xMessageId_p
     *          the xMessageId to set
     */
    public void setxMessageId(String xMessageId_p)
    {
      _xMessageId = xMessageId_p;
    }

    /**
     * @param xRequestId_p
     *          the xRequestId to set
     */
    public void setxRequestId(String xRequestId_p)
    {
      _xRequestId = xRequestId_p;
    }
  }

  protected static final String ID_RACCORDEMENT = "ID_RACCORDEMENT"; //$NON-NLS-1$

  protected static final String PHYSIQUE = "PHYSIQUE"; //$NON-NLS-1$

  protected static final String VIE_DE_RESEAU = "VIE_DE_RESEAU"; //$NON-NLS-1$

  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  protected static final String LISSAGE_CHARGE_VDR = "LISSAGE_CHARGE_VDR"; //$NON-NLS-1$

  private static final long serialVersionUID = 1914038952287337374L;

  /**
   * Contexte du processus
   */
  protected OperationVieReseauContext _processContext;

  /**
   * @return the processContext
   */
  public OperationVieReseauContext getProcessContext()
  {
    return _processContext;
  }

  /**
   * @param processContext_p
   *          the processContext to set
   */
  public void setProcessContext(OperationVieReseauContext processContext_p)
  {
    _processContext = processContext_p;
  }

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idCommande_p
   *          Identifiant de commande à consulter
   * @return Pair de {@link Retour} et {@link Suivi}
   */
  protected Pair<Retour, Suivi> callStarkConnectorPEI0229Get(final Tracabilite tracabilite_p, final String idCommande_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    Suivi suivi = null;

    Tracabilite pei0229tracabilite = createTracabilitePEI0229(tracabilite_p);
    MultivaluedMap<String, String> headers = createHeadersPEI0229(pei0229tracabilite);
    String path = IStarkURI.PEI0229 + idCommande_p + "/suivi"; //$NON-NLS-1$

    try
    {
      RESTRequest restRequest = new RESTRequest.RESTRequestBuilder() //
          .httpMethod(HttpMethod.GET) //
          .traceability(pei0229tracabilite) //
          .method(IStarkURI.PEI0229) //
          .headers(headers) //
          .path(path) //
          .build();

      // Call STARK connector
      ConnectorResponse<Retour, STARKResponse<Suivi>> connectorResponse = STARKProxy.getInstance().sendRequest(restRequest, Suivi.class);

      Retour technicalRetour = connectorResponse._first; //Technical retour of connector
      STARKResponse<Suivi> functionalResponse = connectorResponse._second;

      if (isRetourNOK(technicalRetour))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, technicalRetour.getLibelle());
      }
      else if (nonNull(functionalResponse) && nonNull(functionalResponse.getReponseErreur()))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, functionalResponse.getReponseErreur().getError() + " : " + functionalResponse.getReponseErreur().getErrorDescription()); //$NON-NLS-1$
      }
      else if (nonNull(functionalResponse) && nonNull(functionalResponse.getResponse()))
      {
        suivi = functionalResponse.getResponse();
      }
      else
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(IMessage.ERREUR_ID_ACTION_CORRECTIVE, idCommande_p));
      }
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage());
    }

    return new Pair<>(retour, suivi);
  }

  /**
   * call Stark Connector : PEI0229 POST
   *
   * @param tracabilite_p
   *          tracabilite
   * @param noCompte_p
   *          Numéro compte
   * @param clientOperateur_p
   *          Client operateur
   * @param listeCleSequencement_p
   *          Liste cle sequencement
   * @return Pair de Retour et String
   */
  protected Pair<Retour, String> callStarkConnectorPEI0229Post(final Tracabilite tracabilite_p, final String noCompte_p, final String clientOperateur_p, final List<String> listeCleSequencement_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    String idActionCorrective = null;

    Tracabilite pei0229tracabilite = createTracabilitePEI0229(tracabilite_p);
    MultivaluedMap<String, String> headers = createHeadersPEI0229(pei0229tracabilite);

    // Construction objet request PE0033
    ActionCorrective pei0229Request = new ActionCorrective(clientOperateur_p, noCompte_p);
    if (!CollectionUtils.isEmpty(listeCleSequencement_p))
    {
      pei0229Request.setListeCleSequencement(listeCleSequencement_p);
    }
    IRavelJson jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();

    try
    {
      RESTRequest restRequest = new RESTRequest.RESTRequestBuilder() //
          .httpMethod(HttpMethod.POST) //
          .request(pei0229Request) //
          .traceability(pei0229tracabilite) //
          .method(IStarkURI.PEI0229) //
          .headers(headers) //
          .path(IStarkURI.PEI0229) //
          .serializer(jsonBuilder) //
          .build();

      // Call STARK connector
      ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = STARKProxy.getInstance().sendRequest(restRequest, ReponseErreur.class);

      Retour technicalRetour = connectorResponse._first;
      STARKResponse<ReponseErreur> functionalResponse = connectorResponse._second;

      if (isRetourNOK(technicalRetour))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, technicalRetour.getLibelle());
      }

      if (nonNull(functionalResponse) && nonNull(functionalResponse.getReponseErreur()))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, functionalResponse.getReponseErreur().getError() + " : " + functionalResponse.getReponseErreur().getErrorDescription()); //$NON-NLS-1$
      }

      if (nonNull(functionalResponse) && (ErrorCode.OK_00201.getHttpErrorCode() == functionalResponse.getHttpStatusCode()) && nonNull(functionalResponse.getResponseHeaders()))
      {
        idActionCorrective = functionalResponse.getResponseHeaders().getFirst(IHttpHeadersConsts.LOCATION);
      }
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage());
    }

    if (isRetourOK(retour) && isBlank(idActionCorrective))
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, IMessage.ERREUR_ID_ACTION_CORRECTIVE);
    }

    return new Pair<>(retour, idActionCorrective);
  }

  /**
   * call Stark Connector : PEI0229 PUT
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idActionCorrective_p
   *          Identifiant de l'action corrective
   * @return {@link Retour}
   */
  protected Retour callStarkConnectorPEI0229Put(final Tracabilite tracabilite_p, final String idActionCorrective_p)
  {
    Tracabilite pei0229tracabilite = createTracabilitePEI0229(tracabilite_p);
    MultivaluedMap<String, String> headers = createHeadersPEI0229(pei0229tracabilite);

    HashMap<String, String> queryParams = new HashMap<>();
    queryParams.put("action", "executerAction"); //$NON-NLS-1$ //$NON-NLS-2$

    try
    {
      RESTRequest restRequest = new RESTRequest.RESTRequestBuilder() //
          .httpMethod(HttpMethod.PUT) //
          .traceability(pei0229tracabilite) //
          .method(IStarkURI.PEI0229) //
          .headers(headers) //
          .path(idActionCorrective_p) //
          .queryParameter(queryParams) //
          .build();

      // Call STARK connector
      ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = STARKProxy.getInstance().sendRequest(restRequest, ReponseErreur.class);

      Retour technicalRetour = connectorResponse._first; //Technical retour of connector
      STARKResponse<ReponseErreur> functionalResponse = connectorResponse._second;

      if (isRetourNOK(technicalRetour))
      {
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, technicalRetour.getLibelle());
      }

      if (nonNull(functionalResponse) && nonNull(functionalResponse.getReponseErreur()))
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, functionalResponse.getReponseErreur().getError() + " : " + functionalResponse.getReponseErreur().getErrorDescription()); //$NON-NLS-1$
      }
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, exception.getMessage());
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Verification de la présence des headers obligatoires
   *
   * @param request_p
   *          {@link Request} requête du processus
   * @return the {@link Retour}.
   */
  protected Retour checkHeaders(final Request request_p)
  {
    String xSource = null;
    String xProcess = null;

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        xSource = header.getValue();
      }
      else if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        xProcess = header.getValue();
      }
      else if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()))
      {
        _processContext.setxRequestId(header.getValue());
      }
      else if (IHttpHeadersConsts.X_MESSAGE_ID.equalsIgnoreCase(header.getName()))
      {
        _processContext.setxMessageId(header.getValue());
      }
      else if (IHttpHeadersConsts.X_ACTION_ID.equalsIgnoreCase(header.getName()))
      {
        _processContext.setxActionId(header.getValue());
      }
    }

    if (isBlank(xSource))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(IMessage.INVALID_HEADER, IHttpHeadersConsts.X_SOURCE));
    }

    if (isBlank(xProcess))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(IMessage.INVALID_HEADER, IHttpHeadersConsts.X_PROCESS));
    }

    if (isBlank(_processContext.getxRequestId()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(IMessage.INVALID_HEADER, IHttpHeadersConsts.X_REQUEST_ID));
    }

    if (isBlank(_processContext.getxMessageId()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(IMessage.INVALID_HEADER, IHttpHeadersConsts.X_MESSAGE_ID));
    }

    if (isBlank(_processContext.getxActionId()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(IMessage.INVALID_HEADER, IHttpHeadersConsts.X_ACTION_ID));
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Validation du body de la requete de creation
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param requestBody_p
   *          {@link PE0529_PostRequest}
   * @return {@link Retour}
   * @param <T>
   *          the type of the request body.
   */
  protected <T> Retour checkRequestBody(Tracabilite tracabilite_p, T requestBody_p)
  {
    Retour retour = RetourFactory.createOkRetour();

    if (nonNull(requestBody_p))
    {
      ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
      Validator validator = factory.getValidator();
      Set<ConstraintViolation<T>> constraintViolations = validator.validate(requestBody_p);

      if (!constraintViolations.isEmpty())
      {
        Map<String, Set<String>> errorsMap = new HashMap<>();

        for (ConstraintViolation<T> c : constraintViolations)
        {
          if (!errorsMap.containsKey(c.getMessage()))
          {
            errorsMap.put(c.getMessage(), new HashSet<>());
          }
          errorsMap.get(c.getMessage()).add(c.getPropertyPath().toString());
        }

        StringBuilder messages = new StringBuilder();

        for (Map.Entry<String, Set<String>> entry : errorsMap.entrySet())
        {
          StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$

          for (String path : entry.getValue())
          {
            joiner.add(path);
          }

          messages.append(entry.getKey()).append(" {").append(joiner.toString()).append("}."); //$NON-NLS-1$ //$NON-NLS-2$
        }

        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, messages.toString()));
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, messages.toString());
      }

      factory.close();
    }
    else
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, IMessage.INVALID_REQUEST_BODY_FORMAT);
    }

    return retour;
  }

  /**
   * Creation des headers pour l'appel à PEI0229_CommandeActionCorrective
   *
   *
   * @param pei0229tracabilite_p
   *          {@link Tracabilite}
   * @return headers
   */
  protected MultivaluedMap<String, String> createHeadersPEI0229(final Tracabilite pei0229tracabilite_p)
  {
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
    headers.add(IHttpHeadersConsts.X_REQUEST_ID, _processContext.getxRequestId());
    headers.add(IHttpHeadersConsts.X_MESSAGE_ID, pei0229tracabilite_p.getIdCorrelationSpirit());
    headers.add(IHttpHeadersConsts.X_ACTION_ID, pei0229tracabilite_p.getIdCorrelationSpirit());

    return headers;
  }

  /**
   * Creation de la tracabilite pour l'appel à PEI0229_CommandeActionCorrective
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Tracabilite}
   */
  protected Tracabilite createTracabilitePEI0229(final Tracabilite tracabilite_p)
  {
    Tracabilite pei0229tracabilite = new Tracabilite(tracabilite_p);
    pei0229tracabilite.setIdCorrelationSpirit(UUID.randomUUID().toString());

    return pei0229tracabilite;
  }

  /**
   * Get an OLTComposite, either directly from RES or from a local cache.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param nomOLT_p
   *          the name of the OLT.
   * @return a pair with the {@link Retour} and, when OK, the {@link OltComposite}.
   * @throws RavelException
   *           on error.
   */
  protected Pair<Retour, OltComposite> getOltComposite(Tracabilite tracabilite_p, String nomOLT_p) throws RavelException
  {
    OltComposite oltComposite;

    // Get the OltComposite from cache, if it is already present
    if (_processContext._cacheOltComposite.containsKey(nomOLT_p))
    {
      oltComposite = _processContext._cacheOltComposite.get(nomOLT_p);
    }
    // Otherwise get it from RES and save it in the cache
    else
    {
      ConnectorResponse<Retour, OltComposite> resResponse = RESProxy.getInstance().oltCompositeLireUn(tracabilite_p, nomOLT_p);

      if (isRetourNOK(resResponse._first))
      {
        return new Pair<>(resResponse._first, null);
      }

      oltComposite = resResponse._second;
      _processContext._cacheOltComposite.put(nomOLT_p, oltComposite);
    }

    return new Pair<>(RetourFactory.createOkRetour(), oltComposite);
  }

  /**
   * Get a PMComposite, either directly from RES or from a local cache.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param referencePmBytel_p
   *          the referencePmBytel.
   * @return a pair with the {@link Retour} and, when OK, the {@link PMComposite}.
   * @throws RavelException
   *           on error.
   */
  protected Pair<Retour, PMComposite> getPMComposite(Tracabilite tracabilite_p, String referencePmBytel_p) throws RavelException
  {
    PMComposite pmComposite;

    // Get the PMComposite from cache, if it is already present
    if (_processContext._cachePMComposite.containsKey(referencePmBytel_p))
    {
      pmComposite = _processContext._cachePMComposite.get(referencePmBytel_p);
    }
    // Otherwise get it from RES and save it in the cache
    else
    {
      ConnectorResponse<Retour, PMComposite> resResponseLirePmParRef = RESProxy.getInstance().pmCompositeLireUnParReferencePmBytel(tracabilite_p, referencePmBytel_p);

      if (isRetourNOK(resResponseLirePmParRef._first))
      {
        return new Pair<>(resResponseLirePmParRef._first, null);
      }

      pmComposite = resResponseLirePmParRef._second;
      _processContext._cachePMComposite.put(referencePmBytel_p, pmComposite);
    }

    return new Pair<>(RetourFactory.createOkRetour(), pmComposite);
  }

  /**
   * Récupère le PortPM d'un PMComposite à partir d'un objet PositionPortPm.<br>
   * Get the PortPM represented by a PositionPortPm.
   *
   * @param pmComposite_p
   *          {@link PMComposite} dans lequel trouver le portPm
   * @param posPortPm_p
   *          {@link PositionPortPm} de reference
   * @return {@link PortPM}
   */
  protected PortPM getPortPmFromPmComposite(final PMComposite pmComposite_p, final PositionPortPm posPortPm_p)
  {
    PortPM portPmComposite = null;

    if(pmComposite_p.getReferencePmBytel().equals(posPortPm_p.getReferencePmBytel()))
    {
      if (nonNull(pmComposite_p) && nonNull(posPortPm_p))
      {
        BoitierPM boitierPM = pmComposite_p.getListeBoitierPM().get(posPortPm_p.getReferenceBoitierPm());

        if (nonNull(boitierPM))
        {
          PanneauPM panneauPM = boitierPM.getListePanneauPM().get(posPortPm_p.getNomPanneau());

          if (nonNull(panneauPM))
          {
            portPmComposite = panneauPM.getListePortPM().get(posPortPm_p.getPositionPort());
          }
        }
      }
    }

    return portPmComposite;
  }

  /**
   * Récupère le PortPon d'un OLTComposite à partir d'un objet PositionPortPon
   *
   * @param oltComposite_p
   *          {@link OltComposite} dans lequel trouver le portPon
   * @param posPortPon_p
   *          {@link PositionPortPon} de reference
   * @return {@link PortPON}
   */
  protected PortPON getPortPonFromOltComposite(final OltComposite oltComposite_p, final PositionPortPon posPortPon_p)
  {
    PortPON portPonComposite = null;

    if(oltComposite_p.getNomOLT().equals(posPortPon_p.getNomOLT()))
    {
      if (nonNull(oltComposite_p) && nonNull(posPortPon_p))
      {
        CartePON cartePon = oltComposite_p.getListeCartePON().get(posPortPon_p.getPositionCarte());

        if (nonNull(cartePon))
        {
          portPonComposite = cartePon.getListePortPON().get(posPortPon_p.getPosition());
        }
      }
    }

    return portPonComposite;
  }

  /**
   * Creation de l'impact client lié à la migration d'un port PM
   *
   * @param migrationPortPm_p
   *          Objet de migrationPortPm
   * @param pmComposite_p
   *          PMComposite
   * @param idOperationVieReseau_p
   *          Identifiant de l'operation
   * @param tracabilite_p
   *          Tracabilite
   * @return Pair de {@link Retour} et Pair de {@link ProvisioningVDR} et {@link RessourcePortPM}
   * @throws RavelException
   *           on error.
   */
  protected Pair<Retour, Pair<ProvisioningVDR, RessourcePortPM>> getProvisioningMigration(final MigrationPortPm migrationPortPm_p, final PMComposite pmComposite_p, final String idOperationVieReseau_p, final Tracabilite tracabilite_p) throws RavelException
  {
    Pair<ProvisioningVDR, RessourcePortPM> result = new Pair<>(null, null);

    PositionPortPm posPortPmSrc = migrationPortPm_p.getPositionPortPmSource();
    PositionPortPm posPortPmCible = migrationPortPm_p.getPositionPortPmCible();
    String idRessource = posPortPmSrc.toRessourceId();

    ClientImpacte clientImpacte = new ClientImpacte(null, ID_RACCORDEMENT);
    clientImpacte.setIdRessource(idRessource);
    ProvisioningVDR provisioningVDR = new ProvisioningVDRMigration(clientImpacte, posPortPmSrc, posPortPmCible);

    ConnectorResponse<Retour, Ressource> resLireRessource = RESProxy.getInstance().ressourceLireUn(tracabilite_p, idRessource, TypeRessource.PORT_PM.name());

    if (isRetourNOK(resLireRessource._first))
    {
      if (IMegConsts.DONNEE_INCONNUE.equals(resLireRessource._first.getDiagnostic()))
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, resLireRessource._first.getLibelle()));
        return new Pair<>(RetourFactory.createOkRetour(), result); // Client suivant
      }
      else
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_LECTURE, "RessourcePortPM", idRessource)); //$NON-NLS-1$
        return new Pair<>(resLireRessource._first, result);
      }
    }

    RessourcePortPM ressourcePortPMSrc = (RessourcePortPM) resLireRessource._second;
    provisioningVDR.setRessourcePortPM(ressourcePortPMSrc);
    result._second = ressourcePortPMSrc;

    if (!Statut.ALLOUE.name().equals(ressourcePortPMSrc.getStatut()))
    {
      return new Pair<>(RetourFactory.createOkRetour(), result); // Client suivant
    }

    provisioningVDR.getClientImpacte().setIdentifiantClient(ressourcePortPMSrc.getIdRessourceLie());
    result._first = provisioningVDR;

    PortPM portPMSrc = getPortPmFromPmComposite(pmComposite_p, posPortPmSrc);
    PortPM portPMCible = getPortPmFromPmComposite(pmComposite_p, posPortPmCible);

    if (isNull(portPMSrc) || isNull(portPMCible) || portPMSrc.getListeLienPortPMPon().equals(portPMCible.getListeLienPortPMPon()))
    {
      // On marque temporairement le client impacté à EN_COURS
      // Si l'appel RES.ressourcePortPmGererMigrationPortPm est NOK, le client sera NOK
      // Sinon le client sera supprimé de la liste clients impacté et ne sera pas ajouté dans REX
      provisioningVDR.getClientImpacte().setStatutProvisioning(ClientImpacteStatutProvisionning.EN_COURS.name());
      return new Pair<>(RetourFactory.createOkRetour(), result); // Client sans IDClient, client suivant
    }

    for (LienPortPMPon lienPortPon : portPMCible.getListeLienPortPMPon().values())
    {
      PortPonId portPonId = lienPortPon.getPortPon();

      Pair<Retour, OltComposite> resLireOlt = getOltComposite(tracabilite_p, portPonId.getNomOLT());

      if (isRetourNOK(resLireOlt._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_LECTURE, "OLTComposite", portPonId.getNomOLT())); //$NON-NLS-1$

        return new Pair<>(resLireOlt._first, result);
      }

      OltComposite oltComposite = resLireOlt._second;
      if (("NOKIA".equalsIgnoreCase(oltComposite.getConstructeur()) && _processContext.getConfigurationPE0529().isSequencerOltNokia()) //$NON-NLS-1$
          || ("HUAWEI".equalsIgnoreCase(oltComposite.getConstructeur()) && _processContext.getConfigurationPE0529().isSequencerOltHuawei())) //$NON-NLS-1$
      {
        provisioningVDR.addCleSequencement(portPonId.getNomOLT() + portPonId.getPositionCartePON() + portPonId.getPositionPortPON()); // $NON-NLS-2$
      }
    }

    return new Pair<>(RetourFactory.createOkRetour(), result);
  }

  /**
   * Creation de l'impact client lié à la modification d'un port PM
   *
   * @param modificationPortPm_p
   *          Objet de modificationPortPm
   * @param pmComposite_p
   *          PMComposite
   * @param idOperationVieReseau_p
   *          Identifiant de l'operation
   * @param tracabilite_p
   *          Tracabilite
   * @return Pair de {@link Retour} et {@link ProvisioningVDR}
   * @throws RavelException
   *           on error.
   */
  protected Pair<Retour, ProvisioningVDR> getProvisioningModification(final ModificationPortPm modificationPortPm_p, final PMComposite pmComposite_p, final String idOperationVieReseau_p, final Tracabilite tracabilite_p) throws RavelException
  {
    PositionPortPm posPortPm = modificationPortPm_p.getPositionPortPm();
    String idRessource = posPortPm.toRessourceId();

    ClientImpacte clientImpacte = new ClientImpacte(null, ID_RACCORDEMENT);
    clientImpacte.setIdRessource(idRessource);
    ProvisioningVDR provisioningVDR = new ProvisioningVDRModification(clientImpacte, posPortPm);

    ConnectorResponse<Retour, Ressource> resLireRessource = RESProxy.getInstance().ressourceLireUn(tracabilite_p, idRessource, TypeRessource.PORT_PM.name());

    if (isRetourNOK(resLireRessource._first))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, resLireRessource._first.getLibelle()));
      return new Pair<>(RetourFactory.createOkRetour(), null); // Client suivant
    }

    RessourcePortPM ressourcePortPMSrc = (RessourcePortPM) resLireRessource._second;
    provisioningVDR.setRessourcePortPM(ressourcePortPMSrc);

    if (!Statut.ALLOUE.name().equals(ressourcePortPMSrc.getStatut()))
    {
      return new Pair<>(RetourFactory.createOkRetour(), null); // Client suivant
    }

    if (modificationPortPm_p.getLiensPortPonSource().equals(modificationPortPm_p.getLiensPortPonCible()))
    {
      return new Pair<>(RetourFactory.createOkRetour(), null); // Client suivant
    }

    provisioningVDR.getClientImpacte().setIdentifiantClient(ressourcePortPMSrc.getIdRessourceLie());
    provisioningVDR.getClientImpacte().setIdRessource(idRessource);

    PortPM portPM = getPortPmFromPmComposite(pmComposite_p, posPortPm);

    for (LienPortPMPon lienPortPon : portPM.getListeLienPortPMPon().values())
    {
      PortPonId portPonId = lienPortPon.getPortPon();

      Pair<Retour, OltComposite> resLireOlt = getOltComposite(tracabilite_p, portPonId.getNomOLT());

      if (isRetourNOK(resLireOlt._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_LECTURE, "OLTComposite", portPonId.getNomOLT())); //$NON-NLS-1$

        return new Pair<>(resLireOlt._first, null);
      }
      OltComposite oltComposite = resLireOlt._second;
      if (("NOKIA".equalsIgnoreCase(oltComposite.getConstructeur()) && _processContext.getConfigurationPE0529().isSequencerOltNokia()) //$NON-NLS-1$
          || ("HUAWEI".equalsIgnoreCase(oltComposite.getConstructeur()) && _processContext.getConfigurationPE0529().isSequencerOltHuawei())) //$NON-NLS-1$
      {
        provisioningVDR.addCleSequencement(portPonId.getNomOLT() + portPonId.getPositionCartePON() + portPonId.getPositionPortPON()); // $NON-NLS-2$
      }
    }

    return new Pair<>(RetourFactory.createOkRetour(), provisioningVDR);
  }

  /** Check if a PositionPortPm is in a Set of PositionPortPm objects comparing functionally
   * @param positionPortPmSet_p The Set to containing PositionPortPm elements
   * @param positionPortPm_p The element to check
   * @return true if found, false otherwise
   */
  protected boolean isPositionPortPmInSet(Set<PositionPortPm> positionPortPmSet_p, PositionPortPm positionPortPm_p)
  {
    return positionPortPmSet_p.stream().filter(p ->p.isFunctionallyEquals(positionPortPm_p)).findFirst().isPresent();
  }

  /**
   *
   * Validation de la configuration du processus
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @return Retour OK si la configuration est bonne.
   */
  protected Retour loadConfiguration(final Tracabilite tracabilite_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    String configPE0529Param = getConfigParameter(PARAM_CONFIG_PATH);
    if (!StringTools.isNullOrEmpty(configPE0529Param))
    {
      try
      {
        Path configPE0529Path = Paths.get(configPE0529Param);
        String configPE0529File = new String(Files.readAllBytes(configPE0529Path));
        _processContext.setConfigurationPE0529(MarshallTools.unmarshall(ConfigurationPE0529.class, configPE0529File));
      }
      catch (Exception exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
        retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(IMessage.FILE_ERROR, exception.getMessage()));
      }
    }
    else
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(IMessage.NO_PARAM, PARAM_CONFIG_PATH)));
      retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(IMessage.NO_PARAM, PARAM_CONFIG_PATH));
    }
    return retour;
  }

  /**
   * Mapping entre le statut du suivi de commande et le statut d'operation vie reseau
   *
   * @param statut_p
   *          statut dans {@link Suivi}
   * @return Statut {@link OperationVieReseauStatut}
   */
  protected String mappingStatutProvisionning(final String statut_p)
  {
    if (com.bytel.spirit.common.shared.saab.cmd.Statut.DEMARRE.name().equals(statut_p) //
        || com.bytel.spirit.common.shared.saab.cmd.Statut.PROPOSE.name().equals(statut_p))
    {
      return ClientImpacteStatutProvisionning.EN_COURS.name();
    }
    else if (com.bytel.spirit.common.shared.saab.cmd.Statut.TRAITE.name().equals(statut_p))
    {
      return ClientImpacteStatutProvisionning.TRAITE_OK.name();
    }
    else if (com.bytel.spirit.common.shared.saab.cmd.Statut.INVALIDE.name().equals(statut_p) //
        || com.bytel.spirit.common.shared.saab.cmd.Statut.INTERVENTION_SUPPORT.name().equals(statut_p))
    {
      return ClientImpacteStatutProvisionning.NOK.name();
    }

    return ClientImpacteStatutProvisionning.NOK.name();
  }

  /**
   * Envoi de la réponse synchrone pour la requête POST
   *
   * @param request_p
   *          {@link Request}
   * @param bl002Result_p
   *          {@link Pair} de {@link Retour} et {@link ReponseErreur}
   * @param idOperationVieReseau_p
   *          Identifiant de l'operation Vie Reseau
   * @throws RavelException
   *           on error.
   *
   */
  protected void syncPostResponse(Request request_p, final Pair<Retour, ReponseErreur> bl002Result_p, final String idOperationVieReseau_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      Response rsp;
      ReponseErreur reponseErreur = bl002Result_p._second;
      Retour retour = bl002Result_p._first;

      if (reponseErreur != null)
      {
        ErrorCode errorCode;

        if (IMegSpiritConsts.ACCES_REFUSE.equals(retour.getDiagnostic()))
        {
          errorCode = ErrorCode.KO_00403;
        }
        else
        {
          errorCode = getDefaultHttpCodeFromRetour(retour);
        }
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur, ReponseErreur.class));
        rsp = new Response(errorCode, ravelResponse);
      }
      else
      {
        PE0529_PostResponse peResponse = new PE0529_PostResponse();
        peResponse.setIdOperationVieReseau(idOperationVieReseau_p);
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(peResponse, PE0529_PostResponse.class));
        rsp = new Response(ErrorCode.OK_00201, ravelResponse);
      }

      request_p.setResponse(rsp);
    }
  }

  /**
   * Envoi de la réponse synchrone pour la requête PUT
   *
   * @param request_p
   *          {@link Request}
   * @param bl002Result_p
   *          {@link Pair} de {@link Retour} et {@link ReponseErreur}
   * @throws RavelException
   *           on error.
   */
  protected void syncPutResponse(Request request_p, final Pair<Retour, ReponseErreur> bl002Result_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp;
      ReponseErreur reponseErreur = bl002Result_p._second;
      Retour retour = bl002Result_p._first;

      if (reponseErreur != null)
      {
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

        ErrorCode errorCode;

        if (IMegSpiritConsts.ACCES_REFUSE.equals(retour.getDiagnostic()))
        {
          errorCode = ErrorCode.KO_00403;
        }
        else
        {
          errorCode = getDefaultHttpCodeFromRetour(retour);
        }

        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur, ReponseErreur.class));
        rsp = new Response(errorCode, ravelResponse);
      }
      else
      {
        rsp = new Response(ErrorCode.OK_00202, ravelResponse);
      }

      request_p.setResponse(rsp);
    }
  }

  /**
   * Construction de l'OLTComposite à partir des changements de VDR
   *
   * @param oltComposite_p
   *          {@link OltComposite} à transformer
   * @param donneesBrutes_p
   *          {@link PE0529_PostRequest} données brutes de l'operation vie reseau
   * @param nomOlt_p
   *          Nom de l'OLT
   */
  protected void updateOltComposite(OltComposite oltComposite_p, final PE0529_PostRequest donneesBrutes_p, final String nomOlt_p)
  {
    if (nonNull(oltComposite_p) && nonNull(donneesBrutes_p))
    {
      oltComposite_p.setDateDernierImport(null);

      // Traitement des suppressions Ports Pon
      for (SuppressionPortPon suppressionPortPon : donneesBrutes_p.getSuppressionsPortsPon())
      {
        PositionPortPon posPortPon = suppressionPortPon.getPositionPortPon();

        if (posPortPon.getNomOLT().equals(nomOlt_p))
        {
          PortPON portPonComposite = getPortPonFromOltComposite(oltComposite_p, posPortPon);

          if (nonNull(portPonComposite))
          {
            portPonComposite.setStatutTechnique(StatutTechniqueOlt.SUPPRIME.name());
          }
        }
      }

      // Traitement des ajouts Ports Pon
      for (AjoutPortPon ajoutPortPon : donneesBrutes_p.getAjoutsPortsPon())
      {
        PositionPortPon posPortPon = ajoutPortPon.getPositionPortPon();

        if (posPortPon.getNomOLT().equals(nomOlt_p))
        {
          CartePON cartePONComposite = oltComposite_p.getListeCartePON().get(posPortPon.getPositionCarte());

          if (isNull(cartePONComposite))
          {
            cartePONComposite = new CartePON(posPortPon.getPositionCarte(), ajoutPortPon.getCartePon().getModeleCarte(), StatutTechniqueOlt.OPERATIONNEL.name());
            oltComposite_p.getListeCartePON().put(posPortPon.getPositionCarte(), cartePONComposite);
          }

          PortPON portPONComposite = new PortPON(posPortPon.getPosition(), StatutTechniqueOlt.OPERATIONNEL.name(), new HashSet<>(ajoutPortPon.getSfpListeTechnologieCompatible()), ajoutPortPon.getMaxOntId());
          portPONComposite.setReferenceCableRenvoi(ajoutPortPon.getReferenceCableRenvoiNro());
          portPONComposite.setCodificationVolume(ajoutPortPon.getCodificationVolume());
          portPONComposite.setPositionFoNro(ajoutPortPon.getPositionFoNro());
          cartePONComposite.getListePortPON().put(posPortPon.getPosition(), portPONComposite);
        }
      }
      // Traitement des modifications Ports Pon
      for (ModificationPortPon modifPortPon : donneesBrutes_p.getModificationsPortsPon())
      {
        PositionPortPon posPortPon = modifPortPon.getPositionPortPon();

        if (posPortPon.getNomOLT().equals(nomOlt_p))
        {
          PortPON portPonComposite = getPortPonFromOltComposite(oltComposite_p, posPortPon);

          if (nonNull(portPonComposite))
          {
            portPonComposite.setSfpListeTechnologieCompatible(new HashSet<>(modifPortPon.getSfpListeTechnologieCompatible()));
          }
        }
      }
    }
  }

  /**
   * Construction du PMComposite à partir des changements de VDR
   *
   * @param pmComposite_p
   *          {@link PMComposite} à transformer
   * @param idOperationVieReseau_p
   *          Identifiant de l'OVR
   * @param donneesBrutes_p
   *          {@link PE0529_PostRequest} données brutes de l'operation vie reseau
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @throws RavelException
   *           on error.
   */
  protected Pair<Retour, List<ProvisioningVDR>> updatePmComposite(PMComposite pmComposite_p, final String idOperationVieReseau_p, final PE0529_PostRequest donneesBrutes_p, final Tracabilite tracabilite_p) throws RavelException
  {
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>();

    if (nonNull(pmComposite_p) && nonNull(donneesBrutes_p))
    {
      pmComposite_p.setDateDernierImport(null);

      // Traitement des ajouts Ports Pm
      for (AjoutPortPm ajoutPortPm : donneesBrutes_p.getAjoutsPortsPm())
      {
        PositionPortPm posPortPm = ajoutPortPm.getPositionPortsPm();

        if (posPortPm.getReferencePmBytel().equals(pmComposite_p.getReferencePmBytel()))
        {
          BoitierPM boitierPM = pmComposite_p.getListeBoitierPM().get(posPortPm.getReferenceBoitierPm());

          if (isNull(boitierPM))
          {
            boitierPM = new BoitierPM(ajoutPortPm.getBoitierPm().getReferenceBoitierPm(), StatutTechniquePM.OPERATIONNEL.name(), null);
            boitierPM.setNomPmTechnique(ajoutPortPm.getBoitierPm().getNomPmTechnique());
            pmComposite_p.getListeBoitierPM().put(ajoutPortPm.getBoitierPm().getReferenceBoitierPm(), boitierPM);
          }

          PanneauPM panneauPm = boitierPM.getListePanneauPM().get(posPortPm.getNomPanneau());

          if (isNull(panneauPm))
          {
            panneauPm = new PanneauPM(posPortPm.getNomPanneau(), StatutTechniquePM.OPERATIONNEL.name(), null);
            panneauPm.setBaie(ajoutPortPm.getPanneauPm().getBaie());
            panneauPm.setFace(ajoutPortPm.getPanneauPm().getFace());
            panneauPm.setTiroir(ajoutPortPm.getPanneauPm().getTiroir());
            panneauPm.setPositionAlpha(ajoutPortPm.getPanneauPm().getPositionAlpha());
            boitierPM.getListePanneauPM().put(posPortPm.getNomPanneau(), panneauPm);
          }

          PortPM portPM = new PortPM(posPortPm.getPositionPort(), StatutTechniquePM.OPERATIONNEL.name(), null);
          portPM.setNomCoupleur(posPortPm.getNomCoupleur());

          for (LienPortPon lienPortPon : ajoutPortPm.getLiensPortPon())
          {
            String cleLienPortPon = lienPortPon.toRessourceId();
            PortPonId portPonId = new PortPonId(lienPortPon.getNomOLT(), lienPortPon.getPositionCartePon(), lienPortPon.getPositionPortPon());
            LienPortPMPon lienPortPMPon = new LienPortPMPon(StatutTechniquePM.OPERATIONNEL.name(), portPonId);
            portPM.getListeLienPortPMPon().put(cleLienPortPon, lienPortPMPon);
          }

          panneauPm.getListePortPM().put(portPM.getPosition(), portPM);
        }
      }

      // Traitement des modifications Ports Pm
      for (ModificationPortPm modificationPortPm : donneesBrutes_p.getModificationsPortsPm())
      {
        PositionPortPm posPortPm = modificationPortPm.getPositionPortPm();
        PortPM portPm = getPortPmFromPmComposite(pmComposite_p, posPortPm);

        if (nonNull(portPm))
        {
          Pair<Retour, ProvisioningVDR> retourProvModif = getProvisioningModification(modificationPortPm, pmComposite_p, idOperationVieReseau_p, tracabilite_p);

          if(isRetourNOK(retourProvModif._first))
          {
            return new Pair<>(retourProvModif._first, listeProvisioning);
          }
          if(nonNull(retourProvModif._second))
          {
            listeProvisioning.add(retourProvModif._second);
          }

          for (LienPortPon lienPortPon : modificationPortPm.getLiensPortPonCible())
          {
            String cleLienPortPon = lienPortPon.toRessourceId();
            PortPonId portPonId = new PortPonId(lienPortPon.getNomOLT(), lienPortPon.getPositionCartePon(), lienPortPon.getPositionPortPon());
            LienPortPMPon lienPortPMPon = new LienPortPMPon(StatutTechniquePM.OPERATIONNEL.name(), portPonId);
            portPm.getListeLienPortPMPon().put(cleLienPortPon, lienPortPMPon);
          }

          for (LienPortPon lienPortPon : modificationPortPm.getLiensPortPonSource())
          {
            String cleLienPortPon = lienPortPon.toRessourceId();
            portPm.getListeLienPortPMPon().remove(cleLienPortPon);
          }
        }
      }

      // Traitement des migrations Ports Pm
      for (MigrationPortPm migrationportPm : donneesBrutes_p.getMigrationsPortsPm())
      {
        PositionPortPm posPortSrc = migrationportPm.getPositionPortPmSource();
        PositionPortPm posPortCible = migrationportPm.getPositionPortPmCible();

        if(posPortSrc.getReferencePmBytel().equals(pmComposite_p.getReferencePmBytel()) && posPortCible.getReferencePmBytel().equals(pmComposite_p.getReferencePmBytel()))
        {
          Pair<Retour, Pair<ProvisioningVDR, RessourcePortPM>> retourProvMigr = getProvisioningMigration(migrationportPm, pmComposite_p, idOperationVieReseau_p, tracabilite_p);

          if(isRetourNOK(retourProvMigr._first))
          {
            return new Pair<>(retourProvMigr._first, listeProvisioning);
          }
          if(nonNull(retourProvMigr._second._first))
          {
            listeProvisioning.add(retourProvMigr._second._first);
          }
          if(isNull(retourProvMigr._second._second))
          {
            continue; // RessourcePortPM DONNEE_INCONNUE
          }

          if (Statut.ALLOUE.name().equals(retourProvMigr._second._second.getStatut()))
          {
            String refBoitier = posPortSrc.getReferenceBoitierPm();
            BoitierPM boitierPMSrc = pmComposite_p.getListeBoitierPM().get(refBoitier);
            PanneauPM panneauPMSrc = boitierPMSrc.getListePanneauPM().get(posPortSrc.getNomPanneau());
            PortPM portPmComposite = panneauPMSrc.getListePortPM().get(posPortSrc.getPositionPort());

            if (portPmComposite != null)
            {
              BoitierPM boitierPMCible = pmComposite_p.getListeBoitierPM().get(posPortCible.getReferenceBoitierPm());
              PanneauPM panneauPMCible = boitierPMCible.getListePanneauPM().get(posPortCible.getNomPanneau());
              PortPM portPMCible = new PortPM(posPortCible.getPositionPort(), portPmComposite.getStatutTechnique(), portPmComposite.getListeLienPortPMPon());
              portPMCible.setSurchargePortPM(portPmComposite.getSurchargePortPM());
              portPMCible.setIdRessourceRaccordement(portPmComposite.getIdRessourceRaccordement());
              portPMCible.setNomCoupleur(portPmComposite.getNomCoupleur());
              portPMCible.setDateCreation(portPmComposite.getDateCreation());
              portPMCible.setDateModification(portPmComposite.getDateModification());
              portPMCible.setDateModification(portPmComposite.getDateModification());
              panneauPMCible.getListePortPM().put(posPortCible.getPositionPort(), portPMCible);
            }
          }
        }
      }
    }

    return new Pair<>(RetourFactory.createOkRetour(), listeProvisioning);
  }

  /**
   * Verify that everything is valid in the AjoutsPortsPon.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param postRequest_p
   *          the request.
   * @return the {@link Retour}.
   * @throws RavelException
   *           on error.
   */
  protected Retour verifyAddedPortPMList(Tracabilite tracabilite_p, PE0529_PostRequest postRequest_p) throws RavelException
  {
    // On contrôle si les liens portPon existent dans RES ou dans ajoutsPortsPon
    for (AjoutPortPm ajoutPortPm : postRequest_p.getAjoutsPortsPm())
    {
      for (LienPortPon lienPortPon : ajoutPortPm.getLiensPortPon())
      {
        Pair<Retour, OltComposite> resResponseLireOlt = getOltComposite(tracabilite_p, lienPortPon.getNomOLT());

        if (isRetourNOK(resResponseLireOlt._first))
        {
          return resResponseLireOlt._first;
        }

        if ((getPortPonFromOltComposite(resResponseLireOlt._second, lienPortPon.toPositionPortPon()) == null) && (postRequest_p.getAjoutPortPonFromPositionPortPm(lienPortPon) == null))
        {
          return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(IMessage.LIEN_PORT_PON_INEXISTANT, lienPortPon.getNomOLT(), lienPortPon.getPositionCartePon(), lienPortPon.getPositionPortPon()));
        }
      }
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Verify that everything is valid in the ModificationsPortsPm.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param postRequest_p
   *          the request.
   * @return the {@link Retour}.
   * @throws RavelException
   *           on error.
   */
  protected Retour verifyModificationPortPMList(Tracabilite tracabilite_p, PE0529_PostRequest postRequest_p) throws RavelException
  {
    for (ModificationPortPm modificationPortPm : postRequest_p.getModificationsPortsPm())
    {
      PositionPortPm posPortPm = modificationPortPm.getPositionPortPm();

      // Contrôle de l'existence de positionPortPm dans RES - Make sure the portPM exists in RES
      Pair<Retour, PMComposite> resResponseLirePmParRef = getPMComposite(tracabilite_p, posPortPm.getReferencePmBytel());

      if (isRetourNOK(resResponseLirePmParRef._first))
      {
        return resResponseLirePmParRef._first;
      }

      if ((getPortPmFromPmComposite(resResponseLirePmParRef._second, posPortPm) == null) && !isPositionPortPmInSet(postRequest_p.getListePortPmAjoutes(), posPortPm))
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(IMessage.PORTPM_MODIFICATION_INEXISTANT, posPortPm.getReferencePmBytel(), posPortPm.getReferenceBoitierPm(), posPortPm.getNomPanneau(), posPortPm.getPositionPort()));
      }

      // Get the set of all technologies associated with the source LienPortPon
      Set<String> listeTechnoSrc = new HashSet<>();

      for (LienPortPon lienPortPon : modificationPortPm.getLiensPortPonSource())
      {
        Pair<Retour, OltComposite> resResponseLireOlt = getOltComposite(tracabilite_p, lienPortPon.getNomOLT());

        if (isRetourNOK(resResponseLireOlt._first))
        {
          return resResponseLireOlt._first;
        }

        PortPON portPon = getPortPonFromOltComposite(resResponseLireOlt._second, lienPortPon.toPositionPortPon());

        if (nonNull(portPon))
        {
          listeTechnoSrc.addAll(portPon.getSfpListeTechnologieCompatible());
        }
        // TODO: SHOULDN'T WE AT LEAST WARN?
      }

      // Get the set of all technologies associated with the source LienPortPon
      Set<String> listeTechnoCible = new HashSet<>();

      // Contrôle des modifications des ports PON d'adduction des ports Pm :
      // - tous les ports PON cible doivent exister dans RES ou dans ajoutsPortsPon - Make sure the target ports PON exist in either RES or the added ports PON (AjoutPortPon)
      for (LienPortPon lienPortPon : modificationPortPm.getLiensPortPonCible())
      {
        Pair<Retour, OltComposite> resResponseLireOlt = getOltComposite(tracabilite_p, lienPortPon.getNomOLT());

        if (isRetourNOK(resResponseLireOlt._first))
        {
          return resResponseLireOlt._first;
        }

        PortPON portPon = getPortPonFromOltComposite(resResponseLireOlt._second, lienPortPon.toPositionPortPon());

        if (portPon == null)
        {
          AjoutPortPon ajoutPortPon = postRequest_p.getAjoutPortPonFromPositionPortPm(lienPortPon);

          if (ajoutPortPon == null)
          {
            return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(IMessage.LIEN_PORT_PON_INEXISTANT, lienPortPon.getNomOLT(), lienPortPon.getPositionCartePon(), lienPortPon.getPositionPortPon()));
          }

          listeTechnoCible.addAll(ajoutPortPon.getSfpListeTechnologieCompatible());
        }
        else
        {
          listeTechnoCible.addAll(portPon.getSfpListeTechnologieCompatible());
        }
      }

      //  - contrôle des changements de technologiePON dans les modifications des ports Pm
      // Make sure all of the technologies available in the source ports are still available in the target ones
      if (!listeTechnoCible.containsAll(listeTechnoSrc))
      {
        String message = MessageFormat.format(IMessage.MODIFICATION_TECHNO_IMPOSSIBLE, posPortPm.getReferencePmBytel(), posPortPm.getReferenceBoitierPm(), posPortPm.getNomPanneau(), posPortPm.getPositionPort());
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, message);
      }
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Verify that everything is valid in the ModificationsPortsPon.
   *
   * @param tracabilite_p
   *          the tracabilite.
   * @param postRequest_p
   *          the request.
   * @return the {@link Retour}.
   * @throws RavelException
   *           on error.
   */
  protected Retour verifyModificationPortPONList(Tracabilite tracabilite_p, PE0529_PostRequest postRequest_p) throws RavelException
  {
    //  - interdire downgrade de XGPON à GPON si debitGarantieCapaciteAllouee > 0
    for (ModificationPortPon modificationPortPon : postRequest_p.getModificationsPortsPon())
    {
      Pair<Retour, OltComposite> resResponseLireOlt = getOltComposite(tracabilite_p, modificationPortPon.getPositionPortPon().getNomOLT());

      if (isRetourNOK(resResponseLireOlt._first))
      {
        return resResponseLireOlt._first;
      }

      try
      {
        PortPON portPon = getPortPonFromOltComposite(resResponseLireOlt._second, modificationPortPon.getPositionPortPon());

        if (!modificationPortPon.getSfpListeTechnologieCompatible().contains(TypeTechnologiePON.XGSPON.name()) && portPon.getSfpListeTechnologieCompatible().contains(TypeTechnologiePON.XGSPON.name()) && (portPon.getSurchargePortPON().getDebitGarantieCapaciteAllouee() > 0))
        {
          return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MessageFormat.format(IMessage.STPFTECHNOCOMPATIBLE_NON_MODIFIABLE, modificationPortPon.getPositionPortPon().getNomOLT(), modificationPortPon.getPositionPortPon().getPositionCarte(), modificationPortPon.getPositionPortPon().getPosition()));
        }
      }
      catch (Exception exception)
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, IMessage.PORT_PON_INEXISTANT);
      }
    }

    return RetourFactory.createOkRetour();
  }

}
