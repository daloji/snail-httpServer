/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0529;

import static com.bytel.ravel.common.utils.RetourFactory.isRetourNOK;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.isBlank;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.StringJoiner;
import java.util.stream.Collectors;

import com.bytel.spirit.common.shared.saab.res.StatutTechniquePM;
import com.bytel.spirit.tesla.processes.PE0529.structs.ProvisioningVDRMigration;
import org.apache.commons.collections4.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.spirit.common.activities.shared.BL4600_CreerErreurSpirit;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL850_ObtenirTicket;
import com.bytel.spirit.common.activities.shared.BL851_LibererTicket;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.air.AIRProxy;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.res.LienPortPMPon;
import com.bytel.spirit.common.shared.saab.res.OltComposite;
import com.bytel.spirit.common.shared.saab.res.OntId;
import com.bytel.spirit.common.shared.saab.res.PMComposite;
import com.bytel.spirit.common.shared.saab.res.PortPM;
import com.bytel.spirit.common.shared.saab.res.PortPON;
import com.bytel.spirit.common.shared.saab.res.PortPonId;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;
import com.bytel.spirit.common.shared.saab.res.Statut;
import com.bytel.spirit.common.shared.saab.res.TypeIdentifiant;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.common.shared.saab.rex.CleRechercheOperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacte;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacteStatutProvisionning;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseauStatut;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheOperationVieReseauRequest;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.types.json.Suivi;
import com.bytel.spirit.common.shared.utils.PFIFilter;
import com.bytel.spirit.common.shared.utils.PFIFilterOption;
import com.bytel.spirit.common.shared.utils.PFIUtils;
import com.bytel.spirit.tesla.processes.PE0529.structs.ProvisioningVDR;
import com.bytel.spirit.tesla.shared.types.PE0529.AjoutPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.LienPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.MigrationPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPm;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.SuppressionPortPon;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PostRequest;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PutRequest;
import com.bytel.spirit.tesla.shared.types.PE0529.response.PE0529_GetResponse;

/**
 * Processus déclenché pour mettre à jour la topologie réseau d'accès FTTH à la suite d'opérations Vie de Réseau
 * (exemples : swap de coupleur PON128, modernisation ZTD, …).
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public final class PE0529_OperationVieReseau extends AbstractOperationVieReseau
{

  private static final long serialVersionUID = 2961320081278552194L;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p)
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ZERO;
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new OperationVieReseauContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continuePutProcess(Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      if (State.PE0529_CONTINUE.equals(_processContext.getState()) && isNull(_processContext.getBl002Return()._second))
      {
        // Call BL400
        _processContext.setState(State.PE0529_BL400);
        Retour bl400Retour = PE0529_BL400_Provisioning(tracabilite_p, _processContext.getIdOperationVieReseau());
        _processContext.setProcessRetour(bl400Retour);
      }
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
    }
    finally
    {
      _processContext.setState(State.PE0529_BL005);
      PE0529_BL005_GererErreurPROSPERModification(_processContext.getProcessRetour(), tracabilite_p);
    }

    this.setRetour(_processContext.getProcessRetour());
    _processContext.setState(State.PE0529_END);
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Nothing to do
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p)
  {
    try
    {
      // Call BL001
      _processContext.setState(State.PE0529_BL001);
      Pair<Retour, String> bl001Retour = PE0529_BL001_VerifierDonneesConsultation(tracabilite_p, request_p);
      _processContext.setProcessRetour(bl001Retour._first);

      if (isRetourOK(bl001Retour._first))
      {
        String idOperationVieReseau = bl001Retour._second;
        _processContext.setIdOperationVieReseau(idOperationVieReseau);

        // Call BL100
        _processContext.setState(State.PE0529_BL100);
        Pair<Retour, PE0529_GetResponse> bl100Retour = PE0529_BL100_ConsulterOperationVDR(idOperationVieReseau, tracabilite_p);
        _processContext.setProcessRetour(bl100Retour._first);
        _processContext.setConsultationResponse(bl100Retour._second);
      }
    }
    catch (final Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      Retour retourException = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
      _processContext.setProcessRetour(retourException);
    }
    finally
    {
      // Call BL002
      _processContext.setState(State.PE0529_BL002);
      Pair<Retour, Response> retourBL002 = PE0529_BL002_FormaterReponseConsultation( //
          tracabilite_p, _processContext.getProcessRetour(), //
          _processContext.getConsultationResponse() //
      );

      _processContext.setProcessRetour(retourBL002._first);
      this.setRetour(retourBL002._first);

      // Send the response
      if (nonNull(request_p))
      {
        request_p.setResponse(retourBL002._second);
      }

      _processContext.setState(State.PE0529_END);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Nothing to do
  }

  @Override
  @LogStartProcess
  protected void startPostProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      // Call BL001
      _processContext.setState(State.PE0529_BL001);
      Pair<Retour, PE0529_PostRequest> bl001Retour = PE0529_BL001_VerifierDonneesCreation(request_p, tracabilite_p);
      _processContext.setProcessRetour(bl001Retour._first);

      if (isRetourOK(bl001Retour._first) && nonNull(bl001Retour._second))
      {
        // Call BL100
        _processContext.setState(State.PE0529_BL100);
        Pair<Retour, String> bl100Retour = PE0529_BL100_CreerOperationVDR(bl001Retour._second, tracabilite_p);
        _processContext.setProcessRetour(bl100Retour._first);
        _processContext.setIdOperationVieReseau(bl100Retour._second);
      }
    }
    catch (final Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      Retour retourException = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
      _processContext.setProcessRetour(retourException);
    }
    finally
    {
      // Call BL002
      _processContext.setState(State.PE0529_BL002);
      Pair<Retour, ReponseErreur> bl002Result = PE0529_BL002_FormaterReponseCreation(_processContext.getProcessRetour(), tracabilite_p);
      _processContext.setBl002Return(bl002Result);

      // Send the response
      syncPostResponse(request_p, bl002Result, _processContext.getIdOperationVieReseau());

      this.setRetour(bl002Result._first);
      _processContext.setState(State.PE0529_END);
    }
  }

  @Override
  @LogStartProcess
  protected void startPutProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      // Call BL001
      _processContext.setState(State.PE0529_BL001);
      Pair<Retour, PE0529_PutRequest> bl001Retour = PE0529_BL001_VerifierDonneesModification(tracabilite_p, request_p);
      _processContext.setProcessRetour(bl001Retour._first);

      if (isRetourOK(bl001Retour._first) && nonNull(bl001Retour._second))
      {
        // Call BL100
        if (Action.annuler.name().equals(bl001Retour._second.getAction()))
        {
          _processContext.setState(State.PE0529_BL100);
          Retour bl100Retour = PE0529_BL100_AnnulerOperationVDR(_processContext.getIdOperationVieReseau(), tracabilite_p);
          _processContext.setProcessRetour(bl100Retour);
        }

        // Call BL200
        else if (Action.executer.name().equals(bl001Retour._second.getAction()))
        {
          _processContext.setState(State.PE0529_BL200);
          Pair<Retour, List<ProvisioningVDR>> bl200Retour = PE0529_BL200_MajReferentiel(_processContext.getIdOperationVieReseau(), tracabilite_p);
          if(isRetourOK(bl200Retour._first))
          {
            _processContext.setListeProvisioning(bl200Retour._second);
          }
          _processContext.setProcessRetour(bl200Retour._first);

        }
      }
    }
    catch (final Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      Retour retourException = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
      _processContext.setProcessRetour(retourException);
    }
    finally
    {
      // Call BL002
      _processContext.setState(State.PE0529_BL002);
      Pair<Retour, ReponseErreur> bl002Result = PE0529_BL002_FormaterReponseModification(_processContext.getProcessRetour(), tracabilite_p);
      _processContext.setBl002Return(bl002Result);

      // Send the response
      syncPutResponse(request_p, bl002Result);

      this.setRetour(bl002Result._first);
      _processContext.setState(State.PE0529_CONTINUE);
    }
  }

  /**
   * Verification de la STI en entrée du processus
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param request_p
   *          {@link Request} Requête d'entrée du processus
   * @return {@link Pair} of {@link Retour} and String idOperationVieReseau
   */
  @LogProcessBL
  private Pair<Retour, String> PE0529_BL001_VerifierDonneesConsultation(Tracabilite tracabilite_p, Request request_p)
  {
    String idOperationVieReseau = null;
    Retour retour = checkHeaders(request_p);

    if (isRetourOK(retour))
    {
      idOperationVieReseau = request_p.getUrlDynamicParameters();

      if (isBlank(idOperationVieReseau))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(IMessage.INVALID_QUERY_PARAMETER, ParameterUrl.idOperationVieReseau.name(), null));
      }
    }

    return new Pair<>(retour, idOperationVieReseau);
  }

  /**
   * Verification de la STI en entrée du processus
   *
   * @param request_p
   *          {@link Request} Requête d'entrée du processus
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Pair} of {@link Retour} and {@link PE0529_PostRequest}
   */
  @LogProcessBL
  private Pair<Retour, PE0529_PostRequest> PE0529_BL001_VerifierDonneesCreation(final Request request_p, final Tracabilite tracabilite_p)
  {
    PE0529_PostRequest creationRequest = null;
    Retour retour = checkHeaders(request_p);

    if (isRetourOK(retour))
    {
      try
      {
        creationRequest = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0529_PostRequest.class);
        retour = checkRequestBody(tracabilite_p, creationRequest);
      }
      catch (Exception e)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, IMessage.INVALID_REQUEST_BODY_FORMAT);
      }
    }

    return new Pair<>(retour, creationRequest);
  }

  /**
   * Verification de la STI en entrée du processus
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param request_p
   *          {@link Request} Requête d'entrée du processus
   * @return {@link Pair} of {@link Retour} and {@link PE0529_PutRequest}
   */
  @LogProcessBL
  private Pair<Retour, PE0529_PutRequest> PE0529_BL001_VerifierDonneesModification(final Tracabilite tracabilite_p, final Request request_p)
  {
    // Check headers
    Retour retour = checkHeaders(request_p);

    if (isRetourNOK(retour))
    {
      return new Pair<>(retour, null);
    }

    retour = loadConfiguration(tracabilite_p);

    if (!RetourFactory.isRetourOK(retour))
    {
      return new Pair<>(retour, null);
    }

    PE0529_PutRequest modificationRequest;

    try
    {
      modificationRequest = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0529_PutRequest.class);

      // Check request body
      retour = checkRequestBody(tracabilite_p, modificationRequest);

      if (isRetourNOK(retour))
      {
        return new Pair<>(retour, null);
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, IMessage.INVALID_REQUEST_BODY_FORMAT), null);
    }

    // Get and check the url parameters
    String idOperationVieReseau = request_p.getUrlDynamicParameters();
    _processContext.setIdOperationVieReseau(idOperationVieReseau);

    if (isBlank(idOperationVieReseau))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(IMessage.INVALID_QUERY_PARAMETER, ParameterUrl.idOperationVieReseau.name(), null)), null);
    }

    return new Pair<>(RetourFactory.createOkRetour(), modificationRequest);
  }

  /**
   *
   * Formatage de la reponse de création
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param retour_p
   *          {@link Retour} à formater
   * @param getResponse_p
   *          Le retour de BL100
   * @return {@link Response}
   */
  @LogProcessBL
  private Pair<Retour, Response> PE0529_BL002_FormaterReponseConsultation(Tracabilite tracabilite_p, Retour retour_p, PE0529_GetResponse getResponse_p)
  {
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ErrorCode httpCode = ErrorCode.OK_00200;

    try
    {
      if (isRetourOK(retour_p))
      {
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(getResponse_p, PE0529_GetResponse.class));
      }
      else
      {
        ReponseErreur reponseErreur = new ReponseErreur();
        reponseErreur.setError(retour_p.getDiagnostic());
        reponseErreur.setErrorDescription(retour_p.getLibelle());
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur, ReponseErreur.class));

        httpCode = getDefaultHttpCodeFromRetour(retour_p);
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      Retour retourException = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
      _processContext.setProcessRetour(retourException);
      httpCode = ErrorCode.KO_00500;
    }

    return new Pair<>(retour_p, new Response(httpCode, ravelResponse));
  }

  /**
   * Formatage de la reponse de création
   *
   * @param retour_p
   *          {@link Retour} à formater
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Response}
   */
  @LogProcessBL
  private Pair<Retour, ReponseErreur> PE0529_BL002_FormaterReponseCreation(final Retour retour_p, @SuppressWarnings("unused") final Tracabilite tracabilite_p)
  {
    ReponseErreur reponseErreur = null;

    if (isRetourNOK(retour_p))
    {
      reponseErreur = new ReponseErreur();
      reponseErreur.setError(retour_p.getDiagnostic());
      reponseErreur.setErrorDescription(retour_p.getLibelle());
    }

    return new Pair<>(retour_p, reponseErreur);
  }

  /**
   * @param retour_p
   *          The retour
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Pair <Retour, ResponseErreur> }
   */
  @LogProcessBL
  private Pair<Retour, ReponseErreur> PE0529_BL002_FormaterReponseModification(final Retour retour_p, @SuppressWarnings("unused") final Tracabilite tracabilite_p)
  {
    ReponseErreur reponseErreur = null;

    if (isRetourNOK(retour_p))
    {
      reponseErreur = new ReponseErreur();
      reponseErreur.setError(retour_p.getDiagnostic());
      reponseErreur.setErrorDescription(retour_p.getLibelle());
    }

    return new Pair<>(retour_p, reponseErreur);
  }

  /**
   * PE0529_BL005_GererErreurPROSPER
   *
   * @param retourIn_p
   *          retour input
   * @param tracabilite_p
   *          tracabilite
   * @return {@link Retour}
   * @throws RavelException
   *           on error.
   */
  @LogProcessBL
  private Retour PE0529_BL005_GererErreurPROSPERModification(final Retour retourIn_p, final Tracabilite tracabilite_p) throws RavelException
  {
    if (isRetourNOK(retourIn_p))
    {
      // Call activite BL4600
      BL4600_CreerErreurSpirit bl4600 = new BL4600_CreerErreurSpirit.BL4600_CreerErreurSpiritBuilder() //
          .tracabilite(tracabilite_p) //
          .retour(retourIn_p) //
          .build();

      bl4600.execute(this);

      return bl4600.getRetour();
    }

    return retourIn_p;
  }

  /**
   * Annulation d'une operation vie reseau
   *
   * @param idOperationVieReseau_p
   *          L'identifiant de la requete
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Retour}
   * @throws RavelException
   *           on error.
   */
  @LogProcessBL
  private Retour PE0529_BL100_AnnulerOperationVDR(final String idOperationVieReseau_p, final Tracabilite tracabilite_p) throws RavelException
  {
    // Lecture de l'opération vie de réseau REX
    ConnectorResponse<Retour, OperationVieReseau> rexLireOVR = REXProxy.getInstance().operationVieReseauLireUn(tracabilite_p, idOperationVieReseau_p);

    if (isRetourNOK(rexLireOVR._first))
    {
      return rexLireOVR._first;
    }

    if (isNull(rexLireOVR._second))
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(IMessage.OPERATION_VIE_RESEAU_INCONNUE, idOperationVieReseau_p));
    }

    // Convert the statut from REX
    OperationVieReseauStatut operationStatut = OperationVieReseauStatut.valueOf(rexLireOVR._second.getStatut());

    // Modification du statut de l'opération en fonction du statut actuel
    ConnectorResponse<Retour, Nothing> rexModifierStatut = null;

    switch (operationStatut)
    {
      case ACQUITTE:
        rexModifierStatut = REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.OBSOLETE.name(), null, null);
        break;

      case EN_COURS_MAJ_REFERENTIEL:
        rexModifierStatut = REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegConsts.TRAITEMENT_ARRETE, IMessage.OPERATION_ANNULEE_MAJ_REFERENTIEL);
        break;

      case EN_COURS_PROVISIONING:
        rexModifierStatut = REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegConsts.TRAITEMENT_ARRETE, IMessage.OPERATION_ANNULEE_PROV_CLIENT);
        break;

      case OBSOLETE:
      case TRAITE_NOK:
      case TRAITE_OK:
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MessageFormat.format(IMessage.OPERATION_ETAT_FINAL, idOperationVieReseau_p, operationStatut.name()));
    }

    if (rexModifierStatut != null)
    {
      return rexModifierStatut._first;
    }

    // Remark: this can never happen, but needed by sonar
    return null;
  }

  /**
   * @param idOperationVieReseau
   *          L'identifiant de la requete
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return oRetour,oOperationVieReseau in JSon format
   * @throws RavelException
   *           on error.
   */
  @LogProcessBL
  private Pair<Retour, PE0529_GetResponse> PE0529_BL100_ConsulterOperationVDR(final String idOperationVieReseau, final Tracabilite tracabilite_p) throws RavelException
  {
    PE0529_GetResponse getResponse = null;

    // Call REX.operationVieReseauLireUn
    ConnectorResponse<Retour, OperationVieReseau> rexResponse = REXProxy.getInstance().operationVieReseauLireUn(tracabilite_p, idOperationVieReseau);
    Retour oRetour = rexResponse._first;

    if (isRetourOK(oRetour))
    {
      OperationVieReseau rexOperationVieReseau = rexResponse._second;

      try
      {
        getResponse = new PE0529_GetResponse( //
            rexOperationVieReseau.getIdOperationVieReseau(), //
            rexOperationVieReseau.getStatut(), //
            rexOperationVieReseau.getDateCreation(), //
            rexOperationVieReseau.getDateAnnulation(), //
            rexOperationVieReseau.getDateExecution(), //
            rexOperationVieReseau.getTypeOperationVieReseau(), //
            rexOperationVieReseau.getIdOperationVieReseauLie(), //
            rexOperationVieReseau.getNumeroGCR() //
        );

        PE0529_PostRequest donneesBrutes = RavelJsonTools.getInstance().fromJson(rexOperationVieReseau.getDonneeBrute(), PE0529_PostRequest.class);
        getResponse.setListeTypeEquipementImpacte(new ArrayList<>(donneesBrutes.getListeTypeEquipementImpacte()));
        getResponse.setMigrationsPortsPm(donneesBrutes.getMigrationsPortsPm());
        getResponse.setModificationsPortsPm(donneesBrutes.getModificationsPortsPm());
        getResponse.setAjoutsPortsPm(donneesBrutes.getAjoutsPortsPm());
        getResponse.setSuppressionsPortsPm(donneesBrutes.getSuppressionsPortsPm());
        getResponse.setModificationsPortsPon(donneesBrutes.getModificationsPortsPon());
        getResponse.setAjoutsPortsPon(donneesBrutes.getAjoutsPortsPon());
        getResponse.setSuppressionsPortsPon(donneesBrutes.getSuppressionsPortsPon());
      }
      catch (Exception e)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
        oRetour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_DONNEE_BRUTE, idOperationVieReseau));
      }
    }

    return new Pair<>(oRetour, getResponse);
  }

  /**
   * Opération de création de la Vie de Réseau
   *
   * @param creationRequest
   *          {@link PE0529_PostRequest} Requête de création
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Pair} du retour {@link Retour} et idOperationVieReseau {@link String}
   * @throws RavelException
   *           on error.
   */
  @LogProcessBL
  private Pair<Retour, String> PE0529_BL100_CreerOperationVDR(final PE0529_PostRequest creationRequest, final Tracabilite tracabilite_p) throws RavelException
  {
    // List of ports pm source that need to be migrated
    Set<PositionPortPm> listePortPmSourceMigres = creationRequest.getListePortPmSourceMigres();

    // Get a set with all of the ports pm that need to be suppressed
    // except for those present as the source for the migrations
    Set<PositionPortPm> listePortPmSupprimesNonMigres = creationRequest.getListePortPmSupprimes();
    listePortPmSupprimesNonMigres.removeAll(listePortPmSourceMigres);

    // Contrôle fonctionnel sur les objets PortPm supprimés
    // Make sure that the ports that need to be suppressed are not allocated
    for (PositionPortPm portPm : listePortPmSupprimesNonMigres)
    {
      String idRessource = portPm.toRessourceId();
      ConnectorResponse<Retour, Ressource> resResponseLirePortPM = RESProxy.getInstance().ressourceLireUn(tracabilite_p, idRessource, TypeRessource.PORT_PM.name());

      if (isRetourOK(resResponseLirePortPM._first))
      {
        RessourcePortPM ressourcePortPM = (RessourcePortPM) resResponseLirePortPM._second;

        if (Statut.ALLOUE.name().equals(ressourcePortPM.getStatut()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MessageFormat.format(IMessage.PORTPM_ALLOUE, portPm.getReferencePmBytel(), portPm.getReferenceBoitierPm(), portPm.getNomPanneau(), portPm.getPositionPort())), null);
        }
      }
    }

    // Contrôle fonctionnel sur les objets PortPm migrés : - chaque portPm Source doit exister dans RES
    // Make sure the ports that need to be migrated exist in RES
    for (PositionPortPm portPm : listePortPmSourceMigres)
    {
      Pair<Retour, PMComposite> pmCompositeResponse = getPMComposite(tracabilite_p, portPm.getReferencePmBytel());

      if (isRetourNOK(pmCompositeResponse._first))
      {
        return new Pair<>(pmCompositeResponse._first, null);
      }

      if (getPortPmFromPmComposite(pmCompositeResponse._second, portPm) == null)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(IMessage.PORTPM_SOURCE_INEXISTANT, portPm.getReferencePmBytel(), portPm.getReferenceBoitierPm(), portPm.getNomPanneau(), portPm.getPositionPort())), null);
      }
    }

    // Liste des ports pm cibles
    Set<PositionPortPm> listePortPmCible = creationRequest.getListePortPmCibleMigres();
    // Liste des ports pm à ajouter
    Set<PositionPortPm> listePortPmAjout = creationRequest.getListePortPmAjoutes();

    // - chaque portPm Cible doit exister dans RES ou dans ajoutsPortsPm
    // Make sure the target ports for the migrations exist either in RES or in the list of ports to be added (ajoutsPortsPm)
    for (PositionPortPm portPm : listePortPmCible)
    {
      // TODO: IT SEEMS LIKE THE PAIR SOURCE AND TARGET ARE ALWAYS FROM THE SAME referencePMBytel, IF THIS IS TRUE, THERE'S NO NEED TO CHECK FOR NOK
      Pair<Retour, PMComposite> pmCompositeResponse = getPMComposite(tracabilite_p, portPm.getReferencePmBytel());

      if (isRetourNOK(pmCompositeResponse._first))
      {
        return new Pair<>(pmCompositeResponse._first, null);
      }

      if (getPortPmFromPmComposite(pmCompositeResponse._second, portPm) == null && !isPositionPortPmInSet(listePortPmAjout, portPm))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(IMessage.PORTPM_CIBLE_INEXISTANT, portPm.getReferencePmBytel(), portPm.getReferenceBoitierPm(), portPm.getNomPanneau(), portPm.getPositionPort())), null);
      }
    }

    // Contrôle des changements de technologiePON dans les migrations des ports Pm
    for (MigrationPortPm migration : creationRequest.getMigrationsPortsPm())
    {
      PositionPortPm posPortPmSrc = migration.getPositionPortPmSource();
      PositionPortPm posPortPmCible = migration.getPositionPortPmCible();

      // Can never be NOK because there's a previous verification
      PMComposite pmComposite = getPMComposite(tracabilite_p, posPortPmSrc.getReferencePmBytel())._second;

      // PortPM can never be null because there's a previous verification
      PortPM portPmSrc = getPortPmFromPmComposite(pmComposite, posPortPmSrc);

      // Get the list of PortPonId associated with each source PortPM
      List<PortPonId> listePortPonSourceId = portPmSrc.getListeLienPortPMPon().values().stream().map(LienPortPMPon::getPortPon).collect(Collectors.toList());

      Set<String> listeTechnoSrc = new HashSet<>();

      // Get all of the technologies available in the source ports being migrated
      for (PortPonId portPonId : listePortPonSourceId)
      {
        Pair<Retour, OltComposite> oltResponse = getOltComposite(tracabilite_p, portPonId.getNomOLT());

        if (isRetourNOK(oltResponse._first))
        {
          return new Pair<>(oltResponse._first, null);
        }

        PortPON portPon = getPortPonFromOltComposite(oltResponse._second, new PositionPortPon(portPonId.getPositionPortPON(), portPonId.getPositionCartePON(), portPonId.getNomOLT()));

        if (nonNull(portPon))
        {
          listeTechnoSrc.addAll(portPon.getSfpListeTechnologieCompatible());
        }
      }

      // TODO: This assumes the same PmComposite - while before it is not assumed
      PortPM portPmCible = getPortPmFromPmComposite(pmComposite, posPortPmCible);

      Set<String> listeTechnoCible = new HashSet<>();

      // Get all of the technologies available in the target ports for the migration
      if (nonNull(portPmCible))
      {
        // Get the list of PortPonId associated with each target PortPM
        List<PortPonId> listePortPonCibleId = portPmCible.getListeLienPortPMPon().values().stream().map(LienPortPMPon::getPortPon).collect(Collectors.toList());

        for (PortPonId portPonId : listePortPonCibleId)
        {
          Pair<Retour, OltComposite> oltResponse = getOltComposite(tracabilite_p, portPonId.getNomOLT());

          if (isRetourNOK(oltResponse._first))
          {
            return new Pair<>(oltResponse._first, null);
          }

          PortPON portPon = getPortPonFromOltComposite(oltResponse._second, new PositionPortPon(portPonId.getPositionPortPON(), portPonId.getPositionCartePON(), portPonId.getNomOLT()));

          if (nonNull(portPon))
          {
            listeTechnoCible.addAll(portPon.getSfpListeTechnologieCompatible());
          }
        }
      }
      // migrationPortPm.positionPortPmCible existe dans ajoutsPortsPm
      else
      {
        // Get the list of PortPonId associated with each target PortPM
        for (LienPortPon lienPortPon : creationRequest.getListeLienPortPonAjouteFromPositionPortPm(posPortPmCible))
        {
          Pair<Retour, OltComposite> oltResponse = getOltComposite(tracabilite_p, lienPortPon.getNomOLT());

          if (isRetourNOK(oltResponse._first))
          {
            return new Pair<>(oltResponse._first, null);
          }

          OltComposite oltComposite = oltResponse._second;

          // Check if the PortPON is in the OltComposite
          PortPON portPon = getPortPonFromOltComposite(oltComposite, lienPortPon.toPositionPortPon());

          if (portPon != null)
          {
            listeTechnoCible.addAll(portPon.getSfpListeTechnologieCompatible());
          }
          // Otherwise it needs to be in the list of added ports Pon (AjoutPortPon)
          else
          {
            AjoutPortPon ajoutPortPon = creationRequest.getAjoutPortPonFromPositionPortPm(lienPortPon);

            if (ajoutPortPon != null)
            {
              listeTechnoCible.addAll(ajoutPortPon.getSfpListeTechnologieCompatible());
            }
            else
            {
              return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(IMessage.LIEN_PORT_PON_INEXISTANT, lienPortPon.getNomOLT(), lienPortPon.getPositionCartePon(), lienPortPon.getPositionPortPon())), null);
            }
          }
        }
      }

      // Make sure all of the technologies available in the source ports are still available in the target ones
      if (!listeTechnoCible.containsAll(listeTechnoSrc))
      {
        String message = MessageFormat.format(IMessage.MODIFICATION_TECHNO_IMPOSSIBLE, posPortPmSrc.getReferencePmBytel(), posPortPmSrc.getReferenceBoitierPm(), posPortPmSrc.getNomPanneau(), posPortPmSrc.getPositionPort());
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, message), null);
      }
    }

    // Contrôle fonctionnel sur les objets PortPm modifiés
    Retour retour = verifyModificationPortPMList(tracabilite_p, creationRequest);

    if (isRetourNOK(retour))
    {
      return new Pair<>(retour, null);
    }

    // Contrôle fonctionnel sur les objets Ports PM ajouté
    retour = verifyAddedPortPMList(tracabilite_p, creationRequest);

    if (isRetourNOK(retour))
    {
      return new Pair<>(retour, null);
    }

    // Contrôle fonctionnel sur les objets PortPon modifiés (modif des caractéristiques SfpTechnologieComptible) :
    retour = verifyModificationPortPONList(tracabilite_p, creationRequest);

    if (isRetourNOK(retour))
    {
      return new Pair<>(retour, null);
    }

    // Contrôle fonctionnel sur les objets PortPon supprimés : Contrôle si les ports PON à supprimer ont des OntId Alloué
    for (SuppressionPortPon suppressionPortPon : creationRequest.getSuppressionsPortsPon())
    {
      PositionPortPon posPortPon = suppressionPortPon.getPositionPortPon();
      Pair<Retour, OltComposite> resResponseLireOlt = getOltComposite(tracabilite_p, posPortPon.getNomOLT());

      if (isRetourNOK(resResponseLireOlt._first))
      {
        return new Pair<>(resResponseLireOlt._first, null);
      }

      OltComposite oltComposite = resResponseLireOlt._second;
      PortPON portPon = getPortPonFromOltComposite(oltComposite, posPortPon);

      if (nonNull(portPon))
      {
        for (OntId ontId : portPon.getListeOntId().values())
        {
          StringJoiner joiner = new StringJoiner("-"); //$NON-NLS-1$
          joiner.add(String.valueOf(posPortPon.getNomOLT()));
          joiner.add(String.valueOf(posPortPon.getPositionCarte()));
          joiner.add(String.valueOf(posPortPon.getPosition()));
          joiner.add(String.valueOf(ontId.getPosition()));
          String idRessource = joiner.toString();
          ConnectorResponse<Retour, Ressource> resLireRessource = RESProxy.getInstance().ressourceLireUn(tracabilite_p, idRessource, TypeRessource.ONT_ID.name());

          if (isRetourNOK(resLireRessource._first))
          {
            if(IMegSpiritConsts.DONNEE_INCONNUE.equals(resLireRessource._first.getDiagnostic()))
            {
              continue;
            }
            else
            {
              return new Pair<>(resLireRessource._first, null);
            }
          }

          if (Statut.ALLOUE.name().equals(resLireRessource._second.getStatut()))
          {
            String message = MessageFormat.format(IMessage.SUPPRESSION_PORT_PON_IMPOSSIBLE_ONTID, posPortPon.getNomOLT(), posPortPon.getPositionCarte(), posPortPon.getPosition(), ontId.getPosition());
            return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, message), null);
          }
        }
      }
    }

    // Construction de l'objet OperationVieReseau (à passer au verbe SAAB créer de REX) à partir des éléments de la STI
    BL800_ObtenirSequence bl800 = new BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder() //
        .tracabilite(tracabilite_p) //
        .code(UniqueIdConstant.ID_OPERATION_VIE_RESEAU) //
        .build();
    String idOperationVieReseau = bl800.execute(this);

    if (isRetourNOK(bl800.getRetour()))
    {
      return new Pair<>(bl800.getRetour(), null);
    }

    // Appel REX.operationVieReseauCreer
    OperationVieReseau operationVieReseau = new OperationVieReseau( //
        idOperationVieReseau, //
        creationRequest.getTypeVieReseau(), //
        OperationVieReseauStatut.ACQUITTE.name(), //
        creationRequest.getDonneesBrutes() //
    );

    operationVieReseau.setNumeroGCR(creationRequest.getNumeroGCR());
    ConnectorResponse<Retour, Nothing> retourRex = REXProxy.getInstance().operationVieReseauCreer(tracabilite_p, operationVieReseau);
    if (isRetourNOK(retourRex._first))
    {
      return new Pair<>(retourRex._first, null);
    }

    ConnectorResponse<Retour, OperationVieReseau> retourRexLireUn = REXProxy.getInstance().operationVieReseauLireUn(tracabilite_p, idOperationVieReseau);
    if (isRetourNOK(retourRexLireUn._first))
    {
      return new Pair<>(retourRexLireUn._first, null);
    }
    operationVieReseau = retourRexLireUn._second;

    Set<String> listePm = creationRequest.getListeReferencesPmBytel();
    Set<String> listeOlt = creationRequest.getListeNomOlt();
    Set<String> listeBoitierPM = creationRequest.getListeBoitierPM();
    List<CleRechercheOperationVieReseau> listeCleRechercheOperationVieReseau = new ArrayList<>();

    for (String referencePmBytel : listePm)
    {
      CleRechercheOperationVieReseau cleRechercheOperationVieReseau = new CleRechercheOperationVieReseau( //
          creationRequest.getTypeVieReseau(), //
          "PM", //$NON-NLS-1$
          referencePmBytel, //
          idOperationVieReseau //
      );
      listeCleRechercheOperationVieReseau.add(cleRechercheOperationVieReseau);
    }

    for (String boitierPM : listeBoitierPM)
    {
      CleRechercheOperationVieReseau cleRechercheOperationVieReseau = new CleRechercheOperationVieReseau( //
          creationRequest.getTypeVieReseau(), //
          "BOITIER", //$NON-NLS-1$
          boitierPM, //
          idOperationVieReseau //
      );
      listeCleRechercheOperationVieReseau.add(cleRechercheOperationVieReseau);
    }

    CleRechercheOperationVieReseau cleRechercheOperationVieReseauDate = new CleRechercheOperationVieReseau( //
        creationRequest.getTypeVieReseau(), //
        "DATE_CREATION", //$NON-NLS-1$
        DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd.format(operationVieReseau.getDateCreation()), //
        idOperationVieReseau //
    );
    listeCleRechercheOperationVieReseau.add(cleRechercheOperationVieReseauDate);

    for (String nomOlt : listeOlt)
    {
      CleRechercheOperationVieReseau cleRechercheOperationVieReseau = new CleRechercheOperationVieReseau( //
          creationRequest.getTypeVieReseau(), //
          "OLT", //$NON-NLS-1$
          nomOlt, //
          idOperationVieReseau //
      );

      listeCleRechercheOperationVieReseau.add(cleRechercheOperationVieReseau);
    }

    // Appel REX.cleRechercheOperationVieReseauCreerListe
    ListeCleRechercheOperationVieReseauRequest listeCle = new ListeCleRechercheOperationVieReseauRequest(listeCleRechercheOperationVieReseau);
    ConnectorResponse<Retour, Nothing> rexResponseCreerListe = REXProxy.getInstance().cleRechercheOperationVieReseauCreerListe(tracabilite_p, listeCle);

    if (isRetourNOK(rexResponseCreerListe._first))
    {
      return new Pair<>(rexResponseCreerListe._first, null);
    }

    return new Pair<>(RetourFactory.createOkRetour(), idOperationVieReseau);
  }

  /**
   * Mise à jour du referentiel d'operation vie reseau
   *
   * @param idOperationVieReseau_p
   *          L'identifiant de la requete
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return Pair de {@link Retour} et liste de {@link ProvisioningVDR}
   * @throws RavelException
   *           on error.
   */
  @LogProcessBL
  private Pair<Retour, List<ProvisioningVDR>> PE0529_BL200_MajReferentiel(final String idOperationVieReseau_p, final Tracabilite tracabilite_p) throws RavelException
  {
    // listePairMigration & listePairModification
    List<ProvisioningVDR> listeProvisioning = new ArrayList<>();

    // Lecture de l'opération vie de réseau REX
    ConnectorResponse<Retour, OperationVieReseau> rexLireOVR = REXProxy.getInstance().operationVieReseauLireUn(tracabilite_p, idOperationVieReseau_p);

    if (isRetourNOK(rexLireOVR._first) || isNull(rexLireOVR._second))
    {
      return new Pair<>((RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(IMessage.OPERATION_VIE_RESEAU_INCONNUE, idOperationVieReseau_p))), listeProvisioning);
    }

    OperationVieReseau operationVieReseau = rexLireOVR._second;
    _processContext.setOperationVieReseau(operationVieReseau);

    // Conditions d'exécution de l'opération : le statut doit etre ACQUITTE
    if (!OperationVieReseauStatut.ACQUITTE.name().equals(operationVieReseau.getStatut()))
    {
      return new Pair<>((RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, IMessage.OPERATION_VIE_RESEAU_NON_ACQUITTE)), listeProvisioning);
    }

    PE0529_PostRequest donneesBrutes = RavelJsonTools.getInstance().fromJson(operationVieReseau.getDonneeBrute(), PE0529_PostRequest.class);
    Set<String> listePmImpactes = donneesBrutes.getListeReferencesPmBytel();
    Set<String> listeOLTImpactes = donneesBrutes.getListeNomOltOperationPortPon();
    String typeVieReseau = donneesBrutes.getTypeVieReseau();

    // Une seule opération doit être exécutée sur un PM donné
    for (String referencePmBytel : listePmImpactes)
    {
      ConnectorResponse<Retour, List<OperationVieReseau>> rexLireTousParCle = //
          REXProxy.getInstance().operationVieReseauCompositeLireTousParCleRecherche(tracabilite_p, typeVieReseau, TypeIdentifiant.PM.name(), referencePmBytel);

      if (isRetourNOK(rexLireTousParCle._first))
      {
        return new Pair<>(rexLireTousParCle._first, listeProvisioning);
      }

      for (OperationVieReseau operation : rexLireTousParCle._second)
      {
        if (OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name().equals(operation.getStatut()) //
            || OperationVieReseauStatut.EN_COURS_PROVISIONING.name().equals(operation.getStatut()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MessageFormat.format(IMessage.EXECUTION_IMPOSSIBLE_SUR, operation.getIdOperationVieReseau(), "PM")), listeProvisioning); //$NON-NLS-1$
        }
      }
    }

    // Une seule opération doit être exécutée sur un OLT donnée
    for (String nomOlt : listeOLTImpactes)
    {
      ConnectorResponse<Retour, List<OperationVieReseau>> rexLireTousParCle = //
          REXProxy.getInstance().operationVieReseauCompositeLireTousParCleRecherche(tracabilite_p, typeVieReseau, TypeIdentifiant.OLT.name(), nomOlt);

      if (isRetourNOK(rexLireTousParCle._first))
      {
        return  new Pair<>(rexLireTousParCle._first, listeProvisioning);
      }

      for (OperationVieReseau operation : rexLireTousParCle._second)
      {
        if (OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name().equals(operation.getStatut()) //
            || OperationVieReseauStatut.EN_COURS_PROVISIONING.name().equals(operation.getStatut()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MessageFormat.format(IMessage.EXECUTION_IMPOSSIBLE_SUR, operation.getIdOperationVieReseau(), "OLT")), listeProvisioning); //$NON-NLS-1$
        }
      }
    }

    // Modification de statut pour commencer la mise à jour référentiel
    ConnectorResponse<Retour, Nothing> rexModifierStatut = REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name(), null, null);

    if (isRetourNOK(rexModifierStatut._first))
    {
      return new Pair<>(rexModifierStatut._first, listeProvisioning);
    }

    // Mise à jour Référentiel RES : PMComposite
    for (String referencePmBytel : listePmImpactes)
    {
      Pair<Retour, PMComposite> resLirePm = getPMComposite(tracabilite_p, referencePmBytel);

      if (isRetourNOK(resLirePm._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_LECTURE, "PMComposite", referencePmBytel)); //$NON-NLS-1$

        return new Pair<>(resLirePm._first, listeProvisioning);
      }

      // Remove this entry from cache to force the update from RES
      _processContext._cachePMComposite.remove(referencePmBytel);

      PMComposite pmComposite = resLirePm._second;

      // Construction du PMComposite à partir des changements VDR
      Pair<Retour, List<ProvisioningVDR>> retourUpdatePm = updatePmComposite(pmComposite, idOperationVieReseau_p, donneesBrutes, tracabilite_p);

      if(isRetourNOK(retourUpdatePm._first))
      {
        return new Pair<>(retourUpdatePm._first, listeProvisioning);
      }
      if(!CollectionUtils.isEmpty(retourUpdatePm._second))
      {
        listeProvisioning.addAll(retourUpdatePm._second);
      }

      ConnectorResponse<Retour, Nothing> resGererImportPm = RESProxy.getInstance().pmCompositeGererImport(tracabilite_p, pmComposite, VIE_DE_RESEAU);

      if (isRetourNOK(resGererImportPm._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_IMPORT, "PMComposite", referencePmBytel)); //$NON-NLS-1$

        return new Pair<>(resGererImportPm._first, listeProvisioning);
      }

      for (MigrationPortPm migrationPortPm : donneesBrutes.getMigrationsPortsPm())
      {
        PositionPortPm posPortPmSrc = migrationPortPm.getPositionPortPmSource();
        PositionPortPm posPortPmCible = migrationPortPm.getPositionPortPmCible();
        String idRessource = posPortPmSrc.toRessourceId();

        // Recupération de l'objet provisioning associé à la migration
        Optional<ProvisioningVDRMigration> optProv = listeProvisioning.stream() //
                                                                  .filter(p -> p instanceof ProvisioningVDRMigration) //
                                                                  .map(p -> (ProvisioningVDRMigration) p) //
                                                                  .filter(p -> p.getSource().equals(posPortPmSrc) && p.getCible().equals(posPortPmCible)).findFirst();
        if(optProv.isPresent())
        {
          ProvisioningVDR provisioningVDR = optProv.get();

          ConnectorResponse<Retour, RessourcePortPM> resGererMigration = RESProxy.getInstance().ressourcePortPmGererMigrationPortPm( //
              tracabilite_p, //
              idRessource, //
              PHYSIQUE, //
              posPortPmCible.getReferencePmBytel(), //
              null, //
              posPortPmCible.getReferenceBoitierPm(), //
              null, //
              posPortPmCible.getNomPanneau(), //
              posPortPmCible.getPositionPort(), //
              null, //
              provisioningVDR.getRessourcePortPM().getIdRessourceLie() //
          );

          if (isRetourNOK(resGererMigration._first))
          {
            String errorMsg = resGererMigration._first.getLibelle();
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, errorMsg));

            if(!ClientImpacteStatutProvisionning.EN_COURS.name().equals(provisioningVDR.getClientImpacte().getStatutProvisioning()))
            {
              provisioningVDR.getClientImpacte().setStatutProvisioning(ClientImpacteStatutProvisionning.NOK.name());
              provisioningVDR.getClientImpacte().setErreurProvisioning(MessageFormat.format(IMessage.ERREUR_MIGRATION_PORT_PM, errorMsg));
            }
          }
        }
      }

      // traitement des ports Pm dans suppressionPortPm
      boolean deletedPort = false;

      for (PositionPortPm posPortPm : donneesBrutes.getListePortPmSupprimes())
      {
        if (posPortPm.getReferencePmBytel().equals(referencePmBytel))
        {
          PortPM portPm = getPortPmFromPmComposite(pmComposite, posPortPm);

          if (nonNull(portPm))
          {
            portPm.setStatutTechnique(StatutTechniquePM.SUPPRIME.name());
            deletedPort = true;
          }
        }
      }

      if(deletedPort)
      {
        resGererImportPm = RESProxy.getInstance().pmCompositeGererImport(tracabilite_p, pmComposite, VIE_DE_RESEAU);

        if (isRetourNOK(resGererImportPm._first))
        {
          REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_IMPORT, "PMComposite", referencePmBytel)); //$NON-NLS-1$

          return new Pair<>(resGererImportPm._first, listeProvisioning);
        }
      }
    }

    // Suppression des clientImpactes temporaires au statut EN_COURS
    listeProvisioning = listeProvisioning.stream()
                                         .filter(p -> !ClientImpacteStatutProvisionning.EN_COURS.name().equals(p.getClientImpacte().getStatutProvisioning())) //
                                         .collect(Collectors.toList()); //

    // Ecriture listeClientImpacte dans REX
    Set<ClientImpacte> clientsImpactes = listeProvisioning.stream() //
                                                          .map(ProvisioningVDR::getClientImpacte) //
                                                          .collect(Collectors.toSet()); //
    if(!clientsImpactes.isEmpty())
    {
      ConnectorResponse<Retour, Nothing> rexModifierListeClientImpacte = REXProxy.getInstance().operationVieReseauModifierListeClientImpacte( //
          tracabilite_p, //
          idOperationVieReseau_p, //
          clientsImpactes//
      );

      if (isRetourNOK(rexModifierListeClientImpacte._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut( //
            tracabilite_p, //
            idOperationVieReseau_p,
            OperationVieReseauStatut.TRAITE_NOK.name(),
            IMegSpiritConsts.TRAITEMENT_ARRETE, PE0529_OperationVieReseau.IMessage.ERREUR_MODIFIER_LISTE
        );

        return new Pair<>(rexModifierListeClientImpacte._first, listeProvisioning);
      }
    }


    // Mise à jour Référentiel RES : OLTComposite
    for (String nomOlt : listeOLTImpactes)
    {
      Pair<Retour, OltComposite> resLireOlt = getOltComposite(tracabilite_p, nomOlt);

      if (isRetourNOK(resLireOlt._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_LECTURE, "OLTComposite", nomOlt)); //$NON-NLS-1$

        return new Pair<>(resLireOlt._first, listeProvisioning);
      }

      OltComposite oltComposite = resLireOlt._second;

      // Construction de OLTComposite en à partir des changements demandés dans VDR
      updateOltComposite(oltComposite, donneesBrutes, nomOlt);

      ConnectorResponse<Retour, Nothing> resGererImportOlt = RESProxy.getInstance().oltCompositeGererImport(tracabilite_p, oltComposite);

      if (isRetourNOK(resGererImportOlt._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_IMPORT, "OLTComposite", nomOlt)); //$NON-NLS-1$

        return new Pair<>(resGererImportOlt._first, listeProvisioning);
      }
    }

    // Mise en quarantaine l'Import sur les PM impactés
    for (String referencePmBytel : listePmImpactes)
    {
      ConnectorResponse<Retour, Nothing> resModifierQuarantainePm = RESProxy.getInstance().pmCompositeModifierSurchargeDateDebutQuarantainePM(tracabilite_p, referencePmBytel);

      if (isRetourNOK(resModifierQuarantainePm._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_MODIFIER_QUARANTAINE, "PM")); //$NON-NLS-1$

        return new Pair<>(resModifierQuarantainePm._first, listeProvisioning);
      }
    }

    // Mise en quarantaine l'Import sur les OLT impactés
    for (String nomOlt : listeOLTImpactes)
    {
      ConnectorResponse<Retour, Nothing> resModifierQuarantaineOlt = RESProxy.getInstance().oltCompositemodifierSurchargeDateDebutQuarantaineOLT(tracabilite_p, null, nomOlt);

      if (isRetourNOK(resModifierQuarantaineOlt._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_MODIFIER_QUARANTAINE, "OLT")); //$NON-NLS-1$

        return new Pair<>(resModifierQuarantaineOlt._first, listeProvisioning);
      }
    }

    // vérification et changement du statut de l'opération
    ConnectorResponse<Retour, OperationVieReseau> rexLireVDR = REXProxy.getInstance().operationVieReseauLireUn(tracabilite_p, idOperationVieReseau_p);

    if (isRetourNOK(rexLireVDR._first))
    {
      REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(IMessage.ERREUR_LECTURE, "OperationVieReseau", idOperationVieReseau_p)); //$NON-NLS-1$

      return new Pair<>(rexLireVDR._first, listeProvisioning);
    }

    if (OperationVieReseauStatut.TRAITE_NOK.name().equals(rexLireVDR._second.getStatut()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, IMessage.OPERATION_ANNULEE_TRAITEMENT_TOPO), listeProvisioning);
    }

    return new Pair<>(RetourFactory.createOkRetour(), listeProvisioning);
  }

  /**
   * Opération de provisionning
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param idOperationVieReseau_p
   *          Identifiant de l'Operation Vie Reseau
   * @return {@link Retour}
   * @throws RavelException
   *           on error.
   */
  @LogProcessBL
  private Retour PE0529_BL400_Provisioning(final Tracabilite tracabilite_p, final String idOperationVieReseau_p) throws RavelException
  {
    // Condition d'exécution de provisioning
    ConnectorResponse<Retour, OperationVieReseau> rexLireOVR = REXProxy.getInstance().operationVieReseauLireUn(tracabilite_p, idOperationVieReseau_p);

    if (isRetourNOK(rexLireOVR._first))
    {
      REXProxy.getInstance().operationVieReseauModifierStatut( //
          tracabilite_p, //
          idOperationVieReseau_p, //
          OperationVieReseauStatut.TRAITE_NOK.name(), //
          IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(PE0529_OperationVieReseau.IMessage.ERREUR_LECTURE, "OperationVieReseau", idOperationVieReseau_p) //$NON-NLS-1$
      );

      return rexLireOVR._first;
    }

    OperationVieReseau operationVieReseau = rexLireOVR._second;

    // Check the statut
    OperationVieReseauStatut statutOperation = OperationVieReseauStatut.valueOf(operationVieReseau.getStatut());

    if (OperationVieReseauStatut.TRAITE_NOK.equals(statutOperation))
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, PE0529_OperationVieReseau.IMessage.OPERATION_ANNULEE_TRAITEMENT_TOPO);
    }

    if (!OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.equals(statutOperation))
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, PE0529_OperationVieReseau.IMessage.ERREUR_STATUT);
    }

    // Controle du lancer du provisioning et changement de statut de l'opération
    ConnectorResponse<Retour, Nothing> rexModifierStatutOperation = REXProxy.getInstance().operationVieReseauModifierStatut( //
        tracabilite_p, //
        idOperationVieReseau_p, //
        OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), //
        null, null //
    );

    if (isRetourNOK(rexModifierStatutOperation._first))
    {
      REXProxy.getInstance().operationVieReseauModifierStatut( //
          tracabilite_p, //
          idOperationVieReseau_p, //
          OperationVieReseauStatut.TRAITE_NOK.name(), //
          IMegSpiritConsts.TRAITEMENT_ARRETE, PE0529_OperationVieReseau.IMessage.ERREUR_MODIFIER_STATUT //
      );

      return rexModifierStatutOperation._first;
    }

    // Provisioning des Ports Pm modifiés dans migrationsPortsPm et dans modificationPortsPm
    for(ProvisioningVDR provisioningVDR : _processContext.getListeProvisioning().stream().filter(ProvisioningVDR::isNotNOK).collect(Collectors.toSet()))
    {
      rexLireOVR = REXProxy.getInstance().operationVieReseauLireUn(tracabilite_p, idOperationVieReseau_p);

      if (isRetourNOK(rexLireOVR._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut( //
            tracabilite_p, //
            idOperationVieReseau_p, //
            OperationVieReseauStatut.TRAITE_NOK.name(), //
            IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(PE0529_OperationVieReseau.IMessage.ERREUR_LECTURE, "OperationVieReseau", idOperationVieReseau_p) //$NON-NLS-1$
        );

        return rexLireOVR._first;
      }

      OperationVieReseau operationVieReseauClient = rexLireOVR._second;
      OperationVieReseauStatut statutOperationClient = OperationVieReseauStatut.valueOf(operationVieReseauClient.getStatut());

      // - Verification que l'operation a bien été mise au statut EN_COURS_PROVISIONNING
      if (!OperationVieReseauStatut.EN_COURS_PROVISIONING.equals(statutOperationClient))
      {
        rexModifierStatutOperation = REXProxy.getInstance().operationVieReseauModifierStatut( //
            tracabilite_p, //
            idOperationVieReseau_p, //
            OperationVieReseauStatut.TRAITE_NOK.name(), //
            IMegSpiritConsts.TRAITEMENT_ARRETE, PE0529_OperationVieReseau.IMessage.OPERATION_ANNULEE //
        );

        return rexModifierStatutOperation._first;
      }

      //  - Récupération de noCompte et de clientOperateur de AIR à partir de idRaccordement (=identifiantClient)
      ConnectorResponse<Retour, List<IndexRecherchePfi>> airIndexLire = AIRProxy.getInstance().indexRechercherPfiLireTousParCleRecherche( //
          tracabilite_p, //
          ID_RACCORDEMENT, //
          provisioningVDR.getClientImpacte().getIdentifiantClient() //
      );

      if (isRetourNOK(airIndexLire._first))
      {
        String erreurProv = MessageFormat.format(PE0529_OperationVieReseau.IMessage.NOCLIENT_NON_TROUVE, provisioningVDR.getIdPortImpacte());
        provisioningVDR.getClientImpacte().setStatutProvisioning(ClientImpacteStatutProvisionning.NOK.name());
        provisioningVDR.getClientImpacte().setErreurProvisioning(erreurProv);
      }
      else
      {
        for (IndexRecherchePfi index : airIndexLire._second)
        {
          ConnectorResponse<Retour, PFI> rpgLirePfi = RPGProxy.getInstance().pfiLireUn(tracabilite_p, index.getClientOperateur(), index.getNoCompte());

          if (isRetourOK(rpgLirePfi._first) && nonNull(rpgLirePfi._second))
          {
            // - Recherche Point d'acces de type VOIP ou FAX a l'etat ACTIF
            PFIFilter statutPFI = new PFIFilter(PFIFilterOption.STATUT, com.bytel.spirit.common.shared.saab.rpg.Statut.ACTIF.name());
            PFIFilter typePA = new PFIFilter(PFIFilterOption.TYPE_PA, TypePA.FAX.name(), TypePA.VOIP.name());
            List<PA> listpaFiltered = PFIUtils.filterPA(rpgLirePfi._second.getPa(), statutPFI, typePA);

            if (!CollectionUtils.isEmpty(listpaFiltered))
            {
              provisioningVDR.setClientOperateur(index.getClientOperateur());
              provisioningVDR.setNoCompte(index.getNoCompte());
              break;
            }
          }
        }
      }

      if(!provisioningVDR.noCompteExists())
      {
        if(isBlank(provisioningVDR.getClientImpacte().getStatutProvisioning()))
        {
          provisioningVDR.getClientImpacte().setStatutProvisioning(ClientImpacteStatutProvisionning.NOK.name());
          provisioningVDR.getClientImpacte().setErreurProvisioning(IMessage.NOCOMPTE_INCONNU);
        }
        continue; // Client suivant
      }

      if(_processContext.getConfigurationPE0529().isLissageDeCharge())
      {
        BL850_ObtenirTicket bl850 = new BL850_ObtenirTicket.BL850_ObtenirTicketBuilder().tracabilite(tracabilite_p).type(LISSAGE_CHARGE_VDR).build();
        bl850.execute(this);
        if(isRetourOK(bl850.getRetour()))
        {
          provisioningVDR.setTicketLissage(true);
        }
      }

      // Creation et execution d'une action Corrective via processus SPIRIT PEI0229_CommandeActionCorrective
      Pair<Retour, String> retourPei0229Post = callStarkConnectorPEI0229Post(tracabilite_p, provisioningVDR.getNoCompte(), provisioningVDR.getClientOperateur(), provisioningVDR.getListeCleSequencement());

      if (isRetourNOK(retourPei0229Post._first))
      {
        String errorMsg = retourPei0229Post._first.getLibelle();
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, errorMsg));
        provisioningVDR.getClientImpacte().setStatutProvisioning(ClientImpacteStatutProvisionning.NOK.name());
        provisioningVDR.getClientImpacte().setErreurProvisioning(MessageFormat.format(IMessage.ERREUR_ACTION_CORRECTIVE, "POST", errorMsg));  //$NON-NLS-1$
      }
      else
      {
        Retour retourPei0229Put = callStarkConnectorPEI0229Put(tracabilite_p, retourPei0229Post._second);

        if (isRetourNOK(retourPei0229Put))
        {
          String errorMsg = retourPei0229Put.getLibelle();
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, retourPei0229Put.getLibelle()));
          provisioningVDR.getClientImpacte().setStatutProvisioning(ClientImpacteStatutProvisionning.NOK.name());
          provisioningVDR.getClientImpacte().setErreurProvisioning(MessageFormat.format(IMessage.ERREUR_ACTION_CORRECTIVE, "PUT", errorMsg));  //$NON-NLS-1$
        }
        else
        {
          // Recupération de l'idActionCorrective et assignation dans le client impacté
          String idActionCorrective = retourPei0229Post._second.replace(PE0529_OperationVieReseau.IStarkURI.PEI0229, ""); //$NON-NLS-1$
          provisioningVDR.getClientImpacte().setIdCommande(idActionCorrective);
        }
      }

      if(_processContext.getConfigurationPE0529().isLissageDeCharge() && provisioningVDR.hasTicketLissage())
      {
        BL851_LibererTicket bl851 = new BL851_LibererTicket.BL851_LibererTicketBuilder().tracabilite(tracabilite_p).type(LISSAGE_CHARGE_VDR).build();
        bl851.execute(this);
      }
    }

    // Mise à jour des clients impactés par l'operation
    operationVieReseau.setListeClientImpacte(_processContext.getListeProvisioning().stream().map(ProvisioningVDR::getClientImpacte).collect(Collectors.toSet()));
    if(!operationVieReseau.getListeClientImpacte().isEmpty())
    {
      ConnectorResponse<Retour, Nothing> rexModifierListeClientImpacte = REXProxy.getInstance().operationVieReseauModifierListeClientImpacte( //
          tracabilite_p,  //
          idOperationVieReseau_p, //
          operationVieReseau.getListeClientImpacte() //
      );

      if (isRetourNOK(rexModifierListeClientImpacte._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, PE0529_OperationVieReseau.IMessage.ERREUR_MODIFIER_LISTE);

        return rexModifierListeClientImpacte._first;
      }
    }

    // Repetition consultation provisionning client tant que tous ne sont pas traité
    boolean repeterConsultation = operationVieReseau.getListeClientImpacte().stream().anyMatch(impactClient -> !ClientImpacteStatutProvisionning.NOK.name().equals(impactClient.getStatutProvisioning()));

    if(repeterConsultation)
    {
      while (repeterConsultation)
      {
        for (ClientImpacte clientImpacte : operationVieReseau.getListeClientImpacte())
        {
          String statutProvisionning;

          if (!isBlank(clientImpacte.getIdCommande()))
          {
            Pair<Retour, Suivi> retourPei0229Get = callStarkConnectorPEI0229Get(tracabilite_p, clientImpacte.getIdCommande());

            if (isRetourNOK(retourPei0229Get._first))
            {
              String errorMsg =  retourPei0229Get._first.getLibelle();
              RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, errorMsg));
              clientImpacte.setErreurProvisioning(MessageFormat.format(IMessage.ERREUR_ACTION_CORRECTIVE, "GET", errorMsg));  //$NON-NLS-1$
              statutProvisionning = ClientImpacteStatutProvisionning.NOK.name();
            }
            else
            {
              statutProvisionning = mappingStatutProvisionning(retourPei0229Get._second.getStatut());

              if (ClientImpacteStatutProvisionning.NOK.name().equals(statutProvisionning))
              {
                clientImpacte.setErreurProvisioning(retourPei0229Get._second.getLibelleErreur());
              }
            }
          }
          else
          {
            statutProvisionning = ClientImpacteStatutProvisionning.NOK.name();
          }

          clientImpacte.setStatutProvisioning(statutProvisionning);
        }

        repeterConsultation = operationVieReseau.getListeClientImpacte().stream().anyMatch(impactClient -> ClientImpacteStatutProvisionning.EN_COURS.name().equals(impactClient.getStatutProvisioning()));
      }

      // - Mise à jour des clients impactés par l'operation
      ConnectorResponse<Retour, Nothing> rexModifierListeClientImpacte = REXProxy.getInstance().operationVieReseauModifierListeClientImpacte( //
          tracabilite_p,  //
          idOperationVieReseau_p, //
          operationVieReseau.getListeClientImpacte() //
      );

      if (isRetourNOK(rexModifierListeClientImpacte._first))
      {
        REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.TRAITEMENT_ARRETE, PE0529_OperationVieReseau.IMessage.ERREUR_MODIFIER_LISTE);

        return rexModifierListeClientImpacte._first;
      }
    }

    // Modification du statut de l'operation en fonction du statut des provisionning client
    if (operationVieReseau.getListeClientImpacte().stream().allMatch(impactClient -> ClientImpacteStatutProvisionning.TRAITE_OK.name().equals(impactClient.getStatutProvisioning())))
    {
      rexModifierStatutOperation = REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_OK.name(), null, null);

      return rexModifierStatutOperation._first;
    }
    else
    {
      rexModifierStatutOperation = REXProxy.getInstance().operationVieReseauModifierStatut(tracabilite_p, idOperationVieReseau_p, OperationVieReseauStatut.TRAITE_NOK.name(), IMegSpiritConsts.COMMANDE_TRAITEE_NOK, PE0529_OperationVieReseau.IMessage.PROVISIONNING_NOK);

      return rexModifierStatutOperation._first;
    }
  }
}