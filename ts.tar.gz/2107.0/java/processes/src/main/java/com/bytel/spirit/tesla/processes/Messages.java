/*******************************************************************************
* $Id: Messages.java 20553 2019-04-19 07:44:48Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author jsantos
 * @version ($Revision: 20553 $ $Date: 2019-04-19 09:44:48 +0200 (ven. 19 avril 2019) $)
 */
public class Messages
{
  /**
   * the internal BUNDLE_NAME.
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.tesla.processes.messages"; //$NON-NLS-1$

  /**
   * the internal RESOURCE_BUNDLE.
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(Messages.BUNDLE_NAME);

  /**
   * Get the string value.
   *
   * @param key
   *          the key
   * @return the value
   */
  public static String getString(String key)
  {
    try
    {
      return Messages.RESOURCE_BUNDLE.getString(key);
    }
    catch (MissingResourceException e)
    {
      return '!' + key + '!';
    }
  }

  /**
   * default constructor
   */
  private Messages()
  {
    // Nothing to do
  }
}