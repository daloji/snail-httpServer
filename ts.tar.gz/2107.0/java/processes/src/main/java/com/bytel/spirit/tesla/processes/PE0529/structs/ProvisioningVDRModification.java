/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0529.structs;

import java.util.Objects;
import java.util.StringJoiner;

import com.bytel.spirit.common.shared.saab.rex.ClientImpacte;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPm;

/**
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class ProvisioningVDRModification extends ProvisioningVDR
{

  /**
   * Position port PM modifie
   */
  private PositionPortPm _port;

  /**
   * Constructeur
   *
   * @param clientImpacte_p
   *     the clientImpacte to set
   * @param port_p
   *     the positionPortPm to set
   */
  public ProvisioningVDRModification(ClientImpacte clientImpacte_p, PositionPortPm port_p)
  {
    super(clientImpacte_p);
    _port = port_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    if (!super.equals(o_p))
    {
      return false;
    }
    ProvisioningVDRModification that = (ProvisioningVDRModification) o_p;
    return Objects.equals(_port, that._port);
  }

  @Override
  public String getIdPortImpacte()
  {
    StringJoiner joiner = new StringJoiner("/");
    joiner.add(_port.getReferencePmBytel());
    joiner.add(_port.getReferenceBoitierPm());
    joiner.add(_port.getNomPanneau());
    joiner.add(String.valueOf(_port.getPositionPort()));
    return joiner.toString();
  }

  /**
   * @return value of _port.
   */
  public PositionPortPm getPort()
  {
    return _port;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(super.hashCode(), _port);
  }

  /**
   * @param port_p
   *     the _port to set.
   */
  public void setPort(PositionPortPm port_p)
  {
    _port = port_p;
  }

  @Override
  public String toString()
  {
    return "ProvisioningVDRModification [" + "_clientImpacte=" + _clientImpacte + ", _listeCleSequencement=" + _listeCleSequencement + ", _noCompte=" + _noCompte + ", _clientOperateur=" + _clientOperateur + ", _ressourcePortPM=" + _ressourcePortPM + ", _ticketLissage=" + _ticketLissage + ", _port=" + _port + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$ // $NON-NLS-6$ // $NON-NLS-7$ // $NON-NLS-8$ // $NON-NLS-9$
  }
}
