/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0033.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.squareup.moshi.Json;

/**
 *
 * @author rdavid
 * @version ($Revision$ $Date$)
 */
public class PE0033_Request implements Serializable
{
  /**
   * SV UID
   */
  private static final long serialVersionUID = 6658927237574202520L;

  /**
   * ClientOperateur.
   */
  @Json(name = "clientOperateur")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Size(min = 1, max = 20, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private String _clientOperateur;

  /**
   * NoCOmpte.
   */
  @Json(name = "noCompte")
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Size(min = 1, max = 20, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private String _noCompte;

  /**
   * ListeCleSequencement
   */
  @Json(name = "listeCleSequencement")
  private List<String> _listeCleSequencement;

  /**
   *
   */
  public PE0033_Request()
  {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @param clientOperateur_p
   *          clientOperateur
   * @param noCompte_p
   *          noCompte
   */
  public PE0033_Request(String clientOperateur_p, String noCompte_p)
  {
    super();
    _clientOperateur = clientOperateur_p;
    _noCompte = noCompte_p;
  }

  /**
   * @param clientOperateur_p
   *          clientOperateur
   * @param noCompte_p
   *          noCompte
   * @param listeCleSequencement_p
   *          listeCleSequencement
   */
  public PE0033_Request(String clientOperateur_p, String noCompte_p, List<String> listeCleSequencement_p)
  {
    _clientOperateur = clientOperateur_p;
    _noCompte = noCompte_p;
    _listeCleSequencement = listeCleSequencement_p == null ? null : new ArrayList<>(listeCleSequencement_p);
  }

  /**
   * Add a cleSequencement to listeCleSequencement
   *
   * @param cleSequencement_p
   *          the cleSequencement to add
   */
  public void addCleSequencement(String cleSequencement_p)
  {
    if(_listeCleSequencement == null)
    {
      _listeCleSequencement = new ArrayList<>();
    }
    _listeCleSequencement.add(cleSequencement_p);
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    PE0033_Request that = (PE0033_Request) o_p;
    return Objects.equals(_clientOperateur, that._clientOperateur) && Objects.equals(_noCompte, that._noCompte) && Objects.equals(_listeCleSequencement, that._listeCleSequencement);
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return value of _listeCleSequencement.
   */
  public List<String> getListeCleSequencement()
  {
    return _listeCleSequencement == null ? null : new ArrayList<>(_listeCleSequencement);
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_clientOperateur, _noCompte, _listeCleSequencement);
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param listeCleSequencement_p
   *     the _listeCleSequencement to set.
   */
  public void setListeCleSequencement(List<String> listeCleSequencement_p)
  {
    _listeCleSequencement = listeCleSequencement_p == null ? null : new ArrayList<>(listeCleSequencement_p);
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  @Override
  public String toString()
  {
    return "STIRequestObject [" + "_clientOperateur=" + _clientOperateur + ", _noCompte=" + _noCompte + ", _listeCleSequencement=" + _listeCleSequencement + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$
  }
}
