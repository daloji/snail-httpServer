/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PI0344;

import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI037_LireNrmDescReseau;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI037_LireNrmDescReseau.OSSFAI_SI037_LireNrmDescReseauBuilder;
import com.bytel.spirit.common.connectors.nrm.structs.NRMDescReseauRetour;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.StatutTechniqueOlt;
import com.bytel.spirit.tesla.processes.Messages;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_RecupererDetailProvisioningPONCarte;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_RecupererDetailProvisioningPONDonneesSpecifiques;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_RecupererDetailProvisioningPONOlt;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_RecupererDetailProvisioningPONSti;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_Retour;
import com.bytel.spirit.tesla.processes.PI0344.sti.PI0344_Retour.ReponseFonctionnelle;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PI0344_RecupererDetailProvisioningPON extends SpiritProcessSkeleton
{
  /**
   *
   * The enum to input Parameters Url
   *
   * @author mbaptist
   * @version ($Revision$ $Date$)
   */
  public enum ParameterUrl
  {
    /**
     * Nom de l'OLT
     */
    nomOlt,

    /**
     * Position de la carte PON
     */
    positionCartePON,

  }

  /**
   * Process context
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public static final class PI0344_RecupererDetailProvisioningPONContext extends Context
  {
    /**
     * Serial UID
     */
    private static final long serialVersionUID = 2034462906739834221L;

    /**
     * recupererDetailProvisioningPonSti
     */
    private PI0344_RecupererDetailProvisioningPONSti _recupererDetailProvisioningPonSti;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PI0344_START;

    /**
     * Object {@code Retour} du processus
     */
    private Retour _processRetour;

    /**
     * @return value of _processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the recupererDetailProvisioningPonSti
     */
    public PI0344_RecupererDetailProvisioningPONSti getRecupererDetailProvisioningPonSti()
    {
      return _recupererDetailProvisioningPonSti;
    }

    /**
     * @return value of _state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param processRetour_p
     *          The _processRetour to set.
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param recupererDetailProvisioningPonSti_p
     *          the recupererDetailProvisioningPonSti to set
     */
    public void setRecupererDetailProvisioningPonSti(PI0344_RecupererDetailProvisioningPONSti recupererDetailProvisioningPonSti_p)
    {
      _recupererDetailProvisioningPonSti = recupererDetailProvisioningPonSti_p;
    }

    /**
     * @param state_p
     *          The _state to set.
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }
  }

  /**
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PI0344_START(MandatoryProcessState.PRC_START),
    /**
     * PI Step to call BL001
     */
    PI0344_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * PI Step to call BL002
     */
    PI0344_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * PI Step to call BL005
     */
    PI0344_BL005(MandatoryProcessState.PRC_RUNNING),
    /**
     * PI Step to call BL100
     */
    PI0344_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PI0344_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }

  }

  /**
   * The constant for emptyBody message
   */
  private static final String MESSAGE_EMPTY_BODY = Messages.getString("PE0341.emptyBody"); //$NON-NLS-1$

  /**
   * Serial UID
   */
  private static final long serialVersionUID = -5416815396682633389L;

  /**
   * The constant for PI0344_RecupererDetailProvisioningPON.UnexpectedContinueProcessReceived message
   */
  private static final String MESSAGE_UNEXPECTED_CONTINUE_PROCESS_RECEIVED = Messages.getString("PI0344_RecupererDetailProvisioningPON.UnexpectedContinueProcessReceived"); //$NON-NLS-1$
  /**
   * OPERATIONAL
   */
  private static final String OPERATIONAL = "OPERATIONAL"; //$NON-NLS-1$

  /**
   * The process context.
   */
  private PI0344_RecupererDetailProvisioningPONContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PI0344_RecupererDetailProvisioningPONContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, MESSAGE_UNEXPECTED_CONTINUE_PROCESS_RECEIVED);
  }

  @Override
  protected void exitKOMetroLog(String s_p)
  {
    // Not required for now in Ravel
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();

    PI0344_Retour pi0344_Retour = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour));

    try
    {
      _processContext.setState(State.PI0344_BL001);
      retour = PI0344_BL001_VerifierDonnees(tracabilite_p, request_p);

      pi0344_Retour = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour));

      if (RetourFactory.isRetourOK(retour))
      {
        _processContext.setState(State.PI0344_BL100);
        pi0344_Retour = PI0344_BL100_Traitement(tracabilite_p, _processContext._recupererDetailProvisioningPonSti.getNomOlt(), _processContext._recupererDetailProvisioningPonSti.getPositionCartePON());
      }
    }
    catch (Exception ex)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
      pi0344_Retour = new PI0344_Retour(RetourConverter.convertToJsonRetour(retour));
    }
    finally
    {
      _processContext.setState(State.PI0344_BL002);
      pi0344_Retour = PI0344_BL002_FormaterReponse(tracabilite_p, pi0344_Retour);

      syncResponse(request_p, pi0344_Retour);

      // end of startProcess
      _processContext.setState(State.PI0344_BL005);
      retour = PI0344_BL005_GererErreurPROSPER(tracabilite_p, retour);

      _processContext.setState(State.PI0344_END);
      this.setRetour(retour);
    }
  }

  /**
   * Check the request parameters
   *
   * @param request_p
   *          request
   * @return {@link Retour}
   *
   * @throws RavelException
   *           In case of an error
   */
  private Retour checkRequestParameters(final Request request_p) throws RavelException
  {
    // Get body parameters
    _processContext._recupererDetailProvisioningPonSti = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PI0344_RecupererDetailProvisioningPONSti.class);

    // Check the body parameters
    if (_processContext._recupererDetailProvisioningPonSti == null)
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MESSAGE_EMPTY_BODY);
    }

    if (StringTools.isNullOrEmpty(_processContext._recupererDetailProvisioningPonSti.getNomOlt()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0344.BL001.ParameterNullOrEmpty"), ParameterUrl.nomOlt.name())); //$NON-NLS-1$
    }

    if (null == _processContext._recupererDetailProvisioningPonSti.getPositionCartePON())
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0344.BL001.ParameterNullOrEmpty"), ParameterUrl.positionCartePON.name())); //$NON-NLS-1$
    }

    if (_processContext._recupererDetailProvisioningPonSti.getPositionCartePON() < 0)
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0344.BL001.InvalidFieldValue"), ParameterUrl.positionCartePON.name())); //$NON-NLS-1$
    }

    return RetourFactory.createOkRetour();
  }

  /**
   *
   * @param tracabilite_p
   *          The trace
   * @param request_p
   *          The request
   * @return {@link Retour}
   *
   * @throws RavelException
   *           on errors
   */
  @LogProcessBL
  private Retour PI0344_BL001_VerifierDonnees(Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    try
    {
      return checkRequestParameters(request_p);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PI0344.BL001.StiError") + "\\n" + ExceptionTools.getStringStackTrace(e))); //$NON-NLS-1$ //$NON-NLS-2$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PI0344.BL001.StiError")); //$NON-NLS-1$
    }
  }

  /**
   * * Response formatter add erreur to response if the previous BLs sends an error, if not create a response ok.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param pi0344Retour_p
   *          PI0344_Retour
   * @return {@link PI0344_Retour}
   */
  @LogProcessBL
  private PI0344_Retour PI0344_BL002_FormaterReponse(Tracabilite tracabilite_p, PI0344_Retour pi0344Retour_p)
  {
    if (!isRetourOK(RetourConverter.convertFromJsonRetour(pi0344Retour_p.getRetour())))
    {
      ReponseFonctionnelle reponse = new ReponseFonctionnelle(null, null, null, tracabilite_p, null);
      pi0344Retour_p.setReponseFonctionnelle(reponse);
    }

    return pi0344Retour_p;
  }

  /**
   * @param tracabilite_p
   *          The tracability
   * @param retour_p
   *          The retour to handle
   * @return {@link Retour}
   * @throws RavelException
   *           Exception thrown if something fails
   */
  @LogProcessBL
  private Retour PI0344_BL005_GererErreurPROSPER(Tracabilite tracabilite_p, Retour retour_p) throws RavelException
  {
    return RetourFactory.createOkRetour();
  }

  /**
   * Creates a new PFIComplet object from RPG,CMD and RST referential.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param nomOlt_p
   *          Nom de l'OLT
   * @param positionCartePON_p
   *          Position de la carte PON
   * @return Pair of types Retour,PFIComplet
   * @throws RavelException
   *           Throws RavelException if thrown by one of the connectors.
   */
  @LogProcessBL
  private PI0344_Retour PI0344_BL100_Traitement(Tracabilite tracabilite_p, String nomOlt_p, Integer positionCartePON_p) throws RavelException
  {
    // Call activity OSSFAI_SI037_LireNrmDescReseau
    OSSFAI_SI037_LireNrmDescReseau si037 = new OSSFAI_SI037_LireNrmDescReseauBuilder() //
        .tracabilite(tracabilite_p) //
        .nomOlt(nomOlt_p) //
        .carte(positionCartePON_p) //
        .build();
    NRMDescReseauRetour si037Retour = si037.execute(this);

    if (RetourFactory.isRetourNOK(si037.getRetour()))
    {
      return new PI0344_Retour(RetourConverter.convertToJsonRetour(si037.getRetour()));
    }

    // Build Olt
    PI0344_RecupererDetailProvisioningPONOlt olt = new PI0344_RecupererDetailProvisioningPONOlt(nomOlt_p, //
        si037Retour.getNomNR(), //
        si037Retour.getConstructeur(), //
        si037Retour.getModele(), //
        si037Retour.getVersionInterfaceEchange(), //
        OPERATIONAL.equals(si037Retour.getStatutTechniqueOlt()) ? StatutTechniqueOlt.OPERATIONNEL.name() : StatutTechniqueOlt.SUPPRIME.name(), //
        si037Retour.getNomOmc());
    olt.setDateDernierImport(LocalDateTime.now());

    // Build Carte
    PI0344_RecupererDetailProvisioningPONCarte carte = new PI0344_RecupererDetailProvisioningPONCarte(positionCartePON_p, //
        "CartePON", //$NON-NLS-1$
        OPERATIONAL.equals(si037Retour.getStatutTechniqueCarte()) ? StatutTechniqueOlt.OPERATIONNEL.name() : StatutTechniqueOlt.SUPPRIME.name()); //

    // Build DonneesSpecifiquest
    PI0344_RecupererDetailProvisioningPONDonneesSpecifiques donneesSpecifiquesP2P = new PI0344_RecupererDetailProvisioningPONDonneesSpecifiques();

    // Calcul du statut technique aggrégé
    String statutTechnique = StatutTechniqueOlt.OPERATIONNEL.name();

    if (!olt.getStatutTechnique().equals(StatutTechniqueOlt.OPERATIONNEL.name()))
    {
      statutTechnique = olt.getStatutTechnique();
    }
    else if (!carte.getStatutTechnique().equals(StatutTechniqueOlt.OPERATIONNEL.name()))
    {
      statutTechnique = carte.getStatutTechnique();
    }

    // Build ReponseFonctionnelle
    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle(olt, carte, donneesSpecifiquesP2P, null, statutTechnique);

    return new PI0344_Retour(RetourConverter.convertToJsonRetour(RetourFactory.createOkRetour()), reponseFonctionnelle);
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param pi0344Retour_p
   *          the PI0344_Retour
   * @throws RavelException
   *           In case of error
   */
  private void syncResponse(Request request_p, PI0344_Retour pi0344Retour_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ErrorCode errorCode = ErrorCode.KO_00503;

      if (pi0344Retour_p != null)
      {
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pi0344Retour_p, PI0344_Retour.class));

        Retour retour = RetourConverter.convertFromJsonRetour(pi0344Retour_p.getRetour());

        if (isRetourOK(retour))
        {
          errorCode = ErrorCode.OK_00200;
        }
        else
        {
          //mapping of error code
          switch (retour.getCategorie())
          {
            case IMegConsts.CAT1:
            case IMegConsts.CAT2:
              errorCode = ErrorCode.KO_00503;
              break;
            case IMegConsts.CAT3:
              errorCode = ErrorCode.KO_00400;
              break;
            case IMegConsts.CAT4:
              errorCode = ErrorCode.KO_00404;
              break;
            case IMegConsts.CAT6:
            case IMegConsts.CAT10:
              errorCode = ErrorCode.KO_00500;
              break;
          }
        }
      }

      request_p.setResponse(new Response(errorCode, ravelResponse));
    }
  }

}
