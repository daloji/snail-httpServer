/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0033;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringJoiner;
import java.util.TreeMap;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5110_ExecuterActionCorrective;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechnique;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.AbstractStPfs;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.tesla.processes.Messages;
import com.bytel.spirit.tesla.processes.PE0033.sti.PE0033_Request;
import com.bytel.spirit.tesla.processes.PE0033.structs.PE0033_BL001Return;

/**
 *
 * @author rdavid
 * @version ($Revision$ $Date$)
 */
public class PE0033_ReconciliationInterne extends SpiritProcessSkeleton
{

  /**
   *
   * The enum to input Parameters Url
   *
   * @author mbaptist
   * @version ($Revision$ $Date$)
   */
  public enum ParameterUrl
  {
    /**
     * param portee
     */
    portee
  }

  /**
   * @author rrosa
   * @version ($Revision$ $Date$)
   */
  public enum PorteeType
  {
    /**
     * ESSAYER_REPROV
     */
    ESSAYER_REPROV,
    /**
     * FORCER_REPROV
     */
    FORCER_REPROV,
    /**
     * SIMPLE
     */
    SIMPLE
  }

  /**
  *
  *
  */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0033_START(MandatoryProcessState.PRC_START),
    /**
     * BL001
     */
    PE0033_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * BL002
     */
    PE0033_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * BL005
     */
    PE0033_BL005(MandatoryProcessState.PRC_RUNNING),

    /**
     * BL100
     */
    PE0033_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PE0033_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    private MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    private Boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    private Boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * @return the asynchronousState
     */
    public final Boolean getAsynchronousState()
    {
      return _asynchronousState;
    }

    /**
     * @return the replayableState
     */
    public final Boolean getReplayableState()
    {
      return _replayableState;
    }

    /**
     * @return the technicalState
     */
    public final MandatoryProcessState getTechnicalState()
    {
      return _technicalState;
    }

    /**
     * @param asynchronousState_p
     *          the asynchronousState to set
     */
    protected final void setAsynchronousState(final Boolean asynchronousState_p)
    {
      _asynchronousState = asynchronousState_p;
    }

    /**
     * @param replayableState_p
     *          the replayableState to set
     */
    protected final void setReplayableState(final Boolean replayableState_p)
    {
      _replayableState = replayableState_p;
    }

    /**
     * @param technicalState_p
     *          the technicalState to set
     */
    protected final void setTechnicalState(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
    }
  }

  /**
   *
   * @author jiantila
   * @version ($Revision: 22040 $ $Date: 2019-05-28 17:54:49 +0200 (mar. 28 mai 2019) $)
   */
  public static final class PE0033_ReconciliationInterneContext extends Context
  {
    /**
     * Serial Version UID.<br/>
     */
    private static final long serialVersionUID = -1760830627803352010L;

    /**
     * Object state
     */
    private State _state = State.PE0033_START;

    /**
     * The Source.<br/>
     */
    private String _source;

    /**
     * The Process.<br/>
     */
    private String _process;

    /**
     * The Client Operateur.<br/>
     */
    private String _clientOperateur;

    /**
     * The Numero de Compte.<br/>
     */
    private String _noCompte;

    /**
     * path config commande
     */
    private String _pathConfigCommande;

    /**
     * The Portee.<br/>
     */
    private String _portee;

    /**
     * The liste Cle Sequencement
     */
    private List<String> _listeCleSequencement;

    /**
     * @return the clientOperateur
     */
    public String getClientOperateur()
    {
      return _clientOperateur;
    }

    /**
     * @return value of _listeCleSequencement.
     */
    public List<String> getListeCleSequencement()
    {
      return _listeCleSequencement == null ? null : new ArrayList<>(_listeCleSequencement);
    }

    /**
     * @return the noCompte
     */
    public String getNoCompte()
    {
      return _noCompte;
    }

    /**
     * @return the pathConfigCommande
     */
    public String getPathConfigCommande()
    {
      return _pathConfigCommande;
    }

    /**
     * @return the portee
     */
    public String getPortee()
    {
      return _portee;
    }

    /**
     * @return the process
     */
    public String getProcess()
    {
      return _process;
    }

    /**
     * @return the source
     */
    public String getSource()
    {
      return _source;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param clientOperateur_p
     *          the clientOperateur to set
     */
    public void setClientOperateur(String clientOperateur_p)
    {
      _clientOperateur = clientOperateur_p;
    }

    /**
     * @param listeCleSequencement_p
     *     the _listeCleSequencement to set.
     */
    public void setListeCleSequencement(List<String> listeCleSequencement_p)
    {
      _listeCleSequencement = listeCleSequencement_p == null ? null : new ArrayList<>(listeCleSequencement_p);
    }

    /**
     * @param noCompte_p
     *          the noCompte to set
     */
    public void setNoCompte(String noCompte_p)
    {
      _noCompte = noCompte_p;
    }

    /**
     * @param pathConfigCommande_p
     *          the pathConfigCommande to set
     */
    public void setPathConfigCommande(String pathConfigCommande_p)
    {
      _pathConfigCommande = pathConfigCommande_p;
    }

    /**
     * @param portee_p
     *          the portee to set
     */
    public void setPortee(String portee_p)
    {
      _portee = portee_p;
    }

    /**
     * @param process_p
     *          the process to set
     */
    public void setProcess(String process_p)
    {
      _process = process_p;
    }

    /**
     * @param source_p
     *          the source to set
     */
    public void setSource(String source_p)
    {
      _source = source_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }
  }

  /**
   * String for Map noCPT.<br/>
   */
  private static final String NO_CPT = "noCpt"; //$NON-NLS-1$

  /**
   * String for Map cliOpe.<br/>
   */
  private static final String CLI_OPE = "cliOpe"; //$NON-NLS-1$

  /**
   * String for Map portee.<br/>
   */
  private static final String PORTEE = "portee"; //$NON-NLS-1$

  /**
   * Headers Manquant.<br/>
   */
  private static final String HEADERS_MANQUANT = Messages.getString("PE0033.HeaderObligatoireManquant"); //$NON-NLS-1$

  /**
   * Request Body Object Empty.<br/>
   */
  private static final String BODY_EMPTY = Messages.getString("PE0033.RequestObjectEmpty"); //$NON-NLS-1$

  /**
   * Numero Compte est Inconnu.<br/>
   */
  private static final String NUMERO_COMPTE_INCONNU = Messages.getString("PE0033.NumeroCompteInconnu"); //$NON-NLS-1$

  /**
   * Serial Version UID.<br/>
   */
  private static final long serialVersionUID = -7517350947779712190L;

  /**
   * FICHIER_CONFIGURATION param
   */
  private static final String FICHIER_CONFIGURATION = "fichierConfiguration"; //$NON-NLS-1$

  /**
   * Process context.<br/>
   */
  private PE0033_ReconciliationInterneContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(final Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState().getTechnicalState();
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0033_ReconciliationInterneContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState().getAsynchronousState();
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState().getReplayableState();
  }

  @Override
  protected void continueProcess(Request arg0_p, Tracabilite arg1_p) throws RavelException
  {
    // TODO Auto-generated method stub

  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    //nothing to do

  }

  @Override
  protected void startMetroLog()
  {
    //nothing to do

  }

  @LogStartProcess
  @Override
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();

    try
    {
      _processContext.setPathConfigCommande(getConfigParameter(FICHIER_CONFIGURATION));
      // Call BL001
      _processContext.setState(State.PE0033_BL001);
      PE0033_BL001Return bl001Return = PE0033_BL001_VerifierDonnees(tracabilite_p, request_p);
      retour = bl001Return.getRetour();

      if (isRetourOK(retour))
      {
        // Call BL100
        _processContext.setState(State.PE0033_BL100);
        retour = PE0033_BL100_Traitement(bl001Return.getTracabilite(), bl001Return.getClientOperateur(), bl001Return.getNoCompte());
      }
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage());
    }
    finally
    {
      // Call BL002
      _processContext.setState(State.PE0033_BL002);
      Pair<Retour, Response> bl002Response = PE0033_BL002_FormaterReponse(tracabilite_p, retour);
      setRetour(bl002Response._first);
      request_p.setResponse(bl002Response._second);

      // Call BL005
      _processContext.setState(State.PE0033_BL005);
      PE0033_BL005_GererErreurPROSPER(tracabilite_p, retour); //retour BL005 is ignored

      // Set End State
      _processContext.setState(State.PE0033_END);
    }
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param request_p
   *          request
   * @return PE0033_BL001Return
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private PE0033_BL001Return PE0033_BL001_VerifierDonnees(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    // Validate headers
    Retour retour = checkAndExtractHeaders(request_p);
    if (RetourFactory.isRetourNOK(retour))
    {
      return new PE0033_BL001Return(retour, null, null, tracabilite_p);
    }

    retour = checkRequestParameters(request_p);
    if (RetourFactory.isRetourNOK(retour))
    {
      return new PE0033_BL001Return(retour, null, null, tracabilite_p);
    }

    // Validate payload
    Pair<Retour, PE0033_Request> pe0033Request = extractAndCheckPayload(tracabilite_p, request_p);
    PE0033_Request stiRequestObject = pe0033Request._second;
    retour = pe0033Request._first;
    if (RetourFactory.isRetourNOK(retour))
    {
      return new PE0033_BL001Return(retour, null, null, tracabilite_p);
    }
    _processContext.setClientOperateur(stiRequestObject.getClientOperateur());
    _processContext.setNoCompte(stiRequestObject.getNoCompte());
    _processContext.setListeCleSequencement(stiRequestObject.getListeCleSequencement());

    // Enrich tracability
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(CLI_OPE, _processContext.getClientOperateur());
    refFonc.put(NO_CPT, _processContext.getNoCompte());
    refFonc.put(PORTEE, _processContext.getPortee());

    // Call BL1700
    BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
    bl1700.execute(this);

    // Call RPG PFI lireUn
    ConnectorResponse<Retour, PFI> pfiLireUnResponse = RPGProxy.getInstance().pfiLireUn(tracabilite_p, _processContext.getClientOperateur(), _processContext.getNoCompte());
    retour = pfiLireUnResponse._first;

    if (RetourFactory.isRetourNOK(retour) && IMegConsts.CAT4.equals(retour.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(retour.getDiagnostic()))
    {
      retour.setDiagnostic(IMegSpiritConsts.NUMERO_COMPTE_INCONNU);
      retour.setLibelle(MessageFormat.format(NUMERO_COMPTE_INCONNU, _processContext.getNoCompte(), _processContext.getClientOperateur()));
    }

    return new PE0033_BL001Return(retour, _processContext.getClientOperateur(), _processContext.getNoCompte(), _processContext.getListeCleSequencement(), tracabilite_p);
  }

  /**
   * Cette activité vérifie le retour et error code.<br>
   * Mise en forme de la réponse <br />
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite} for log purposes
   * @param retour_p
   *          The retour of previous BLs
   * @return The response {@Code PE0332_BL002_Return}
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  private Pair<Retour, Response> PE0033_BL002_FormaterReponse(Tracabilite tracabilite_p, final Retour retour_p) throws RavelException
  {
    // Build response
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ravelResponse.setResult(RavelJsonTools.getInstance().toJson(new BasicResponse(RetourConverter.convertToJsonRetour(retour_p)), BasicResponse.class));

    ErrorCode httpCode;
    if (isRetourOK(retour_p))
    {
      httpCode = ErrorCode.OK_00200;
    }
    else
    {
      switch (retour_p.getDiagnostic())
      {
        case IMegSpiritConsts.NON_RESPECT_STI:
          httpCode = ErrorCode.KO_00400;
          break;
        case IMegSpiritConsts.NUMERO_COMPTE_INCONNU:
          httpCode = ErrorCode.KO_00404;
          break;
        case IMegSpiritConsts.TRAITEMENT_ARRETE:
          httpCode = ErrorCode.KO_00500;
          break;
        default:
          httpCode = ErrorCode.KO_00503;
          break;
      }
    }
    return new Pair<>(retour_p, new Response(httpCode, ravelResponse));
  }

  /**
   * Cette activité permet de créer une alerte à l'exploitant pour analyse et demande de reprise.
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param retour_p
   *          The retour of previous BLs
   * @return The response {@Code Retour}
   * @throws RavelException
   *           If something goes wrong, should not be thrown
   */
  @LogProcessBL
  private Retour PE0033_BL005_GererErreurPROSPER(Tracabilite tracabilite_p, final Retour retour_p) throws RavelException
  {
    return retour_p;
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param clientOperateur_p
   *          clientOperateur
   * @param noCompte_p
   *          noCompte
   * @return Retour
   * @throws RavelException
   *           on error
   *
   */
  @LogProcessBL
  private Retour PE0033_BL100_Traitement(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    ActionCorrective actionCorrective = new ActionCorrective(clientOperateur_p, noCompte_p);
    actionCorrective.setListeCleSequencement(_processContext.getListeCleSequencement());
    List<ActionServiceTechnique> listActionSt = new ArrayList<>();

    if (!PorteeType.SIMPLE.name().equals(_processContext.getPortee()))
    {
      ConnectorResponse<Retour, List<ServiceTechnique>> stLireTousResponse = RSTProxy.getInstance().serviceTechniqueLireTousParPfi(tracabilite_p, clientOperateur_p, noCompte_p, null, null);
      if (!isRetourOK(stLireTousResponse._first) && !IMegConsts.DONNEE_INCONNUE.equals(stLireTousResponse._first.getDiagnostic()))
      {
        //technical error
        return stLireTousResponse._first;
      }

      if (isRetourOK(stLireTousResponse._first))
      {
        for (ServiceTechnique st : stLireTousResponse._second)
        {
          if (Statut.ECHEC.name().equals(st.getStatut()))
          {
            ActionServiceTechnique actionSt = new ActionServiceTechnique();
            actionSt.setTypeAction("MODIFICATION"); //$NON-NLS-1$
            actionSt.setIdSt(st.getIdSt());
            actionSt.setTypeServiceTechnique(st.getTypeServiceTechnique());
            actionSt.setDateModification(st.getDateModification());

            if (TypeST.PFS.name().equals(st.getTypeServiceTechnique()))
            {
              String typePfs = ((AbstractStPfs) st).getTypePfs();
              actionSt.setTypePfs(typePfs);
            }

            if (PorteeType.ESSAYER_REPROV.name().equals(_processContext.getPortee()))
            {
              actionSt.setStatut(Statut.INDETERMINE.name());
            }
            else if (PorteeType.FORCER_REPROV.name().equals(_processContext.getPortee()))
            {
              actionSt.setStatut(Statut.INACTIF.name());
            }
            listActionSt.add(actionSt);
          }
        }
      }
    }

    actionCorrective.setActionsServicesTechniques((listActionSt.isEmpty() ? null : listActionSt));
    // Call BL5100
    BL5100_CreerActionCorrective bl5100 = new BL5100_CreerActionCorrective.BL5100_CreerActionCorrectiveBuilder()//
        .tracabilite(tracabilite_p)//
        .idExterne(tracabilite_p.getIdCorrelationSpirit())//
        .actionCorrective(actionCorrective).build();
    String idActionCorrective = bl5100.execute(this);
    Retour retourBL5100 = bl5100.getRetour();
    if (RetourFactory.isRetourNOK(retourBL5100))
    {
      return retourBL5100;
    }

    // Call BL5110
    BL5110_ExecuterActionCorrective bl5110 = new BL5110_ExecuterActionCorrective.BL5110_ExecuterActionCorrectiveBuilder()//
        .tracabilite(tracabilite_p)//
        .configPath(_processContext.getPathConfigCommande())//
        .idActionCorrective(idActionCorrective)//
        .ttl(Duration.ofSeconds(getTtl()))//
        .build();
    bl5110.execute(this);
    return bl5110.getRetour();
  }

  /**
   * @param request_p
   *          request
   * @return Retour
   */
  private Retour checkAndExtractHeaders(Request request_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    String process = null;
    String source = null;

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        source = header.getValue();
      }
      else if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        process = header.getValue();
      }
    }

    if (StringTools.containsOneNullOrEmpty(source, process))
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$

      if (StringTools.isNullOrEmpty(source))
      {
        joiner.add(IHttpHeadersConsts.X_SOURCE);
      }

      if (StringTools.isNullOrEmpty(process))
      {
        joiner.add(IHttpHeadersConsts.X_PROCESS);
      }

      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(HEADERS_MANQUANT, joiner.toString()));

    }
    else
    {
      _processContext.setSource(source);
      _processContext.setProcess(process);
    }

    return retour;
  }

  /**
   * Check the request parameters
   *
   * @param request_p
   *          request
   * @return {@link Retour}
   */
  private Retour checkRequestParameters(final Request request_p)
  {
    List<Parameter> urlParameters = request_p.getUrlParameters().getUrlParameters();
    String portee = null;

    for (Parameter parametre : urlParameters)
    {
      if (parametre.getName().equals(ParameterUrl.portee.name()))
      {
        portee = parametre.getValue();
      }
    }

    if ((portee != null) && !PorteeType.ESSAYER_REPROV.name().equals(portee) && !PorteeType.FORCER_REPROV.name().equals(portee))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0033.InvalidFieldValue"), ParameterUrl.portee.name())); //$NON-NLS-1$
    }

    if (portee == null)
    {
      portee = PorteeType.SIMPLE.name();
    }
    _processContext.setPortee(portee);

    return RetourFactory.createOkRetour();
  }

  /**
   * @param request_p
   *          request
   * @return Pair<Retour, STIRequestObject>
   * @throws RavelException
   *           on error
   */
  private Pair<Retour, PE0033_Request> extractAndCheckPayload(Tracabilite tracabilite_p, Request request_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();

    // Get payload
    PE0033_Request pe0033Request = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0033_Request.class);

    if (pe0033Request == null)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, BODY_EMPTY), null);
    }

    // Validate payload
    ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
    Validator validator = factory.getValidator();
    Set<ConstraintViolation<PE0033_Request>> constraintViolations = validator.validate(pe0033Request); //validate request with hibernate validation framework
    factory.close();

    if (!constraintViolations.isEmpty())
    {
      Map<String, List<String>> validationMessages = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);//stores validation messages grouped by its type (format, required, conditional,etc..)

      StringBuilder requiredAttrSb = new StringBuilder();
      StringBuilder formatErrAttrSb = new StringBuilder();

      for (ConstraintViolation<PE0033_Request> c : constraintViolations)
      {
        List<String> messageList = validationMessages.get(c.getMessage()); //get the the list of fields with the error stored in the key
        if (messageList == null)
        {
          validationMessages.put(c.getMessage(), new ArrayList<>(Arrays.asList(c.getPropertyPath().toString()))); //stores the validation error type as key and all the fields with the same error in a list as value
        }
        else
        {
          messageList.add(c.getPropertyPath().toString()); //add a new field name to the list
        }
      }

      //Formats the output validation message, concatenating all the errors found
      for (Entry<String, List<String>> validationEntry : validationMessages.entrySet())
      {
        if (IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT.equals(validationEntry.getKey()))
        {
          if (requiredAttrSb.length() > 0)
          {
            requiredAttrSb.append(' ');
          }
          Collections.sort(validationMessages.get(validationEntry.getKey())); //sort alphabetic
          requiredAttrSb.append(validationEntry.getValue());
        }
        if (IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE.equals(validationEntry.getKey()))
        {
          if (formatErrAttrSb.length() > 0)
          {
            formatErrAttrSb.append(' ');
          }
          Collections.sort(validationMessages.get(validationEntry.getKey())); //sort alphabetic
          formatErrAttrSb.append(validationEntry.getValue());
        }
      }

      StringBuilder validationMessageSb = new StringBuilder();

      if (StringTools.isNotNullOrEmpty(requiredAttrSb.toString()))
      {
        validationMessageSb.append(MessageFormat.format(Messages.getString("Validation.RequiredField"), requiredAttrSb.toString())); //$NON-NLS-1$
      }
      if (StringTools.isNotNullOrEmpty(formatErrAttrSb.toString()))
      {
        validationMessageSb.append(MessageFormat.format(Messages.getString("Validation.InvalidFieldFormat"), formatErrAttrSb.toString())); //$NON-NLS-1$
      }

      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, validationMessageSb.toString()));
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, validationMessageSb.toString());
    }

    return new Pair<>(retour, pe0033Request);
  }
}
