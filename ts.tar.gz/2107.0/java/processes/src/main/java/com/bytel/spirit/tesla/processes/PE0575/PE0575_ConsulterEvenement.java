/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0575;

import static java.util.Objects.isNull;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.sega.SEGA_SI148_NotifierDemandePROV;
import com.bytel.spirit.common.activities.sega.SEGA_SI148_NotifierDemandePROV.SEGA_SI148_NotifierDemandePROVBuilder;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.processes.Messages;
import com.bytel.spirit.tesla.processes.PE0575.structs.EvenementFinProv;
import com.bytel.spirit.tesla.processes.PE0575.structs.Notification;
import org.apache.commons.lang3.StringUtils;

/**
 *
 * @author root
 * @version ($Revision$ $Date$)
 */
public class PE0575_ConsulterEvenement extends SpiritProcessSkeleton
{

  /**
   *
   * @author jiantila
   * @version ($Revision$ $Date$)
   */
  private enum State
  {

    /**
     * The first step to execute.
     */
    PI0575_START(MandatoryProcessState.PRC_START),

    /**
     * Step to call BL001
     */
    PI0575_BL001(MandatoryProcessState.PRC_RUNNING),

    /**
     * Step to call BL100
     */
    PI0575_BL100(MandatoryProcessState.PRC_RUNNING),

    /**
     * Step to call BL002
     */
    PI0575_BL002(MandatoryProcessState.PRC_RUNNING),

    /**
     * Step to call BL005
     */
    PI0575_BL005(MandatoryProcessState.PRC_RUNNING),

    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP);
    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Default constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    private State(MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   *
   * @author jiantila
   * @version ($Revision$ $Date$)
   */
  static class PE0575_ConsulterEvenementContext extends Context
  {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * state
     */
    State _state = State.PI0575_START;

    /**
     * notification
     */
    Notification _notification;

    /**
     * evenenemnt fin prov
     */
    EvenementFinProv _evenementfinProv;

    /**
     *
     */
    Retour _retour;

    /**
     * @return the evenementfinProv
     */
    public EvenementFinProv getEvenementfinProv()
    {
      return _evenementfinProv;
    }

    /**
     * @return the notification
     */
    public Notification getNotification()
    {
      return _notification;
    }

    /**
     * @return the retour
     */
    public Retour getRetour()
    {
      return _retour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param evenementfinProv_p
     *          the evenementfinProv to set
     */
    public void setEvenementfinProv(EvenementFinProv evenementfinProv_p)
    {
      _evenementfinProv = evenementfinProv_p;
    }

    /**
     * @param notification_p
     *          the notification to set
     */
    public void setNotification(Notification notification_p)
    {
      _notification = notification_p;
    }

    /**
     * @param retour_p
     *          the retour to set
     */
    public void setRetour(Retour retour_p)
    {
      _retour = retour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

  }

  /**
   * The constant for emptyBody message
   */
  private static final String ID_CMD = "idCmd"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ID_EXTERNE = "idExterne"; //$NON-NLS-1$

  /**
   *
   */
  private static final String DATE_TRAITEMENT = "dateTraitement"; //$NON-NLS-1$

  /**
   *
   */
  private static final String NATURE_COMMANDE = "natureCommande"; //$NON-NLS-1$

  /**
   *
   */
  private static final String STATUT = "statut"; //$NON-NLS-1$

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * list Nature Commande
   */
  private static final List<String> LIST_NATURECOMMANDE = Arrays.asList("CREATION_PFI", "MODIFICATION_PFI", "SUPPRESSION_PFI"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$

  /**
   * list Statut EvementFinProv
   */
  private static final List<String> LIST_STATUT = Arrays.asList("TRAITE_OK", "TRAITE_NOK", "OBSOLETE"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$

  /**
   *
   */
  private static final String TRAITE_NOK = "TRAITE_NOK"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ECHEC_NOTIF = "ECHEC_NOTIF"; //$NON-NLS-1$

  /**
   * The process context
   */
  private PE0575_ConsulterEvenementContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour arg0_p) throws RavelException
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public String getInternalState()
  {
    return _processContext._state.toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofSeconds(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext._state._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0575_ConsulterEvenementContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext._state._asynchronousState;

  }

  @Override
  public boolean isReplayable()
  {
    return _processContext._state._replayableState;
  }

  @Override
  protected void continueProcess(Request arg0_p, Tracabilite arg1_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, Messages.getString("PI0575.UnexpectedContinueProcessReceived")); //$NON-NLS-1$

  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    //NOP

  }

  @Override
  protected void startMetroLog()
  {
    //NOP
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    try
    {
      _processContext.setState(State.PI0575_BL001);
      retour = PI0575_BL001_GET_VerifierDonnees(tracabilite_p, request_p);
      _processContext.setRetour(retour);
      if (isRetourOK(retour))
      {
        _processContext.setState(State.PI0575_BL100);
        Pair<Notification, Retour> bl100 = PI0575_BL100_RecupererNotification(tracabilite_p, _processContext.getEvenementfinProv());
        retour = bl100._second;
        _processContext.setRetour(retour);

      }
    }
    catch (Exception exception)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      _processContext.setRetour(retour);
    }
    finally
    {
      _processContext.setState(State.PI0575_BL002);
      ReponseErreur responseErreur = PI0575_BL002_GET_FormaterReponse(tracabilite_p, _processContext.getRetour());
      retour = PI0575_BL005_GererErreurPROSPER(tracabilite_p, _processContext.getRetour());
      syncResponse(tracabilite_p, request_p, responseErreur, _processContext.getRetour());
      setRetour(_processContext.getRetour());
      _processContext.setState(State.ENDED);
    }

  }

  /**
   * verification Notification
   *
   * @param evenementFin_p
   *          evenementFinProv
   *
   *
   * @return Retour
   */
  private Retour checkEvenementFinProv(EvenementFinProv evenementFin_p)
  {
    String message = null;
    if (isNull(evenementFin_p))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PI0575.emptyBody")); //$NON-NLS-1$
    }
    if (StringUtils.isEmpty(evenementFin_p.getIdCmd()))
    {
      message = MessageFormat.format(Messages.getString("PI0575.BL001.ParameterNullOrEmpty"), ID_CMD); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, message);

    }
    if (StringUtils.isEmpty(evenementFin_p.getIdExterne()))
    {
      message = MessageFormat.format(Messages.getString("PI0575.BL001.ParameterNullOrEmpty"), ID_EXTERNE); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, message);

    }
    if (isNull(evenementFin_p.getDateTraitement()))
    {
      message = MessageFormat.format(Messages.getString("PI0575.BL001.ParameterNullOrEmpty"), DATE_TRAITEMENT); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, message);
    }
    if (StringUtils.isEmpty(evenementFin_p.getNatureCommande()))
    {
      message = MessageFormat.format(Messages.getString("PI0575.BL001.ParameterNullOrEmpty"), NATURE_COMMANDE); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, message);

    }
    if (!LIST_NATURECOMMANDE.contains(evenementFin_p.getNatureCommande()))
    {
      message = Messages.getString("PI0575.BL001.ErroNatureCommande"); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, message);
    }

    if (StringUtils.isEmpty(evenementFin_p.getStatut()))
    {
      message = MessageFormat.format(Messages.getString("PI0575.BL001.ParameterNullOrEmpty"), STATUT); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, message);
    }

    if (!LIST_STATUT.contains(evenementFin_p.getStatut()))
    {
      message = Messages.getString("PI0575.BL001.ErroStatut"); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, message);
    }
    if (TRAITE_NOK.equals(evenementFin_p.getStatut()) && StringUtils.isEmpty(evenementFin_p.getRaisonErreur()))
    {
      message = Messages.getString("PI0575.BL001.errorRaison"); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, message);
    }
    if (!TRAITE_NOK.equals(evenementFin_p.getStatut()) && StringUtils.isNotEmpty(evenementFin_p.getRaisonErreur()))
    {
      message = Messages.getString("PI0575.BL001.errorRaisonPresent"); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, message);
    }
    return RetourFactory.createOkRetour();

  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param request_p
   *          request
   * @return Retour
   */
  @LogProcessBL
  private Retour PI0575_BL001_GET_VerifierDonnees(Tracabilite tracabilite_p, Request request_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    try
    {
      EvenementFinProv evenementFin = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), EvenementFinProv.class);
      retour = checkEvenementFinProv(evenementFin);
      _processContext.setEvenementfinProv(evenementFin);

    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, exception.getMessage()));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "error sti"); //$NON-NLS-1$
    }

    return retour;
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param retour_p
   *          retour
   * @return ReponseErreur
   */
  @LogProcessBL
  private ReponseErreur PI0575_BL002_GET_FormaterReponse(Tracabilite tracabilite_p, Retour retour_p)
  {

    ReponseErreur response = null;
    if (!isRetourOK(retour_p))
    {
      response = new ReponseErreur();
      response.setError(retour_p.getDiagnostic());
      response.setErrorDescription(retour_p.getLibelle());
    }
    return response;
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param retour_p
   *          retour
   * @return request_p,
   */
  @LogProcessBL
  private Retour PI0575_BL005_GererErreurPROSPER(Tracabilite tracabilite_p, Retour retour_p)
  {

    return retour_p;
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param eventment_p
   *          evenement
   * @return Pair<Notification, Retour>
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Notification, Retour> PI0575_BL100_RecupererNotification(Tracabilite tracabilite_p, EvenementFinProv eventment_p) throws RavelException
  {

    Notification notification = new Notification();
    notification.setCommandeId(eventment_p.getIdCmd());
    if (TRAITE_NOK.equals(eventment_p.getStatut()))
    {
      notification.setStatut("KO"); //$NON-NLS-1$
    }
    else
    {
      notification.setStatut("OK"); //$NON-NLS-1$
    }
    notification.setNatureCommande(eventment_p.getNatureCommande());
    notification.setRaisonErreur(eventment_p.getRaisonErreur());
    notification.setSystemeAppelant(eventment_p.getSystemeAppelant());
    notification.setDateTraitement(eventment_p.getDateTraitement());
    notification.setClientOperateur(eventment_p.getClientOperateur());
    notification.setNoCompte(eventment_p.getNoCompte());

    SEGA_SI148_NotifierDemandePROV sega_si148 = new SEGA_SI148_NotifierDemandePROVBuilder()//
        .tracabilite(tracabilite_p)//
        .commandeId(notification.getCommandeId())//
        .statut(notification.getStatut())//
        .raisonErreur(notification.getRaisonErreur())//
        .build();

    sega_si148.execute(this);
    Retour retour = sega_si148.getRetour();
    return new Pair<Notification, Retour>(notification, retour);

  }

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @param request_p
   *          request
   * @param reponserreur_p
   *          reponse Erreur
   * @param retour_p
   *          retour
   * @throws RavelException
   *           exception
   */
  private void syncResponse(Tracabilite tracabilite_p, Request request_p, ReponseErreur reponserreur_p, Retour retour_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

      Response rsp = null;

      if (reponserreur_p != null)
      {
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponserreur_p, ReponseErreur.class));

        ErrorCode errorCode = null;
        switch (reponserreur_p.getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
          case IMegConsts.DONNEE_INCONNUE:
          case IMegSpiritConsts.DONNEE_INVALIDE:
          case ECHEC_NOTIF:
            errorCode = ErrorCode.KO_00404;
            break;
          default:
            errorCode = ErrorCode.KO_00500;

        }

        rsp = new Response(errorCode, ravelResponse);

      }
      else
      {
        //Add empty Json in case OK
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(retour_p, Retour.class));
        rsp = new Response(ErrorCode.OK_00200, ravelResponse);
      }

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PI0575_ConsulterEvenement"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);

    }
  }

}
