/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.activities.shared.BL850_ObtenirTicket;
import com.bytel.spirit.common.activities.shared.BL850_ObtenirTicket.BL850_ObtenirTicketBuilder;
import com.bytel.spirit.common.activities.shared.BL851_LibererTicket;
import com.bytel.spirit.common.activities.shared.BL851_LibererTicket.BL851_LibererTicketBuilder;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.saab.connectors.spark.sql.SparkSQLProxy;
import com.bytel.spirit.saab.connectors.spark.sql.type.ColumnMetadata;
import com.bytel.spirit.saab.connectors.spark.sql.type.RowData;
import com.bytel.spirit.saab.connectors.spark.sql.type.SparkResult;

/**
 * This class exposes methodes to call different Connectors in the PROSPER context. <br/>
 * It is referenced by several processes like PP0333 and PE0332.
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public final class ProsperConnectorUtils
{
  private static ProsperConnectorUtils _instance = new ProsperConnectorUtils();

  /**
   * Get an instance for the ProsperConnectorUtils singleton
   *
   * @return The ProsperConnectorUtils reference
   */
  public static ProsperConnectorUtils getInstance()
  {
    return _instance;
  }

  /**
   * Private constructor
   */
  private ProsperConnectorUtils()
  {
    //nothing to do
  }

  /**
   * Call BL851 to acquire a permission to call Connector SPARK. <br/>
   * If a permission is granted, call the SPARK connector to execute the query in the requete_p parameter.
   *
   * @param tracabilite_p
   *          Tracabilite for log purposes
   * @param callingProcess_p
   *          The calling process reference
   * @param requete_p
   *          The requete to execute
   * @param readLimit_p
   *          The maximum number of data to return. If the this value is exceeded returns a partial response
   * @return
   * @throws RavelException
   *           Thrown if any exception occurs
   */
  public Pair<Retour, List<Map<String, String>>> invokeSPARKConnector(Tracabilite tracabilite_p, IActivityCaller callingProcess_p, String requete_p, int readLimit_p) throws RavelException
  {
    Retour retour = null;
    final BL850_ObtenirTicket bl850 = new BL850_ObtenirTicketBuilder() //
        .tracabilite(tracabilite_p) //
        .type("REQUETE_EXPLOITATION_SPARK") //
        .build();
    bl850.execute(callingProcess_p);
    retour = bl850.getRetour();
    if (!RetourFactory.isRetourOK(retour))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, retour.getLibelle()));
      return new Pair<>(retour, null);
    }

    final ConnectorResponse<Retour, SparkResult> sparkResponse = SparkSQLProxy.getInstance().executeSelectRequest(tracabilite_p, requete_p, readLimit_p);
    retour = sparkResponse._first;

    final BL851_LibererTicket bl851 = new BL851_LibererTicketBuilder() //
        .tracabilite(tracabilite_p) //
        .type("REQUETE_EXPLOITATION_SPARK") //
        .build();
    bl851.execute(callingProcess_p);

    //ignore retour of BL851 but log
    if (!RetourFactory.isRetourOK(bl851.getRetour()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, bl851.getRetour().getLibelle()));
    }

    return new Pair<>(retour, sparkResultToMap(sparkResponse._second));
  }

  /**
   * Transform a SparkResult to List<Map<String,String>>. Each element of the list represet a row of the SparkResult.
   * The Map Key is the column name and the value is the data value for the respective column
   *
   * @param sparkResult_p
   *          SparkResult represents the result of the SPARK connector
   *
   *
   * @return List<Map<String, String>> Represents the SPARK result in form of List<Map<String,String>>. If sparkResult_p
   *         is null returns empty list
   */
  private List<Map<String, String>> sparkResultToMap(SparkResult sparkResult_p)
  {
    List<Map<String, String>> result = new ArrayList<Map<String, String>>();
    if (sparkResult_p != null)
    {
      List<ColumnMetadata> columnMetaData = sparkResult_p.getMetadata();
      if ((columnMetaData != null) && !columnMetaData.isEmpty())
      {
        for (RowData rowData : sparkResult_p.getData())
        {
          if ((rowData != null))
          {
            Map<String, String> rowDataMap = new HashMap<String, String>();
            List<String> listvalue = rowData.getData();
            int index = 0;
            for (ColumnMetadata colomn : columnMetaData)
            {
              String key = colomn.getColumnName();
              String value = null;
              if (index < listvalue.size())
              {
                value = listvalue.get(index);
              }

              rowDataMap.put(key, value);
              index++;
            }
            result.add(rowDataMap);

          }
        }
      }
    }

    return result;
  }

}
