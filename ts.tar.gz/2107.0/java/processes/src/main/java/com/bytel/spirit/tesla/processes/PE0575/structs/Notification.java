/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0575.structs;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class Notification implements Serializable
{

  private static final long serialVersionUID = 1L;

  /**
   * Identifiant de la commande
   */
  private String _commandeId;

  /**
   * Date de publication de l'evenement
   */
  private LocalDateTime _dateTraitement;

  /**
   * Nature de la commande
   */
  private String _natureCommande;

  /**
   * Statut de la commande
   */
  private String _statut;

  /**
   * Libellé d'erreur associé en cas de rejet ou de traitement NOK
   */
  private String _raisonErreur;

  /**
   * le système technique à notifier
   */
  private String _systemeAppelant;

  /**
   * client Operateur
   */
  private String _clientOperateur;

  /**
   * numéro du compte du client
   */
  private String _noCompte;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    Notification other = (Notification) obj;
    if (_clientOperateur == null)
    {
      if (other._clientOperateur != null)
      {
        return false;
      }
    }
    else if (!_clientOperateur.equals(other._clientOperateur))
    {
      return false;
    }
    if (_commandeId == null)
    {
      if (other._commandeId != null)
      {
        return false;
      }
    }
    else if (!_commandeId.equals(other._commandeId))
    {
      return false;
    }
    if (_dateTraitement == null)
    {
      if (other._dateTraitement != null)
      {
        return false;
      }
    }
    else if (!_dateTraitement.equals(other._dateTraitement))
    {
      return false;
    }
    if (_natureCommande == null)
    {
      if (other._natureCommande != null)
      {
        return false;
      }
    }
    else if (!_natureCommande.equals(other._natureCommande))
    {
      return false;
    }
    if (_noCompte == null)
    {
      if (other._noCompte != null)
      {
        return false;
      }
    }
    else if (!_noCompte.equals(other._noCompte))
    {
      return false;
    }
    if (_raisonErreur == null)
    {
      if (other._raisonErreur != null)
      {
        return false;
      }
    }
    else if (!_raisonErreur.equals(other._raisonErreur))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    if (_systemeAppelant == null)
    {
      if (other._systemeAppelant != null)
      {
        return false;
      }
    }
    else if (!_systemeAppelant.equals(other._systemeAppelant))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the commandeId
   */
  public String getCommandeId()
  {
    return _commandeId;
  }

  /**
   * @return the dateTraitement
   */
  public LocalDateTime getDateTraitement()
  {
    return _dateTraitement;
  }

  /**
   * @return the natureCommande
   */
  public String getNatureCommande()
  {
    return _natureCommande;
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the raison_Erreur
   */
  public String getRaisonErreur()
  {
    return _raisonErreur;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the systemeAppelant
   */
  public String getSystemeAppelant()
  {
    return _systemeAppelant;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_clientOperateur == null) ? 0 : _clientOperateur.hashCode());
    result = (prime * result) + ((_commandeId == null) ? 0 : _commandeId.hashCode());
    result = (prime * result) + ((_dateTraitement == null) ? 0 : _dateTraitement.hashCode());
    result = (prime * result) + ((_natureCommande == null) ? 0 : _natureCommande.hashCode());
    result = (prime * result) + ((_noCompte == null) ? 0 : _noCompte.hashCode());
    result = (prime * result) + ((_raisonErreur == null) ? 0 : _raisonErreur.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    result = (prime * result) + ((_systemeAppelant == null) ? 0 : _systemeAppelant.hashCode());
    return result;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param commandeId_p
   *          the commandeId to set
   */
  public void setCommandeId(String commandeId_p)
  {
    _commandeId = commandeId_p;
  }

  /**
   * @param dateTraitement_p
   *          the dateTraitement to set
   */
  public void setDateTraitement(LocalDateTime dateTraitement_p)
  {
    _dateTraitement = dateTraitement_p;
  }

  /**
   * @param natureCommande_p
   *          the natureCommande to set
   */
  public void setNatureCommande(String natureCommande_p)
  {
    _natureCommande = natureCommande_p;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param raisonErreur_p
   *          the raison_Erreur to set
   */
  public void setRaisonErreur(String raisonErreur_p)
  {
    _raisonErreur = raisonErreur_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param systemeAppelant_p
   *          the systemeAppelant to set
   */
  public void setSystemeAppelant(String systemeAppelant_p)
  {
    _systemeAppelant = systemeAppelant_p;
  }

  @Override
  public String toString()
  {
    return "Notification [_commandeId=" + _commandeId + ", _dateTraitement=" + _dateTraitement + ", _natureCommande=" + _natureCommande + ", _statut=" + _statut + ", _raisonErreur=" + _raisonErreur + ", _systemeAppelant=" + _systemeAppelant + ", _clientOperateur=" + _clientOperateur + ", _noCompte=" + _noCompte + "]"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$//$NON-NLS-4$//$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$//$NON-NLS-9$
  }

}
