/*******************************************************************************
 * $Id: PE0396_GererAlarmeDirecte.java 52224 2021-05-19 13:36:55Z jsantos $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0396;

import java.nio.ByteBuffer;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.io.IOUtils;
import org.snmp4j.PDU;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.connectors.stark.STARKProxy;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.functional.types.json.notification.structs.DonneesOntInconnu;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.processes.Messages;
import com.bytel.spirit.tesla.processes.PE0341.sti.PE0341_NotificationReseauSTI;
import com.bytel.spirit.tesla.processes.PE0396.structs.AlarmReseau;
import com.bytel.spirit.tesla.processes.PE0396.structs.ConfigurationPE0396;

/**
 *
 * @author jiantila
 * @version ($Revision: 52224 $ $Date: 2021-05-19 15:36:55 +0200 (mer. 19 mai 2021) $)
 */
public class PE0396_GererAlarmeDirecte extends SpiritProcessSkeleton
{
  /**
   *
   * @author jiantila
   * @version ($Revision: 52224 $ $Date: 2021-05-19 15:36:55 +0200 (mer. 19 mai 2021) $)
   */
  public static final class PE0396_GererAlarmeDirecteContext extends Context
  {
    /** Serial UID */
    private static final long serialVersionUID = -8108995374327259698L;

    /** Contains the next step to execute. Initialized with the first step to execute. */
    private State _state = State.PE0396_START;

    /** Process Retour */
    private Retour _retour;

    /** AlarmReseau */
    private AlarmReseau _alarmReseau;

    /** ConfigurationPE0396 */
    private ConfigurationPE0396 _configurationPE0396;

    /**
     * Start date of process of trap SNMP
     */
    private LocalDateTime _dateDebutTraitement;

    /**
     * @return the alarmReseau
     */
    public AlarmReseau getAlarmReseau()
    {
      return _alarmReseau;
    }

    /**
     * @return the configurationPE0396
     */
    public ConfigurationPE0396 getConfigurationPE0396()
    {
      return _configurationPE0396;
    }

    public LocalDateTime getDateDebutTraitement()
    {
      return _dateDebutTraitement;
    }

    /**
     * @return the retour
     */
    public Retour getRetour()
    {
      return _retour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param alarmReseau_p
     *          the alarmReseau to set
     */
    public void setAlarmReseau(AlarmReseau alarmReseau_p)
    {
      _alarmReseau = alarmReseau_p;
    }

    /**
     * @param configurationPE0396_p
     *          the configurationPE0396 to set
     */
    public void setConfigurationPE0396(ConfigurationPE0396 configurationPE0396_p)
    {
      _configurationPE0396 = configurationPE0396_p;
    }

    public void setDateDebutTraitement(LocalDateTime dateDebutTraitement_p)
    {
      this._dateDebutTraitement = dateDebutTraitement_p;
    }

    /**
     * @param retour_p
     *          the retour to set
     */
    public void setRetour(Retour retour_p)
    {
      _retour = retour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

  }

  /**
   *
   * @author jiantila
   * @version ($Revision: 52224 $ $Date: 2021-05-19 15:36:55 +0200 (mer. 19 mai 2021) $)
   */
  public enum State
  {
    /** Initial step to execute */
    PE0396_START(MandatoryProcessState.PRC_START),
    /** Step to call BL001 */
    PE0396_BL001(MandatoryProcessState.PRC_RUNNING),
    /** Step to call BL002 */
    PE0396_BL002(MandatoryProcessState.PRC_RUNNING),
    /** Step to call BL005 */
    PE0396_BL005(MandatoryProcessState.PRC_RUNNING),
    /** Step to call BL200 */
    PE0396_BL200(MandatoryProcessState.PRC_RUNNING, true, true),
    /** Terminal state. */
    PE0396_END(MandatoryProcessState.PRC_STOP);

    /** Technical state associated. */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /** The asynchronous state. */
    protected boolean _asynchronousState = false;

    /** Replayable state. */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * Interface to list the usrates.
   */
  interface IUsrates
  {
    String TEN = "10";
    String ONE_TWENTY_FIVE = "1.25";
  }

  /** Constant fot huawei */
  private static final String HUAWEI = "huawei"; //$NON-NLS-1$
  /** Constant fot nokia */
  private static final String NOKIA = "nokia"; //$NON-NLS-1$

  /** Constant fot OMC_HUAWEI */
  private static final String OMC_HUAWEI = "OMC_HUAWEI"; //$NON-NLS-1$
  /** Constant fot OMC_NOKIA */
  private static final String OMC_NOKIA = "OMC_NOKIA"; //$NON-NLS-1$

  /** Serial UID */
  private static final long serialVersionUID = 1546049094723331821L;

  /** processus PE0341_NotificationReseau */
  private static final String PE0341_NotificationReseau = "PE0341_NotificationReseau"; //$NON-NLS-1$
  /** processus PE0341 URI */
  private static final String URI_PE0341 = "/notifications-reseau"; //$NON-NLS-1$

  /** OID HUAWEI TYPE OLT */
  private static final String OID_HUAWEI_TYPE_OLT = "1.3.6.1.4.1.2011.2.15.1.7.1.8.0"; //$NON-NLS-1$
  /** OID NOKIA TYPE OLT */
  private static final String OID_NOKIA_TYPE_OLT = "1.3.6.1.4.1.637.69.6.1.1.1.15"; //$NON-NLS-1$

  /** OID NOM OLT */
  private static final String OID_NOM_OLT_HUAWEI = "1.3.6.1.4.1.2011.2.15.1.7.1.1.0"; //$NON-NLS-1$
  /** OID NOM OLT NOKIA */
  private static final String OID_NOM_OLT_NOKIA = "1.3.6.1.4.1.637.69.6.1.1.1.9"; //$NON-NLS-1$

  /** OID DATE ALARME */
  private static final String OID_DATE_ALARME_NOKIA = "1.3.6.1.4.1.637.69.6.1.1.1.5"; //$NON-NLS-1$

  /** OID SLOT PORT */
  private static final String OID_SLOT_PORT = "1.3.6.1.4.1.2011.2.15.1.7.1.3.0"; //$NON-NLS-1$

  /** OID DATE ALARME */
  private static final String OID_DATE_ALARME_HUAWEI = "1.3.6.1.4.1.2011.2.15.1.7.1.5.0"; //$NON-NLS-1$

  /** OID HUAWEI SLID */
  private static final String OID_HUAWEI_SLID = "1.3.6.1.4.1.2011.2.15.1.7.1.3.0"; //$NON-NLS-1$
  /** OID NOKIA SLID */
  private static final String OID_NOKIA_SLID = "1.3.6.1.4.1.637.69.6.1.1.1.8"; //$NON-NLS-1$

  /** VALIDATION */
  private static final String VALIDATION = "VALIDATION"; //$NON-NLS-1$

  /** OID NOKIA */
  protected static final String[] OIDS_NOKIA = { OID_NOKIA_TYPE_OLT, OID_NOM_OLT_NOKIA, OID_DATE_ALARME_NOKIA, OID_NOKIA_SLID };

  /** OID HUAWEI */
  protected static final String[] OIDS_HUAWEI = { OID_HUAWEI_TYPE_OLT, OID_NOM_OLT_HUAWEI, OID_SLOT_PORT, OID_DATE_ALARME_HUAWEI, OID_HUAWEI_SLID };

  /** Constant for mesAlarmeDirecte */
  private static final String MES_ALARME_DIRECTE = "mesAlarmeDirecte"; //$NON-NLS-1$
  /** Constant for slidFiltreListe */
  private static final String SLID_FILTRE_LISTE = "slidFiltreListe"; //$NON-NLS-1$
  /** Constant for slidFiltreFlag */
  private static final String SLID_FILTRE_FLAG = "slidFiltreFlag"; //$NON-NLS-1$
  /** Constant for slidPrefixHuawei */
  private static final String SLID_PREFIX_HUAWEI = "slidPrefixHuawei"; //$NON-NLS-1$
  /** Constant for slidPrefixNokia */
  private static final String SLID_PREFIX_NOKIA = "slidPrefixNokia"; //$NON-NLS-1$

  /** EVENT_HUAWEI */
  private static final String EVENT_HUAWEI = "The GPON ONT is discovered by the OLT"; //$NON-NLS-1$
  /** EVENT_NOKIA */
  private static final String EVENT_NOKIA = "New ONT Discovered"; //$NON-NLS-1$

  /** Constant for number 1 */
  private static final String ONE = "1"; //$NON-NLS-1$

  /** The process context instance */
  private PE0396_GererAlarmeDirecteContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    super.initializeContext();
    _processContext = new PE0396_GererAlarmeDirecteContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    if (isRetourOK(_processContext.getRetour()))
    {
      // Call BL200_ExecuterPM
      Retour retourBL200 = PE0396_BL200_ExecuterPM(tracabilite_p, _processContext.getAlarmReseau());
      _processContext.setRetour(retourBL200);
    }

    // Call BL005_GererErreurPROSPER
    _processContext.setState(State.PE0396_BL005);
    PE0396_BL005_GererErreurPROSPER(tracabilite_p, _processContext.getRetour());
    _processContext.setState(State.PE0396_END);
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // NOP
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      //initialise start date
      _processContext.setDateDebutTraitement(LocalDateTime.now());
      // Build and log snmp request
      PDU pdu = new PDU();
      pdu.decodeBER(new BERInputStream(ByteBuffer.wrap(IOUtils.toByteArray(request_p.streamPayload()))));
      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, " Trap Received:" + pdu)); //$NON-NLS-1$

      // Call BL001_VerifierDonnees
      _processContext.setState(State.PE0396_BL001);
      Pair<Retour, AlarmReseau> bl001 = PE0396_BL001_VerifierDonnees(tracabilite_p, pdu);
      Retour retourBL001 = bl001._first;
      _processContext.setRetour(retourBL001);
      _processContext.setAlarmReseau(bl001._second);
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      _processContext.setRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
    }
    finally
    {
      // Call BL002_FormaterReponse
      _processContext.setState(State.PE0396_BL002);
      Retour retourBL002 = PE0396_BL002_FormaterReponse(tracabilite_p, _processContext.getRetour());
      _processContext.setRetour(retourBL002);
      _processContext.setState(State.PE0396_BL200);
    }
  }

  /**
   * call Stark Connector
   *
   * @param tracabilite_p
   *          tracabilite
   * @param pe0341Request_p
   *          Request object
   * @param headers
   *          header of request
   * @return Retour object
   * @throws RavelException
   *           exception
   */
  private Retour callStarkConnector(Tracabilite tracabilite_p, PE0341_NotificationReseauSTI pe0341Request_p, MultivaluedMap<String, String> headers) throws RavelException
  {
    IRavelJson jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();
    RESTRequest restRequest = new RESTRequestBuilder()//
        .httpMethod(HttpMethod.POST)//
        .request(pe0341Request_p)//
        .traceability(tracabilite_p) //
        .method(URI_PE0341)//
        .headers(headers)//
        .path(URI_PE0341)//
        .queryParameter(null)//
        .serializer(jsonBuilder)//
        .build();

    // Call STARK connector
    ConnectorResponse<Retour, STARKResponse<ReponseErreur>> connectorResponse = STARKProxy.getInstance().sendRequest(restRequest, ReponseErreur.class);

    if ((connectorResponse != null) && (connectorResponse._first != null))
    {
      Retour technicalRetour = connectorResponse._first; //Technical retour of connector
      STARKResponse<ReponseErreur> functionalResponse = connectorResponse._second;
      if (RetourFactory.isRetourNOK(technicalRetour))
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, technicalRetour.getLibelle()));
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.SERVICE_TIERS_INDISPONIBLE, technicalRetour.getLibelle());
      }
      if ((functionalResponse != null) && (functionalResponse.getReponseErreur() != null))
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, functionalResponse.getReponseErreur().getError() + "  " + functionalResponse.getReponseErreur().getErrorDescription()); //$NON-NLS-1$
      }
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Check STI from PDU
   *
   * @param pdu_p
   *          pdu
   * @return Retour
   */
  private Retour checkSTI(final PDU pdu_p)
  {
    // on cherche le nombre d'oids nokia manquant
    List<String> nbMissingOidsNokia = new ArrayList<>();
    for (String oid : OIDS_NOKIA)
    {
      if (pdu_p.getVariable(new OID(oid)) == null)
      {
        nbMissingOidsNokia.add(oid);
      }
    }

    if (nbMissingOidsNokia.size() == 0)
    {
      return RetourFactory.createOkRetour();
    }

    if ((nbMissingOidsNokia.size() > 0) && (nbMissingOidsNokia.size() != OIDS_NOKIA.length))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PE0396.missingOID"), nbMissingOidsNokia.toString())); //$NON-NLS-1$
    }

    // idem pour Huawei
    List<String> nbMissingOidsHuawei = new ArrayList<>();
    for (String oid : OIDS_HUAWEI)
    {
      if (pdu_p.getVariable(new OID(oid)) == null)
      {
        nbMissingOidsHuawei.add(oid);
      }
    }

    if (nbMissingOidsHuawei.size() == 0)
    {
      return RetourFactory.createOkRetour();
    }

    if ((nbMissingOidsHuawei.size() > 0) && (nbMissingOidsHuawei.size() != OIDS_HUAWEI.length))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PE0396.missingOID"), nbMissingOidsHuawei.toString())); //$NON-NLS-1$
    }

    // unkown PDU
    return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, Messages.getString("PE0396.unkownPDU")); //$NON-NLS-1$

  }

  /**
   * getNomOltNokia
   *
   * @param value_p
   *          String contains olt
   * @return olt value
   */
  private String getNomOltNokia(final String value_p)
  {
    String olt = null;
    if (value_p != null)
    {
      int index = value_p.indexOf(":"); //$NON-NLS-1$
      if (index > 0)
      {
        olt = value_p.substring(index + 1, value_p.length());
        index = olt.indexOf(":"); //$NON-NLS-1$
        if (index > 0)
        {
          olt = olt.substring(0, index);

        }
      }
    }
    return olt;
  }

  /**
   * get PAssword value
   *
   * @param value_p
   *          string contain password
   * @return password
   */
  private String getPasswordHuawei(final String value_p)
  {
    String password = null;
    if (value_p != null)
    {
      String regex = "(.*)Password=([0-9a-fA-FxX]+)(.*)"; //$NON-NLS-1$
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(value_p);

      if (matcher.find())
      {
        password = matcher.group(2);
      }
    }
    return password;
  }

  /**
   * get Port huawei
   *
   * @param value_p
   *          contain port
   * @return port
   */
  private String getPortHuawei(final String value_p)
  {
    String port = null;
    if (value_p != null)
    {
      String regex = "(.*)Port=(\\d+)(.*)"; //$NON-NLS-1$
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(value_p);

      if (matcher.find())
      {
        port = matcher.group(2);
      }
    }
    return port;
  }

  /**
   * get Port from slot
   *
   * @param value_p
   *          value contains port
   * @return port
   */
  private String getPortNokia(final String value_p, final String usRate_p)
  {
    String port = null;

    if (value_p != null)
    {
      int index = value_p.lastIndexOf(":"); //$NON-NLS-1$
      if (index > 0)
      {
        port = value_p.substring(index + 1, value_p.length());
        String str[] = port.split("\\."); //$NON-NLS-1$
        if (str.length > 4)
        {
          port = str[3];
          if (IUsrates.ONE_TWENTY_FIVE.equals(usRate_p))
          {
            //suppression PON
            if (port.contains("PON")) //$NON-NLS-1$
            {
              port = port.replaceFirst("PON", ""); //$NON-NLS-1$ //$NON-NLS-2$
            }
          }
          else if (IUsrates.TEN.equals(usRate_p))
          {
            //suppression PON
            if (port.contains("PONXGS")) //$NON-NLS-1$
            {
              port = port.replaceFirst("PONXGS", ""); //$NON-NLS-1$ //$NON-NLS-2$
            }
          }
        }
        else
        {
          port = null;
        }
      }
    }

    return port;
  }

  /**
   * get SLid for Nokia
   *
   * @param value_p
   *          string contain slid
   * @return slid
   */
  private String getSlidNokia(final String value_p)
  {
    String slid = null;
    if (value_p != null)
    {
      String regex = "(.*)SLID=([0-9a-fA-FxX]+)(.*)"; //$NON-NLS-1$
      Pattern pattern = Pattern.compile(regex);
      slid = value_p.replaceAll("\\s+", ""); //$NON-NLS-1$//$NON-NLS-2$
      Matcher matcher = pattern.matcher(slid);

      if (matcher.find())
      {
        slid = matcher.group(2);
      }
    }
    return slid;
  }

  /**
   * getSlotHuawei
   *
   * @param value_p
   *          value
   * @return Slot for Huawei
   */
  private String getSlotHuawei(final String value_p)
  {
    String slot = null;
    if (value_p != null)
    {
      String regex = "(.*)Slot=(\\d+)(.*)"; //$NON-NLS-1$
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(value_p);

      if (matcher.find())
      {
        slot = matcher.group(2);
      }
    }
    return slot;
  }

  /**
   *
   * getSlotNokia
   *
   * @param value_p
   *          string contains port
   * @return port
   */
  private String getSlotNokia(String value_p)
  {
    String slot = null;

    if (value_p != null)
    {
      int index = value_p.lastIndexOf(":"); //$NON-NLS-1$
      if (index > 0)
      {
        slot = value_p.substring(index + 1, value_p.length());
        String str[] = slot.split("\\."); //$NON-NLS-1$
        if (str.length > 3)
        {
          slot = str[2];
          //suppression LT
          if (slot.contains("LT")) //$NON-NLS-1$
          {
            slot = slot.replaceFirst("LT", ""); //$NON-NLS-1$//$NON-NLS-2$
          }
        }
        else
        {
          slot = null;
        }
      }
    }

    return slot;

  }

  /**
   * get USRATE for Nokia
   *
   * @param value_p
   *          string contain slid
   * @return slid
   */
  private String getUsrate(final String value_p)
  {
    String usrate = null;
    if (value_p != null)
    {
      String regex = "(.*)USRATE=(([0-9]+\\.[0-9]+)|([0-9]+))(.*)"; //$NON-NLS-1$
      Pattern pattern = Pattern.compile(regex);
      usrate = value_p.replaceAll("\\s+", ""); //$NON-NLS-1$//$NON-NLS-2$
      Matcher matcher = pattern.matcher(usrate);

      if (matcher.find())
      {
        usrate = matcher.group(2);
      }
    }
    return usrate;
  }

  /**
   * Fixes the SLID length by adding "1" values.
   * @param slidNokia_p the SLID
   * @return Slid with 72 characters
   */
  private String fixSlidLength(String slidNokia_p)
  {
    if (slidNokia_p != null)
    {
      while (slidNokia_p.length() < 72)
      {
        slidNokia_p = slidNokia_p.concat(ONE);
      }
    }
    return slidNokia_p;
  }

  /**
   * load process configuration
   *
   * @return ConfigurationPE0396
   */
  private Pair<Retour, ConfigurationPE0396> loadConfiguration()
  {
    ConfigurationPE0396 configuration = new ConfigurationPE0396();

    String mesAlarmeDirecte = getConfigParameter(MES_ALARME_DIRECTE);
    if (StringTools.isNotNullOrEmpty(mesAlarmeDirecte))
    {
      boolean value = Boolean.parseBoolean(mesAlarmeDirecte);
      if (!value)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, Messages.getString("PE0396.traitement_alarme")), null); //$NON-NLS-1$
      }
      configuration.setMesAlarmeDirecte(value);
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, MessageFormat.format(Messages.getString("PE0396.NoParam"), MES_ALARME_DIRECTE)), null); //$NON-NLS-1$
    }

    String slidFiltreFlag = getConfigParameter(SLID_FILTRE_FLAG);
    if (slidFiltreFlag != null)
    {
      configuration.setSlidFiltreFlag(slidFiltreFlag);
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, MessageFormat.format(Messages.getString("PE0396.NoParam"), SLID_FILTRE_FLAG)), null); //$NON-NLS-1$
    }

    String slidFiltreList = getConfigParameter(SLID_FILTRE_LISTE);
    if (slidFiltreList == null)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, MessageFormat.format(Messages.getString("PE0396.NoParam"), SLID_FILTRE_LISTE)), null); //$NON-NLS-1$
    }
    if (StringTools.isNullOrEmpty(slidFiltreList))
    {
      // if string empty -> empty List
      configuration.setSlidFiltreListe(new ArrayList<>());
    }
    else
    {
      // else set the list
      String str[] = slidFiltreList.split(","); //$NON-NLS-1$
      configuration.setSlidFiltreListe(Arrays.asList(str));
    }

    String slidPrefixHuawei = getConfigParameter(SLID_PREFIX_HUAWEI);
    if (slidPrefixHuawei != null)
    {
      configuration.setSlidPrefixHuawei(slidPrefixHuawei);
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, MessageFormat.format(Messages.getString("PE0396.NoParam"), SLID_PREFIX_HUAWEI)), null); //$NON-NLS-1$
    }

    String slidPrefixNokia = getConfigParameter(SLID_PREFIX_NOKIA);
    if (slidPrefixNokia != null)
    {
      configuration.setSlidPrefixNokia(slidPrefixNokia);
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, MessageFormat.format(Messages.getString("PE0396.NoParam"), SLID_PREFIX_NOKIA)), null); //$NON-NLS-1$
    }

    return new Pair<>(RetourFactory.createOkRetour(), configuration);
  }

  /**
   * PE0396_BL001_VerifierDonnees
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param pdu_p
   *          PDU
   * @return Pair<AlarmReseau, Retour>
   * @throws RavelException
   *           ravel exception
   */
  @LogProcessBL
  private Pair<Retour, AlarmReseau> PE0396_BL001_VerifierDonnees(Tracabilite tracabilite_p, final PDU pdu_p) throws RavelException
  {
    AlarmReseau alarmReseau = new AlarmReseau();

    //check STI
    Retour retourSTI = checkSTI(pdu_p);
    if (RetourFactory.isRetourNOK(retourSTI))
    {
      return new Pair<>(retourSTI, alarmReseau);
    }

    Pair<Retour, ConfigurationPE0396> loadConf = loadConfiguration();
    Retour retourConf = loadConf._first;
    String usrate = null;
    if (RetourFactory.isRetourNOK(retourConf))
    {
      return new Pair<>(retourConf, alarmReseau);
    }
    _processContext.setConfigurationPE0396(loadConf._second);

    if (pdu_p.getVariable(new OID(OID_HUAWEI_TYPE_OLT)) != null)
    {
      alarmReseau.setTypeOlt(HUAWEI);

      Variable typeEvenement = pdu_p.getVariable(new OID(OID_HUAWEI_TYPE_OLT));
      alarmReseau.setTypeEvenement(typeEvenement.toString().replaceAll("^\"", "").replaceAll("\"$", "")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

      if (!EVENT_HUAWEI.equals(alarmReseau.getTypeEvenement()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0396.ErrorOIDValue"), "typeEvenement", alarmReseau.getTypeEvenement())), null); //$NON-NLS-1$ //$NON-NLS-2$
      }

      Variable slid = pdu_p.getVariable(new OID(OID_HUAWEI_SLID));
      if (slid != null)
      {
        String passwordSlid = getPasswordHuawei(slid.toString());

        // If the hexadecimal prefix 0x is present, remove it.
        if ((passwordSlid != null) && passwordSlid.startsWith("0x")) //$NON-NLS-1$
        {
          passwordSlid = passwordSlid.substring(2);
        }

        alarmReseau.setSlid(passwordSlid);
      }
    }
    else if (pdu_p.getVariable(new OID(OID_NOKIA_TYPE_OLT)) != null)
    {
      alarmReseau.setTypeOlt(NOKIA);

      Variable typeEvent = pdu_p.getVariable(new OID(OID_NOKIA_TYPE_OLT));
      alarmReseau.setTypeEvenement(typeEvent.toString().replaceAll("^\"", "").replaceAll("\"$", "")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

      if (!EVENT_NOKIA.equals(alarmReseau.getTypeEvenement()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0396.ErrorOIDValue"), "typeEvenement", alarmReseau.getTypeEvenement())), null); //$NON-NLS-1$ //$NON-NLS-2$
      }

      Variable slid = pdu_p.getVariable(new OID(OID_NOKIA_SLID));
      if (slid != null)
      {
        String slidNokia = getSlidNokia(slid.toString());

        // If the hexadecimal prefix 0x is present, remove it.
        if ((slidNokia != null) && slidNokia.startsWith("0x")) //$NON-NLS-1$
        {
          slidNokia = slidNokia.substring(2);
        }

        usrate = getUsrate(slid.toString());

        if (usrate.equals(IUsrates.ONE_TWENTY_FIVE))
        {
          alarmReseau.setSlid(slidNokia);
        }
        else if (usrate.equals(IUsrates.TEN))
        {
          slidNokia = fixSlidLength(slidNokia);

          alarmReseau.setSlid(slidNokia);
        }
      }

    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, Messages.getString("PE0396.errorOID_Olt")), alarmReseau); //$NON-NLS-1$
    }

    if (alarmReseau.getSlid() == null)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, Messages.getString("PE0396.errorOID_slidNull")), alarmReseau); //$NON-NLS-1$
    }

    // si liste vide et VALIDATION -> toutes les alarmes sont bloquées.
    if ((_processContext.getConfigurationPE0396().getSlidFiltreListe().size() == 0) && (VALIDATION.equals(_processContext.getConfigurationPE0396().getSlidFiltreFlag())))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0396.nonconforme"), alarmReseau.getSlid())), alarmReseau); //$NON-NLS-1$
    }

    boolean flagTrouve = false;
    for (String expression : _processContext.getConfigurationPE0396().getSlidFiltreListe())
    {
      Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
      Matcher matcher = pattern.matcher(alarmReseau.getSlid());
      if (matcher.find())
      {
        flagTrouve = true;
        if (VALIDATION.equals(_processContext.getConfigurationPE0396().getSlidFiltreFlag()))
        {
          break;
        }
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0396.rejectSLID"), alarmReseau.getSlid())), alarmReseau); //$NON-NLS-1$
      }
    }
    // Le Slid ne correspond à aucune expression
    if ((!flagTrouve) && (VALIDATION.equals(_processContext.getConfigurationPE0396().getSlidFiltreFlag())))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0396.nonconforme"), alarmReseau.getSlid())), alarmReseau); //$NON-NLS-1$
    }

    if (HUAWEI.equals(alarmReseau.getTypeOlt()))
    {
      // AMS Huawei
      Variable nomOlt = pdu_p.getVariable(new OID(OID_NOM_OLT_HUAWEI));
      if (nomOlt != null)
      {
        alarmReseau.setNomOlt(nomOlt.toString());
      }

      Variable slotPort = pdu_p.getVariable(new OID(OID_SLOT_PORT));
      if (slotPort != null)
      {
        String slot = getSlotHuawei(slotPort.toString());
        alarmReseau.setSlot(slot);
        String port = getPortHuawei(slotPort.toString());
        alarmReseau.setPort(port);
      }

      String date = ""; //$NON-NLS-1$
      try
      {
        Variable datealarme = pdu_p.getVariable(new OID(OID_DATE_ALARME_HUAWEI));
        if (datealarme != null)
        {
          date = datealarme.toString();
          if (date.contains("\"")) //$NON-NLS-1$
          {
            date = date.replace("\"", ""); //$NON-NLS-1$//$NON-NLS-2$
          }

          DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd - HH:mm:ss'Z'"); //$NON-NLS-1$
          LocalDateTime dateTime = ZonedDateTime.of(LocalDateTime.parse(date, formatter), ZoneId.of("UTC")).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime(); //$NON-NLS-1$
          alarmReseau.setDateAlarme(dateTime);

        }
      }
      catch (Exception ex)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0396.ErrorOIDValue"), "Date", date)), null); //$NON-NLS-1$//$NON-NLS-2$
      }

    }
    else
    {
      // AMS Nokia
      Variable nomOltNokia = pdu_p.getVariable(new OID(OID_NOM_OLT_NOKIA));
      if (nomOltNokia != null)
      {
        String olt = getNomOltNokia(nomOltNokia.toString());
        alarmReseau.setNomOlt(olt);
        String slot = getSlotNokia(nomOltNokia.toString());
        alarmReseau.setSlot(slot);
        String port = getPortNokia(nomOltNokia.toString(), usrate);
        alarmReseau.setPort(port);
      }

      String date = ""; //$NON-NLS-1$
      try
      {
        Variable dateOltNokia = pdu_p.getVariable(new OID(OID_DATE_ALARME_NOKIA));
        if (dateOltNokia != null)
        {
          date = dateOltNokia.toString();
          if (date.contains("\"")) //$NON-NLS-1$
          {
            date = date.replace("\"", ""); //$NON-NLS-1$//$NON-NLS-2$
          }
          DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH); //$NON-NLS-1$
          LocalDateTime dateTime = LocalDateTime.parse(date, formatter);
          alarmReseau.setDateAlarme(dateTime);
        }
      }
      catch (Exception ex)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0396.ErrorOIDValue"), "Date", date)), null); //$NON-NLS-1$//$NON-NLS-2$
      }

    }

    return new Pair<>(RetourFactory.createOkRetour(), alarmReseau);
  }

  /**
   * PE0396_BL002_FormaterReponse
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retourIn_p
   *          retourIn
   * @return Retour
   */
  @LogProcessBL
  private Retour PE0396_BL002_FormaterReponse(Tracabilite tracabilite_p, Retour retourIn_p)
  {
    return retourIn_p;
  }

  /**
   * PE0396_BL005_GererErreurPROSPER
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retourIn_p
   *          retour input
   * @return retour
   */
  @LogProcessBL
  private Retour PE0396_BL005_GererErreurPROSPER(Tracabilite tracabilite_p, Retour retourIn_p)
  {
    return retourIn_p;
  }

  /**
   * PE0396_BL200_ExecuterPM
   *
   * @param tracabilite_p
   *          tracabilite
   * @param alarmReseau_p
   *          AlarmReseau
   * @return Retour
   * @throws RavelException
   *           exception
   *
   */
  @LogProcessBL
  private Retour PE0396_BL200_ExecuterPM(Tracabilite tracabilite_p, AlarmReseau alarmReseau_p) throws RavelException
  {
    // Create a new Tracabilite to avoid passing the existing one to the command
    Tracabilite tracabilite = new Tracabilite(tracabilite_p);
    tracabilite.setNomProcessus(PE0341_NotificationReseau);
    tracabilite.setIdCorrelationSpirit(UUID.randomUUID().toString());
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<String, String>();
    headers.add(IHttpHeadersConsts.X_REQUEST_ID, tracabilite.getIdCorrelationSpirit());
    headers.add(IHttpHeadersConsts.X_PROCESS, tracabilite.getNomProcessus());

    if (HUAWEI.equals(alarmReseau_p.getTypeOlt()))
    {
      headers.add(IHttpHeadersConsts.X_SOURCE, OMC_HUAWEI);
    }
    if (NOKIA.equals(alarmReseau_p.getTypeOlt()))
    {
      headers.add(IHttpHeadersConsts.X_SOURCE, OMC_NOKIA);
    }

    // Build DonneesOntInconnu
    DonneesOntInconnu donneeOntInconnu = new DonneesOntInconnu();

    if (StringTools.isNullOrEmpty(alarmReseau_p.getNomOlt()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0396.ErrorOIDValue"), "NomOlt", alarmReseau_p.getNomOlt())); //$NON-NLS-1$//$NON-NLS-2$
    }
    donneeOntInconnu.setNomOLT(alarmReseau_p.getNomOlt());

    try
    {
      donneeOntInconnu.setSlot(Integer.parseInt(alarmReseau_p.getSlot()));
    }
    catch (Exception ex)
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0396.ErrorOIDValue"), "Slot", alarmReseau_p.getSlot())); //$NON-NLS-1$//$NON-NLS-2$
    }

    try
    {
      donneeOntInconnu.setPort(Integer.parseInt(alarmReseau_p.getPort()));
    }
    catch (Exception ex)
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0396.ErrorOIDValue"), "Port", alarmReseau_p.getPort())); //$NON-NLS-1$//$NON-NLS-2$
    }
    donneeOntInconnu.setSlid(alarmReseau_p.getSlid());

    // Build PE0341_NotificationReseauSTI
    PE0341_NotificationReseauSTI pe341Request = new PE0341_NotificationReseauSTI(alarmReseau_p.getTypeEvenement(), donneeOntInconnu);
    pe341Request.setDateReception(_processContext.getDateDebutTraitement());
    pe341Request.setDateGenerationEvenementReseau(alarmReseau_p.getDateAlarme());

    // Call Stark Connector
    return callStarkConnector(tracabilite, pe341Request, headers);
  }
}
