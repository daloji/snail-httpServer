/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0000;

import java.io.File;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.time.Duration;

import org.apache.commons.io.IOUtils;
import org.snmp4j.PDU;
import org.snmp4j.asn1.BERInputStream;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.TimeTicks;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author dangelis
 * @version ($Revision$ $Date$)
 */
public class PE0000_TestSNMPTRAP extends SpiritProcessSkeleton
{

  /**
   * Holds context data for PE0000_TestSNMPTRAP
   *
   * @author dangelis
   * @version ($Revision: 22040 $ $Date: 2019-05-28 17:54:49 +0200 (mar. 28 mai 2019) $)
   */
  public static final class PE0000_TestSNMPTRAPContext extends Context
  {
    /**
     * PE0000_TestSNMPTRAP
     */
    private static final long serialVersionUID = -3507159535645911585L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private transient State _state = State.PE0000_START;

    /**
     * @return the state
     */
    public final State getState()
    {
      return _state;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(final State state_p)
    {
      _state = state_p;
    }

  }

  /**
   * PE0000 states
   *
   * @author dangelis
   * @version ($Revision: 22040 $ $Date: 2019-05-28 17:54:49 +0200 (mar. 28 mai 2019) $)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0000_START(MandatoryProcessState.PRC_START),

    /**
     * Terminal state.
     */
    PE0000_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    private MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    private Boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    private Boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * @return the asynchronousState
     */
    public final Boolean getAsynchronousState()
    {
      return _asynchronousState;
    }

    /**
     * @return the replayableState
     */
    public final Boolean getReplayableState()
    {
      return _replayableState;
    }

    /**
     * @return the technicalState
     */
    public final MandatoryProcessState getTechnicalState()
    {
      return _technicalState;
    }

    /**
     * @param asynchronousState_p
     *          the asynchronousState to set
     */
    protected final void setAsynchronousState(final Boolean asynchronousState_p)
    {
      _asynchronousState = asynchronousState_p;
    }

    /**
     * @param replayableState_p
     *          the replayableState to set
     */
    protected final void setReplayableState(final Boolean replayableState_p)
    {
      _replayableState = replayableState_p;
    }

    /**
     * @param technicalState_p
     *          the technicalState to set
     */
    protected final void setTechnicalState(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = -660974609672084872L;

  /**
   * The process's context.
   */
  private PE0000_TestSNMPTRAPContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().name();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ZERO;
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState().getTechnicalState();
  }

  @Override
  public void initializeContext()
  {
    super.initializeContext();
    _processContext = new PE0000_TestSNMPTRAPContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState().getAsynchronousState();
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState().getReplayableState();
  }

  @Override
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    // TODO Auto-generated method stub

  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // TODO Auto-generated method stub

  }

  @Override
  protected void startMetroLog()
  {
    // TODO Auto-generated method stub

  }

  @Override
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    _processContext.setState(State.PE0000_START);
    PDU pdu = new PDU();
    PDU trapExpect = new PDU();
    trapExpect.setType(PDU.TRAP);
    trapExpect.setRequestID(new Integer32(0));

    OID oid = new OID("1.2.3.4.5"); //$NON-NLS-1$
    trapExpect.add(new VariableBinding(SnmpConstants.snmpTrapOID, oid));
    trapExpect.add(new VariableBinding(SnmpConstants.sysUpTime, new TimeTicks(5000))); // put your uptime here
    trapExpect.add(new VariableBinding(SnmpConstants.sysDescr, new OctetString("System Description"))); //$NON-NLS-1$

    //Add Payload
    Variable var = new OctetString("some string"); //$NON-NLS-1$
    trapExpect.add(new VariableBinding(oid, var));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    try
    {

      pdu.decodeBER(new BERInputStream(ByteBuffer.wrap(IOUtils.toByteArray(request_p.streamPayload()))));
      RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, "Trap Expect:" + trapExpect.toString() + " Trap Received:" + pdu)); //$NON-NLS-1$ //$NON-NLS-2$
      pdu.setRequestID(new Integer32(0));
      if ((trapExpect.getType() == (pdu.getType())) && ((trapExpect.getVariable(SnmpConstants.snmpTrapOID).equals(pdu.getVariable(SnmpConstants.snmpTrapOID))) && (trapExpect.getVariable(SnmpConstants.sysDescr).equals(pdu.getVariable(SnmpConstants.sysDescr)))))
      {

        request_p.setResponse(new Response(ErrorCode.KO_00400, ravelResponse));

        File file = new File("./tt-files/data/success.txt"); //$NON-NLS-1$
        if (!file.exists())
        {
          file.createNewFile();
        }
        PrintWriter writer = new PrintWriter("./tt-files/data/success.txt", "UTF-8"); //$NON-NLS-1$ //$NON-NLS-2$
        writer.println("Trap Expect:" + trapExpect.toString() + " Trap Received:" + pdu.toString()); //$NON-NLS-1$ //$NON-NLS-2$
        writer.close();

      }
      else
      {
        request_p.setResponse(new Response(ErrorCode.KO_00500, ravelResponse));
      }
    }
    catch (Exception exception)
    {
      request_p.setResponse(new Response(ErrorCode.KO_00500, ravelResponse));
    }

    _processContext.setState(State.PE0000_END);
  }

}
