/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0033.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author rdavid
 * @version ($Revision$ $Date$)
 */
public class PE0033_BL001Return implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -4859343980805730498L;

  /**
   *
   */
  private Retour _retour;

  /**
   *
   */
  private String _clientOperateur;

  /**
   *
   */
  private String _noCompte;

  /**
   *
   */
  private List<String> _listeCleSequencement;

  /**
   *
   */
  private Tracabilite _tracabilite;

  /**
   * @param retour_p
   *          retour
   * @param clientOperateur_p
   *          clientOperateur
   * @param noCompte_p
   *          noCompte
   * @param tracabilite_p
   *          tracabilite
   */
  public PE0033_BL001Return(Retour retour_p, String clientOperateur_p, String noCompte_p, Tracabilite tracabilite_p)
  {
    super();
    _retour = retour_p;
    _clientOperateur = clientOperateur_p;
    _noCompte = noCompte_p;
    _tracabilite = tracabilite_p;
  }

  /**
   * @param retour_p
   *          retour
   * @param clientOperateur_p
   *          clientOperateur
   * @param noCompte_p
   *          noCompte
   * @param tracabilite_p
   *          tracabilite
   * @param listeCleSequencement_p
   *          listeCleSequencement
   */
  public PE0033_BL001Return(Retour retour_p, String clientOperateur_p, String noCompte_p, List<String> listeCleSequencement_p, Tracabilite tracabilite_p)
  {
    _retour = retour_p;
    _clientOperateur = clientOperateur_p;
    _noCompte = noCompte_p;
    _listeCleSequencement = listeCleSequencement_p == null ? null : new ArrayList<>(listeCleSequencement_p);
    _tracabilite = tracabilite_p;
  }

  /**
   * Add a cleSequencement to listeCleSequencement
   *
   * @param cleSequencement_p
   *          the cleSequencement to add
   */
  public void addCleSequencement(String cleSequencement_p)
  {
    if(_listeCleSequencement == null)
    {
      _listeCleSequencement = new ArrayList<>();
    }
    _listeCleSequencement.add(cleSequencement_p);
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return value of _listeCleSequencement.
   */
  public List<String> getListeCleSequencement()
  {
    return _listeCleSequencement == null ? new ArrayList<>() : new ArrayList<>(_listeCleSequencement);
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the retour
   */
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * @return the tracabilite
   */
  public Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param listeCleSequencement_p
   *     the _listeCleSequencement to set.
   */
  public void setListeCleSequencement(List<String> listeCleSequencement_p)
  {
    _listeCleSequencement = listeCleSequencement_p == null ? null : new ArrayList<>(listeCleSequencement_p);
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param retour_p
   *          the retour to set
   */
  public void setRetour(Retour retour_p)
  {
    _retour = retour_p;
  }

  /**
   * @param tracabilite_p
   *          the tracabilite to set
   */
  public void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }
}
