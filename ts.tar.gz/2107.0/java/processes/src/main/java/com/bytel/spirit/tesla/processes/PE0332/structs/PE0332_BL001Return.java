/*******************************************************************************
* $Id: PE0332_BL001Return.java 21437 2019-05-15 10:15:31Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0332.structs;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;
import com.bytel.spirit.common.shared.saab.rex.RequeteExploitation;
import com.bytel.spirit.common.shared.saab.rex.TemplateRequeteExploitation;

/**
 * Class that holds the retour and objects returned by BL001 of process PE0032.
 * 
 * @author jjoly
 * @version ($Revision: 21437 $ $Date: 2019-05-15 12:15:31 +0200 (mer. 15 mai 2019) $)
 */
public final class PE0332_BL001Return extends AbstractBLReturn
{
  /**
   * Unique Serial Version Identifier
   */
  private static final long serialVersionUID = 3152356505967507476L;

  /**
   * Object SAAB REX {@Code TemplateRequeteExploitation}
   */
  private TemplateRequeteExploitation _templateRequeteExploitation;

  /**
   * Object SAAB REX {@Code RequeteExploitation}
   */
  private RequeteExploitation _requeteExploitation;

  /**
   * Constructor
   *
   * @param retour_p
   *          Retour of BL001
   * @param templateRequeteExploitation_p
   *          TemplateRequeteExploitation object
   * @param requeteExploitation_p
   *          RequeteExploitation object
   */
  public PE0332_BL001Return(final Retour retour_p, final TemplateRequeteExploitation templateRequeteExploitation_p, final RequeteExploitation requeteExploitation_p)
  {
    super(retour_p);

    _templateRequeteExploitation = templateRequeteExploitation_p;
    _requeteExploitation = requeteExploitation_p;
  }

  /**
   * @return the requeteExploitation
   */
  public final RequeteExploitation getRequeteExploitation()
  {
    return _requeteExploitation;
  }

  /**
   * @return the templateRequeteExploitation
   */
  public final TemplateRequeteExploitation getTemplateRequeteExploitation()
  {
    return _templateRequeteExploitation;
  }

  /**
   * @param requeteExploitation_p
   *          the requeteExploitation to set
   */
  public void setRequeteExploitation(final RequeteExploitation requeteExploitation_p)
  {
    _requeteExploitation = requeteExploitation_p;
  }

  /**
   * @param templateRequeteExploitation_p
   *          the templateRequeteExploitation to set
   */
  public void setTemplateRequeteExploitation(final TemplateRequeteExploitation templateRequeteExploitation_p)
  {
    _templateRequeteExploitation = templateRequeteExploitation_p;
  }

}
