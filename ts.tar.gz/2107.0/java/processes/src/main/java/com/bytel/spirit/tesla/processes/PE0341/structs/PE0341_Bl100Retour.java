/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0341.structs;

import java.io.Serializable;

import com.bytel.ravel.common.business.generated.Retour;

/**
 *
 * @author aazzouzi
 * @version ($Revision$ $Date$)
 */
public class PE0341_Bl100Retour implements Serializable
{
  /**
   * Serial versionUID
   */
  private static final long serialVersionUID = -2850682241414669955L;

  /** Id notification reseau */
  private String _idNotificationReseau;

  /** Type notification reseau */
  private String _typeNotificationReseau;

  /**
   * Retour
   */
  private Retour _retour;

  /**
   * @param retour_p
   *          The retour
   */
  public PE0341_Bl100Retour(Retour retour_p)
  {
    super();
    _retour = retour_p;
  }

  /**
   * @param idNotificationReseau_p
   *          The id notification reseau
   * @param typeNotificationReseau_p
   *          The type notification reseau
   * @param retour_p
   *          The retour
   */
  public PE0341_Bl100Retour(String idNotificationReseau_p, String typeNotificationReseau_p, Retour retour_p)
  {
    super();
    _idNotificationReseau = idNotificationReseau_p;
    _typeNotificationReseau = typeNotificationReseau_p;
    _retour = retour_p;
  }

  /**
   * @return the idNotificationReseau
   */
  public String getIdNotificationReseau()
  {
    return _idNotificationReseau;
  }

  /**
   * @return the retour
   */
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * @return the typeNotificationReseau
   */
  public String getTypeNotificationReseau()
  {
    return _typeNotificationReseau;
  }

  /**
   * @param idNotificationReseau_p
   *          the idNotificationReseau to set
   */
  public void setIdNotificationReseau(String idNotificationReseau_p)
  {
    _idNotificationReseau = idNotificationReseau_p;
  }

  /**
   * @param retour_p
   *          the retour to set
   */
  public void setRetour(Retour retour_p)
  {
    _retour = retour_p;
  }

  /**
   * @param typeNotificationReseau_p
   *          the typeNotificationReseau to set
   */
  public void setTypeNotificationReseau(String typeNotificationReseau_p)
  {
    _typeNotificationReseau = typeNotificationReseau_p;
  }

}
