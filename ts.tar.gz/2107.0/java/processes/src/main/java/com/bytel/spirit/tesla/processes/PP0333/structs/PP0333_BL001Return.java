/*******************************************************************************
* $Id: PP0333_BL001Return.java 21437 2019-05-15 10:15:31Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PP0333.structs;

import java.io.Serializable;

import com.bytel.spirit.common.shared.saab.rex.DecisionExploitation;
import com.bytel.spirit.common.shared.saab.rex.RequeteExploitation;
import com.bytel.spirit.common.shared.saab.rex.TemplateRequeteExploitation;

/**
 * Class that holds the Retour and objects returned by BL001 of process PP0333
 *
 * @author jiantila
 * @version ($Revision: 21437 $ $Date: 2019-05-15 12:15:31 +0200 (mer. 15 mai 2019) $)
 */
public class PP0333_BL001Return implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -6578112233383463782L;

  /**
   * requete exploitation
   */
  private RequeteExploitation _requeteExploitation;

  /**
   * template requete exploitation
   */
  private TemplateRequeteExploitation _templateRequeteExploitation;

  /**
   * decision exploitation
   */
  private DecisionExploitation _decisionExploitation;

  /**
   * @return the decisionExploitation
   */
  public DecisionExploitation getDecisionExploitation()
  {
    return _decisionExploitation;
  }

  /**
   * @return the requeteExploitation
   */
  public RequeteExploitation getRequeteExploitation()
  {
    return _requeteExploitation;
  }

  /**
   * @return the templateRequeteExploitation
   */
  public TemplateRequeteExploitation getTemplateRequeteExploitation()
  {
    return _templateRequeteExploitation;
  }

  /**
   * @param decisionExploitation_p
   *          the decisionExploitation to set
   */
  public void setDecisionExploitation(DecisionExploitation decisionExploitation_p)
  {
    _decisionExploitation = decisionExploitation_p;
  }

  /**
   * @param requeteExploitation_p
   *          the requeteExploitation to set
   */
  public void setRequeteExploitation(RequeteExploitation requeteExploitation_p)
  {
    _requeteExploitation = requeteExploitation_p;
  }

  /**
   * @param templateRequeteExploitation_p
   *          the templateRequeteExploitation to set
   */
  public void setTemplateRequeteExploitation(TemplateRequeteExploitation templateRequeteExploitation_p)
  {
    _templateRequeteExploitation = templateRequeteExploitation_p;
  }
}
