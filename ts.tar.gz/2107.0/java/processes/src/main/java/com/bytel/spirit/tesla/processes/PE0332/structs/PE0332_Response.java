/*******************************************************************************
* $Id: PE0332_Response.java 21513 2019-05-16 07:45:08Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0332.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.squareup.moshi.Json;

/**
 * Class that holds the Retour and ResponseFonctionnelle of process PE0332
 *
 * @author jiantila
 * @version ($Revision: 21513 $ $Date: 2019-05-16 09:45:08 +0200 (jeu. 16 mai 2019) $)
 */
public class PE0332_Response implements Serializable
{

  /**
   * Define ReponseFonctionelle structure
   *
   * @author jgregori
   * @version ($Revision: 21513 $ $Date: 2019-05-16 09:45:08 +0200 (jeu. 16 mai 2019) $)
   */
  static final class ReponseFonctionnelle
  {
    /**
     * The map of key/value
     */
    @Json(name = "resultat")
    private List<Map<String, String>> _resultat;

    /**
     * Constructor
     *
     * @param resultat_p
     *          List of key/value pair. Represents a Resultat[] of STBL
     */
    public ReponseFonctionnelle(List<Map<String, String>> resultat_p)
    {
      super();
      _resultat = resultat_p != null ? new ArrayList<>(resultat_p) : null;
    }

    /**
     * @return the resultat
     */
    public List<Map<String, String>> getResultat()
    {
      return _resultat != null ? new ArrayList<>(_resultat) : null;
    }

  }

  /**
   *
   */
  private static final long serialVersionUID = -864956497672528081L;

  /**
   * Retour
   */

  @Json(name = "retour")
  private com.bytel.ravel.types.Retour _retour;

  /**
   * ReponseFonctionnelle
   */
  @Json(name = "reponseFonctionnelle")
  private ReponseFonctionnelle _reponseFonctionnelle;

  /**
   * @param retour_p
   *          Retour of process
   * @param result_p
   *          List of key/value pair. Represents a Resultat[] of STBL
   */
  public PE0332_Response(com.bytel.ravel.types.Retour retour_p, List<Map<String, String>> result_p)
  {
    _retour = retour_p;

    if (result_p != null)
    {
      _reponseFonctionnelle = new ReponseFonctionnelle(result_p);
    }

  }

  /**
   * @return the reponseFonctionnelle
   */
  public List<Map<String, String>> getResultat()
  {
    if (_reponseFonctionnelle != null)
    {
      return _reponseFonctionnelle.getResultat();
    }
    return null;
  }

  /**
   * @return the retour
   */
  public com.bytel.ravel.types.Retour getRetour()
  {
    return _retour;
  }

  /**
   * @param retour_p
   *          the retour to set
   */
  public void setRetour(com.bytel.ravel.types.Retour retour_p)
  {
    _retour = retour_p;
  }

}
