/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0341.sti;

import java.io.Serializable;
import java.util.Objects;

import com.squareup.moshi.Json;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0341_NotificationReseauPut implements Serializable
{
  /**
   * Serial versionUID
   */
  private static final long serialVersionUID = 7809842895736472190L;

  /** typeEvenement */
  @Json(name = "action")
  private String _action;

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if ((o_p == null) || (getClass() != o_p.getClass()))
    {
      return false;
    }
    PE0341_NotificationReseauPut that = (PE0341_NotificationReseauPut) o_p;
    return _action.equals(that._action);
  }

  /**
   * @return value of _action
   */
  public String getAction()
  {
    return _action;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_action);
  }

  /**
   * @param action_p
   *          The _action to set.
   */
  public void setAction(String action_p)
  {
    _action = action_p;
  }

  @Override
  public String toString()
  {
    return "PE0341_NotificationReseauPut [" + "_action=" + _action + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }
}
