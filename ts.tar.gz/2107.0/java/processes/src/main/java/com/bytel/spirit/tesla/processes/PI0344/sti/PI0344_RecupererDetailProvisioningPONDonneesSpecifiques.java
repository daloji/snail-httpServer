/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PI0344.sti;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.squareup.moshi.Json;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PI0344_RecupererDetailProvisioningPONDonneesSpecifiques implements Serializable
{
  /**
   * The serialVersionUID
   */
  private static final long serialVersionUID = 3416616669346336952L;

  /**
   * Model of the P2P Card
   */
  @Json(name = "modele")
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  private String _modele;

  /**
   * The Default Constructor
   */
  public PI0344_RecupererDetailProvisioningPONDonneesSpecifiques()
  {
    // The Default Constructor
  }

  /**
   * @param modele_p
   *          The Model of the P2P Card
   */
  public PI0344_RecupererDetailProvisioningPONDonneesSpecifiques(String modele_p)
  {
    super();
    _modele = modele_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0344_RecupererDetailProvisioningPONDonneesSpecifiques other = (PI0344_RecupererDetailProvisioningPONDonneesSpecifiques) obj;
    if (_modele == null)
    {
      if (other._modele != null)
      {
        return false;
      }
    }
    else if (!_modele.equals(other._modele))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the modele
   */
  public String getModele()
  {
    return _modele;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_modele == null) ? 0 : _modele.hashCode());
    return result;
  }

  /**
   * @param modele_p
   *          the modele to set
   */
  public void setModele(String modele_p)
  {
    _modele = modele_p;
  }

  @Override
  public String toString()
  {
    return "PI0344_RecupererDetailProvisioningPONDonneesSpecifiques [_modele=" + _modele + "]"; //$NON-NLS-1$ //$NON-NLS-2$
  }

}
