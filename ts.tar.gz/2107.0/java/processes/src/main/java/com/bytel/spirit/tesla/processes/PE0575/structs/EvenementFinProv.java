/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0575.structs;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.ravel.common.json.format.impl.Rfc3339LocalDateTime;
import com.squareup.moshi.Json;

/**
 *
 * @author jiantila
 * @version ($Revision$ $Date$)
 */
public class EvenementFinProv implements Serializable
{

  private static final long serialVersionUID = 1L;

  /**
   * Identifiant de la commande
   */
  @Json(name = "idCmd")
  private String _idCmd;

  /**
   *
   */
  @Json(name = "idModComm")
  private String _idModificationCommerciale;

  /**
   * Identifiant externe de la commande
   */
  @Json(name = "idExterne")
  private String _idExterne;

  /**
   * Date de publication de l'evenement
   */
  @Json(name = "dateTraitement")
  @RavelLocalDateTimeFormat(Rfc3339LocalDateTime.class)
  private LocalDateTime _dateTraitement;

  /**
   * Nature de la commande
   */
  @Json(name = "natureCommande")
  private String _natureCommande;

  /**
   * Statut de la commande
   */
  @Json(name = "statut")
  private String _statut;

  /**
   * Libellé d'erreur associé en cas de rejet ou de traitement NOK
   */
  @Json(name = "raison_Erreur")
  private String _raisonErreur;

  /**
   * le système technique à notifier
   */
  @Json(name = "systemeAppelant")
  private String _systemeAppelant;

  /**
   * client Operateur
   */
  @Json(name = "clientOperateur")
  private String _clientOperateur;

  /**
   * numéro du compte du client
   */
  @Json(name = "noCompte")
  private String _noCompte;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    EvenementFinProv other = (EvenementFinProv) obj;
    if (_clientOperateur == null)
    {
      if (other._clientOperateur != null)
      {
        return false;
      }
    }
    else if (!_clientOperateur.equals(other._clientOperateur))
    {
      return false;
    }
    if (_dateTraitement == null)
    {
      if (other._dateTraitement != null)
      {
        return false;
      }
    }
    else if (!_dateTraitement.equals(other._dateTraitement))
    {
      return false;
    }
    if (_idCmd == null)
    {
      if (other._idCmd != null)
      {
        return false;
      }
    }
    else if (!_idCmd.equals(other._idCmd))
    {
      return false;
    }
    if (_idExterne == null)
    {
      if (other._idExterne != null)
      {
        return false;
      }
    }
    else if (!_idExterne.equals(other._idExterne))
    {
      return false;
    }
    if (_idModificationCommerciale == null)
    {
      if (other._idModificationCommerciale != null)
      {
        return false;
      }
    }
    else if (!_idModificationCommerciale.equals(other._idModificationCommerciale))
    {
      return false;
    }
    if (_natureCommande == null)
    {
      if (other._natureCommande != null)
      {
        return false;
      }
    }
    else if (!_natureCommande.equals(other._natureCommande))
    {
      return false;
    }
    if (_noCompte == null)
    {
      if (other._noCompte != null)
      {
        return false;
      }
    }
    else if (!_noCompte.equals(other._noCompte))
    {
      return false;
    }
    if (_raisonErreur == null)
    {
      if (other._raisonErreur != null)
      {
        return false;
      }
    }
    else if (!_raisonErreur.equals(other._raisonErreur))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    if (_systemeAppelant == null)
    {
      if (other._systemeAppelant != null)
      {
        return false;
      }
    }
    else if (!_systemeAppelant.equals(other._systemeAppelant))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the dateTraitement
   */
  public LocalDateTime getDateTraitement()
  {
    return _dateTraitement;
  }

  /**
   * @return the idCmd
   */
  public String getIdCmd()
  {
    return _idCmd;
  }

  /**
   * @return the idExterne
   */
  public String getIdExterne()
  {
    return _idExterne;
  }

  /**
   * @return the idModificationCommerciale
   */
  public String getIdModificationCommerciale()
  {
    return _idModificationCommerciale;
  }

  /**
   * @return the natureCommande
   */
  public String getNatureCommande()
  {
    return _natureCommande;
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the raison_Erreur
   */
  public String getRaisonErreur()
  {
    return _raisonErreur;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the systemeAppelant
   */
  public String getSystemeAppelant()
  {
    return _systemeAppelant;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_clientOperateur == null) ? 0 : _clientOperateur.hashCode());
    result = (prime * result) + ((_dateTraitement == null) ? 0 : _dateTraitement.hashCode());
    result = (prime * result) + ((_idCmd == null) ? 0 : _idCmd.hashCode());
    result = (prime * result) + ((_idExterne == null) ? 0 : _idExterne.hashCode());
    result = (prime * result) + ((_idModificationCommerciale == null) ? 0 : _idModificationCommerciale.hashCode());
    result = (prime * result) + ((_natureCommande == null) ? 0 : _natureCommande.hashCode());
    result = (prime * result) + ((_noCompte == null) ? 0 : _noCompte.hashCode());
    result = (prime * result) + ((_raisonErreur == null) ? 0 : _raisonErreur.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    result = (prime * result) + ((_systemeAppelant == null) ? 0 : _systemeAppelant.hashCode());
    return result;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param dateTraitement_p
   *          the dateTraitement to set
   */
  public void setDateTraitement(LocalDateTime dateTraitement_p)
  {
    _dateTraitement = dateTraitement_p;
  }

  /**
   * @param idCmd_p
   *          the idCmd to set
   */
  public void setIdCmd(String idCmd_p)
  {
    _idCmd = idCmd_p;
  }

  /**
   * @param idExterne_p
   *          the idExterne to set
   */
  public void setIdExterne(String idExterne_p)
  {
    _idExterne = idExterne_p;
  }

  /**
   * @param idModificationCommerciale_p
   *          the idModificationCommerciale to set
   */
  public void setIdModificationCommerciale(String idModificationCommerciale_p)
  {
    _idModificationCommerciale = idModificationCommerciale_p;
  }

  /**
   * @param natureCommande_p
   *          the natureCommande to set
   */
  public void setNatureCommande(String natureCommande_p)
  {
    _natureCommande = natureCommande_p;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param raison_Erreur_p
   *          the raison_Erreur to set
   */
  public void setRaisonErreur(String raisonErreur_p)
  {
    _raisonErreur = raisonErreur_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param systemeAppelant_p
   *          the systemeAppelant to set
   */
  public void setSystemeAppelant(String systemeAppelant_p)
  {
    _systemeAppelant = systemeAppelant_p;
  }

  @Override
  public String toString()
  {
    return "EvenementFinProv [_idCmd=" + _idCmd + ", _idModificationCommerciale=" + _idModificationCommerciale + ", _idExterne=" + _idExterne + ", _dateTraitement=" + _dateTraitement + ", _natureCommande=" + _natureCommande + ", _statut=" + _statut + ", _raison_Erreur=" + _raisonErreur + ", _systemeAppelant=" + _systemeAppelant + ", _clientOperateur=" + _clientOperateur + ", _noCompte=" + _noCompte + "]"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$//$NON-NLS-4$//$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-11$
  }

}
