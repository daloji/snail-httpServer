/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0341;

import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.data.exchange.generated.RavelResponse.ResponseHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder;
import com.bytel.spirit.common.activities.shared.BL5400_DecoderSlid;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.structs.BL5400_Return;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.notification.AbstractNotificationReseau;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauONTInconnuJSON;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauRecommandationTvJSON;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauTypeEvenement;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.CleRechercheNotificationReseau;
import com.bytel.spirit.common.shared.saab.rex.NotificationReseauStatut;
import com.bytel.spirit.common.shared.saab.rex.NotificationReseauType;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheNotificationReseauRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateNotificationReseauStatutRequest;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL500_TraiterNotificationReseau;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL500_TraiterNotificationReseau.PE0341_BL500_TraiterNotificationReseauBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationReturn;
import com.bytel.spirit.tesla.processes.Messages;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigurationAChaudPE;
import com.bytel.spirit.tesla.processes.PE0341.config.TypeNotificationEnum;
import com.bytel.spirit.tesla.processes.PE0341.sti.PE0341_NotificationReseauPut;
import com.bytel.spirit.tesla.processes.PE0341.sti.PE0341_NotificationReseauSTI;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PE0341_NotificationReseau extends SpiritRestApiProcessSkeleton
{

  /**
   * Process context
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public static final class PE0341_NotificationReseauContext extends Context
  {

    /**
     * Serial UID
     */
    private static final long serialVersionUID = -8108995374327259698L;
    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0341_START;

    /**
     * configurationAChaudPE pour utiliser dans l'apelle de la BL500
     */
    private ConfigurationAChaudPE _configurationAChaudPE;

    /**
     * delaiTemporisation
     */
    private Integer _delaiTemporisation = 0;

    /**
     * Nombre de compensations.
     */
    private Integer _nombreCompensation = 0;

    /**
     * idRequest
     */
    private String _idRequest;

    /**
     * process
     */
    private String _process;

    /**
     * source
     */
    private String _source;

    /**
     * tracabilite
     */
    private Tracabilite _tracabilite;

    /**
     * Object {@code Retour} du processus
     */
    private Retour _processRetour;

    /**
     * locationHeaderUrlParameter
     */
    private String _locationHeaderUrlParameter;

    /**
     * notificationReseauSti
     */
    private PE0341_NotificationReseauSTI _notificationReseauSti;

    /**
     * notificationReseau
     */
    private AbstractNotificationReseau _abstractNotificationReseau;

    /**
     * bl002_Return
     */
    private Pair<Retour, ReponseErreur> _bl002Return;

    /**
     * idNotificationReseau
     */
    private String _idNotificationReseau;

    /**
     * @return the notificationReseau
     */
    public AbstractNotificationReseau getAbstractNotificationReseau()
    {
      return _abstractNotificationReseau;
    }

    /**
     * @return the bl002_Return
     */
    public Pair<Retour, ReponseErreur> getBl002Return()
    {
      return _bl002Return;
    }

    /**
     * @return the configurationAChaudPE
     */
    public ConfigurationAChaudPE getConfigurationAChaudPE()
    {
      return _configurationAChaudPE;
    }

    /**
     * @return the delaiTemporisation
     */
    public Integer getDelaiTemporisation()
    {
      return _delaiTemporisation;
    }

    /**
     * @return the idNotificationReseau
     */
    public String getIdNotificationReseau()
    {
      return _idNotificationReseau;
    }

    /**
     * @return value of _idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the locationHeaderUrlParameter
     */
    public String getLocationHeaderUrlParameter()
    {
      return _locationHeaderUrlParameter;
    }

    /**
     * Renvoyer le nombre de compensations.
     *
     * @return Nombre de compensations.
     */
    public Integer getNombreCompensation()
    {
      return _nombreCompensation;
    }

    /**
     * @return value of _notificationReseauSti
     */
    public PE0341_NotificationReseauSTI getNotificationReseauSti()
    {
      return _notificationReseauSti;
    }

    /**
     * @return value of _process
     */
    public String getProcess()
    {
      return _process;
    }

    /**
     * @return value of _processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return value of _source
     */
    public String getSource()
    {
      return _source;
    }

    /**
     * @return value of _state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the tracabilite
     */
    public Tracabilite getTracabilite()
    {
      return _tracabilite;
    }

    /**
     *
     * @param abstractNotificationReseau_p
     *          the notificationReseau to set
     */
    public void setAbstractNotificationReseau(AbstractNotificationReseau abstractNotificationReseau_p)
    {
      _abstractNotificationReseau = abstractNotificationReseau_p;
    }

    /**
     * @param bl002Return_p
     *          the bl002_Return to set
     */
    public void setBl002Return(Pair<Retour, ReponseErreur> bl002Return_p)
    {
      _bl002Return = bl002Return_p;
    }

    /**
     * @param configurationAChaudPE_p
     *          the configurationAChaudPE to set
     */
    public void setConfigurationAChaudPE(ConfigurationAChaudPE configurationAChaudPE_p)
    {
      _configurationAChaudPE = configurationAChaudPE_p;
    }

    /**
     * @param delaiTemporisation_p
     *          the delaiTemporisation to set
     */
    public void setDelaiTemporisation(Integer delaiTemporisation_p)
    {
      _delaiTemporisation = delaiTemporisation_p;
    }

    /**
     *
     * @param idNotificationReseau_p
     *          the idNotificationReseau to set
     */
    public void setIdNotificationReseau(String idNotificationReseau_p)
    {
      _idNotificationReseau = idNotificationReseau_p;
    }

    /**
     *
     * @param idRequest_p
     *          The _idRequest to set.
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param locationHeaderUrlParameter_p
     *          the locationHeaderUrlParameter to set
     */
    public void setLocationHeaderUrlParameter(String locationHeaderUrlParameter_p)
    {
      _locationHeaderUrlParameter = locationHeaderUrlParameter_p;
    }

    /**
     * Fixer le nombre de compensations.
     *
     * @param nombreCompensation_p
     *          Nombre de compensations.
     */
    public void setNombreCompensation(Integer nombreCompensation_p)
    {
      _nombreCompensation = nombreCompensation_p;
    }

    /**
     * @param notificationReseauSti_p
     *          The _notificationReseauSti to set.
     */
    public void setNotificationReseauSti(PE0341_NotificationReseauSTI notificationReseauSti_p)
    {
      _notificationReseauSti = notificationReseauSti_p;
    }

    /**
     * @param process_p
     *          The _process to set.
     */
    public void setProcess(String process_p)
    {
      _process = process_p;
    }

    /**
     * @param processRetour_p
     *          The _processRetour to set.
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param source_p
     *          The _source to set.
     */
    public void setSource(String source_p)
    {
      _source = source_p;
    }

    /**
     * @param state_p
     *          The _state to set.
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param tracabilite_p
     *          the tracabilite to set
     */
    public void setTracabilite(Tracabilite tracabilite_p)
    {
      _tracabilite = tracabilite_p;
    }
  }

  /**
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0341_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call BL001
     */
    PE0341_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL002
     */
    PE0341_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL005
     */
    PE0341_BL005(MandatoryProcessState.PRC_RUNNING, true, true),
    /**
     * Step to call BL100
     */
    PE0341_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PE0341_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PE0341_REX_UPDATE_AQUITTE
     */
    PE0341_REX_UPDATE_AQUITTE(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL210
     */
    PE0341_BL210(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL220
     */
    PE0341_BL220(MandatoryProcessState.PRC_RUNNING),
    /**
     * Initial step of continueProcess
     */
    PE0341_CONTINUE(MandatoryProcessState.PRC_RUNNING, true, true),
    /**
     * Step to call BL500
     */
    PE0341_BL500(MandatoryProcessState.PRC_SLEEPING, true, true),
    /**
     * Terminal state.
     */
    PE0341_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState;

    /**
     * Replayable state.
     */
    protected boolean _replayableState;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      this(technicalState_p, false, false);
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayableState_p
     *          true if is replayable
     * @param asynchronousState_p
     *          true if is asynchronous
     */
    State(final MandatoryProcessState technicalState_p, boolean replayableState_p, boolean asynchronousState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayableState_p;
      _asynchronousState = asynchronousState_p;
    }

  }

  /** Configuration path Param */
  private static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * PROFIL_TV
   */
  private static final String PROFIL_TV = "PROFIL_TV"; //$NON-NLS-1$

  /**
   * ONT_INCONNU
   */
  private static final String ONT_INCONNU = "ONT_INCONNU"; //$NON-NLS-1$

  /**
   * The constant for typeNotification process parameter
   */
  private static final String TYPE_NOTIFICATION = "typeNotification"; //$NON-NLS-1$

  /**
   * The constant for tempoMax process parameter
   */
  private static final String TEMPO_MAX = "tempoMax"; //$NON-NLS-1$

  /**
   * The constant for nbrCompensationMax process parameter
   */
  private static final String NBR_COMPENSATION_MAX = "nbrCompensationMax"; //$NON-NLS-1$

  /**
   * The constant for ParameterNullOrEmpty message
   */
  private static final String MESSAGE_PARAMETER_NULL_OR_EMPTY = Messages.getString("PE0341.ParameterNullOrEmpty"); //$NON-NLS-1$

  /**
   * The constant for ParameterInvalid message
   */
  private static final String MESSAGE_PARAMETER_INVALID = Messages.getString("PE0341.InvalideAttributeError"); //$NON-NLS-1$

  /**
   * The constant for HeaderNullOrEmpty message
   */
  private static final String MESSAGE_INVALID_HEADER = Messages.getString("PE0341.HeaderNullOrEmpty"); //$NON-NLS-1$

  /**
   * The constant for emptyBody message
   */
  private static final String MESSAGE_EMPTY_BODY = Messages.getString("PE0341.emptyBody"); //$NON-NLS-1$

  /**
   * The constant for noParam message
   */
  private static final String MESSAGE_NO_PARAM = Messages.getString("PE0341.noParam"); //$NON-NLS-1$

  /** The constant for FileError message */
  private static final String MESSAGE_FILE_ERROR = Messages.getString("PE0341.FileError"); //$NON-NLS-1$

  /**
   * The constant for noParam message
   */
  private static final String MESSAGE_NO_PARAM_A_CHAUD = Messages.getString("PE0341.noParamAChaud"); //$NON-NLS-1$

  /**
   * The constant for invalidConfigParam message
   */
  private static final String MESSAGE_INVALID_CONFIG_PARAM = Messages.getString("PE0341.invalidConfigParam"); //$NON-NLS-1$

  /**
   * The constant for invalidConfigParamLessThenZero message
   */
  private static final String MESSAGE_INVALID_CONFIG_PARAM_LESS_THAN_0 = Messages.getString("PE0341.invalidConfigParamLessThanZero"); //$NON-NLS-1$

  /**
   * The constant for invalidConfigParamLessThenZero message
   */
  private static final String MESSAGE_INVALID_CONFIG_PARAM_LESS_OR_EQUALS_TO_0 = Messages.getString("PE0341.invalidConfigParamLessOrEqualsToero"); //$NON-NLS-1$

  /**
   * ACTION constant
   */
  private static final String ACTION = "action"; //$NON-NLS-1$

  /**
   * TYPE_EVENEMENT constant
   */
  private static final String TYPE_EVENEMENT = "typeEvenement"; //$NON-NLS-1$

  /**
   * donneesOntInconnu constant
   */
  private static final String DONNEES_ONT_INCONNU = "donneesOntInconnu"; //$NON-NLS-1$

  /**
   * locationHeaderUrl constant
   */
  private static final String LOCATION_HEADER_URL_PARAM = "locationHeaderUrl"; //$NON-NLS-1$

  /**
   * PFI constant
   */
  private static final String PFI = "Pfi"; //$NON-NLS-1$

  /**
   * BSS_GP constant
   */
  private static final String BSS_GP = "BSS_GP"; //$NON-NLS-1$

  /**
   * CLIENT_OPERATEUR constant
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$
  /**
   * NO_COMPTE constant
   */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   * NOM_OLT constant
   */
  private static final String NOM_OLT = "nomOlt"; //$NON-NLS-1$

  /**
   * SLOT constant
   */
  private static final String SLOT = "slot"; //$NON-NLS-1$

  /**
   * PORT constant
   */
  private static final String PORT = "port"; //$NON-NLS-1$

  /**
   * SLID constant
   */
  private static final String SLID = "slid"; //$NON-NLS-1$

  /**
   * idNotificationReseau constant
   */
  private static final String ID_NOTIFICATION_RESEAU = "idNotificationReseau"; //$NON-NLS-1$

  /**
   * Serial UID
   */
  private static final long serialVersionUID = 4294880970038922561L;

  /**
   * Valid value in the action parameter
   */
  private static final String RELANCE = "relance"; //$NON-NLS-1$

  /**
   * The process context.
   */
  private PE0341_NotificationReseauContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p)
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  /**
   * @return the processContext
   */
  public PE0341_NotificationReseauContext getProcessContext()
  {
    return _processContext;
  }

  @Override
  public Duration getSleepTime()
  {
    try
    {
      return Duration.ofMillis(_processContext.getDelaiTemporisation().longValue());
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), exception));
      return Duration.ofMillis(30000L);
    }
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    super.initializeContext();
    _processContext = new PE0341_NotificationReseauContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  /**
   * @param processContext_p
   *          the processContext to set
   */
  public void setProcessContext(PE0341_NotificationReseauContext processContext_p)
  {
    _processContext = processContext_p;
  }

  @Override
  @LogContinueProcess
  protected void continuePostProcess(Tracabilite tracabilite_p)
  {
    _processContext.setTracabilite(tracabilite_p);
    try
    {
      asyncProcess(tracabilite_p);
      if (State.PE0341_BL005.equals(_processContext.getState()))
      {
        _processContext.setProcessRetour(PE0341_BL005_GererErreurPROSPERCreation(_processContext.getProcessRetour()));
        _processContext.setState(State.PE0341_END);
      }
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
      _processContext.setState(State.PE0341_END);
    }
    this.setRetour(_processContext.getProcessRetour());
  }

  @Override
  @LogContinueProcess
  protected void continuePutProcess(Tracabilite tracabilite_p)
  {
    try
    {
      asyncProcess(tracabilite_p);
      if (State.PE0341_BL005.equals(_processContext.getState()))
      {
        _processContext.setProcessRetour(PE0341_BL005_GererErreurProsperModification(_processContext.getProcessRetour()));
        _processContext.setState(State.PE0341_END);
      }
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
      _processContext.setState(State.PE0341_END);
    }
    this.setRetour(_processContext.getProcessRetour());
  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    return;
  }

  @Override
  protected void startMetroLog()
  {
    return;
  }

  @Override
  @LogStartProcess
  protected void startPostProcess(Request request_p, Tracabilite tracabilite_p)
  {
    _processContext.setTracabilite(tracabilite_p);
    try
    {
      _processContext.setState(State.PE0341_BL001);
      _processContext.setProcessRetour(PE0341_BL001_VerifierDonneesCreation(request_p, tracabilite_p));

      if (RetourFactory.isRetourOK(_processContext.getProcessRetour()))
      {
        _processContext.setState(State.PE0341_BL100);
        Pair<Retour, AbstractNotificationReseau> bl100Response = PE0341_BL100_CreerNotificationReseau(_processContext.getNotificationReseauSti(), tracabilite_p);

        _processContext.setProcessRetour(bl100Response._first);
        _processContext.setAbstractNotificationReseau(bl100Response._second);

        if (RetourFactory.isRetourOK(_processContext.getProcessRetour()))
        {
          _processContext.setState(State.PE0341_BL200);
          _processContext.setProcessRetour(PE0341_BL200_CreerCleRecherecheNotificationReseau(_processContext.getAbstractNotificationReseau(), tracabilite_p));
        }
      }
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), exception));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
    }
    finally
    {
      _processContext.setState(State.PE0341_BL002);
      _processContext.setBl002Return(PE0341_BL002_FormaterReponseCreation(_processContext.getProcessRetour()));
      _processContext.setProcessRetour(_processContext.getBl002Return()._first);

      syncPostResponse(request_p, tracabilite_p, _processContext.getBl002Return()._second, _processContext.getAbstractNotificationReseau());
      this.setRetour(_processContext.getProcessRetour());
      _processContext.setState(State.PE0341_CONTINUE);
    }
  }

  @Override
  @LogStartProcess
  protected void startPutProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = null;
    try
    {
      _processContext.setState(State.PE0341_BL001);
      Pair<Retour, AbstractNotificationReseau> retourBl001 = PE0341_BL001_VerifierDonneesModification(tracabilite_p, request_p);
      retour = retourBl001._first;
      if (RetourFactory.isRetourOK(retour))
      {
        _processContext.setState(State.PE0341_REX_UPDATE_AQUITTE);
        UpdateNotificationReseauStatutRequest updateReq = new UpdateNotificationReseauStatutRequest(retourBl001._second.getIdNotificationReseau(), NotificationReseauStatut.ACQUITTE.name());
        Pair<Retour, Nothing> returnREXModifierStatut = REXProxy.getInstance().notificationReseauModifierStatut(tracabilite_p, updateReq);
        retour = returnREXModifierStatut._first;
      }
    }
    catch (Exception ex)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), ex));
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex.getMessage());
    }
    finally
    {
      _processContext.setState(State.PE0341_BL002);
      Pair<Retour, ReponseErreur> bl002Result = PEI0341_BL002_FormaterReponseModification(retour);
      _processContext.setBl002Return(bl002Result);
      syncPutResponse(request_p, bl002Result);
      this.setRetour(bl002Result._first);
      _processContext.setState(State.PE0341_CONTINUE);
    }
  }

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   */
  private void asyncProcess(Tracabilite tracabilite_p)
  {
    if (State.PE0341_CONTINUE.equals(_processContext.getState()))
    {
      if (_processContext.getBl002Return()._second == null)
      {
        UpdateNotificationReseauStatutRequest updateNotificationReseauStatutRequest = new UpdateNotificationReseauStatutRequest(_processContext.getAbstractNotificationReseau().getIdNotificationReseau(), NotificationReseauStatut.EN_COURS.name());
        try
        {
          ConnectorResponse<Retour, Nothing> response = REXProxy.getInstance().notificationReseauModifierStatut(tracabilite_p, updateNotificationReseauStatutRequest);
          _processContext.setProcessRetour(response._first);
        }
        catch (RavelException exception)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
          _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
        }
        finally
        {
          if (RetourFactory.isRetourOK(_processContext.getProcessRetour()))
          {
            _processContext.setState(State.PE0341_BL500);
          }
          else
          {
            _processContext.setState(State.PE0341_BL005);
          }
        }
      }
      else
      {
        _processContext.setState(State.PE0341_BL005);
      }
    }

    if (State.PE0341_BL500.equals(_processContext.getState()))
    {
      PE0341_BL500_TraiterNotificationReseau.PE0341_BL500_TraiterNotificationReseauBuilder builderBL500 = new PE0341_BL500_TraiterNotificationReseauBuilder();

      builderBL500.tracabilite(tracabilite_p);
      builderBL500.configurationAChaudPE(_processContext.getConfigurationAChaudPE());
      builderBL500.nombreCompensation(_processContext.getNombreCompensation());
      builderBL500.notificationReseau(_processContext.getAbstractNotificationReseau());

      PE0341_BL500_TraiterNotificationReseau pe0341_BL500_TraiterNotificationReseau = builderBL500.build();
      TraiterNotificationReturn bl500Return = null;
      try
      {
        bl500Return = pe0341_BL500_TraiterNotificationReseau.execute(this);
        _processContext.setProcessRetour(pe0341_BL500_TraiterNotificationReseau.getRetour());
      }
      catch (RavelException exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
        _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
      }

      UpdateNotificationReseauStatutRequest updateNotificationReseauStatutRequest = null;
      if (RetourFactory.isRetourNOK(_processContext.getProcessRetour()))
      {
        if (bl500Return == null)
        {
          _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "BL500 returned a null TraiterNotificationReturn object")); //$NON-NLS-1$
        }
        else if (bl500Return.isCompenserTraitement())
        {
          _processContext.setDelaiTemporisation(bl500Return.getDelaiTemporisation());
          _processContext.setNombreCompensation(bl500Return.getNombreCompensation());

          return;
        }
        updateNotificationReseauStatutRequest = new UpdateNotificationReseauStatutRequest(_processContext.getAbstractNotificationReseau().getIdNotificationReseau(), NotificationReseauStatut.TRAITE_NOK.name());
        updateNotificationReseauStatutRequest.setCodeErreur(_processContext.getProcessRetour().getDiagnostic());
        updateNotificationReseauStatutRequest.setLibelleErreur(_processContext.getProcessRetour().getLibelle());
      }
      else
      {
        updateNotificationReseauStatutRequest = new UpdateNotificationReseauStatutRequest(_processContext.getAbstractNotificationReseau().getIdNotificationReseau(), NotificationReseauStatut.TRAITE_OK.name());
        if (bl500Return != null)
        {
          updateNotificationReseauStatutRequest.setIdCmd(bl500Return.getIdCmd());
        }
        else
        {
          _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "BL500 returned a null TraiterNotificationReturn object")); //$NON-NLS-1$
        }

      }

      try
      {
        ConnectorResponse<Retour, Nothing> response = REXProxy.getInstance().notificationReseauModifierStatut(tracabilite_p, updateNotificationReseauStatutRequest);
        _processContext.setProcessRetour(response._first);
      }
      catch (RavelException exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
        _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
      }
      _processContext.setState(State.PE0341_BL005);
    }
  }

  /**
   * @param idNotificationReseux_p
   *          {@link String}
   * @return {@link String}
   */
  private String constructLocationURI(final String idNotificationReseux_p)
  {

    String uri = _processContext.getLocationHeaderUrlParameter();

    if (uri.endsWith("/")) //$NON-NLS-1$
    {
      return uri + idNotificationReseux_p;
    }

    return uri + "/" + idNotificationReseux_p; //$NON-NLS-1$
  }

  /**
   *
   * return a {@link String} like "|nomOld|slot|port"
   *
   * @param notificationReseau_p
   *          {@link NotificationReseauONTInconnuJSON}
   * @return {@link String}
   */
  private String createPonPath(NotificationReseauONTInconnuJSON notificationReseau_p)
  {
    StringBuilder builder = new StringBuilder();
    builder.append("|"); //$NON-NLS-1$
    builder.append(notificationReseau_p.getNomOlt());
    builder.append("|"); //$NON-NLS-1$
    builder.append(notificationReseau_p.getPositionCartePon()); //slot
    builder.append("|"); //$NON-NLS-1$
    builder.append(notificationReseau_p.getPositionPon()); //port
    return builder.toString();
  }

  /**
   *
   * return a {@link String} like "clientOperateur|noCompte"
   *
   * @param notificationReseau_p
   *          {@link NotificationReseauRecommandationTvJSON}
   * @return {@link String}
   */
  private String createProfilTv(NotificationReseauRecommandationTvJSON notificationReseau_p)
  {
    StringBuilder builder = new StringBuilder();
    builder.append(notificationReseau_p.getClientOperateur());
    builder.append("|"); //$NON-NLS-1$
    builder.append(notificationReseau_p.getNoCompte());
    return builder.toString();
  }

  /**
   *
   * Validate process configuration
   *
   * @return Retour OK if all required parameters are well configured
   */
  private Retour loadConfiguration()
  {
    Retour retour = RetourFactory.createOkRetour();
    // Load config
    String configPE0341Param = getConfigParameter(PARAM_CONFIG_PATH);
    if (!StringTools.isNullOrEmpty(configPE0341Param))
    {
      try
      {
        Path configPE0341Path = Paths.get(configPE0341Param);
        String configPE0341File = new String(Files.readAllBytes(configPE0341Path));
        _processContext.setConfigurationAChaudPE(MarshallTools.unmarshall(ConfigurationAChaudPE.class, configPE0341File));
      }
      catch (Exception exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), exception));
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_FILE_ERROR, exception.getMessage()));
      }
    }
    else
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_NO_PARAM, PARAM_CONFIG_PATH)));
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, PARAM_CONFIG_PATH));
    }

    for (com.bytel.spirit.tesla.processes.PE0341.config.ConfigCompensationTraitementNotification configCompensationTraitementNotification : _processContext.getConfigurationAChaudPE().getListeConfigCompensationTraitementNotifications())
    {
      TypeNotificationEnum typeNotification = configCompensationTraitementNotification.getTypeNotification();
      if (typeNotification == null)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_NO_PARAM_A_CHAUD, TYPE_NOTIFICATION)));
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM_A_CHAUD, TYPE_NOTIFICATION));
      }

      if (!(NotificationReseauType.RECOMMANDATION_TV.name().equals(typeNotification.name()) || NotificationReseauType.ONT_INCONNU.name().equals(typeNotification.name())))
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_INVALID_CONFIG_PARAM, TYPE_NOTIFICATION, "RECOMMANDATION_TV, ONT_INCONNU"))); //$NON-NLS-1$
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_INVALID_CONFIG_PARAM, TYPE_NOTIFICATION, "RECOMMANDATION_TV, ONT_INCONNU")); //$NON-NLS-1$
      }

      BigInteger tempoMax = configCompensationTraitementNotification.getTempoMax();
      if (tempoMax == null)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_NO_PARAM_A_CHAUD, TEMPO_MAX)));
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM_A_CHAUD, TEMPO_MAX));
      }
      if (tempoMax.intValue() < 0)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_INVALID_CONFIG_PARAM_LESS_THAN_0, TEMPO_MAX)));
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_INVALID_CONFIG_PARAM_LESS_THAN_0, TEMPO_MAX));
      }

      BigInteger nbrCompensationMax = configCompensationTraitementNotification.getNbrMaxCompensation();
      if (nbrCompensationMax == null)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_NO_PARAM_A_CHAUD, NBR_COMPENSATION_MAX)));
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM_A_CHAUD, NBR_COMPENSATION_MAX));
      }
      if (nbrCompensationMax.intValue() <= 0)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_INVALID_CONFIG_PARAM_LESS_THAN_0, NBR_COMPENSATION_MAX)));
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_INVALID_CONFIG_PARAM_LESS_OR_EQUALS_TO_0, NBR_COMPENSATION_MAX));
      }
    }

    String locationHeaderUrlParam = getConfigParameter(LOCATION_HEADER_URL_PARAM);

    if (locationHeaderUrlParam == null)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_NO_PARAM, LOCATION_HEADER_URL_PARAM)));
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, LOCATION_HEADER_URL_PARAM));
    }

    _processContext.setLocationHeaderUrlParameter(locationHeaderUrlParam);

    return retour;
  }

  /**
   * Loads the parameter idNotificationReseau into the ProcessContext
   *
   * @param request_p
   *          request
   * @param tracabilite_p
   *          Tracabilite
   * @return Retour OK if idNotificationReseau is present in request, retour NOK otherwise
   */
  private Retour loadIdNotificationReseauIntoProcessContext(final Tracabilite tracabilite_p, final Request request_p)
  {
    // get url parameters
    String idNotificationReseau = request_p.getUrlDynamicParameters();

    if (StringTools.isNullOrEmpty(idNotificationReseau))
    {
      String libelleErreur = MessageFormat.format(MESSAGE_PARAMETER_NULL_OR_EMPTY, "idNotificationReseau"); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }
    _processContext.setIdNotificationReseau(idNotificationReseau);
    return RetourFactory.createOkRetour();
  }

  /**
   * Validates that each key in headersMap_p has a value in the request_p parameter, and if yes set the corresponding
   * value.
   *
   *
   * @param tracabilite_p
   *          The object tracabilite
   * @param request_p
   *          The request The original request containing all headers
   *
   * @return Retour OK if all the headers in the headersMap_p are set, NOK otherwise
   */
  private Retour parseRequestHeaders(Tracabilite tracabilite_p, final Request request_p)
  {
    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()))
      {
        _processContext.setIdRequest(header.getValue());
      }
      else if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        _processContext.setProcess(header.getValue());
      }
      else if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        _processContext.setSource(header.getValue());
      }
    }

    String libelleErreur;
    if (StringTools.isNullOrEmpty(_processContext.getIdRequest()))
    {
      libelleErreur = MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_REQUEST_ID);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, libelleErreur);
    }

    if (StringTools.isNullOrEmpty(_processContext.getProcess()))
    {
      libelleErreur = MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_PROCESS);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, libelleErreur);
    }

    if (StringTools.isNullOrEmpty(_processContext.getSource()))
    {
      libelleErreur = MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_SOURCE);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, libelleErreur);
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Validates that each key in headersMap_p has a value in the request_p parameter, and if yes set the corresponding
   * value.
   *
   *
   * @param tracabilite_p
   *          The object tracabilite
   * @param request_p
   *          The request The original request containing all headers
   *
   * @return Retour OK if all the headers in the headersMap_p are set, NOK otherwise
   */
  private Retour parseRequestHeadersModification(Tracabilite tracabilite_p, final Request request_p)
  {
    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()))
      {
        _processContext.setIdRequest(header.getValue());
      }
      else if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        _processContext.setProcess(header.getValue());
      }
      else if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        _processContext.setSource(header.getValue());
      }
    }

    String libelleErreur;
    if (StringTools.isNullOrEmpty(_processContext.getIdRequest()))
    {
      libelleErreur = MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_REQUEST_ID);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }

    if (StringTools.isNullOrEmpty(_processContext.getProcess()))
    {
      libelleErreur = MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_PROCESS);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }

    if (StringTools.isNullOrEmpty(_processContext.getSource()))
    {
      libelleErreur = MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_SOURCE);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Extracts and check the request url/body parameters
   *
   * @param request_p
   *          request
   * @return {@link Retour}
   *
   * @throws RavelException
   *           En cas d'erreur
   */
  private Retour parseRequestPayloadCreation(final Request request_p) throws RavelException
  {
    _processContext.setNotificationReseauSti(RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0341_NotificationReseauSTI.class));

    if (_processContext.getNotificationReseauSti() == null)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MESSAGE_EMPTY_BODY));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MESSAGE_EMPTY_BODY);
    }

    if (StringTools.isNullOrEmpty(_processContext.getNotificationReseauSti().getTypeEvenement()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_PARAMETER_NULL_OR_EMPTY, TYPE_EVENEMENT)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_PARAMETER_NULL_OR_EMPTY, TYPE_EVENEMENT));
    }

    if (NotificationReseauTypeEvenement.NEW_ONT_DISCOVERED.getDisplayName().equals(_processContext.getNotificationReseauSti().getTypeEvenement()) || NotificationReseauTypeEvenement.THE_GPON_ONT_IS_DISCOVERED_BY_OLT.getDisplayName().equals(_processContext.getNotificationReseauSti().getTypeEvenement()))
    {
      return validateRequestPayloadOntInconnu();
    }
    else if (NotificationReseauTypeEvenement.RECOMMANDATION_TV.getDisplayName().equals(_processContext.getNotificationReseauSti().getTypeEvenement()))
    {
      return validateRequestPayloadRecommandationTv();
    }
    else
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_PARAMETER_INVALID, TYPE_EVENEMENT, _processContext.getNotificationReseauSti().getTypeEvenement())));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_PARAMETER_INVALID, TYPE_EVENEMENT, _processContext.getNotificationReseauSti().getTypeEvenement()));
    }
  }

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param request_p
   *          {@link Request}
   * @return {@link Retour}
   * @throws RavelException
   *           if error
   */
  private Retour parseRequestPayloadModification(Tracabilite tracabilite_p, Request request_p) throws RavelException
  {

    PE0341_NotificationReseauPut body = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0341_NotificationReseauPut.class);

    if (body == null)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MESSAGE_EMPTY_BODY));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_EMPTY_BODY);
    }

    String libelleErreur;
    if (StringTools.isNullOrEmpty(body.getAction()))
    {
      libelleErreur = MessageFormat.format(MESSAGE_PARAMETER_NULL_OR_EMPTY, ACTION);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }
    if (!RELANCE.equals(body.getAction()))
    {
      libelleErreur = MessageFormat.format(MESSAGE_PARAMETER_INVALID, ACTION, body.getAction());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param request_p
   *          {@link Request} Object technique «virtuel» regroupant l'ensemble des informations fournies en entrées du
   *          service REST (PATH + paramètres de l'URL, headers http, body http)
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   *
   * @return {@link Retour}
   */
  @LogProcessBL
  private Retour PE0341_BL001_VerifierDonneesCreation(final Request request_p, Tracabilite tracabilite_p)
  {
    try
    {
      Retour retour = parseRequestHeaders(tracabilite_p, request_p);

      if (!RetourFactory.isRetourOK(retour))
      {
        return retour;
      }

      retour = parseRequestPayloadCreation(request_p);

      if (!RetourFactory.isRetourOK(retour))
      {
        return retour;
      }

      retour = loadConfiguration();

      if (!RetourFactory.isRetourOK(retour))
      {
        return retour;
      }

      return RetourFactory.createOkRetour();
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
    }
  }

  /**
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param request_p
   *          {@link Request}
   * @return {@link Pair}
   * @throws RavelException
   *           if error
   */
  private Pair<Retour, AbstractNotificationReseau> PE0341_BL001_VerifierDonneesModification(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    Retour retour = parseRequestHeadersModification(tracabilite_p, request_p);

    if (!RetourFactory.isRetourOK(retour))
    {
      return new Pair<>(retour, null);
    }

    retour = loadIdNotificationReseauIntoProcessContext(tracabilite_p, request_p);

    if (!RetourFactory.isRetourOK(retour))
    {
      return new Pair<>(retour, null);
    }

    retour = parseRequestPayloadModification(tracabilite_p, request_p);

    if (!RetourFactory.isRetourOK(retour))
    {
      return new Pair<>(retour, null);
    }

    retour = loadConfiguration();

    if (!RetourFactory.isRetourOK(retour))
    {
      return new Pair<>(retour, null);
    }

    ConnectorResponse<Retour, AbstractNotificationReseau> rexReturn = REXProxy.getInstance().notificationReseauLireUn(tracabilite_p, _processContext.getIdNotificationReseau());

    if (RetourFactory.isRetourOK(rexReturn._first))
    {
      _processContext.setAbstractNotificationReseau(rexReturn._second);
      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.ID_EXTERNE, _processContext.getIdRequest());
      refFonc.put(ID_NOTIFICATION_RESEAU, _processContext.getIdNotificationReseau());

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
      bl1700.execute(this);
    }

    return new Pair<>(rexReturn._first, rexReturn._second);
  }

  /**
   * @param retour_p
   *          The retour
   * @return {@link Pair <Retour, String> }
   */
  @LogProcessBL
  private Pair<Retour, ReponseErreur> PE0341_BL002_FormaterReponseCreation(Retour retour_p)
  {
    ReponseErreur reponseErreur = null;

    if (RetourFactory.isRetourNOK(retour_p))
    {
      reponseErreur = new ReponseErreur();
      reponseErreur.setError(retour_p.getDiagnostic());
      reponseErreur.setErrorDescription(retour_p.getLibelle());
    }

    return new Pair<>(retour_p, reponseErreur);
  }

  /**
   * @param retour_p
   *          The retour
   * @return @Retour
   */
  @LogProcessBL
  private Retour PE0341_BL005_GererErreurPROSPERCreation(Retour retour_p)
  {
    return retour_p;
  }

  /**
   * @param retour_p
   *          The retour
   * @return @Retour
   */
  @LogProcessBL
  private Retour PE0341_BL005_GererErreurProsperModification(Retour retour_p)
  {
    return retour_p;
  }

  /**
   *
   * @param notificationReseauSti_p
   *          The notificationReseauSti object
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @return {@link Pair}
   *
   * @throws RavelException
   *           Ravel Exception
   */
  @LogProcessBL
  private Pair<Retour, AbstractNotificationReseau> PE0341_BL100_CreerNotificationReseau(PE0341_NotificationReseauSTI notificationReseauSti_p, Tracabilite tracabilite_p) throws RavelException
  {
    BL800_ObtenirSequence bl800Resp = new BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder().tracabilite(tracabilite_p).code(UniqueIdConstant.ID_NOTIFICATION_RESEAU).build();
    String idNotificationReseau = bl800Resp.execute(this);

    if (!RetourFactory.isRetourOK(bl800Resp.getRetour()))
    {
      return new Pair<>(bl800Resp.getRetour(), null);
    }

    String typeNotificationReseau = null;

    if (NotificationReseauTypeEvenement.RECOMMANDATION_TV.name().equals(notificationReseauSti_p.getTypeEvenement()))
    {
      typeNotificationReseau = NotificationReseauType.RECOMMANDATION_TV.name();
    }
    else
    {
      typeNotificationReseau = NotificationReseauType.ONT_INCONNU.name();
    }

    AbstractNotificationReseau notificationReseau = null;

    if (NotificationReseauType.ONT_INCONNU.name().equals(typeNotificationReseau))
    {
      NotificationReseauONTInconnuJSON notificationReseauONT = new NotificationReseauONTInconnuJSON();
      notificationReseauONT.setNomOlt(notificationReseauSti_p.getDonneeOntInconnu().getNomOLT());
      notificationReseauONT.setPositionCartePon(notificationReseauSti_p.getDonneeOntInconnu().getSlot().toString());
      notificationReseauONT.setPositionPon(notificationReseauSti_p.getDonneeOntInconnu().getPort().toString());
      notificationReseauONT.setSlid(notificationReseauSti_p.getDonneeOntInconnu().getSlid());

      notificationReseau = notificationReseauONT;
    }
    else
    {
      NotificationReseauRecommandationTvJSON notificationReseauRecommandation = new NotificationReseauRecommandationTvJSON();
      notificationReseauRecommandation.setClientOperateur(notificationReseauSti_p.getPfi().getClientOperateur());
      notificationReseauRecommandation.setNoCompte(notificationReseauSti_p.getPfi().getNoCompte());

      notificationReseau = notificationReseauRecommandation;
    }

    LocalDateTime dateReception = null;
    LocalDateTime dateGenerationEvenementReseau = null;

    if (notificationReseauSti_p.getDateReception() == null)
    {
      dateReception = DateTimeManager.getInstance().now();
    }
    else
    {
      dateReception = notificationReseauSti_p.getDateReception();
    }

    if (notificationReseauSti_p.getDateGenerationEvenementReseau() == null)
    {
      dateGenerationEvenementReseau = dateReception;
    }
    else
    {
      dateGenerationEvenementReseau = notificationReseauSti_p.getDateGenerationEvenementReseau();
    }

    notificationReseau.setIdNotificationReseau(idNotificationReseau);
    notificationReseau.setTypeNotificationReseau(typeNotificationReseau);
    notificationReseau.setStatut(NotificationReseauStatut.ACQUITTE.name());
    notificationReseau.setDateReception(dateReception);
    notificationReseau.setDateGenerationEvenementReseau(dateGenerationEvenementReseau);
    notificationReseau.setNbRelance(0);

    ConnectorResponse<Retour, Nothing> rexResp = REXProxy.getInstance().notificationReseauCreer(tracabilite_p, notificationReseau);

    if (RetourFactory.isRetourNOK(rexResp._first))
    {
      return new Pair<>(rexResp._first, null);
    }

    return new Pair<>(rexResp._first, notificationReseau);
  }

  /**
   * @param notificationReseau_p
   *          {@link AbstractNotificationReseau}
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Retour}
   * @throws RavelException
   *           if errors
   */
  @LogProcessBL
  private Retour PE0341_BL200_CreerCleRecherecheNotificationReseau(AbstractNotificationReseau notificationReseau_p, Tracabilite tracabilite_p) throws RavelException

  {
    if (NotificationReseauType.ONT_INCONNU.name().equals(notificationReseau_p.getTypeNotificationReseau()))
    {
      return PE0341_BL210_CreerCleRecherecheNotifOntInconnu((NotificationReseauONTInconnuJSON) notificationReseau_p, tracabilite_p);
    }
    else if (NotificationReseauType.RECOMMANDATION_TV.name().equals(notificationReseau_p.getTypeNotificationReseau()))
    {
      return PE0341_BL220_CreerCleRecherecheProfilTv((NotificationReseauRecommandationTvJSON) notificationReseau_p, tracabilite_p);
    }
    return RetourFactory.createOkRetour();
  }

  /**
   *
   * @param notificationReseau_p
   *          {@link NotificationReseauONTInconnuJSON}
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Retour}
   * @throws RavelException
   *           if proxy got some error
   */
  @LogProcessBL
  private Retour PE0341_BL210_CreerCleRecherecheNotifOntInconnu(NotificationReseauONTInconnuJSON notificationReseau_p, Tracabilite tracabilite_p) throws RavelException
  {

    List<CleRechercheNotificationReseau> cles = new ArrayList<>();
    cles.add(new CleRechercheNotificationReseau(ONT_INCONNU, "SLID", notificationReseau_p.getSlid(), notificationReseau_p.getIdNotificationReseau())); //$NON-NLS-1$
    cles.add(new CleRechercheNotificationReseau(ONT_INCONNU, "PON_PATH", createPonPath(notificationReseau_p), notificationReseau_p.getIdNotificationReseau())); //$NON-NLS-1$

    BL5400_DecoderSlid bl5400_DecoderSlid = new BL5400_DecoderSlid.BL5400_DecoderSlidBuilder().tracabilite(tracabilite_p).slid(notificationReseau_p.getSlid()).build();
    try
    {
      BL5400_Return bl5400_Return = bl5400_DecoderSlid.execute(this);
      if (RetourFactory.isRetourOK(bl5400_DecoderSlid.getRetour()))
      {
        cles.add(new CleRechercheNotificationReseau(ONT_INCONNU, "SN_ONT", ("ONT_INCONNU|" + bl5400_Return.getNumeroSerieOnt()), notificationReseau_p.getIdNotificationReseau())); //$NON-NLS-1$ //$NON-NLS-2$
      }
    }
    catch (RavelException e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
    }

    return REXProxy.getInstance().cleRechercheNotificationReseau(tracabilite_p, new ListeCleRechercheNotificationReseauRequest(cles))._first;

  }

  /**
   * @param notificationReseau_p
   *          {@link NotificationReseauRecommandationTvJSON}
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Retour}
   * @throws RavelException
   *           if proxy got some error
   */
  @LogProcessBL
  private Retour PE0341_BL220_CreerCleRecherecheProfilTv(NotificationReseauRecommandationTvJSON notificationReseau_p, Tracabilite tracabilite_p) throws RavelException
  {
    List<CleRechercheNotificationReseau> cles = new ArrayList<>();
    cles.add(new CleRechercheNotificationReseau(PROFIL_TV, "PFI", createProfilTv(notificationReseau_p), notificationReseau_p.getIdNotificationReseau())); //$NON-NLS-1$

    return REXProxy.getInstance().cleRechercheNotificationReseau(tracabilite_p, new ListeCleRechercheNotificationReseauRequest(cles))._first;

  }

  /**
   *
   * @param retour_p
   *          {@link Retour}
   * @return {@link Pair}
   */
  private Pair<Retour, ReponseErreur> PEI0341_BL002_FormaterReponseModification(Retour retour_p)
  {
    ReponseErreur responseErreur = null;
    if (!RetourFactory.isRetourOK(retour_p))
    {
      responseErreur = new ReponseErreur();
      responseErreur.setError(retour_p.getDiagnostic());
      responseErreur.setErrorDescription(retour_p.getLibelle());
    }
    return new Pair<>(retour_p, responseErreur);
  }

  /**
   * Send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param tracabilite_p
   *          The tracabilite
   * @param reponserreur_p
   *          the reponserreur
   * @param notificationReseau_p
   *          te idNotificationReseux
   */
  private void syncPostResponse(Request request_p, Tracabilite tracabilite_p, ReponseErreur reponserreur_p, AbstractNotificationReseau notificationReseau_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

      if (reponserreur_p != null)
      {
        ErrorCode errorCode;

        try
        {
          ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponserreur_p, ReponseErreur.class));
        }
        catch (Exception ex)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
        }

        switch (reponserreur_p.getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
          case IMegSpiritConsts.ENTREE_INCORRECTE:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegConsts.CONFIGURATION_INVALIDE:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.ACCES_REFUSE:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        ResponseHeader location = new ResponseHeader();
        location.setName(IHttpHeadersConsts.LOCATION);
        location.setValue(constructLocationURI(notificationReseau_p.getIdNotificationReseau()));
        ravelResponse.getResponseHeader().add(location);
        request_p.setResponse(new Response(ErrorCode.OK_00201, ravelResponse));
      }
    }
  }

  /**
   * @param request_p
   *          {@link Retour}
   * @param bl002Result_p
   *          {@link Pair}
   * @throws RavelException
   *           if error
   */
  private void syncPutResponse(Request request_p, Pair<Retour, ReponseErreur> bl002Result_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp;
      ReponseErreur reponseErreur = bl002Result_p._second;

      if (reponseErreur != null)
      {
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

        ErrorCode errorCode;
        switch (reponseErreur.getError())
        {
          case IMegConsts.DONNEE_INCONNUE:
            reponseErreur.setError(IMegSpiritConsts.ENTREE_INCORRECTE);
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.NON_RESPECT_STI:
          case IMegSpiritConsts.ENTREE_INCORRECTE:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ID_NOTIFICATION_INNCONU:
          case IMegConsts.CONFIGURATION_INVALIDE:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.ERREUR_INTERNE:
            errorCode = ErrorCode.KO_00500;
            break;
          default:
            errorCode = ErrorCode.KO_00503;
        }

        if ((errorCode == ErrorCode.KO_00400) || (errorCode == ErrorCode.KO_00404))
        {
          ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur, ReponseErreur.class));
        }
        else
        {
          ravelResponse.setResult("{}"); //$NON-NLS-1$
        }

        rsp = new Response(errorCode, ravelResponse);
      }
      else
      {
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(new BasicResponse(RetourConverter.convertToJsonRetour(bl002Result_p._first)), BasicResponse.class));
        rsp = new Response(ErrorCode.OK_00202, ravelResponse);
      }
      request_p.setResponse(rsp);
    }

  }

  /**
   * @return {@link Retour}
   *
   */
  private Retour validateRequestPayloadOntInconnu()
  {
    if (_processContext.getNotificationReseauSti().getDonneeOntInconnu() == null)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_PARAMETER_INVALID, DONNEES_ONT_INCONNU, _processContext.getNotificationReseauSti().getDonneeOntInconnu())));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_PARAMETER_INVALID, DONNEES_ONT_INCONNU, _processContext.getNotificationReseauSti().getDonneeOntInconnu()));
    }

    if (StringTools.isNullOrEmpty(_processContext.getNotificationReseauSti().getDonneeOntInconnu().getNomOLT()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_PARAMETER_INVALID, NOM_OLT, _processContext.getNotificationReseauSti().getDonneeOntInconnu().getNomOLT())));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_PARAMETER_INVALID, NOM_OLT, _processContext.getNotificationReseauSti().getDonneeOntInconnu().getNomOLT()));
    }

    if (_processContext.getNotificationReseauSti().getDonneeOntInconnu().getSlot() == null)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_PARAMETER_INVALID, SLOT, _processContext.getNotificationReseauSti().getDonneeOntInconnu().getSlot())));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_PARAMETER_INVALID, SLOT, _processContext.getNotificationReseauSti().getDonneeOntInconnu().getSlot()));
    }
    if (_processContext.getNotificationReseauSti().getDonneeOntInconnu().getPort() == null)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_PARAMETER_INVALID, PORT, _processContext.getNotificationReseauSti().getDonneeOntInconnu().getPort())));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_PARAMETER_INVALID, PORT, _processContext.getNotificationReseauSti().getDonneeOntInconnu().getPort()));
    }

    if (StringTools.isNullOrEmpty(_processContext.getNotificationReseauSti().getDonneeOntInconnu().getSlid()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_PARAMETER_INVALID, SLID, _processContext.getNotificationReseauSti().getDonneeOntInconnu().getSlid())));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_PARAMETER_INVALID, SLID, _processContext.getNotificationReseauSti().getDonneeOntInconnu().getSlid()));
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * @return {@link Retour}
   *
   */
  private Retour validateRequestPayloadRecommandationTv()
  {
    if (_processContext.getNotificationReseauSti().getPfi() == null)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_PARAMETER_INVALID, PFI, _processContext.getNotificationReseauSti().getPfi())));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_PARAMETER_INVALID, PFI, _processContext.getNotificationReseauSti().getPfi()));
    }
    if (StringTools.isNullOrEmpty(_processContext.getNotificationReseauSti().getPfi().getClientOperateur()) || !_processContext.getNotificationReseauSti().getPfi().getClientOperateur().equals(BSS_GP))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_PARAMETER_INVALID, CLIENT_OPERATEUR, _processContext.getNotificationReseauSti().getPfi().getClientOperateur())));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_PARAMETER_INVALID, CLIENT_OPERATEUR, _processContext.getNotificationReseauSti().getPfi().getClientOperateur()));
    }

    if (StringTools.isNullOrEmpty(_processContext.getNotificationReseauSti().getPfi().getNoCompte()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext.getTracabilite(), MessageFormat.format(MESSAGE_PARAMETER_INVALID, CLIENT_OPERATEUR, _processContext.getNotificationReseauSti().getPfi().getNoCompte())));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(MESSAGE_PARAMETER_INVALID, NO_COMPTE, _processContext.getNotificationReseauSti().getPfi().getNoCompte()));
    }

    return RetourFactory.createOkRetour();

  }

}
