/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0341.structs;

import java.io.Serializable;

import com.bytel.ravel.common.business.generated.Retour;

/**
 * Structure de retour du BL500_TraiterNotificationReseau.
 * 
 * @author msilva
 */
public class PE0341_BL500Return implements Serializable
{

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = -7441041132220436061L;

  /**
   * retour
   */
  private Retour _retour;

  /**
   * Indique s'il faut compenser le traitement.
   */
  private Boolean _compenserTraitement;

  /**
   * delaiTemporisation
   */
  private Integer _delaiTemporisation;

  /**
   * idCmd
   */
  private String _idCmd;

  /**
   * @param retour_p
   *          {@link Retour}
   * @param compenserTraitement_p
   *          true s'il faut compenser le traitement. {@link Boolean}
   * @param delaiTemporisation_p
   *          {@link Integer}
   * @param idCmd_p
   *          {@link String}
   */
  public PE0341_BL500Return(Retour retour_p, Boolean compenserTraitement_p, Integer delaiTemporisation_p, String idCmd_p)
  {
    super();
    _retour = retour_p;
    _compenserTraitement = compenserTraitement_p;
    _delaiTemporisation = delaiTemporisation_p;
    _idCmd = idCmd_p;
  }

  @Override
  public boolean equals(Object obj) // NOSONAR
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0341_BL500Return other = (PE0341_BL500Return) obj;
    if (_delaiTemporisation == null)
    {
      if (other._delaiTemporisation != null)
      {
        return false;
      }
    }
    else if (!_delaiTemporisation.equals(other._delaiTemporisation))
    {
      return false;
    }
    if (_idCmd == null)
    {
      if (other._idCmd != null)
      {
        return false;
      }
    }
    else if (!_idCmd.equals(other._idCmd))
    {
      return false;
    }
    if (_compenserTraitement == null)
    {
      if (other._compenserTraitement != null)
      {
        return false;
      }
    }
    else if (!_compenserTraitement.equals(other._compenserTraitement))
    {
      return false;
    }
    if (_retour == null)
    {
      if (other._retour != null)
      {
        return false;
      }
    }
    else if (!_retour.equals(other._retour))
    {
      return false;
    }
    return true;
  }

  /**
   * Déterminer s'il faut compenser le traitement.
   *
   * @return true s'il faut compenser le traitement.
   */
  public Boolean getCompenserTraitement()
  {
    return _compenserTraitement;
  }

  /**
   * @return the delaiTemporisation
   */
  public Integer getDelaiTemporisation()
  {
    return _delaiTemporisation;
  }

  /**
   * @return the idCmd
   */
  public String getIdCmd()
  {
    return _idCmd;
  }

  /**
   * @return the retour
   */
  public Retour getRetour()
  {
    return _retour;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_delaiTemporisation == null) ? 0 : _delaiTemporisation.hashCode());
    result = (prime * result) + ((_idCmd == null) ? 0 : _idCmd.hashCode());
    result = (prime * result) + ((_compenserTraitement == null) ? 0 : _compenserTraitement.hashCode());
    result = (prime * result) + ((_retour == null) ? 0 : _retour.hashCode());
    return result;
  }

  /**
   * Indiquer s'il faut compenser le traitement.
   *
   * @param compenserTraitement_p
   *          true s'il faut le compenser.
   */
  public void setCompenserTraitement(Boolean compenserTraitement_p)
  {
    _compenserTraitement = compenserTraitement_p;
  }

  /**
   * @param delaiTemporisation_p
   *          the delaiTemporisation to set
   */
  public void setDelaiTemporisation(Integer delaiTemporisation_p)
  {
    _delaiTemporisation = delaiTemporisation_p;
  }

  /**
   * @param idCmd_p
   *          the idCmd to set
   */
  public void setIdCmd(String idCmd_p)
  {
    _idCmd = idCmd_p;
  }

  /**
   * @param retour_p
   *          the retour to set
   */
  public void setRetour(Retour retour_p)
  {
    _retour = retour_p;
  }

  @Override
  public String toString()
  {
    return "PE0341_BL500Return [_retour=" + _retour + ", _compenserTraitement=" + _compenserTraitement + ", _delaiTemporisation=" + _delaiTemporisation + ", _idCmd=" + _idCmd + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
  }

}
