/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PI0344.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author aazzouzi
 * @version ($Revision$ $Date$)
 */
public class PI0344_RecupererDetailProvisioningPONSti implements Serializable
{

  /**
   * Serial versionUID
   */
  private static final long serialVersionUID = -2738160789031157313L;

  /**
   * nomOlt
   */
  @Json(name = "nomOlt")
  private String _nomOlt;

  /**
   * positionCartePON
   */
  @Json(name = "positionCartePON")
  private Integer _positionCartePON;

  /**
   * @param nomOlt_p
   *          nomOlt
   * @param positionCartePON_p
   *          positionCartePON
   */
  public PI0344_RecupererDetailProvisioningPONSti(String nomOlt_p, Integer positionCartePON_p)
  {
    super();
    _nomOlt = nomOlt_p;
    _positionCartePON = positionCartePON_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0344_RecupererDetailProvisioningPONSti other = (PI0344_RecupererDetailProvisioningPONSti) obj;
    if (_nomOlt == null)
    {
      if (other._nomOlt != null)
      {
        return false;
      }
    }
    else if (!_nomOlt.equals(other._nomOlt))
    {
      return false;
    }
    if (_positionCartePON == null)
    {
      if (other._positionCartePON != null)
      {
        return false;
      }
    }
    else if (!_positionCartePON.equals(other._positionCartePON))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the nomOlt
   */
  public String getNomOlt()
  {
    return _nomOlt;
  }

  /**
   * @return the positionCartePON
   */
  public Integer getPositionCartePON()
  {
    return _positionCartePON;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_nomOlt == null) ? 0 : _nomOlt.hashCode());
    result = (prime * result) + ((_positionCartePON == null) ? 0 : _positionCartePON.hashCode());
    return result;
  }

  /**
   * @param nomOlt_p
   *          the nomOlt to set
   */
  public void setNomOlt(String nomOlt_p)
  {
    _nomOlt = nomOlt_p;
  }

  /**
   * @param positionCartePON_p
   *          the positionCartePON to set
   */
  public void setPositionCartePON(Integer positionCartePON_p)
  {
    _positionCartePON = positionCartePON_p;
  }

  @Override
  public String toString()
  {
    return "PI0344_RecupererDetailProvisioningPONSti [_nomOlt=" + _nomOlt + ", _positionCartePON=" + _positionCartePON + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

}
