/*******************************************************************************
* $Id: AlarmReseau.java 29590 2019-12-16 10:55:46Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0396.structs;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 *
 * @author jiantila
 * @version ($Revision: 29590 $ $Date: 2019-12-16 11:55:46 +0100 (lun. 16 déc. 2019) $)
 */
public class AlarmReseau implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * nomOlt
   */
  private String _nomOlt;

  /**
   * slot
   */
  private String _slot;

  /**
   * port
   */
  private String _port;

  /**
   * slid
   */
  private String _slid;

  /**
   * dateAlarme
   */
  private LocalDateTime _dateAlarme;
  /**
   * typeEvenement
   */
  private String _typeEvenement;

  /**
   * typeOlt
   */
  private String _typeOlt;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    AlarmReseau other = (AlarmReseau) obj;
    if (_dateAlarme == null)
    {
      if (other._dateAlarme != null)
      {
        return false;
      }
    }
    else if (!_dateAlarme.equals(other._dateAlarme))
    {
      return false;
    }
    if (_nomOlt == null)
    {
      if (other._nomOlt != null)
      {
        return false;
      }
    }
    else if (!_nomOlt.equals(other._nomOlt))
    {
      return false;
    }
    if (_port == null)
    {
      if (other._port != null)
      {
        return false;
      }
    }
    else if (!_port.equals(other._port))
    {
      return false;
    }
    if (_slid == null)
    {
      if (other._slid != null)
      {
        return false;
      }
    }
    else if (!_slid.equals(other._slid))
    {
      return false;
    }
    if (_slot == null)
    {
      if (other._slot != null)
      {
        return false;
      }
    }
    else if (!_slot.equals(other._slot))
    {
      return false;
    }
    if (_typeEvenement == null)
    {
      if (other._typeEvenement != null)
      {
        return false;
      }
    }
    else if (!_typeEvenement.equals(other._typeEvenement))
    {
      return false;
    }
    if (_typeOlt == null)
    {
      if (other._typeOlt != null)
      {
        return false;
      }
    }
    else if (!_typeOlt.equals(other._typeOlt))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateAlarme
   */
  public LocalDateTime getDateAlarme()
  {
    return _dateAlarme;
  }

  /**
   * @return the nomOlt
   */
  public String getNomOlt()
  {
    return _nomOlt;
  }

  /**
   * @return the port
   */
  public String getPort()
  {
    return _port;
  }

  /**
   * @return the slid
   */
  public String getSlid()
  {
    return _slid;
  }

  /**
   * @return the slot
   */
  public String getSlot()
  {
    return _slot;
  }

  /**
   * @return the typeEvenement
   */
  public String getTypeEvenement()
  {
    return _typeEvenement;
  }

  /**
   * @return the typeOlt
   */
  public String getTypeOlt()
  {
    return _typeOlt;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateAlarme == null) ? 0 : _dateAlarme.hashCode());
    result = (prime * result) + ((_nomOlt == null) ? 0 : _nomOlt.hashCode());
    result = (prime * result) + ((_port == null) ? 0 : _port.hashCode());
    result = (prime * result) + ((_slid == null) ? 0 : _slid.hashCode());
    result = (prime * result) + ((_slot == null) ? 0 : _slot.hashCode());
    result = (prime * result) + ((_typeEvenement == null) ? 0 : _typeEvenement.hashCode());
    result = (prime * result) + ((_typeOlt == null) ? 0 : _typeOlt.hashCode());
    return result;
  }

  /**
   * @param dateAlarme_p
   *          the dateAlarme to set
   */
  public void setDateAlarme(LocalDateTime dateAlarme_p)
  {
    _dateAlarme = dateAlarme_p;
  }

  /**
   * @param nomOlt_p
   *          the nomOlt to set
   */
  public void setNomOlt(String nomOlt_p)
  {
    _nomOlt = nomOlt_p;
  }

  /**
   * @param port_p
   *          the port to set
   */
  public void setPort(String port_p)
  {
    _port = port_p;
  }

  /**
   * @param slid_p
   *          the slid to set
   */
  public void setSlid(String slid_p)
  {
    _slid = slid_p;
  }

  /**
   * @param slot_p
   *          the slot to set
   */
  public void setSlot(String slot_p)
  {
    _slot = slot_p;
  }

  /**
   * @param typeEvenement_p
   *          the typeEvenement to set
   */
  public void setTypeEvenement(String typeEvenement_p)
  {
    _typeEvenement = typeEvenement_p;
  }

  /**
   * @param typeOlt_p
   *          the typeOlt to set
   */
  public void setTypeOlt(String typeOlt_p)
  {
    _typeOlt = typeOlt_p;
  }

  @Override
  public String toString()
  {
    return "AlarmReseau [_nomOlt=" + _nomOlt + ", _slot=" + _slot + ", _port=" + _port + ", _slid=" + _slid + ", _dateAlarme=" + _dateAlarme + ", _typeEvenement=" + _typeEvenement + ", _typeOlt=" + _typeOlt + "]"; //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$
  }

}
