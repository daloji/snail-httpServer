/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PI0344.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.squareup.moshi.Json;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PI0344_RecupererDetailProvisioningPONOlt implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 8778877666595413537L;
  /**
   * The OLT name
   */
  @Json(name = "nomOLT")
  private String _nomOLT;

  /**
   * The connection node name
   */
  @Json(name = "nomNR")
  private String _nomNR;

  /**
   * The manufacturer of the OLT
   */
  @Json(name = "constructeur")
  private String _constructeur;

  /**
   * The OLT model
   */
  @Json(name = "modele")
  private String _modele;

  /**
   * Version of the exchange interface
   */
  @Json(name = "versionInterfaceEchange")
  private String _versionInterfaceEchange;

  /**
   * Statut technique OLT
   */
  @Json(name = "statutTechnique")
  private String _statutTechnique;

  /**
   * Date of the last import
   */
  @Json(name = "dateDernierImport")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateDernierImport;

  /**
   * dateCreation attribute
   */
  @Json(name = "dateCreation")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateCreation;

  /**
   * dateModification attribute
   */
  @Json(name = "dateModification")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateModification;

  /**
   * nomOmc
   */
  @Json(name = "nomOmc")
  private String _nomOmc;

  /**
   * @param nomOLT_p
   *          nomOLT
   * @param nomNR_p
   *          nomNR
   * @param constructeur_p
   *          constructeur
   * @param modele_p
   *          modele
   * @param nomOmc_p
   *          nomOmc
   * @param versionInterfaceEchange_p
   *          versionInterfaceEchange
   * @param statutTechnique_p
   *          statut technique
   *
   */
  public PI0344_RecupererDetailProvisioningPONOlt(String nomOLT_p, String nomNR_p, String constructeur_p, String modele_p, String versionInterfaceEchange_p, String statutTechnique_p, String nomOmc_p)
  {
    super();
    _nomOLT = nomOLT_p;
    _nomNR = nomNR_p;
    _constructeur = constructeur_p;
    _modele = modele_p;
    _versionInterfaceEchange = versionInterfaceEchange_p;
    _statutTechnique = statutTechnique_p;
    _nomOmc = nomOmc_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0344_RecupererDetailProvisioningPONOlt other = (PI0344_RecupererDetailProvisioningPONOlt) obj;
    if (_constructeur == null)
    {
      if (other._constructeur != null)
      {
        return false;
      }
    }
    else if (!_constructeur.equals(other._constructeur))
    {
      return false;
    }
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }
    if (_dateDernierImport == null)
    {
      if (other._dateDernierImport != null)
      {
        return false;
      }
    }
    else if (!_dateDernierImport.equals(other._dateDernierImport))
    {
      return false;
    }
    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }
    if (_modele == null)
    {
      if (other._modele != null)
      {
        return false;
      }
    }
    else if (!_modele.equals(other._modele))
    {
      return false;
    }
    if (_nomNR == null)
    {
      if (other._nomNR != null)
      {
        return false;
      }
    }
    else if (!_nomNR.equals(other._nomNR))
    {
      return false;
    }
    if (_nomOLT == null)
    {
      if (other._nomOLT != null)
      {
        return false;
      }
    }
    else if (!_nomOLT.equals(other._nomOLT))
    {
      return false;
    }
    if (_nomOmc == null)
    {
      if (other._nomOmc != null)
      {
        return false;
      }
    }
    else if (!_nomOmc.equals(other._nomOmc))
    {
      return false;
    }
    if (_statutTechnique == null)
    {
      if (other._statutTechnique != null)
      {
        return false;
      }
    }
    else if (!_statutTechnique.equals(other._statutTechnique))
    {
      return false;
    }
    if (_versionInterfaceEchange == null)
    {
      if (other._versionInterfaceEchange != null)
      {
        return false;
      }
    }
    else if (!_versionInterfaceEchange.equals(other._versionInterfaceEchange))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the constructeur
   */
  public String getConstructeur()
  {
    return _constructeur;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateDernierImport
   */
  public LocalDateTime getDateDernierImport()
  {
    return _dateDernierImport;
  }

  /**
   * @return the dateModification
   */
  public LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the modele
   */
  public String getModele()
  {
    return _modele;
  }

  /**
   * @return the nomNR
   */
  public String getNomNR()
  {
    return _nomNR;
  }

  /**
   * @return the nomOLT
   */
  public String getNomOLT()
  {
    return _nomOLT;
  }

  /**
   * @return the nomOmc
   */
  public String getNomOmc()
  {
    return _nomOmc;
  }

  /**
   * @return the statutTechnique
   */
  public String getStatutTechnique()
  {
    return _statutTechnique;
  }

  /**
   * @return the versionInterfaceEchange
   */
  public String getVersionInterfaceEchange()
  {
    return _versionInterfaceEchange;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_constructeur == null) ? 0 : _constructeur.hashCode());
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateDernierImport == null) ? 0 : _dateDernierImport.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());
    result = (prime * result) + ((_modele == null) ? 0 : _modele.hashCode());
    result = (prime * result) + ((_nomNR == null) ? 0 : _nomNR.hashCode());
    result = (prime * result) + ((_nomOLT == null) ? 0 : _nomOLT.hashCode());
    result = (prime * result) + ((_nomOmc == null) ? 0 : _nomOmc.hashCode());
    result = (prime * result) + ((_statutTechnique == null) ? 0 : _statutTechnique.hashCode());
    result = (prime * result) + ((_versionInterfaceEchange == null) ? 0 : _versionInterfaceEchange.hashCode());
    return result;
  }

  /**
   * @param constructeur_p
   *          the constructeur to set
   */
  public void setConstructeur(String constructeur_p)
  {
    _constructeur = constructeur_p;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateDernierImport_p
   *          the dateDernierImport to set
   */
  public void setDateDernierImport(LocalDateTime dateDernierImport_p)
  {
    _dateDernierImport = dateDernierImport_p;
  }

  /**
   * @param dateModification_p
   *          the dateModification to set
   */
  public void setDateModification(LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param modele_p
   *          the modele to set
   */
  public void setModele(String modele_p)
  {
    _modele = modele_p;
  }

  /**
   * @param nomNR_p
   *          the nomNR to set
   */
  public void setNomNR(String nomNR_p)
  {
    _nomNR = nomNR_p;
  }

  /**
   * @param nomOLT_p
   *          the nomOLT to set
   */
  public void setNomOLT(String nomOLT_p)
  {
    _nomOLT = nomOLT_p;
  }

  /**
   * @param nomOmc_p
   *          the nomOmc to set
   */
  public void setNomOmc(String nomOmc_p)
  {
    _nomOmc = nomOmc_p;
  }

  /**
   * @param statutTechnique_p
   *          the statutTechnique to set
   */
  public void setStatutTechnique(String statutTechnique_p)
  {
    _statutTechnique = statutTechnique_p;
  }

  /**
   * @param versionInterfaceEchange_p
   *          the versionInterfaceEchange to set
   */
  public void setVersionInterfaceEchange(String versionInterfaceEchange_p)
  {
    _versionInterfaceEchange = versionInterfaceEchange_p;
  }

  @Override
  public String toString()
  {
    return "PI0344_RecupererDetailProvisioningPONOlt [_nomOLT=" + _nomOLT + ", _nomNR=" + _nomNR + ", _constructeur=" + _constructeur + ", _modele=" + _modele + ", _versionInterfaceEchange=" + _versionInterfaceEchange + ", _statutTechnique=" + _statutTechnique + ", _dateDernierImport=" + _dateDernierImport + ", _dateCreation=" + _dateCreation + ", _dateModification=" + _dateModification + ", _nomOmc=" + _nomOmc + "]";
  }

}
