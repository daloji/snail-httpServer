/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PI0574;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.UUID;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.parameter.ParameterManager;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL6000_PublierEvenementFinProv;
import com.bytel.spirit.common.activities.shared.structs.DemandePublierEvenementFinProv;
import com.bytel.spirit.common.config.Configuration;
import com.bytel.spirit.common.config.Parameter;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.diagnostic.EvenementFinProv;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.types.parameters.GenericConfigurationFilter;
import com.bytel.spirit.tesla.processes.Messages;
import com.bytel.spirit.tesla.processes.PI0574.sti.PI0574_EnvoyerModCommClotureRequest;

/**
 *
 * @author hduarte
 * @version ($Revision$ $Date$)
 */
public class PI0574_EnvoyerModCommCloture extends SpiritProcessSkeleton
{

  /**
   * The enum to imput parameters
   *
   * @author hduarte
   * @version ($Revision$ $Date$)
   */
  public enum Parameters
  {
    /**
     * L’identifiant de la commande
     */
    idCmd,

    /**
     * identifiant externe de la commande
     */
    idExterne,

    /**
     * identifiant d’une modification commerciale
     */
    idModComm,

    /**
     * nature de la commande
     */
    natureCommande,

    /**
     * statut de ModComm
     */
    statut,

    /**
     * Libellé d’erreur associé en cas de d’erreur de provisioning
     */
    raison_Erreur,

    /**
     * le système Apeplant
     */
    systemeAppelant,

    /**
     * le client Operateur
     */
    clientOperateur,

    /**
     * numéro du client
     */
    noCompte,
  }

  /**
   *
   * @author hduarte
   * @version ($Revision$ $Date$)
   */
  public static final class PI0574_EnvoyerModCommClotureContext extends Context
  {
    /**
     *
     */
    private static final long serialVersionUID = 5464379132605393306L;

    /** Contains the next step to execute. Initialized with the first step to execute. */
    private State _state = State.PI0574_START;

    /** Process Retour */
    private Retour _retour;

    /**
     *
     * idCmd
     *
     */
    private String _idCmd;

    /**
     *
     * idExterne
     *
     */
    private String _idExterne;

    /**
     *
     * idModComm
     *
     */
    private String _idModComm;

    /**
     *
     * natureCommande
     *
     */
    private String _natureCommande;

    /**
     * path config commande
     */
    private String _pathConfigCommande;

    /**
     *
     * statut
     *
     */
    private String _statut;

    /**
     *
     * raisonErreur
     *
     */
    private String _raisonErreur;

    /**
     *
     * systemeAppelant
     *
     */
    private String _systemeAppelant;

    /**
     *
     * clientOperateur
     *
     */
    private String _clientOperateur;

    /**
     *
     * noCompte
     *
     */
    private String _noCompte;

    /**
     * @return the clientOperateur
     */
    public String getClientOperateur()
    {
      return _clientOperateur;
    }

    /**
     * @return the idCmd
     */
    public String getIdCmd()
    {
      return _idCmd;
    }

    /**
     * @return the idExterne
     */
    public String getIdExterne()
    {
      return _idExterne;
    }

    /**
     * @return the idModComm
     */
    public String getIdModComm()
    {
      return _idModComm;
    }

    /**
     * @return the natureCommande
     */
    public String getNatureCommande()
    {
      return _natureCommande;
    }

    /**
     * @return the noCompte
     */
    public String getNoCompte()
    {
      return _noCompte;
    }

    /**
     * @return the pathConfigCommande
     */
    public String getPathConfigCommande()
    {
      return _pathConfigCommande;
    }

    /**
     * @return the raisonErreur
     */
    public String getRaisonErreur()
    {
      return _raisonErreur;
    }

    /**
     * @return the retour
     */
    public Retour getRetour()
    {
      return _retour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the statut
     */
    public String getStatut()
    {
      return _statut;
    }

    /**
     * @return the systemeAppelant
     */
    public String getSystemeAppelant()
    {
      return _systemeAppelant;
    }

    /**
     * @param clientOperateur_p
     *          the clientOperateur to set
     */
    public void setClientOperateur(String clientOperateur_p)
    {
      _clientOperateur = clientOperateur_p;
    }

    /**
     * @param idCmd_p
     *          the idCmd to set
     */
    public void setIdCmd(String idCmd_p)
    {
      _idCmd = idCmd_p;
    }

    /**
     * @param idExterne_p
     *          the idExterne to set
     */
    public void setIdExterne(String idExterne_p)
    {
      _idExterne = idExterne_p;
    }

    /**
     * @param idModComm_p
     *          the idModComm to set
     */
    public void setIdModComm(String idModComm_p)
    {
      _idModComm = idModComm_p;
    }

    /**
     * @param natureCommande_p
     *          the natureCommande to set
     */
    public void setNatureCommande(String natureCommande_p)
    {
      _natureCommande = natureCommande_p;
    }

    /**
     * @param noCompte_p
     *          the noCompte to set
     */
    public void setNoCompte(String noCompte_p)
    {
      _noCompte = noCompte_p;
    }

    /**
     * @param pathConfigCommande_p
     *          the pathConfigCommande to set
     */
    public void setPathConfigCommande(String pathConfigCommande_p)
    {
      _pathConfigCommande = pathConfigCommande_p;
    }

    /**
     * @param raisonErreur_p
     *          the raisonErreur to set
     */
    public void setRaisonErreur(String raisonErreur_p)
    {
      _raisonErreur = raisonErreur_p;
    }

    /**
     * @param retour_p
     *          the retour to set
     */
    public void setRetour(Retour retour_p)
    {
      _retour = retour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param statut_p
     *          the statut to set
     */
    public void setStatut(String statut_p)
    {
      _statut = statut_p;
    }

    /**
     * @param systemeAppelant_p
     *          the systemeAppelant to set
     */
    public void setSystemeAppelant(String systemeAppelant_p)
    {
      _systemeAppelant = systemeAppelant_p;
    }

  }

  /**
   *
   * @author hduarte
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The first step to execute
     */
    PI0574_START(MandatoryProcessState.PRC_START),
    /**
     * PI Step to call BL001
     */
    PI0574_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * PI Step to call BL002
     */
    PI0574_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * PI Step to call BL005
     */
    PI0574_BL005(MandatoryProcessState.PRC_RUNNING),
    /**
     * PI Step to call BL100
     */
    PI0574_BL100(MandatoryProcessState.PRC_RUNNING),

    /**
     * Step when process is running
     */
    PI0574_RUNNING(MandatoryProcessState.PRC_RUNNING),

    /**
     * Termimal state
     */
    PI0574_STOP(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayableState_p
     *          true if is replayable
     * @param asynchronousState_p
     *          true if is asynchronous
     */
    State(final MandatoryProcessState technicalState_p, boolean replayableState_p, boolean asynchronousState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayableState_p;
      _asynchronousState = asynchronousState_p;
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = -2662717345212008189L;

  /**
   * TRAITE String constant
   */
  private static final String TRAITE = "TRAITE"; //$NON-NLS-1$

  /**
   * TRAITE_OK String constant
   */
  private static final String TRAITE_OK = "TRAITE_OK"; //$NON-NLS-1$

  /**
   * publierEvenementFinProv String constant
   */
  private static final String PUBLIEREVENEMENTFINPROV = "publierEvenementFinProv"; //$NON-NLS-1$

  /**
   * PI0574 String constant
   */
  private static final String PI0574 = "PI0574"; //$NON-NLS-1$

  /**
   * FICHIER_CONFIGURATION param
   */
  private static final String FICHIER_CONFIGURATION = "fichierConfiguration"; //$NON-NLS-1$

  /**
   * Notif_SystemeAppelant_TTL parameter.
   */
  private Integer _notif_SystemeAppelant_TTL;

  /**
   * process context
   */
  private PI0574_EnvoyerModCommClotureContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PI0574_EnvoyerModCommClotureContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, Messages.getString("PI0574_EnvoyerModCommCloture.UnexpectedContinueProcessReceived")); //$NON-NLS-1$
  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    return;
  }

  @Override
  protected void startMetroLog()
  {
    return;
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();

    try
    {
      _processContext.setPathConfigCommande(getConfigParameter(FICHIER_CONFIGURATION));
      PI0574_EnvoyerModCommClotureRequest pi0574Request = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PI0574_EnvoyerModCommClotureRequest.class);

      _processContext.setState(State.PI0574_BL001);
      retour = PI0574_BL001_VerifierDonnees(tracabilite_p, pi0574Request);

      if (RetourFactory.isRetourOK(retour))
      {
        _processContext.setState(State.PI0574_BL100);
        Pair<EvenementFinProv, Retour> bl100Retour = PI0574_BL100_ConstruireEvenement(tracabilite_p);
        retour = bl100Retour._second;
      }
    }
    catch (Exception ex)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
    }
    finally
    {
      _processContext.setState(State.PI0574_BL002);
      retour = PI0574_BL002_FormaterResponse(tracabilite_p, retour, request_p);

      _processContext.setState(State.PI0574_BL005);
      retour = PI0574_BL005_GererErreurPROSPER(retour);

      _processContext.setState(State.PI0574_STOP);
      this.setRetour(retour);
    }
  }

  /**
   * Check the request parameters
   *
   * @param pi0574Request_p
   *          the request
   * @return {@link Retour}
   *
   * @throws RavelException
   *           In case of an error
   */
  private Retour checkRequestParameters(final PI0574_EnvoyerModCommClotureRequest pi0574Request_p) throws RavelException
  {

    // Read config
    Configuration config = ParameterManager.getInstance().findOne("configEvenementFinProv", new GenericConfigurationFilter()); //$NON-NLS-1$

    for (Parameter param : config.getParameter())
    {

      if ("notif_SystemeAppelant_TTL".equals(param.getKey())) //$NON-NLS-1$
      {
        _notif_SystemeAppelant_TTL = Integer.parseInt(param.getValue());
      }
    }
    if (null == _notif_SystemeAppelant_TTL)
    {
      _notif_SystemeAppelant_TTL = 259200;
    }

    if (pi0574Request_p == null)
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PI0574.emptyBody")); //$NON-NLS-1$
    }

    String idCmd = pi0574Request_p.getIdCmd();
    if (StringTools.isNullOrEmpty(idCmd))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0574.BL001.ParameterNullOrEmpty"), Parameters.idCmd.name())); //$NON-NLS-1$
    }

    String idExterne = pi0574Request_p.getIdExterne();
    if (StringTools.isNullOrEmpty(idExterne))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0574.BL001.ParameterNullOrEmpty"), Parameters.idExterne.name())); //$NON-NLS-1$
    }

    String idModComm = pi0574Request_p.getIdModComm();
    if (StringTools.isNullOrEmpty(idModComm))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0574.BL001.ParameterNullOrEmpty"), Parameters.idModComm.name())); //$NON-NLS-1$
    }

    String natureCommande = pi0574Request_p.getNatureCommande();
    if (StringTools.isNullOrEmpty(natureCommande))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0574.BL001.ParameterNullOrEmpty"), Parameters.natureCommande.name())); //$NON-NLS-1$
    }

    String statut = pi0574Request_p.getStatut();
    if (StringTools.isNullOrEmpty(statut))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0574.BL001.ParameterNullOrEmpty"), Parameters.statut.name())); //$NON-NLS-1$
    }
    if (!TRAITE.equalsIgnoreCase(statut))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0574.BL001.InvalideAttributeError"), Parameters.statut.name(), statut)); //$NON-NLS-1$
    }

    String raison_Erreur = pi0574Request_p.getRaisonErreur();

    String systemeAppelant = pi0574Request_p.getSystemeAppelant();
    if (StringTools.isNullOrEmpty(systemeAppelant))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0574.BL001.ParameterNullOrEmpty"), Parameters.systemeAppelant.name())); //$NON-NLS-1$
    }

    String clientOperateur = pi0574Request_p.getClientOperateur();
    if (StringTools.isNullOrEmpty(clientOperateur))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0574.BL001.ParameterNullOrEmpty"), Parameters.clientOperateur.name())); //$NON-NLS-1$
    }

    String noCompte = pi0574Request_p.getNoCompte();
    if (StringTools.isNullOrEmpty(noCompte))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, MessageFormat.format(Messages.getString("PI0574.BL001.ParameterNullOrEmpty"), Parameters.noCompte.name())); //$NON-NLS-1$
    }

    _processContext.setIdCmd(idCmd);
    _processContext.setIdExterne(idExterne);
    _processContext.setIdModComm(idModComm);
    _processContext.setNatureCommande(natureCommande);
    _processContext.setStatut(statut);
    _processContext.setRaisonErreur(raison_Erreur);
    _processContext.setSystemeAppelant(systemeAppelant);
    _processContext.setClientOperateur(clientOperateur);
    _processContext.setNoCompte(noCompte);

    return RetourFactory.createOkRetour();
  }

  /**
   *
   * @param tracabilite_p
   *          The trace
   * @param pi0574Request_p
   *          the request
   * @return {@link Retour}
   *
   * @throws RavelException
   *           on errors
   */
  @LogProcessBL
  private Retour PI0574_BL001_VerifierDonnees(Tracabilite tracabilite_p, final PI0574_EnvoyerModCommClotureRequest pi0574Request_p) throws RavelException
  {
    try
    {
      return checkRequestParameters(pi0574Request_p);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PI0574.BL001.StiError") + "\\n" + ExceptionTools.getStringStackTrace(e))); //$NON-NLS-1$ //$NON-NLS-2$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PI0574.BL001.StiError")); //$NON-NLS-1$
    }
  }

  /**
   * PI0521 BL002 FormaterResponse
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param retour_p
   *          Retour
   * @param request_p
   *          the request
   * @return Retour
   *
   * @throws RavelException
   *           En cas d'erreur
   */
  @LogProcessBL
  private Retour PI0574_BL002_FormaterResponse(Tracabilite tracabilite_p, Retour retour_p, Request request_p) throws RavelException
  {
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    ReponseErreur reponseErreur = null;

    if (RetourFactory.isRetourNOK(retour_p))
    {
      reponseErreur = new ReponseErreur();
      reponseErreur.setError(retour_p.getDiagnostic());
      reponseErreur.setErrorDescription(retour_p.getLibelle());

      try
      {
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur, ReponseErreur.class));
      }
      catch (Exception ex)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
      }
    }
    else
    {
      ravelResponse.setResult(RavelJsonTools.getInstance().toJson(retour_p, Retour.class));
    }

    request_p.setResponse(new Response(ErrorCode.OK_00200, ravelResponse));

    return retour_p;
  }

  /**
   * PE0396_BL005_GererErreurPROSPER
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retour_p
   *          retour input
   * @return retour
   */
  @LogProcessBL
  private Retour PI0574_BL005_GererErreurPROSPER(Retour retour_p)
  {
    retour_p = RetourFactory.createOkRetour();
    return retour_p;
  }

  /**
   * Main treatment BL.
   *
   * @param tracabilite_p
   *          tracabilite
   * @return Pair<EvenementFinProv, Retour>
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Pair<EvenementFinProv, Retour> PI0574_BL100_ConstruireEvenement(Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();

    EvenementFinProv evenementFinProv = new EvenementFinProv();
    evenementFinProv.setIdCmd(_processContext.getIdCmd());
    evenementFinProv.setIdExterne(_processContext.getIdExterne());
    evenementFinProv.setIdModComm(_processContext.getIdModComm());
    evenementFinProv.setDateTraitement(DateTimeManager.getInstance().now());
    evenementFinProv.setNatureCommande(_processContext.getNatureCommande());

    if (_processContext.getStatut().equals(TRAITE))
    {
      evenementFinProv.setStatut(TRAITE_OK);
    }
    evenementFinProv.setRaisonErreur(_processContext.getRaisonErreur());
    evenementFinProv.setSystemeAppelant(_processContext.getSystemeAppelant());
    evenementFinProv.setClientOperateur(_processContext.getClientOperateur());
    evenementFinProv.setNoCompte(_processContext.getNoCompte());

    String callerId = UUID.randomUUID().toString();

    DemandePublierEvenementFinProv demandePublierEvenementFinProv = new DemandePublierEvenementFinProv(evenementFinProv, _notif_SystemeAppelant_TTL, PUBLIEREVENEMENTFINPROV, PI0574, callerId);

    BL6000_PublierEvenementFinProv bl6000 = new BL6000_PublierEvenementFinProv.BL6000_PublierEvenementFinProvBuilder()//
        .tracabilite(tracabilite_p)//
        .demandePublierEvenementFinProv(demandePublierEvenementFinProv)//
        .configuration(_processContext.getPathConfigCommande())//
        .build();

    EvenementFinProv bl6000Retour = bl6000.execute(this);

    if (RetourFactory.isRetourNOK(bl6000.getRetour()))
    {
      retour = bl6000.getRetour();
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, retour.getLibelle()));
      return new Pair<>(bl6000Retour, retour);
    }
    return new Pair<>(bl6000Retour, retour);
  }

}
