/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0529.structs;

import static org.apache.commons.lang3.StringUtils.isBlank;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.bytel.spirit.common.shared.saab.res.RessourcePortPM;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacte;
import com.bytel.spirit.common.shared.saab.rex.ClientImpacteStatutProvisionning;

/**
 * Objet contenant les impacts client sur le provisioning de l'operation vie reseau
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public abstract class ProvisioningVDR
{

  /**
   * Client Impacte
   */
  protected ClientImpacte _clientImpacte;

  /**
   * Liste des cles de sequencement
   */
  protected List<String> _listeCleSequencement;

  /**
   * Numero Compte
   */
  protected String _noCompte;

  /**
   * Client Operateur
   */
  protected String _clientOperateur;

  /**
   * Ressource Port PM du provisioning
   */
  protected RessourcePortPM _ressourcePortPM;

  /**
   * Flag true si le client a un ticket de lissage de charge actif
   */
  protected boolean _ticketLissage = false;

  /**
   * Constructeur
   *
   * @param clientImpacte_p
   *      the clientImpacte to set
   */
  public ProvisioningVDR(ClientImpacte clientImpacte_p)
  {
    _clientImpacte = clientImpacte_p;
  }

  /**
   * Add a cleSequencement to _listeCleSequencement
   *
   * @param cleSequencement_p
   *      the cleSequencement to add.
   */
  public void addCleSequencement(final String cleSequencement_p)
  {
    if(_listeCleSequencement == null)
    {
      _listeCleSequencement = new ArrayList<>();
    }
    _listeCleSequencement.add(cleSequencement_p);
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    ProvisioningVDR that = (ProvisioningVDR) o_p;
    return Objects.equals(_clientImpacte, that._clientImpacte) && Objects.equals(_listeCleSequencement, that._listeCleSequencement) && Objects.equals(_noCompte, that._noCompte) && Objects.equals(_clientOperateur, that._clientOperateur);
  }

  /**
   * @return value of _clientImpacte.
   */
  public ClientImpacte getClientImpacte()
  {
    return _clientImpacte;
  }

  /**
   * @return value of _clientOperateur.
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * Identifiant du port impacté (source pour Migration et portPm pour Modification)
   *
   * @return Identifiant du port
   */
  public abstract String getIdPortImpacte();

  /**
   * @return value of _listeCleSequencement.
   */
  public List<String> getListeCleSequencement()
  {
    return _listeCleSequencement == null ? new ArrayList<>() : new ArrayList<>(_listeCleSequencement);
  }

  /**
   * @return value of _noClient.
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return value of _ressourcePortPM.
   */
  public RessourcePortPM getRessourcePortPM()
  {
    return _ressourcePortPM;
  }

  /**
   * Verifie si le clientImpacte possede un identifiant
   *
   * @return true si clientImpacte.identifiantClient est non null
   */
  public boolean hasIdentifiantClient()
  {
    return (_clientImpacte != null && !isBlank(_clientImpacte.getIdentifiantClient()));
  }

  /**
   * @return value of _ticketLissage.
   */
  public boolean hasTicketLissage()
  {
    return _ticketLissage;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(_clientImpacte, _listeCleSequencement, _noCompte, _clientOperateur, _ticketLissage);
  }

  /**
   * Verifie si le clientImpacte n'est pas NOK
   *
   * @return true si clientImpacte.statutProvisioning != NOK
   */
  public boolean isNotNOK()
  {
    return (_clientImpacte != null && (isBlank(_clientImpacte.getStatutProvisioning()) || !ClientImpacteStatutProvisionning.NOK.equals(ClientImpacteStatutProvisionning.valueOf(_clientImpacte.getStatutProvisioning()))));
  }

  /**
   * Verifie si noCompte et clientOperateur existent
   *
   * @return true si noCompte et clientOperateur existent
   */
  public boolean noCompteExists()
  {
    return (_noCompte != null && _clientOperateur != null);
  }

  /**
   * @param clientImpacte_p
   *     the _clientImpacte to set.
   */
  public void setClientImpacte(final ClientImpacte clientImpacte_p)
  {
    _clientImpacte = clientImpacte_p;
  }

  /**
   * @param clientOperateur_p
   *     the _clientOperateur to set.
   */
  public void setClientOperateur(final String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param listeCleSequencement_p
   *     the _listeCleSequencement to set.
   */
  public void setListeCleSequencement(final List<String> listeCleSequencement_p)
  {
    _listeCleSequencement = listeCleSequencement_p == null ? null : new ArrayList<>(listeCleSequencement_p);
  }

  /**
   * @param noCompte_p
   *     the _noClient to set.
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param ressourcePortPM_p
   *     the _ressourcePortPM to set.
   */
  public void setRessourcePortPM(RessourcePortPM ressourcePortPM_p)
  {
    _ressourcePortPM = ressourcePortPM_p;
  }

  /**
   * @param ticketLissage_p
   *     the _ticketLissage to set.
   */
  public void setTicketLissage(boolean ticketLissage_p)
  {
    _ticketLissage = ticketLissage_p;
  }

  @Override
  public String toString()
  {
    return "ProvisioningVDR [" + "_clientImpacte=" + _clientImpacte + ", _listeCleSequencement=" + _listeCleSequencement + ", _noCompte=" + _noCompte + ", _clientOperateur=" + _clientOperateur + ", _ressourcePortPM=" + _ressourcePortPM + ", _ticketLissage=" + _ticketLissage + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$ // $NON-NLS-6$ // $NON-NLS-7$ // $NON-NLS-8$
  }
}
