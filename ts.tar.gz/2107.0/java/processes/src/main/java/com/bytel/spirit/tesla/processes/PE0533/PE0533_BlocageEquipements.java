/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0533;

import static java.util.Objects.hash;
import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;
import static org.apache.commons.collections4.CollectionUtils.isEmpty;
import static org.apache.commons.collections4.SetUtils.difference;
import static org.apache.commons.collections4.SetUtils.union;
import static org.apache.commons.lang3.StringUtils.defaultString;
import static org.apache.commons.lang3.StringUtils.isBlank;

import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.StringJoiner;
import java.util.TreeSet;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.NotNull;
import javax.ws.rs.HttpMethod;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.IRavelJsonAdapter;
import com.bytel.ravel.common.json.RavelJson.RavelJsonBuilder;
import com.bytel.ravel.common.json.RavelJsonException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.AbstractBLReturn;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.bytel.spirit.common.shared.saab.res.StatutBlockage;
import com.bytel.spirit.common.shared.saab.res.TypeIdentifiant;
import com.bytel.spirit.common.shared.saab.rex.BlocageEquipement;
import com.bytel.spirit.common.shared.saab.rex.BlocageEquipementStatut;
import com.bytel.spirit.common.shared.saab.rex.CleRechercheBlocageEquipement;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseau;
import com.bytel.spirit.common.shared.saab.rex.OperationVieReseauStatut;
import com.bytel.spirit.common.shared.saab.rex.request.ListeCleRechercheBlocageEquipementRequest;
import com.bytel.spirit.common.shared.saab.rex.request.UpdateBlocageEquipementRequest;
import com.bytel.spirit.tesla.processes.Messages;
import com.bytel.spirit.tesla.shared.types.PE0529.request.PE0529_PostRequest;
import com.bytel.spirit.tesla.shared.types.PE0533.Equipement;
import com.bytel.spirit.tesla.shared.types.PE0533.OLT;
import com.bytel.spirit.tesla.shared.types.PE0533.PM;
import com.bytel.spirit.tesla.shared.types.PE0533.request.PE0533_PostRequest;
import com.bytel.spirit.tesla.shared.types.PE0533.request.PE0533_PutRequest;
import com.bytel.spirit.tesla.shared.types.PE0533.response.PE0533_GetResponse;
import com.google.gson.annotations.Expose;
import com.squareup.moshi.Json;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class PE0533_BlocageEquipements extends SpiritRestApiProcessSkeleton
{
  /**
   * CleRechercheBlocageEquipementComparator
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  public static final class CleRechercheBlocageEquipementComparator implements Comparator<com.bytel.spirit.common.shared.saab.rex.CleRechercheBlocageEquipement>
  {
    @Override
    public final int compare( //
        final com.bytel.spirit.common.shared.saab.rex.CleRechercheBlocageEquipement lhs_p, //
        final com.bytel.spirit.common.shared.saab.rex.CleRechercheBlocageEquipement rhs_p)
    {
      return Comparator.comparing(CleRechercheBlocageEquipement::getTypeCle) //
          .thenComparing(CleRechercheBlocageEquipement::getValeurCle) //
          .thenComparing(CleRechercheBlocageEquipement::getIdBlocageEquipement) //
          .compare(lhs_p, rhs_p);
    }
  }

  /**
   * Equipement comparator
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  public static final class EquipementComparator implements Comparator<com.bytel.spirit.common.shared.saab.rex.Equipement>
  {
    @Override
    public final int compare( //
        final com.bytel.spirit.common.shared.saab.rex.Equipement lhs_p, //
        final com.bytel.spirit.common.shared.saab.rex.Equipement rhs_p)
    {
      switch (lhs_p.getType())
      {
        case "OLT": //$NON-NLS-1$
          return Comparator.comparing(com.bytel.spirit.common.shared.saab.rex.Equipement::getType) //
              .thenComparing(com.bytel.spirit.common.shared.saab.rex.Equipement::getNomOLT) //
              .compare(lhs_p, rhs_p);

        case "PM": //$NON-NLS-1$
          return Comparator.comparing(com.bytel.spirit.common.shared.saab.rex.Equipement::getType) //
              .thenComparing(com.bytel.spirit.common.shared.saab.rex.Equipement::getReferencePmBytel) //
              .compare(lhs_p, rhs_p);

        default:
          return -1;
      }
    }
  }

  /**
   * HTTP Headers
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  public interface IPE0533HttpHeadersConsts
  {
    /**
     * Operation identifier for network live
     */
    public static final String ID_BLOCAGE_EQUIPEMENT = "idBlocageEquipement"; //$NON-NLS-1$

  }

  /**
   * PE0533 sync states (BL001, BL100, BL200, BL300 and BL002)
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  public enum PE0533State
  {
    /**
     * The next step to execute is:
     */
    PE0533_START(MandatoryProcessState.PRC_START),

    /**
     * The next step to execute is:
     */
    PE0533_SYNC(MandatoryProcessState.PRC_RUNNING),

    /**
     * Terminal state.
     */
    PE0533_END(MandatoryProcessState.PRC_STOP);

    /**
     * The asynchronous state.
     */
    private Boolean _asynchronousState;

    /**
     * Replayable state.
     */
    private Boolean _replayableState;

    /**
     * Technical state associated.
     */
    private MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * Default constructor.
     *
     * @param technicalState_p
     *          the associated {@link MandatoryProcessState}.
     */
    private PE0533State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * @return Process internal state, must match the enum defining all the steps in the process.
     */
    public final String getInternalState()
    {
      return toString();
    }

    /**
     * TechnicalState getter.
     *
     * @return Technical state, values must match {@link com.bytel.ravel.services.process.MandatoryProcessState}
     */
    public final MandatoryProcessState getTechnicalState()
    {
      return _technicalState;
    }

    /**
     * @return <code>true</code> if the process is asynchronous. <code>false</code> otherwise.
     */
    public final Boolean isAsynchronous()
    {
      return _asynchronousState;
    }

    /**
     * @return <code>true</code> if an asynchronous process is replayable. <code>false</code> otherwise.
     */
    public final Boolean isReplayable()
    {
      return _replayableState;
    }

    /**
     * @param asynchronousState_p
     *          the asynchronousState to set
     */
    protected final void setAsynchronousState(@NotNull final Boolean asynchronousState_p)
    {
      _asynchronousState = asynchronousState_p;
    }

    /**
     * @param replayableState_p
     *          the replayableState to set
     */
    protected final void setReplayableState(@NotNull final Boolean replayableState_p)
    {
      _replayableState = replayableState_p;
    }

    /**
     * @param technicalState_p
     *          the technicalState to set
     */
    protected final void setTechnicalState(@NotNull final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
    }
  } // class PE0533State

  /**
   * Defines the structure of the returned object in PE0533_BL001_VerifierDonnesCreation and
   * PE0533_BL001_VerifierDonnesModification
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   * @param <T>
   *          Could be {@link PE0533_PutRequest} or {@link PE0533_PostRequest}
   */
  static final class PE0533_BL001_VerifierDonneesReturn<T> extends AbstractBLReturn
  {
    /**
     * Unique serial identifier
     */
    private static final long serialVersionUID = 1688524252378141612L;

    /**
     * The POST request
     */
    private T _postRequest;

    /**
     * Constructor
     *
     * @param retour_p
     *          The object {@link Retour}
     */
    public PE0533_BL001_VerifierDonneesReturn(@NotNull final Retour retour_p)
    {
      super(retour_p);

      _postRequest = null;
    }

    /**
     * Constructor
     *
     * @param request_p
     *          The request
     * @param retour_p
     *          The object {@link Retour}
     */
    public PE0533_BL001_VerifierDonneesReturn(@NotNull final T request_p, @NotNull final Retour retour_p)
    {
      super(retour_p);

      if (isRetourOK(retour_p))
      {
        _postRequest = request_p;
      }
    }

    @Override
    public final boolean equals(final Object object_p)
    {
      if (this == object_p)
      {
        return true;
      }

      if (isNull(object_p) || //
          (getClass() != object_p.getClass()))
      {
        return false;
      }

      @SuppressWarnings("unchecked")
      final PE0533_BL001_VerifierDonneesReturn<T> other = PE0533_BL001_VerifierDonneesReturn.class.cast(object_p);
      return Objects.equals(_postRequest, other.getRequest()) //
          && Objects.equals(getRetour(), other.getRetour());
    }

    /**
     * @return the postRequest
     */
    public final T getRequest()
    {
      return _postRequest;
    }

    @Override
    public final int hashCode()
    {
      return hash(_postRequest, getRetour());
    }

    @Override
    public String toString()
    {
      return new StringBuilder() //
          .append("BL001_VerifierDonneesReturn [_postRequest=") //$NON-NLS-1$
          .append(_postRequest) //
          .append(", _retour=") //$NON-NLS-1$
          .append(getRetour()) //
          .append("]") //$NON-NLS-1$
          .toString();
    }
  } // class BL001_VerifierDonneesReturn

  /**
   * Defines the structure of the returned object in PE0533_BL002_FormaterReponseCreation
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  static final class PE0533_BL002_FormaterReponseCreationReturn extends ReponseErreur
  {
    /**
     * Unique serial identifier
     */
    private static final long serialVersionUID = -3757702853396988799L;

    /**
     * Identifiant de Blocage Prise Clients créée
     */
    @Json(name = "idBlocageEquipement")
    @Expose
    private String _idBlocageEquipement;

    /**
     * Constructor
     *
     * @param idBlocageEquipement_p
     *          The equipment lock identifier
     */
    public PE0533_BL002_FormaterReponseCreationReturn(@NotNull final String idBlocageEquipement_p)
    {
      super();

      _idBlocageEquipement = idBlocageEquipement_p;
    }

    /**
     * Constructor
     *
     * @param error_p
     *          The error
     * @param errorDescription_p
     *          The error description
     */
    public PE0533_BL002_FormaterReponseCreationReturn(@NotNull final String error_p, @NotNull final String errorDescription_p)
    {
      super(error_p, errorDescription_p);

      _idBlocageEquipement = null;
    }

    @Override
    public final boolean equals(@NotNull final Object object_p)
    {
      if (this == object_p)
      {
        return true;
      }

      if (isNull(object_p) || //
          (getClass() != object_p.getClass()))
      {
        return false;
      }

      final PE0533_BL002_FormaterReponseCreationReturn other = PE0533_BL002_FormaterReponseCreationReturn.class.cast(object_p);
      return Objects.equals(getError(), other.getError()) //
          && Objects.equals(getErrorDescription(), other.getErrorDescription()) //
          && Objects.equals(_idBlocageEquipement, other.getidBlocageEquipement());
    }

    /**
     * @return the idBlocageEquipement
     */
    public final String getidBlocageEquipement()
    {
      return _idBlocageEquipement;
    }

    @Override
    public final int hashCode()
    {
      return hash(_idBlocageEquipement, getError(), getErrorDescription());
    }

    /**
     * @param idBlocageEquipement_p
     *          the idBlocageEquipement to set
     */
    public void setIdBlocageEquipement(@NotNull final String idBlocageEquipement_p)
    {
      _idBlocageEquipement = idBlocageEquipement_p;
    }

    @Override
    public final String toString()
    {
      return new StringBuilder() //
          .append("PE0533_BL002_FormaterReponseCreationReturn [_idBlocageEquipement=") //$NON-NLS-1$
          .append(_idBlocageEquipement) //
          .append(", _error=") //$NON-NLS-1$
          .append(getError()) //
          .append(", _errorDescription=") //$NON-NLS-1$
          .append(getErrorDescription()) //
          .append("]") //$NON-NLS-1$
          .toString();
    }

    /**
     * @param error_p
     *          the error to set
     * @return Return current handler
     */
    public PE0533_BL002_FormaterReponseCreationReturn withError(@NotNull final String error_p)
    {
      setError(error_p);

      return this;
    }

    /**
     * @param errorDescription_p
     *          the errorDescription to set
     * @return Return current handler
     */
    public PE0533_BL002_FormaterReponseCreationReturn withErrorDescription(@NotNull final String errorDescription_p)
    {
      setError(errorDescription_p);

      return this;
    }

    /**
     * @param idBlocageEquipement_p
     *          the idBlocageEquipement to set
     * @return Return current handler
     */
    public PE0533_BL002_FormaterReponseCreationReturn withidBlocageEquipement(@NotNull final String idBlocageEquipement_p)
    {
      _idBlocageEquipement = idBlocageEquipement_p;

      return this;
    }
  }

  /**
   * Defines the structure of the returned object in PE0533PE0533_BL200_CreerBlocageEquipements
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  static final class PE0533_BL200_CreerBlocageEquipementsReturn extends AbstractBLReturn
  {
    /**
     * Unique serial identifier
     */
    private static final long serialVersionUID = 8110494309586008189L;

    /**
     * L’id de la ressource BlocageEquipements créée dans REX
     */
    private String _idBlocageEquipement;

    /**
     * Constructor
     *
     * @param retour_p
     *          The object {@link Retour} to set
     */
    public PE0533_BL200_CreerBlocageEquipementsReturn(@NotNull final Retour retour_p)
    {
      super(retour_p);

      _idBlocageEquipement = null;
    }

    /**
     * Constructor
     *
     * @param idBlocageEquipement_p
     *          The BlockageEquipement identifier to set
     * @param retour_p
     *          The object {@link Retour} to set
     */
    public PE0533_BL200_CreerBlocageEquipementsReturn(@NotNull final String idBlocageEquipement_p, @NotNull final Retour retour_p)
    {
      super(retour_p);

      _idBlocageEquipement = idBlocageEquipement_p;
    }

    @Override
    public final boolean equals(final Object object_p)
    {
      if (this == object_p)
      {
        return true;
      }

      if (isNull(object_p) || //
          (getClass() != object_p.getClass()))
      {
        return false;
      }

      final PE0533_BL200_CreerBlocageEquipementsReturn other = PE0533_BL200_CreerBlocageEquipementsReturn.class.cast(object_p);
      return Objects.equals(_idBlocageEquipement, other.getidBlocageEquipement()) //
          && Objects.equals(getRetour(), other.getRetour());
    }

    /**
     * @return the idBlocageEquipement
     */
    public final String getidBlocageEquipement()
    {
      return _idBlocageEquipement;
    }

    @Override
    public final int hashCode()
    {
      return hash(_idBlocageEquipement, getRetour());
    }

    @Override
    public final String toString()
    {
      return new StringBuilder() //
          .append("PE0533_BL200_CreerBlocageEquipementsReturn [_idBlocageEquipement=") //$NON-NLS-1$
          .append(_idBlocageEquipement) //
          .append(", _retour=") //$NON-NLS-1$
          .append(getRetour()) //
          .append("]") //$NON-NLS-1$
          .toString();
    }
  }

  /**
   * Holds context data for PE0533_BlocageEquipements
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  static final class PE0533_BlocageEquipementsContext extends Context
  {
    /**
     * Unique serial identifier
     */
    private static final long serialVersionUID = 8976230633467643878L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private transient PE0533State _state = PE0533State.PE0533_START;

    /**
     * Si l’appel est déclenché via B2R<br />
     * Authorization: Bearer <Token B2R><br />
     * Sinon<br />
     * Authorization: Basic <Authentification string>
     */
    private String _autorization = null;
    /**
     * GET Response for consultation
     */
    private PE0533_GetResponse _consultationResponse;
    /**
     * Nom de l’émetteur d’un traitement (sous la forme <NomDuST>.<application>)
     */
    private String _xSource = null;

    /**
     * Identifiant de requête sur le SI<br />
     * (identifiant unique généré lors de l'appel à chaque ressource<br />
     * si non présent en entrée et fourni à chaque service appelé en synchrone)
     */
    private String _xRequestId = null;

    /**
     * Unique pour chaque interaction entre ST<br />
     * (il peut permettre de gérer l'anti-rejeu sur des alimentations par exemple)
     */
    private String _xMessageId = null;

    /**
     * Nom humainement compréhensible de l’action de l’appelant<br />
     * (ex : soumissionPanier)
     */
    private String _xProcess = null;

    /**
     * La requête va être appliquée sur le SI<br />
     * avec potentiellement un ensemble de traitements synchrones décorrélés dans le temps : les actions<br />
     * (identifiant unique généré lors du démarrage d'un nouveau traitement asynchrone ou<br />
     * si non présent en entrée et fourni à chaque service appelé en synchrone)
     */
    private String _xActionId = null;

    /**
     * Toujours 1 pour cette version d’interface
     */
    private String _xVersion = null;

    /**
     * Selon les opérations, un ou plusieurs types de contenu peuvent être gérés parmi :<br />
     *
     * <pre>
     *   <ul>
     *     <li>multipart/form-data</li>
     *     <li>application/json</li>
     *     <li>application/pdf</li>
     *     <li>audio/wav</li>
     *   </ul>
     * </pre>
     *
     * Se référer à la description de chaque opération pour la liste des types supportés par l'opération.
     */
    private PE0533ContentType _contentType = null;

    /**
     * Equipment locking identifier
     */
    private String _idBlocageEquipement;

    /**
     * @return the autorization
     */
    public final String getAutorization()
    {
      return _autorization;
    }

    /**
     * @return the consultationResponse
     */
    public PE0533_GetResponse getConsultationResponse()
    {
      return _consultationResponse;
    }

    /**
     * @return the contentType
     */
    public final PE0533ContentType getContentType()
    {
      return _contentType;
    }

    /**
     * @return the idBlocageEquipement
     */
    public final String getIdBlocageEquipement()
    {
      return _idBlocageEquipement;
    }

    /**
     * @return the state
     */
    public final PE0533State getState()
    {
      return _state;
    }

    /**
     * @return the xActionId
     */
    public final String getXActionId()
    {
      return _xActionId;
    }

    /**
     * @return the xMessageId
     */
    public final String getXMessageId()
    {
      return _xMessageId;
    }

    /**
     * @return the process
     */
    public final String getXProcess()
    {
      return _xProcess;
    }

    /**
     * @return the xRequestId
     */
    public final String getXRequestId()
    {
      return _xRequestId;
    }

    /**
     * @return the xSource
     */
    public final String getXSource()
    {
      return _xSource;
    }

    /**
     * @return the XVersion
     */
    public final String getXVersion()
    {
      return _xVersion;
    }

    /**
     * @param autorization_p
     *          the autorization to set
     */
    public void setAutorization(@NotNull final String autorization_p)
    {
      if (Pattern.matches("(Basic|Bearer).+", autorization_p)) //$NON-NLS-1$
      {
        _autorization = autorization_p;
      }
      else
      {
        // Nothing to do yet
      }
    }

    /**
     * @param consultationResponse_p
     *          the consultationResponse to set
     */
    public void setConsultationResponse(PE0533_GetResponse consultationResponse_p)
    {
      _consultationResponse = consultationResponse_p;
    }

    /**
     * @param contentType_p
     *          the contentType to set
     */
    public void setContentType(@NotNull final String contentType_p)
    {
      try
      {
        _contentType = PE0533ContentType.valueOf(contentType_p);
      }
      catch (final IllegalArgumentException | NullPointerException ignore)
      {
        _contentType = PE0533ContentType.invalid;
      }
    }

    /**
     * @param idBlocageEquipement_p
     *          The lock identifier to set
     */
    public void setIdBlocageEquipement(@NotNull final String idBlocageEquipement_p)
    {
      _idBlocageEquipement = idBlocageEquipement_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(final PE0533State state_p)
    {
      _state = state_p;
    }

    /**
     * @param xActionId_p
     *          the xActionId to set
     */
    public void setXActionId(@NotNull final String xActionId_p)
    {
      _xActionId = xActionId_p;
    }

    /**
     * @param xMessageId_p
     *          the xMessageId to set
     */
    public void setXMessageId(@NotNull final String xMessageId_p)
    {
      _xMessageId = xMessageId_p;
    }

    /**
     * @param xProcess_p
     *          the process to set
     */
    public void setXProcess(@NotNull final String xProcess_p)
    {
      _xProcess = xProcess_p;
    }

    /**
     * @param xRequestId_p
     *          the xRequestId to set
     */
    public void setXRequestId(@NotNull final String xRequestId_p)
    {
      _xRequestId = xRequestId_p;
    }

    /**
     * @param xSource_p
     *          the xSource to set
     */
    public void setXSource(@NotNull final String xSource_p)
    {
      _xSource = xSource_p;
    }

    /**
     * @param xVersion_p
     *          the xVersion to set
     */
    public void setXVersion(@NotNull final String xVersion_p)
    {
      _xVersion = xVersion_p;
    }
  } // class PE0533_BlocageEquipementsContext

  /**
   * PE0533 content-types
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  enum PE0533ContentType
  {

    /**
     * Invalid value
     */
    invalid(""), //$NON-NLS-1$

    /**
     * Value for "multipart/form-data"
     */
    multipart_form_data("multipart/form-data"), //$NON-NLS-1$

    /**
     * Value for "application/json"
     */
    application_json("application/json"), //$NON-NLS-1$

    /**
     * Value for "application/pdf"
     */
    application_pdf("application_pdf"), //$NON-NLS-1$

    /**
     * value for "audio/wav"
     */
    audio_wav("audio_wav"); //$NON-NLS-1$

    /**
     * The content-type
     */
    private String _contentType;

    /**
     * Constructor
     *
     * @param contentType_p
     *          The expected content-type
     */
    PE0533ContentType(String contentType_p)
    {
      _contentType = contentType_p;
    }

    /**
     *
     * @param value_p
     *          The value to compare
     * @return True if equals, false elsewhere
     */
    public boolean equals(final String value_p) //NOSONAR
    {
      return _contentType.equals(value_p);
    }

    /**
     * @return the type
     */
    public String getValue()
    {
      return _contentType;
    }
  } // enum PE0533ContentType

  /**
   * Unique serial identifier
   */
  private static final long serialVersionUID = 5002005453913145333L;

  /**
   * The process's context.
   */
  private PE0533_BlocageEquipementsContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(@NotNull final Retour retour_p) throws RavelException
  {
    return MarshallTools.marshall(retour_p);
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ZERO;
  }

  @Override
  public final MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState().getTechnicalState();
  }

  @Override
  public void initializeContext()
  {
    super.initializeContext();
    _processContext = new PE0533_BlocageEquipementsContext();
  }

  @Override
  public final boolean isAsynchronous()
  {
    return _processContext.getState().isAsynchronous();
  }

  @Override
  public final boolean isReplayable()
  {
    return _processContext.getState().isReplayable();
  }

  @Override
  protected void exitKOMetroLog(@NotNull final String reason_p)
  {
    // Nothing to do yet
  }

  @Override
  @LogStartProcess
  protected void startDeleteProcess(@NotNull final Request request_p, @NotNull final Tracabilite traceability_p) throws RavelException
  {
    try
    {
      _processContext.setState(PE0533State.PE0533_SYNC);

      Retour bl001Retour = PE0533_BL001_VerifierDonnesSuppression(traceability_p, request_p);
      setRetour(bl001Retour);
      if (!isRetourOK(bl001Retour))
      {
        return;
      }

      Retour bl100Retour = PE0533_BL100_SupprimerBlocageEquipements(traceability_p, _processContext.getIdBlocageEquipement());
      setRetour(bl100Retour);
    }
    catch (final RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, exception));
      setRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
    }
    finally
    {
      Pair<Retour, Response> bl002_retour = PE0533_BL002_FormaterReponseSuppression(traceability_p, getRetour());
      this.setRetour(bl002_retour._first);
      request_p.setResponse(bl002_retour._second);

      _processContext.setState(PE0533State.PE0533_END);
    }
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(@NotNull final Request request_p, @NotNull final Tracabilite traceability_p) throws RavelException
  {
    try
    {
      _processContext.setState(PE0533State.PE0533_SYNC);

      Retour bl001Retour = PE0533_BL001_VerifierDonnesConsultation(traceability_p, request_p);
      setRetour(bl001Retour);

      if (isRetourOK(bl001Retour))
      {
        // Appel BL100
        Pair<Retour, PE0533_GetResponse> bl100Retour = PE0533_BL100_ConsulterBlocageEquipements(traceability_p, _processContext.getIdBlocageEquipement());
        setRetour(bl100Retour._first);
        if (isRetourOK(bl100Retour._first))
        {
          _processContext.setConsultationResponse(bl100Retour._second);
        }

      }
    }
    catch (final RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, exception));
      setRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
    }
    finally
    {
      Pair<Retour, Response> bl002_retour = PE0533_BL002_FormaterReponseConsultation(traceability_p, getRetour(), _processContext.getConsultationResponse());
      this.setRetour(bl002_retour._first);
      request_p.setResponse(bl002_retour._second);

      _processContext.setState(PE0533State.PE0533_END);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Nothing to do yet
  }

  @Override
  @LogStartProcess
  protected void startPostProcess(@NotNull final Request request_p, @NotNull final Tracabilite traceability_p) throws RavelException
  {
    try
    {
      _processContext.setState(PE0533State.PE0533_SYNC);

      final PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> bl001 = PE0533_BL001_VerifierDonnesCreation(traceability_p, request_p);
      setRetour(bl001.getRetour());
      if (!isRetourOK(getRetour()))
      {
        return;
      }

      final PE0533_BL200_CreerBlocageEquipementsReturn bl200 = PE0533_BL200_CreerBlocageEquipements(traceability_p, bl001.getRequest());
      _processContext.setIdBlocageEquipement(bl200.getidBlocageEquipement());
      setRetour(bl200.getRetour());
      if (!isRetourOK(getRetour()))
      {
        return;
      }
    }
    catch (final RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, exception));
      setRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
    }
    finally
    {
      final PE0533_BL002_FormaterReponseCreationReturn bl002 = PE0533_BL002_FormaterReponseCreation(traceability_p, getRetour(), _processContext.getIdBlocageEquipement());
      syncPostResponse(traceability_p, request_p, getRetour(), bl002);

      _processContext.setState(PE0533State.PE0533_END);
    }
  }

  @Override
  @LogStartProcess
  protected void startPutProcess(@NotNull final Request request_p, @NotNull final Tracabilite traceability_p) throws RavelException
  {
    try
    {
      _processContext.setState(PE0533State.PE0533_SYNC);

      final PE0533_BL001_VerifierDonneesReturn<PE0533_PutRequest> bl001 = PE0533_BL001_VerifierDonnesModification(traceability_p, request_p);
      setRetour(bl001.getRetour());
      if (!isRetourOK(getRetour()))
      {
        return;
      }

      setRetour(PE0533_BL300_ModifierBlocageEquipements(traceability_p, _processContext.getIdBlocageEquipement(), bl001.getRequest().getListeIdOperationVieReseau(), bl001.getRequest().getListeEquipement()));
      if (!isRetourOK(getRetour()))
      {
        return;
      }
    }
    catch (final RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, exception));
      setRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));
    }
    finally
    {
      final ReponseErreur bl002 = PE0533_BL002_FormaterReponseModification(traceability_p, getRetour());
      syncPutResponse(traceability_p, request_p, getRetour(), bl002);

      _processContext.setState(PE0533State.PE0533_END);
    }
  }

  /**
   * Verify the mandatory headers
   *
   * @param traceability_p
   *          The {@link Tracabilite} to set
   * @param request_p
   *          The request
   *
   * @return The object {@link Retour}
   */
  private final Retour checkHeaders(@SuppressWarnings("unused") @NotNull final Tracabilite traceability_p, @NotNull final Request request_p)
  {
    return RetourFactory.createOkRetour();
  }

  /**
   * Modifier blocage equipement. Calls RES for PM Equipement
   *
   * @param traceability_p
   * @param equipements_p
   * @param status_p
   * @param commentaire_p
   * @return
   * @throws RavelException
   */
  private Retour modifierSurchargePriseClient(Tracabilite traceability_p, Set<Equipement> equipements_p, String status_p, String commentaire_p) throws RavelException
  {
    for (final Equipement equipment : equipements_p)
    {
      if (equipment instanceof PM)
      {
        final PM other = PM.class.cast(equipment);
        if (nonNull(other.getListeReferenceBoitierPm()))
        {
          for (final String referenceBoitierPm : other.getListeReferenceBoitierPm())
          {
            final ConnectorResponse<Retour, Nothing> retour = RESProxy.getInstance().pmCompositeModifierSurchargePriseClientBoitierPM( //
                traceability_p, //
                other.getReferencePmBytel(), //
                referenceBoitierPm, //
                status_p, //
                commentaire_p);
            if (!isRetourOK(retour._first))
            {
              return retour._first;
            }
          }
        }
        else
        {
          final ConnectorResponse<Retour, Nothing> retour = RESProxy.getInstance().pmCompositeModifierSurchargePriseClientPM( //
              traceability_p, //
              other.getReferencePmBytel(), //
              status_p, //
              commentaire_p);
          if (!isRetourOK(retour._first))
          {
            return retour._first;
          }
        }
      }
      else if (equipment instanceof OLT)
      {
        final OLT other = OLT.class.cast(equipment);
        if (nonNull(other.getListePositionCarte()))
        {
          for (final Integer positionCarte : other.getListePositionCarte())
          {
            final ConnectorResponse<Retour, Nothing> retour = RESProxy.getInstance().oltCompositeModifierSurchargePriseClientCarte( //
                traceability_p, //
                other.getNomOLT(), //
                positionCarte.toString(), //
                status_p, //
                commentaire_p);
            if (!isRetourOK(retour._first))
            {
              return retour._first;
            }
          }
        }
        else
        {
          final ConnectorResponse<Retour, Nothing> retour = RESProxy.getInstance().oltCompositeModifierSurchargePriseClientOLT( //
              traceability_p, //
              other.getNomOLT(), //
              status_p, //
              commentaire_p);
          if (!isRetourOK(retour._first))
          {
            return retour._first;
          }
        }
      }
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Subpart of BL100 Supprimer blocage equipement. Calls RES for OLT and PM Equipement
   *
   * @param tracabilite_p
   * @param listeEqpt_p
   * @param status_p
   * @param commentaireBlocage_p
   * @return
   * @throws RavelException
   */
  private Retour modifierSurchargePriseClientFromRex(Tracabilite tracabilite_p, Set<com.bytel.spirit.common.shared.saab.rex.Equipement> listeEqpt_p, String status_p, String commentaireBlocage_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();

    for (com.bytel.spirit.common.shared.saab.rex.Equipement equipement : listeEqpt_p)
    {
      if (TypeIdentifiant.PM.name().equals(equipement.getType()))
      {
        retour = modifierSurchargePriseClientPM(tracabilite_p, equipement, status_p, commentaireBlocage_p);
      }
      else if (TypeIdentifiant.OLT.name().equals(equipement.getType()))
      {
        retour = modifierSurchargePriseClientOLT(tracabilite_p, equipement, status_p, commentaireBlocage_p);
      }

      if (!isRetourOK(retour))
      {
        break;
      }
    }
    return retour;
  }

  /**
   * Subpart of BL100 Supprimer blocage equipement. Calls RES for OLT Equipement
   *
   * @param tracabilite_p
   *          The {@link Tracabilite} to set
   * @param equipement_p
   *          The {@link Equipement} from REX to set
   * @param status_p
   * @param commentaireBlocage_p
   *          The {@link String} for commentaire in REX
   * @return The object {@link Retour}
   * @throws RavelException
   *           Exceptions from REX
   */
  private Retour modifierSurchargePriseClientOLT(Tracabilite tracabilite_p, com.bytel.spirit.common.shared.saab.rex.Equipement equipement_p, String status_p, String commentaireBlocage_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    if (CollectionUtils.isNotEmpty(equipement_p.getListePositionCarte()))
    {
      for (Integer positionCarte : equipement_p.getListePositionCarte())
      {
        ConnectorResponse<Retour, Nothing> oRetour = RESProxy.getInstance().oltCompositeModifierSurchargePriseClientCarte(tracabilite_p, equipement_p.getNomOLT(), positionCarte.toString(), status_p, commentaireBlocage_p);
        if (!isRetourOK(oRetour._first))
        {
          retour = oRetour._first;
          break;
        }
      }
    }
    else
    {
      ConnectorResponse<Retour, Nothing> oRetour = RESProxy.getInstance().oltCompositeModifierSurchargePriseClientOLT(tracabilite_p, equipement_p.getNomOLT(), status_p, commentaireBlocage_p);
      if (!isRetourOK(oRetour._first))
      {
        retour = oRetour._first;
      }
    }

    return retour;
  }

  /**
   * Subpart of BL100 Supprimer blocage equipement. Calls RES for PM Equipement
   *
   * @param tracabilite_p
   *          The {@link Tracabilite} to set
   * @param equipement_p
   *          The {@link Equipement} from REX to set
   * @param status_p
   * @param commentaireBlocage_p
   *          The {@link String} for commentaire in REX
   * @return The {@link Retour}
   * @throws RavelException
   *           Exceptions from REX
   */
  private Retour modifierSurchargePriseClientPM(Tracabilite tracabilite_p, com.bytel.spirit.common.shared.saab.rex.Equipement equipement_p, String status_p, String commentaireBlocage_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    if (CollectionUtils.isNotEmpty(equipement_p.getListeReferenceBoitierPm()))
    {
      for (String referenceBoitierPm : equipement_p.getListeReferenceBoitierPm())
      {
        ConnectorResponse<Retour, Nothing> oRetour = RESProxy.getInstance().pmCompositeModifierSurchargePriseClientBoitierPM(tracabilite_p, equipement_p.getReferencePmBytel(), referenceBoitierPm, status_p, commentaireBlocage_p);
        if (!isRetourOK(oRetour._first))
        {
          retour = oRetour._first;
          break;
        }
      }
    }
    else
    {
      ConnectorResponse<Retour, Nothing> oRetour = RESProxy.getInstance().pmCompositeModifierSurchargePriseClientPM(tracabilite_p, equipement_p.getReferencePmBytel(), status_p, commentaireBlocage_p);
      if (!isRetourOK(oRetour._first))
      {
        retour = oRetour._first;
      }
    }

    return retour;
  }

  /**
   * Validates the URL parameter.
   *
   * @param traceability_p
   *          The {@link Tracabilite} to set
   *
   * @param request_p
   *          The request to set
   * @return The return object {@link PE0533_BL001_VerifierDonneesReturn}
   */
  private final Retour PE0533_BL001_VerifierDonnees(@NotNull final Tracabilite traceability_p, @NotNull final Request request_p)
  {
    final Retour retour = checkHeaders(traceability_p, request_p);

    if (isRetourOK(retour))
    {
      _processContext.setIdBlocageEquipement(request_p.getUrlDynamicParameters());
      if (isBlank(_processContext.getIdBlocageEquipement()))
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, //
            MessageFormat.format(Messages.getString("Validation.RequiredUrlParameter"), "idBlocageEquipement")); //$NON-NLS-1$ //$NON-NLS-2$);
      }
    }

    return retour;
  }

  /**
   * Validates JSON object received in the request parameter.
   *
   * @param traceability_p
   *          The {@link Tracabilite} to set
   * @param clazz_p
   *          Generic object
   * @param request_p
   *          The request to set
   * @return The return object {@link PE0533_BL001_VerifierDonneesReturn}
   * @throws RavelException,
   *           On error
   */
  private final <T> PE0533_BL001_VerifierDonneesReturn<T> PE0533_BL001_VerifierDonnees(@NotNull final Tracabilite traceability_p, @NotNull final Request request_p, @NotNull Class<T> clazz_p) throws RavelException
  {
    final Retour retour = checkHeaders(traceability_p, request_p);

    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<T> adapter = instance.adapter(clazz_p);
    final T request = adapter.fromJson(request_p.getPayload());

    final Set<String> required = new TreeSet<>();
    final Set<String> invalid = new TreeSet<>();
    final StringJoiner joiner = new StringJoiner("; "); //$NON-NLS-1$

    if (!isRetourOK(retour))
    {
      joiner.add(defaultString(retour.getLibelle(), null));
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, traceability_p, joiner.toString()));
      return new PE0533_BL001_VerifierDonneesReturn<T>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, joiner.toString()));
    }

    if (HttpMethod.PUT.equals(request_p.getHttpMethod()))
    {
      _processContext.setIdBlocageEquipement(request_p.getUrlDynamicParameters());
      if (isNull(_processContext.getIdBlocageEquipement()) || StringUtils.isEmpty(_processContext.getIdBlocageEquipement()))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredUrlParameter"), "idBlocageEquipement")); //$NON-NLS-1$ //$NON-NLS-2$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, traceability_p, joiner.toString()));
        return new PE0533_BL001_VerifierDonneesReturn<T>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, joiner.toString()));
      }
    }

    if (nonNull(request))
    {
      final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
      final Validator validator = factory.getValidator();
      final Set<ConstraintViolation<T>> constraintViolations = validator.validate(request);
      if (!constraintViolations.isEmpty())
      {
        for (ConstraintViolation<T> constraintViolation : constraintViolations)
        {
          if (IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT.equals(constraintViolation.getMessage()))
          {
            required.add(constraintViolation.getPropertyPath().toString());
          }
          else if (IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE.equals(constraintViolation.getMessage()))
          {
            invalid.add(constraintViolation.getPropertyPath().toString());
          }
        }
      } // if
      factory.close();

      if (!required.isEmpty())
      {
        final StringJoiner requiredJoiner = new StringJoiner(", "); //$NON-NLS-1$i
        required.stream().forEach(requiredStr -> requiredJoiner.add(requiredStr));
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), requiredJoiner.toString())); //$NON-NLS-1$
      }
      if (!invalid.isEmpty())
      {
        final StringJoiner invalidJoiner = new StringJoiner(", "); //$NON-NLS-1$
        required.stream().forEach(invalidStr -> invalidJoiner.add(invalidStr));
        joiner.add(MessageFormat.format(Messages.getString("Validation.InvalidFieldFormat"), invalidJoiner.toString())); //$NON-NLS-1$
      }
      if (joiner.length() != 0)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, traceability_p, joiner.toString()));
        return new PE0533_BL001_VerifierDonneesReturn<T>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, joiner.toString()));
      }
    }
    else
    {
      return new PE0533_BL001_VerifierDonneesReturn<T>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, Messages.getString("PE0533.EntreeIncorrecte"))); //$NON-NLS-1$
    }
    return new PE0533_BL001_VerifierDonneesReturn<T>(request, retour);
  }

  /**
   * Validates the request parameter and headers
   *
   * @param tracabilite_p
   *          The {@link Tracabilite} to set
   * @param request_p
   *          The request to set
   * @return The return object, idBlocageEquipement
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Retour PE0533_BL001_VerifierDonnesConsultation(@NotNull Tracabilite tracabilite_p, @NotNull final Request request_p) throws RavelException
  {

    return PE0533_BL001_VerifierDonnees(tracabilite_p, request_p);
  }

  /**
   * Validates JSON object received in the request parameter.
   *
   * @param traceability_p
   *          The {@link Tracabilite} to set
   * @param request_p
   *          The request to set
   * @return The return object {@link PE0533_BL001_VerifierDonneesReturn}
   * @throws RavelException,
   *           On error
   */
  @LogProcessBL
  private PE0533_BL001_VerifierDonneesReturn<PE0533_PostRequest> PE0533_BL001_VerifierDonnesCreation(@NotNull Tracabilite traceability_p, @NotNull Request request_p) throws RavelException
  {
    return PE0533_BL001_VerifierDonnees(traceability_p, request_p, PE0533_PostRequest.class);
  }

  /**
   * Validates JSON object received in the request parameter.
   *
   * @param traceability_p
   *          The {@link Tracabilite} to set
   * @param request_p
   *          The request to set
   * @return The return object {@link PE0533_BL001_VerifierDonneesReturn}
   * @throws RavelException,
   *           On error
   */
  @LogProcessBL
  private PE0533_BL001_VerifierDonneesReturn<PE0533_PutRequest> PE0533_BL001_VerifierDonnesModification(@NotNull Tracabilite traceability_p, @NotNull Request request_p) throws RavelException
  {
    return PE0533_BL001_VerifierDonnees(traceability_p, request_p, PE0533_PutRequest.class);
  }

  /**
   * Validates the request parameter and headers
   *
   * @param tracabilite_p
   *          The {@link Tracabilite} to set
   * @param request_p
   *          The request to set
   * @return The return object, idBlocageEquipement
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Retour PE0533_BL001_VerifierDonnesSuppression(@NotNull Tracabilite tracabilite_p, @NotNull final Request request_p) throws RavelException
  {
    return PE0533_BL001_VerifierDonnees(tracabilite_p, request_p);

  }

  /**
   *
   * @param tracabilite_p
   *          The {@link Tracabilite} to set
   * @param retour_p
   *          The status object {@link Retour}
   * @param consulterResponse_p
   *          The response to send {@link PE0533_GetResponse}
   * @return The return object {@link ConnectorResponse}
   */
  @LogProcessBL
  private final Pair<Retour, Response> PE0533_BL002_FormaterReponseConsultation(Tracabilite tracabilite_p, @NotNull final Retour retour_p, final PE0533_GetResponse consulterResponse_p)
  {
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ErrorCode httpCode = ErrorCode.OK_00200;
    try
    {
      if (isRetourOK(retour_p))
      {
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(consulterResponse_p, PE0533_GetResponse.class));
      }
      else
      {
        ReponseErreur reponseErreur = new ReponseErreur();
        reponseErreur.setError(retour_p.getDiagnostic());
        reponseErreur.setErrorDescription(retour_p.getLibelle());
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur, ReponseErreur.class));
        httpCode = getDefaultHttpCodeFromRetour(retour_p);
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      Retour retourException = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
      setRetour(retourException);
      httpCode = ErrorCode.KO_00500;
    }
    return new Pair<>(retour_p, new Response(httpCode, ravelResponse));
  }

  /**
   *
   * @param traceability_p
   *          The {@link Tracabilite} to set
   * @param retour_p
   *          The status object {@link Retour}
   * @param idBlocageEquipement_p
   *          Identifiant de Blocage Prise Clients créée
   * @return The return object {@link PE0533_BL002_FormaterReponseCreationReturn}
   */
  @LogProcessBL
  private final PE0533_BL002_FormaterReponseCreationReturn PE0533_BL002_FormaterReponseCreation(@SuppressWarnings("unused") @NotNull Tracabilite traceability_p, @NotNull final Retour retour_p, @NotNull final String idBlocageEquipement_p)
  {
    if (isRetourOK(retour_p))
    {
      return new PE0533_BL002_FormaterReponseCreationReturn(idBlocageEquipement_p);
    }

    return new PE0533_BL002_FormaterReponseCreationReturn(retour_p.getDiagnostic(), retour_p.getLibelle());
  }

  /**
   *
   * @param traceability_p
   *          The {@link Tracabilite} to set
   * @param retour_p
   *          The status object {@link Retour}
   * @return The return object {@link PE0533_BL002_FormaterReponseCreationReturn}
   */
  @LogProcessBL
  private final ReponseErreur PE0533_BL002_FormaterReponseModification(@SuppressWarnings("unused") @NotNull Tracabilite traceability_p, @NotNull final Retour retour_p)
  {
    return isRetourOK(retour_p) ? null : new ReponseErreur(retour_p.getDiagnostic(), retour_p.getLibelle());
  }

  /**
   *
   * @param tracabilite_p
   *          The {@link Tracabilite} to set
   * @param retour_p
   *          The status object {@link Retour}
   *
   * @return The return object {@link PE0533_BL002_FormaterReponseCreationReturn}
   */
  @LogProcessBL
  private final Pair<Retour, Response> PE0533_BL002_FormaterReponseSuppression(Tracabilite tracabilite_p, @NotNull final Retour retour_p)
  {
    Response ravelResponse = null;
    Retour bl002_retour = RetourFactory.createOkRetour();

    if (isRetourOK(retour_p))
    {
      ravelResponse = new Response(ErrorCode.OK_00200);
    }
    else
    {
      try
      {
        ErrorCode httpCode = getDefaultHttpCodeFromRetour(retour_p);
        ravelResponse = new Response(httpCode);
        ReponseErreur reponseErreur = new ReponseErreur();
        reponseErreur.setError(retour_p.getDiagnostic());
        reponseErreur.setErrorDescription(retour_p.getLibelle());

        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur, ReponseErreur.class));

      }
      catch (Exception e)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
        bl002_retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
        setRetour(bl002_retour);

        ravelResponse = new Response(ErrorCode.KO_00500);
      }
    }
    return new Pair<>(bl002_retour, ravelResponse);
  }

  /**
   * @param idBlocageEquipement_p
   *          The parameter
   * @param tracabilite_p
   *          The {@link Tracabilite} to set
   *
   * @return The {@Retour}
   * @throws RavelException
   *           {@link RavelException}
   */
  @LogProcessBL
  private final Pair<Retour, PE0533_GetResponse> PE0533_BL100_ConsulterBlocageEquipements(Tracabilite tracabilite_p, String idBlocageEquipement_p) throws RavelException
  {
    PE0533_GetResponse getResponse = null;

    ConnectorResponse<Retour, BlocageEquipement> lireUnResponse = REXProxy.getInstance().blocageEquipementLireUn(tracabilite_p, idBlocageEquipement_p);
    if (isRetourOK(lireUnResponse._first))
    {
      BlocageEquipement blocageEquipement = lireUnResponse._second; // TODO

      //Copy Equipement from SAAB to STI Equipement
      Set<Equipement> listEquipement = new TreeSet<>();
      if (nonNull(blocageEquipement.getListeEquipement()))
      {
        final Set<com.bytel.spirit.common.shared.saab.rex.Equipement> equipements = new TreeSet<>(new EquipementComparator());
        equipements.addAll(blocageEquipement.getListeEquipement());
        for (com.bytel.spirit.common.shared.saab.rex.Equipement equipement : equipements) // TODO
        {
          if (TypeIdentifiant.OLT.name().equals(equipement.getType()))
          {
            OLT olt = new OLT(equipement.getNomOLT());
            olt.setListePositionCarte(equipement.getListePositionCarte());

            listEquipement.add(olt);
          }
          else if (TypeIdentifiant.PM.name().equals(equipement.getType()))
          {
            PM pm = new PM(equipement.getReferencePmBytel());
            pm.setListeReferenceBoitierPm(equipement.getListeReferenceBoitierPm());

            listEquipement.add(pm);
          }
        }
      }
      getResponse = new PE0533_GetResponse(blocageEquipement.getIdBlocageEquipement(), listEquipement, blocageEquipement.getListeIdOperationVieReseau());
    }

    return new Pair<>(lireUnResponse._first, getResponse);
  }

  /**
   * @param idBlocageEquipement_p
   *          The parameter
   * @param tracabilite_p
   *          The {@link Tracabilite} to set
   *
   * @return The {@Retour}
   * @throws RavelException
   *           {@link RavelException}
   */
  @LogProcessBL
  private final Retour PE0533_BL100_SupprimerBlocageEquipements(Tracabilite tracabilite_p, String idBlocageEquipement_p) throws RavelException
  {
    Retour bl100_retour = RetourFactory.createOkRetour();

    ConnectorResponse<Retour, BlocageEquipement> lireUnResponse = REXProxy.getInstance().blocageEquipementLireUn(tracabilite_p, idBlocageEquipement_p);
    if (!isRetourOK(lireUnResponse._first))
    {
      return lireUnResponse._first;
    }

    ConnectorResponse<Retour, Nothing> supprimerblocageResponse = REXProxy.getInstance().blocageEquipementSupprimer(tracabilite_p, idBlocageEquipement_p);
    if (!isRetourOK(supprimerblocageResponse._first))
    {
      return supprimerblocageResponse._first;
    }

    BlocageEquipement oBlocageEquipement = lireUnResponse._second; // TODO

    LocalDateTime now = LocalDateTime.now();
    String commentaireBlocage = MessageFormat.format(Messages.getString("PE0533.deblocage"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(now)); //$NON-NLS-1$

    final Set<com.bytel.spirit.common.shared.saab.rex.Equipement> listeEqpt = new TreeSet<>(new EquipementComparator());
    listeEqpt.addAll(oBlocageEquipement.getListeEquipement());

    bl100_retour = modifierSurchargePriseClientFromRex(tracabilite_p, listeEqpt, BlocageEquipementStatut.INACTIF.name(), commentaireBlocage);

    return bl100_retour;
  }

  /**
   * Objective of this activity is to create {@link BlocageEquipement} of REX connector with data from the STI,<br />
   * provide a resource identifier which is unique <b>idBlocageEquipement</b>.
   *
   * @param traceability_p
   *          The {@link Tracabilite} to set
   * @param request_p
   *          The request to set
   * @return The return object {@link PE0533_BL200_CreerBlocageEquipementsReturn}
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private final PE0533_BL200_CreerBlocageEquipementsReturn PE0533_BL200_CreerBlocageEquipements(@NotNull Tracabilite traceability_p, @NotNull final PE0533_PostRequest request_p) throws RavelException
  {
    // Functional control : Verify if at least one operation exists with status ACQUITTE or EN_COURS to block the equipment
    Boolean operationEligible = false;
    int operationTrouvee = 0;
    final List<String> donneesBrute = new ArrayList<>();
    for (final String idOperationVieReseau : request_p.getListeIdOperationVieReseau())
    {
      final ConnectorResponse<Retour, OperationVieReseau> operationVieReseauLireUn = REXProxy.getInstance().operationVieReseauLireUn(traceability_p, idOperationVieReseau);
      if (isRetourOK(operationVieReseauLireUn._first))
      {
        donneesBrute.add(operationVieReseauLireUn._second.getDonneeBrute());
        if (Arrays
            .asList( //
                OperationVieReseauStatut.ACQUITTE.name(), //
                OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), //
                OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name()) //
            .contains(operationVieReseauLireUn._second.getStatut()))
        {
          operationEligible = true;
        }
        operationTrouvee++;
      }
    } // for idOperationVieReseau

    if (operationTrouvee == 0)
    {
      return new PE0533_BL200_CreerBlocageEquipementsReturn(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Aucun identifiant OperationVieReseau n’est trouve")); //$NON-NLS-1$
    }

    if (!operationEligible)
    {
      return new PE0533_BL200_CreerBlocageEquipementsReturn(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "Operation vie reseau non eligible pour créer un Blocage Prise Clients")); //$NON-NLS-1$
    }

    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0529_PostRequest> adapter = instance.adapter(PE0529_PostRequest.class);

    final Set<PM> listePMBlocage = new TreeSet<>();
    final Set<OLT> listeOLTBlocage = new TreeSet<>();
    final Set<String> listePMVDR = new TreeSet<>();
    final Set<String> listeOLTVDR = new TreeSet<>();
    for (final Equipement equipment : request_p.getListeEquipement())
    {
      if (equipment instanceof PM)
      {
        final PM other = PM.class.cast(equipment);
        listePMBlocage.add(other);

        // La liste est construite à partir des valeurs de referencePmBytel présentes dans donneesBrutes de toutes les OperationVieReseau de la liste RequestBody.listeIdOperations sans redondance.
        donneesBrute.stream().forEach(jsonRequest -> {

          try
          {
            final PE0529_PostRequest request = adapter.fromJson(jsonRequest);
            listePMVDR.addAll(request.getListeReferencesPmBytel());
          }
          catch (final RavelJsonException exception)
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, exception));
          }
        });
      }
      else if (equipment instanceof OLT)
      {
        final OLT other = OLT.class.cast(equipment);
        listeOLTBlocage.add(other);

        // La liste est construite à partir des valeurs de nomOLT présentes dans donneesBrutes de toutes les OperationVieReseau de la liste RequestBody.listeIdOperations sans redondance.
        donneesBrute.stream().forEach(jsonRequest -> {

          try
          {
            final PE0529_PostRequest request = adapter.fromJson(jsonRequest);
            listeOLTVDR.addAll(request.getListeNomOlt());
          }
          catch (final RavelJsonException exception)
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, exception));
          }
        });
      }
    } // for equipment

    if (!difference( //
        union( //
            listePMBlocage.stream().map(PM::getReferencePmBytel).collect(Collectors.toSet()), //
            listeOLTBlocage.stream().map(OLT::getNomOLT).collect(Collectors.toSet())), //
        union(listePMVDR, listeOLTVDR)) //
            .isEmpty())
    {
      return new PE0533_BL200_CreerBlocageEquipementsReturn(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "liste equipements non eligible pour créer un Blocage Equipement")); //$NON-NLS-1$
    }

    // Construction de l’objet BlocageEquipement à passer au verbe creer
    final BL800_ObtenirSequence bl800 = new BL800_ObtenirSequenceBuilder() //
        .tracabilite(traceability_p) //
        .code(UniqueIdConstant.ID_BLOCAGE_EQUIPEMENT) //
        .build();
    final String idBlocageEquipement = bl800.execute(this);
    if (!isRetourOK(bl800.getRetour()))
    {
      return new PE0533_BL200_CreerBlocageEquipementsReturn(bl800.getRetour());
    }

    final BlocageEquipement blocageEquipement = new BlocageEquipement(idBlocageEquipement, StatutBlockage.ACTIF.name(), request_p.getListeIdOperationVieReseau().stream().collect(Collectors.toSet()), request_p.getListeEquipement().stream().map(Equipement::toSAAB).collect(Collectors.toSet()));

    // Création de l’objet BlocageEquipement dans REX
    final ConnectorResponse<Retour, Nothing> rex = REXProxy.getInstance().blocageEquipementCreer( //
        traceability_p, //
        blocageEquipement);
    if (!isRetourOK(rex._first))
    {
      return new PE0533_BL200_CreerBlocageEquipementsReturn(rex._first);
    }

    // Activation de Blocage de prises clients sur les équipements
    for (final PM pm : listePMBlocage) // Each PM in oListeEquipement
    {
      if (!isEmpty(pm.getListeReferenceBoitierPm()))
      {
        for (final String referenceBoitierPm : pm.getListeReferenceBoitierPm())
        {
          final ConnectorResponse<Retour, Nothing> response = RESProxy.getInstance().pmCompositeModifierSurchargePriseClientBoitierPM( //
              traceability_p, //
              pm.getReferencePmBytel(), //
              referenceBoitierPm, //
              StatutBlockage.ACTIF.name(), //
              MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(LocalDateTime.now()))); //$NON-NLS-1$
          if (!isRetourOK(response._first))
          {
            return new PE0533_BL200_CreerBlocageEquipementsReturn(null, response._first);
          }
        } // for boitierPM
      }
      else
      {
        final ConnectorResponse<Retour, Nothing> response = RESProxy.getInstance().pmCompositeModifierSurchargePriseClientPM( //
            traceability_p, //
            pm.getReferencePmBytel(), //
            StatutBlockage.ACTIF.name(), //
            MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(LocalDateTime.now()))); //$NON-NLS-1$
        if (!isRetourOK(response._first))
        {
          return new PE0533_BL200_CreerBlocageEquipementsReturn(null, response._first);
        }
      }
    } // for pm

    for (final OLT olt : listeOLTBlocage) // Each OLT in oListeEquipement
    {
      if (!isEmpty(olt.getListePositionCarte()))
      {
        for (final Integer positionCarte : olt.getListePositionCarte())
        {
          final ConnectorResponse<Retour, Nothing> response = RESProxy.getInstance().oltCompositeModifierSurchargePriseClientCarte( //
              traceability_p, //
              olt.getNomOLT(), //
              positionCarte.toString(), //
              StatutBlockage.ACTIF.name(), //
              MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(LocalDateTime.now()))); //$NON-NLS-1$
          if (!isRetourOK(response._first))
          {
            return new PE0533_BL200_CreerBlocageEquipementsReturn(null, response._first);
          }
        } // for positionCarte
      }
      else
      {
        final ConnectorResponse<Retour, Nothing> response = RESProxy.getInstance().oltCompositeModifierSurchargePriseClientOLT( //
            traceability_p, //
            olt.getNomOLT(), //
            StatutBlockage.ACTIF.name(), //
            MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(LocalDateTime.now()))); //$NON-NLS-1$
        if (!isRetourOK(response._first))
        {
          return new PE0533_BL200_CreerBlocageEquipementsReturn(null, response._first);
        }
      }
    } // for olt

    final Set<String> listePM = new TreeSet<>();
    final Set<String> listeOLT = new TreeSet<>();
    final Set<String> listeBoitiers = new TreeSet<>();
    final Set<String> listeCartes = new TreeSet<>();
    request_p.getListeEquipement().stream().forEach(equipment -> {

      if (equipment instanceof PM)
      {
        final PM other = PM.class.cast(equipment);
        listePM.add(other.getReferencePmBytel());
        if (nonNull(other.getListeReferenceBoitierPm()))
        {
          listeBoitiers.addAll(other.getListeReferenceBoitierPm().stream() //
              .map(referenceBoitierPm -> new StringBuilder() //
                  .append(other.getReferencePmBytel()) //
                  .append("|") //$NON-NLS-1$
                  .append(referenceBoitierPm) //
                  .toString()) //
              .collect(Collectors.toCollection(TreeSet::new)));
        }
      }
      else if (equipment instanceof OLT)
      {
        final OLT other = OLT.class.cast(equipment);
        listeOLT.add(other.getNomOLT());
        if (nonNull(other.getListePositionCarte()))
        {
          listeCartes.addAll(other.getListePositionCarte().stream() //
              .map(positionCarte -> new StringBuilder() //
                  .append(other.getNomOLT()) //
                  .append("|") //$NON-NLS-1$
                  .append(positionCarte) //
                  .toString()) //
              .collect(Collectors.toCollection(TreeSet::new)));
        }
      }
    });

    final Set<CleRechercheBlocageEquipement> clesRechercheBlocageEquipements = new TreeSet<>(new CleRechercheBlocageEquipementComparator());
    listePM.stream().forEach(referencePmBytel -> clesRechercheBlocageEquipements.add(new CleRechercheBlocageEquipement("PM", referencePmBytel, idBlocageEquipement))); //$NON-NLS-1$
    listeBoitiers.stream().forEach(boitier -> clesRechercheBlocageEquipements.add(new CleRechercheBlocageEquipement("BOITIER", boitier, idBlocageEquipement))); //$NON-NLS-1$
    listeOLT.stream().forEach(nomOlt -> clesRechercheBlocageEquipements.add(new CleRechercheBlocageEquipement("OLT", nomOlt, idBlocageEquipement))); //$NON-NLS-1$
    listeCartes.stream().forEach(carte -> clesRechercheBlocageEquipements.add(new CleRechercheBlocageEquipement("CARTE", carte, idBlocageEquipement))); //$NON-NLS-1$

    final ConnectorResponse<Retour, Nothing> response = REXProxy.getInstance().cleRechercheBlocageEquipementCreerListe(traceability_p, new ListeCleRechercheBlocageEquipementRequest(new ArrayList<>(clesRechercheBlocageEquipements)));
    if (!isRetourOK(response._first))
    {
      return new PE0533_BL200_CreerBlocageEquipementsReturn(null, response._first);
    }

    return new PE0533_BL200_CreerBlocageEquipementsReturn(idBlocageEquipement, RetourFactory.createOkRetour()); // TODO
  }

  /**
   * @param traceability_p
   *          The {@link Tracabilite} to set
   * @param idBlocageEquipement_p
   *          Identifiant unique de oBlocageEquipements dans REX
   * @param listeIdOperationVieReseau_p
   *          La liste des idOperationVieReseau associés au BlocageVieReseau Objet de type " liste String "
   * @param listeEquipements_p
   *          Liste des équipements sur lesquels le blocage doit être appliqué. Type : Tableau d’objet de type
   *          <equipement> (Cf [A1])
   * @return The object {@link Retour}
   * @throws RavelException
   *           {@link RavelException}
   */
  @LogProcessBL
  private final Retour PE0533_BL300_ModifierBlocageEquipements(@NotNull final Tracabilite traceability_p, @NotNull final String idBlocageEquipement_p, @NotNull final Set<String> listeIdOperationVieReseau_p, @NotNull final Set<Equipement> listeEquipements_p) throws RavelException
  {
    // Functional control : Verify if at least one operation exists with status ACQUITTE or EN_COURS to block the equipment
    Boolean operationEligible = false;
    int operationTrouvee = 0;
    final List<String> donneesBrute = new ArrayList<>();
    for (final String idOperationVieReseau : listeIdOperationVieReseau_p)
    {
      final ConnectorResponse<Retour, OperationVieReseau> operationVieReseauLireUn = REXProxy.getInstance().operationVieReseauLireUn(traceability_p, idOperationVieReseau);
      if (isRetourOK(operationVieReseauLireUn._first))
      {
        donneesBrute.add(operationVieReseauLireUn._second.getDonneeBrute());
        if (Arrays
            .asList( //
                OperationVieReseauStatut.ACQUITTE.name(), //
                OperationVieReseauStatut.EN_COURS_PROVISIONING.name(), //
                OperationVieReseauStatut.EN_COURS_MAJ_REFERENTIEL.name()) //
            .contains(operationVieReseauLireUn._second.getStatut()))
        {
          operationEligible = true;
        }
        operationTrouvee++;
      }
    } // for idOperationVieReseau

    if (operationTrouvee == 0)
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Aucun identifiant OperationVieReseau n’est trouve"); //$NON-NLS-1$
    }

    if (!operationEligible)
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "Operation vie reseau non eligible pour modifier un Blocage Prise Clients"); //$NON-NLS-1$
    }

    // Lecture de BlocageEquipements dans REX
    final ConnectorResponse<Retour, BlocageEquipement> blocageEquipementLireUn = REXProxy.getInstance().blocageEquipementLireUn( //
        traceability_p, //
        idBlocageEquipement_p);
    if (!isRetourOK(blocageEquipementLireUn._first))
    {
      return blocageEquipementLireUn._first;
    }

    // On sauvegarde la liste des equipenets bloqués dans listeEquipementInitiale
    final Set<Equipement> equipementInitiale = new TreeSet<>();
    for (final com.bytel.spirit.common.shared.saab.rex.Equipement equipement : blocageEquipementLireUn._second.getListeEquipement()) // TODO
    {
      switch (equipement.getType())
      {
        case "OLT": //$NON-NLS-1$
          equipementInitiale.add(new OLT(equipement));
          break;

        case "PM": //$NON-NLS-1$
          equipementInitiale.add(new PM(equipement));
          break;

        default:
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, "Unknow equipment type: " + equipement.getType())); //$NON-NLS-1$
      }
    }

    // Vérification des idOperationVieReseau
    if (listeIdOperationVieReseau_p.size() < blocageEquipementLireUn._second.getListeIdOperationVieReseau().size())
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, "mettre tous les idOperationVieReseau dans listeIdOperationVieReseau"); //$NON-NLS-1$
    }

    // Vérification Si les équipements dans oListeEquimepents[] sont impactés dans les VDR dont id est dans oListeIdOperationVieReseau[]
    final IRavelJson instance = new RavelJsonBuilder() //
        .profil("STARK") //$NON-NLS-1$
        .build(); //
    final IRavelJsonAdapter<PE0529_PostRequest> adapter = instance.adapter(PE0529_PostRequest.class);

    final Set<PM> listePMBlocage = new TreeSet<>();
    final Set<OLT> listeOLTBlocage = new TreeSet<>();
    final Set<String> listePMVDR = new TreeSet<>();
    final Set<String> listeOLTVDR = new TreeSet<>();
    for (final Equipement equipment : listeEquipements_p)
    {
      if (equipment instanceof PM)
      {
        final PM other = PM.class.cast(equipment);
        listePMBlocage.add(other);

        // La liste est construite à partir des valeurs de referencePmBytel présentes dans donneesBrutes de toutes les OperationVieReseau de la liste RequestBody.listeIdOperations sans redondance.
        donneesBrute.stream().forEach(jsonRequest -> {

          try
          {
            final PE0529_PostRequest request = adapter.fromJson(jsonRequest);
            listePMVDR.addAll(request.getListeReferencesPmBytel());
          }
          catch (final RavelJsonException exception)
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, exception));
          }
        });
      }
      else if (equipment instanceof OLT)
      {
        final OLT other = OLT.class.cast(equipment);
        listeOLTBlocage.add(other);

        // La liste est construite à partir des valeurs de nomOLT présentes dans donneesBrutes de toutes les OperationVieReseau de la liste RequestBody.listeIdOperations sans redondance.
        donneesBrute.stream().forEach(jsonRequest -> {

          try
          {
            final PE0529_PostRequest request = adapter.fromJson(jsonRequest);
            listeOLTVDR.addAll(request.getListeNomOlt());
          }
          catch (final RavelJsonException exception)
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, exception));
          }
        });
      }
    } // for equipment

    if (!difference( //
        union( //
            listePMBlocage.stream().map(PM::getReferencePmBytel).collect(Collectors.toSet()), //
            listeOLTBlocage.stream().map(OLT::getNomOLT).collect(Collectors.toSet())), //
        union(listePMVDR, listeOLTVDR)) //
            .isEmpty())
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "liste equipements non eligible pour créer un Blocage Prise Clients"); //$NON-NLS-1$
    }

    // Modification de blocage prise Clients dans REX
    final Set<com.bytel.spirit.common.shared.saab.rex.Equipement> equipements = new TreeSet<>(new EquipementComparator());
    equipements.addAll(listeEquipements_p.stream().map(Equipement::toSAAB).collect(Collectors.toSet()));
    final ConnectorResponse<Retour, Nothing> blocageEquipementModifier = REXProxy.getInstance().blocageEquipementModifier( //
        traceability_p, //
        new UpdateBlocageEquipementRequest(idBlocageEquipement_p, listeIdOperationVieReseau_p, equipements));
    if (!isRetourOK(blocageEquipementModifier._first))
    {
      return blocageEquipementModifier._first;
    }

    // Dé-activation de Blocage de prises clients sur les équipements de listeEquipementInitiale
    Retour retour = modifierSurchargePriseClient(traceability_p, equipementInitiale, StatutBlockage.INACTIF.name(), null);
    if (!isRetourOK(retour))
    {
      return retour;
    }

    // Activation de Blocage de prises clients sur les équipements
    retour = modifierSurchargePriseClient(traceability_p, listeEquipements_p, StatutBlockage.ACTIF.name(), MessageFormat.format(Messages.getString("PE0533.blocageVR"), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZ.format(LocalDateTime.now()))); //$NON-NLS-1$
    if (!isRetourOK(retour))
    {
      return retour;
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Send a sync response for requester.
   *
   * @param traceability_p
   *          The {@link Tracabilite} to set
   * @param request_p
   *          The request object
   * @param retour_p
   *          The status object {@link Retour}
   * @param response_p
   *          the response object
   */
  private void syncPostResponse(@NotNull final Tracabilite traceability_p, @NotNull final Request request_p, @NotNull final Retour retour_p, @NotNull final PE0533_BL002_FormaterReponseCreationReturn response_p)
  {
    if (nonNull(request_p))
    {
      final IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ErrorCode errorCode = null;
      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

      try
      {
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(response_p, PE0533_BL002_FormaterReponseCreationReturn.class));
      }
      catch (final RavelException exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, exception));
      }

      if (isRetourOK(retour_p))
      {
        errorCode = ErrorCode.OK_00201;
      }
      else
      {
        if (retour_p.getDiagnostic().equals(IMegSpiritConsts.ACCES_REFUSE))
        {
          errorCode = ErrorCode.KO_00403;
        }
        else
        {
          errorCode = super.getDefaultHttpCodeFromRetour(retour_p);
        }
      }

      request_p.setResponse(new Response(errorCode, ravelResponse));
    }
  }

  /**
   * @param traceability_p
   * @param request_p
   * @param retour_p
   * @param bl002_p
   */
  private void syncPutResponse(@NotNull Tracabilite traceability_p, @NotNull Request request_p, Retour retour_p, ReponseErreur bl002_p)
  {
    if (nonNull(request_p))
    {
      final IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ErrorCode errorCode = null;
      if (nonNull(bl002_p))
      {
        try
        {
          ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
          ravelResponse.setResult(RavelJsonTools.getInstance().toJson(bl002_p, ReponseErreur.class));
        }
        catch (final RavelException exception)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, traceability_p, exception));
        }
      }

      if (isRetourOK(retour_p))
      {
        errorCode = ErrorCode.OK_00204;
      }
      else
      {
        if (retour_p.getDiagnostic().equals(IMegSpiritConsts.ACCES_REFUSE))
        {
          errorCode = ErrorCode.KO_00403;
        }
        else
        {
          errorCode = super.getDefaultHttpCodeFromRetour(retour_p);
        }
      }
      request_p.setResponse(new Response(errorCode, ravelResponse));
    }
  }
}
