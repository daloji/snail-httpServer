/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PI0574.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author hduarte
 * @version ($Revision$ $Date$)
 */
public class PI0574_EnvoyerModCommClotureRequest implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -8046227887449770381L;

  /**
   *
   * idCmd
   *
   */
  @Json(name = "idCmd")
  private String _idCmd;

  /**
   *
   * idExterne
   *
   */
  @Json(name = "idExterne")
  private String _idExterne;

  /**
   *
   * idModComm
   *
   */
  @Json(name = "idModComm")
  private String _idModComm;

  /**
   *
   * natureCommande
   *
   */
  @Json(name = "natureCommande")
  private String _natureCommande;

  /**
   *
   * statut
   *
   */
  @Json(name = "statut")
  private String _statut;

  /**
   *
   * raisonErreur
   *
   */
  @Json(name = "raison_Erreur")
  private String _raisonErreur;

  /**
   *
   * systemeAppelant
   *
   */
  @Json(name = "systemeAppelant")
  private String _systemeAppelant;

  /**
   *
   * clientOperateur
   *
   */
  @Json(name = "clientOperateur")
  private String _clientOperateur;

  /**
   *
   * noCompte
   *
   */
  @Json(name = "noCompte")
  private String _noCompte;

  /**
   * @param idCmd_p
   *          idCmd
   * @param idExterne_p
   *          idExterne
   * @param idModComm_p
   *          idModComm
   * @param natureCommande_p
   *          natureCommande
   * @param statut_p
   *          statut
   * @param raisonErreur_p
   *          raisonErreur
   * @param systemeAppelant_p
   *          systemeAppelant
   * @param clientOperateur_p
   *          clientOperateur
   * @param noCompte_p
   *          noCompte
   */
  public PI0574_EnvoyerModCommClotureRequest(String idCmd_p, String idExterne_p, String idModComm_p, String natureCommande_p, String statut_p, String raisonErreur_p, String systemeAppelant_p, String clientOperateur_p, String noCompte_p)
  {
    super();
    _idCmd = idCmd_p;
    _idExterne = idExterne_p;
    _idModComm = idModComm_p;
    _natureCommande = natureCommande_p;
    _statut = statut_p;
    _raisonErreur = raisonErreur_p;
    _systemeAppelant = systemeAppelant_p;
    _clientOperateur = clientOperateur_p;
    _noCompte = noCompte_p;
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the idCmd
   */
  public String getIdCmd()
  {
    return _idCmd;
  }

  /**
   * @return the idExterne
   */
  public String getIdExterne()
  {
    return _idExterne;
  }

  /**
   * @return the idModComm
   */
  public String getIdModComm()
  {
    return _idModComm;
  }

  /**
   * @return the natureCommande
   */
  public String getNatureCommande()
  {
    return _natureCommande;
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the raisonErreur
   */
  public String getRaisonErreur()
  {
    return _raisonErreur;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the systemeAppelant
   */
  public String getSystemeAppelant()
  {
    return _systemeAppelant;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param idCmd_p
   *          the idCmd to set
   */
  public void setIdCmd(String idCmd_p)
  {
    _idCmd = idCmd_p;
  }

  /**
   * @param idExterne_p
   *          the idExterne to set
   */
  public void setIdExterne(String idExterne_p)
  {
    _idExterne = idExterne_p;
  }

  /**
   * @param idModComm_p
   *          the idModComm to set
   */
  public void setIdModComm(String idModComm_p)
  {
    _idModComm = idModComm_p;
  }

  /**
   * @param natureCommande_p
   *          the natureCommande to set
   */
  public void setNatureCommande(String natureCommande_p)
  {
    _natureCommande = natureCommande_p;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param raisonErreur_p
   *          the raisonErreur to set
   */
  public void setRaisonErreur(String raisonErreur_p)
  {
    _raisonErreur = raisonErreur_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param systemeAppelant_p
   *          the systemeAppelant to set
   */
  public void setSystemeAppelant(String systemeAppelant_p)
  {
    _systemeAppelant = systemeAppelant_p;
  }

}
