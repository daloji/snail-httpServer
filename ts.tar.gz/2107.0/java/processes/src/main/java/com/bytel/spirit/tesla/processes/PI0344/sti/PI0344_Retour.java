/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PI0344.sti;

import com.bytel.ravel.types.Retour;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.squareup.moshi.Json;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PI0344_Retour extends BasicResponse
{

  /**
   * ReponseFonctionnelle
   *
   * @author mbaptist
   * @version ($Revision$ $Date$)
   */
  public static class ReponseFonctionnelle
  {
    /**
     * Détail de l'équipement OLT
     */
    @Json(name = "olt")
    private PI0344_RecupererDetailProvisioningPONOlt _olt;

    /**
     * Détail de la carte
     */
    @Json(name = "carte")
    private PI0344_RecupererDetailProvisioningPONCarte _carte;

    /**
     * Liste des caractéristiques utiles au provisioning
     */
    @Json(name = "donneesSpecifiques")
    private PI0344_RecupererDetailProvisioningPONDonneesSpecifiques _donneesSpecifiques;

    /**
     * Statut technique agrégé
     */
    @Json(name = "statutTechnique")
    private String _statutTechnique;

    /**
     * tracabilite
     */
    @Json(name = "tracabilite")
    private Tracabilite _tracabilite;

    /**
     *
     */
    public ReponseFonctionnelle()
    {
      super();
    }

    /**
     * @param olt_p
     *          olt
     * @param carte_p
     *          carte
     * @param donneesSpecifiques_p
     *          donneesSpecifiques
     * @param tracabilitePI_p
     *          tracabilite
     * @param statutTechnique_p
     *          statutTechnique
     */
    public ReponseFonctionnelle(PI0344_RecupererDetailProvisioningPONOlt olt_p, PI0344_RecupererDetailProvisioningPONCarte carte_p, PI0344_RecupererDetailProvisioningPONDonneesSpecifiques donneesSpecifiques_p, Tracabilite tracabilitePI_p, String statutTechnique_p)
    {
      super();
      _olt = olt_p;
      _carte = carte_p;
      _donneesSpecifiques = donneesSpecifiques_p;
      _tracabilite = tracabilitePI_p;
      _statutTechnique = statutTechnique_p;
    }

    /**
     * @return the carte
     */
    public PI0344_RecupererDetailProvisioningPONCarte getPI0344RecupererDetailProvisioningPONCarte()
    {
      return _carte;
    }

    /**
     * @return the donneesSpecifiques
     */
    public PI0344_RecupererDetailProvisioningPONDonneesSpecifiques getPI0344RecupererDetailProvisioningPONDonneesSpecifiques()
    {
      return _donneesSpecifiques;
    }

    /**
     * @return the olt
     */
    public PI0344_RecupererDetailProvisioningPONOlt getPI0344RecupererDetailProvisioningPONOlt()
    {
      return _olt;
    }

    /**
     * @return the statutTechnique
     */
    public String getStatutTechnique()
    {
      return _statutTechnique;
    }

    /**
     * @return the tracabilite
     */
    public Tracabilite getTracabilite()
    {
      return _tracabilite;
    }

    /**
     * @param carte_p
     *          the carte to set
     */
    public void setPI0344RecupererDetailProvisioningPONCarte(PI0344_RecupererDetailProvisioningPONCarte carte_p)
    {
      _carte = carte_p;
    }

    /**
     * @param donneesSpecifiques_p
     *          the donneesSpecifiques to set
     */
    public void setPI0344RecupererDetailProvisioningPONDonneesSpecifiques(PI0344_RecupererDetailProvisioningPONDonneesSpecifiques donneesSpecifiques_p)
    {
      _donneesSpecifiques = donneesSpecifiques_p;
    }

    /**
     * @param olt_p
     *          the olt to set
     */
    public void setPI0344RecupererDetailProvisioningPONOlt(PI0344_RecupererDetailProvisioningPONOlt olt_p)
    {
      _olt = olt_p;
    }

    /**
     * @param statutTechnique_p
     *          the statutTechnique to set
     */
    public void setStatutTechnique(String statutTechnique_p)
    {
      _statutTechnique = statutTechnique_p;
    }

    /**
     * @param tracabilite_p
     *          the tracabilite to set
     */
    public void setTracabilite(Tracabilite tracabilite_p)
    {
      _tracabilite = tracabilite_p;
    }

  }

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * reponseFonctionnelle
   */
  @Json(name = "reponseFonctionnelle")
  private ReponseFonctionnelle _reponseFonctionnelle;

  /**
   * @param retour_p
   *          retour
   */
  public PI0344_Retour(Retour retour_p)
  {
    super(retour_p);

  }

  /**
   * @param retour_p
   *          retour
   * @param reponseFonctionnelle_p
   *          reponseFonctionnelle
   */
  public PI0344_Retour(Retour retour_p, ReponseFonctionnelle reponseFonctionnelle_p)
  {
    super(retour_p);
    _reponseFonctionnelle = reponseFonctionnelle_p;
  }

  /**
   * @return the reponseFonctionnelle
   */
  public ReponseFonctionnelle getReponseFonctionnelle()
  {
    return _reponseFonctionnelle;
  }

  /**
   * @param reponseFonctionnelle_p
   *          the reponseFonctionnelle to set
   */
  public void setReponseFonctionnelle(ReponseFonctionnelle reponseFonctionnelle_p)
  {
    _reponseFonctionnelle = reponseFonctionnelle_p;
  }

}
