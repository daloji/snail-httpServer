/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0529.structs;

import java.util.Objects;
import java.util.StringJoiner;

import com.bytel.spirit.common.shared.saab.rex.ClientImpacte;
import com.bytel.spirit.tesla.shared.types.PE0529.PositionPortPm;

/**
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public class ProvisioningVDRMigration extends ProvisioningVDR
{

  /**
   * Position port PM source
   */
  private PositionPortPm _source;

  /**
   * Position port PM cible
   */
  private PositionPortPm _cible;

  /**
   * Constructeur
   *
   * @param clientImpacte_p
   *     the clientImpacte to set
   * @param source_p
   *     the positionPortPm source to set
   * @param cible_p
   *     the positionPortPm cible to set
   */
  public ProvisioningVDRMigration(ClientImpacte clientImpacte_p, PositionPortPm source_p, PositionPortPm cible_p)
  {
    super(clientImpacte_p);
    _source = source_p;
    _cible = cible_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
    {
      return true;
    }
    if (o_p == null || getClass() != o_p.getClass())
    {
      return false;
    }
    if (!super.equals(o_p))
    {
      return false;
    }
    ProvisioningVDRMigration that = (ProvisioningVDRMigration) o_p;
    return Objects.equals(_source, that._source) && Objects.equals(_cible, that._cible);
  }

  /**
   * @return value of _cible.
   */
  public PositionPortPm getCible()
  {
    return _cible;
  }

  @Override
  public String getIdPortImpacte()
  {
    StringJoiner joiner = new StringJoiner("/");
    joiner.add(_cible.getReferencePmBytel());
    joiner.add(_cible.getReferenceBoitierPm());
    joiner.add(_cible.getNomPanneau());
    joiner.add(String.valueOf(_cible.getPositionPort()));
    return joiner.toString();
  }

  /**
   * @return value of _source.
   */
  public PositionPortPm getSource()
  {
    return _source;
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(super.hashCode(), _source, _cible);
  }

  /**
   * @param cible_p
   *     the _cible to set.
   */
  public void setCible(PositionPortPm cible_p)
  {
    _cible = cible_p;
  }

  /**
   * @param source_p
   *     the _source to set.
   */
  public void setSource(PositionPortPm source_p)
  {
    _source = source_p;
  }

  @Override
  public String toString()
  {
    return "ProvisioningVDRMigration [" + "_clientImpacte=" + _clientImpacte + ", _listeCleSequencement=" + _listeCleSequencement + ", _noCompte=" + _noCompte + ", _clientOperateur=" + _clientOperateur + ", _ressourcePortPM=" + _ressourcePortPM + ", _ticketLissage=" + _ticketLissage + ", _source=" + _source + ", _cible=" + _cible + "]"; // $NON-NLS-1$ // $NON-NLS-2$ // $NON-NLS-3$ // $NON-NLS-4$ // $NON-NLS-5$ // $NON-NLS-6$ // $NON-NLS-7$ // $NON-NLS-8$ // $NON-NLS-9$ // $NON-NLS-10$
  }
}
