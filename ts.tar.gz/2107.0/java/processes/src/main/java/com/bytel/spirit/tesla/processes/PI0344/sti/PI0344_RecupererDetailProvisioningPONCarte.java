/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PI0344.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.squareup.moshi.Json;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PI0344_RecupererDetailProvisioningPONCarte implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 2706391249408276050L;

  /**
   * Carte position
   */
  @Json(name = "position")
  private Integer _position;

  /**
   * Carte type
   */
  @Json(name = "typeCarte")
  private String _typeCarte;

  /**
   * Statut technique Carte
   */
  @Json(name = "statutTechnique")
  private String _statutTechnique;

  /**
   * dateCreation attribute
   */
  @Json(name = "dateCreation")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateCreation;

  /**
   * dateModification attribute
   */
  @Json(name = "dateModification")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateModification;

  /**
   * @param position_p
   *          position
   * @param typeCarte_p
   *
   *          typeCarte
   * @param modele_p
   *
   *          modele
   * @param statutTechnique_p
   *          statutTechnique
   */
  public PI0344_RecupererDetailProvisioningPONCarte(Integer position_p, String typeCarte_p, String statutTechnique_p)
  {
    super();
    _position = position_p;
    _typeCarte = typeCarte_p;
    _statutTechnique = statutTechnique_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PI0344_RecupererDetailProvisioningPONCarte other = (PI0344_RecupererDetailProvisioningPONCarte) obj;
    if (_dateCreation == null)
    {
      if (other._dateCreation != null)
      {
        return false;
      }
    }
    else if (!_dateCreation.equals(other._dateCreation))
    {
      return false;
    }
    if (_dateModification == null)
    {
      if (other._dateModification != null)
      {
        return false;
      }
    }
    else if (!_dateModification.equals(other._dateModification))
    {
      return false;
    }
    if (_position == null)
    {
      if (other._position != null)
      {
        return false;
      }
    }
    else if (!_position.equals(other._position))
    {
      return false;
    }
    if (_statutTechnique == null)
    {
      if (other._statutTechnique != null)
      {
        return false;
      }
    }
    else if (!_statutTechnique.equals(other._statutTechnique))
    {
      return false;
    }
    if (_typeCarte == null)
    {
      if (other._typeCarte != null)
      {
        return false;
      }
    }
    else if (!_typeCarte.equals(other._typeCarte))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateCreation
   */
  public LocalDateTime getDateCreation()
  {
    return _dateCreation;
  }

  /**
   * @return the dateModification
   */
  public LocalDateTime getDateModification()
  {
    return _dateModification;
  }

  /**
   * @return the position
   */
  public Integer getPosition()
  {
    return _position;
  }

  /**
   * @return the statutTechnique
   */
  public String getStatutTechnique()
  {
    return _statutTechnique;
  }

  /**
   * @return the typeCarte
   */
  public String getTypeCarte()
  {
    return _typeCarte;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateCreation == null) ? 0 : _dateCreation.hashCode());
    result = (prime * result) + ((_dateModification == null) ? 0 : _dateModification.hashCode());
    result = (prime * result) + ((_position == null) ? 0 : _position.hashCode());
    result = (prime * result) + ((_statutTechnique == null) ? 0 : _statutTechnique.hashCode());
    result = (prime * result) + ((_typeCarte == null) ? 0 : _typeCarte.hashCode());
    return result;
  }

  /**
   * @param dateCreation_p
   *          the dateCreation to set
   */
  public void setDateCreation(LocalDateTime dateCreation_p)
  {
    _dateCreation = dateCreation_p;
  }

  /**
   * @param dateModification_p
   *          the dateModification to set
   */
  public void setDateModification(LocalDateTime dateModification_p)
  {
    _dateModification = dateModification_p;
  }

  /**
   * @param position_p
   *          the position to set
   */
  public void setPosition(Integer position_p)
  {
    _position = position_p;
  }

  /**
   * @param statutTechnique_p
   *          the statutTechnique to set
   */
  public void setStatutTechnique(String statutTechnique_p)
  {
    _statutTechnique = statutTechnique_p;
  }

  /**
   * @param typeCarte_p
   *          the typeCarte to set
   */
  public void setTypeCarte(String typeCarte_p)
  {
    _typeCarte = typeCarte_p;
  }

  @Override
  public String toString()
  {
    return "PI0344_RecupererDetailProvisioningPONCarte [_position=" + _position + ", _typeCarte=" + _typeCarte + ", _statutTechnique=" + _statutTechnique + ", _dateCreation=" + _dateCreation + ", _dateModification=" + _dateModification + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
  }

}
