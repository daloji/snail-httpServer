/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.processes.PE0341.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.Rfc3339LocalDateTime;
import com.bytel.spirit.common.shared.functional.types.json.notification.structs.DonneesOntInconnu;
import com.bytel.spirit.common.shared.functional.types.json.notification.structs.Pfi;
import com.squareup.moshi.Json;

/**
 *
 * @author aazzouzi
 * @version ($Revision$ $Date$)
 */
public class PE0341_NotificationReseauSTI implements Serializable
{

  /**
   * Serial versionUID
   */
  private static final long serialVersionUID = 2553145080130217950L;

  /** typeEvenement */
  @Json(name = "typeEvenement")
  private String _typeEvenement;

  /** donneesOntInconnu */
  @Json(name = "donneesOntInconnu")
  private DonneesOntInconnu _donneeOntInconnu;

  /** pfi */
  @Json(name = "pfi")
  private Pfi _pfi;

  /** dateReception **/
  @Json(name = "dateReception")
  @RavelLocalDateTimeFormat(Rfc3339LocalDateTime.class)
  private LocalDateTime _dateReception;

  /** dateGenerationEvenementReseau **/
  @Json(name = "dateGenerationEvenementReseau")
  @RavelLocalDateTimeFormat(Rfc3339LocalDateTime.class)
  private LocalDateTime _dateGenerationEvenementReseau;

  /**
   * @param typeEvenement_p
   *          The typeEvenement
   * @param donneeOntInconnu_p
   *          donneeOntInconnu
   */
  public PE0341_NotificationReseauSTI(String typeEvenement_p, DonneesOntInconnu donneeOntInconnu_p)
  {
    super();
    _typeEvenement = typeEvenement_p;
    _donneeOntInconnu = donneeOntInconnu_p;

  }

  /**
   * @param typeEvenement_p
   *          The typeEvenement
   * @param donneeOntInconnu_p
   *          donneeOntInconnu
   * @param pfi_p
   *          pfi
   */
  public PE0341_NotificationReseauSTI(String typeEvenement_p, DonneesOntInconnu donneeOntInconnu_p, Pfi pfi_p)
  {
    super();
    _typeEvenement = typeEvenement_p;
    _donneeOntInconnu = donneeOntInconnu_p;
    _pfi = pfi_p;

  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0341_NotificationReseauSTI other = (PE0341_NotificationReseauSTI) obj;
    if (_dateGenerationEvenementReseau == null)
    {
      if (other._dateGenerationEvenementReseau != null)
      {
        return false;
      }
    }
    else if (!_dateGenerationEvenementReseau.equals(other._dateGenerationEvenementReseau))
    {
      return false;
    }
    if (_dateReception == null)
    {
      if (other._dateReception != null)
      {
        return false;
      }
    }
    else if (!_dateReception.equals(other._dateReception))
    {
      return false;
    }
    if (_donneeOntInconnu == null)
    {
      if (other._donneeOntInconnu != null)
      {
        return false;
      }
    }
    else if (!_donneeOntInconnu.equals(other._donneeOntInconnu))
    {
      return false;
    }
    if (_pfi == null)
    {
      if (other._pfi != null)
      {
        return false;
      }
    }
    else if (!_pfi.equals(other._pfi))
    {
      return false;
    }
    if (_typeEvenement == null)
    {
      if (other._typeEvenement != null)
      {
        return false;
      }
    }
    else if (!_typeEvenement.equals(other._typeEvenement))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateGenerationEvenementReseau
   */
  public LocalDateTime getDateGenerationEvenementReseau()
  {
    return _dateGenerationEvenementReseau;
  }

  /**
   * @return the dateReception
   */
  public LocalDateTime getDateReception()
  {
    return _dateReception;
  }

  /**
   * @return the donneeOntInconnu
   */
  public DonneesOntInconnu getDonneeOntInconnu()
  {
    return _donneeOntInconnu;
  }

  /**
   * @return value of _pfi
   */
  public Pfi getPfi()
  {
    return _pfi;
  }

  /**
   * @return the typeEvenement
   */
  public String getTypeEvenement()
  {
    return _typeEvenement;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateGenerationEvenementReseau == null) ? 0 : _dateGenerationEvenementReseau.hashCode());
    result = (prime * result) + ((_dateReception == null) ? 0 : _dateReception.hashCode());
    result = (prime * result) + ((_donneeOntInconnu == null) ? 0 : _donneeOntInconnu.hashCode());
    result = (prime * result) + ((_pfi == null) ? 0 : _pfi.hashCode());
    result = (prime * result) + ((_typeEvenement == null) ? 0 : _typeEvenement.hashCode());
    return result;
  }

  /**
   * @param dateGenerationEvenementReseau_p
   *          the dateGenerationEvenementReseau to set
   */
  public void setDateGenerationEvenementReseau(LocalDateTime dateGenerationEvenementReseau_p)
  {
    _dateGenerationEvenementReseau = dateGenerationEvenementReseau_p;
  }

  /**
   * @param dateReception_p
   *          the dateReception to set
   */
  public void setDateReception(LocalDateTime dateReception_p)
  {
    _dateReception = dateReception_p;
  }

  /**
   * @param donneeOntInconnu_p
   *          the donneeOntInconnu to set
   */
  public void setDonneeOntInconnu(DonneesOntInconnu donneeOntInconnu_p)
  {
    _donneeOntInconnu = donneeOntInconnu_p;
  }

  /**
   * @param pfi_p
   *          The _pfi to set.
   */
  public void setPfi(Pfi pfi_p)
  {
    _pfi = pfi_p;
  }

  /**
   * @param typeEvenement_p
   *          the typeEvenement to set
   */
  public void setTypeEvenement(String typeEvenement_p)
  {
    _typeEvenement = typeEvenement_p;
  }

  @Override
  public String toString()
  {
    return "PE0341_NotificationReseauSTI [_typeEvenement=" + _typeEvenement + ", _donneeOntInconnu=" + _donneeOntInconnu + ", _pfi=" + _pfi + ", _dateReception=" + _dateReception + ", _dateGenerationEvenementReseau=" + _dateGenerationEvenementReseau + "]"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$//$NON-NLS-5$ //$NON-NLS-6$
  }

}
