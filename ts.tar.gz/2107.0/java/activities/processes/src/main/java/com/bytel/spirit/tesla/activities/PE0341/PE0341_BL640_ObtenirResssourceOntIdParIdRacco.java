/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import static java.util.Objects.isNull;

import java.text.MessageFormat;
import java.util.StringJoiner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.aspectJ.LogActivity;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI096_LireNrmInfosParIdRacco;
import com.bytel.spirit.common.connectors.nrm.structs.NRMInfosParIdRacco;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.activities.Messages;
import com.bytel.spirit.tesla.activities.PE0341.structs.RessourceOntId;

/**
 *
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
public final class PE0341_BL640_ObtenirResssourceOntIdParIdRacco extends BuiltActivityContext<RessourceOntId>
{
  /**
   * The PE0341_BL640_ObtenirResssourceOntIdParIdRacco builder
   *
   * @author JCHEVRON
   * @version ($Revision$ $Date$)
   */
  public static final class PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder
  {
    /**
     * The PE0341_BL640_ObtenirResssourceOntIdParIdRacco object to build
     */
    private final PE0341_BL640_ObtenirResssourceOntIdParIdRacco _toBuild;

    /**
     * The builder constructor
     */
    public PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder()
    {
      _toBuild = new PE0341_BL640_ObtenirResssourceOntIdParIdRacco();
    }

    /**
     * Controls the required fields of {@link PE0341_BL640_ObtenirResssourceOntIdParIdRacco} and returns the instance.
     *
     * @return The {@link PE0341_BL640_ObtenirResssourceOntIdParIdRacco} instance
     */
    public PE0341_BL640_ObtenirResssourceOntIdParIdRacco build()
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$
      if (isNull(_toBuild.getTracabilite()))
      {
        joiner.add("'_tracabilite'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getIdRaccordement()))
      {
        joiner.add("'_idRaccordement'"); //$NON-NLS-1$
      }

      // PARAMETRE INVALIDE
      if (0 != joiner.length())
      {
        _toBuild.setRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0341_BL640_ObtenirResssourceOntIdParIdRacco.paramNotFilled"), joiner.toString()))); //$NON-NLS-1$
      }

      return _toBuild;
    }

    /**
     * Set the idRaccordement parameter in PE0341_BL640_ObtenirResssourceOntIdParIdRacco instance
     *
     * @param idRaccordement_p
     *          The idRaccordement
     * @return The builder instance
     */
    public PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder idRaccordement(final String idRaccordement_p)
    {
      _toBuild.setIdRaccordement(idRaccordement_p);
      return this;
    }

    /**
     * Set the Tracabilite parameter in PE0341_BL640_ObtenirResssourceOntIdParIdRacco instance
     *
     * @param tracabilite_p
     *          The tracabilite
     * @return The builder instance
     */
    public PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder tracabilite(final Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }

  }

  /**
   * Definition of all execution steps.
   *
   * @author JCHEVRON
   * @version ($Revision$ $Date$)
   */
  private enum Step
  {
    /**
     * first step to execute.
     */
    First,

    /**
     * if all steps have been executed.
     */
    End
  }

  /**
   *
   */
  private static final long serialVersionUID = -3764071191951608745L;

  /**
   * ID Raccordement
   */
  private String _idRaccordement;

  /**
   * Tracabilite
   */
  private Tracabilite _tracabilite;

  /**
   * The next step of the activity to execute.
   */
  private Step _nextStep = Step.First;

  @Override
  @LogActivity
  public RessourceOntId executeNextStep(IActivityCaller iActivityCaller_p) throws RavelException
  {
    RessourceOntId result = null;

    switch (_nextStep)
    {
      case First:
        result = obtenirResssourceOntIdParIdRacco(iActivityCaller_p);
        _nextStep = Step.End;
        break;

      default:
        break;
    }

    return result;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_nextStep);
  }

  /**
   * @param iActivityCaller_p
   *          iActivityCaller
   * @return RessourceOntId
   * @throws RavelException
   *           In case of RavelException
   */
  private RessourceOntId obtenirResssourceOntIdParIdRacco(IActivityCaller iActivityCaller_p) throws RavelException
  {
    // Récupération les caracteristiques de l’accès FTTH sur le système technique Legacy {NRM}
    OSSFAI_SI096_LireNrmInfosParIdRacco si096_lireNrmInfosParIdRacco = new OSSFAI_SI096_LireNrmInfosParIdRacco.OSSFAI_SI096_LireNrmInfosParIdRaccoBuilder()//
        .tracabilite(_tracabilite)//
        .idRessourceRaccordement(_idRaccordement)//
        .build();
    NRMInfosParIdRacco si096_infos = si096_lireNrmInfosParIdRacco.execute(iActivityCaller_p);
    Retour si096_retour = si096_lireNrmInfosParIdRacco.getRetour();

    if (RetourFactory.isRetourNOK(si096_retour))
    {
      setRetour(si096_retour);
      return null;
    }

    String nomOlt = si096_infos.getNomOlt();
    Integer ontId = si096_infos.getOntId();
    Integer positionCartePon = si096_infos.getCarte();
    Integer positionPortPon = si096_infos.getPort();
    String idRessourceLie = _idRaccordement;
    setRetour(si096_retour);

    return new RessourceOntId(nomOlt, ontId, positionCartePon, positionPortPon, idRessourceLie);
  }

  /**
   * @return the _idRaccordement
   */
  String getIdRaccordement()
  {
    return _idRaccordement;
  }

  /**
   * @return the tracabilite
   */
  Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @param idRaccordement_p
   *          the idRaccordement to set
   */
  void setIdRaccordement(String idRaccordement_p)
  {
    _idRaccordement = idRaccordement_p;
  }

  /**
   * @param tracabilite_p
   *          the tracabilite to set
   */
  void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }
}
