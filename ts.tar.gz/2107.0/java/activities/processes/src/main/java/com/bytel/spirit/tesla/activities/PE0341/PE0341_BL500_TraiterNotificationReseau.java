/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import static java.util.Objects.isNull;

import java.text.MessageFormat;
import java.util.StringJoiner;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.aspectJ.LogActivity;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.shared.functional.types.json.notification.AbstractNotificationReseau;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauONTInconnuJSON;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauRecommandationTvJSON;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.NotificationReseauType;
import com.bytel.spirit.tesla.activities.Messages;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL600_TraiterNotificationOntInconnu.PE0341_BL600_TraiterNotificationOntInconnuBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationReturn;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigurationAChaudPE;

/**
 * Contexte du BL500 Traiter Notification Reseau.
 *
 * @author icarrao
 * @version ($Revision$ $Date$)
 */
public final class PE0341_BL500_TraiterNotificationReseau extends BuiltActivityContext<TraiterNotificationReturn>
{
  /**
   * The PE0341_BL500_TraiterNotificationReseau builder
   *
   * @author icarrao
   * @version ($Revision$ $Date$)
   */
  public static final class PE0341_BL500_TraiterNotificationReseauBuilder
  {
    /**
     * The PE0341_BL500_TraiterNotificationReseau object to build
     */
    private PE0341_BL500_TraiterNotificationReseau _toBuild;

    /**
     * The builder constructor
     */
    public PE0341_BL500_TraiterNotificationReseauBuilder()
    {
      _toBuild = new PE0341_BL500_TraiterNotificationReseau();
    }

    /**
     * Controls the required fields of {@link PE0341_BL500_TraiterNotificationReseau} and returns the instance.
     *
     * @return The {@link PE0341_BL500_TraiterNotificationReseau} instance
     */
    public PE0341_BL500_TraiterNotificationReseau build()
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$
      if (isNull(_toBuild.getTracabilite()))
      {
        joiner.add("'_tracabilite'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNotificationReseau()))
      {
        joiner.add("'_notificationReseau'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNombreCompensation()))
      {
        joiner.add("'_nombreCompensation'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getConfigurationAChaudPE()))
      {
        joiner.add("'_configurationAChaudPE'"); //$NON-NLS-1$
      }

      // PARAMETRE INVALIDE
      if (0 != joiner.length())
      {
        _toBuild.setRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0341_BL500_TraiterNotificationReseau.paramNotFilled"), joiner.toString()))); //$NON-NLS-1$
      }

      return _toBuild;
    }

    /**
     * Set the configurationAChaudPE parameter in PE0340_BL500 instance
     *
     * @param configurationAChaudPE_p
     *          Configuration
     * @return Builder pour BL500 Traiter Notification Réseau
     */
    public PE0341_BL500_TraiterNotificationReseauBuilder configurationAChaudPE(final ConfigurationAChaudPE configurationAChaudPE_p)
    {
      _toBuild.setConfigurationAChaudPE(configurationAChaudPE_p);
      return this;
    }

    /**
     * Fixer le nombre de compensations dans le builder.
     *
     * @param nombreCompensation_p
     *          Nombre de compensations.
     * @return The builder instance
     */
    public PE0341_BL500_TraiterNotificationReseauBuilder nombreCompensation(final Integer nombreCompensation_p)
    {
      _toBuild.setNombreCompensation(nombreCompensation_p);
      return this;
    }

    /**
     * Set the numeroSerieont_p parameter in PE0341_BL500_TraiterNotificationReseauBuilder instance
     *
     * @param notificationReseau_p
     *          The notificationReseau
     * @return The builder instance
     */
    public PE0341_BL500_TraiterNotificationReseauBuilder notificationReseau(final AbstractNotificationReseau notificationReseau_p)
    {
      _toBuild.setNotificationReseau(notificationReseau_p);
      return this;
    }

    /**
     * Set the Tracabilite parameter in PE0341_BL500_TraiterNotificationReseauBuilder instance
     *
     * @param tracabilite_p
     *          The tracabilite
     * @return The builder instance
     */
    public PE0341_BL500_TraiterNotificationReseauBuilder tracabilite(final Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   * Definition of all execution steps.
   *
   * @author icarrao
   * @version ($Revision$ $Date$)
   */
  private enum Step
  {
    /**
     * first step to execute.
     */
    First,

    /**
     * if all steps have been executed.
     */
    End;
  }

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = -3530080190912161785L;

  /**
   * Tracabilite
   */
  private Tracabilite _tracabilite;

  /**
   * NotificationReseau
   */
  private AbstractNotificationReseau _notificationReseau;

  /**
   * The next step of the activity to execute.
   */
  private Step _nextStep = Step.First;

  /**
   * Nombre de compensations.
   */
  private Integer _nombreCompensation;

  /**
   * ConfigurationAChaudPE
   */
  private ConfigurationAChaudPE _configurationAChaudPE;

  @Override
  @LogActivity
  public TraiterNotificationReturn executeNextStep(IActivityCaller callingProcess_p) throws RavelException
  {
    TraiterNotificationReturn result = null;

    switch (_nextStep) //NOSONAR
    {
      case First:
        result = traiterNotificationReseau(callingProcess_p);
        _nextStep = Step.End;
        break;

      default:
        break;
    }

    return result;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_nextStep);
  }

  /**
   * @param callingProcess_p
   *          callingProcess
   * @return PE0341_BL500_Return
   * @throws RavelException
   *           On case of exception
   */
  private TraiterNotificationReturn traiterNotificationReseau(IActivityCaller callingProcess_p) throws RavelException
  {
    TraiterNotificationReturn notificationReturn = new TraiterNotificationReturn(false, null, 0);
    if (NotificationReseauType.ONT_INCONNU.name().equals(_notificationReseau.getTypeNotificationReseau()))
    {
      final PE0341_BL600_TraiterNotificationOntInconnu bl600 = new PE0341_BL600_TraiterNotificationOntInconnuBuilder()//
          .tracabilite(_tracabilite) //
          .notificationReseauONTInconnuJSON((NotificationReseauONTInconnuJSON) _notificationReseau) //
          .nombreCompensation(_nombreCompensation) //
          .configurationAChaudPE(_configurationAChaudPE) //
          .build();
      notificationReturn = bl600.execute(callingProcess_p);
      setRetour(bl600.getRetour());
    }
    else if (NotificationReseauType.RECOMMANDATION_TV.name().equals(_notificationReseau.getTypeNotificationReseau()))
    {
      final PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTv.PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
          .tracabilite(_tracabilite) //
          .notificationReseauRecommandationTvJSON((NotificationReseauRecommandationTvJSON) _notificationReseau) //
          .nombreCompensation(_nombreCompensation) //
          .configurationAchaudPE(_configurationAChaudPE) //
          .build();
      notificationReturn = bl700.execute(callingProcess_p);
      setRetour(bl700.getRetour());
    }
    else
    {
      setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PE0341_BL500_TraiterNotificationReseau.configInvalide"), _notificationReseau.getTypeNotificationReseau()))); //$NON-NLS-1$
    }

    return notificationReturn;
  }

  /**
   * @return value of _configurationAChaudPE
   */
  ConfigurationAChaudPE getConfigurationAChaudPE()
  {
    return _configurationAChaudPE;
  }

  /**
   * Renvoyer le nombre de compensations.
   *
   * @return Nombre de compensations.
   */
  Integer getNombreCompensation()
  {
    return _nombreCompensation;
  }

  /**
   * @return the notificationReseau
   */
  AbstractNotificationReseau getNotificationReseau()
  {
    return _notificationReseau;
  }

  /**
   * @return the tracabilite
   */
  Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @param configurationAChaudPE_p
   *          The _configurationAChaudPE to set.
   */
  void setConfigurationAChaudPE(ConfigurationAChaudPE configurationAChaudPE_p)
  {
    _configurationAChaudPE = configurationAChaudPE_p;
  }

  /**
   * Fixer le nombre de compensations.
   *
   * @param nombreCompensation_p
   *          Nombre de compensations.
   */
  void setNombreCompensation(Integer nombreCompensation_p)
  {
    _nombreCompensation = nombreCompensation_p;
  }

  /**
   * @param notificationReseau_p
   *          the notificationReseau to set
   */
  void setNotificationReseau(AbstractNotificationReseau notificationReseau_p)
  {
    _notificationReseau = notificationReseau_p;
  }

  /**
   * @param tracabilite_p
   *          the tracabilite to set
   */
  void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }
}
