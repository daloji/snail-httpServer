/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import static java.util.Objects.isNull;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.aspectJ.LogActivity;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.connectors.air.AIRProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.shared.functional.types.Annonce.Statut;
import com.bytel.spirit.common.shared.functional.types.json.notification.AbstractNotificationReseau;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.tesla.activities.Messages;

/**
 *
 * @author icarrao
 * @version ($Revision$ $Date$)
 */
public final class PE0341_BL610_IdentifierPfiParSnOnt extends BuiltActivityContext<List<PFI>>
{
  /**
   * The PE0341_BL610_IdentifierPfiParSnOnt builder
   *
   * @author icarrao
   * @version ($Revision$ $Date$)
   */
  public static final class PE0341_BL610_IdentifierPfiParSnOntBuilder
  {
    /**
     * The PE0341_BL610_IdentifierPfiParSnOnt object to build
     */
    private PE0341_BL610_IdentifierPfiParSnOnt _toBuild;

    /**
     * The builder constructor
     */
    public PE0341_BL610_IdentifierPfiParSnOntBuilder()
    {
      _toBuild = new PE0341_BL610_IdentifierPfiParSnOnt();
    }

    /**
     * Controls the required fields of {@link PE0341_BL610_IdentifierPfiParSnOnt} and returns the instance.
     *
     * @return The {@link PE0341_BL610_IdentifierPfiParSnOnt} instance
     */
    public PE0341_BL610_IdentifierPfiParSnOnt build()
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$
      if (isNull(_toBuild.getTracabilite()))
      {
        joiner.add("'_tracabilite'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNotificationReseau()))
      {
        joiner.add("'_notificationReseau'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNombreCompensation()))
      {
        joiner.add("'_nombreCompensation'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNumeroSerieOnt()))
      {
        joiner.add("'_numeroSerieOnt'"); //$NON-NLS-1$
      }

      // PARAMETRE INVALIDE
      if (0 != joiner.length())
      {
        _toBuild.setRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0341_BL610_IdentifierPfiParSnOnt.paramNotFilled"), joiner.toString()))); //$NON-NLS-1$
      }

      return _toBuild;
    }

    /**
     * Set the nombreCompensation parameter in PE0341_BL610_IdentifierPfiParSnOntBuilder instance
     *
     * @param nombreCompensation_p
     *          Nombre de compensations.
     * @return The builder instance
     */
    public PE0341_BL610_IdentifierPfiParSnOntBuilder nombreCompensation(final Integer nombreCompensation_p)
    {
      _toBuild.setNombreCompensation(nombreCompensation_p);
      return this;
    }

    /**
     * Set the idNotificationReseau_p parameter in PE0340_BL610_IdentifierPfiParSnOnt instance
     *
     * @param notificationReseau_p
     *          notificationReseau object
     * @return The builder instance
     */
    public PE0341_BL610_IdentifierPfiParSnOntBuilder notificationReseau(final AbstractNotificationReseau notificationReseau_p)
    {
      _toBuild.setNotificationReseau(notificationReseau_p);
      return this;
    }

    /**
     * Set the numeroSerieont_p parameter in PE0341_BL610_IdentifierPfiParSnOntBuilder instance
     *
     * @param numeroSerieont_p
     *          The numeroSerieont
     * @return The builder instance
     */
    public PE0341_BL610_IdentifierPfiParSnOntBuilder numeroSerieOnt(final String numeroSerieont_p)
    {
      _toBuild.setNumeroSerieOnt(numeroSerieont_p);
      return this;
    }

    /**
     * Set the Tracabilite parameter in PE0341_BL610_IdentifierPfiParSnOntBuilder instance
     *
     * @param tracabilite_p
     *          The tracabilite
     * @return The builder instance
     */
    public PE0341_BL610_IdentifierPfiParSnOntBuilder tracabilite(final Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   * Definition of all execution steps.
   *
   * @author icarrao
   * @version ($Revision$ $Date$)
   */
  private enum Step
  {
    /**
     * first step to execute.
     */
    First,

    /**
     * if all steps have been executed.
     */
    End;
  }

  /**
   *
   */
  private static final long serialVersionUID = -459597530322132486L;

  /**
   * Tracabilite
   */
  private Tracabilite _tracabilite;

  /**
   * network notification identifier
   */
  private AbstractNotificationReseau _notificationReseau;

  /**
   * numeroSerieOnt
   */
  private String _numeroSerieOnt;

  /**
   * The next step of the activity to execute.
   */
  private Step _nextStep = Step.First;

  /**
   * Nombre de compensations.
   */
  private Integer _nombreCompensation;

  @Override
  @LogActivity
  public List<PFI> executeNextStep(IActivityCaller callingProcess_p) throws RavelException
  {
    List<PFI> result = null;

    switch (_nextStep)
    {
      case First:
        result = identifierPfiParSnOnt(callingProcess_p);
        _nextStep = Step.End;
        break;

      default:
        break;
    }

    return result;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_nextStep);
  }

  /**
   * @param equipementDeclareList_p
   *          equipementDeclareList
   * @return EquipementDeclare
   */
  private EquipementDeclare findEquipementDeclare(List<EquipementDeclare> equipementDeclareList_p)
  {
    EquipementDeclare eqtDeclare = null;

    if (equipementDeclareList_p != null)
    {
      for (EquipementDeclare equipmentDeclare : equipementDeclareList_p)
      {
        if (_numeroSerieOnt.equals(equipmentDeclare.getNoIdentifiant()) && //
            Statut.ACTIF.toString().equals(equipmentDeclare.getStatut().toString()))
        {
          if ("BRANCHEMENT_OPTIQUE".equals(equipmentDeclare.getTypeEquipement()) || //$NON-NLS-1$
              "MODEM_BRANCHEMENT_OPTIQUE".equals(equipmentDeclare.getTypeEquipement())) //$NON-NLS-1$
          {
            eqtDeclare = equipmentDeclare;
          }
        }
      }
    }

    return eqtDeclare;
  }

  /**
   * @param callingProcess_p
   *          callingProcess
   * @return List<PFI>
   * @throws RavelException
   *           In case of exception
   */
  private List<PFI> identifierPfiParSnOnt(@SuppressWarnings("unused") final IActivityCaller callingProcess_p) throws RavelException
  {
    List<PFI> listPFI = new ArrayList<>();

    // call AIR connector
    ConnectorResponse<Retour, List<IndexRecherchePfi>> pfiLireTousParCleResponse = AIRProxy.getInstance().indexRechercherPfiLireTousParCleRecherche(_tracabilite, "SN_ONT", _numeroSerieOnt); //$NON-NLS-1$
    if (RetourFactory.isRetourNOK(pfiLireTousParCleResponse._first))
    {
      if (IMegConsts.DONNEE_INCONNUE.equals(pfiLireTousParCleResponse._first.getDiagnostic()))
      {
        setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_ONT_INCONNU, MessageFormat.format(Messages.getString("PE0341_BL610_IdentifierPfiParSnOnt.AirResponseDonneInconnue"), _notificationReseau, _nombreCompensation))); //$NON-NLS-1$
        return null;
      }

      setRetour(pfiLireTousParCleResponse._first);
      return null;
    }

    for (IndexRecherchePfi indexRecherchePfi : pfiLireTousParCleResponse._second)
    {
      String clientoperateur = indexRecherchePfi.getClientOperateur();
      String noCompte = indexRecherchePfi.getNoCompte();

      //call RPG connector
      final ConnectorResponse<Retour, PFI> pfiLireUnResponse = RPGProxy.getInstance().pfiLireUn(_tracabilite, clientoperateur, noCompte);
      if (!isResultOK(pfiLireUnResponse._first))
      {
        if (IMegConsts.DONNEE_INCONNUE.equals(pfiLireUnResponse._first.getDiagnostic()))
        {
          continue;
        }

        setRetour(pfiLireUnResponse._first);
        return null;
      }

      //calls the method to find if this PFI has one EquipmentDeclare that respects the SPEC specifications
      EquipementDeclare eqtDeclare = findEquipementDeclare(pfiLireUnResponse._second.getEquipementDeclare());
      if (!isNull(eqtDeclare))
      {
        listPFI.add(pfiLireUnResponse._second);
      }
    }

    if (listPFI.isEmpty())
    {
      setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_ONT_INCONNU, Messages.getString("PE0341_BL610_IdentifierPfiParSnOnt.ListPfiZero"))); //$NON-NLS-1$
      return null;
    }

    if (listPFI.size() > 1)
    {
      setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, Messages.getString("PE0341_BL610_IdentifierPfiParSnOnt.ListPfiMoreThanOne"))); //$NON-NLS-1$
      return null;
    }

    setRetour(RetourFactory.createOkRetour());
    return listPFI;
  }

  /**
   * @return the nombreCompensation
   */
  final Integer getNombreCompensation()
  {
    return _nombreCompensation;
  }

  /**
   * @return the notificationReseau
   */
  final AbstractNotificationReseau getNotificationReseau()
  {
    return _notificationReseau;
  }

  /**
   * @return the numeroSerieOnt
   */
  final String getNumeroSerieOnt()
  {
    return _numeroSerieOnt;
  }

  /**
   * @return the tracabilite
   */
  final Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * Fixer le nombre de compensations
   *
   * @param nombreCompensation_p
   *          Nombre de compensations.
   */
  void setNombreCompensation(final Integer nombreCompensation_p)
  {
    _nombreCompensation = nombreCompensation_p;
  }

  /**
   * @param notificationReseau_p
   *          the idNotificationReseau to set
   */
  void setNotificationReseau(final AbstractNotificationReseau notificationReseau_p)
  {
    _notificationReseau = notificationReseau_p;
  }

  /**
   * @param numeroSerieOnt_p
   *          the numeroSerieOnt to set
   */
  void setNumeroSerieOnt(final String numeroSerieOnt_p)
  {
    _numeroSerieOnt = numeroSerieOnt_p;
  }

  /**
   * @param tracabilite_p
   *          the tracabilite to set
   */
  void setTracabilite(final Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }
}
