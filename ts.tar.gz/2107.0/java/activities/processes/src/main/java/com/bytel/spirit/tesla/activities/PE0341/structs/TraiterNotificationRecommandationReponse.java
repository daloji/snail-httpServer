/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341.structs;

import java.io.Serializable;

import com.bytel.ravel.types.Retour;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.squareup.moshi.Json;

/**
 *
 * @author mvasques
 * @version ($Revision$ $Date$)
 */
public class TraiterNotificationRecommandationReponse extends BasicResponse
{

  /**
   *
   * @author mvasques
   * @version ($Revision$ $Date$)
   */
  public static class ReponseFonctionnelle implements Serializable
  {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * idCmd
     */
    @Json(name = "idCmd")
    private String _idCmd;

    /**
     * @param idCmd_p
     *          the idCmd
     *
     *
     */
    public ReponseFonctionnelle(String idCmd_p)
    {
      super();
      _idCmd = idCmd_p;
    }

    /**
     * @return the idCmd
     */
    public String getIdCmd()
    {
      return _idCmd;
    }

    /**
     * @param idCmd_p
     *          the idCmd to set
     */
    public void setIdCmd(String idCmd_p)
    {
      _idCmd = idCmd_p;
    }

  }

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * reponseFonctionnelle
   */
  @Json(name = "reponseFonctionnelle")
  private ReponseFonctionnelle _reponseFonctionnelle;

  /**
   * @param retour_p
   *          the retour
   * @param idCmd_p
   *          the idCmd
   */
  public TraiterNotificationRecommandationReponse(Retour retour_p, String idCmd_p)
  {
    super(retour_p);

    _reponseFonctionnelle = new ReponseFonctionnelle(idCmd_p);

  }

  /**
   * @return the reponseFonctionnelle
   */
  public ReponseFonctionnelle getReponseFonctionnelle()
  {
    return _reponseFonctionnelle;
  }

  /**
   * @param reponseFonctionnelle_p
   *          the reponseFonctionnelle to set
   */
  public void setReponseFonctionnelle(ReponseFonctionnelle reponseFonctionnelle_p)
  {
    _reponseFonctionnelle = reponseFonctionnelle_p;
  }

}
