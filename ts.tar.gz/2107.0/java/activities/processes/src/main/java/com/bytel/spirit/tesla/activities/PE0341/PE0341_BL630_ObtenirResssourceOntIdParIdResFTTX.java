/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import static java.util.Objects.isNull;

import java.text.MessageFormat;
import java.util.StringJoiner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.aspectJ.LogActivity;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI031_LireNrmId;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI031_LireNrmId.OSSFAI_SI031_LireNrmIdBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI032_LireNrmInfos;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI032_LireNrmInfos.OSSFAI_SI032_LireNrmInfosBuilder;
import com.bytel.spirit.common.connectors.nrm.structs.NRMInfosRetour;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.activities.Messages;
import com.bytel.spirit.tesla.activities.PE0341.structs.RessourceOntId;

/**
 *
 * @author icarrao
 * @version ($Revision$ $Date$)
 */
public final class PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX extends BuiltActivityContext<RessourceOntId>
{
  /**
   * The PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder builder
   *
   * @author icarrao
   * @version ($Revision$ $Date$)
   */
  public static final class PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder
  {
    /**
     * The PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX object to build
     */
    private PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX _toBuild;

    /**
     * The builder constructor
     */
    public PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder()
    {
      _toBuild = new PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX();
    }

    /**
     * Controls the required fields of {@link PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX} and returns the instance.
     *
     * @return The {@link PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX} instance
     */
    public PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX build()
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$
      if (isNull(_toBuild.getTracabilite()))
      {
        joiner.add("'_tracabilite'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getIdRessourceReseauFTTX()))
      {
        joiner.add("'_idRessourceReseauFTTX'"); //$NON-NLS-1$
      }

      // PARAMETRE INVALIDE
      if (0 != joiner.length())
      {
        _toBuild.setRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX.paramNotFilled"), joiner.toString()))); //$NON-NLS-1$
      }

      return _toBuild;
    }

    /**
     * Set the Tracabilite parameter in PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX instance
     *
     * @param idRessourceReseauFTTX_p
     *          The idRessourceReseauFTTX
     * @return The builder instance
     */
    public PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder idRessourceReseauFTTX(final String idRessourceReseauFTTX_p)
    {
      _toBuild.setIdRessourceReseauFTTX(idRessourceReseauFTTX_p);
      return this;
    }

    /**
     * Set the Tracabilite parameter in PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX instance
     *
     * @param tracabilite_p
     *          The tracabilite
     * @return The builder instance
     */
    public PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder tracabilite(final Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }

  }

  /**
   * Definition of all execution steps.
   *
   * @author icarrao
   * @version ($Revision$ $Date$)
   */
  private enum Step
  {
    /**
     * first step to execute.
     */
    First,

    /**
     * if all steps have been executed.
     */
    End;
  }

  /**
   *
   */
  private static final long serialVersionUID = -3764071191951608745L;

  /**
   * NotificationReseau
   */
  private String _idRessourceReseauFTTX;

  /**
   * Tracabilite
   */
  private Tracabilite _tracabilite;

  /**
   * The next step of the activity to execute.
   */
  private Step _nextStep = Step.First;

  @Override
  @LogActivity
  public RessourceOntId executeNextStep(IActivityCaller iActivityCaller_p) throws RavelException
  {
    RessourceOntId result = null;

    switch (_nextStep)
    {
      case First:
        result = obtenirResssourceOntIdParIdResFTTX(iActivityCaller_p);
        _nextStep = Step.End;
        break;

      default:
        break;
    }

    return result;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_nextStep);
  }

  /**
   * @param iActivityCaller_p
   *          iActivityCaller
   * @return PE340_BL600_Return
   * @throws RavelException
   *           In case of RavelException
   */
  private RessourceOntId obtenirResssourceOntIdParIdResFTTX(IActivityCaller iActivityCaller_p) throws RavelException
  {
    // Récupération du nrmId à partir de idRessourceReseauFTTX (idOss)
    OSSFAI_SI031_LireNrmId si031LireNrmId = new OSSFAI_SI031_LireNrmIdBuilder() //
        .tracabilite(_tracabilite) //
        .idOss(Long.valueOf(_idRessourceReseauFTTX))//
        .build();
    Long nrmId = si031LireNrmId.execute(iActivityCaller_p);
    Retour si031LireNrmIdRetour = si031LireNrmId.getRetour();

    if (RetourFactory.isRetourNOK(si031LireNrmIdRetour))
    {
      setRetour(si031LireNrmIdRetour);
      return null;
    }

    // Récupération les caracteristiques de l’accès FTTH sur le système technique Legacy {NRM}
    OSSFAI_SI032_LireNrmInfos si032LireNrmInfos = new OSSFAI_SI032_LireNrmInfosBuilder()//
        .tracabilite(_tracabilite)//
        .nrmId(nrmId.intValue())//
        .build();
    NRMInfosRetour nrmInfosRetour = si032LireNrmInfos.execute(iActivityCaller_p);
    Retour si032LireNrmInfosRetour = si032LireNrmInfos.getRetour();

    if (RetourFactory.isRetourNOK(si032LireNrmInfosRetour))
    {
      setRetour(si032LireNrmInfosRetour);
      return null;
    }

    String nomOlt = nrmInfosRetour.getNomOLT();
    Integer ontId = nrmInfosRetour.getOntId();
    Integer positionCartePon = nrmInfosRetour.getCarte();
    Integer positionPortPon = nrmInfosRetour.getPort();
    String idRessourceLie = _idRessourceReseauFTTX;
    setRetour(si032LireNrmInfosRetour);

    return new RessourceOntId(nomOlt, ontId, positionCartePon, positionPortPon, idRessourceLie);
  }

  /**
   * @return the notificationReseau
   */
  String getIdRessourceReseauFTTX()
  {
    return _idRessourceReseauFTTX;
  }

  /**
   * @return the tracabilite
   */
  Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @param idRessourceReseauFTTX_p
   *          the idRessourceReseauFTTX to set
   */
  void setIdRessourceReseauFTTX(String idRessourceReseauFTTX_p)
  {
    _idRessourceReseauFTTX = idRessourceReseauFTTX_p;
  }

  /**
   * @param tracabilite_p
   *          the tracabilite to set
   */
  void setTracabilite(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }
}
