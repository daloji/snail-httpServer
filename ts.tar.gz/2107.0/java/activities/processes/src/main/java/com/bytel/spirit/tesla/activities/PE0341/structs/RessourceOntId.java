/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341.structs;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author icarrao
 * @version ($Revision$ $Date$)
 */
public class RessourceOntId implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 8390014244103345125L;

  /** The nomOlt. */
  @Json(name = "nomOlt") // $NON-NLS-1$
  private String _nomOlt;

  /** The ontId. */
  @Json(name = "ontId") // $NON-NLS-1$
  private Integer _ontId;

  /** The positionCartePon. */
  @Json(name = "positionCartePon") // $NON-NLS-1$
  private Integer _positionCartePon;

  /** The positionPortPon. */
  @Json(name = "positionPortPon") // $NON-NLS-1$
  private Integer _positionPortPon;

  /** The idRessourceLie. */
  @Json(name = "idRessourceLie") // $NON-NLS-1$
  private String _idRessourceLie;

  /**
   * @param nomOlt_p
   *          the nomOlt.
   * @param ontId_p
   *          the ontId_p.
   * @param positionCartePon_p
   *          positionCartePon
   * @param positionPortPon_p
   *          positionPortPon
   * @param idRessourceLie_p
   *          idRessourceLie
   */
  public RessourceOntId(String nomOlt_p, Integer ontId_p, Integer positionCartePon_p, Integer positionPortPon_p, String idRessourceLie_p)
  {
    _nomOlt = nomOlt_p;
    _ontId = ontId_p;
    _positionCartePon = positionCartePon_p;
    _positionPortPon = positionPortPon_p;
    _idRessourceLie = idRessourceLie_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    RessourceOntId other = (RessourceOntId) obj;
    if (_idRessourceLie == null)
    {
      if (other._idRessourceLie != null)
      {
        return false;
      }
    }
    else if (!_idRessourceLie.equals(other._idRessourceLie))
    {
      return false;
    }
    if (_nomOlt == null)
    {
      if (other._nomOlt != null)
      {
        return false;
      }
    }
    else if (!_nomOlt.equals(other._nomOlt))
    {
      return false;
    }
    if (_ontId == null)
    {
      if (other._ontId != null)
      {
        return false;
      }
    }
    else if (!_ontId.equals(other._ontId))
    {
      return false;
    }
    if (_positionCartePon == null)
    {
      if (other._positionCartePon != null)
      {
        return false;
      }
    }
    else if (!_positionCartePon.equals(other._positionCartePon))
    {
      return false;
    }
    if (_positionPortPon == null)
    {
      if (other._positionPortPon != null)
      {
        return false;
      }
    }
    else if (!_positionPortPon.equals(other._positionPortPon))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the idRessourceLie
   */
  public String getIdRessourceLie()
  {
    return _idRessourceLie;
  }

  /**
   * @return the nomOlt
   */
  public String getNomOlt()
  {
    return _nomOlt;
  }

  /**
   * @return the ontId
   */
  public Integer getOntId()
  {
    return _ontId;
  }

  /**
   * @return the positionCartePon
   */
  public Integer getPositionCartePon()
  {
    return _positionCartePon;
  }

  /**
   * @return the positionPortPon
   */
  public Integer getPositionPortPon()
  {
    return _positionPortPon;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_idRessourceLie == null) ? 0 : _idRessourceLie.hashCode());
    result = (prime * result) + ((_nomOlt == null) ? 0 : _nomOlt.hashCode());
    result = (prime * result) + ((_ontId == null) ? 0 : _ontId.hashCode());
    result = (prime * result) + ((_positionCartePon == null) ? 0 : _positionCartePon.hashCode());
    result = (prime * result) + ((_positionPortPon == null) ? 0 : _positionPortPon.hashCode());
    return result;
  }

  /**
   * @param idRessourceLie_p
   *          the idRessourceLie to set
   */
  public void setIdRessourceLie(String idRessourceLie_p)
  {
    _idRessourceLie = idRessourceLie_p;
  }

  /**
   * @param nomOlt_p
   *          the nomOlt to set
   */
  public void setNomOlt(String nomOlt_p)
  {
    _nomOlt = nomOlt_p;
  }

  /**
   * @param ontId_p
   *          the ontId to set
   */
  public void setOntId(Integer ontId_p)
  {
    _ontId = ontId_p;
  }

  /**
   * @param positionCartePon_p
   *          the positionCartePon to set
   */
  public void setPositionCartePon(Integer positionCartePon_p)
  {
    _positionCartePon = positionCartePon_p;
  }

  /**
   * @param positionPortPon_p
   *          the positionPortPon to set
   */
  public void setPositionPortPon(Integer positionPortPon_p)
  {
    _positionPortPon = positionPortPon_p;
  }

}
