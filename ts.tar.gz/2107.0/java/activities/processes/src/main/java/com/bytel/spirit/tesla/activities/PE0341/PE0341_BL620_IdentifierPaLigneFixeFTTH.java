/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import static java.util.Objects.isNull;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.services.aspectJ.LogActivity;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI031_LireNrmId;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI100_RecupererIdRaccordementParNrmId;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI117_RecupererIdRaccoparIdOss;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauONTInconnuJSON;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.TechnologieAccess;
import com.bytel.spirit.common.shared.utils.PFIUtils;
import com.bytel.spirit.tesla.activities.Messages;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX.PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.RessourceOntId;

/**
 * This activity is responsible for identifying the {@link PA} where the resource On Id is the same as the one in the
 * {@link NotificationReseauONTInconnuJSON} in the parameters.
 *
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
public final class PE0341_BL620_IdentifierPaLigneFixeFTTH extends BuiltActivityContext<PA>
{

  /**
   * The builder of {@link PE0341_BL620_IdentifierPaLigneFixeFTTH}
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  public static final class PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder
  {
    /**
     * The object to build
     */
    private final PE0341_BL620_IdentifierPaLigneFixeFTTH _toBuild;

    /**
     * The constructor of the builder.
     */
    public PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder()
    {
      _toBuild = new PE0341_BL620_IdentifierPaLigneFixeFTTH();
    }

    /**
     * @return the created object.
     */
    public PE0341_BL620_IdentifierPaLigneFixeFTTH build()
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$
      if (isNull(_toBuild.getTracabilite()))
      {
        joiner.add("'_tracabilite'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNotificationReseau()))
      {
        joiner.add("'_notificationReseau'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNombreCompensation()))
      {
        joiner.add("'_nombreCompensation'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getPfi()))
      {
        joiner.add("'_pfi'"); //$NON-NLS-1$
      }

      // PARAMETRE INVALIDE
      if (0 != joiner.length())
      {
        _toBuild.setRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0341_BL620_IdentifierPaLigneFixeFTTH.paramNotFilled"), joiner.toString()))); //$NON-NLS-1$
      }

      return _toBuild;
    }

    /**
     * Set the nombreCompensation parameter in PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder instance
     *
     * @param nombreCompensation_p
     *          Nombre de compensations.
     * @return The builder instance
     */
    public PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder nombreCompensation(final Integer nombreCompensation_p)
    {
      _toBuild.setNombreCompensation(nombreCompensation_p);
      return this;
    }

    /**
     * @param notificationReseau_p
     *          the notificatioNReseau.
     * @return the builder.
     */
    public PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder notificationReseau(NotificationReseauONTInconnuJSON notificationReseau_p)
    {
      _toBuild.setNotificationReseau(notificationReseau_p);
      return this;
    }

    /**
     * @param ontInstalleBasculeSpirit_p
     *          the ConfigPE0341.ontInstalleBasculeSpirit.
     * @return the builder.
     */
    public PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder ontInstalleBasculeSpirit(boolean ontInstalleBasculeSpirit_p)
    {
      _toBuild.setOntInstalleBasculeSpirit(ontInstalleBasculeSpirit_p);
      return this;
    }

    /**
     * @param pfi_p
     *          the pfi.
     * @return the builder.
     */
    public PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder pfi(PFI pfi_p)
    {
      _toBuild.setPfi(pfi_p);
      return this;
    }

    /**
     * @param topologieFtthBasculeSurSpirit_p
     *          the ConfigPE0341.topologieFtthBasculeSurSpirit.
     * @return the builder.
     */
    public PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder topologieFtthBasculeSurSpirit(boolean topologieFtthBasculeSurSpirit_p)
    {
      _toBuild.setTopologieFtthBasculeSurSpirit(topologieFtthBasculeSurSpirit_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          the tracabilite.
     * @return the builder.
     */
    public PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   * Definition of all execution steps.
   *
   * @author acorreia
   * @version ($Revision$ $Date$)
   */
  public enum Step
  {
    /**
     * First
     */
    FIRST,

    /**
     * Last
     */
    END
  }

  /**
   * Unique serial identifier
   */
  private static final long serialVersionUID = 1093399945806979509L;

  /**
   * The traceability
   */
  private Tracabilite _tracabilite;

  /**
   * The porfolio
   */
  private PFI _pfi;

  /**
   * The network notification object
   */
  private NotificationReseauONTInconnuJSON _notificationReseau;

  /**
   * Contains the new step to execute.
   */
  private Step _nextStep = Step.FIRST;

  /**
   * Nombre de compensations.
   */
  private Integer _nombreCompensation;

  /**
   * ConfigPE0341.ontInstalleBasculeSpirit
   */
  private boolean _ontInstalleBasculeSpirit;

  /**
   * ConfigPE0341.topologieFtthBasculeSurSpirit
   */
  private boolean _topologieFtthBasculeSurSpirit;

  @Override
  @LogActivity
  public PA executeNextStep(IActivityCaller iActivityCaller_p) throws RavelException
  {
    PA response = null;

    switch (_nextStep)
    {
      case FIRST:
        response = identifierPaLigneFixeFTTH(iActivityCaller_p);
        _nextStep = Step.END;
        break;

      default:
        break;
    }

    return response;
  }

  @Override
  public boolean isEndStep()
  {
    return _nextStep == Step.END;
  }

  /**
   * Filter the list of {@link PA}, from the pfi.
   *
   * @param paList_p
   *          the list of {@link PA}.
   * @return the resulting list.
   */
  private List<PA> filterPA(List<PA> paList_p)
  {
    List<PA> result = new ArrayList<>();

    for (PA pa : paList_p)
    {
      if (!Statut.ACTIF.equals(pa.getStatut()))
      {
        continue;
      }

      if (!PFIUtils.isValidPALigneFixe(pa))
      {
        continue;
      }

      if (StringTools.isNotNullOrEmpty(pa.getPaTypeLigneFixe().getIdRaccordement()))
      {
        continue;
      }

      if ((pa.getPaTypeLigneFixe().getInfoBrutBssGp() != null))
      {
        if (StringTools.isNotNullOrEmpty(pa.getPaTypeLigneFixe().getInfoBrutBssGp().getIdRessourceReseauFTTX())//
            && (pa.getPaTypeLigneFixe().getInfoBrutBssGp().getAccesTechnique() != null)//
            && TechnologieAccess.FTTH.name().equals(pa.getPaTypeLigneFixe().getInfoBrutBssGp().getAccesTechnique().getTechnologieAcces()))
        {
          result.add(pa);
        }
      }

      if (pa.getPaTypeLigneFixe().getInfoBrutBssEnt() != null)
      {
        if (StringTools.isNotNullOrEmpty(pa.getPaTypeLigneFixe().getInfoBrutBssEnt().getIdRessourceReseauFTTX()) //
            && (pa.getPaTypeLigneFixe().getInfoBrutBssEnt().getAccesTechnique() != null) //
            && TechnologieAccess.FTTH.name().equals(pa.getPaTypeLigneFixe().getInfoBrutBssEnt().getAccesTechnique().getTechnologieAcces()))
        {
          result.add(pa);
        }
      }

    }

    return result;
  }

  /**
   * Identify the list of {@link PA}s where the resource On Id is the same as the one in the
   * {@link NotificationReseauONTInconnuJSON} in the parameters.
   *
   * @param iActivityCaller_p
   *          the caller of the activity.
   * @return the list of {@link PA}.
   * @throws RavelException
   *           on errors
   */
  private PA identifierPaLigneFixeFTTH(IActivityCaller iActivityCaller_p) throws RavelException
  {
    // Get the list of points PaTypeLigneFixe given by the filter
    List<PA> paTypeLigneFixeList = filterPA(_pfi.getPa());
    List<PA> listePaLigneFtthRetenu = new ArrayList<>();

    // If the list is empty
    if (paTypeLigneFixeList.isEmpty())
    {
      setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PALF_ACTIF_INCONNU, Messages.getString("PE0341_BL620_IdentifierPaLigneFixeFTTH.NoPalfFound"))); //$NON-NLS-1$
      return null;
    }

    for (PA palf : paTypeLigneFixeList)
    {
      String idRessourceReseauFTTX;

      // Get the idRessourceReseauFTTX
      if (palf.getPaTypeLigneFixe().getInfoBrutBssGp() != null)
      {
        idRessourceReseauFTTX = palf.getPaTypeLigneFixe().getInfoBrutBssGp().getIdRessourceReseauFTTX();
      }
      else if (palf.getPaTypeLigneFixe().getInfoBrutBssEnt() != null)
      {
        idRessourceReseauFTTX = palf.getPaTypeLigneFixe().getInfoBrutBssEnt().getIdRessourceReseauFTTX();
      }
      else
      {
        continue;
      }

      if (!_ontInstalleBasculeSpirit) // MES RACC OFF
      {
        // Récupération du nrmId à partir de idRessourceReseauFTTX (idOss)
        OSSFAI_SI031_LireNrmId si031 = new OSSFAI_SI031_LireNrmId.OSSFAI_SI031_LireNrmIdBuilder()//
            .tracabilite(_tracabilite)//
            .idOss(Long.parseLong(idRessourceReseauFTTX))//
            .build();
        Long nrmId = si031.execute(iActivityCaller_p);
        Retour si031Retour = si031.getRetour();

        if (RetourFactory.isRetourNOK(si031Retour))
        {
          setRetour(si031Retour);
          return null;
        }

        // Call OSSFAI_SI100
        OSSFAI_SI100_RecupererIdRaccordementParNrmId si100 = new OSSFAI_SI100_RecupererIdRaccordementParNrmId.OSSFAI_SI100_RecupererIdRaccordementParNrmIdBuilder()//
            .tracabilite(_tracabilite)//
            .nrmId(nrmId.toString())//
            .build();
        si100.execute(iActivityCaller_p);
        Retour si100Retour = si100.getRetour();

        if (RetourFactory.isRetourNOK(si100Retour))
        {
          setRetour(si100Retour);
          return null;
        }

        // Call PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX
        final PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX bl630 = new PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder() //
            .tracabilite(_tracabilite) //
            .idRessourceReseauFTTX(idRessourceReseauFTTX) //
            .build();

        RessourceOntId ressourceOntId;
        try
        {
          ressourceOntId = bl630.execute(iActivityCaller_p);
        }
        catch (final RavelException exception)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _tracabilite, exception));
          setRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(Messages.getString("PE0341_BL620_IdentifierPaLigneFixeFTTH.ObtenirRessourceOntIdException"), exception.getMessage()))); //$NON-NLS-1$
          return null;
        }

        final Retour bl630Retour = bl630.getRetour();
        if (RetourFactory.isRetourNOK(bl630Retour))
        {
          if (!IMegSpiritConsts.DONNEE_NON_DISPONIBLE.equals(bl630Retour.getDiagnostic()))
          {
            setRetour(bl630Retour);
            return null;
          }
        }
        // If the result matches the NotificationReseau in the parameters
        else if (Objects.equals(ressourceOntId.getNomOlt(), _notificationReseau.getNomOlt()) //
            && Objects.equals(ressourceOntId.getPositionCartePon().toString(), _notificationReseau.getPositionCartePon()) //
            && Objects.equals(ressourceOntId.getPositionPortPon().toString(), _notificationReseau.getPositionPon()))
        {
          listePaLigneFtthRetenu.add(palf);
          break;
//          setRetour(RetourFactory.createOkRetour());
//          return palf;
        }
      }
      else if(!_topologieFtthBasculeSurSpirit) // MES TOPO OFF && MES RACC ON
      {
        // récup idRacco par idOss
        OSSFAI_SI117_RecupererIdRaccoparIdOss si117 = new OSSFAI_SI117_RecupererIdRaccoparIdOss.OSSFAI_SI117_RecupererIdRaccoparIdOssBuilder()//
            .tracabilite(_tracabilite)//
            .idOss(Long.parseLong(idRessourceReseauFTTX))//
            .build();
        String idRaccordement = si117.execute(iActivityCaller_p);
        Retour si117Retour = si117.getRetour();

        if (RetourFactory.isRetourNOK(si117Retour))
        {
          setRetour(si117Retour);
          return null;
        }

        // Call PE0341_BL640_ObtenirResssourceOntIdParIdRacco
        final PE0341_BL640_ObtenirResssourceOntIdParIdRacco bl640 = new PE0341_BL640_ObtenirResssourceOntIdParIdRacco.PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder() //
            .tracabilite(_tracabilite) //
            .idRaccordement(idRaccordement) //
            .build();

        RessourceOntId ressourceOntId;
        try
        {
          ressourceOntId = bl640.execute(iActivityCaller_p);
        }
        catch (final RavelException exception)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _tracabilite, exception));
          setRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, MessageFormat.format(Messages.getString("PE0341_BL620_IdentifierPaLigneFixeFTTH.ObtenirRessourceOntIdException"), exception.getMessage()))); //$NON-NLS-1$
          return null;
        }

        final Retour bl640Retour = bl640.getRetour();
        if (RetourFactory.isRetourNOK(bl640Retour))
        {
          if (!IMegSpiritConsts.DONNEE_NON_DISPONIBLE.equals(bl640Retour.getDiagnostic()))
          {
            setRetour(bl640Retour);
            return null;
          }
        }
        // If the result matches the NotificationReseau in the parameters
        else if (Objects.equals(ressourceOntId.getNomOlt(), _notificationReseau.getNomOlt()) //
            && Objects.equals(ressourceOntId.getPositionCartePon().toString(), _notificationReseau.getPositionCartePon()) //
            && Objects.equals(ressourceOntId.getPositionPortPon().toString(), _notificationReseau.getPositionPon()))
        {
          listePaLigneFtthRetenu.add(palf);
        }
      }
      else // MES TOPO ON && MES RACC ON
      {
        // récup idRacco par idOss
        OSSFAI_SI117_RecupererIdRaccoparIdOss si117 = new OSSFAI_SI117_RecupererIdRaccoparIdOss.OSSFAI_SI117_RecupererIdRaccoparIdOssBuilder()//
            .tracabilite(_tracabilite)//
            .idOss(Long.parseLong(idRessourceReseauFTTX))//
            .build();
        String idRaccordement = si117.execute(iActivityCaller_p);
        Retour si117Retour = si117.getRetour();

        if (RetourFactory.isRetourNOK(si117Retour))
        {
          setRetour(si117Retour);
          return null;
        }

        // Call RES.lireTousParIdRessourceLie
        ConnectorResponse<Retour, List<Ressource>> resResponse = RESProxy.getInstance().ressourceLireTousParIdRessourceLie(_tracabilite, idRaccordement, "ONT_ID"); //$NON-NLS-1$
        List<Ressource> ressources = resResponse._second;

        if (RetourFactory.isRetourNOK(resResponse._first))
        {
          setRetour(resResponse._first);
          return null;
        }
        else if ((ressources == null) || ressources.isEmpty())
        {
          setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(Messages.getString("PE0341_BL620_IdentifierPaLigneFixeFTTH.NoRessourcesOntId"), idRaccordement))); //$NON-NLS-1$
          return null;
        }
        else
        {
          com.bytel.spirit.common.shared.saab.res.RessourceOntId ressourceOntId = (com.bytel.spirit.common.shared.saab.res.RessourceOntId) ressources.get(0);

          if (Objects.equals(ressourceOntId.getNomOLT(), _notificationReseau.getNomOlt()) //
              && Objects.equals(ressourceOntId.getPositionCartePON().toString(), _notificationReseau.getPositionCartePon()) //
              && Objects.equals(ressourceOntId.getPositionPortPON().toString(), _notificationReseau.getPositionPon()))
          {
            listePaLigneFtthRetenu.add(palf);
            break;
          }
        }
      }
    }

    // If no match was found
    if(listePaLigneFtthRetenu.isEmpty())
    {
      setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PON_PATH_INCONNU, MessageFormat.format(Messages.getString("PE0341_BL620_IdentifierPaLigneFixeFTTH.NoResults"), _notificationReseau.getNomOlt(), _notificationReseau.getPositionCartePon(), _notificationReseau.getPositionPon(), _notificationReseau.getIdNotificationReseau(), _nombreCompensation))); //$NON-NLS-1$
      return null;
    }

    setRetour(RetourFactory.createOkRetour());
    return listePaLigneFtthRetenu.get(0);
  }

  /**
   * @return the nombreCompensation
   */
  final Integer getNombreCompensation()
  {
    return _nombreCompensation;
  }

  /**
   * @return value of _notificationReseau.
   */
  final NotificationReseauONTInconnuJSON getNotificationReseau()
  {
    return _notificationReseau;
  }

  /**
   * @return value of _pfi.
   */
  final PFI getPfi()
  {
    return _pfi;
  }

  /**
   * @return value of _tracabilite
   */
  final Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @return the ontInstalleBasculeSpirit
   */
  final boolean isOntInstalleBasculeSpirit()
  {
    return _ontInstalleBasculeSpirit;
  }

  /**
   * @return value of _topologieFtthBasculeSurSpirit.
   */
  boolean isTopologieFtthBasculeSurSpirit()
  {
    return _topologieFtthBasculeSurSpirit;
  }

  /**
   * Fixer le nombre de compensations
   *
   * @param nombreCompensation_p
   *          Nombre de compensations.
   */
  void setNombreCompensation(final Integer nombreCompensation_p)
  {
    _nombreCompensation = nombreCompensation_p;
  }

  /**
   * @param notificationReseau_p
   *          the _notificationReseau to set.
   */
  void setNotificationReseau(final NotificationReseauONTInconnuJSON notificationReseau_p)
  {
    _notificationReseau = notificationReseau_p;
  }

  /**
   * @param ontInstalleBasculeSpirit_p
   *          the ontInstalleBasculeSpirit to set
   */
  void setOntInstalleBasculeSpirit(boolean ontInstalleBasculeSpirit_p)
  {
    _ontInstalleBasculeSpirit = ontInstalleBasculeSpirit_p;
  }

  /**
   * @param pfi_p
   *          the _pfi to set.
   */
  void setPfi(final PFI pfi_p)
  {
    _pfi = pfi_p;
  }

  /**
   * @param topologieFtthBasculeSurSpirit_p
   *     the _topologieFtthBasculeSurSpirit to set.
   */
  void setTopologieFtthBasculeSurSpirit(boolean topologieFtthBasculeSurSpirit_p)
  {
    _topologieFtthBasculeSurSpirit = topologieFtthBasculeSurSpirit_p;
  }

  /**
   * @param tracabilite_p
   *          The _tracabilite to set.
   */
  void setTracabilite(final Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }
}
