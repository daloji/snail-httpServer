/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341.structs;

import java.io.Serializable;

/**
 *
 * @author jrolao
 * @version ($Revision$ $Date$)
 */
public class TraiterNotificationReturn implements Serializable
{

  /** The serial version UID. */
  private static final long serialVersionUID = -832441785348496202L;

  /**
   * Indique s'il faut compenser le traitement;
   */
  private boolean _compenserTraitement;

  /**
   * idCmd
   */
  private String _idCmd;

  /**
   * Nombre de compensations.
   */
  private int _nombreCompensation;

  /**
   * delaiTemporisation
   */
  private int _delaiTemporisation;

  /**
   * Default contructor
   */
  public TraiterNotificationReturn()
  {
    super();
  }

  /**
   * Construire une structure de retour de notification.
   *
   * @param compenserTraitment_p
   *          true s'il faut compenser le traitement.
   * @param idCmd_p
   *          idCMD
   * @param delaiTemporisation_p
   *          delaiTemporisation
   */
  public TraiterNotificationReturn(boolean compenserTraitment_p, String idCmd_p, int delaiTemporisation_p)
  {
    _delaiTemporisation = delaiTemporisation_p;
    _compenserTraitement = compenserTraitment_p;
    _idCmd = idCmd_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    TraiterNotificationReturn other = (TraiterNotificationReturn) obj;
    if (_delaiTemporisation != other._delaiTemporisation)
    {
      return false;
    }
    if (_idCmd == null)
    {
      if (other._idCmd != null)
      {
        return false;
      }
    }
    else if (!_idCmd.equals(other._idCmd))
    {
      return false;
    }
    if (_nombreCompensation != other._nombreCompensation)
    {
      return false;
    }
    if (_compenserTraitement != other._compenserTraitement)
    {
      return false;
    }
    return true;
  }

  /**
   * @return the delaiTemporisation
   */
  public int getDelaiTemporisation()
  {
    return _delaiTemporisation;
  }

  /**
   * @return the idCMD
   */
  public String getIdCmd()
  {
    return _idCmd;
  }

  /**
   * Renvoyer le nombre de compensations.
   *
   * @return Nombre de compensations.
   */
  public int getNombreCompensation()
  {
    return _nombreCompensation;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + _delaiTemporisation;
    result = (prime * result) + ((_idCmd == null) ? 0 : _idCmd.hashCode());
    result = (prime * result) + _nombreCompensation;
    result = (prime * result) + (_compenserTraitement ? 1231 : 1237);
    return result;
  }

  /**
   * Déterminer si le traitement est compensé.
   *
   * @return true s'il l'est.
   */
  public boolean isCompenserTraitement()
  {
    return _compenserTraitement;
  }

  /**
   * Indiquer s'il faut compenser le traitement.
   *
   * @param compenserTraitement_p
   *          true s'il faut le compenser.
   */
  public void setCompenserTraitement(boolean compenserTraitement_p)
  {
    _compenserTraitement = compenserTraitement_p;
  }

  /**
   * @param delaiTemporisation_p
   *          the delaiTemporisation to set
   */
  public void setDelaiTemporisation(int delaiTemporisation_p)
  {
    _delaiTemporisation = delaiTemporisation_p;
  }

  /**
   * @param idCmd_p
   *          the idCMD to set
   */
  public void setIdCmd(String idCmd_p)
  {
    _idCmd = idCmd_p;
  }

  /**
   * Fixer le nombre de compensations.
   *
   * @param nombreCompensation_p
   *          Nombre de compensations.
   */
  public void setNombreCompensation(int nombreCompensation_p)
  {
    _nombreCompensation = nombreCompensation_p;
  }

  @Override
  public String toString()
  {
    return "TraiterNotificationReturn [_compenserTraitement=" + _compenserTraitement + ", _idCmd=" + _idCmd + ", _nombreCompensation=" + _nombreCompensation + ", _delaiTemporisation=" + _delaiTemporisation + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
  }

}
