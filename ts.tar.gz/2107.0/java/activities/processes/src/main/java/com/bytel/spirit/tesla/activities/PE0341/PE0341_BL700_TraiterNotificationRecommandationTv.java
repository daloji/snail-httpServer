package com.bytel.spirit.tesla.activities.PE0341;

import static java.util.Objects.isNull;

import java.text.MessageFormat;
import java.util.StringJoiner;
import java.util.UUID;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.aspectJ.LogActivity;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.connectors.stark.STARKProxy;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauRecommandationTvJSON;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.activities.Messages;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationRecommandationReponse;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationReturn;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigCompensationTraitementNotification;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigurationAChaudPE;
import com.bytel.spirit.tesla.processes.PE0341.config.TypeNotificationEnum;
import com.bytel.spirit.tesla.shared.types.PE0432.PEI0432_Request;
import com.bytel.spirit.tesla.shared.types.PE0432.PortefeuilleServices;

/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/

/**
 * Contexte du BL700 Traiter Notification Recommandation TV
 *
 * @author mvasques
 * @version ($Revision$ $Date$)
 */
public final class PE0341_BL700_TraiterNotificationRecommandationTv extends BuiltActivityContext<TraiterNotificationReturn>
{
  /**
   * Builder du BL700 Traiter Notification Recommandation TV
   *
   * @author mvasques
   * @version ($Revision$ $Date$)
   */
  public static final class PE0341_BL700_TraiterNotificationRecommandationTvBuilder
  {
    /**
     * The PE0341_BL700_RecupererNrmId object to build
     */
    private PE0341_BL700_TraiterNotificationRecommandationTv _toBuild;

    /**
     * The builder constructor
     */
    public PE0341_BL700_TraiterNotificationRecommandationTvBuilder()
    {
      _toBuild = new PE0341_BL700_TraiterNotificationRecommandationTv();
    }

    /**
     * Controls the required fields of {@link PE0341_BL700_TraiterNotificationRecommandationTvBuilder} and returns the
     * instance.
     *
     * @return The {@link PE0341_BL700_TraiterNotificationRecommandationTvBuilder} instance
     */
    public PE0341_BL700_TraiterNotificationRecommandationTv build()
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$
      if (isNull(_toBuild.getTracabilite()))
      {
        joiner.add("'_tracabilite'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNotificationReseauRecommandationTvJSON()))
      {
        joiner.add("'_notificationReseauRecommandationTvJSON'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNombreCompensation()))
      {
        joiner.add("'_nombreCompensation'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getConfigurationAchaudPE()))
      {
        joiner.add("'_configurationAchaudPE'"); //$NON-NLS-1$
      }

      // PARAMETRE INVALIDE
      if (0 != joiner.length())
      {
        _toBuild.setRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0341_BL600_TraiterNotificationOntInconnu.paramNotFilled"), joiner.toString()))); //$NON-NLS-1$
      }

      return _toBuild;
    }

    /**
     *
     *
     * @param configurationAchaudPE_p
     *          the configurationAchaudPE_p
     *
     * @return BL700_TraiterNotificationRecommandationTvBuilder
     */

    public PE0341_BL700_TraiterNotificationRecommandationTvBuilder configurationAchaudPE(ConfigurationAChaudPE configurationAchaudPE_p)
    {
      _toBuild.setConfigurationAChaudPE(configurationAchaudPE_p);
      return this;
    }

    /**
     * Fixer le nombre de compensations.
     *
     * @param nombreCompensation_p
     *          Nombre de compensations.
     * @return BL700_TraiterNotificationRecommandationTvBuilder
     */
    public PE0341_BL700_TraiterNotificationRecommandationTvBuilder nombreCompensation(Integer nombreCompensation_p)
    {
      _toBuild.setNombreCompensation(nombreCompensation_p);
      return this;
    }

    /**
     * @param notificationReseauRecommandationTvJSON_p
     *          the notificationReseauRecommandationTvJSON
     *
     * @return BL700_TraiterNotificationRecommandationTvBuilder
     */
    public PE0341_BL700_TraiterNotificationRecommandationTvBuilder notificationReseauRecommandationTvJSON(NotificationReseauRecommandationTvJSON notificationReseauRecommandationTvJSON_p)
    {
      _toBuild.setNotificationReseauRecommandationTvJSON(notificationReseauRecommandationTvJSON_p);
      return this;
    }

    /**
     * @param tracabilite_p
     *          tracabilite
     * @return BL700_TraiterNotificationRecommandationTvBuilder
     */
    public PE0341_BL700_TraiterNotificationRecommandationTvBuilder tracabilite(Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   *
   * @author mvasques
   * @version ($Revision$ $Date$)
   */
  private enum Step
  {
    /**
     * first step to execute.
     */
    First,

    /**
     * if all steps have been executed.
     */
    End;
  }

  /**
   * Unique serial identifier
   */
  private static final long serialVersionUID = -4686557468961019386L;

  /**
   * ConfigurationPE0341
   */
  private ConfigurationAChaudPE _configurationAchaudPE;

  /**
   * Tracabilite
   */
  private Tracabilite _tracabilite;

  /**
   * NotificationReseauRecommandationTvJSON
   */
  private NotificationReseauRecommandationTvJSON _notificationReseauRecommandationTvJSON;

  /**
   * Nombre de compensations.
   */
  private Integer _nombreCompensation;

  /**
   * The next step of the activity to execute.
   */
  private Step _nextStep = Step.First;

  /** Ravel Json serializer */
  private IRavelJson _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();

  @Override
  @LogActivity
  public TraiterNotificationReturn executeNextStep(IActivityCaller callingProcess_p) throws RavelException
  {
    TraiterNotificationReturn result = null;

    switch (_nextStep)
    {
      case First:
        result = traiterNotificationRecommandation(callingProcess_p);
        _nextStep = Step.End;
        break;

      default:
        break;
    }

    return result;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_nextStep);
  }

  /**
   * @param callingProcess_p
   *          the callingProcess
   *
   * @return the return
   * @throws RavelException
   *           on error
   */
  private TraiterNotificationReturn traiterNotificationRecommandation(@SuppressWarnings("unused") IActivityCaller callingProcess_p) throws RavelException
  {
    TraiterNotificationReturn result = new TraiterNotificationReturn(false, null, 0);
    //Create a new Tracabilite to avoid passing the existing one to the command
    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setNomProcessus(_tracabilite.getNomProcessus());
    tracabilite.setIdCorrelationSpirit(_tracabilite.getIdCorrelationSpirit());
    tracabilite.setIdCorrelationByTel(_tracabilite.getIdCorrelationByTel());
    //Get process name to call
    String processToCall = "/modifier-profil-tv"; //$NON-NLS-1$

    //Build the request
    PortefeuilleServices pfi = new PortefeuilleServices();
    pfi.setClientOperateur(_notificationReseauRecommandationTvJSON.getClientOperateur());
    pfi.setNoCompte(_notificationReseauRecommandationTvJSON.getNoCompte());

    PEI0432_Request pei0432Request = new PEI0432_Request();
    pei0432Request.setPorteFeuilleServices(pfi);

    // Create a map with the necessary headers
    MultivaluedMap<String, String> headers = new MultivaluedHashMap<String, String>();
    headers.add(IHttpHeadersConsts.X_REQUEST_ID, UUID.randomUUID().toString());
    headers.add(IHttpHeadersConsts.X_SOURCE, "TESLA"); //$NON-NLS-1$
    headers.add(IHttpHeadersConsts.X_PROCESS, "PE0341_NotificationReseau"); //$NON-NLS-1$

    RESTRequest restRequest = new RESTRequest.RESTRequestBuilder()//
        .httpMethod(HttpMethod.POST)//
        .request(pei0432Request)//
        .traceability(tracabilite) //
        .method(processToCall)//
        .path(processToCall)//
        .serializer(_jsonBuilder)//
        .headers(headers).build();

    try
    {
      ConnectorResponse<Retour, STARKResponse<TraiterNotificationRecommandationReponse>> connectorResponse = STARKProxy.getInstance().sendRequest(restRequest, TraiterNotificationRecommandationReponse.class);

      if (!isResultOK(connectorResponse._first) || IMegSpiritConsts.NON_RESPECT_STI.equals(connectorResponse._first.getDiagnostic()))
      {
        setRetour(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, connectorResponse._first.getLibelle()));
      }
      else
      {
        if (isResultOK(connectorResponse._first))
        {
          result.setIdCmd(connectorResponse._second.getResponse().getReponseFonctionnelle().getIdCmd());
        }

        setRetour(connectorResponse._first);
      }
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _tracabilite, exception));
      setRetour(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, exception.getMessage()));
    }

    //Traitement à exécuter quel que soit le résultat des étapes précédentes :
    if (RetourFactory.isRetourNOK(getRetour()))
    {
      for (ConfigCompensationTraitementNotification configRelanTraitNotif : _configurationAchaudPE.getListeConfigCompensationTraitementNotifications())
      {
        if (TypeNotificationEnum.RECOMMANDATION_TV.equals(configRelanTraitNotif.getTypeNotification()))
        {
          if (_nombreCompensation >= configRelanTraitNotif.getNbrMaxCompensation().intValue())
          {
            String message = MessageFormat.format(Messages.getString("PE0341_BL700_TraiterNotificationRecommandationTv.nbrrelaceatte"), getRetour().getDiagnostic()); //$NON-NLS-1$
            setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NBR_COMPENSATION_ATTEINT, message));
          }

          if (IMegConsts.CAT2.equals(getRetour().getCategorie()))
          {
            result.setCompenserTraitement(true);
            result.setDelaiTemporisation(configRelanTraitNotif.getTempoMax().intValue());
            _nombreCompensation++;
            result.setNombreCompensation(_nombreCompensation);
          }
        }
      }
    }

    return result;
  }

  /**
   * Renvoyer la configuration.
   *
   * @return Configuration.
   */
  final ConfigurationAChaudPE getConfigurationAchaudPE()
  {

    return _configurationAchaudPE;
  }

  /**
   * Renvoyer le nombre de compensations.
   *
   * @return Nombre de compensations.
   */
  final Integer getNombreCompensation()
  {

    return _nombreCompensation;
  }

  /**
   * @return value of _notificationReseauRecommandationTvJSON
   */
  final NotificationReseauRecommandationTvJSON getNotificationReseauRecommandationTvJSON()
  {
    return _notificationReseauRecommandationTvJSON;
  }

  /**
   * @return value of _tracabilite
   */
  final Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @param configurationAchaudPE_p
   *
   *          the configurationAchaudPE
   */
  void setConfigurationAChaudPE(final ConfigurationAChaudPE configurationAchaudPE_p)
  {

    _configurationAchaudPE = configurationAchaudPE_p;
  }

  /**
   * Fixer le nombre de compensations.
   *
   * @param nombreCompensation_p
   *          Nombre de compensations.
   */
  void setNombreCompensation(final Integer nombreCompensation_p)
  {
    _nombreCompensation = nombreCompensation_p;
  }

  /**
   * @param notificationReseauRecommandationTvJSON_p
   *          set the notificationReseauRecommandationTvJSON
   *
   */
  void setNotificationReseauRecommandationTvJSON(final NotificationReseauRecommandationTvJSON notificationReseauRecommandationTvJSON_p)
  {
    _notificationReseauRecommandationTvJSON = notificationReseauRecommandationTvJSON_p;
  }

  /**
   * @param tracabilite_p
   *          the tracabilite to set
   */
  void setTracabilite(final Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }
}
