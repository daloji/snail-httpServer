/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import static java.util.Objects.isNull;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringJoiner;
import java.util.UUID;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.aspectJ.LogActivity;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.RESTRequest;
import com.bytel.ravel.services.connector.RESTRequest.RESTRequestBuilder;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.ravel.services.process.activity.BuiltActivityContext;
import com.bytel.spirit.common.activities.shared.BL5400_DecoderSlid;
import com.bytel.spirit.common.activities.shared.structs.BL5400_Return;
import com.bytel.spirit.common.connectors.stark.STARKProxy;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauONTInconnuJSON;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.tesla.activities.Messages;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL610_IdentifierPfiParSnOnt.PE0341_BL610_IdentifierPfiParSnOntBuilder;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL620_IdentifierPaLigneFixeFTTH.PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationRecommandationReponse;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationReturn;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigCompensationTraitementNotification;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigurationAChaudPE;
import com.bytel.spirit.tesla.processes.PE0341.config.TypeNotificationEnum;
import com.bytel.spirit.tesla.shared.types.PE0340.EquipementOntInstalle;
import com.bytel.spirit.tesla.shared.types.PE0340.PEI0340_Request;
import com.bytel.spirit.tesla.shared.types.PE0340.PortefeuilleServices;

/**
 * Contexte du BL600 Traiter Notification ONT inconnu.
 *
 * @author jrolao
 * @version ($Revision$ $Date$)
 */
public final class PE0341_BL600_TraiterNotificationOntInconnu extends BuiltActivityContext<TraiterNotificationReturn>
{
  /**
   * The PE0340_BL600_TraiterNotificationOntInconnu builder
   *
   * @author jrolao
   * @version ($Revision$ $Date$)
   */
  public static final class PE0341_BL600_TraiterNotificationOntInconnuBuilder
  {
    /**
     * The PE0340_BL600_TraiterNotificationOntInconnu object to build
     */
    private PE0341_BL600_TraiterNotificationOntInconnu _toBuild;

    /**
     * The builder constructor
     */
    public PE0341_BL600_TraiterNotificationOntInconnuBuilder()
    {
      _toBuild = new PE0341_BL600_TraiterNotificationOntInconnu();
    }

    /**
     * Controls the required fields of {@link PE0341_BL610_IdentifierPfiParSnOnt} and returns the instance.
     *
     * @return The {@link PE0341_BL610_IdentifierPfiParSnOnt} instance
     */
    public PE0341_BL600_TraiterNotificationOntInconnu build()
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$
      if (isNull(_toBuild.getTracabilite()))
      {
        joiner.add("'_tracabilite'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNotificationReseau()))
      {
        joiner.add("'_notificationReseau'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getNombreCompensation()))
      {
        joiner.add("'_nombreCompensation'"); //$NON-NLS-1$
      }
      if (isNull(_toBuild.getConfigurationAChaudPE()))
      {
        joiner.add("'_configurationAChaudPE'"); //$NON-NLS-1$
      }

      // PARAMETRE INVALIDE
      if (0 != joiner.length())
      {
        _toBuild.setRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0341_BL600_TraiterNotificationOntInconnu.paramNotFilled"), joiner.toString()))); //$NON-NLS-1$
      }

      return _toBuild;
    }

    /**
     * Set the configurationAChaudPE parameter in PE0340_BL600 instance
     *
     * @param configurationAChaudPE_p
     *          configurationAChaudPE
     * @return The builder instance
     */
    public PE0341_BL600_TraiterNotificationOntInconnuBuilder configurationAChaudPE(final ConfigurationAChaudPE configurationAChaudPE_p)
    {
      _toBuild.setConfigurationAChaudPE(configurationAChaudPE_p);
      return this;
    }

    /**
     * Set the nombreCompensation parameter in PE0340_BL600 instance
     *
     * @param nombreCompensation_p
     *          Nombre de compensations.
     * @return The builder instance
     */
    public PE0341_BL600_TraiterNotificationOntInconnuBuilder nombreCompensation(final Integer nombreCompensation_p)
    {
      _toBuild.setNombreCompensation(nombreCompensation_p);
      return this;
    }

    /**
     * Set the numeroSerieont_p parameter in PE0340_BL610_IdentifierPfiParSnOnt instance
     *
     * @param notificationReseau_p
     *          notificationReseau object
     * @return The builder instance
     */
    public PE0341_BL600_TraiterNotificationOntInconnuBuilder notificationReseauONTInconnuJSON(final NotificationReseauONTInconnuJSON notificationReseau_p)
    {
      _toBuild.setNotificationReseau(notificationReseau_p);
      return this;
    }

    /**
     * Set the Tracabilite parameter in PE0340_BL610_IdentifierPfiParSnOnt instance
     *
     * @param tracabilite_p
     *          The tracabilite
     * @return The builder instance
     */
    public PE0341_BL600_TraiterNotificationOntInconnuBuilder tracabilite(final Tracabilite tracabilite_p)
    {
      _toBuild.setTracabilite(tracabilite_p);
      return this;
    }
  }

  /**
   * Definition of all execution steps.
   *
   * @author jrolao
   * @version ($Revision$ $Date$)
   */
  private enum Step
  {
    /**
     * first step to execute.
     */
    First,

    /**
     * if all steps have been executed.
     */
    End;
  }

  /**
   *
   */
  private static final long serialVersionUID = -459597530322132486L;

  /** Ravel Json serializer */
  private IRavelJson _jsonBuilder = new RavelJson.RavelJsonBuilder().profil(SpiritConstants.JSON_PROFILE_STARK).build();

  /**
   * Tracabilite
   */
  private Tracabilite _tracabilite;

  /**
   * NotificationReseauONTInconnuJSON
   */
  private NotificationReseauONTInconnuJSON _notificationReseau;

  /**
   * ConfigurationAChaudPE
   */
  private ConfigurationAChaudPE _configurationAChaudPE;

  /**
   * Nombre de compensations.
   */
  private Integer _nombreCompensation;

  /**
   * The next step of the activity to execute.
   */
  private Step _nextStep = Step.First;

  @Override
  @LogActivity
  public TraiterNotificationReturn executeNextStep(IActivityCaller arg0_p) throws RavelException
  {
    TraiterNotificationReturn result = null;

    switch (_nextStep) //NOSONAR
    {
      case First:
        result = traiterNotificationOntInconnu(arg0_p);
        _nextStep = Step.End;
        break;

      default:
        break;
    }

    return result;
  }

  @Override
  public boolean isEndStep()
  {
    return Step.End.equals(_nextStep);
  }

  /**
   * @param arg0_p
   *          IActivityCaller
   * @return PE0341_BL600_Return
   * @throws RavelException
   *           on error
   */
  private TraiterNotificationReturn traiterNotificationOntInconnu(IActivityCaller arg0_p) throws RavelException
  {
    final TraiterNotificationReturn result = new TraiterNotificationReturn(false, null, 0);

    final List<PA> listPA = new ArrayList<>();
    // Décoder le Slid de l’alarme pour extraire les données
    final BL5400_DecoderSlid bL5400 = new BL5400_DecoderSlid.BL5400_DecoderSlidBuilder() //
        .slid(_notificationReseau.getSlid()) //
        .tracabilite(_tracabilite) //
        .build();
    final BL5400_Return bL5400return = bL5400.execute(arg0_p);
    setRetour(bL5400.getRetour());

    if (RetourFactory.isRetourOK(getRetour()))
    {
      // Identifier les Pfi Associés a l’equipement ONT recu dans L’alarme
      final PE0341_BL610_IdentifierPfiParSnOnt bL610 = new PE0341_BL610_IdentifierPfiParSnOntBuilder() //
          .tracabilite(_tracabilite) //
          .notificationReseau(_notificationReseau) // https://jira.bouyguestelecom.fr/browse/SPIRIT-2697
          .nombreCompensation(_nombreCompensation) // https://jira.bouyguestelecom.fr/browse/SPIRIT-2697
          .numeroSerieOnt(bL5400return.getNumeroSerieOnt()) //
          .build();
      final List<PFI> bL610Return = bL610.execute(arg0_p);
      setRetour(bL610.getRetour());

      if (RetourFactory.isRetourOK(getRetour()))
      {
        //Determiner la liste PA ligne FTTX du Pfi
        final PE0341_BL620_IdentifierPaLigneFixeFTTH bL620 = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
            .tracabilite(_tracabilite) //
            .notificationReseau(_notificationReseau) //
            .nombreCompensation(_nombreCompensation) // https://jira.bouyguestelecom.fr/browse/SPIRIT-2697
            .pfi(bL610Return.get(0)) //
            .ontInstalleBasculeSpirit(_configurationAChaudPE.isOntInstalleBasculeSpirit()) //
            .topologieFtthBasculeSurSpirit(_configurationAChaudPE.isTopologieFtthBasculeSurSpirit()) //
            .build();
        final PA resultBL620 = bL620.execute(arg0_p);
        listPA.add(resultBL620);
        setRetour(bL620.getRetour());

        if (RetourFactory.isRetourOK(getRetour()))
        {
          // Déclencher l’appel vers le processus PE0341

          // Create a new Tracabilite to avoid passing the existing one to the command
          final Tracabilite tracabilite = new Tracabilite();
          tracabilite.setNomProcessus(_tracabilite.getNomProcessus());
          tracabilite.setIdCorrelationSpirit(_tracabilite.getIdCorrelationSpirit());
          tracabilite.setIdCorrelationByTel(_tracabilite.getIdCorrelationByTel());

          //Build the request
          final PEI0340_Request pei340Request = new PEI0340_Request();
          final PortefeuilleServices portefeuilleServices = new PortefeuilleServices();
          portefeuilleServices.setNoCompte(bL610Return.get(0).getNoCompte());
          portefeuilleServices.setClientOperateur(bL610Return.get(0).getClientOperateur());

          final EquipementOntInstalle equipementOntInstalle = new EquipementOntInstalle();
          equipementOntInstalle.setNoIdentifiant(bL5400return.getNumeroSerieOnt());
          equipementOntInstalle.setTechnologiePon(bL5400return.getTechonologie());
          equipementOntInstalle.setDateConnexion(_notificationReseau.getDateGenerationEvenementReseau());

          final String identifiantFonctionnelPA = listPA.get(0).getIdentifiantFonctionnelPA();

          // Set the values in the pei340Request
          pei340Request.setEquipementOntInstalle(equipementOntInstalle);
          pei340Request.setIdentifiantFonctionnelPA(identifiantFonctionnelPA);
          pei340Request.setPortefeuilleServices(portefeuilleServices);

          // Get process name to call
          final String processToCall = "/modifier-ont-installe"; //$NON-NLS-1$

          // Create a map with the necessary headers
          final MultivaluedMap<String, String> headers = new MultivaluedHashMap<>();
          headers.add(IHttpHeadersConsts.X_REQUEST_ID, UUID.randomUUID().toString());
          headers.add(IHttpHeadersConsts.X_SOURCE, "TESLA"); //$NON-NLS-1$
          headers.add(IHttpHeadersConsts.X_PROCESS, "PE0341_NotificationReseau"); //$NON-NLS-1$

          final RESTRequest restRequest = new RESTRequestBuilder() //
              .httpMethod(HttpMethod.POST) //
              .request(pei340Request) //
              .headers(headers) //
              .traceability(tracabilite) //
              .method(processToCall) //
              .path(processToCall) //
              .serializer(_jsonBuilder) //
              .build();

          try
          {
            // Call connector
            final ConnectorResponse<Retour, STARKResponse<TraiterNotificationRecommandationReponse>> connectorResponse = STARKProxy.getInstance().sendRequest(restRequest, TraiterNotificationRecommandationReponse.class);
            if (!isResultOK(connectorResponse._first) && //
                IMegSpiritConsts.NON_RESPECT_STI.equals(connectorResponse._first.getDiagnostic()))
            {
              setRetour(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, connectorResponse._first.getLibelle()));
            }
            else
            {
              if (isResultOK(connectorResponse._first))
              {
                result.setIdCmd(connectorResponse._second.getResponse().getReponseFonctionnelle().getIdCmd());
              }
              else
              {
                setRetour(connectorResponse._first);
              }
            }
          }
          catch (final RavelException exception)
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _tracabilite,
                new StringBuilder() //
                    .append("PE0341_BL600_TraiterNotificationOntInconnu/") //$NON-NLS-1$
                    .append(_notificationReseau.getIdNotificationReseau()) //
                    .append("/") //$NON-NLS-1$
                    .append(_nombreCompensation) //
                    .append(" - ") //$NON-NLS-1$
                    .append(exception.getMessage()) //
                    .toString()));
            setRetour(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, exception.getMessage()));
          }
        }
      }
    }

    // Si oRetour.resultat == NOK
    if (RetourFactory.isRetourNOK(getRetour()))
    {
      for (ConfigCompensationTraitementNotification conf : _configurationAChaudPE.getListeConfigCompensationTraitementNotifications())
      {
        if (TypeNotificationEnum.ONT_INCONNU.equals(conf.getTypeNotification()))
        {
          if (_nombreCompensation >= conf.getNbrMaxCompensation().intValue())
          {
            setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NBR_COMPENSATION_ATTEINT, MessageFormat.format(Messages.getString("PE0341_BL600_TraiterNotificationRecommandationTv.nbrrelaceatte"), getRetour().getDiagnostic()))); //$NON-NLS-1$
          }

          if (IMegConsts.CAT2.equals(getRetour().getCategorie()) || //
              (IMegConsts.CAT4.equals(getRetour().getCategorie()) && //
                  Arrays.asList(IMegSpiritConsts.SN_ONT_INCONNU, IMegSpiritConsts.PALF_ACTIF_INCONNU, IMegSpiritConsts.PON_PATH_INCONNU).contains(getRetour().getDiagnostic())))
          {
            result.setCompenserTraitement(true);
            result.setDelaiTemporisation(conf.getTempoMax().intValue());
            _nombreCompensation++;
            result.setNombreCompensation(_nombreCompensation);
          }
        }
      }
    }

    return result;
  }

  /**
   * @return value of _configurationAChaudPE
   */
  final ConfigurationAChaudPE getConfigurationAChaudPE()
  {
    return _configurationAChaudPE;
  }

  /**
   * Renvoyer le nombre de compensations.
   *
   * @return Nombre de compensations.
   */
  final Integer getNombreCompensation()
  {
    return _nombreCompensation;
  }

  /**
   * @return the notificationReseau
   */
  final NotificationReseauONTInconnuJSON getNotificationReseau()
  {
    return _notificationReseau;
  }

  /**
   * @return the tracabilite
   */
  final Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * @param configurationAChaudPE_p
   *          The _configurationAChaudPE to set.
   */
  void setConfigurationAChaudPE(final ConfigurationAChaudPE configurationAChaudPE_p)
  {
    _configurationAChaudPE = configurationAChaudPE_p;
  }

  /**
   * Fixer le nombre de compensations
   *
   * @param nombreCompensation_p
   *          Nombre de compensations.
   */
  void setNombreCompensation(final Integer nombreCompensation_p)
  {
    _nombreCompensation = nombreCompensation_p;
  }

  /**
   * @param notificationReseau_p
   *          the notificationReseau to set
   */
  void setNotificationReseau(final NotificationReseauONTInconnuJSON notificationReseau_p)
  {
    _notificationReseau = notificationReseau_p;
  }

  /**
   * @param tracabilite_p
   *          the tracabilite to set
   */
  void setTracabilite(final Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }
}
