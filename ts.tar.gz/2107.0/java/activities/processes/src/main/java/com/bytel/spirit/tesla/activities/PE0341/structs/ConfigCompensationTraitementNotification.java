/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341.structs;

import java.io.Serializable;

/**
 * Configuration d'une notification de compensation.
 *
 * @author jrolao
 * @version ($Revision$ $Date$)
 * @deprecated Utiliser la version générée par la configuration.
 */
@Deprecated
public final class ConfigCompensationTraitementNotification implements Serializable
{
  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 1L;

  /**
   * Nombre de compensations maximal.
   */
  private int _nbrCompensationMax;

  /**
   * TempoMax
   */
  private int _tempoMax;

  /**
   * Type Notification
   */
  private String _typeNotification;

  /**
   * @param nbrCompensationMax_p
   *          Nombre de compensation maximal.
   * @param tempoMax_p
   *          tempoMax
   * @param typeNotification_p
   *          typeNotification
   */
  public ConfigCompensationTraitementNotification(int nbrCompensationMax_p, int tempoMax_p, String typeNotification_p)
  {
    _nbrCompensationMax = nbrCompensationMax_p;
    _tempoMax = tempoMax_p;
    _typeNotification = typeNotification_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    ConfigCompensationTraitementNotification other = (ConfigCompensationTraitementNotification) obj;
    if (_nbrCompensationMax != other._nbrCompensationMax)
    {
      return false;
    }
    if (_tempoMax != other._tempoMax)
    {
      return false;
    }
    if (_typeNotification == null)
    {
      if (other._typeNotification != null)
      {
        return false;
      }
    }
    else if (!_typeNotification.equals(other._typeNotification))
    {
      return false;
    }
    return true;
  }

  /**
   * Renvoyer le nombre de compensations maximal.
   *
   * @return Nombre de compensations maximal.
   */
  public int getNbrCompensationMax()
  {
    return _nbrCompensationMax;
  }

  /**
   * @return the tempoMax
   */
  public int getTempoMax()
  {
    return _tempoMax;
  }

  /**
   * @return the typeNotification
   */
  public String getTypeNotification()
  {
    return _typeNotification;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + _nbrCompensationMax;
    result = (prime * result) + _tempoMax;
    result = (prime * result) + ((_typeNotification == null) ? 0 : _typeNotification.hashCode());
    return result;
  }

  /**
   * Fixer le nombre de compensation maximal.
   *
   * @param nbrCompensationMax_p
   *          Nombre de compensation maximal.
   */
  public void setNbrCompensationMax(int nbrCompensationMax_p)
  {
    _nbrCompensationMax = nbrCompensationMax_p;
  }

  /**
   * @param tempoMax_p
   *          the tempoMax to set
   */
  public void setTempoMax(int tempoMax_p)
  {
    _tempoMax = tempoMax_p;
  }

  /**
   * @param typeNotification_p
   *          the typeNotification to set
   */
  public void setTypeNotification(String typeNotification_p)
  {
    _typeNotification = typeNotification_p;
  }

  @Override
  public String toString()
  {
    return "ConfigCompensationTraitementNotification [_nbrCompensationMax=" + _nbrCompensationMax + ", _tempoMax=" + _tempoMax + ", _typeNotification=" + _typeNotification + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
  }

}
