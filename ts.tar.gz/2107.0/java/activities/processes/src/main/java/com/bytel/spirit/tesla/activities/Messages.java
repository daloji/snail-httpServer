package com.bytel.spirit.tesla.activities;

import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author jpais
 * @version ($Revision: 3231 $ $Date: 2018-01-02 14:05:57 +0100 (Tue, 02 Jan 2018) $)
 */
public class Messages
{
  /**
   * BUNDLE_NAME
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.tesla.activities.messages"; //$NON-NLS-1$
  /**
   *
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(Messages.BUNDLE_NAME);

  /**
   * Gets the string.
   *
   * @param key_p
   *          the key
   * @return the value
   */
  public static String getString(String key_p)
  {
    try
    {
      return Messages.RESOURCE_BUNDLE.getString(key_p);
    }
    catch (MissingResourceException e)
    {
      return '!' + key_p + '!';
    }
  }

  /**
   * Returns a message formatted with the supplied pattern and arguments
   *
   * @param pattern_p
   *          pattern_p
   * @param arguments_p
   *          arguments_p
   * @return String
   */
  public static String getString(String pattern_p, Object... arguments_p)
  {
    return MessageFormat.format(pattern_p, arguments_p);
  }

  /**
   *
   */
  private Messages()
  {
  }
}
