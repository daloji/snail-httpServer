/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.connectors.stark.STARKProxy;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauRecommandationTvJSON;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL700_TraiterNotificationRecommandationTv.PE0341_BL700_TraiterNotificationRecommandationTvBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationRecommandationReponse;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationReturn;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigCompensationTraitementNotification;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigurationAChaudPE;
import com.bytel.spirit.tesla.processes.PE0341.config.TypeNotificationEnum;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author mvasques
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ STARKProxy.class, IActivityCaller.class })
public class PE0341_BL700_TraiterNotificationRecommandationTvTest
{

  /**
   * bean Factory generation
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);
  }

  /**
   * Mock de {@Code Tracabilite}
   */
  protected Tracabilite _tracabilite;

  /**
   * Mock the {@link IActivityCaller}
   */
  @MockNice
  protected IActivityCaller _activityCallerMock;

  /**
   * Mock the {@code STARKProxy}
   */
  @MockStrict
  private STARKProxy _starkProxyMock;

  /**
   * Tests initialisation.
   *
   * @throws IOException
   *           on error
   */
  @Before
  public void beforeTest() throws IOException
  {

    _tracabilite = __podam.manufacturePojoWithFullData(Tracabilite.class);

    // Reset mocks
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(STARKProxy.class);

  }

  /**
   * Test when parameter tracabilite of PE0341_BL700_TraiterNotificationRecommandationTvBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL700_TraiterNotificationRecommandationTv_KO_Test_001() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_tracabilite'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
        .tracabilite(null) //
        .notificationReseauRecommandationTvJSON(new NotificationReseauRecommandationTvJSON())//
        .nombreCompensation(2)//
        .configurationAchaudPE(new ConfigurationAChaudPE())//
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, bl700.getRetour());
  }

  /**
   * Test when parameter nombreCompensation of PE0341_BL700_TraiterNotificationRecommandationTvBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */

  @Test
  public void PE0341_BL700_TraiterNotificationRecommandationTv_KO_Test_002() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_nombreCompensation'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
        .tracabilite(_tracabilite) //
        .notificationReseauRecommandationTvJSON(new NotificationReseauRecommandationTvJSON())//
        .nombreCompensation(null)//
        .configurationAchaudPE(new ConfigurationAChaudPE())//
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, bl700.getRetour());
  }

  /**
   * Test when parameter notificationReseauRecommandationTvJSON of
   * PE0341_BL700_TraiterNotificationRecommandationTvBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL700_TraiterNotificationRecommandationTv_KO_Test_003() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_notificationReseauRecommandationTvJSON'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
        .tracabilite(_tracabilite) //
        .notificationReseauRecommandationTvJSON(null)//
        .nombreCompensation(2)//
        .configurationAchaudPE(new ConfigurationAChaudPE())//
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, bl700.getRetour());
  }

  /**
   * Test when parameter configurationAchaudPE of PE0341_BL700_TraiterNotificationRecommandationTvBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL700_TraiterNotificationRecommandationTv_KO_Test_004() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_configurationAchaudPE'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
        .tracabilite(_tracabilite) //
        .notificationReseauRecommandationTvJSON(new NotificationReseauRecommandationTvJSON())//
        .nombreCompensation(2)//
        .configurationAchaudPE(null)//
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, bl700.getRetour());
  }

  /**
   * Testing PE0341_BL700_TraiterNotificationRecommandationTv when when connector stark retour is KO, Diagnostique =
   * NON_RESPECT_STI
   *
   * @throws RavelException
   *           the error
   *
   */
  @Test
  public void PE0341_BL700_TraiterNotificationRecommandationTv_Test_001() throws RavelException
  {
    //Preparing  de input data
    Retour retourKO = RetourFactoryForTU.createKO(IMegConsts.CAT2, IMegSpiritConsts.NON_RESPECT_STI, "connector response error", null); //$NON-NLS-1$

    //Mocking the stark connector
    TraiterNotificationRecommandationReponse response = new TraiterNotificationRecommandationReponse(RetourConverter.convertToJsonRetour(retourKO), "idCmd"); //$NON-NLS-1$

    STARKResponse<TraiterNotificationRecommandationReponse> stark = new STARKResponse<>(400, null);
    stark.setResponse(response);

    ConnectorResponse<Retour, STARKResponse<TraiterNotificationRecommandationReponse>> connectorResponse = new ConnectorResponse<>(retourKO, stark);

    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(TraiterNotificationRecommandationReponse.class))).andReturn(connectorResponse);

    PowerMock.replayAll();

    //Executing the test
    PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
        .tracabilite(_tracabilite)//
        .notificationReseauRecommandationTvJSON(new NotificationReseauRecommandationTvJSON())//
        .nombreCompensation(3)//
        .configurationAchaudPE(new ConfigurationAChaudPE())//
        .build();

    bl700.execute(_activityCallerMock);
    PowerMock.verifyAll();

    //Expectations and assertions
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "connector response error", null); //$NON-NLS-1$

    Assert.assertEquals(expectedRetour, bl700.getRetour());

  }

  /**
   *
   * Testing PE0341_BL700_TraiterNotificationRecommandationTv when connector stark retour is OK
   *
   * @throws RavelException
   *           on error
   *
   */
  @Test
  public void PE0341_BL700_TraiterNotificationRecommandationTv_Test_002() throws RavelException
  {
    //Preparing  de input data
    Retour retourOK = RetourFactoryForTU.createOkRetour();

    //Mocking the stark connector
    TraiterNotificationRecommandationReponse response = new TraiterNotificationRecommandationReponse(RetourConverter.convertToJsonRetour(retourOK), "idCmd"); //$NON-NLS-1$

    STARKResponse<TraiterNotificationRecommandationReponse> stark = new STARKResponse<>(400, null);
    stark.setResponse(response);

    ConnectorResponse<Retour, STARKResponse<TraiterNotificationRecommandationReponse>> connectorResponse = new ConnectorResponse<>(retourOK, stark);

    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(TraiterNotificationRecommandationReponse.class))).andReturn(connectorResponse);

    PowerMock.replayAll();

    //Executing the test
    PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
        .tracabilite(_tracabilite)//
        .nombreCompensation(3)//
        .notificationReseauRecommandationTvJSON(new NotificationReseauRecommandationTvJSON())//
        .configurationAchaudPE(new ConfigurationAChaudPE())//
        .build();

    TraiterNotificationReturn actualResult = bl700.execute(_activityCallerMock);
    PowerMock.verifyAll();

    //Expectations and assertions
    Retour expectedRetourOK = RetourFactoryForTU.createOkRetour();

    Assert.assertEquals(expectedRetourOK, bl700.getRetour());
    Assert.assertEquals("idCmd", actualResult.getIdCmd()); //$NON-NLS-1$

  }

  /**
   *
   * Testing PE0341_BL700_TraiterNotificationRecommandationTv when connectors gives an exception
   *
   * @throws RavelException
   *
   *           on error
   */
  @Test
  public void PE0341_BL700_TraiterNotificationRecommandationTv_Test_003() throws RavelException
  {

    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "error from connector", null); //$NON-NLS-1$

    //Mocking the stark connector
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(TraiterNotificationRecommandationReponse.class))).andThrow(new RavelException(ExceptionType.CONNECTOR_INITIALIZATION_ERROR, ErrorCode.AGRTOR_00001, "error from connector")); //$NON-NLS-1$

    PowerMock.replayAll();

    //Executing the test
    PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
        .tracabilite(_tracabilite)//
        .notificationReseauRecommandationTvJSON(new NotificationReseauRecommandationTvJSON())//
        .nombreCompensation(3)//
        .configurationAchaudPE(new ConfigurationAChaudPE())//
        .build();

    bl700.execute(_activityCallerMock);
    PowerMock.verifyAll();

    //Assertion
    Assert.assertEquals(expectedRetour, bl700.getRetour());

  }

  /**
   * Testing PE0341_BL700_TraiterNotificationRecommandationTv when retour is NOK, typeNotification is RECOMMANDATION_TV,
   * nombreCompensation > nbrMaxCompensation
   *
   * @throws RavelException
   *           on error
   *
   */
  @Test
  public void PE0341_BL700_TraiterNotificationRecommandationTv_Test_005() throws RavelException
  {
    //Preparing the input data
    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.ACCES_REFUSE, "connector response error", null); //$NON-NLS-1$

    ConfigCompensationTraitementNotification configRelTraitNotif = new ConfigCompensationTraitementNotification();
    configRelTraitNotif.setTypeNotification(TypeNotificationEnum.RECOMMANDATION_TV);
    configRelTraitNotif.setNbrMaxCompensation(BigInteger.ONE);
    configRelTraitNotif.setTempoMax(BigInteger.TEN);

    List<ConfigCompensationTraitementNotification> listeConfigCompensationTraitementNotification = new ArrayList<>();
    listeConfigCompensationTraitementNotification.add(configRelTraitNotif);

    ConfigurationAChaudPE configurationAChaudPE = new ConfigurationAChaudPE();
    configurationAChaudPE.getListeConfigCompensationTraitementNotifications().add(configRelTraitNotif);

    //Mocking the stark connector
    TraiterNotificationRecommandationReponse response = new TraiterNotificationRecommandationReponse(RetourConverter.convertToJsonRetour(retourNOK), "idCmd"); //$NON-NLS-1$

    STARKResponse<TraiterNotificationRecommandationReponse> stark = new STARKResponse<>(400, null);
    stark.setResponse(response);

    ConnectorResponse<Retour, STARKResponse<TraiterNotificationRecommandationReponse>> connectorResponse = new ConnectorResponse<>(retourNOK, stark);

    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(TraiterNotificationRecommandationReponse.class))).andReturn(connectorResponse);

    PowerMock.replayAll();

    //Executing the test
    PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
        .tracabilite(_tracabilite)//
        .notificationReseauRecommandationTvJSON(new NotificationReseauRecommandationTvJSON())//
        .nombreCompensation(8)//
        .configurationAchaudPE(configurationAChaudPE)//
        .build();

    TraiterNotificationReturn actualResult = bl700.execute(_activityCallerMock);
    PowerMock.verifyAll();

    //Expectations and assertions
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NBR_COMPENSATION_ATTEINT, "le nombre max d'iteration est atteint pour l'erreur: SERVICE_INDISPONIBLE", null); //$NON-NLS-1$

    Assert.assertEquals(expectedRetour, bl700.getRetour());
    Assert.assertFalse(actualResult.isCompenserTraitement());
  }

  /**
   * Testing PE0341_BL700_TraiterNotificationRecommandationTv when retour is NOK, typeNotification is not
   * RECOMMANDATION_TV, nombreCompensation > nbrMaxCompensation
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PE0341_BL700_TraiterNotificationRecommandationTv_Test_006() throws RavelException
  {
    //Preparing the input data
    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.ACCES_REFUSE, "connector response error", null); //$NON-NLS-1$

    ConfigCompensationTraitementNotification configRelTraitNotif = new ConfigCompensationTraitementNotification();
    configRelTraitNotif.setTypeNotification(TypeNotificationEnum.ONT_INCONNU);

    List<ConfigCompensationTraitementNotification> listeConfigCompensationTraitementNotification = new ArrayList<>();
    listeConfigCompensationTraitementNotification.add(configRelTraitNotif);

    ConfigurationAChaudPE configurationAChaudPE = new ConfigurationAChaudPE();
    configurationAChaudPE.getListeConfigCompensationTraitementNotifications().add(configRelTraitNotif);

    //Mocking the stark connector
    TraiterNotificationRecommandationReponse response = new TraiterNotificationRecommandationReponse(RetourConverter.convertToJsonRetour(retourNOK), "idCmd"); //$NON-NLS-1$

    STARKResponse<TraiterNotificationRecommandationReponse> stark = new STARKResponse<>(400, null);
    stark.setResponse(response);

    ConnectorResponse<Retour, STARKResponse<TraiterNotificationRecommandationReponse>> connectorResponse = new ConnectorResponse<>(retourNOK, stark);

    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(TraiterNotificationRecommandationReponse.class))).andReturn(connectorResponse);

    PowerMock.replayAll();

    //Executing the test
    PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
        .tracabilite(_tracabilite)//
        .notificationReseauRecommandationTvJSON(new NotificationReseauRecommandationTvJSON())//
        .nombreCompensation(8)//
        .configurationAchaudPE(configurationAChaudPE)//
        .build();

    bl700.execute(_activityCallerMock);
    PowerMock.verifyAll();

    //Expectations and assertions
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "connector response error", null); //$NON-NLS-1$

    Assert.assertEquals(expectedRetour, bl700.getRetour());

  }

  /**
   * Testing PE0341_BL700_TraiterNotificationRecommandationTv when retour is NOK, typeNotification is not
   * RECOMMANDATION_TV, nombreCompensation <= nbrMaxCompensation
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PE0341_BL700_TraiterNotificationRecommandationTv_Test_007() throws RavelException
  {
    //Preparing the input data
    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ACCES_REFUSE, "connector response error", null); //$NON-NLS-1$

    ConfigCompensationTraitementNotification configRelTraitNotif = new ConfigCompensationTraitementNotification();
    configRelTraitNotif.setTypeNotification(TypeNotificationEnum.RECOMMANDATION_TV);
    configRelTraitNotif.setNbrMaxCompensation(BigInteger.ONE);
    configRelTraitNotif.setTempoMax(BigInteger.ZERO);

    List<ConfigCompensationTraitementNotification> listeConfigCompensationTraitementNotification = new ArrayList<>();
    listeConfigCompensationTraitementNotification.add(configRelTraitNotif);

    ConfigurationAChaudPE configurationAChaudPE = new ConfigurationAChaudPE();
    configurationAChaudPE.getListeConfigCompensationTraitementNotifications().add(configRelTraitNotif);

    //Mocking the stark connector
    TraiterNotificationRecommandationReponse response = new TraiterNotificationRecommandationReponse(RetourConverter.convertToJsonRetour(retourNOK), "idCmd"); //$NON-NLS-1$

    STARKResponse<TraiterNotificationRecommandationReponse> stark = new STARKResponse<>(400, null);
    stark.setResponse(response);

    ConnectorResponse<Retour, STARKResponse<TraiterNotificationRecommandationReponse>> connectorResponse = new ConnectorResponse<>(retourNOK, stark);

    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(TraiterNotificationRecommandationReponse.class))).andReturn(connectorResponse);

    PowerMock.replayAll();

    //Executing the test
    PE0341_BL700_TraiterNotificationRecommandationTv bl700 = new PE0341_BL700_TraiterNotificationRecommandationTvBuilder()//
        .tracabilite(_tracabilite)//
        .notificationReseauRecommandationTvJSON(new NotificationReseauRecommandationTvJSON())//
        .nombreCompensation(0)//
        .configurationAchaudPE(configurationAChaudPE)//
        .build();

    bl700.execute(_activityCallerMock);
    PowerMock.verifyAll();

    //Expectations and assertions
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.SERVICE_INDISPONIBLE, "connector response error", null); //$NON-NLS-1$

    Assert.assertEquals(expectedRetour, bl700.getRetour());

  }

}
