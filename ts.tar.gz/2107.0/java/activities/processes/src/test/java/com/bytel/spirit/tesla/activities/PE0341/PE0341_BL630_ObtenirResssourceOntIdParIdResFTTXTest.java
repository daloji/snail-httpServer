/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import java.io.IOException;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI031_LireNrmId;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI031_LireNrmId.OSSFAI_SI031_LireNrmIdBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI032_LireNrmInfos;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI032_LireNrmInfos.OSSFAI_SI032_LireNrmInfosBuilder;
import com.bytel.spirit.common.connectors.nrm.structs.NRMInfosRetour;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX.PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.RessourceOntId;

/**
 *
 * @author icarrao
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ OSSFAI_SI031_LireNrmId.class, OSSFAI_SI031_LireNrmIdBuilder.class, PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX.class, OSSFAI_SI032_LireNrmInfos.class, OSSFAI_SI032_LireNrmInfosBuilder.class })
public class PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXTest
{
  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  private IActivityCaller _activityCallerMock;

  /**
   * Mock de {@link OSSFAI_SI031_LireNrmId}
   */
  @MockStrict
  private OSSFAI_SI031_LireNrmId _si031Mock;

  /**
   * Mock de {@link OSSFAI_SI031_LireNrmIdBuilder}
   */
  @MockStrict
  private OSSFAI_SI031_LireNrmIdBuilder _si031BuilderMock;

  /**
   * Mock de {@link OSSFAI_SI032_LireNrmInfos}
   */
  @MockStrict
  private OSSFAI_SI032_LireNrmInfos _si032Mock;

  /**
   * Mock de {@link OSSFAI_SI032_LireNrmInfosBuilder}
   */
  @MockStrict
  private OSSFAI_SI032_LireNrmInfosBuilder _si032BuilderMock;

  /**
   * Tests initialisation.
   *
   * @throws IOException
   *           on error
   */
  @Before
  public void beforeTest() throws IOException
  {

    // Reset mocks
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(OSSFAI_SI031_LireNrmId.class);
    PowerMock.mockStaticStrict(OSSFAI_SI031_LireNrmIdBuilder.class);
    PowerMock.mockStaticStrict(OSSFAI_SI032_LireNrmInfos.class);
    PowerMock.mockStaticStrict(OSSFAI_SI032_LireNrmInfosBuilder.class);
  }

  /**
   * Test when parameter tracabilite of PE0340_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL630_ObtenirResssourceOntIdParIdResFTTX_KO_001_Test() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_tracabilite'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX obtenirResssourceOntIdParIdResFTTX = new PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder()//
        .tracabilite(null) //
        .idRessourceReseauFTTX("12")// //$NON-NLS-1$
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdResFTTX.getRetour());
  }

  /**
   * Test when parameter idRessourceReseauFTTX of PE0340_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL630_ObtenirResssourceOntIdParIdResFTTX_KO_002_Test() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_idRessourceReseauFTTX'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX obtenirResssourceOntIdParIdResFTTX = new PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder()//
        .tracabilite(new Tracabilite()) //
        .idRessourceReseauFTTX(null)//
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdResFTTX.getRetour());
  }

  /**
   * Test when OOSFAI_SI031 returns NOK.
   *
   * Returns NOK CAT3 DONNE_INVALIDE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL630_ObtenirResssourceOntIdParIdResFTTX_KO_003_Test() throws Exception
  {
    //Mocks
    PowerMock.expectNew(OSSFAI_SI031_LireNrmIdBuilder.class).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.tracabilite(new Tracabilite())).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.idOss(12L)).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.build()).andReturn(_si031Mock);
    EasyMock.expect(_si031Mock.execute(_activityCallerMock)).andReturn(null);
    EasyMock.expect(_si031Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX obtenirResssourceOntIdParIdResFTTX = new PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder()//
        .tracabilite(new Tracabilite()) //
        .idRessourceReseauFTTX("12")// //$NON-NLS-1$
        .build();

    // Execute activity
    obtenirResssourceOntIdParIdResFTTX.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdResFTTX.getRetour());

  }

  /**
   * Test when OOSFAI_SI032 returns NOK.
   *
   * Returns NOK CAT3 DONNE_INVALIDE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL630_ObtenirResssourceOntIdParIdResFTTX_KO_004_Test() throws Exception
  {
    //Mocks
    PowerMock.expectNew(OSSFAI_SI031_LireNrmIdBuilder.class).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.tracabilite(new Tracabilite())).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.idOss(12L)).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.build()).andReturn(_si031Mock);
    EasyMock.expect(_si031Mock.execute(_activityCallerMock)).andReturn(1L);
    EasyMock.expect(_si031Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.expectNew(OSSFAI_SI032_LireNrmInfosBuilder.class).andReturn(_si032BuilderMock);
    EasyMock.expect(_si032BuilderMock.tracabilite(new Tracabilite())).andReturn(_si032BuilderMock);
    EasyMock.expect(_si032BuilderMock.nrmId(1)).andReturn(_si032BuilderMock);
    EasyMock.expect(_si032BuilderMock.build()).andReturn(_si032Mock);
    EasyMock.expect(_si032Mock.execute(_activityCallerMock)).andReturn(null);
    EasyMock.expect(_si032Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX obtenirResssourceOntIdParIdResFTTX = new PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder()//
        .tracabilite(new Tracabilite()) //
        .idRessourceReseauFTTX("12")// //$NON-NLS-1$
        .build();

    // Execute activity
    obtenirResssourceOntIdParIdResFTTX.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdResFTTX.getRetour());

  }

  /**
   * Test when OOSFAI_SI032 returns OK.
   *
   * Returns OK
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL630_ObtenirResssourceOntIdParIdResFTTX_OK_005_Test() throws Exception
  {
    NRMInfosRetour nrmInfosRetour = new NRMInfosRetour();
    nrmInfosRetour.setCarte(1);
    nrmInfosRetour.setOntId(43);
    nrmInfosRetour.setNomOLT("nomOlt"); //$NON-NLS-1$
    nrmInfosRetour.setPort(34);

    //Mocks
    PowerMock.expectNew(OSSFAI_SI031_LireNrmIdBuilder.class).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.tracabilite(new Tracabilite())).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.idOss(12L)).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.build()).andReturn(_si031Mock);
    EasyMock.expect(_si031Mock.execute(_activityCallerMock)).andReturn(1L);
    EasyMock.expect(_si031Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.expectNew(OSSFAI_SI032_LireNrmInfosBuilder.class).andReturn(_si032BuilderMock);
    EasyMock.expect(_si032BuilderMock.tracabilite(new Tracabilite())).andReturn(_si032BuilderMock);
    EasyMock.expect(_si032BuilderMock.nrmId(1)).andReturn(_si032BuilderMock);
    EasyMock.expect(_si032BuilderMock.build()).andReturn(_si032Mock);
    EasyMock.expect(_si032Mock.execute(_activityCallerMock)).andReturn(nrmInfosRetour);
    EasyMock.expect(_si032Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    // Build activity
    PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX obtenirResssourceOntIdParIdResFTTX = new PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder()//
        .tracabilite(new Tracabilite()) //
        .idRessourceReseauFTTX("12")// //$NON-NLS-1$
        .build();

    // Execute activity
    RessourceOntId response = obtenirResssourceOntIdParIdResFTTX.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createOkRetour();

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdResFTTX.getRetour());
    Assert.assertEquals("nomOlt", response.getNomOlt()); //$NON-NLS-1$
    Assert.assertEquals(new Integer(43), response.getOntId());
    Assert.assertEquals(new Integer(1), response.getPositionCartePon());
    Assert.assertEquals(new Integer(34), response.getPositionPortPon());
    Assert.assertEquals("12", response.getIdRessourceLie()); //$NON-NLS-1$
  }

}
