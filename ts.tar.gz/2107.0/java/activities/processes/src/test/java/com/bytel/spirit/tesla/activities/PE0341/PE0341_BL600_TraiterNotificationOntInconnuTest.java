/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.activities.shared.BL5400_DecoderSlid;
import com.bytel.spirit.common.activities.shared.BL5400_DecoderSlid.BL5400_DecoderSlidBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL5400_Return;
import com.bytel.spirit.common.connectors.stark.STARKProxy;
import com.bytel.spirit.common.connectors.stark.structs.STARKResponse;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauONTInconnuJSON;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL610_IdentifierPfiParSnOnt.PE0341_BL610_IdentifierPfiParSnOntBuilder;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL620_IdentifierPaLigneFixeFTTH.PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationRecommandationReponse;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationReturn;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigCompensationTraitementNotification;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigurationAChaudPE;
import com.bytel.spirit.tesla.processes.PE0341.config.TypeNotificationEnum;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jrolao
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0341_BL620_IdentifierPaLigneFixeFTTH.class, PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder.class, PE0341_BL610_IdentifierPfiParSnOnt.class, PE0341_BL610_IdentifierPfiParSnOntBuilder.class, PE0341_BL600_TraiterNotificationOntInconnu.class, STARKProxy.class, BL5400_DecoderSlid.class, BL5400_DecoderSlidBuilder.class })
public class PE0341_BL600_TraiterNotificationOntInconnuTest
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);
  }

  /**
   * Mock de {@Code Tracabilite}
   */
  protected Tracabilite _tracabilite;

  /**
   * Mock the {@link IActivityCaller}
   */
  @MockNice
  protected IActivityCaller _activityCallerMock;

  /**
   * Mock de {@Code ConfigurationAChaudPE}
   */
  @MockStrict
  private ConfigurationAChaudPE _configurationAChaudPE;

  /**
   * Mock the {@code PE0341_BL620_IdentifierPaLigneFixeFTTH}
   */
  @MockStrict
  private PE0341_BL620_IdentifierPaLigneFixeFTTH _BL620Mock;

  /**
   * Mock de {@link PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder}
   */
  @MockStrict
  private PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder _BL620BuilderMock;

  /**
   * Mock the {@code PE0341_BL610_IdentifierPfiParSnOnt}
   */
  @MockStrict
  private PE0341_BL610_IdentifierPfiParSnOnt _BL610Mock;

  /**
   * Mock de {@link PE0341_BL610_IdentifierPfiParSnOntBuilder}
   */
  @MockStrict
  private PE0341_BL610_IdentifierPfiParSnOntBuilder _BL610BuilderMock;

  /**
   * Mock the {@code STARKProxy}
   */
  @MockStrict
  private STARKProxy _starkProxyMock;

  /**
   * Mock the {@code BL5400_DecoderSlid}
   */
  @MockStrict
  private BL5400_DecoderSlid _BL5400Mock;

  /**
   * Mock de {@link BL5400_DecoderSlidBuilder}
   */
  @MockStrict
  private BL5400_DecoderSlidBuilder _BL5400BuilderMock;

  /**
   * Tests initialisation.
   *
   * @throws IOException
   *           on error
   */
  @Before
  public void beforeTest() throws IOException
  {

    _tracabilite = __podam.manufacturePojoWithFullData(Tracabilite.class);

    // Reset mocks
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(STARKProxy.class);
    PowerMock.mockStaticStrict(BL5400_DecoderSlid.class);
    PowerMock.mockStaticStrict(BL5400_DecoderSlidBuilder.class);
    PowerMock.mockStaticStrict(ConfigurationAChaudPE.class);
    PowerMock.mockStaticStrict(PE0341_BL610_IdentifierPfiParSnOnt.class);
    PowerMock.mockStaticStrict(PE0341_BL610_IdentifierPfiParSnOntBuilder.class);
    PowerMock.mockStaticStrict(PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder.class);
    PowerMock.mockStaticStrict(PE0341_BL620_IdentifierPaLigneFixeFTTH.class);

  }

  /**
   * Test when nominal behavior.
   *
   * Returns OK
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL600_TraiterNotificationOntInconnu_Test_000() throws Exception
  {
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$
    BL5400_Return bl5400Result = new BL5400_Return();
    bl5400Result.setNumeroSerieOnt("NUMEROTECHNOLOGIE"); //$NON-NLS-1$

    PA bL620result = new PA("identifiantfunctionnel", "ONT", Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$

    ConfigurationAChaudPE configurationAChaudPE = new ConfigurationAChaudPE();
    configurationAChaudPE.setOntInstalleBasculeSpirit(false);
    configurationAChaudPE.setTopologieFtthBasculeSurSpirit(false);

    PFI pfi = new PFI();
    List<PFI> bL610Result = new ArrayList<>();
    bL610Result.add(pfi);

    //Mocks
    PowerMock.expectNew(BL5400_DecoderSlidBuilder.class).andReturn(_BL5400BuilderMock);
    EasyMock.expect(_BL5400BuilderMock.slid("slid")).andReturn(_BL5400BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_BL5400BuilderMock.tracabilite(_tracabilite)).andReturn(_BL5400BuilderMock);
    EasyMock.expect(_BL5400BuilderMock.build()).andReturn(_BL5400Mock);
    EasyMock.expect(_BL5400Mock.execute(_activityCallerMock)).andReturn(bl5400Result);
    EasyMock.expect(_BL5400Mock.getRetour()).andReturn(retourOK);

    PowerMock.expectNew(PE0341_BL610_IdentifierPfiParSnOntBuilder.class).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.tracabilite(_tracabilite)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.notificationReseau(notificationReseau)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.nombreCompensation(2)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.numeroSerieOnt("NUMEROTECHNOLOGIE")).andReturn(_BL610BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_BL610BuilderMock.build()).andReturn(_BL610Mock);
    EasyMock.expect(_BL610Mock.execute(_activityCallerMock)).andReturn(bL610Result);
    EasyMock.expect(_BL610Mock.getRetour()).andReturn(retourOK);

    PowerMock.expectNew(PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder.class).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.tracabilite(_tracabilite)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.notificationReseau(notificationReseau)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.nombreCompensation(2)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.pfi(pfi)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.ontInstalleBasculeSpirit(false)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.topologieFtthBasculeSurSpirit(false)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.build()).andReturn(_BL620Mock);
    EasyMock.expect(_BL620Mock.execute(_activityCallerMock)).andReturn(bL620result);
    EasyMock.expect(_BL620Mock.getRetour()).andReturn(retourOK);

    //STARK connector
    TraiterNotificationRecommandationReponse response = new TraiterNotificationRecommandationReponse(RetourConverter.convertToJsonRetour(retourOK), "idCmd"); //$NON-NLS-1$
    STARKResponse<TraiterNotificationRecommandationReponse> stark = new STARKResponse<>(400, null);
    stark.setResponse(response);
    ConnectorResponse<Retour, STARKResponse<TraiterNotificationRecommandationReponse>> connectorResponse = new ConnectorResponse<>(retourOK, stark);
    EasyMock.expect(STARKProxy.getInstance()).andReturn(_starkProxyMock);
    EasyMock.expect(_starkProxyMock.sendRequest(EasyMock.anyObject(), EasyMock.eq(TraiterNotificationRecommandationReponse.class))).andReturn(connectorResponse);

    PowerMock.replayAll();

    // Build activity
    PE0341_BL600_TraiterNotificationOntInconnu bl600 = new PE0341_BL600_TraiterNotificationOntInconnu.PE0341_BL600_TraiterNotificationOntInconnuBuilder()//
        .tracabilite(_tracabilite) //
        .nombreCompensation(2)//
        .notificationReseauONTInconnuJSON(notificationReseau)//
        .configurationAChaudPE(configurationAChaudPE)//
        .build();

    //Executing the test
    bl600.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl600.getRetour());
  }

  /**
   * Test when parameter tracabilite of PE0341_BL600_TraiterNotificationOntInconnuBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "!PE0341_BL600_TraiterNotificationOntInconnu.paramNotFilled!"
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL600_TraiterNotificationOntInconnu_Test_001() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_tracabilite', '_notificationReseau', '_configurationAChaudPE'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL600_TraiterNotificationOntInconnu bl600 = new PE0341_BL600_TraiterNotificationOntInconnu.PE0341_BL600_TraiterNotificationOntInconnuBuilder()//
        .tracabilite(null) //
        .nombreCompensation(2)//
        .notificationReseauONTInconnuJSON(null)//
        .configurationAChaudPE(null)//
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, bl600.getRetour());
  }

  /**
   * Test when BL5400_DecoderSlid returns NOK.
   *
   * Returns NOK CAT3 DONNE_INVALIDE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL600_TraiterNotificationOntInconnu_Test_002() throws Exception
  {
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$

    //Mocks
    PowerMock.expectNew(BL5400_DecoderSlidBuilder.class).andReturn(_BL5400BuilderMock);
    EasyMock.expect(_BL5400BuilderMock.slid("slid")).andReturn(_BL5400BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_BL5400BuilderMock.tracabilite(_tracabilite)).andReturn(_BL5400BuilderMock);
    EasyMock.expect(_BL5400BuilderMock.build()).andReturn(_BL5400Mock);
    EasyMock.expect(_BL5400Mock.execute(_activityCallerMock)).andReturn(null);
    EasyMock.expect(_BL5400Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL600_TraiterNotificationOntInconnu bl600 = new PE0341_BL600_TraiterNotificationOntInconnu.PE0341_BL600_TraiterNotificationOntInconnuBuilder()//
        .tracabilite(_tracabilite) //
        .nombreCompensation(2)//
        .notificationReseauONTInconnuJSON(notificationReseau)//
        .configurationAChaudPE(new ConfigurationAChaudPE())//
        .build();

    //Executing the test
    bl600.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl600.getRetour());

  }

  /**
   * Test when PE0341_BL610_IdentifierPfiParSnOnt returns NOK.
   *
   * Returns NOK CAT3 DONNE_INVALIDE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL600_TraiterNotificationOntInconnu_Test_003() throws Exception
  {

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setIdNotificationReseau("id"); //$NON-NLS-1$
    notificationReseau.setSlid("slid"); //$NON-NLS-1$
    BL5400_Return bl5400Result = new BL5400_Return();
    bl5400Result.setNumeroSerieOnt("NUMEROTECHNOLOGIE"); //$NON-NLS-1$

    //Mocks
    PowerMock.expectNew(BL5400_DecoderSlidBuilder.class).andReturn(_BL5400BuilderMock);
    EasyMock.expect(_BL5400BuilderMock.slid("slid")).andReturn(_BL5400BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_BL5400BuilderMock.tracabilite(_tracabilite)).andReturn(_BL5400BuilderMock);
    EasyMock.expect(_BL5400BuilderMock.build()).andReturn(_BL5400Mock);
    EasyMock.expect(_BL5400Mock.execute(_activityCallerMock)).andReturn(bl5400Result);
    EasyMock.expect(_BL5400Mock.getRetour()).andReturn(retourOK);

    PowerMock.expectNew(PE0341_BL610_IdentifierPfiParSnOntBuilder.class).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.tracabilite(_tracabilite)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.notificationReseau(notificationReseau)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.nombreCompensation(2)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.numeroSerieOnt("NUMEROTECHNOLOGIE")).andReturn(_BL610BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_BL610BuilderMock.build()).andReturn(_BL610Mock);
    EasyMock.expect(_BL610Mock.execute(_activityCallerMock)).andReturn(null);
    EasyMock.expect(_BL610Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL600_TraiterNotificationOntInconnu bl600 = new PE0341_BL600_TraiterNotificationOntInconnu.PE0341_BL600_TraiterNotificationOntInconnuBuilder()//
        .tracabilite(_tracabilite) //
        .nombreCompensation(2)//
        .notificationReseauONTInconnuJSON(notificationReseau)//
        .configurationAChaudPE(new ConfigurationAChaudPE())//
        .build();

    //Executing the test
    bl600.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl600.getRetour());

  }

  /**
   * Test when PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder returns NOK and Configuration is NOK
   *
   * Returns NOK CAT4, NBR_COMPENSATION_ATTEINT
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL600_TraiterNotificationOntInconnu_Test_004() throws Exception
  {

    List<ConfigCompensationTraitementNotification> listConfig = new ArrayList<>();
    ConfigCompensationTraitementNotification config = new ConfigCompensationTraitementNotification();
    config.setTypeNotification(TypeNotificationEnum.ONT_INCONNU);
    config.setNbrMaxCompensation(BigInteger.ONE);
    config.setTempoMax(BigInteger.ONE);
    listConfig.add(config);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setIdNotificationReseau("id"); //$NON-NLS-1$
    notificationReseau.setSlid("slid"); //$NON-NLS-1$
    BL5400_Return bl5400Result = new BL5400_Return();
    bl5400Result.setNumeroSerieOnt("NUMEROTECHNOLOGIE"); //$NON-NLS-1$

    PFI pfi = new PFI();
    List<PFI> bL610Result = new ArrayList<>();
    bL610Result.add(pfi);

    //Mocks
    PowerMock.expectNew(BL5400_DecoderSlidBuilder.class).andReturn(_BL5400BuilderMock);
    EasyMock.expect(_BL5400BuilderMock.slid("slid")).andReturn(_BL5400BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_BL5400BuilderMock.tracabilite(_tracabilite)).andReturn(_BL5400BuilderMock);
    EasyMock.expect(_BL5400BuilderMock.build()).andReturn(_BL5400Mock);
    EasyMock.expect(_BL5400Mock.execute(_activityCallerMock)).andReturn(bl5400Result);
    EasyMock.expect(_BL5400Mock.getRetour()).andReturn(retourOK);

    PowerMock.expectNew(PE0341_BL610_IdentifierPfiParSnOntBuilder.class).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.tracabilite(_tracabilite)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.notificationReseau(notificationReseau)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.nombreCompensation(2)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.numeroSerieOnt("NUMEROTECHNOLOGIE")).andReturn(_BL610BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_BL610BuilderMock.build()).andReturn(_BL610Mock);
    EasyMock.expect(_BL610Mock.execute(_activityCallerMock)).andReturn(bL610Result);
    EasyMock.expect(_BL610Mock.getRetour()).andReturn(retourOK);

    PowerMock.expectNew(PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder.class).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.tracabilite(_tracabilite)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.notificationReseau(notificationReseau)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.nombreCompensation(2)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.pfi(pfi)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.ontInstalleBasculeSpirit(false)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.topologieFtthBasculeSurSpirit(false)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.build()).andReturn(_BL620Mock);
    EasyMock.expect(_BL620Mock.execute(_activityCallerMock)).andReturn(null);
    EasyMock.expect(_BL620Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE")); //$NON-NLS-1$

    EasyMock.expect(_configurationAChaudPE.isOntInstalleBasculeSpirit()).andReturn(false);
    EasyMock.expect(_configurationAChaudPE.isTopologieFtthBasculeSurSpirit()).andReturn(false);
    EasyMock.expect(_configurationAChaudPE.getListeConfigCompensationTraitementNotifications()).andReturn(listConfig);
    PowerMock.replayAll();

    // Build activity
    PE0341_BL600_TraiterNotificationOntInconnu bl600 = new PE0341_BL600_TraiterNotificationOntInconnu.PE0341_BL600_TraiterNotificationOntInconnuBuilder()//
        .tracabilite(_tracabilite) //
        .nombreCompensation(2)//
        .notificationReseauONTInconnuJSON(notificationReseau)//
        .configurationAChaudPE(_configurationAChaudPE)//
        .build();

    //Executing the test
    bl600.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NBR_COMPENSATION_ATTEINT, "le nombre max d'iteration est atteint pour l'erreur: DONNEE_INVALIDE", null); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl600.getRetour());

  }

  /**
   * Test when PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder returns NOK and Configuration is OK.
   *
   * Returns NOK CAT2 DONNE_INVALIDE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL600_TraiterNotificationOntInconnu_Test_005() throws Exception
  {

    List<ConfigCompensationTraitementNotification> listConfig = new ArrayList<>();
    ConfigCompensationTraitementNotification config = new ConfigCompensationTraitementNotification();
    config.setTypeNotification(TypeNotificationEnum.ONT_INCONNU);
    config.setNbrMaxCompensation(BigInteger.ONE);
    config.setTempoMax(BigInteger.ONE);
    listConfig.add(config);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setIdNotificationReseau("id"); //$NON-NLS-1$
    notificationReseau.setSlid("slid"); //$NON-NLS-1$
    BL5400_Return bl5400Result = new BL5400_Return();
    bl5400Result.setNumeroSerieOnt("NUMEROTECHNOLOGIE"); //$NON-NLS-1$

    PFI pfi = new PFI();
    List<PFI> bL610Result = new ArrayList<>();
    bL610Result.add(pfi);

    //Mocks
    PowerMock.expectNew(BL5400_DecoderSlidBuilder.class).andReturn(_BL5400BuilderMock);
    EasyMock.expect(_BL5400BuilderMock.slid("slid")).andReturn(_BL5400BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_BL5400BuilderMock.tracabilite(_tracabilite)).andReturn(_BL5400BuilderMock);
    EasyMock.expect(_BL5400BuilderMock.build()).andReturn(_BL5400Mock);
    EasyMock.expect(_BL5400Mock.execute(_activityCallerMock)).andReturn(bl5400Result);
    EasyMock.expect(_BL5400Mock.getRetour()).andReturn(retourOK);

    PowerMock.expectNew(PE0341_BL610_IdentifierPfiParSnOntBuilder.class).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.tracabilite(_tracabilite)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.notificationReseau(notificationReseau)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.nombreCompensation(0)).andReturn(_BL610BuilderMock);
    EasyMock.expect(_BL610BuilderMock.numeroSerieOnt("NUMEROTECHNOLOGIE")).andReturn(_BL610BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_BL610BuilderMock.build()).andReturn(_BL610Mock);
    EasyMock.expect(_BL610Mock.execute(_activityCallerMock)).andReturn(bL610Result);
    EasyMock.expect(_BL610Mock.getRetour()).andReturn(retourOK);

    PowerMock.expectNew(PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder.class).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.tracabilite(_tracabilite)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.notificationReseau(notificationReseau)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.nombreCompensation(0)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.pfi(pfi)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.ontInstalleBasculeSpirit(false)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.topologieFtthBasculeSurSpirit(false)).andReturn(_BL620BuilderMock);
    EasyMock.expect(_BL620BuilderMock.build()).andReturn(_BL620Mock);
    EasyMock.expect(_BL620Mock.execute(_activityCallerMock)).andReturn(null);
    EasyMock.expect(_BL620Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE")); //$NON-NLS-1$

    EasyMock.expect(_configurationAChaudPE.isOntInstalleBasculeSpirit()).andReturn(false);
    EasyMock.expect(_configurationAChaudPE.isTopologieFtthBasculeSurSpirit()).andReturn(false);
    EasyMock.expect(_configurationAChaudPE.getListeConfigCompensationTraitementNotifications()).andReturn(listConfig);
    PowerMock.replayAll();

    // Build activity
    PE0341_BL600_TraiterNotificationOntInconnu bl600 = new PE0341_BL600_TraiterNotificationOntInconnu.PE0341_BL600_TraiterNotificationOntInconnuBuilder()//
        .tracabilite(_tracabilite) //
        .nombreCompensation(0)//
        .notificationReseauONTInconnuJSON(notificationReseau)//
        .configurationAChaudPE(_configurationAChaudPE)//
        .build();

    //Executing the test
    TraiterNotificationReturn result = bl600.execute(_activityCallerMock);

    // Expected
    TraiterNotificationReturn expectedResult = new TraiterNotificationReturn(true, null, 1);
    expectedResult.setNombreCompensation(1);
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE"); //$NON-NLS-1$ //;

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl600.getRetour());
    Assert.assertEquals(expectedResult, result);

  }

}
