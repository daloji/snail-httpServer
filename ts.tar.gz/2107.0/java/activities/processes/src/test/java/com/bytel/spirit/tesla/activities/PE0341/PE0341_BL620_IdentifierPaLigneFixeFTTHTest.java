/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI031_LireNrmId;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI031_LireNrmId.OSSFAI_SI031_LireNrmIdBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI100_RecupererIdRaccordementParNrmId;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI100_RecupererIdRaccordementParNrmId.OSSFAI_SI100_RecupererIdRaccordementParNrmIdBuilder;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI117_RecupererIdRaccoparIdOss;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI117_RecupererIdRaccoparIdOss.OSSFAI_SI117_RecupererIdRaccoparIdOssBuilder;
import com.bytel.spirit.common.connectors.nrm.structs.NRMIdRaccordementByNrmId;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauONTInconnuJSON;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.rpg.AccesTechnique;
import com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssEnt;
import com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssGp;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.TechnologieAccess;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL620_IdentifierPaLigneFixeFTTH.PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX.PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL640_ObtenirResssourceOntIdParIdRacco.PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.RessourceOntId;

/**
 * Test class for PE0341_BL620_IdentifierPaLigneFixeFTTH2.
 *
 * @author acorreia
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({ PE0341_BL620_IdentifierPaLigneFixeFTTH.class, RESProxy.class, OSSFAI_SI031_LireNrmId.class, OSSFAI_SI031_LireNrmIdBuilder.class, OSSFAI_SI100_RecupererIdRaccordementParNrmId.class, OSSFAI_SI100_RecupererIdRaccordementParNrmIdBuilder.class, OSSFAI_SI117_RecupererIdRaccoparIdOss.class, OSSFAI_SI117_RecupererIdRaccoparIdOssBuilder.class, PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX.class, PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder.class, PE0341_BL640_ObtenirResssourceOntIdParIdRacco.class, PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder.class  })
public class PE0341_BL620_IdentifierPaLigneFixeFTTHTest
{
  /**
   * The activity to test
   */
  private PE0341_BL620_IdentifierPaLigneFixeFTTH _activity;

  /**
   * The tracabilite
   */
  private Tracabilite _tracabilite;

  /**
   * The IActivityCaller mock
   */
  @MockStrict
  private IActivityCaller _activityCallerMock;

  /**
   * The PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX mock
   */
  @MockStrict
  private PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX _bl630Mock;

  /**
   * The PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder mock
   */
  @MockStrict
  private PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder _bl630BuilderMock;

  /**
   * The PE0341_BL640_ObtenirResssourceOntIdParIdRacco mock
   */
  @MockStrict
  private PE0341_BL640_ObtenirResssourceOntIdParIdRacco _bl640Mock;

  /**
   * The PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder mock
   */
  @MockStrict
  private PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder _bl640BuilderMock;

  /**
   * The OSSFAI_SI031_LireNrmId mock
   */
  @MockStrict
  private OSSFAI_SI031_LireNrmId _si031Mock;

  /**
   * The OSSFAI_SI031_LireNrmIdBuilder mock
   */
  @MockStrict
  private OSSFAI_SI031_LireNrmIdBuilder _si031BuilderMock;

  /**
   * The OSSFAI_SI100_RecupererIdRaccordementParNrmId mock
   */
  @MockStrict
  private OSSFAI_SI100_RecupererIdRaccordementParNrmId _si100Mock;

  /**
   * The OSSFAI_SI100_RecupererIdRaccordementParNrmIdBuilder mock
   */
  @MockStrict
  private OSSFAI_SI100_RecupererIdRaccordementParNrmIdBuilder _si100BuilderMock;

  /**
   * The OSSFAI_SI117_RecupererIdRaccoparIdOss mock
   */
  @MockStrict
  private OSSFAI_SI117_RecupererIdRaccoparIdOss _si117Mock;

  /**
   * The OSSFAI_SI117_RecupererIdRaccoparIdOssBuilder mock
   */
  @MockStrict
  private OSSFAI_SI117_RecupererIdRaccoparIdOssBuilder _si117BuilderMock;

  /**
   * The RESProxy mock
   */
  @MockStrict
  private RESProxy _resProxyMock;

  /**
   * Runs before each test.
   */
  @Before
  public void beforeTest()
  {
    _tracabilite = new Tracabilite();

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(RESProxy.class);
  }

  /**
   * NOK, missing tracabilite.
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PE0341_BL620_Test_Builder_001() throws RavelException
  {
    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_tracabilite', '_notificationReseau', '_nombreCompensation', '_pfi'"); // $NON-NLS-1$ //$NON-NLS-1$

    // Create and call the activity
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, missing notificationReseau.
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PE0341_BL620_Test_Builder_002() throws RavelException
  {
    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_notificationReseau', '_nombreCompensation', '_pfi'"); // $NON-NLS-1$ //$NON-NLS-1$

    // Create and call the activity
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, missing pfi.
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PE0341_BL620_Test_Builder_003() throws RavelException
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_pfi'"); // $NON-NLS-1$ //$NON-NLS-1$

    // Create and call the activity
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, empty list of PA ligne Fixe.
   *
   * @throws RavelException
   *           on error
   */
  @Test
  public void PE0341_BL620_Test_NOK_001() throws RavelException
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    // PA whose type is different from LIGNE_FIXE
    PA patypePa = new PA(null, TypePA.COMPTE_ACCES.name(), Statut.ACTIF, null, null);

    // PA missing InforBruteBssGp
    PaTypeLigneFixe paTypeLigneFixeInfo = new PaTypeLigneFixe();

    PA paInfo = new PA(null, TypePA.LIGNE_FIXE.name(), Statut.ACTIF, null, null);
    paInfo.setPaTypeLigneFixe(paTypeLigneFixeInfo);

    // PA whose statut is not ACTIF
    AccesTechnique accesTechniqueStatut = new AccesTechnique(TechnologieAccess.FTTH.name(), null);

    InfoBrutBssGp infoBrutBssGpStatut = new InfoBrutBssGp(null, null);
    infoBrutBssGpStatut.setAccesTechnique(accesTechniqueStatut);

    PaTypeLigneFixe paTypeLigneFixeStatut = new PaTypeLigneFixe();
    paTypeLigneFixeStatut.setInfoBrutBssGp(infoBrutBssGpStatut);

    PA paStatut = new PA(null, TypePA.LIGNE_FIXE.name(), Statut.RESILIE, null, null);
    paStatut.setPaTypeLigneFixe(paTypeLigneFixeStatut);

    // PA whose idRaccordement is not null or empty
    AccesTechnique accesTechniqueId = new AccesTechnique(TechnologieAccess.FTTH.name(), null);

    InfoBrutBssGp infoBrutBssGpId = new InfoBrutBssGp(null, null);
    infoBrutBssGpId.setAccesTechnique(accesTechniqueId);

    PaTypeLigneFixe paTypeLigneFixeId = new PaTypeLigneFixe();
    paTypeLigneFixeId.setInfoBrutBssGp(infoBrutBssGpId);
    paTypeLigneFixeId.setIdRaccordement(StringConstants.FALSE);

    PA paId = new PA(null, TypePA.LIGNE_FIXE.name(), Statut.ACTIF, null, null);
    paId.setPaTypeLigneFixe(paTypeLigneFixeId);

    List<PA> paList = new ArrayList<>();
    paList.add(patypePa);
    paList.add(paStatut);
    paList.add(paInfo);
    paList.add(paId);

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PALF_ACTIF_INCONNU, "Pas de PaLF actif trouvé."); // $NON-NLS-1$ //$NON-NLS-1$

    // Create and call the activity
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, OSSFAI_SI031 returns NOK.
   * ontInstalleBasculeSpirit = false
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_002() throws Exception
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$
    final Long nmrId = 1L;

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    // Prepare mocks for the calls made by the activity
    prepareCallSI031(idRessourceReseauFTTX, nmrId, expectedRetour);

    // Create and call the activity
    PowerMock.replayAll();
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);
    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, OSSFAI_SI100 returns NOK.
   * ontInstalleBasculeSpirit = false
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_003() throws Exception
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$
    final Long nmrId = 1L;

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    // Prepare mocks for the calls made by the activity
    prepareCallSI031(idRessourceReseauFTTX, nmrId, RetourFactoryForTU.createOkRetour());
    prepareCallSI100(nmrId, expectedRetour);

    // Create and call the activity
    PowerMock.replayAll();
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);
    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX throws exception.
   * ontInstalleBasculeSpirit = false
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_004() throws Exception
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$
    final Long nmrId = 1L;

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "L'appel à activité PE0340_BL630_ObtenirResssourceOntIdParIdResFTTX a resultè dans une exception: END START."); // $NON-NLS-1$ //$NON-NLS-1$

    // Prepare mocks for the calls made by the activity
    prepareCallSI031(idRessourceReseauFTTX, nmrId, RetourFactoryForTU.createOkRetour());
    prepareCallSI100(nmrId, RetourFactoryForTU.createOkRetour());

    // Prepare call to PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX
    PowerMock.expectNew(PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX.PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder.class).andReturn(_bl630BuilderMock);
    EasyMock.expect(_bl630BuilderMock.tracabilite(_tracabilite)).andReturn(_bl630BuilderMock);
    EasyMock.expect(_bl630BuilderMock.idRessourceReseauFTTX(idRessourceReseauFTTX)).andReturn(_bl630BuilderMock);
    EasyMock.expect(_bl630BuilderMock.build()).andReturn(_bl630Mock);

    EasyMock.expect(_bl630Mock.execute(_activityCallerMock)).andThrow(new RavelException(ExceptionType.CONNECTOR_CHECKING_ERROR, ErrorCode.AGRTOR_00001, StringConstants.END_START));

    // Create and call the activity
    PowerMock.replayAll();

    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX returns NOK.
   * ontInstalleBasculeSpirit = false
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_005() throws Exception
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$
    final Long nmrId = 1L;

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    // Prepare mocks for the calls made by the activity
    prepareCallSI031(idRessourceReseauFTTX, nmrId, RetourFactoryForTU.createOkRetour());
    prepareCallSI100(nmrId, RetourFactoryForTU.createOkRetour());

    // Prepare call to PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX
    prepareCallBL630_ObtenirResssourceOntIdParIdResFTTX(idRessourceReseauFTTX, expectedRetour, null);

    // Create and call the activity
    PowerMock.replayAll();
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);
    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, no result.
   * ontInstalleBasculeSpirit = false
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_006() throws Exception
  {
    // Prepare objects for the request
    final String nomOlt = "nomOlt"; // $NON-NLS-1$ //$NON-NLS-1$
    final int slot = 1;
    final int port = 2;
    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$
    final Long nmrId = 1L;

    // Create the NotificationReseau
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = createValidNotificationReseau(nomOlt, slot, port);
    notificationReseauONTInconnuJSON.setIdNotificationReseau("id"); //$NON-NLS-1$

    // Create the PA list
    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PON_PATH_INCONNU, "Correspondant au triplet: nomOlt:nomOlt / numeroCarte:1 / numeroPortRelatif:2 / idNotificationReseau:id / nombreCompensation:2."); // $NON-NLS-1$ //$NON-NLS-1$

    // Prepare mocks for the calls made by the activity
    prepareCallSI031(idRessourceReseauFTTX, nmrId, RetourFactoryForTU.createOkRetour());
    prepareCallSI100(nmrId, RetourFactoryForTU.createOkRetour());

    // Prepare call to PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX
    RessourceOntId ressourceOntId = new RessourceOntId(null, null, null, null, null);
    prepareCallBL630_ObtenirResssourceOntIdParIdResFTTX(idRessourceReseauFTTX, RetourFactoryForTU.createOkRetour(), ressourceOntId);

    // Create and call the activity
    PowerMock.replayAll();
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX returns NOK DONNEE_NON_DISPONIBLE.
   * ontInstalleBasculeSpirit = false
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_007() throws Exception
  {
    // Prepare objects for the request
    final String nomOlt = "nomOltGp"; // $NON-NLS-1$ //$NON-NLS-1$
    final int slot = 1;
    final int port = 2;
    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$
    final Long nmrId = 1L;

    // Create the NotificationReseau
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = createValidNotificationReseau(nomOlt, slot, port);
    notificationReseauONTInconnuJSON.setIdNotificationReseau("id"); //$NON-NLS-1$

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PON_PATH_INCONNU, "Correspondant au triplet: nomOlt:nomOltGp / numeroCarte:1 / numeroPortRelatif:2 / idNotificationReseau:id / nombreCompensation:2."); //$NON-NLS-1$

    // Prepare mocks for the calls made by the activity
    prepareCallSI031(idRessourceReseauFTTX, nmrId, RetourFactoryForTU.createOkRetour());
    prepareCallSI100(nmrId, RetourFactoryForTU.createOkRetour());

    // Prepare call to PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX
    Retour bl630Retour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegSpiritConsts.DONNEE_NON_DISPONIBLE, IMegConsts.LIBELLE);
    prepareCallBL630_ObtenirResssourceOntIdParIdResFTTX(idRessourceReseauFTTX, bl630Retour, null);

    // Create and call the activity
    PowerMock.replayAll();

    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, OSSFAI_SI117 returns NOK.
   * ontInstalleBasculeSpirit = true
   * topologieFtthBasculeSurSpirit = true
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_008() throws Exception
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    // Prepare mocks for the calls made by the activity
    prepareCallSI117(idRessourceReseauFTTX, expectedRetour);

    // Create and call the activity
    PowerMock.replayAll();
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .ontInstalleBasculeSpirit(true)//
        .topologieFtthBasculeSurSpirit(true)//
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);
    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, RES returns NOK.
   * ontInstalleBasculeSpirit = true
   * topologieFtthBasculeSurSpirit = true
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_009() throws Exception
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    // Prepare mocks for the calls made by the activity
    prepareCallSI117(idRessourceReseauFTTX, RetourFactoryForTU.createOkRetour());

    ConnectorResponse<Retour, List<Ressource>> response = new ConnectorResponse<Retour, List<Ressource>>(expectedRetour, null);
    prepareCallResProxy(response);

    // Create and call the activity
    PowerMock.replayAll();
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .ontInstalleBasculeSpirit(true)//
        .topologieFtthBasculeSurSpirit(true)//
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);
    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, RES returns empty Ressources list.
   * ontInstalleBasculeSpirit = true
   * topologieFtthBasculeSurSpirit = true
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_010() throws Exception
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "ONT_ID non trouvé pour le raccordement idRacco"); //$NON-NLS-1$

    // Prepare mocks for the calls made by the activity
    prepareCallSI117(idRessourceReseauFTTX, RetourFactoryForTU.createOkRetour());

    ConnectorResponse<Retour, List<Ressource>> response = new ConnectorResponse<Retour, List<Ressource>>(RetourFactory.createOkRetour(), null);
    prepareCallResProxy(response);

    // Create and call the activity
    PowerMock.replayAll();
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .ontInstalleBasculeSpirit(true)//
        .topologieFtthBasculeSurSpirit(true)//
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);
    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, OSSFAI_SI117 returns NOK.
   * ontInstalleBasculeSpirit = true
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_011() throws Exception
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    // Prepare mocks for the calls made by the activity
    prepareCallSI117(idRessourceReseauFTTX, expectedRetour);

    // Create and call the activity
    PowerMock.replayAll();
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .ontInstalleBasculeSpirit(true)//
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);
    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, PE0341_BL640_ObtenirResssourceOntIdParIdRacco throws exception.
   * ontInstalleBasculeSpirit = true
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_012() throws Exception
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$
    final Long nmrId = 1L;

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "L'appel à activité PE0340_BL630_ObtenirResssourceOntIdParIdResFTTX a resultè dans une exception: END START."); // $NON-NLS-1$ //$NON-NLS-1$

    // Prepare mocks for the calls made by the activity
    prepareCallSI117(idRessourceReseauFTTX, RetourFactoryForTU.createOkRetour());

    // Prepare call to PE0341_BL640_ObtenirResssourceOntIdParIdRacco
    PowerMock.expectNew(PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder.class).andReturn(_bl640BuilderMock);
    EasyMock.expect(_bl640BuilderMock.tracabilite(_tracabilite)).andReturn(_bl640BuilderMock);
    EasyMock.expect(_bl640BuilderMock.idRaccordement("idRacco")).andReturn(_bl640BuilderMock);
    EasyMock.expect(_bl640BuilderMock.build()).andReturn(_bl640Mock);

    EasyMock.expect(_bl640Mock.execute(_activityCallerMock)).andThrow(new RavelException(ExceptionType.CONNECTOR_CHECKING_ERROR, ErrorCode.AGRTOR_00001, StringConstants.END_START));

    // Create and call the activity
    PowerMock.replayAll();

    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .ontInstalleBasculeSpirit(true) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, PE0341_BL640_ObtenirResssourceOntIdParIdRacco returns NOK.
   * ontInstalleBasculeSpirit = true
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_013() throws Exception
  {
    // Prepare objects for the request
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$
    final Long nmrId = 1L;

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    // Prepare mocks for the calls made by the activity
    prepareCallSI117(idRessourceReseauFTTX, RetourFactoryForTU.createOkRetour());

    // Prepare call to PE0341_BL640_ObtenirResssourceOntIdParIdRacco
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", expectedRetour, null); // $NON-NLS-1$

    // Create and call the activity
    PowerMock.replayAll();

    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
      .tracabilite(_tracabilite) //
      .notificationReseau(notificationReseauONTInconnuJSON) //
      .nombreCompensation(2) //
      .pfi(pfi) //
      .ontInstalleBasculeSpirit(true) //
      .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, no result.
   * ontInstalleBasculeSpirit = true
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_014() throws Exception
  {
    // Prepare objects for the request
    final String nomOlt = "nomOlt"; // $NON-NLS-1$ //$NON-NLS-1$
    final int slot = 1;
    final int port = 2;
    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$
    final Long nmrId = 1L;

    // Create the NotificationReseau
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = createValidNotificationReseau(nomOlt, slot, port);
    notificationReseauONTInconnuJSON.setIdNotificationReseau("id"); //$NON-NLS-1$

    // Create the PA list
    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PON_PATH_INCONNU, "Correspondant au triplet: nomOlt:nomOlt / numeroCarte:1 / numeroPortRelatif:2 / idNotificationReseau:id / nombreCompensation:2."); // $NON-NLS-1$ //$NON-NLS-1$

    // Prepare mocks for the calls made by the activity
    prepareCallSI117(idRessourceReseauFTTX, RetourFactoryForTU.createOkRetour());

    // Prepare call to PE0341_BL640_ObtenirResssourceOntIdParIdRacco
    RessourceOntId ressourceOntId = new RessourceOntId(null, null, null, null, null);
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", RetourFactory.createOkRetour(), ressourceOntId); // $NON-NLS-1$

    // Create and call the activity
    PowerMock.replayAll();
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .ontInstalleBasculeSpirit(true) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, PE0341_BL640_ObtenirResssourceOntIdParIdRacco returns NOK DONNEE_NON_DISPONIBLE.
   * ontInstalleBasculeSpirit = true
   * topologieFtthBasculeSurSpirit = false
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_015() throws Exception
  {
    // Prepare objects for the request
    final String nomOlt = "nomOltGp"; // $NON-NLS-1$ //$NON-NLS-1$
    final int slot = 1;
    final int port = 2;
    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$
    final Long nmrId = 1L;

    // Create the NotificationReseau
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = createValidNotificationReseau(nomOlt, slot, port);
    notificationReseauONTInconnuJSON.setIdNotificationReseau("id"); //$NON-NLS-1$

    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(true, idRessourceReseauFTTX, 1));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PON_PATH_INCONNU, "Correspondant au triplet: nomOlt:nomOltGp / numeroCarte:1 / numeroPortRelatif:2 / idNotificationReseau:id / nombreCompensation:2."); // $NON-NLS-1$ //$NON-NLS-1$

    // Prepare mocks for the calls made by the activity
    prepareCallSI117(idRessourceReseauFTTX, RetourFactoryForTU.createOkRetour());

    // Prepare call to PE0341_BL640_ObtenirResssourceOntIdParIdRacco
    Retour bl640Retour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegSpiritConsts.DONNEE_NON_DISPONIBLE, IMegConsts.LIBELLE);
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", bl640Retour, null); // $NON-NLS-1$


    // Create and call the activity
    PowerMock.replayAll();

    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .ontInstalleBasculeSpirit(true) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * NOK, two PA with the same idRessourceReseauFTTX but last OSSFAI_SI117 call returns NOK
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_NOK_016() throws Exception
  {
    // Prepare objects for the request
    final String idRessourceReseauFTTXGp = "99999"; // $NON-NLS-1$ //$NON-NLS-1$
    final String idRessourceReseauFTTXEnt = "12345"; // $NON-NLS-1$ //$NON-NLS-1$

    final String nomOlt = "nomOltGp"; // $NON-NLS-1$ //$NON-NLS-1$
    final int slot = 1;
    final int port = 2;

    // The expected response
    Retour expectedRetour = RetourFactoryForTU.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE);

    // Create the NotificationReseau
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = createValidNotificationReseau(nomOlt, slot, port);

    // Create the PA list
    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(false, idRessourceReseauFTTXEnt, 3));
    paList.add(createValidPA(false, idRessourceReseauFTTXGp, 1));
    paList.add(createValidPA(true, idRessourceReseauFTTXGp, 2));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // Prepare mocks for the calls made by the activity
    // Calls to the first PA
    prepareCallSI117(idRessourceReseauFTTXEnt, RetourFactoryForTU.createOkRetour());
    RessourceOntId ressourceOntId2 = new RessourceOntId(nomOlt, null, slot, port, null);
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", RetourFactory.createOkRetour(), ressourceOntId2); // $NON-NLS-1$

    // Calls to the second PA
    prepareCallSI117(idRessourceReseauFTTXGp, RetourFactoryForTU.createOkRetour());
    RessourceOntId ressourceOntId1 = new RessourceOntId(nomOlt, null, slot, port, null);
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", RetourFactory.createOkRetour(), ressourceOntId1); // $NON-NLS-1$

    // Calls to the third PA
    prepareCallSI117(idRessourceReseauFTTXGp, expectedRetour);

    // Create and call the activity
    PowerMock.replayAll();

    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .ontInstalleBasculeSpirit(true) //
        .topologieFtthBasculeSurSpirit(false) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);
    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(expectedRetour, _activity.getRetour());
    Assert.assertNull(actualPA);
  }

  /**
   * Nominal test with ontInstalleBasculeSpirit = false and topologieFtthBasculeSurSpirit = false.</br>
   * OK, three PAs (one with the same idRessourceReseauFTTX).
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_OK_001() throws Exception
  {
    // Prepare objects for the request
    final String idRessourceReseauFTTXGp = "99999"; // $NON-NLS-1$ //$NON-NLS-1$
    final String idRessourceReseauFTTXEnt = "12345"; // $NON-NLS-1$ //$NON-NLS-1$

    final String nomOlt = "nomOltGp"; // $NON-NLS-1$ //$NON-NLS-1$
    final int slot = 1;
    final int port = 2;

    // Create the NotificationReseau
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = createValidNotificationReseau(nomOlt, slot, port);

    // The expected response
    PA expectedPA = createValidPA(false, idRessourceReseauFTTXEnt, 3);

    // Create the PA list
    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(false, idRessourceReseauFTTXGp, 1));
    paList.add(createValidPA(true, idRessourceReseauFTTXGp, 2));
    paList.add(expectedPA);

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // Prepare mocks for the calls made by the activity
    // Calls to the first PA
    prepareCallSI031(idRessourceReseauFTTXGp, 1L, RetourFactoryForTU.createOkRetour());
    prepareCallSI100(1L, RetourFactoryForTU.createOkRetour());

    RessourceOntId ressourceOntId1 = new RessourceOntId(nomOlt, null, slot + 1, port + 1, null);
    prepareCallBL630_ObtenirResssourceOntIdParIdResFTTX(idRessourceReseauFTTXGp, RetourFactoryForTU.createOkRetour(), ressourceOntId1);

    // Calls to the second PA
    prepareCallSI031(idRessourceReseauFTTXGp, 1L, RetourFactoryForTU.createOkRetour());
    prepareCallSI100(1L, RetourFactoryForTU.createOkRetour());

    prepareCallBL630_ObtenirResssourceOntIdParIdResFTTX(idRessourceReseauFTTXGp, RetourFactoryForTU.createOkRetour(), ressourceOntId1);

    // Calls to the third PA
    prepareCallSI031(idRessourceReseauFTTXEnt, 1L, RetourFactoryForTU.createOkRetour());
    prepareCallSI100(1L, RetourFactoryForTU.createOkRetour());

    RessourceOntId ressourceOntId2 = new RessourceOntId(nomOlt, null, slot, port, null);
    prepareCallBL630_ObtenirResssourceOntIdParIdResFTTX(idRessourceReseauFTTXEnt, RetourFactoryForTU.createOkRetour(), ressourceOntId2);

    // Create and call the activity
    PowerMock.replayAll();

    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _activity.getRetour());
    Assert.assertEquals(expectedPA, actualPA);
  }

  /**
   * Nominal test with ontInstalleBasculeSpirit = true and topologieFtthBasculeSurSpirit = true.</br>
   * OK, one PA with the same idRessourceReseauFTTX.</br>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_OK_002() throws Exception
  {
    // Prepare objects for the request
    final String nomOlt = "nomOltGp"; // $NON-NLS-1$ //$NON-NLS-1$
    final int slot = 1;
    final int port = 2;

    // Create the NotificationReseau
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = createValidNotificationReseau(nomOlt, slot, port);

    final String idRessourceReseauFTTX = "12345"; // $NON-NLS-1$ //$NON-NLS-1$

    // Expected response
    PA expectedPA = createValidPA(true, idRessourceReseauFTTX, 1);

    List<PA> paList = new ArrayList<>();
    paList.add(expectedPA);

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // Prepare mocks for the calls made by the activity
    prepareCallSI117(idRessourceReseauFTTX, RetourFactoryForTU.createOkRetour());

    com.bytel.spirit.common.shared.saab.res.RessourceOntId ressourceOntId = new com.bytel.spirit.common.shared.saab.res.RessourceOntId(null, nomOlt, slot, port, null);
    List<Ressource> ressources = Stream.of(ressourceOntId).collect(Collectors.toList());
    ConnectorResponse<Retour, List<Ressource>> response = new ConnectorResponse<>(RetourFactory.createOkRetour(), ressources);
    prepareCallResProxy(response);

    // Create and call the activity
    PowerMock.replayAll();
    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .ontInstalleBasculeSpirit(true)//
        .topologieFtthBasculeSurSpirit(true)//
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);
    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(RetourFactory.createOkRetour(), _activity.getRetour());
    Assert.assertEquals(expectedPA, actualPA);
  }

  /**
   * Nominal test with ontInstalleBasculeSpirit = true and topologieFtthBasculeSurSpirit = false.</br>
   * OK, one PA with the same idRessourceReseauFTTX.</br>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_OK_003() throws Exception
  {
    // Prepare objects for the request
    final String idRessourceReseauFTTXGp = "99999"; // $NON-NLS-1$ //$NON-NLS-1$
    final String idRessourceReseauFTTXEnt = "12345"; // $NON-NLS-1$ //$NON-NLS-1$

    final String nomOlt = "nomOltGp"; // $NON-NLS-1$ //$NON-NLS-1$
    final int slot = 1;
    final int port = 2;

    // Create the NotificationReseau
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = createValidNotificationReseau(nomOlt, slot, port);

    // The expected response
    PA expectedPA = createValidPA(false, idRessourceReseauFTTXEnt, 3);

    // Create the PA list
    List<PA> paList = new ArrayList<>();
    paList.add(createValidPA(false, idRessourceReseauFTTXGp, 1));
    paList.add(createValidPA(true, idRessourceReseauFTTXGp, 2));
    paList.add(expectedPA);

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // Prepare mocks for the calls made by the activity
    // Calls to the first PA
    prepareCallSI117(idRessourceReseauFTTXGp, RetourFactoryForTU.createOkRetour());
    RessourceOntId ressourceOntId1 = new RessourceOntId(nomOlt, null, slot + 1, port + 1, null);
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", RetourFactory.createOkRetour(), ressourceOntId1); // $NON-NLS-1$

    // Calls to the second PA
    prepareCallSI117(idRessourceReseauFTTXGp, RetourFactoryForTU.createOkRetour());
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", RetourFactory.createOkRetour(), ressourceOntId1); // $NON-NLS-1$

    // Calls to the third PA
    prepareCallSI117(idRessourceReseauFTTXEnt, RetourFactoryForTU.createOkRetour());
    RessourceOntId ressourceOntId2 = new RessourceOntId(nomOlt, null, slot, port, null);
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", RetourFactory.createOkRetour(), ressourceOntId2); // $NON-NLS-1$

    // Create and call the activity
    PowerMock.replayAll();

    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
      .tracabilite(_tracabilite) //
      .notificationReseau(notificationReseauONTInconnuJSON) //
      .nombreCompensation(2) //
      .pfi(pfi) //
      .ontInstalleBasculeSpirit(true) //
      .topologieFtthBasculeSurSpirit(false) //
      .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _activity.getRetour());
    Assert.assertEquals(expectedPA, actualPA);
  }

  /**
   * Nominal test with ontInstalleBasculeSpirit = true and topologieFtthBasculeSurSpirit = false.</br>
   * OK, three PA with the same idRessourceReseauFTTX.</br>
   *
   * @throws Exception
   *           on error.
   */
  @Test
  public void PE0341_BL620_Test_OK_004() throws Exception
  {
    // Prepare objects for the request
    final String idRessourceReseauFTTXGp = "99999"; // $NON-NLS-1$ //$NON-NLS-1$
    final String idRessourceReseauFTTXEnt = "12345"; // $NON-NLS-1$ //$NON-NLS-1$

    final String nomOlt = "nomOltGp"; // $NON-NLS-1$ //$NON-NLS-1$
    final int slot = 1;
    final int port = 2;

    // Create the NotificationReseau
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = createValidNotificationReseau(nomOlt, slot, port);

    // The expected response
    PA expectedPA = createValidPA(false, idRessourceReseauFTTXEnt, 3);

    // Create the PA list
    List<PA> paList = new ArrayList<>();
    paList.add(expectedPA);
    paList.add(createValidPA(false, idRessourceReseauFTTXGp, 1));
    paList.add(createValidPA(true, idRessourceReseauFTTXGp, 2));

    PFI pfi = new PFI();
    pfi.setPa(paList);

    // Prepare mocks for the calls made by the activity
    // Calls to the first PA
    prepareCallSI117(idRessourceReseauFTTXEnt, RetourFactoryForTU.createOkRetour());
    RessourceOntId ressourceOntId2 = new RessourceOntId(nomOlt, null, slot, port, null);
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", RetourFactory.createOkRetour(), ressourceOntId2); // $NON-NLS-1$

    // Calls to the second PA
    prepareCallSI117(idRessourceReseauFTTXGp, RetourFactoryForTU.createOkRetour());
    RessourceOntId ressourceOntId1 = new RessourceOntId(nomOlt, null, slot, port, null);
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", RetourFactory.createOkRetour(), ressourceOntId1); // $NON-NLS-1$

    // Calls to the third PA
    prepareCallSI117(idRessourceReseauFTTXGp, RetourFactoryForTU.createOkRetour());
    prepareCallBL640_ObtenirResssourceOntIdParIdRacco("idRacco", RetourFactory.createOkRetour(), ressourceOntId1); // $NON-NLS-1$

    // Create and call the activity
    PowerMock.replayAll();

    _activity = new PE0341_BL620_IdentifierPaLigneFixeFTTHBuilder() //
        .tracabilite(_tracabilite) //
        .notificationReseau(notificationReseauONTInconnuJSON) //
        .nombreCompensation(2) //
        .pfi(pfi) //
        .ontInstalleBasculeSpirit(true) //
        .topologieFtthBasculeSurSpirit(false) //
        .build();

    PA actualPA = _activity.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Check the result is as expected
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), _activity.getRetour());
    Assert.assertEquals(expectedPA, actualPA);
  }

  /**
   * Create a valid {@link NotificationReseauONTInconnuJSON}.
   *
   * @param nomOlt_p
   *          the olt name.
   * @param slot_p
   *          the slot.
   * @param port_p
   *          the port.
   * @return the create object.
   */
  private NotificationReseauONTInconnuJSON createValidNotificationReseau(String nomOlt_p, int slot_p, int port_p)
  {
    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();
    notificationReseauONTInconnuJSON.setNomOlt(nomOlt_p);
    notificationReseauONTInconnuJSON.setPositionCartePon(Integer.toString(slot_p));
    notificationReseauONTInconnuJSON.setPositionPon(Integer.toString(port_p));

    return notificationReseauONTInconnuJSON;
  }

  /**
   * Create a valid {@link PA}.
   *
   * @param isPAEnt_p
   *          whether the PA is a InfoBrutBssEnt or InfoBrutBssGp.
   * @param idRessourceReseauFTTX_p
   *          the idRessourceReseauFTTX.
   * @param id_p
   *          the id for the created {@link PA}.
   * @return the create object.
   */
  private PA createValidPA(boolean isPAEnt_p, String idRessourceReseauFTTX_p, int id_p)
  {
    AccesTechnique accesTechnique = new AccesTechnique(TechnologieAccess.FTTH.name(), null);

    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();

    if (isPAEnt_p)
    {
      InfoBrutBssEnt infoBrutBssEnt = new InfoBrutBssEnt();
      infoBrutBssEnt.setAccesTechnique(accesTechnique);
      infoBrutBssEnt.setIdRessourceReseauFTTX(idRessourceReseauFTTX_p);

      paTypeLigneFixe.setInfoBrutBssEnt(infoBrutBssEnt);
    }
    else
    {
      InfoBrutBssGp infoBrutBssGp = new InfoBrutBssGp(null, null);
      infoBrutBssGp.setAccesTechnique(accesTechnique);
      infoBrutBssGp.setIdRessourceReseauFTTX(idRessourceReseauFTTX_p);

      paTypeLigneFixe.setInfoBrutBssGp(infoBrutBssGp);
    }

    PA pa = new PA("identifiantFonctionnelPA" + id_p, TypePA.LIGNE_FIXE.name(), Statut.ACTIF, null, null); // $NON-NLS-1$ //$NON-NLS-1$
    pa.setPaTypeLigneFixe(paTypeLigneFixe);

    return pa;
  }

  /**
   * Prepare the call to {@link PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX}.
   *
   * @param idRessourceReseauFTTX_p
   *          the idRessourceReseautFTTX.
   * @param finalRetour_p
   *          the {@link Retour} of the activity.
   * @param ressourceOntId_p
   *          the {@link RessourceOntId} returned by the activity.
   * @throws Exception
   *           on error.
   */
  private void prepareCallBL630_ObtenirResssourceOntIdParIdResFTTX(String idRessourceReseauFTTX_p, Retour finalRetour_p, RessourceOntId ressourceOntId_p) throws Exception
  {
    PowerMock.expectNew(PE0341_BL630_ObtenirResssourceOntIdParIdResFTTX.PE0341_BL630_ObtenirResssourceOntIdParIdResFTTXBuilder.class).andReturn(_bl630BuilderMock);
    EasyMock.expect(_bl630BuilderMock.tracabilite(_tracabilite)).andReturn(_bl630BuilderMock);
    EasyMock.expect(_bl630BuilderMock.idRessourceReseauFTTX(idRessourceReseauFTTX_p)).andReturn(_bl630BuilderMock);
    EasyMock.expect(_bl630BuilderMock.build()).andReturn(_bl630Mock);

    EasyMock.expect(_bl630Mock.execute(_activityCallerMock)).andReturn(ressourceOntId_p);
    EasyMock.expect(_bl630Mock.getRetour()).andReturn(finalRetour_p);
  }

  /**
   * Prepare the call to {@link PE0341_BL640_ObtenirResssourceOntIdParIdRacco}.
   *
   * @param idRaccordement_p
   *          the idRaccordement.
   * @param finalRetour_p
   *          the {@link Retour} of the activity.
   * @param ressourceOntId_p
   *          the {@link RessourceOntId} returned by the activity.
   * @throws Exception
   *           on error.
   */
  private void prepareCallBL640_ObtenirResssourceOntIdParIdRacco(String idRaccordement_p, Retour finalRetour_p, RessourceOntId ressourceOntId_p) throws Exception
  {
    PowerMock.expectNew(PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder.class).andReturn(_bl640BuilderMock);
    EasyMock.expect(_bl640BuilderMock.tracabilite(_tracabilite)).andReturn(_bl640BuilderMock);
    EasyMock.expect(_bl640BuilderMock.idRaccordement(idRaccordement_p)).andReturn(_bl640BuilderMock);
    EasyMock.expect(_bl640BuilderMock.build()).andReturn(_bl640Mock);

    EasyMock.expect(_bl640Mock.execute(_activityCallerMock)).andReturn(ressourceOntId_p);
    EasyMock.expect(_bl640Mock.getRetour()).andReturn(finalRetour_p);
  }

  /**
   * Prepare the call to RES.ressourceLireTousParIdRessourceLie.
   *
   * @param response_p
   *          The response to the RES call
   * @throws RavelException
   *           on error
   */
  private void prepareCallResProxy(ConnectorResponse<Retour, List<Ressource>> response_p) throws RavelException
  {
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.ressourceLireTousParIdRessourceLie(_tracabilite, "idRacco", "ONT_ID")).andReturn(response_p); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * Prepare the call to {@link OSSFAI_SI031_LireNrmId}.
   *
   * @param idRessourceReseauFTTX_p
   *          the idRessourceReseautFTTX.
   * @param finalRetour_p
   *          the {@link Retour} of the activity.
   * @param nmrId_p
   *          the nmrId returned by the activity.
   * @throws Exception
   *           on error.
   */
  private void prepareCallSI031(String idRessourceReseauFTTX_p, Long nmrId_p, Retour finalRetour_p) throws Exception
  {
    PowerMock.expectNew(OSSFAI_SI031_LireNrmIdBuilder.class).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.tracabilite(_tracabilite)).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.idOss(Long.parseLong(idRessourceReseauFTTX_p))).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.build()).andReturn(_si031Mock);

    EasyMock.expect(_si031Mock.execute(_activityCallerMock)).andReturn(nmrId_p);
    EasyMock.expect(_si031Mock.getRetour()).andReturn(finalRetour_p);
  }

  /**
   * Prepare the call to {@link OSSFAI_SI100_RecupererIdRaccordementParNrmId}.
   *
   * @param nmrId_p
   *          the nmrId returned by the OSSFAI_SI031_LireNrmId.
   * @param finalRetour_p
   *          the {@link Retour} of the activity.
   * @throws Exception
   *           on error.
   */
  private void prepareCallSI100(Long nmrId_p, Retour finalRetour_p) throws Exception
  {
    PowerMock.expectNew(OSSFAI_SI100_RecupererIdRaccordementParNrmIdBuilder.class).andReturn(_si100BuilderMock);
    EasyMock.expect(_si100BuilderMock.tracabilite(_tracabilite)).andReturn(_si100BuilderMock);
    EasyMock.expect(_si100BuilderMock.nrmId(nmrId_p.toString())).andReturn(_si100BuilderMock);
    EasyMock.expect(_si100BuilderMock.build()).andReturn(_si100Mock);

    EasyMock.expect(_si100Mock.execute(_activityCallerMock)).andReturn(new NRMIdRaccordementByNrmId());
    EasyMock.expect(_si100Mock.getRetour()).andReturn(finalRetour_p);
  }

  /**
   * Prepare the call to {@link OSSFAI_SI117_RecupererIdRaccoparIdOss}.
   *
   * @param idRessourceReseauFTTX_p
   *          the idRessourceReseautFTTX.
   * @param finalRetour_p
   *          the {@link Retour} of the activity.
   * @throws Exception
   *           on error.
   */
  private void prepareCallSI117(String idRessourceReseauFTTX_p, Retour finalRetour_p) throws Exception
  {
    PowerMock.expectNew(OSSFAI_SI117_RecupererIdRaccoparIdOssBuilder.class).andReturn(_si117BuilderMock);
    EasyMock.expect(_si117BuilderMock.tracabilite(_tracabilite)).andReturn(_si117BuilderMock);
    EasyMock.expect(_si117BuilderMock.idOss(Long.parseLong(idRessourceReseauFTTX_p))).andReturn(_si117BuilderMock);
    EasyMock.expect(_si117BuilderMock.build()).andReturn(_si117Mock);

    EasyMock.expect(_si117Mock.execute(_activityCallerMock)).andReturn("idRacco"); //$NON-NLS-1$
    EasyMock.expect(_si117Mock.getRetour()).andReturn(finalRetour_p);
  }
}
