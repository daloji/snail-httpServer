/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.connectors.air.AIRProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauONTInconnuJSON;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL610_IdentifierPfiParSnOnt.PE0341_BL610_IdentifierPfiParSnOntBuilder;

/**
 *
 * @author icarrao
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ AIRProxy.class, RPGProxy.class })
public class PE0341_BL610_IdentifierPfiParSnOntTest
{
  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  private IActivityCaller _activityCallerMock;

  /**
   * Mock de {@link AIRProxy}
   */
  @MockStrict
  private AIRProxy _airProxyMock;

  /**
   * Mock de {@link RPGProxy}
   */
  @MockStrict
  private RPGProxy _rpgProxyMock;

  /**
   * Tests initialisation.
   *
   * @throws IOException
   *           on error
   */
  @Before
  public void beforeTest() throws IOException
  {
    // Reset mocks
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(AIRProxy.class);
    PowerMock.mockStaticStrict(RPGProxy.class);
  }

  /**
   * Test when parameter tracabilite of PE0340_BL610_IdentifierPfiParSnOntBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL610_IdentifierPfiParSnOnt_KO_001_Test() throws Exception
  {
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_tracabilite', '_notificationReseau', '_nombreCompensation'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL610_IdentifierPfiParSnOnt obtenirResssourceOntIdParIdResFTTX = new PE0341_BL610_IdentifierPfiParSnOntBuilder()//
        .tracabilite(null) //
        .numeroSerieOnt("235") //$NON-NLS-1$
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdResFTTX.getRetour());
  }

  /**
   * Test when parameter numeroSerieOnt of PE0340_BL610_IdentifierPfiParSnOntBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled: '_idNotificationReseau', '_nombreCompensation',
   * '_numeroSerieOnt'"
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL610_IdentifierPfiParSnOnt_KO_002_Test() throws Exception
  {
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_notificationReseau', '_nombreCompensation', '_numeroSerieOnt'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL610_IdentifierPfiParSnOnt obtenirResssourceOntIdParIdResFTTX = new PE0341_BL610_IdentifierPfiParSnOntBuilder()//
        .tracabilite(new Tracabilite()) //
        .numeroSerieOnt(null).build();

    // Asserts
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdResFTTX.getRetour());
  }

  /**
   * Test when AIRProxy returns NOK.
   *
   * Returns NOK CAT3 DONNE_INVALIDE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL610_IdentifierPfiParSnOnt_KO_003_Test() throws Exception
  {
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$

    //Mocks
    ConnectorResponse<Retour, List<IndexRecherchePfi>> airReturn = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT3, //
        IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE_AIR_ERROR"), null); //$NON-NLS-1$
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxyMock);
    EasyMock.expect(_airProxyMock.indexRechercherPfiLireTousParCleRecherche(EasyMock.eq(new Tracabilite()), EasyMock.eq("SN_ONT"), EasyMock.eq("234"))).andReturn(airReturn); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL610_IdentifierPfiParSnOnt identifierPfiParSnOnt = new PE0341_BL610_IdentifierPfiParSnOntBuilder()//
        .tracabilite(new Tracabilite()) //
        .notificationReseau(notificationReseau) //
        .nombreCompensation(2) //
        .numeroSerieOnt("234").build(); //$NON-NLS-1$

    // Execute activity
    identifierPfiParSnOnt.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE_AIR_ERROR"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, identifierPfiParSnOnt.getRetour());
  }

  /**
   * Test when AIRProxy returns NOK - with the diagnostic DONNEE_INCONNUE.
   *
   * Returns NOK CAT3 SN_ONT_INCONNU
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL610_IdentifierPfiParSnOnt_KO_004_Test() throws Exception
  {
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$

    //Mocks
    ConnectorResponse<Retour, List<IndexRecherchePfi>> airReturn = new ConnectorResponse<Retour, List<IndexRecherchePfi>>(RetourFactoryForTU.createNOK(IMegConsts.CAT3, //
        IMegConsts.DONNEE_INCONNUE, "LIBELLE_AIR_ERROR"), null); //$NON-NLS-1$
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxyMock);
    EasyMock.expect(_airProxyMock.indexRechercherPfiLireTousParCleRecherche(EasyMock.eq(new Tracabilite()), EasyMock.eq("SN_ONT"), EasyMock.eq("234"))).andReturn(airReturn); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL610_IdentifierPfiParSnOnt identifierPfiParSnOnt = new PE0341_BL610_IdentifierPfiParSnOntBuilder()//
        .tracabilite(new Tracabilite()) //
        .notificationReseau(notificationReseau) //
        .nombreCompensation(2) //
        .numeroSerieOnt("234").build(); //$NON-NLS-1$

    // Execute activity
    identifierPfiParSnOnt.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_ONT_INCONNU, "numero de serie Ont non attribué a un Pfi"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, identifierPfiParSnOnt.getRetour());
  }

  /**
   * Test when RPGProxy returns NOK - with the diagnostic DONNEE_INCONNUE in the 2 iterations of the cycle.
   *
   * Returns NOK CAT4 SN_ONT_INCONNU
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL610_IdentifierPfiParSnOnt_KO_005_Test() throws Exception
  {
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$

    IndexRecherchePfi indexRecherchePfi_1 = new IndexRecherchePfi("clientOp1", "noCompte1"); //$NON-NLS-1$ //$NON-NLS-2$
    IndexRecherchePfi indexRecherchePfi_2 = new IndexRecherchePfi("clientOp2", "noCompte2"); //$NON-NLS-1$ //$NON-NLS-2$
    List<IndexRecherchePfi> listRetourAir = new ArrayList<>();
    listRetourAir.add(indexRecherchePfi_1);
    listRetourAir.add(indexRecherchePfi_2);

    //Mocks AIR
    ConnectorResponse<Retour, List<IndexRecherchePfi>> airReturn = new ConnectorResponse<Retour, List<IndexRecherchePfi>>(RetourFactoryForTU.createOkRetour(), listRetourAir);
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxyMock);
    EasyMock.expect(_airProxyMock.indexRechercherPfiLireTousParCleRecherche(EasyMock.eq(new Tracabilite()), EasyMock.eq("SN_ONT"), EasyMock.eq("234"))).andReturn(airReturn); //$NON-NLS-1$//$NON-NLS-2$

    //Mocks RPG 1st iteration
    ConnectorResponse<Retour, PFI> rpgReturn1 = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createNOK(IMegConsts.CAT3, //
        IMegConsts.DONNEE_INCONNUE, "LIBELLE_RPG_ERROR"), null); //$NON-NLS-1$
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.eq(new Tracabilite()), EasyMock.eq("clientOp1"), EasyMock.eq("noCompte1"))).andReturn(rpgReturn1); //$NON-NLS-1$//$NON-NLS-2$

    //Mocks RPG 2nd iteration
    ConnectorResponse<Retour, PFI> rpgReturn2 = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createNOK(IMegConsts.CAT3, //
        IMegConsts.DONNEE_INCONNUE, "LIBELLE_RPG_ERROR"), null); //$NON-NLS-1$
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.eq(new Tracabilite()), EasyMock.eq("clientOp2"), EasyMock.eq("noCompte2"))).andReturn(rpgReturn2); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL610_IdentifierPfiParSnOnt identifierPfiParSnOnt = new PE0341_BL610_IdentifierPfiParSnOntBuilder()//
        .tracabilite(new Tracabilite()) //
        .notificationReseau(notificationReseau) //
        .nombreCompensation(2) //
        .numeroSerieOnt("234").build(); //$NON-NLS-1$

    // Execute activity
    List<PFI> response = identifierPfiParSnOnt.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_ONT_INCONNU, "numero de serie Ont non attribué"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, identifierPfiParSnOnt.getRetour());
    Assert.assertEquals(null, response);
  }

  /**
   * Test when RPGProxy returns NOK - with the diagnostic DONNEE_INCONNUE (1st iteration) AND ACCES_NON_AUTORISE (2nd
   * iteration)
   *
   * Returns NOK CAT1 ACCES_NON_AUTORISE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL610_IdentifierPfiParSnOnt_KO_006_Test() throws Exception
  {
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$

    IndexRecherchePfi indexRecherchePfi_1 = new IndexRecherchePfi("clientOp1", "noCompte1"); //$NON-NLS-1$ //$NON-NLS-2$
    IndexRecherchePfi indexRecherchePfi_2 = new IndexRecherchePfi("clientOp2", "noCompte2"); //$NON-NLS-1$ //$NON-NLS-2$
    List<IndexRecherchePfi> listRetourAir = new ArrayList<>();
    listRetourAir.add(indexRecherchePfi_1);
    listRetourAir.add(indexRecherchePfi_2);

    //Mocks AIR
    ConnectorResponse<Retour, List<IndexRecherchePfi>> airReturn = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listRetourAir);
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxyMock);
    EasyMock.expect(_airProxyMock.indexRechercherPfiLireTousParCleRecherche(EasyMock.eq(new Tracabilite()), EasyMock.eq("SN_ONT"), EasyMock.eq("234"))).andReturn(airReturn); //$NON-NLS-1$//$NON-NLS-2$

    //Mocks RPG 1st iteration
    ConnectorResponse<Retour, PFI> rpgReturn1 = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT3, //
        IMegConsts.DONNEE_INCONNUE, "LIBELLE_RPG_ERROR"), null); //$NON-NLS-1$
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.eq(new Tracabilite()), EasyMock.eq("clientOp1"), EasyMock.eq("noCompte1"))).andReturn(rpgReturn1); //$NON-NLS-1$//$NON-NLS-2$

    //Mocks RPG 2nd iteration
    ConnectorResponse<Retour, PFI> rpgReturn2 = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT1, //
        IMegConsts.ACCES_NON_AUTORISE, "LIBELLE_RPG_ERROR"), null); //$NON-NLS-1$
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.eq(new Tracabilite()), EasyMock.eq("clientOp2"), EasyMock.eq("noCompte2"))).andReturn(rpgReturn2); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL610_IdentifierPfiParSnOnt identifierPfiParSnOnt = new PE0341_BL610_IdentifierPfiParSnOntBuilder()//
        .tracabilite(new Tracabilite()) //
        .notificationReseau(notificationReseau) //
        .nombreCompensation(2) //
        .numeroSerieOnt("234").build(); //$NON-NLS-1$

    // Execute activity
    List<PFI> response = identifierPfiParSnOnt.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ACCES_NON_AUTORISE, "LIBELLE_RPG_ERROR"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, identifierPfiParSnOnt.getRetour());
    Assert.assertEquals(null, response);
  }

  /**
   * Test when RPGProxy returns OK - with a list with 2 PFI's both have one valid equipmentDeclare
   *
   * Returns NOK CAT4 DONNE_INVALIDE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL610_IdentifierPfiParSnOnt_KO_007_Test() throws Exception
  {
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$

    IndexRecherchePfi indexRecherchePfi_1 = new IndexRecherchePfi("clientOp1", "noCompte1"); //$NON-NLS-1$ //$NON-NLS-2$
    IndexRecherchePfi indexRecherchePfi_2 = new IndexRecherchePfi("clientOp2", "noCompte2"); //$NON-NLS-1$ //$NON-NLS-2$
    List<IndexRecherchePfi> listRetourAir = new ArrayList<>();
    listRetourAir.add(indexRecherchePfi_1);
    listRetourAir.add(indexRecherchePfi_2);

    //Mocks AIR
    ConnectorResponse<Retour, List<IndexRecherchePfi>> airReturn = new ConnectorResponse<Retour, List<IndexRecherchePfi>>(RetourFactoryForTU.createOkRetour(), listRetourAir);
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxyMock);
    EasyMock.expect(_airProxyMock.indexRechercherPfiLireTousParCleRecherche(EasyMock.eq(new Tracabilite()), EasyMock.eq("SN_ONT"), EasyMock.eq("234"))).andReturn(airReturn); //$NON-NLS-1$//$NON-NLS-2$

    //Mocks RPG 1st iteration
    PFI pfi_1 = new PFI();
    pfi_1.setClientOperateur("clientOp1"); //$NON-NLS-1$
    pfi_1.setNoCompte("noCompte1"); //$NON-NLS-1$
    EquipementDeclare equipementDeclare_1 = new EquipementDeclare("", "234", "BRANCHEMENT_OPTIQUE", Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<EquipementDeclare> equipementDeclaresList_1 = new ArrayList<>();
    equipementDeclaresList_1.add(equipementDeclare_1);
    pfi_1.setEquipementDeclare(equipementDeclaresList_1);

    ConnectorResponse<Retour, PFI> rpgReturn1 = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi_1);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.eq(new Tracabilite()), EasyMock.eq("clientOp1"), EasyMock.eq("noCompte1"))).andReturn(rpgReturn1); //$NON-NLS-1$//$NON-NLS-2$

    //Mocks RPG 2nd iteration
    PFI pfi_2 = new PFI();
    pfi_2.setClientOperateur("clientOp2"); //$NON-NLS-1$
    pfi_2.setNoCompte("noCompte2"); //$NON-NLS-1$
    EquipementDeclare equipementDeclare_2 = new EquipementDeclare("", "234", "MODEM_BRANCHEMENT_OPTIQUE", Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<EquipementDeclare> equipementDeclaresList_2 = new ArrayList<>();
    equipementDeclaresList_2.add(equipementDeclare_2);
    pfi_2.setEquipementDeclare(equipementDeclaresList_2);

    ConnectorResponse<Retour, PFI> rpgReturn2 = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi_2);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.eq(new Tracabilite()), EasyMock.eq("clientOp2"), EasyMock.eq("noCompte2"))).andReturn(rpgReturn2); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL610_IdentifierPfiParSnOnt identifierPfiParSnOnt = new PE0341_BL610_IdentifierPfiParSnOntBuilder()//
        .tracabilite(new Tracabilite()) //
        .notificationReseau(notificationReseau) //
        .nombreCompensation(2) //
        .numeroSerieOnt("234").build(); //$NON-NLS-1$

    // Execute activity
    List<PFI> response = identifierPfiParSnOnt.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, "numero de serie Ont attribué a Plusieurs Pfi"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, identifierPfiParSnOnt.getRetour());
    Assert.assertEquals(null, response);
  }

  /**
   * Test when RPGProxy returns OK - with a list with 2 PFI's one have a List of equipementDeclare both have an empty
   * list.
   *
   * Returns OK
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL610_IdentifierPfiParSnOnt_KO_008_Test() throws Exception
  {
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$

    IndexRecherchePfi indexRecherchePfi_1 = new IndexRecherchePfi("clientOp1", "noCompte1"); //$NON-NLS-1$ //$NON-NLS-2$
    IndexRecherchePfi indexRecherchePfi_2 = new IndexRecherchePfi("clientOp2", "noCompte2"); //$NON-NLS-1$ //$NON-NLS-2$
    List<IndexRecherchePfi> listRetourAir = new ArrayList<>();
    listRetourAir.add(indexRecherchePfi_1);
    listRetourAir.add(indexRecherchePfi_2);

    //Mocks AIR
    ConnectorResponse<Retour, List<IndexRecherchePfi>> airReturn = new ConnectorResponse<Retour, List<IndexRecherchePfi>>(RetourFactoryForTU.createOkRetour(), listRetourAir);
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxyMock);
    EasyMock.expect(_airProxyMock.indexRechercherPfiLireTousParCleRecherche(EasyMock.eq(new Tracabilite()), EasyMock.eq("SN_ONT"), EasyMock.eq("234"))).andReturn(airReturn); //$NON-NLS-1$//$NON-NLS-2$

    //Mocks RPG 1st iteration
    PFI pfi_1 = new PFI();
    pfi_1.setClientOperateur("clientOp1"); //$NON-NLS-1$
    pfi_1.setNoCompte("noCompte1"); //$NON-NLS-1$
    pfi_1.setEquipementDeclare(new ArrayList<>());

    ConnectorResponse<Retour, PFI> rpgReturn1 = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi_1);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.eq(new Tracabilite()), EasyMock.eq("clientOp1"), EasyMock.eq("noCompte1"))).andReturn(rpgReturn1); //$NON-NLS-1$//$NON-NLS-2$

    //Mocks RPG 2nd iteration
    PFI pfi_2 = new PFI();
    pfi_2.setClientOperateur("clientOp2"); //$NON-NLS-1$
    pfi_2.setNoCompte("noCompte2"); //$NON-NLS-1$
    pfi_2.setEquipementDeclare(new ArrayList<>());

    ConnectorResponse<Retour, PFI> rpgReturn2 = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi_2);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.eq(new Tracabilite()), EasyMock.eq("clientOp2"), EasyMock.eq("noCompte2"))).andReturn(rpgReturn2); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL610_IdentifierPfiParSnOnt identifierPfiParSnOnt = new PE0341_BL610_IdentifierPfiParSnOntBuilder()//
        .tracabilite(new Tracabilite()) //
        .notificationReseau(notificationReseau) //
        .nombreCompensation(2) //
        .numeroSerieOnt("234").build(); //$NON-NLS-1$

    // Execute activity
    List<PFI> response = identifierPfiParSnOnt.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.SN_ONT_INCONNU, "numero de serie Ont non attribué"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, identifierPfiParSnOnt.getRetour());
    Assert.assertEquals(null, response);
  }

  /**
   * Test when RPGProxy returns OK - with a list with 2 PFI's both have equipmentDeclares. Only one of those is valid
   *
   * Returns OK
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0340_BL610_IdentifierPfiParSnOnt_OK_009_Test() throws Exception
  {
    NotificationReseauONTInconnuJSON notificationReseau = new NotificationReseauONTInconnuJSON();
    notificationReseau.setSlid("slid"); //$NON-NLS-1$

    IndexRecherchePfi indexRecherchePfi_1 = new IndexRecherchePfi("clientOp1", "noCompte1"); //$NON-NLS-1$ //$NON-NLS-2$
    IndexRecherchePfi indexRecherchePfi_2 = new IndexRecherchePfi("clientOp2", "noCompte2"); //$NON-NLS-1$ //$NON-NLS-2$
    List<IndexRecherchePfi> listRetourAir = new ArrayList<>();
    listRetourAir.add(indexRecherchePfi_1);
    listRetourAir.add(indexRecherchePfi_2);

    //Mocks AIR
    ConnectorResponse<Retour, List<IndexRecherchePfi>> airReturn = new ConnectorResponse<Retour, List<IndexRecherchePfi>>(RetourFactoryForTU.createOkRetour(), listRetourAir);
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxyMock);
    EasyMock.expect(_airProxyMock.indexRechercherPfiLireTousParCleRecherche(EasyMock.eq(new Tracabilite()), EasyMock.eq("SN_ONT"), EasyMock.eq("234"))).andReturn(airReturn); //$NON-NLS-1$//$NON-NLS-2$

    //Mocks RPG 1st iteration
    PFI pfi_1 = new PFI();
    pfi_1.setClientOperateur("clientOp1"); //$NON-NLS-1$
    pfi_1.setNoCompte("noCompte1"); //$NON-NLS-1$

    EquipementDeclare equipementDeclare_1 = new EquipementDeclare("", "234", "NOT_BRANCHEMENT_OPTIQUE", Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<EquipementDeclare> equipementDeclaresList_1 = new ArrayList<>();
    equipementDeclaresList_1.add(equipementDeclare_1);

    EquipementDeclare equipementDeclare_3 = new EquipementDeclare("", "234", "BRANCHEMENT_OPTIQUE", Statut.RESILIE, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    equipementDeclaresList_1.add(equipementDeclare_3);
    pfi_1.setEquipementDeclare(equipementDeclaresList_1);

    ConnectorResponse<Retour, PFI> rpgReturn1 = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi_1);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.eq(new Tracabilite()), EasyMock.eq("clientOp1"), EasyMock.eq("noCompte1"))).andReturn(rpgReturn1); //$NON-NLS-1$//$NON-NLS-2$

    //Mocks RPG 2nd iteration
    PFI pfi_2 = new PFI();
    pfi_2.setClientOperateur("clientOp2"); //$NON-NLS-1$
    pfi_2.setNoCompte("noCompte2"); //$NON-NLS-1$
    EquipementDeclare equipementDeclare_2 = new EquipementDeclare("", "234", "MODEM_BRANCHEMENT_OPTIQUE", Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<EquipementDeclare> equipementDeclaresList_2 = new ArrayList<>();
    equipementDeclaresList_2.add(equipementDeclare_2);

    EquipementDeclare equipementDeclare_4 = new EquipementDeclare("", "234455", "BRANCHEMENT_OPTIQUE", Statut.RESILIE, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    equipementDeclaresList_2.add(equipementDeclare_4);

    pfi_2.setEquipementDeclare(equipementDeclaresList_2);

    ConnectorResponse<Retour, PFI> rpgReturn2 = new ConnectorResponse<Retour, PFI>(RetourFactoryForTU.createOkRetour(), pfi_2);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxyMock);
    EasyMock.expect(_rpgProxyMock.pfiLireUn(EasyMock.eq(new Tracabilite()), EasyMock.eq("clientOp2"), EasyMock.eq("noCompte2"))).andReturn(rpgReturn2); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL610_IdentifierPfiParSnOnt identifierPfiParSnOnt = new PE0341_BL610_IdentifierPfiParSnOntBuilder()//
        .tracabilite(new Tracabilite()) //
        .notificationReseau(notificationReseau) //
        .nombreCompensation(2) //
        .numeroSerieOnt("234").build(); //$NON-NLS-1$

    // Execute activity
    List<PFI> response = identifierPfiParSnOnt.execute(_activityCallerMock);

    // Expected
    PFI expected_pfi = new PFI();
    expected_pfi.setClientOperateur("clientOp2"); //$NON-NLS-1$
    expected_pfi.setNoCompte("noCompte2"); //$NON-NLS-1$
    EquipementDeclare expected_equipementDeclare = new EquipementDeclare("", "234", "MODEM_BRANCHEMENT_OPTIQUE", Statut.ACTIF, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<EquipementDeclare> expected_equipementDeclaresList = new ArrayList<>();
    expected_equipementDeclaresList.add(expected_equipementDeclare);

    EquipementDeclare expected_equipementDeclare_2 = new EquipementDeclare("", "234455", "BRANCHEMENT_OPTIQUE", Statut.RESILIE, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    expected_equipementDeclaresList.add(expected_equipementDeclare_2);

    expected_pfi.setEquipementDeclare(expected_equipementDeclaresList);

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), identifierPfiParSnOnt.getRetour());
    Assert.assertEquals(expected_pfi, response.get(0));
  }
}
