/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import java.io.IOException;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI096_LireNrmInfosParIdRacco;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI096_LireNrmInfosParIdRacco.OSSFAI_SI096_LireNrmInfosParIdRaccoBuilder;
import com.bytel.spirit.common.connectors.nrm.structs.NRMInfosParIdRacco;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL640_ObtenirResssourceOntIdParIdRacco.PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.RessourceOntId;

/**
 *
 * @author JCHEVRON
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ OSSFAI_SI096_LireNrmInfosParIdRacco.class, OSSFAI_SI096_LireNrmInfosParIdRaccoBuilder.class, PE0341_BL640_ObtenirResssourceOntIdParIdRacco.class })
public class PE0341_BL640_ObtenirResssourceOntIdParIdRaccoTest
{
  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  private IActivityCaller _activityCallerMock;

  /**
   * Mock de {@link OSSFAI_SI096_LireNrmInfosParIdRacco}
   */
  @MockStrict
  private OSSFAI_SI096_LireNrmInfosParIdRacco _si096Mock;

  /**
   * Mock de {@link OSSFAI_SI096_LireNrmInfosParIdRaccoBuilder}
   */
  @MockStrict
  private OSSFAI_SI096_LireNrmInfosParIdRaccoBuilder _si096BuilderMock;

  /**
   * Test when parameter tracabilite of PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL640_ObtenirResssourceOntIdParIdRacco_KO_001_Test() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_tracabilite'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL640_ObtenirResssourceOntIdParIdRacco obtenirResssourceOntIdParIdRacco = new PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder()//
        .tracabilite(null) //
        .idRaccordement("12")// //$NON-NLS-1$
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdRacco.getRetour());
  }

  /**
   * Test when parameter idRaccordement of PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL640_ObtenirResssourceOntIdParIdRacco_KO_002_Test() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_idRaccordement'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL640_ObtenirResssourceOntIdParIdRacco obtenirResssourceOntIdParIdRacco = new PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder()//
        .tracabilite(new Tracabilite()) //
        .idRaccordement(null)// //$NON-NLS-1$
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdRacco.getRetour());
  }

  /**
   * Test when OOSFAI_SI096 returns NOK.
   *
   * Returns NOK CAT3 DONNE_INVALIDE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL640_ObtenirResssourceOntIdParIdRacco_KO_003_Test() throws Exception
  {
    //Mocks
    PowerMock.expectNew(OSSFAI_SI096_LireNrmInfosParIdRaccoBuilder.class).andReturn(_si096BuilderMock);
    EasyMock.expect(_si096BuilderMock.tracabilite(new Tracabilite())).andReturn(_si096BuilderMock);
    EasyMock.expect(_si096BuilderMock.idRessourceRaccordement("12")).andReturn(_si096BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_si096BuilderMock.build()).andReturn(_si096Mock);
    EasyMock.expect(_si096Mock.execute(_activityCallerMock)).andReturn(null);
    EasyMock.expect(_si096Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL640_ObtenirResssourceOntIdParIdRacco obtenirResssourceOntIdParIdRacco = new PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder()//
        .tracabilite(new Tracabilite()) //
        .idRaccordement("12")// //$NON-NLS-1$
        .build();

    // Execute activity
    obtenirResssourceOntIdParIdRacco.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "LIBELLE"); //$NON-NLS-1$

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdRacco.getRetour());

  }

  /**
   * Test when OOSFAI_SI096 returns OK.
   *
   * Returns OK
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL640_ObtenirResssourceOntIdParIdRacco_OK_001_Test() throws Exception
  {
    NRMInfosParIdRacco nrmInfosParIdRacco = new NRMInfosParIdRacco();
    nrmInfosParIdRacco.setCarte(1);
    nrmInfosParIdRacco.setOntId(43);
    nrmInfosParIdRacco.setNomOlt("nomOlt"); //$NON-NLS-1$
    nrmInfosParIdRacco.setPort(34);

    //Mocks
    PowerMock.expectNew(OSSFAI_SI096_LireNrmInfosParIdRaccoBuilder.class).andReturn(_si096BuilderMock);
    EasyMock.expect(_si096BuilderMock.tracabilite(new Tracabilite())).andReturn(_si096BuilderMock);
    EasyMock.expect(_si096BuilderMock.idRessourceRaccordement("12")).andReturn(_si096BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_si096BuilderMock.build()).andReturn(_si096Mock);
    EasyMock.expect(_si096Mock.execute(_activityCallerMock)).andReturn(nrmInfosParIdRacco);
    EasyMock.expect(_si096Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    // Build activity
    PE0341_BL640_ObtenirResssourceOntIdParIdRacco obtenirResssourceOntIdParIdRacco = new PE0341_BL640_ObtenirResssourceOntIdParIdRaccoBuilder()//
        .tracabilite(new Tracabilite()) //
        .idRaccordement("12")// //$NON-NLS-1$
        .build();

    // Execute activity
    RessourceOntId response = obtenirResssourceOntIdParIdRacco.execute(_activityCallerMock);

    // Expected
    Retour expectedRetour = RetourFactory.createOkRetour();

    // Asserts
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, obtenirResssourceOntIdParIdRacco.getRetour());
    Assert.assertEquals("nomOlt", response.getNomOlt()); //$NON-NLS-1$
    Assert.assertEquals(new Integer(43), response.getOntId());
    Assert.assertEquals(new Integer(1), response.getPositionCartePon());
    Assert.assertEquals(new Integer(34), response.getPositionPortPon());
    Assert.assertEquals("12", response.getIdRessourceLie()); //$NON-NLS-1$
  }

  /**
   * Tests initialisation.
   *
   * @throws IOException
   *           on error
   */
  @Before
  public void beforeTest() throws IOException
  {

    // Reset mocks
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(OSSFAI_SI096_LireNrmInfosParIdRacco.class);
    PowerMock.mockStaticStrict(OSSFAI_SI096_LireNrmInfosParIdRaccoBuilder.class);
  }
}
