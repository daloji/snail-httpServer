/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.tesla.activities.PE0341;

import java.io.IOException;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.services.process.IActivityCaller;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauONTInconnuJSON;
import com.bytel.spirit.common.shared.functional.types.json.notification.NotificationReseauRecommandationTvJSON;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL500_TraiterNotificationReseau.PE0341_BL500_TraiterNotificationReseauBuilder;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL600_TraiterNotificationOntInconnu.PE0341_BL600_TraiterNotificationOntInconnuBuilder;
import com.bytel.spirit.tesla.activities.PE0341.PE0341_BL700_TraiterNotificationRecommandationTv.PE0341_BL700_TraiterNotificationRecommandationTvBuilder;
import com.bytel.spirit.tesla.activities.PE0341.structs.TraiterNotificationReturn;
import com.bytel.spirit.tesla.processes.PE0341.config.ConfigurationAChaudPE;

/**
 *
 * @author icarrao
 * @version ($Revision$ $Date$)
 */
/**
 *
 * @author icarrao
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0341_BL500_TraiterNotificationReseau.class, NotificationReseauRecommandationTvJSON.class, REXProxy.class, PE0341_BL600_TraiterNotificationOntInconnu.class, PE0341_BL700_TraiterNotificationRecommandationTv.class, PE0341_BL600_TraiterNotificationOntInconnuBuilder.class, PE0341_BL700_TraiterNotificationRecommandationTvBuilder.class })
public class PE0341_BL500_TraiterNotificationReseauTest
{

  /**
   * Mock de {@link IActivityCaller}
   */
  @MockNice
  private IActivityCaller _activityCallerMock;

  /**
   * Mock de {@link REXProxy}
   */
  @MockStrict
  private REXProxy _rexProxyMock;

  /**
   * Mock de {@link PE0341_BL600_TraiterNotificationOntInconnu}
   */
  @MockStrict
  private PE0341_BL600_TraiterNotificationOntInconnu _bl600Mock;

  /**
   * Mock de {@link PE0341_BL700_TraiterNotificationRecommandationTv}
   */
  @MockStrict
  private PE0341_BL700_TraiterNotificationRecommandationTv _bl700Mock;

  /**
   * Mock de {@link PE0341_BL700_TraiterNotificationRecommandationTvBuilder}
   */
  @MockStrict
  private PE0341_BL700_TraiterNotificationRecommandationTvBuilder _bl700BuilderMock;

  /**
   * Mock de {@link PE0341_BL600_TraiterNotificationOntInconnuBuilder}
   */
  @MockStrict
  private PE0341_BL600_TraiterNotificationOntInconnuBuilder _bl600BuilderMock;

  /**
   * Mock de {@link NotificationReseauRecommandationTvJSON}
   */
  @MockStrict
  private NotificationReseauRecommandationTvJSON _notificationReseauMock;

  /** Configuration. */
  @MockStrict
  private ConfigurationAChaudPE _config;

  /**
   * Tests initialisation.
   *
   * @throws IOException
   *           on error
   */
  @Before
  public void beforeTest() throws IOException
  {
    // Reset mocks
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(REXProxy.class);
    PowerMock.mockStaticStrict(PE0341_BL600_TraiterNotificationOntInconnu.class);
    PowerMock.mockStaticStrict(PE0341_BL700_TraiterNotificationRecommandationTv.class);
    PowerMock.mockStaticStrict(PE0341_BL600_TraiterNotificationOntInconnuBuilder.class);
    PowerMock.mockStaticStrict(PE0341_BL700_TraiterNotificationRecommandationTvBuilder.class);
    PowerMock.mockStaticStrict(NotificationReseauRecommandationTvJSON.class);
    PowerMock.mockStaticStrict(ConfigurationAChaudPE.class);
  }

  /**
   * Test when parameter tracabilite of PE0341_BL500_TraiterNotificationReseauBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL500_TraiterNotificationReseau_KO_001_Test() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_tracabilite', '_configurationAChaudPE'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL500_TraiterNotificationReseau bl500 = new PE0341_BL500_TraiterNotificationReseauBuilder()//
        .tracabilite(null) //
        .nombreCompensation(1)//
        .notificationReseau(new NotificationReseauRecommandationTvJSON())//
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, bl500.getRetour());
  }

  /**
   * Test when parameter nombreCompensation of PE0341_BL500_TraiterNotificationReseauBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL500_TraiterNotificationReseau_KO_002_Test() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_nombreCompensation', '_configurationAChaudPE'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL500_TraiterNotificationReseau bl500 = new PE0341_BL500_TraiterNotificationReseauBuilder()//
        .tracabilite(new Tracabilite()) //
        .nombreCompensation(null)//
        .notificationReseau(new NotificationReseauRecommandationTvJSON())//
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, bl500.getRetour());
  }

  /**
   * Test when parameter notificationReseau of PE0341_BL500_TraiterNotificationReseauBuilder is null.
   *
   * Returns NOK CAT3 DONNE_INVALIDE "Activity parameter not filled."
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL500_TraiterNotificationReseau_KO_003_Test() throws Exception
  {
    // Expected
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled: '_notificationReseau', '_configurationAChaudPE'"); //$NON-NLS-1$

    // Build activity
    PE0341_BL500_TraiterNotificationReseau bl500 = new PE0341_BL500_TraiterNotificationReseauBuilder()//
        .tracabilite(new Tracabilite()) //
        .nombreCompensation(1)//
        .notificationReseau(null)//
        .build();

    // Asserts
    Assert.assertEquals(expectedRetour, bl500.getRetour());
  }

  /**
   * Test when typeNotificationReseau = "ABC".
   *
   * BL600 returns KO
   *
   *
   * Returns NOK CAT-4 CONFIGURATION_INVALIDE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL500_TraiterNotificationReseau_KO_004_Test() throws Exception
  {
    //calls BL600
    TraiterNotificationReturn bl600Return = new TraiterNotificationReturn(true, "45", 0); //$NON-NLS-1$
    bl600Return.setNombreCompensation(6);

    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();
    notificationReseauONTInconnuJSON.setIdNotificationReseau("34"); //$NON-NLS-1$
    notificationReseauONTInconnuJSON.setTypeNotificationReseau("ABC"); //$NON-NLS-1$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL500_TraiterNotificationReseau bl500 = new PE0341_BL500_TraiterNotificationReseauBuilder()//
        .tracabilite(new Tracabilite()) //
        .nombreCompensation(1)//
        .notificationReseau(notificationReseauONTInconnuJSON)//
        .configurationAChaudPE(_config)//
        .build();

    TraiterNotificationReturn response = bl500.execute(_activityCallerMock);

    PowerMock.verifyAll();

    // Asserts
    Assert.assertEquals(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "Le type d'évènement ABC non géré"), bl500.getRetour()); //$NON-NLS-1$
    Assert.assertNotNull(response);
  }

  /**
   * Test when typeNotificationReseau = "ONT_INCONNU".
   *
   * BL600 returns KO
   *
   *
   * Returns NOK CAT-1 ACCES_NON_AUTORISE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL500_TraiterNotificationReseau_KO_005_Test() throws Exception
  {
    //calls BL600
    TraiterNotificationReturn bl600Return = new TraiterNotificationReturn(true, "45", 0); //$NON-NLS-1$
    bl600Return.setNombreCompensation(6);

    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();
    notificationReseauONTInconnuJSON.setIdNotificationReseau("34"); //$NON-NLS-1$
    notificationReseauONTInconnuJSON.setTypeNotificationReseau("ONT_INCONNU"); //$NON-NLS-1$

    PowerMock.expectNew(PE0341_BL600_TraiterNotificationOntInconnuBuilder.class).andReturn(_bl600BuilderMock);
    EasyMock.expect(_bl600BuilderMock.tracabilite(new Tracabilite())).andReturn(_bl600BuilderMock);
    EasyMock.expect(_bl600BuilderMock.notificationReseauONTInconnuJSON(notificationReseauONTInconnuJSON)).andReturn(_bl600BuilderMock);
    EasyMock.expect(_bl600BuilderMock.nombreCompensation(1)).andReturn(_bl600BuilderMock);
    EasyMock.expect(_bl600BuilderMock.configurationAChaudPE(_config)).andReturn(_bl600BuilderMock);
    EasyMock.expect(_bl600BuilderMock.build()).andReturn(_bl600Mock);
    EasyMock.expect(_bl600Mock.execute(_activityCallerMock)).andReturn(bl600Return);
    EasyMock.expect(_bl600Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ACCES_NON_AUTORISE, "LIBELLE_BL600_ERROR")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL500_TraiterNotificationReseau bl500 = new PE0341_BL500_TraiterNotificationReseauBuilder()//
        .tracabilite(new Tracabilite()) //
        .nombreCompensation(1)//
        .notificationReseau(notificationReseauONTInconnuJSON)//
        .configurationAChaudPE(_config)//
        .build();

    TraiterNotificationReturn response = bl500.execute(_activityCallerMock);

    PowerMock.verifyAll();

    //Expected
    TraiterNotificationReturn expected_TraiterNotification_Return = new TraiterNotificationReturn(true, "45", 0); //$NON-NLS-1$
    expected_TraiterNotification_Return.setNombreCompensation(6);

    // Asserts
    Assert.assertEquals(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ACCES_NON_AUTORISE, "LIBELLE_BL600_ERROR"), bl500.getRetour()); //$NON-NLS-1$
    Assert.assertEquals(expected_TraiterNotification_Return, response);
  }

  /**
   * Test when typeNotificationReseau = "RECOMMANDATION_TV".
   *
   * BL700 returns KO
   *
   * Returns NOK CAT1 ACCES_NON_AUTORISE
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL500_TraiterNotificationReseau_KO_006_Test() throws Exception
  {
    //calls BL700
    TraiterNotificationReturn bl700Return = new TraiterNotificationReturn(true, null, 0);

    NotificationReseauRecommandationTvJSON notificationReseauRecommandationTvJSON = new NotificationReseauRecommandationTvJSON();
    notificationReseauRecommandationTvJSON.setIdNotificationReseau("34"); //$NON-NLS-1$
    notificationReseauRecommandationTvJSON.setTypeNotificationReseau("RECOMMANDATION_TV"); //$NON-NLS-1$

    PowerMock.expectNew(PE0341_BL700_TraiterNotificationRecommandationTvBuilder.class).andReturn(_bl700BuilderMock);
    EasyMock.expect(_bl700BuilderMock.tracabilite(new Tracabilite())).andReturn(_bl700BuilderMock);
    EasyMock.expect(_bl700BuilderMock.notificationReseauRecommandationTvJSON(notificationReseauRecommandationTvJSON)).andReturn(_bl700BuilderMock);
    EasyMock.expect(_bl700BuilderMock.nombreCompensation(1)).andReturn(_bl700BuilderMock);
    EasyMock.expect(_bl700BuilderMock.configurationAchaudPE(_config)).andReturn(_bl700BuilderMock);
    EasyMock.expect(_bl700BuilderMock.build()).andReturn(_bl700Mock);
    EasyMock.expect(_bl700Mock.execute(_activityCallerMock)).andReturn(bl700Return);
    EasyMock.expect(_bl700Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ACCES_NON_AUTORISE, "LIBELLE_BL700_ERROR")); //$NON-NLS-1$

    PowerMock.replayAll();

    // Build activity
    PE0341_BL500_TraiterNotificationReseau bl500 = new PE0341_BL500_TraiterNotificationReseauBuilder()//
        .tracabilite(new Tracabilite()) //
        .nombreCompensation(1)//
        .notificationReseau(notificationReseauRecommandationTvJSON)//
        .configurationAChaudPE(_config)//
        .build();

    TraiterNotificationReturn response = bl500.execute(_activityCallerMock);

    PowerMock.verifyAll();
    // Asserts
    Assert.assertEquals(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ACCES_NON_AUTORISE, "LIBELLE_BL700_ERROR"), bl500.getRetour()); //$NON-NLS-1$
    Assert.assertEquals(new TraiterNotificationReturn(true, null, 0), response);
  }

  /**
   * Test when typeNotificationReseau = "ONT_INCONNU".
   *
   * BL600 returns OK
   *
   *
   * Returns OK
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL500_TraiterNotificationReseau_OK_007_Test() throws Exception
  {

    //calls BL600
    TraiterNotificationReturn bl600Return = new TraiterNotificationReturn(false, "23", 3);//$NON-NLS-1$
    bl600Return.setNombreCompensation(6);

    NotificationReseauONTInconnuJSON notificationReseauONTInconnuJSON = new NotificationReseauONTInconnuJSON();
    notificationReseauONTInconnuJSON.setIdNotificationReseau("34"); //$NON-NLS-1$
    notificationReseauONTInconnuJSON.setTypeNotificationReseau("ONT_INCONNU"); //$NON-NLS-1$

    PowerMock.expectNew(PE0341_BL600_TraiterNotificationOntInconnuBuilder.class).andReturn(_bl600BuilderMock);
    EasyMock.expect(_bl600BuilderMock.tracabilite(new Tracabilite())).andReturn(_bl600BuilderMock);
    EasyMock.expect(_bl600BuilderMock.notificationReseauONTInconnuJSON(notificationReseauONTInconnuJSON)).andReturn(_bl600BuilderMock);
    EasyMock.expect(_bl600BuilderMock.nombreCompensation(1)).andReturn(_bl600BuilderMock);
    EasyMock.expect(_bl600BuilderMock.configurationAChaudPE(_config)).andReturn(_bl600BuilderMock);
    EasyMock.expect(_bl600BuilderMock.build()).andReturn(_bl600Mock);
    EasyMock.expect(_bl600Mock.execute(_activityCallerMock)).andReturn(bl600Return);
    EasyMock.expect(_bl600Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    // Build activity
    PE0341_BL500_TraiterNotificationReseau bl500 = new PE0341_BL500_TraiterNotificationReseauBuilder()//
        .tracabilite(new Tracabilite()) //
        .nombreCompensation(1)//
        .notificationReseau(notificationReseauONTInconnuJSON)//
        .configurationAChaudPE(_config)//
        .build();

    TraiterNotificationReturn response = bl500.execute(_activityCallerMock);

    //expected
    TraiterNotificationReturn expected_TraiterNotification_Return = new TraiterNotificationReturn(false, "23", 3); //$NON-NLS-1$
    expected_TraiterNotification_Return.setNombreCompensation(6);

    PowerMock.verifyAll();
    // Asserts
    Assert.assertEquals(RetourFactory.createOkRetour(), bl500.getRetour());
    Assert.assertEquals(expected_TraiterNotification_Return, response);
  }

  /**
   * Test when typeNotificationReseau = "RECOMMANDATION_TV".
   *
   * BL700 returns OK
   *
   * Returns OK
   *
   * @throws Exception
   *           Exception
   */
  @Test
  public void PE0341_BL500_TraiterNotificationReseau_OK_008_Test() throws Exception
  {

    //calls BL700
    TraiterNotificationReturn bl700Return = new TraiterNotificationReturn(false, "23", 3); //$NON-NLS-1$
    bl700Return.setNombreCompensation(5);

    NotificationReseauRecommandationTvJSON notificationReseauRecommandationTvJSON = new NotificationReseauRecommandationTvJSON();
    notificationReseauRecommandationTvJSON.setIdNotificationReseau("34"); //$NON-NLS-1$
    notificationReseauRecommandationTvJSON.setTypeNotificationReseau("RECOMMANDATION_TV"); //$NON-NLS-1$

    PowerMock.expectNew(PE0341_BL700_TraiterNotificationRecommandationTvBuilder.class).andReturn(_bl700BuilderMock);
    EasyMock.expect(_bl700BuilderMock.tracabilite(new Tracabilite())).andReturn(_bl700BuilderMock);
    EasyMock.expect(_bl700BuilderMock.notificationReseauRecommandationTvJSON(notificationReseauRecommandationTvJSON)).andReturn(_bl700BuilderMock);
    EasyMock.expect(_bl700BuilderMock.nombreCompensation(1)).andReturn(_bl700BuilderMock);
    EasyMock.expect(_bl700BuilderMock.configurationAchaudPE(_config)).andReturn(_bl700BuilderMock);
    EasyMock.expect(_bl700BuilderMock.build()).andReturn(_bl700Mock);
    EasyMock.expect(_bl700Mock.execute(_activityCallerMock)).andReturn(bl700Return);
    EasyMock.expect(_bl700Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    PowerMock.replayAll();

    // Build activity
    PE0341_BL500_TraiterNotificationReseau bl500 = new PE0341_BL500_TraiterNotificationReseauBuilder()//
        .tracabilite(new Tracabilite()) //
        .nombreCompensation(1)//
        .notificationReseau(notificationReseauRecommandationTvJSON)//
        .configurationAChaudPE(_config)//
        .build();

    TraiterNotificationReturn response = bl500.execute(_activityCallerMock);

    //expected
    TraiterNotificationReturn expected_TraiterNotification_Return = new TraiterNotificationReturn(false, "23", 3); //$NON-NLS-1$
    expected_TraiterNotification_Return.setNombreCompensation(5);

    PowerMock.verifyAll();
    // Asserts
    Assert.assertEquals(RetourFactoryForTU.createOkRetour(), bl500.getRetour());
    Assert.assertEquals(expected_TraiterNotification_Return, response);
  }

}
