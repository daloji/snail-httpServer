package com.bytel.spirit.prof.test;

import org.junit.runner.RunWith;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 *
 * @author jstrub
 * @version ($Revision: 23286 $ $Date: 2019-06-28 11:38:54 +0200 (ven. 28 juin 2019) $)
 */
@RunWith(Cucumber.class)
@CucumberOptions(
    // Strict
    strict = true,
    // Steps
    glue = { "com.consol.citrus.cucumber.step.designer.core", "com.bytel.ravel.step", "com.bytel.spirit.common.test.step" },
    // Plugins
    plugin = { "com.consol.citrus.cucumber.CitrusReporter" },
    // Features
    features = { "src/test/resources/features" })
@Configuration
@ComponentScan({ "com.bytel.ravel", "com.bytel.spirit.common.test" })
public class ProfTestConfig
{
  // Nothing to implement here
}
