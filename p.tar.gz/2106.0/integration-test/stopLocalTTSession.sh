docker ps -qa|xargs -r docker rm -f
