/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.test.step;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bytel.ravel.RavelTestException;
import com.bytel.ravel.config.RavelCassandraConfig;
import com.bytel.ravel.cql.CqlTestActionBuilder;
import com.bytel.ravel.step.helper.AbstractSteps;
import com.bytel.spirit.ford.test.cql.GererKPValidator;
import com.datastax.driver.core.Session;

import cucumber.api.java.en.Given;

/**
 *
 * @author rmohamed
 * @version ($Revision$ $Date$)
 */
public class ResDatabaseSteps extends AbstractSteps
{

  /** BASE_PATH */
  private static final String BASE_PATH = "RES-cql";

  /** Path for file templates : processus/$process-name/<b>files</b>/$templates. */
  private static final String RESULT_DIR = "result"; //$NON-NLS-1$

  /** Constant for method gererKP */
  private static final String METHODE_GERER_KP = "PP0435_GererKP";

  /** Cassandra session */
  @Autowired
  @Qualifier(RavelCassandraConfig.RAVEL_CASSANDRA_SESSION)
  private Session _session;

  /**
   * Default constructor
   */
  public ResDatabaseSteps()
  {
    super(BASE_PATH);
  }

  /**
   * Check that a GestionReferentiel has been created or exist in RES key-space.
   *
   * @param resultJson
   * @throws RavelTestException
   */
  @Given("^RES-DB has created GestionReferentiel that matches data with ([^\"]*)$")
  public void checkGestionReferentiel(String resultJson) throws RavelTestException
  {
    List<String> statements = Arrays.asList(GererKPValidator.CHECK_GESTION_AIGUILLAGE_GERER_BASCULE, //
        GererKPValidator.CHECK_GEOD_RESSOURCE_FTTH_DATA_TABLE_A, //
        GererKPValidator.CHECK_GEOD_RESSOURCE_FTTH_DATA_TABLE_B, //
        GererKPValidator.CHECK_GEOD_RESSOURCE_FTTH_DATA_TABLE_C //
    );

    getDesigner().action(new CqlTestActionBuilder(_session).statements(statements).validator(new GererKPValidator(templateResource(METHODE_GERER_KP, RESULT_DIR, resultJson))));
  }

}
