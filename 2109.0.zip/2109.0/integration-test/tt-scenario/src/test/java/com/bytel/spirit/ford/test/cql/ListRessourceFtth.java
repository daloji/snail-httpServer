/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.test.cql;

import java.io.Serializable;
import java.util.List;

import com.bytel.spirit.common.shared.saab.res.RessourceFtth;
import com.squareup.moshi.Json;

/**
 *
 * This class is used in {@link GererKPValidator} to serialize RessourceFtth in a List
 * 
 * @author rmohamed
 * @version ($Revision$ $Date$)
 */
public class ListRessourceFtth implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * referencePM
   */
  @Json(name = "listeRessourceFtth")
  private List<RessourceFtth> _listeRessourceFtth;

  /**
   * @return the listeRessourceFtth
   */
  public List<RessourceFtth> getListeRessourceFtth()
  {
    return _listeRessourceFtth;
  }

  /**
   * @param listeRessourceFtth_p
   *          the listeRessourceFtth to set
   */
  public void setListeRessourceFtth(List<RessourceFtth> listeRessourceFtth_p)
  {
    _listeRessourceFtth = listeRessourceFtth_p;
  }

}
