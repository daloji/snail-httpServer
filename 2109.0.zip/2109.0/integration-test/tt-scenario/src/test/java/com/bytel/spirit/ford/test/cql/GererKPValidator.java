/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.test.cql;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.cql.ICqlResultValidator;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.saab.res.RessourceFtth;
import com.consol.citrus.context.TestContext;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.TupleValue;

/**
 *
 * @author rmohamed
 * @version ($Revision$ $Date$)
 */
public class GererKPValidator implements ICqlResultValidator
{

  /** Select statement for geod_gestion_aiguillage table */
  public static final String CHECK_GESTION_AIGUILLAGE_GERER_BASCULE = "SELECT type_referentiel, id_etat_actif, id_etat_backup, id_etat_en_ecriture, date_creation, date_modification FROM res.geod_gestion_aiguillage WHERE type_referentiel = '${request.typeReferentiel}';"; //$NON-NLS-1$
  /** Select statement for geod_ressource_ftth_A table */
  public static final String CHECK_GEOD_RESSOURCE_FTTH_DATA_TABLE_A = "SELECT reference_pm, reference_pmt, date_ouverture_commerciale, etat_pm, nombre_ressource_disponible_pmt, nombre_ressource_pmt, autre_information_pm, type_emplacement_pm, type_ingenierie, type_zone, commentaire_pm, type_de_projection, coordonnee_x, coordonnee_y FROM res.geod_ressource_ftth_a;"; //$NON-NLS-1$
  /** Select statement for geod_ressource_ftth_C table */
  public static final String CHECK_GEOD_RESSOURCE_FTTH_DATA_TABLE_B = "SELECT reference_pm, reference_pmt, date_ouverture_commerciale, etat_pm, nombre_ressource_disponible_pmt, nombre_ressource_pmt, autre_information_pm, type_emplacement_pm, type_ingenierie, type_zone, commentaire_pm, type_de_projection, coordonnee_x, coordonnee_y FROM res.geod_ressource_ftth_b;"; //$NON-NLS-1$
  /** Select statement for geod_ressource_ftth_C table */
  public static final String CHECK_GEOD_RESSOURCE_FTTH_DATA_TABLE_C = "SELECT reference_pm, reference_pmt, date_ouverture_commerciale, etat_pm, nombre_ressource_disponible_pmt, nombre_ressource_pmt, autre_information_pm, type_emplacement_pm, type_ingenierie, type_zone, commentaire_pm, type_de_projection, coordonnee_x, coordonnee_y FROM res.geod_ressource_ftth_c;"; //$NON-NLS-1$
  /** Logger. */
  private static Logger log = LoggerFactory.getLogger(GererKPValidator.class);

  /** Json result resource. */
  private final Resource _jsonResultResource;

  /**
   * @param resource
   *          file that contains json results
   *
   */
  public GererKPValidator(Resource resource)
  {
    super();
    _jsonResultResource = resource;
  }

  @Override
  public boolean validate(Map<String, ResultSet> rs_p, TestContext context_p)
  {

    // get result from json file
    String jsonResponse = null;
    try
    {
      jsonResponse = new String(Files.readAllBytes(_jsonResultResource.getFile().toPath()), Charset.defaultCharset());
    }
    catch (IOException exception)
    {
      log.error("Unable to read the result json file {} : {}", _jsonResultResource.getFilename(), exception.getMessage()); //$NON-NLS-1$
      return false;
    }

    // deserialize json to RessourceFtth List
    ListRessourceFtth listRessourceFtth = null;
    try
    {
      listRessourceFtth = deserializeWithMoshi(jsonResponse, ListRessourceFtth.class);
    }
    catch (Exception exception)
    {
      log.error("Unable to deserialize json: {}", exception.getMessage()); //$NON-NLS-1$
      return false;
    }

    List<RessourceFtth> listRessourceFtthItem = new ArrayList<RessourceFtth>();
    if (listRessourceFtth != null)
    {
      listRessourceFtthItem.addAll(listRessourceFtth.getListeRessourceFtth());
    }

    ResultSet result = rs_p.get(CHECK_GESTION_AIGUILLAGE_GERER_BASCULE);
    List<Row> rows = result.all();

    // Only one record is expected in gestion_aiguillage table
    if (rows.size() != 1)
    {
      log.warn("Expected exactly one record but got {}.", result.all().size()); //$NON-NLS-1$
      return false;
    }
    Row r = rows.get(0);
    Assert.assertEquals("type_referentiel != " + context_p.getVariable("request.typeReferentiel"), r.getString("type_referentiel"), context_p.getVariable("request.typeReferentiel")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    // Get suffix of table geod_ressource_ftth_%c
    TupleValue tupleTableActif = r.getTupleValue("id_etat_actif"); //$NON-NLS-1$

    // Tuple(suffix, id_ref)
    Assert.assertNotNull(tupleTableActif.getString(0));
    String tableSuffix = tupleTableActif.getString(0);

    switch (tableSuffix.toUpperCase())
    {
      case "A": //$NON-NLS-1$
        result = rs_p.get(CHECK_GEOD_RESSOURCE_FTTH_DATA_TABLE_A);
        break;
      case "B": //$NON-NLS-1$
        result = rs_p.get(CHECK_GEOD_RESSOURCE_FTTH_DATA_TABLE_B);
        break;
      case "C": //$NON-NLS-1$
        result = rs_p.get(CHECK_GEOD_RESSOURCE_FTTH_DATA_TABLE_C);
        break;
    }

    rows = result.all();
    if (rows.size() != listRessourceFtthItem.size())
    {
      log.warn("Expected exactly {} records but got {}.", listRessourceFtthItem.size(), result.all().size()); //$NON-NLS-1$
      return false;
    }

    // Check that json results are found in records from database
    for (RessourceFtth ressourceFtth : listRessourceFtthItem)
    {
      boolean isPresent = false;
      for (Row row : rows)
      {
        if (ressourceFtth.getReferencePM().equals(row.getString("reference_pm")) //$NON-NLS-1$
            && (ressourceFtth.getDateOuvertureCommerciale().toEpochDay() == row.getDate("date_ouverture_commerciale").getDaysSinceEpoch()) //$NON-NLS-1$
            && ressourceFtth.getEtatPM().equals(row.getString("etat_pm")) //$NON-NLS-1$
            && (ressourceFtth.getNombreRessourceDisponiblePMT() == row.getInt("nombre_ressource_disponible_pmt")) //$NON-NLS-1$
            && (ressourceFtth.getNombreRessourcePMT() == row.getInt("nombre_ressource_pmt")) //$NON-NLS-1$
            && ressourceFtth.getTypeEmplacementPM().equals(row.getString("type_emplacement_pm")) //$NON-NLS-1$
            && ressourceFtth.getTypeIngenierie().equals(row.getString("type_ingenierie")) //$NON-NLS-1$
        )
        {
          isPresent = true;
          break;
        }
      }
      Assert.assertTrue("Result expected from json file is not found in database records : ReferencePM (in json file) " + ressourceFtth.getReferencePM(), isPresent); //$NON-NLS-1$
    }

    return true;
  }

  /**
   * Deserializes the string in jsonString parameter and returns an instance of the deserialized object.
   *
   * @param jsonString_p
   *          The string to deserialize
   * @param clazz_p
   *          The class type of the objet to deserialize to
   * @return The deserialized object
   * @throws RavelException
   *           If thrown by the Json builder
   */
  private <T> T deserializeWithMoshi(String jsonString_p, Class<T> clazz_p) throws RavelException
  {
    return RavelJsonTools.getInstance().fromJson(jsonString_p, clazz_p);
  }

}
