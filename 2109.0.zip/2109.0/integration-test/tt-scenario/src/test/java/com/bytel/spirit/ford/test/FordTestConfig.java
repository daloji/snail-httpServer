package com.bytel.spirit.ford.test;

import org.junit.runner.RunWith;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 *
 * @author jstrub
 * @version ($Revision: 30259 $ $Date: 2020-01-13 14:40:19 +0100 (lun. 13 janv. 2020) $)
 */
@RunWith(Cucumber.class)
@CucumberOptions(
    // Strict
    strict = true,
    // Steps
    glue = { "com.consol.citrus.cucumber.step.designer.core", "com.bytel.ravel.step", "com.bytel.spirit.common.test.step", "com.bytel.spirit.ford.test.step" },
    // Plugins
    plugin = { "com.consol.citrus.cucumber.CitrusReporter" },
    // Features
    features = { "src/test/resources/features/" })
@Configuration
@ComponentScan({ "com.bytel.ravel", "com.bytel.spirit.common.test" })
public class FordTestConfig
{
  // Nothing to implement here
}
