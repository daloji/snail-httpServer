delete from PROSTR.SVCTECACC where PK_SVCTECACC = 123;
insert into PROSTR.SVCTECACC (
    PK_SVCTECACC,
    PFI,
    DCPSVCTEC,
    IDTDERMOD
) values (
    123,
    'pfixxx',
    'ST_VMS_REPONDEUR',
    'ST_VMS_REPONDEUR'
);
delete from PROSTR.PARPNTACC where PK_PARPNTACC = 123;
insert into PROSTR.PARPNTACC (
    PK_PARPNTACC,
    PFI,
    IDTPNTACC,
    FK_TYPPNTACCGEN,
    FK_TYPPNTACCCOM,
    TCN,
    NOMPAR,
    VALPAR,
    IDTDERMOD,
    ACTDERMOD
) values (
    123,
    'pfixxx',
    'idtntacc',
    1,
    1,
    'tnc',
    'MSISDN',
    '33762112176',
    'idtdermod',
    'actdermod'
);