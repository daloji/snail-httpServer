/*******************************************************************************
* $Id: FrontendTester.java 6719 2019-02-11 11:03:32Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.ravel.frontend;

import com.bytel.ravel.embedded.jetty.JettyServer;

/**
 * @author jstrub
 * @version ($Revision: 6719 $ $Date: 2019-02-11 12:03:32 +0100 (lun. 11 févr. 2019) $)
 */
public final class FrontendTester
{
  /**
   * Main
   *
   * @param args
   * @throws Exception
   */
  @SuppressWarnings("nls")
  public static void main(String[] args) throws Exception
  {
    // Resources directory
    String confDir = "conf/";

    // System properties used by Spirit
    System.setProperty("configSpiritFrontendDir", confDir);
    System.setProperty("supervisionSpiritFrontendDir", "logs/");

    // Start the backend !
    JettyServer.main(new String[] { confDir + "frontJetty.xml", "start" });
  }

  /** Private constructor. */
  private FrontendTester()
  {
    // Nothing to do
  }
}
