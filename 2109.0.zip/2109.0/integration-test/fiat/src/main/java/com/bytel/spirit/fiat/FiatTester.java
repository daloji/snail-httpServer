package com.bytel.spirit.fiat;

import com.bytel.ravel.embedded.jetty.JettyServer;

/**
 * Class with a main method to launch a local ST.
 *
 * @author jstrub
 */
public final class FiatTester
{
  /**
   * Main method.
   *
   * @param args
   *          main args
   * @throws Exception
   *           on error
   */
  @SuppressWarnings("nls")
  public static void main(String[] args) throws Exception
  {
    // Resources directory
    String confDir = "conf/";

    // System properties used by Spirit
    System.setProperty("configSpiritBackendDir", confDir);
    System.setProperty("supervisionSpiritBackendDir", "logs/");

    // Start the backend !
    JettyServer.main(new String[] { confDir + "fiatJetty.xml", "start" });
  }

  /** Private constructor. */
  private FiatTester()
  {
    // Nothing to do
  }
}
