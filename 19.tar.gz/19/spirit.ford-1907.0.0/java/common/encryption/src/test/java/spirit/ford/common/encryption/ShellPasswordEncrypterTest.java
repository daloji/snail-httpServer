/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package spirit.ford.common.encryption;

import javax.crypto.SecretKey;

import org.junit.Assert;
import org.junit.Test;

import com.bytel.ravel.common.encryption.DESEncrypter;
import com.bytel.ravel.common.encryption.DESKeyManager;

/**
 * ShellPasswordEncrypter test class
 *
 * @author lchanyip
 * @version ($Revision$ $Date$)
 */
public class ShellPasswordEncrypterTest
{

  /**
   * Encyption test OK
   *
   * @throws Exception
   *
   */
  @Test
  public void testEncrypt() throws Exception
  {
    SecretKey key = new DESKeyManager("com.bytel.spirit.ford.common.encryption.DESKey").getSecretKey(); //$NON-NLS-1$
    Assert.assertEquals("MHndnhfjTSOsxxKKnPjCVA==", new DESEncrypter(key).encrypt("azertyqsdf"));
  }
}
