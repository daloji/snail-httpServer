/*******************************************************************************
 * $Id: ShellPasswordEncrypter.java 35209 2017-04-12 09:39:31Z fcabral $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.common.encryption;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

import com.bytel.ravel.common.encryption.DESEncrypter;
import com.bytel.ravel.common.encryption.DESKeyManager;

/**
 * Tool to encrypt.
 *
 * @author $Author: fcabral $
 * @version ($Revision: 35209 $)
 */
public final class ShellPasswordEncrypter
{

  /**
   * DESEncrypter parameter
   */
  private static DESEncrypter desEncrypter;

  /**
   * Encryption method.
   *
   * @param value
   *          string value to encrypt
   * @return encrypted pwd
   */
  public static synchronized String encrypt(String value)
  {
    try
    {
      if (desEncrypter == null)
      {
        SecretKey key = DESKeyManager.getInstance().getSecretKey();
        desEncrypter = new DESEncrypter(key);
      }
      return desEncrypter.encrypt(value);
    }
    catch (InvalidKeyException exIke)
    {
      exIke.printStackTrace();
    }
    catch (NoSuchAlgorithmException exNsae)
    {
      exNsae.printStackTrace();
    }
    catch (NoSuchPaddingException exNspe)
    {
      exNspe.printStackTrace();
    }
    catch (UnsupportedEncodingException exUee)
    {
      exUee.printStackTrace();
    }
    catch (IllegalStateException exIse)
    {
      exIse.printStackTrace();
    }
    catch (IllegalBlockSizeException exIbse)
    {
      exIbse.printStackTrace();
    }
    catch (BadPaddingException exBpe)
    {
      exBpe.printStackTrace();
    }
    return null;
  }

  /**
   * Main function.
   *
   * @param args_p
   *          data to encrypt
   */
  public static void main(String[] args_p)
  {
    try
    {
      if (args_p.length != 1)
      {
        System.out.println("Usage: java com.bytel.spirit.ford.common.encryption.ShellPasswordEncrypter <password to crypt>"); //$NON-NLS-1$
        return;
      }

      SecretKey key = new DESKeyManager("com.bytel.spirit.ford.common.encryption.DESKey").getSecretKey();
      System.out.println(new DESEncrypter(key).encrypt(args_p[0]));
    }
    catch (InvalidKeyException exIke)
    {
      exIke.printStackTrace();
    }
    catch (NoSuchAlgorithmException exNsae)
    {
      exNsae.printStackTrace();
    }
    catch (NoSuchPaddingException exNspe)
    {
      exNspe.printStackTrace();
    }
    catch (UnsupportedEncodingException exUee)
    {
      exUee.printStackTrace();
    }
    catch (IllegalStateException exIse)
    {
      exIse.printStackTrace();
    }
    catch (IllegalBlockSizeException exIbse)
    {
      exIbse.printStackTrace();
    }
    catch (BadPaddingException exBpe)
    {
      exBpe.printStackTrace();
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }

  }

  /**
   * to avoid public instanciation
   */
  private ShellPasswordEncrypter()
  {

  }

}
