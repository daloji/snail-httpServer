/*******************************************************************************
* $Id: IProcessFileConfigParameters.java 11476 2018-10-11 17:55:22Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.shared.types;

import static java.util.Objects.isNull;

import java.util.Arrays;
import java.util.StringJoiner;

import org.apache.cxf.common.util.CollectionUtils;

import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.spirit.common.ford.config.GenericProcessConfig;

/**
 * Interface containing the config parameter names used in the configuration file
 *
 * @author pcarreir
 * @version ($Revision: 11476 $ $Date: 2018-10-11 19:55:22 +0200 (Thu, 11 Oct 2018) $)
 */
public final class GenericProcessConfigValidator
{
  /**
   * Chemin d acces au repertoire de travail du processus
   */
  public static final String CHEMIN_REP_TRAVAIL = "cheminRepTravail"; //$NON-NLS-1$

  /**
   * Chemin d acces au repertoire d archivage des fichiers traites en succes pour le processus
   */
  public static final String CHEMIN_REP_ARCHIVE_SUCCES = "cheminRepArchiveSucces"; //$NON-NLS-1$

  /**
   * Chemin d acces au repertoire d archivage des fichiers traites en erreur pour le processus
   */
  public static final String CHEMIN_REP_ARCHIVE_ERREUR = "cheminRepArchiveErreur"; //$NON-NLS-1$

  /**
   * Extension appliquer au fichier en cours d’extraction
   */
  public static final String EXTENSION_FICHIER_TEMPORAIRE = "extensionFichierTemporaire"; //$NON-NLS-1$

  /**
   * Durée rétention fichier Temporaire en secondes
   */
  public static final String DUREE_RETENTION_TMP = "dureeRetentionTmp"; //$NON-NLS-1$

  /**
   * Nombre de PFI traites en parallele
   */
  public static final String POOL_SIZE = "poolSize"; //$NON-NLS-1$

  /**
   * Taille de la file d attente
   */
  public static final String WAITING_FILE_SIZE = "waitingFileSize"; //$NON-NLS-1$

  /**
   * Temps d attente de finalisation des traitements
   */
  public static final String ENDING_TIMEOUT = "endingTimeout"; //$NON-NLS-1$

  /**
   * Temps maximal d attente pour ajouter un PFI dans la file d attnte
   */
  public static final String PUSH_TIMEOUT = "pushTimeout"; //$NON-NLS-1$

  /**
   * Numero des lignes pour appeller le flush
   */
  public static final String LINES_TO_FLUSH = "linesToFlush"; //$NON-NLS-1$

  /**
   *
   */
  public static final String CONFIGURATION_FLUX_EXTRACTION = "ConfigurationFluxExtraction"; //$NON-NLS-1$

  /**
   * Liste des identifiant de flux d’extraction autorisés
   */
  public static final String ID_FLUX_EXTRACTION_AUTORISES = "IdFluxExtractionAutorises"; //$NON-NLS-1$

  /**
   * ActivateMultiThread parameter name
   */
  public static final String MULTI_THREAD_FLAG_PARAM = "activateMultiThread"; //$NON-NLS-1$

  /**
   * Checks if there is any mandatory parameter missing in the GenericProcessConfig.
   *
   * @param genericProcessConfig_p
   *          the GenericProcessConfig
   * @return String with the name of the parameters that are missing
   */
  public static String checkInexistantParams(GenericProcessConfig genericProcessConfig_p)
  {
    StringJoiner chaineNomParam = new StringJoiner(StringConstants.SEMICOLON_SEPARATOR);

    if (StringTools.isNullOrEmpty(genericProcessConfig_p.getCheminRepTravail()))
    {
      chaineNomParam.add(CHEMIN_REP_TRAVAIL);
    }
    if (StringTools.isNullOrEmpty(genericProcessConfig_p.getCheminRepArchiveSucces()))
    {
      chaineNomParam.add(CHEMIN_REP_ARCHIVE_SUCCES);
    }
    if (StringTools.isNullOrEmpty(genericProcessConfig_p.getCheminRepArchiveErreur()))
    {
      chaineNomParam.add(CHEMIN_REP_ARCHIVE_ERREUR);
    }
    if (StringTools.isNullOrEmpty(genericProcessConfig_p.getExtensionFichierTemporaire()))
    {
      chaineNomParam.add(EXTENSION_FICHIER_TEMPORAIRE);
    }
    if (isNull(genericProcessConfig_p.getDureeRetentionTmp()))
    {
      chaineNomParam.add(DUREE_RETENTION_TMP);
    }
    if (isNull(genericProcessConfig_p.getPoolSize()))
    {
      chaineNomParam.add(POOL_SIZE);
    }
    if (isNull(genericProcessConfig_p.getWaitingFileSize()))
    {
      chaineNomParam.add(WAITING_FILE_SIZE);
    }
    if (isNull(genericProcessConfig_p.getEndingTimeout()))
    {
      chaineNomParam.add(ENDING_TIMEOUT);
    }
    if (isNull(genericProcessConfig_p.getPushTimeout()))
    {
      chaineNomParam.add(PUSH_TIMEOUT);
    }
    if (isNull(genericProcessConfig_p.getLinesToFlush()))
    {
      chaineNomParam.add(LINES_TO_FLUSH);
    }
    if (CollectionUtils.isEmpty(genericProcessConfig_p.getConfigurationFluxExtraction()))
    {
      chaineNomParam.add(CONFIGURATION_FLUX_EXTRACTION);
    }
    if (StringTools.isNullOrEmpty(genericProcessConfig_p.getIdFluxExtractionAutorises()))
    {
      chaineNomParam.add(ID_FLUX_EXTRACTION_AUTORISES);
    }
    if (isNull(genericProcessConfig_p.isActivateMultiThread()))
    {
      chaineNomParam.add(MULTI_THREAD_FLAG_PARAM);
    }
    return chaineNomParam.toString();
  }

  /**
   * Checks if there is the fluId is not authorized.
   *
   * @param genericProcessConfig_p
   *          the GenericProcessConfig
   * @return String with the name of the parameters that are missing
   */
  public static String checkFluxId(GenericProcessConfig genericProcessConfig_p, String... authoziredFluxId_p)
  {
    StringJoiner chaineNomFlux = new StringJoiner(StringConstants.SEMICOLON_SEPARATOR);

    String[] idFluxExtractionAutorises = genericProcessConfig_p.getIdFluxExtractionAutorises().split(StringConstants.SEMICOLON_SEPARATOR);
    for (String fludIx : idFluxExtractionAutorises)
    {
      if (!Arrays.asList(authoziredFluxId_p).contains(fludIx))
      {
        chaineNomFlux.add(fludIx);
      }
    }

    return chaineNomFlux.toString();
  }

  public static boolean isIdFluxExtractionValid(String idFluxExtraction_p,  String... authoziredFluxId_p)
  {
    // Check IdFluxExtraction
    return Arrays.asList(authoziredFluxId_p).contains(idFluxExtraction_p);
  }

  /**
   *
   */
  private GenericProcessConfigValidator()
  {
    // DO NOTHING
  }

}
