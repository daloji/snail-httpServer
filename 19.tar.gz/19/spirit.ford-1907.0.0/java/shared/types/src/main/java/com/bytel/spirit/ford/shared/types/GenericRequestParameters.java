/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.shared.types;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class GenericRequestParameters
{
  /**
   * Execution mode
   */
  private String _modeExecution;

  /**
   * Flux Extraction Id
   */
  private String _idFluxExtraction;

  /**
   * @param modeExecution_p
   *          The modeExecution to set.
   */
  public void setModeExecution(String modeExecution_p)
  {
    _modeExecution = modeExecution_p;
  }

  /**
   * @param idFluxExtraction_p
   *          The idFluxExtraction to set.
   */
  public void setIdFluxExtraction(String idFluxExtraction_p)
  {
    _idFluxExtraction = idFluxExtraction_p;
  }

  /**
   * @return value of modeExecution
   */
  public String getModeExecution()
  {
    return _modeExecution;
  }

  /**
   * @return value of idFluxExtraction
   */
  public String getIdFluxExtraction()
  {
    return _idFluxExtraction;
  }
}
