
/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
******************************************************************************/

package com.bytel.spirit.ford.shared.misc.processes.workers;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author fbarnabe
 * @version ($Revision$ $Date$)
 */
public class WaitBlockingQueue extends LinkedBlockingQueue<Runnable>
{
  /**
   * serial Id
   */
  private static final long serialVersionUID = -1390911947567971504L;

  /**
   * timeout
   */
  private int _timeout;

  /**
   * unit
   */
  private TimeUnit _unit;

  /**
   * Constructor
   *
   * @param size_p
   *          size
   * @param timeout_p
   *          timeout
   * @param unit_p
   *          unit
   */
  public WaitBlockingQueue(int size_p, int timeout_p, TimeUnit unit_p)
  {
    super(size_p);
    _timeout = timeout_p;
    _unit = unit_p;
  }

  @Override
  public boolean offer(Runnable runable)
  {
    try
    {
      return this.offer(runable, _timeout, _unit);
    }
    catch (Throwable exception)
    {
      return false;
    }
  }
}
