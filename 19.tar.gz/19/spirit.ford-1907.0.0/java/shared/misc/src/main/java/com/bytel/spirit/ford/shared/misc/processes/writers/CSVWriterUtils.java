/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.shared.misc.processes.writers;

import java.time.LocalDateTime;

import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.StringConstants;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public final class CSVWriterUtils
{

  /**
   * Get the string value to write in the csv file. If value is null, write empty string.
   *
   * @param value_p
   * @return
   */
  public static String getCsvValue(Boolean value_p)
  {
    if (value_p != null)
    {
      return value_p.booleanValue() ? "1" : "0"; //$NON-NLS-1$ //$NON-NLS-2$
    }

    return StringConstants.EMPTY_STRING;

  }

  /**
   * Get the value of string field to write in the csv file. If value is null, write empty string.
   *
   * @param value_p
   *          Enum parameter
   * @return String value
   */
  public static <E extends Enum<E>> String getCsvValue(E value_p)
  {
    return value_p == null ? StringConstants.EMPTY_STRING : value_p.name();
  }

  /**
   * Get the value of LocalDateTime field to write in the csv file. If value is null, write empty string.
   *
   * @param value_p
   *          The value to write as a CSV value
   * @param format_p
   *          The date format.
   *
   *
   * @return String value
   */
  public static String getCsvValue(LocalDateTime value_p, DateTimeFormatPattern format_p)
  {
    return value_p == null ? StringConstants.EMPTY_STRING : format_p.format(value_p);
  }

  /**
   *
   */
  private CSVWriterUtils()
  {

  }
}
