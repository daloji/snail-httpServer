/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.shared.misc.processes;

import static com.google.common.base.Strings.isNullOrEmpty;

import java.io.File;
import java.net.URI;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.cxf.helpers.FileUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier;
import com.bytel.spirit.common.ford.config.ConfigurationFluxExtraction;
import com.bytel.spirit.common.ford.config.GenericProcessConfig;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.shared.misc.processes.workers.WaitBlockingQueue;
import com.bytel.spirit.ford.shared.misc.processes.writers.IGenericWriter;
import com.bytel.spirit.ford.shared.types.GenericRequestParameters;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public abstract class FordProcessSkeleton<W extends IGenericWriter<T>, T> extends SpiritProcessSkeleton
{
  /**
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  protected class Worker implements Callable<Retour>
  {
    /**
     * The tracability.
     */
    private Tracabilite _tracabilite;

    /**
     * The object from the RST call.
     */
    private T _objectToWrite;

    /**
     * The writers.
     */
    private List<W> _writers;

    /**
     *
     * @param tracabilite_p
     *          tracabilite
     * @param objectToWrite_p
     *          ServiceTechnique
     * @param writers_p
     *          NFSwriters
     */
    public Worker(Tracabilite tracabilite_p, T objectToWrite_p, List<W> writers_p)
    {
      _tracabilite = tracabilite_p;
      _objectToWrite = objectToWrite_p;
      _writers = new ArrayList<>(writers_p);
    }

    @Override
    public Retour call() throws Exception
    {
      try
      {
        return BL920_Dump(_tracabilite, _objectToWrite, _writers);
      }
      catch (Exception ex)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _tracabilite, ex));
        throw ex;
      }
    }
  }

  /**
   * Serial UID
   */
  protected static final long serialVersionUID = 755121274944204222L;

  /**
   * The message for AUCUNE_EXTRACTION log.
   */
  protected static final String MESSAGE_AUCUNE_EXTRACTION = Messages.getString("FordProcessSkeleton.NoExtractionInConfig"); //$NON-NLS-1$

  /**
   * The message for MESSAGE_LECTURE_IMPOSSIBLE log.
   */
  protected static final String MESSAGE_LECTURE_IMPOSSIBLE = Messages.getString("FordProcessSkeleton.LectureImpossible"); //$NON-NLS-1$

  /**
   * The message for MESSAGE_UNEXPECTED_CONTINUE log.
   */
  protected static final String MESSAGE_UNEXPECTED_CONTINUE = Messages.getString("FordProcessSkeleton.UnexpectedContinueProcessReceived"); //$NON-NLS-1$

  /**
   * The message for MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES
   */
  protected static final String MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES = Messages.getString("FordProcessSkeleton.ParametresConfigurationManquants"); //$NON-NLS-1$

  /**
   * The message for MESSAGE_PARAMETRES_CONFIGURATION_ID_FLUX_EXTRACTION_INVALIDES
   */
  protected static final String MESSAGE_PARAMETRES_CONFIGURATION_ID_FLUX_EXTRACTION_INVALIDES = Messages.getString("FordProcessSkeleton.ParametresIdFluxAutorisesInvalides"); //$NON-NLS-1$

  /**
   * Technical exception message
   */
  protected static final String MESSAGE_TECHNICAL_EXCEPTION = Messages.getString("FordProcessSkeleton.TechnicalExceptionMessage"); //$NON-NLS-1$

  /**
   * The constant for ModeExecutionPasConnu message
   */
  protected static final String MESSAGE_MODE_EXECUTION_PAS_CONNU = Messages.getString("FordProcessSkeleton.ModeExecutionPasConnu"); //$NON-NLS-1$

  /**
   * The constant for FileError message
   */
  protected static final String MESSAGE_FILE_ERROR = Messages.getString("FordProcessSkeleton.FileError"); //$NON-NLS-1$

  /**
   * The constant for NoParam message
   */
  protected static final String MESSAGE_NO_PARAM = Messages.getString("FordProcessSkeleton.NoParam"); //$NON-NLS-1$

  /**
   * The message for Supprimer fichier
   */
  protected static final String MESSAGE_FICHIER_SUPPRIME = Messages.getString("FordProcessSkeleton.FichierSupprime"); //$NON-NLS-1$

  /**
   * The message for MESSAGE_DEPLACER_FICHIER
   */
  protected static final String MESSAGE_DEPLACER_FICHIER = Messages.getString("FordProcessSkeleton.DeplacerFichier"); //$NON-NLS-1$

  /**
   * The message for TIMEOUT ERROR
   */
  protected static final String MESSAGE_TIMEOUT_ERROR = Messages.getString("FordProcessSkeleton.TimeoutError"); //$NON-NLS-1$

  /**
   * The message for TIMEOUT
   */
  protected static final String MESSAGE_TIMEOUT = Messages.getString("FordProcessSkeleton.Timeout"); //$NON-NLS-1$

  /**
   * The message for ErrorWritingFile
   */
  protected static final String MESSAGE_ERROR_WRITING_FILE = Messages.getString("FordProcessSkeleton.ErrorWritingFile"); //$NON-NLS-1$

  /**
   * The message for invalidExtractionName.
   */
  protected static final String MESSAGE_INVALID_EXTRACTION_NAME = Messages.getString("FordProcessSkeleton.InvalidExtractionName"); //$NON-NLS-1$

  /**
   * The message for ErrorRenamingFile.
   */
  protected static final String MESSAGE_ERROR_RENAMING_FILE = Messages.getString("FordProcessSkeleton.ErrorRenamingFile"); //$NON-NLS-1$

  /**
   * The message for ErrorRenamingFile.
   */
  protected static final String MESSAGE_UNAUTHORIZED_FLUX_ID = Messages.getString("FordProcessSkeleton.UnauthorizedFluxId"); //$NON-NLS-1$

  /**
   * Configuration path Param
   */
  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * Mode execution parameter name
   */
  protected static final String PARAM_MODE_EXECUTION = "modeExecution"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_CONF_FLUX_EXTRACTION = "confFluxExtraction"; //$NON-NLS-1$

  /**
   * String that defines the name of the extraction flux.
   */
  protected static final String PARAM_ID_FLUX_EXTRACTION = "idFluxExtraction"; //$NON-NLS-1$

  /**
   * String that defines the pattern.
   */
  protected static final String PARAM_PATTERN = "pattern"; //$NON-NLS-1$

  /**
   * String that defines the chaineConnexion.
   */
  protected static final String PARAM_CHAINE_CONNEXION = "chaineConnexion"; //$NON-NLS-1$

  /**
   * The TransfererFichiers constant.
   */
  protected static final String TRANSFERER_FICHIERS = "TransfererFichiers"; //$NON-NLS-1$

  /**
   * The ProduireExtractions constant.
   */
  protected static final String PRODUIRE_EXTRACTIONS = "ProduireExtractions"; //$NON-NLS-1$

  /**
   * @param path_p
   *          path
   * @param fileName_p
   *          filename
   * @return new URI
   * @throws Exception
   *           exception
   */
  @SuppressWarnings("javadoc")
  static public String addFileToURI(String path_p, String fileName_p) throws RavelException
  {
    URI newUri;
    try
    {
      // get new URI with fileName
      URI uri = new URI(path_p);
      String path = uri.getPath();
      if (!"/".equals(path.substring(path.length() - 1))) //$NON-NLS-1$
      {
        path = path + ("/"); //$NON-NLS-1$
      }
      path = path + fileName_p;
      newUri = new URI(uri.getScheme(), uri.getUserInfo(), uri.getHost(), uri.getPort(), path, uri.getQuery(), uri.getFragment());
    }
    catch (Exception ex)
    {
      throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, ex.getMessage());
    }

    return newUri.toString();
  }

  /**
   * Build the file extraction name. The format of the name returned is <FichierExtraction>_<YYYYMMDDHHMMSS>_v1.csv
   *
   * @param extractionName_p
   *          The extraction name
   * @return The filename in the format specified.
   */
  private static String getFileExtractionName(String extractionName_p, String version_p, String extension_p)
  {
    StringBuilder sb = new StringBuilder();
    sb.append(extractionName_p) //
        .append('_')//
        .append(DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now())) //
        .append('_') //
        .append(version_p) //
        .append(".csv") //$NON-NLS-1$
        .append(extension_p);
    return sb.toString();
  }

  /**
   * This activity initializes the Writer objects for the files in the configuration.
   *
   * @param tracabilite_p
   *          tracabilite
   * @return List of writers
   */
  @LogProcessBL
  protected Pair<Retour, List<W>> BL901_InitWriters(Tracabilite tracabilite_p, GenericProcessConfig processConfig_p, List<String> idFluxExtractionList_p, String modeExecution_p) throws RavelException
  {
    // Get file list
    String cheminRepTravail = processConfig_p.getCheminRepTravail();
    String archiveErreur = processConfig_p.getCheminRepArchiveErreur();
    List<File> files = FileUtils.getFiles(new File(cheminRepTravail), ".+\\.tmp$"); //$NON-NLS-1$

    // Process file list
    files.forEach(file -> {
      // Call BL1200_DeplacerFichier
      BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(file.getName()).repertoireSrc(cheminRepTravail).repertoireDes(archiveErreur).build();
      try
      {
        deplacerFichier.execute(this);
      }
      catch (RavelException e_p)
      {
        // Log
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e_p));
      }

      // Log operation
      String logMessage = MessageFormat.format(MESSAGE_DEPLACER_FICHIER, modeExecution_p, tracabilite_p.getIdCorrelationSpirit(), file.getName(), archiveErreur);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, logMessage));
    });

    if (StringTools.isNullOrEmpty(processConfig_p.getIdFluxExtractionAutorises()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.AUCUNE_EXTRACTION, MESSAGE_AUCUNE_EXTRACTION), Collections.emptyList());
    }

    List<W> writers = new ArrayList<>();
    String[] lExtractionType = processConfig_p.getIdFluxExtractionAutorises().split(";");

    for (String extractionType : lExtractionType)
    {
      // Get factory writer parameters
      Integer linesToFlush = processConfig_p.getLinesToFlush();

      if (idFluxExtractionList_p.contains(extractionType))
      {
        String extractionFileName = getFileExtractionName(extractionType, "v1", processConfig_p.getExtensionFichierTemporaire());

        // Create file
        BL1300_CreerFichier.BL1300_CreerFichierBuilder builder = new BL1300_CreerFichier.BL1300_CreerFichierBuilder();
        BL1300_CreerFichier bl1300_CreerFichier = builder//
            .tracabilite(tracabilite_p)//
            .repertoire(cheminRepTravail)//
            .nomFichier(extractionFileName)//
            .build();
        bl1300_CreerFichier.execute(this);
        Retour retourBl1300 = bl1300_CreerFichier.getRetour();
        if (RetourFactory.isRetourNOK(retourBl1300))
        {
          return new Pair<>(retourBl1300, null);
        }

        // Add writer to list
        Pair<Retour, W> writerRetour = getWriter(tracabilite_p, extractionType, cheminRepTravail, extractionFileName, linesToFlush);
        if (RetourFactory.isRetourOK(writerRetour._first))
        {
          writers.add(writerRetour._second);
        }
        else if (IMegSpiritConsts.CREATION_FICHIER_INVALIDE.equals(writerRetour._first.getDiagnostic()))
        { //could not create a file, so terminate treatment
          return new Pair<>(writerRetour._first, writers); //return writes list to call close writers later
        }
      }
    }
    return new Pair<>(RetourFactory.createOkRetour(), writers);
  }

  /**
   * This activity initializes the execution pool and the semaphore.
   *
   * @param tracabilite_p
   *          tracabilite
   * @return The thread pool and semaphore.
   */
  @LogProcessBL
  protected Pair<Retour, ThreadPoolExecutor> BL902_InitExecutor(Tracabilite tracabilite_p, GenericProcessConfig processConfig_p)
  {
    ThreadPoolExecutor threadPoolExecutor = null;

    if (processConfig_p.isActivateMultiThread())
    {
      WaitBlockingQueue waitBlockingQueue = new WaitBlockingQueue(processConfig_p.getWaitingFileSize(), processConfig_p.getPushTimeout(), TimeUnit.MILLISECONDS);

      threadPoolExecutor = new ThreadPoolExecutor(processConfig_p.getPoolSize(), processConfig_p.getPoolSize(), 0 /* keep alive time */, TimeUnit.MILLISECONDS, waitBlockingQueue);
    }

    return new Pair<>(RetourFactory.createOkRetour(), threadPoolExecutor);
  }

  /**
   * Waits for tasks completion and shutdown the pool.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param processConfig_p
   *          Process config
   * @param threadPoolExecutor_p
   *          stPoolExecutor
   * @param threadPoolExecutorResult_p
   *          list of future objects
   * @return retour Retour
   */
  @LogProcessBL
  protected Retour BL903_WaitExecutor(Tracabilite tracabilite_p, GenericProcessConfig processConfig_p, ThreadPoolExecutor threadPoolExecutor_p, List<Future<Retour>> threadPoolExecutorResult_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    if (processConfig_p.isActivateMultiThread())
    {
      try
      {
        retour = BL903_WaitForTasksCompletion(tracabilite_p, processConfig_p, threadPoolExecutorResult_p);
      }
      finally
      {
        try
        {
          Integer endingTimeout = processConfig_p.getEndingTimeout();
          //shutdown the pool
          threadPoolExecutor_p.shutdown(); // Disable new tasks from being submitted
          // Wait a while for existing tasks to terminate
          if (!threadPoolExecutor_p.awaitTermination(endingTimeout, TimeUnit.MILLISECONDS))
          {
            threadPoolExecutor_p.shutdownNow(); // Cancel currently executing tasks
            // Wait a while for tasks to respond to being cancelled
            if (!threadPoolExecutor_p.awaitTermination(endingTimeout, TimeUnit.MILLISECONDS))
            {
              RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("FordProcessSkeleton.PoolDidNotTerminate"), endingTimeout))); //$NON-NLS-1$
            }
          }
        }
        catch (InterruptedException e_p)
        {
          // (Re-)Cancel if current thread also interrupted
          threadPoolExecutor_p.shutdownNow();
          // Preserve interrupt status
          Thread.currentThread().interrupt();
        }
        catch (Exception e_p)
        {
          String exceptionMessage = (e_p.getCause() != null) && StringTools.isNotNullOrEmpty(e_p.getCause().getMessage()) ? e_p.getCause().getMessage() : e_p.getMessage();
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("FordProcessSkeleton.ShutdownPoolError"), exceptionMessage))); //$NON-NLS-1$
        }
      }
    }
    return retour;
  }

  /**
   * Waits for tasks completion
   *
   * @param tracabilite_p
   *          tracabilite
   * @param processConfig_p
   *          process config
   * @param threadPoolExecutorResult_p
   *          list of futures objects to wait for the computation to complete
   * @return a Retour OK if all tasks completed successfully
   */
  @LogProcessBL
  protected Retour BL903_WaitForTasksCompletion(Tracabilite tracabilite_p, GenericProcessConfig processConfig_p, List<Future<Retour>> threadPoolExecutorResult_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    if (processConfig_p.isActivateMultiThread())
    {
      Integer endingTimeout = processConfig_p.getEndingTimeout();

      try
      {
        // gather all the future result
        for (Future<Retour> future : threadPoolExecutorResult_p)
        {
          if (future != null)
          {
            Retour dumpRetour = future.get(endingTimeout, TimeUnit.MILLISECONDS);
            if (RetourFactory.isRetourNOK(dumpRetour))
            {
              return dumpRetour;
            }
          }
        }
      }
      catch (ExecutionException e_p)
      {
        String exceptionMessage = (e_p.getCause() != null) && StringTools.isNotNullOrEmpty(e_p.getCause().getMessage()) ? e_p.getCause().getMessage() : e_p.getMessage();
        String message = MessageFormat.format(MESSAGE_TECHNICAL_EXCEPTION, "ExecutionException", "BL903_WaitExecutor", exceptionMessage, ExceptionTools.getExceptionLineAndFile(e_p.getCause() == null ? e_p : e_p.getCause())); //$NON-NLS-1$ //$NON-NLS-2$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, message);
      }
      catch (TimeoutException e_p)
      {
        String exceptionMessage = (e_p.getCause() != null) && StringTools.isNotNullOrEmpty(e_p.getCause().getMessage()) ? e_p.getCause().getMessage() : e_p.getMessage();
        String message = MessageFormat.format(MESSAGE_TECHNICAL_EXCEPTION, "TimeoutException", "BL903_WaitExecutor", exceptionMessage, ExceptionTools.getExceptionLineAndFile(e_p.getCause() == null ? e_p : e_p.getCause())); //$NON-NLS-1$ //$NON-NLS-2$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.TIMEOUT, MESSAGE_TIMEOUT_ERROR);
      }
      catch (InterruptedException exception)
      {
        String message = Messages.getString("FordProcessSkeleton.ThreadInterruptedWhileWaiting"); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, message);
      }
      catch (Exception e_p)
      {
        String exceptionMessage = (e_p.getCause() != null) && StringTools.isNotNullOrEmpty(e_p.getCause().getMessage()) ? e_p.getCause().getMessage() : e_p.getMessage();
        String message = MessageFormat.format(MESSAGE_TECHNICAL_EXCEPTION, "Unexpected exception", "BL903_WaitExecutor", exceptionMessage, ExceptionTools.getExceptionLineAndFile(e_p.getCause() == null ? e_p : e_p.getCause())); //$NON-NLS-1$ //$NON-NLS-2$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, message);
      }
    }
    return retour;
  }

  /**
   * This activity closes the open files.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param writers_p
   *          writers
   */
  @LogProcessBL
  protected void BL904_CloseWriters(Tracabilite tracabilite_p, List<W> writers_p, String extensionFichierTemporaire_p)
  {
    writers_p.forEach(writer -> {
      try
      {
        writer.close();

        if (RetourFactory.isRetourOK(writer.getRetour()))
        {
          // Remove temporary extension
          File fileSource = new File(writer.getFilePath() + writer.getFileName());
          File fileDestination = new File(writer.getFilePath() + writer.getFileName().replaceFirst(extensionFichierTemporaire_p, ""));
          if (!fileSource.renameTo(fileDestination))
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_ERROR_RENAMING_FILE, fileSource)));
          }
        }
      }
      catch (Exception e_p)
      {
        // Log
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e_p));
      }
    });
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param objectToWrite_p
   *          object to write
   * @param nfsWriters_p
   *          list of writers
   * @param threadPoolExecutor_p
   *          thread pool executor
   * @return Retour
   */
  @LogProcessBL
  protected Retour BL910_PushIdInExecutor(Tracabilite tracabilite_p, GenericProcessConfig processConfig_p, T objectToWrite_p, List<W> nfsWriters_p, ThreadPoolExecutor threadPoolExecutor_p, List<Future<Retour>> threadPoolExecutorResult_p)
  {
    if (processConfig_p.isActivateMultiThread())
    {
      // Add worker to execution pool
      Worker worker = new Worker(tracabilite_p, objectToWrite_p, nfsWriters_p);

      try
      {
        Future<Retour> future = threadPoolExecutor_p.submit(worker);
        // Set future result for error check
        threadPoolExecutorResult_p.add(future);
      }
      catch (RejectedExecutionException e)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_TIMEOUT, objectToWrite_p.getClass(), objectToWrite_p.toString())));
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.TIMEOUT, MessageFormat.format(MESSAGE_TIMEOUT, objectToWrite_p.getClass(), objectToWrite_p.toString()));
      }
    }
    else // no multithread
    {
      // Call BL920
      return BL920_Dump(tracabilite_p, objectToWrite_p, nfsWriters_p);
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * This activity dispatches the Object to the writers
   *
   * @param tracabilite_p
   *          tracabilite
   * @param object_p
   *          The object to dump.
   * @param writers_p
   *          The list of writes.
   */
  @LogProcessBL
  protected Retour BL920_Dump(Tracabilite tracabilite_p, T object_p, List<W> writers_p)
  {
    // Process writers
    for (W writer : writers_p)
    {
      writer.dump(tracabilite_p, object_p);
      if (RetourFactory.isRetourNOK(writer.getRetour()))
      {
        return writer.getRetour();
      }
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Deletes all files in the work directory
   *
   * @param tracabilite_p
   *          The tracabilite
   */
  protected void deleteAllFilesInWorkPath(Tracabilite tracabilite_p, String workPath_p, String modeExecution_p, String temporaryExtension)
  {
    List<File> files = FileUtils.getFiles(new File(workPath_p), ".+\\" + temporaryExtension + "$"); //$NON-NLS-1$

    // Process file list
    for (File f : files)
    {
      BL3400_SupprimerFichier bl3400 = new BL3400_SupprimerFichier.BL3400_SupprimerFichierBuilder()//
          .tracabilite(tracabilite_p)// set tracabilite
          .repertoire(workPath_p)// set file location Path
          .fileName(f.getName())// set file name
          .build();
      try
      {
        bl3400.execute(this);

        if (RetourFactory.isRetourOK(bl3400.getRetour()))
        {
          String logMessage = MessageFormat.format(MESSAGE_FICHIER_SUPPRIME, modeExecution_p, tracabilite_p.getIdCorrelationSpirit(), f.getName());
          RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, logMessage));
        }
      }
      catch (RavelException exception)
      {
        // Log
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      }
    }
  }

  /**
   * Method to end synchronous process
   *
   * @param request_p
   *          Request parameter
   * @param retour_p
   *          Retour parameter
   *
   * @throws RavelException
   *           RavelException
   */
  protected void endSynchronousProcess(Request request_p, Retour retour_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      String result = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retour_p);
      ravelResponse.setResult(result);

      Response response = new Response(isRetourOK(retour_p) ? ErrorCode.OK_00200 : ErrorCode.KO_00404, ravelResponse);
      request_p.setResponse(response);
    }
  }

  /**
   * Get the matching ConfigurationFluxExtraction
   *
   * @param processConfig_p
   * @param idFluxExtraction_p
   * @return
   */
  protected Pair<Retour, ConfigurationFluxExtraction> getConfigurationFluxExtraction(GenericProcessConfig processConfig_p, String idFluxExtraction_p)
  {
    ConfigurationFluxExtraction matchingConfigFlux = processConfig_p.getConfigurationFluxExtraction().stream().filter(c -> c.getIdFluxExtraction().equals(idFluxExtraction_p)).findFirst().orElse(null);

    if (matchingConfigFlux == null)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_CONF_FLUX_EXTRACTION)), null);
    }

    // Check if any of the ConfigurationFluxExtraction parameters are missing
    if (StringTools.isNullOrEmpty(matchingConfigFlux.getIdFluxExtraction()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_ID_FLUX_EXTRACTION)), null);
    }
    if (StringTools.isNullOrEmpty(matchingConfigFlux.getPattern()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_PATTERN)), null);
    }
    if (isNullOrEmpty(matchingConfigFlux.getChaineConnexion()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_CHAINE_CONNEXION)), null);
    }

    return new Pair<>(RetourFactory.createOkRetour(), matchingConfigFlux);
  }

  /**
   * Gets the URL parameters into the ProcessContext
   *
   * @param request_p
   *          request
   * @return Value of the modeExecution
   *
   */
  protected Pair<Retour, GenericRequestParameters> getParamsFromRequest(Request request_p)
  {
    GenericRequestParameters requestParameters = new GenericRequestParameters();

    // get url parameters
    List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();

    for (Parameter parametre : urlParametersType)
    {
      if (parametre.getName().equalsIgnoreCase(PARAM_MODE_EXECUTION))
      {
        requestParameters.setModeExecution(parametre.getValue());
      }

      if (parametre.getName().equalsIgnoreCase(PARAM_ID_FLUX_EXTRACTION))
      {
        requestParameters.setIdFluxExtraction(parametre.getValue());
      }
    }

    if (StringTools.isNullOrEmpty(requestParameters.getModeExecution()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_MODE_EXECUTION)), null);
    }
    if (!Arrays.asList(PRODUIRE_EXTRACTIONS, TRANSFERER_FICHIERS).contains(requestParameters.getModeExecution()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_MODE_EXECUTION_PAS_CONNU), null);
    }
    if (StringTools.isNullOrEmpty(requestParameters.getIdFluxExtraction()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_ID_FLUX_EXTRACTION)), null);
    }

    return new Pair<>(RetourFactory.createOkRetour(), requestParameters);
  }

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @param extractionName_p
   *          The extraction name that determines the INSFWriter type to create
   * @param filePath_p
   *          The path to store CSV file
   * @param fileName_p
   *          The name of the CSV file
   * @param nbLinesToFlush_p
   *          Number of CSV lines in buffer to flush into the CSV file
   * @return NSFWriterStFactoryRetour object which contains the Retour OK if the Writer is well created or KO otherwise.
   *         If the Writer is well created it will be accessible by method getNSFWriter(), otherwise null is returned.
   *
   */
  protected abstract Pair<Retour, W> getWriter(Tracabilite tracabilite_p, String extractionName_p, String filePath_p, String fileName_p, int nbLinesToFlush_p);
}
