/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.shared.misc.processes.writers;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.shared.misc.processes.Messages;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public interface IGenericWriter<T> extends AutoCloseable
{
  /**
   */
  char CSV_SEPARATOR = ';';

  /**
   * The message for AUCUNE_EXTRACTION log.
   */
  String MESSAGE_ERROR_WRITING_FILE = Messages.getString("FordProcessSkeleton.ErrorWritingFile"); //$NON-NLS-1$

  /**
   * Constructs and configures a new instance of CSVFormat
   *
   * @throws IOException
   *           IOException
   *
   */
  default void createFile(String fullPathFileName_p, Class<? extends Enum<?>> class_p) throws IOException
  {
    // Open file
    BufferedWriter bf = Files.newBufferedWriter(Paths.get(fullPathFileName_p)); // bf is closed in method close by CSVPrinter
    CSVFormat csvFormat = CSVFormat.newFormat(CSV_SEPARATOR).withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(class_p).withQuote('"').withQuoteMode(QuoteMode.MINIMAL);
    this.setCSVPrinter(new CSVPrinter(bf, csvFormat));
  }

  /**
   * Generates files for the specified PFI
   *
   * @param objectToWrite_p
   *          The objet to write
   * @param tracabilite_p
   *          Tracabilite
   */
  void dump(Tracabilite tracabilite_p, T objectToWrite_p);

  /**
   *
   * @return
   */
  String getFileName();

  /**
   *
   * @return
   */
  String getFilePath();

  /**
   * return of writer
   *
   * @return
   */
  Retour getRetour();

  /**
   *
   * @param csvPrinter_p
   */
  void setCSVPrinter(CSVPrinter csvPrinter_p);
}
