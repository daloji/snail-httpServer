/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.Test;
import org.powermock.reflect.Whitebox;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.TestUtils;
import com.bytel.spirit.ford.processes.PP0098.generator.NSFWriterFactory.NSFWriterFactoryRetour;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
//TODO: assert that the file name is the expected in all Tests!
public class NSFWriterFactoryTest
{
  /**
   *
   */
  private final String _workPath = ".";//$NON-NLS-1$
  /**
   *
   */
  private final String _archivePath = "."; //$NON-NLS-1$
  /**
   *
   */
  private final String _environement = "DEV"; //$NON-NLS-1$
  /**
   *
   */
  Tracabilite _tracabilite = new Tracabilite();

  /**
   * Tests that the name of the CSV file is generated according to the STI format.
   *
   * @throws Exception
   *           Non expected exception
   */
  @Test
  public void getExtractionNameTest() throws Exception
  {
    String extractionName = "SPIRIT-LIENEQTPACARTETHD"; //$NON-NLS-1$
    String dateTime = "20180102_103005"; //$NON-NLS-1$
    String expectedFileName = new StringBuilder().append(extractionName)//append extraction name
        .append('_').append(_environement).append('_')//
        .append(dateTime).append(NSFWriterFactory.CSV_FILE_EXTENSION).toString();
    String extractionNameToTest = Whitebox.invokeMethod(NSFWriterFactory.class, "getFileExtractionName", "SPIRIT-LIENEQTPACARTETHD", _environement, dateTime); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(expectedFileName, extractionNameToTest);

  }

  /**
   * Call NSFFactory to get an invalid extraction name.
   *
   * @throws Exception
   */
  @Test
  public void getInvalidNSFWriterTest() throws Exception
  {

    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-XXXX", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourKO(retour));

    assertEquals(IMegConsts.CAT3, retour.getCategorie());
    assertEquals(IMegConsts.CONFIGURATION_INVALIDE, retour.getDiagnostic());
    assertEquals("The extraction name SPIRIT-XXXX is unexpected.", retour.getLibelle()); //$NON-NLS-1$

  }

  /**
   * Use the factory to get the LienEqtPaCarteThdWriter object.
   */
  @Test
  public void getLienEqtPACarteTHDWriterTest()
  {

    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-LIENEQTPACARTETHD", _workPath, _environement, 10, dateTime);
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));
    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof LienEqtPaCarteThdWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the LienEqtPaDecodeurTvWriter object.
   */
  @Test
  public void getLienEqtPADecodeurTVWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-LIENEQTPADECODEURTV", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));
    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof LienEqtPaDecodeurTvWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the LienEqtPaModemDecodeurTvWriter object.
   */
  @Test
  public void getLienEqtPAModemDecodeurTVWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-LIENEQTPAMODEMDECODEURTV", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));
    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof LienEqtPaModemDecodeurTvWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the LienEqtPaModemWriter object.
   */
  @Test
  public void getLienEqtPaModemWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-LIENEQTPAMODEM", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));
    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof LienEqtPaModemWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the LienEqtPaOntWriter object.
   */
  @Test
  public void getLienEqtPAONTWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-LIENEQTPAONT", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof LienEqtPaOntWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the LienSaPaCompteAccesWriter object.
   */
  @Test
  public void getLienSAPACAWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-LIENSAPACA", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof LienSaPaCompteAccesWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the LienSAPAFAXWriter object.
   */
  @Test
  public void getLienSAPAFAXWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-LIENSAPAFAX", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof LienSaPaFaxWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the LienSAPATVWriter object.
   */
  @Test
  public void getLienSaPaTVWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-LIENSAPATV", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));
    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof LienSaPaTvWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the LienSaPaVoipWriter object.
   */
  @Test
  public void getLienSAPAVOIPWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-LIENSAPAVOIP", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof LienSaPaVoipWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the NbPhotoSurPfiWriter object.
   */
  @Test
  public void getNbPhotosSurPFIWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    Map<String, AtomicInteger> pfiCounter = new ConcurrentHashMap<>();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-NBPHOTOSURPFI", _workPath, _environement, 10, dateTime, pfiCounter); //$NON-NLS-1$

    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof NbPhotoSurPfiWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the PACAWriter object.
   */
  @Test
  public void getPACAWriterWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-PACA", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof PaCompteAccesWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the PAFAXWriter object.
   */
  @Test
  public void getPAFAXWriterWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-PAFAX", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));
    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof PaFaxWriter);
    deleteWriterGeneratedCSVFile(writer);
  }

  /**
   * Use the factory to get the PaLigneFixeFttlaWriter object.
   */
  @Test
  public void getPALFFTTLAWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-PALFFTTLA", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof PaLigneFixeFttlaWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the PALFFTTH object.
   */
  @Test
  public void getPALFTTHWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-PALFFTTH", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof PaLigneFixeFtthWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the PALFXDSL object.
   */
  @Test
  public void getPALFXDSLWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-PALFXDSL", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));
    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof PaLigneFixeXdslWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the PaTvWriter object.
   */
  @Test
  public void getPATVWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-PATV", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof PaTvWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the PaVoipWriter object.
   */
  @Test
  public void getPAVOIPWriterWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-PAVOIP", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof PaVoipWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the PfiWriter object.
   */
  @Test
  public void getPFIWriterTest()
  {

    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-PFI", _workPath, _environement, 10, dateTime); //$NON-NLS-1$

    assertEquals(true, RetourFactory.isRetourOK(writerFactoryResult.getRetour()));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof PfiWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Use the factory to get the LienSaPaLigneFixeWriter object.
   */
  @Test
  public void getSAPALFWriterWriterTest()
  {
    String dateTime = TestUtils.getFileDateTime();
    NSFWriterFactoryRetour writerFactoryResult = NSFWriterFactory.getNSFWriter(_tracabilite, "SPIRIT-LIENSAPALF", _workPath, _environement, 10, dateTime); //$NON-NLS-1$
    Retour retour = writerFactoryResult.getRetour();
    assertEquals(true, RetourFactory.isRetourOK(retour));

    INSFWriter writer = writerFactoryResult.getNSFWriter();
    assertTrue(writer instanceof LienSaPaLigneFixeWriter);
    deleteWriterGeneratedCSVFile(writer);

  }

  /**
   * Deletes the CSV file generated by the INSFWriter instance during the test
   *
   * @param writer
   *          The INSFWriter instance that generated the file
   */
  private void deleteWriterGeneratedCSVFile(INSFWriter writer)
  {
    //get the fileName stored in the private field of the Writer
    String fileName = Whitebox.getInternalState(writer, "_fileName"); //$NON-NLS-1$

    new File(fileName).delete();
  }

}
