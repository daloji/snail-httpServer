/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0241;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.HttpMethod;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.csv.CSVFileWriter;
import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier.BL1300_CreerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL900_ObtenirConfigurationEmissionFichier;
import com.bytel.spirit.common.activities.shared.BL900_ObtenirConfigurationEmissionFichier.BL900_ObtenirConfigurationEmissionFichierBuilder;
import com.bytel.spirit.common.activities.shared.structs.ConfigurationEmission;
import com.bytel.spirit.common.connectors.gdr.GDRProxy;
import com.bytel.spirit.common.connectors.gdr.structs.BYTPRD;
import com.bytel.spirit.common.connectors.gdr.structs.CMDSIM;
import com.bytel.spirit.common.connectors.gdr.structs.SUIVISMDP;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PP0241_NotificationSAP.class, GDRProxy.class, BL900_ObtenirConfigurationEmissionFichier.class, BL900_ObtenirConfigurationEmissionFichierBuilder.class, BL1300_CreerFichier.class, BL1300_CreerFichierBuilder.class, BL4300_EnvoyerFichierBuilder.class, BL1200_DeplacerFichier.class, Files.class, File.class, Path.class, Paths.class })
public class PP0241_NotificationSAP_Test extends EasyMockSupport
{
  /**
   * SPRING Context
   */
  private static ClassPathXmlApplicationContext _context;

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Used to close any used resources.<br/>
   */
  @AfterClass
  public static void close()
  {
    _context.close();
  }

  /**
   * @throws RavelException
   *           RavelException
   */
  @BeforeClass
  public static void init() throws RavelException
  {

    ACManagerUtil.resetACManager();
    _context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
    HashMap<String, String> map = new HashMap<String, String>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "test.xml"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    try
    {
      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(LocalDateTime.now());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager is now initialized")); //$NON-NLS-1$
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager instance is already initialized")); //$NON-NLS-1$
    }
  }

  /**
   * Instance of {@link PP0241_NotificationSAP}
   */
  private PP0241_NotificationSAP _processInstance;

  /**
   * _GDRProxy Mock
   */
  @MockStrict
  private GDRProxy _GDRProxyMock;

  /**
   * The BL900 activity mock
   */
  @MockStrict
  BL900_ObtenirConfigurationEmissionFichier _bl900Mock;

  /**
   * The BL900 activity mock
   */
  @MockStrict
  BL900_ObtenirConfigurationEmissionFichierBuilder _bl900BuilderMock;

  /**
   * The BL1300 activity builder mock
   */
  @MockStrict
  BL1300_CreerFichier _bl1300Mock;

  /**
   *
   */
  @MockStrict
  BL1300_CreerFichierBuilder _bl1300BuilderMock;

  /**
   * The BL4300 activity builder mock
   */
  @MockStrict
  BL4300_EnvoyerFichier _bl4300Mock;

  /**
  *
  */
  @MockStrict
  BL4300_EnvoyerFichierBuilder _bl4300BuilderMock;

  /**
   * The BL4300 activity mock
   */
  @MockStrict
  BL1200_DeplacerFichier _bl1200Mock;

  /**
   * The BL1200 activity builder mock
   */
  @MockStrict
  BL1200_DeplacerFichierBuilder _bl1200BuilderMock;

  /**
   *
   */
  @MockStrict
  CSVFileWriter _cvsFileWriterMock;

  /**
   * Mock de {@link Path}
   */
  @MockNice
  private Path _path;

  /**
   * Test StartProcess <br/>
   * Test OK on checkparameters - Parameter exists is OK <br/>
   * CALL BL100 <br/>
   * CALL GDRPROXY_ps021 and Throws Exception <br/>
   *
   * <b>Expected:</b>Resultat = "NOK", Category = "CAT-1", Diagnostic = "Lecture Indisponible"
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_001() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "file.xml"); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps021GetCommandesNonNotifies(_tracabilite)).andThrow(new RavelException(ExceptionType.CONNECTOR_CHECKING_ERROR, ErrorCode.DBPRXY_00001, "")); //$NON-NLS-1$

    PowerMock.replayAll();

    _processInstance.run(request);
    Response response = (Response) request.getResponse();

    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    assertEquals(StringConstants.NOK, result.getResultat());
    assertEquals(IMegConsts.CAT1, result.getCategorie());
    assertEquals(IMegSpiritConsts.MISE_A_JOUR_INDISPONIBLE, result.getDiagnostic());
  }

  /**
   * Test StartProcess <br/>
   * Test OK on checkparameters - Parameter exists is OK <br/>
   * CALL BL100 <br/>
   * CALL GDRPROXY_ps021 and Returns Empty list <br/>
   *
   * <b>Expected:</b>Resultat = "NOK", Category = "CAT-1", Diagnostic = "Lecture Indisponible"
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_002() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "file.xml"); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    List<CMDSIM> emptylist = new ArrayList<CMDSIM>();
    ConnectorResponse<List<CMDSIM>, Retour> gdrResponse = new ConnectorResponse<List<CMDSIM>, Retour>(emptylist, null);

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps021GetCommandesNonNotifies(_tracabilite)).andReturn(gdrResponse);

    PowerMock.replayAll();

    _processInstance.run(request);
    Response response = (Response) request.getResponse();

    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    assertNull(result);
    // assertEquals(StringConstants.OK, result.getResultat());
    assertEquals(0, _processInstance.getProcessContext()._listCommandeESim.size());
  }

  /**
   * Test StartProcess <br/>
   * Test OK on checkparameters - Parameter exists is OK <br/>
   * CALL BL100 <br/>
   * CALL GDRPROXY_ps021 and Returns list 1 CMDSIM<br/>
   * CALL GDRPROXY_ps025 and Returns empty list <br/>
   * CALL GDRPROXY_ps024 and Returns empty list <br/>
   * <b>Expected:</b>Resultat = "OK"
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_003() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "file.xml"); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    List<CMDSIM> cmdsimList = new ArrayList<CMDSIM>();
    CMDSIM cmdsimObject = new CMDSIM(12345L, null, 1L, null, null, null, null, null, null, null, null, null, null, null, null, "1", null, null, null, null, null, null, null, null); //$NON-NLS-1$
    cmdsimList.add(cmdsimObject);
    ConnectorResponse<List<CMDSIM>, Retour> gdrResponse = new ConnectorResponse<List<CMDSIM>, Retour>(cmdsimList, null);

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps021GetCommandesNonNotifies(_tracabilite)).andReturn(gdrResponse);

    List<SUIVISMDP> emptylist = new ArrayList<SUIVISMDP>();

    ConnectorResponse<List<SUIVISMDP>, Retour> gdrResponse1 = new ConnectorResponse<List<SUIVISMDP>, Retour>(emptylist, null);

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps025GetSUIVISMDP(_tracabilite, "12345")).andReturn(gdrResponse1); //$NON-NLS-1$

    PowerMock.replayAll();

    _processInstance.run(request);

    Response response = (Response) request.getResponse();

    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    assertNull(result);
    assertEquals(0, _processInstance.getProcessContext()._listCommandeESim.size());
  }

  /**
   * Test StartProcess <br/>
   * Test OK on checkparameters - Parameter exists is OK <br/>
   * CALL BL100 <br/>
   * CALL GDRPROXY_ps021 and Returns list 1 CMDSIM<br/>
   * CALL GDRPROXY_ps025 and Returns empty list <br/>
   * Expected:</b>Resultat = "KO" <br/>
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_004() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "file.xml"); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    List<CMDSIM> cmdsimList = new ArrayList<CMDSIM>();
    CMDSIM cmdsimObject = new CMDSIM(1L, null, 1L, null, null, null, null, null, null, null, null, null, null, null, null, "numCMDSAP1", null, null, null, null, null, null, null, null); //$NON-NLS-1$
    cmdsimList.add(cmdsimObject);
    ConnectorResponse<List<CMDSIM>, Retour> gdrResponse = new ConnectorResponse<List<CMDSIM>, Retour>(cmdsimList, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps021GetCommandesNonNotifies(_tracabilite)).andReturn(gdrResponse);

    List<SUIVISMDP> emptylist = new ArrayList<SUIVISMDP>();

    ConnectorResponse<List<SUIVISMDP>, Retour> gdrResponse1 = new ConnectorResponse<List<SUIVISMDP>, Retour>(emptylist, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps025GetSUIVISMDP(_tracabilite, "1")).andReturn(gdrResponse1); //$NON-NLS-1$

    PowerMock.replayAll();

    _processInstance.run(request);

    Response response = (Response) request.getResponse();

    PowerMock.verifyAll();

    assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    assertTrue(_processInstance.getProcessContext()._listCommandeESim.isEmpty());
  }

  /**
   * Test StartProcess <br/>
   * Test OK on checkparameters - Parameter exists is OK <br/>
   * CALL BL100 <br/>
   * CALL GDRPROXY_ps021 and Returns list 1 CMDSIM<br/>
   * CALL GDRPROXY_ps025 and Returns empty list <br/>
   * <b>Expected:</b>Resultat = "KO CAT3"<br/>
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_005() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "file.xml"); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    List<CMDSIM> cmdsimList = new ArrayList<CMDSIM>();
    CMDSIM cmdsimObject = new CMDSIM(1L, null, 1L, null, null, null, null, null, null, null, null, null, null, null, null, "numCMDSAP1", null, null, null, null, null, null, null, null); //$NON-NLS-1$
    cmdsimList.add(cmdsimObject);
    ConnectorResponse<List<CMDSIM>, Retour> gdrResponse = new ConnectorResponse<List<CMDSIM>, Retour>(cmdsimList, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps021GetCommandesNonNotifies(_tracabilite)).andReturn(gdrResponse);

    List<SUIVISMDP> emptylist = new ArrayList<SUIVISMDP>();

    ConnectorResponse<List<SUIVISMDP>, Retour> gdrResponse1 = new ConnectorResponse<List<SUIVISMDP>, Retour>(emptylist, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps025GetSUIVISMDP(_tracabilite, "1")).andReturn(gdrResponse1); //$NON-NLS-1$

    PowerMock.replayAll();

    _processInstance.run(request);

    Response response = (Response) request.getResponse();

    PowerMock.verifyAll();

    assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    assertTrue(_processInstance.getProcessContext()._listCommandeESim.isEmpty());
  }

  /**
   * Test StartProcess <br/>
   * Test OK on checkparameters - Parameter exists is OK <br/>
   * CALL BL100 <br/>
   * CALL GDRPROXY_ps021 and Returns list 1 CMDSIM<br/>
   * CALL GDRPROXY_ps025 and Returns list 1 SUIVISMDP <br/>
   * CALL GDRPROXY_ps024 and Returns list 1 BYTPRD <br/>
   * CALL BL900 and Returns OK and ConfigurationEmission with parameters <br/>
   * CALL BL1300 and Returns OK <br/>
   * CALL GDRPROXY_ps023 expect PP0241_NotificationSAP.PARTIEL and Returns OK <br/>
   * CALL BL4300 and Returns NOK <br/>
   * <b>Expected:</b>Resultat = "KO CAT3"<br/>
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_006() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "file.xml"); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    List<CMDSIM> cmdsimList = new ArrayList<CMDSIM>();
    CMDSIM cmdsimObject = new CMDSIM(1L, null, 1L, null, null, null, null, null, null, null, 10000L, null, null, null, null, "numCMDSAP1", null, null, null, null, null, null, null, null); //$NON-NLS-1$
    cmdsimList.add(cmdsimObject);
    ConnectorResponse<List<CMDSIM>, Retour> gdrResponse = new ConnectorResponse<List<CMDSIM>, Retour>(cmdsimList, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps021GetCommandesNonNotifies(_tracabilite)).andReturn(gdrResponse);

    List<SUIVISMDP> listSUIVISMDP = new ArrayList<SUIVISMDP>();
    listSUIVISMDP.add(new SUIVISMDP(1000L, null, null, 1000L, null));
    ConnectorResponse<List<SUIVISMDP>, Retour> gdrResponse1 = new ConnectorResponse<List<SUIVISMDP>, Retour>(listSUIVISMDP, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps025GetSUIVISMDP(_tracabilite, "1")).andReturn(gdrResponse1); //$NON-NLS-1$

    List<BYTPRD> listBYTPRD = new ArrayList<BYTPRD>();

    listBYTPRD.add(new BYTPRD(1L, "typGNC1", "idtARTWRK1", 1L, 1L, "idtFAB1", 1L, 1L, "idtUSASIM1", "codARTSAP1", "libARTSAP1", "debTRAMSI1", "finTRAMSI1", null, 1L)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$

    ConnectorResponse<List<BYTPRD>, Retour> gdrResponse2 = new ConnectorResponse<List<BYTPRD>, Retour>(listBYTPRD, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps024GetBytprd(_tracabilite, "1")).andReturn(gdrResponse2); //$NON-NLS-1$

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(PP0241_NotificationSAP.NOTIFICATION_SAP)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile("file.xml")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(PP0241_NotificationSAP.NOTIFICATION_SAP)).andReturn(_bl900BuilderMock);

    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);

    ConfigurationEmission configurationEmission = new ConfigurationEmission();
    configurationEmission.setCodeFlux(PP0241_NotificationSAP.NOTIFICATION_SAP);
    configurationEmission.setRepertoireTemp("temp"); //$NON-NLS-1$

    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(configurationEmission);

    EasyMock.expect(_bl900Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.expectNew(BL1300_CreerFichierBuilder.class).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.repertoire(EasyMock.anyObject(String.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.build()).andReturn(_bl1300Mock);
    EasyMock.expect(_bl1300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    EasyMock.expect(Paths.get(EasyMock.anyString())).andReturn(_path);
    PowerMock.expectNew(CSVFileWriter.class, EasyMock.anyObject(File.class)).andReturn(_cvsFileWriterMock);
    EasyMock.expect(_cvsFileWriterMock.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);
    EasyMock.expect(_cvsFileWriterMock.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);

    _cvsFileWriterMock.flush();
    EasyMock.expectLastCall();

    _cvsFileWriterMock.close();
    EasyMock.expectLastCall();

    ConnectorResponse<Nothing, Retour> retourps023 = new ConnectorResponse<Nothing, Retour>(null, RetourFactory.createOkRetour());
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps023UpdateEnvoiCmdSim(_tracabilite, "1", PP0241_NotificationSAP.PARTIEL)).andReturn(retourps023); //$NON-NLS-1$

    // CALL 4300

    PowerMock.expectNew(BL4300_EnvoyerFichierBuilder.class).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.chaineConnexion(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.repertoire(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.build()).andReturn(_bl4300Mock);
    EasyMock.expect(_bl4300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl4300Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.DONNEE_INVALIDE, null));

    // CALL 1200
    PowerMock.expectNew(BL1200_DeplacerFichierBuilder.class).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireSrc(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireDes(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.build()).andReturn(_bl1200Mock);
    EasyMock.expect(_bl1200Mock.execute(_processInstance)).andReturn(null);

    PowerMock.replayAll();

    _processInstance.run(request);

    Response response = (Response) request.getResponse();

    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    assertEquals(StringConstants.NOK, result.getResultat());
    assertEquals(IMegConsts.CAT1, result.getCategorie());
    assertEquals(IMegConsts.DONNEE_INVALIDE, result.getDiagnostic());
    assertEquals(1, _processInstance.getProcessContext()._listCommandeESim.size());
  }

  /**
   * Test StartProcess <br/>
   * Test OK on checkparameters - Parameter exists is OK <br/>
   * CALL BL100 <br/>
   * CALL GDRPROXY_ps021 and Returns list 1 CMDSIM<br/>
   * CALL GDRPROXY_ps025 and Returns list 1 SUIVISMDP <br/>
   * CALL GDRPROXY_ps024 and Returns list 1 BYTPRD <br/>
   * CALL BL900 and Returns OK and ConfigurationEmission with parameters <br/>
   * CALL BL1300 and Returns OK <br/>
   * CALL GDRPROXY_ps023 expect PP0241_NotificationSAP.COMPLET and Returns OK <br/>
   * CALL BL4300 and Returns NOK <br/>
   * <b>Expected:</b>Resultat = "KO CAT3"<br/>
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_007() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "file.xml"); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    List<CMDSIM> cmdsimList = new ArrayList<CMDSIM>();
    CMDSIM cmdsimObject = new CMDSIM(1L, null, 1L, null, null, null, null, null, null, null, 1000L, null, null, null, null, "numCMDSAP1", null, null, null, null, null, null, null, null); //$NON-NLS-1$
    cmdsimList.add(cmdsimObject);
    ConnectorResponse<List<CMDSIM>, Retour> gdrResponse = new ConnectorResponse<List<CMDSIM>, Retour>(cmdsimList, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps021GetCommandesNonNotifies(_tracabilite)).andReturn(gdrResponse);

    List<SUIVISMDP> listSUIVISMDP = new ArrayList<SUIVISMDP>();
    listSUIVISMDP.add(new SUIVISMDP(1000L, null, null, 1000L, null));
    ConnectorResponse<List<SUIVISMDP>, Retour> gdrResponse1 = new ConnectorResponse<List<SUIVISMDP>, Retour>(listSUIVISMDP, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps025GetSUIVISMDP(_tracabilite, "1")).andReturn(gdrResponse1); //$NON-NLS-1$

    List<BYTPRD> listBYTPRD = new ArrayList<BYTPRD>();

    listBYTPRD.add(new BYTPRD(1L, "typGNC1", "idtARTWRK1", 1L, 1L, "idtFAB1", 1L, 1L, "idtUSASIM1", "codARTSAP1", "libARTSAP1", "debTRAMSI1", "finTRAMSI1", null, 1L)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$

    ConnectorResponse<List<BYTPRD>, Retour> gdrResponse2 = new ConnectorResponse<List<BYTPRD>, Retour>(listBYTPRD, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps024GetBytprd(_tracabilite, "1")).andReturn(gdrResponse2); //$NON-NLS-1$

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(PP0241_NotificationSAP.NOTIFICATION_SAP)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile("file.xml")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(PP0241_NotificationSAP.NOTIFICATION_SAP)).andReturn(_bl900BuilderMock);

    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);

    ConfigurationEmission configurationEmission = new ConfigurationEmission();
    configurationEmission.setCodeFlux(PP0241_NotificationSAP.NOTIFICATION_SAP);
    configurationEmission.setRepertoireTemp("temp"); //$NON-NLS-1$

    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(configurationEmission);

    EasyMock.expect(_bl900Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.expectNew(BL1300_CreerFichierBuilder.class).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.repertoire(EasyMock.anyObject(String.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.build()).andReturn(_bl1300Mock);
    EasyMock.expect(_bl1300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    EasyMock.expect(Paths.get(EasyMock.anyString())).andReturn(_path);
    PowerMock.expectNew(CSVFileWriter.class, EasyMock.anyObject(File.class)).andReturn(_cvsFileWriterMock);
    EasyMock.expect(_cvsFileWriterMock.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);
    EasyMock.expect(_cvsFileWriterMock.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);

    _cvsFileWriterMock.flush();
    EasyMock.expectLastCall();

    _cvsFileWriterMock.close();
    EasyMock.expectLastCall();

    ConnectorResponse<Nothing, Retour> retourps023 = new ConnectorResponse<Nothing, Retour>(null, RetourFactory.createOkRetour());
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps023UpdateEnvoiCmdSim(_tracabilite, "1", PP0241_NotificationSAP.COMPLET)).andReturn(retourps023); //$NON-NLS-1$

    // CALL 4300
    PowerMock.expectNew(BL4300_EnvoyerFichierBuilder.class).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.chaineConnexion(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.repertoire(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.build()).andReturn(_bl4300Mock);
    EasyMock.expect(_bl4300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl4300Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.DONNEE_INVALIDE, null));

    // CALL 1200
    PowerMock.expectNew(BL1200_DeplacerFichierBuilder.class).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireSrc(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireDes(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.build()).andReturn(_bl1200Mock);
    EasyMock.expect(_bl1200Mock.execute(_processInstance)).andReturn(null);

    PowerMock.replayAll();

    _processInstance.run(request);

    Response response = (Response) request.getResponse();

    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    assertEquals(StringConstants.NOK, result.getResultat());
    assertEquals(IMegConsts.CAT1, result.getCategorie());
    assertEquals(IMegConsts.DONNEE_INVALIDE, result.getDiagnostic());
    assertEquals(1, _processInstance.getProcessContext()._listCommandeESim.size());
  }

  /**
   * Test StartProcess <br/>
   * Test OK on checkparameters - Parameter exists is OK <br/>
   * CALL BL100 <br/>
   * CALL GDRPROXY_ps021 and Returns list 1 CMDSIM<br/>
   * CALL GDRPROXY_ps025 and Returns list 1 SUIVISMDP <br/>
   * CALL GDRPROXY_ps024 and Returns list 1 BYTPRD <br/>
   * CALL BL900 and Returns OK and ConfigurationEmission with parameters <br/>
   * CALL BL1300 and Returns OK <br/>
   * CALL GDRPROXY_ps023 and Returns OK <br/>
   * CALL BL4300 and Returns NOK <br/>
   * <b>Expected:</b>Resultat = "KO CAT1 CONFIGURATION INVALIDE"<br/>
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_008() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "file.xml"); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    List<CMDSIM> cmdsimList = new ArrayList<CMDSIM>();
    CMDSIM cmdsimObject = new CMDSIM(1L, null, 1L, null, null, null, null, null, null, null, 100000L, null, null, null, null, "numCMDSAP1", null, null, null, null, null, null, null, null); //$NON-NLS-1$
    cmdsimList.add(cmdsimObject);
    ConnectorResponse<List<CMDSIM>, Retour> gdrResponse = new ConnectorResponse<List<CMDSIM>, Retour>(cmdsimList, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps021GetCommandesNonNotifies(_tracabilite)).andReturn(gdrResponse);

    List<SUIVISMDP> listSUIVISMDP = new ArrayList<SUIVISMDP>();
    listSUIVISMDP.add(new SUIVISMDP(1000L, null, null, 1000L, null));
    ConnectorResponse<List<SUIVISMDP>, Retour> gdrResponse1 = new ConnectorResponse<List<SUIVISMDP>, Retour>(listSUIVISMDP, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps025GetSUIVISMDP(_tracabilite, "1")).andReturn(gdrResponse1); //$NON-NLS-1$

    List<BYTPRD> listBYTPRD = new ArrayList<BYTPRD>();

    listBYTPRD.add(new BYTPRD(1L, "typGNC1", "idtARTWRK1", 1L, 1L, "idtFAB1", 1L, 1L, "idtUSASIM1", "codARTSAP1", "libARTSAP1", "debTRAMSI1", "finTRAMSI1", null, 1L)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$

    ConnectorResponse<List<BYTPRD>, Retour> gdrResponse2 = new ConnectorResponse<List<BYTPRD>, Retour>(listBYTPRD, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps024GetBytprd(_tracabilite, "1")).andReturn(gdrResponse2); //$NON-NLS-1$

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(PP0241_NotificationSAP.NOTIFICATION_SAP)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile("file.xml")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(PP0241_NotificationSAP.NOTIFICATION_SAP)).andReturn(_bl900BuilderMock);

    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);

    ConfigurationEmission configurationEmission = new ConfigurationEmission();
    configurationEmission.setCodeFlux(PP0241_NotificationSAP.NOTIFICATION_SAP);
    configurationEmission.setRepertoireTemp("temp"); //$NON-NLS-1$

    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(configurationEmission);

    EasyMock.expect(_bl900Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.expectNew(BL1300_CreerFichierBuilder.class).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.repertoire(EasyMock.anyObject(String.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.build()).andReturn(_bl1300Mock);
    EasyMock.expect(_bl1300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    EasyMock.expect(Paths.get(EasyMock.anyString())).andReturn(_path);
    PowerMock.expectNew(CSVFileWriter.class, EasyMock.anyObject(File.class)).andReturn(_cvsFileWriterMock);
    EasyMock.expect(_cvsFileWriterMock.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);
    EasyMock.expect(_cvsFileWriterMock.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);

    _cvsFileWriterMock.flush();
    EasyMock.expectLastCall();

    _cvsFileWriterMock.close();
    EasyMock.expectLastCall();

    ConnectorResponse<Nothing, Retour> retourps023 = new ConnectorResponse<Nothing, Retour>(null, RetourFactory.createOkRetour());
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps023UpdateEnvoiCmdSim(_tracabilite, "1", PP0241_NotificationSAP.PARTIEL)).andReturn(retourps023); //$NON-NLS-1$

    // CALL 4300

    PowerMock.expectNew(BL4300_EnvoyerFichierBuilder.class).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.chaineConnexion(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.repertoire(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.build()).andReturn(_bl4300Mock);
    EasyMock.expect(_bl4300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl4300Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.DONNEE_INVALIDE, null));

    // CALL 1200
    PowerMock.expectNew(BL1200_DeplacerFichierBuilder.class).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireSrc(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireDes(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.build()).andReturn(_bl1200Mock);
    EasyMock.expect(_bl1200Mock.execute(_processInstance)).andReturn(null);

    PowerMock.replayAll();

    _processInstance.run(request);

    Response response = (Response) request.getResponse();

    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    assertEquals(StringConstants.NOK, result.getResultat());
    assertEquals(IMegConsts.CAT1, result.getCategorie());
    assertEquals(IMegConsts.DONNEE_INVALIDE, result.getDiagnostic());
    assertEquals(1, _processInstance.getProcessContext()._listCommandeESim.size());
  }

  /**
   * Test StartProcess <br/>
   * Test OK on checkparameters - Parameter exists is OK <br/>
   * CALL BL100 <br/>
   * CALL GDRPROXY_ps021 and Returns list 1 CMDSIM<br/>
   * CALL GDRPROXY_ps025 and Returns list 1 SUIVISMDP <br/>
   * CALL GDRPROXY_ps024 and Returns list 1 BYTPRD <br/>
   * CALL BL900 and Returns OK and ConfigurationEmission with parameters <br/>
   * CALL BL1300 and Returns OK <br/>
   * CALL GDRPROXY_ps023 and Returns OK <br/>
   * CALL BL4300 and Returns OK <br/>
   * CALL GDRPROXY_ps026 and Returns NOK <br/>
   * <b>Expected:</b>Resultat = "OK"<br/>
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_009() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "file.xml"); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    List<CMDSIM> cmdsimList = new ArrayList<CMDSIM>();
    CMDSIM cmdsimObject = new CMDSIM(1L, null, 1L, null, null, null, null, null, null, null, 10000L, null, null, null, null, "numCMDSAP1", null, null, null, null, null, null, null, null); //$NON-NLS-1$
    cmdsimList.add(cmdsimObject);
    ConnectorResponse<List<CMDSIM>, Retour> gdrResponse = new ConnectorResponse<List<CMDSIM>, Retour>(cmdsimList, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps021GetCommandesNonNotifies(_tracabilite)).andReturn(gdrResponse);

    List<SUIVISMDP> listSUIVISMDP = new ArrayList<SUIVISMDP>();
    listSUIVISMDP.add(new SUIVISMDP(1000L, null, null, 1L, null));
    ConnectorResponse<List<SUIVISMDP>, Retour> gdrResponse1 = new ConnectorResponse<List<SUIVISMDP>, Retour>(listSUIVISMDP, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps025GetSUIVISMDP(_tracabilite, "1")).andReturn(gdrResponse1); //$NON-NLS-1$

    List<BYTPRD> listBYTPRD = new ArrayList<BYTPRD>();

    listBYTPRD.add(new BYTPRD(1L, "typGNC1", "idtARTWRK1", 1L, 1L, "idtFAB1", 1L, 1L, "idtUSASIM1", "codARTSAP1", "libARTSAP1", "debTRAMSI1", "finTRAMSI1", null, 1L)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$

    ConnectorResponse<List<BYTPRD>, Retour> gdrResponse2 = new ConnectorResponse<List<BYTPRD>, Retour>(listBYTPRD, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps024GetBytprd(_tracabilite, "1")).andReturn(gdrResponse2); //$NON-NLS-1$

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(PP0241_NotificationSAP.NOTIFICATION_SAP)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile("file.xml")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(PP0241_NotificationSAP.NOTIFICATION_SAP)).andReturn(_bl900BuilderMock);

    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);

    ConfigurationEmission configurationEmission = new ConfigurationEmission();
    configurationEmission.setCodeFlux(PP0241_NotificationSAP.NOTIFICATION_SAP);
    configurationEmission.setRepertoireTemp("temp"); //$NON-NLS-1$

    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(configurationEmission);

    EasyMock.expect(_bl900Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    String date = DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now());
    String filename = MessageFormat.format(PP0241_NotificationSAP.NOM_FICHIER, date);

    PowerMock.expectNew(BL1300_CreerFichierBuilder.class).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.repertoire(EasyMock.anyObject(String.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.build()).andReturn(_bl1300Mock);
    EasyMock.expect(_bl1300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    EasyMock.expect(Paths.get(EasyMock.anyString())).andReturn(_path);
    PowerMock.expectNew(CSVFileWriter.class, EasyMock.anyObject(File.class)).andReturn(_cvsFileWriterMock);
    EasyMock.expect(_cvsFileWriterMock.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);
    EasyMock.expect(_cvsFileWriterMock.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);

    _cvsFileWriterMock.flush();
    EasyMock.expectLastCall();

    _cvsFileWriterMock.close();
    EasyMock.expectLastCall();

    ConnectorResponse<Nothing, Retour> retourps023 = new ConnectorResponse<Nothing, Retour>(null, RetourFactory.createOkRetour());
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps023UpdateEnvoiCmdSim(_tracabilite, "1", PP0241_NotificationSAP.PARTIEL)).andReturn(retourps023); //$NON-NLS-1$

    // CALL 4300

    PowerMock.expectNew(BL4300_EnvoyerFichierBuilder.class).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.chaineConnexion(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.repertoire(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.build()).andReturn(_bl4300Mock);
    EasyMock.expect(_bl4300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl4300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    // CALL 1200
    PowerMock.expectNew(BL1200_DeplacerFichierBuilder.class).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireSrc(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireDes(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.build()).andReturn(_bl1200Mock);
    EasyMock.expect(_bl1200Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1200Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    ConnectorResponse<Nothing, Retour> retourps026 = new ConnectorResponse<Nothing, Retour>(null, RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, null));
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps026EnregistrerEnvoiFichier(_tracabilite, "1", filename)).andReturn(retourps026); //$NON-NLS-1$

    PowerMock.replayAll();

    _processInstance.run(request);

    Response response = (Response) request.getResponse();

    Retour result = prepareResponse(response);

    PowerMock.verifyAll();
    assertNull(result);

    //assertEquals(StringConstants.OK, result.getResultat());
    assertEquals(1, _processInstance.getProcessContext()._listCommandeESim.size());
  }

  /**
   * Test StartProcess <br/>
   * Test OK on checkparameters - Parameter exists is OK <br/>
   * CALL BL100 <br/>
   * CALL GDRPROXY_ps021 and Returns list 1 CMDSIM<br/>
   * CALL GDRPROXY_ps025 and Returns list 1 SUIVISMDP <br/>
   * CALL GDRPROXY_ps024 and Returns list 1 BYTPRD <br/>
   * CALL BL900 and Returns OK and ConfigurationEmission with parameters <br/>
   * CALL BL1300 and Returns OK <br/>
   * CALL GDRPROXY_ps023 and Returns OK <br/>
   * CALL BL4300 and Returns OK <br/>
   * CALL GDRPROXY_ps026 and Returns NOK <br/>
   * <b>Expected:</b>Resultat = "OK"<br/>
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_009a() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, "file.xml"); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    List<CMDSIM> cmdsimList = new ArrayList<CMDSIM>();
    CMDSIM cmdsimObject = new CMDSIM(1L, null, 1L, null, null, null, null, null, null, null, 10000L, null, null, null, null, "numCMDSAP1", null, null, null, null, null, null, null, null); //$NON-NLS-1$
    cmdsimList.add(cmdsimObject);
    ConnectorResponse<List<CMDSIM>, Retour> gdrResponse = new ConnectorResponse<List<CMDSIM>, Retour>(cmdsimList, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps021GetCommandesNonNotifies(_tracabilite)).andReturn(gdrResponse);

    List<SUIVISMDP> listSUIVISMDP = new ArrayList<SUIVISMDP>();
    listSUIVISMDP.add(new SUIVISMDP(1000L, null, null, 1L, null));
    ConnectorResponse<List<SUIVISMDP>, Retour> gdrResponse1 = new ConnectorResponse<List<SUIVISMDP>, Retour>(listSUIVISMDP, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps025GetSUIVISMDP(_tracabilite, "1")).andReturn(gdrResponse1); //$NON-NLS-1$

    List<BYTPRD> listBYTPRD = new ArrayList<BYTPRD>();

    listBYTPRD.add(new BYTPRD(1L, "typGNC1", "idtARTWRK1", 1L, 1L, "idtFAB1", 1L, 1L, "idtUSASIM1", "codARTSAP1", "libARTSAP1", "debTRAMSI1", "finTRAMSI1", null, 1L)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$

    ConnectorResponse<List<BYTPRD>, Retour> gdrResponse2 = new ConnectorResponse<List<BYTPRD>, Retour>(listBYTPRD, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps024GetBytprd(_tracabilite, "1")).andReturn(gdrResponse2); //$NON-NLS-1$

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(PP0241_NotificationSAP.NOTIFICATION_SAP)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile("file.xml")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(PP0241_NotificationSAP.NOTIFICATION_SAP)).andReturn(_bl900BuilderMock);

    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);

    ConfigurationEmission configurationEmission = new ConfigurationEmission();
    configurationEmission.setCodeFlux(PP0241_NotificationSAP.NOTIFICATION_SAP);
    configurationEmission.setRepertoireTemp("temp"); //$NON-NLS-1$

    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(configurationEmission);

    EasyMock.expect(_bl900Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    String date = DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now());
    String filename = MessageFormat.format(PP0241_NotificationSAP.NOM_FICHIER, date);

    PowerMock.expectNew(BL1300_CreerFichierBuilder.class).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.repertoire(EasyMock.anyObject(String.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.build()).andReturn(_bl1300Mock);
    EasyMock.expect(_bl1300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    EasyMock.expect(Paths.get(EasyMock.anyString())).andReturn(_path);
    PowerMock.expectNew(CSVFileWriter.class, EasyMock.anyObject(File.class)).andReturn(_cvsFileWriterMock);
    EasyMock.expect(_cvsFileWriterMock.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);
    EasyMock.expect(_cvsFileWriterMock.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);

    _cvsFileWriterMock.flush();
    EasyMock.expectLastCall();

    _cvsFileWriterMock.close();
    EasyMock.expectLastCall();

    ConnectorResponse<Nothing, Retour> retourps023 = new ConnectorResponse<Nothing, Retour>(null, RetourFactory.createOkRetour());
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps023UpdateEnvoiCmdSim(_tracabilite, "1", PP0241_NotificationSAP.PARTIEL)).andReturn(retourps023); //$NON-NLS-1$

    // CALL 4300

    PowerMock.expectNew(BL4300_EnvoyerFichierBuilder.class).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.chaineConnexion(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.repertoire(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.build()).andReturn(_bl4300Mock);
    EasyMock.expect(_bl4300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl4300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    // CALL 1200
    PowerMock.expectNew(BL1200_DeplacerFichierBuilder.class).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.nomFichier(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireSrc(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireDes(EasyMock.anyObject(String.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.build()).andReturn(_bl1200Mock);
    EasyMock.expect(_bl1200Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1200Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    ConnectorResponse<Nothing, Retour> retourps026 = new ConnectorResponse<Nothing, Retour>(null, RetourFactory.createOkRetour());
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps026EnregistrerEnvoiFichier(_tracabilite, "1", filename)).andReturn(retourps026); //$NON-NLS-1$

    PowerMock.replayAll();

    _processInstance.run(request);

    Response response = (Response) request.getResponse();

    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    assertNull(result);

    //    assertEquals(StringConstants.OK, result.getResultat());
    assertEquals(1, _processInstance.getProcessContext()._listCommandeESim.size());
  }

  /**
   * Test StartProcess <br/>
   * Test failure on checkparameters - Missing Parameters <br/>
   *
   * <b>Expected:</b>Resultat = "NOK", Category = "CAT-1", Diagnostic = "Configuration_INVALIDE""
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_PARAM000() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    PowerMock.replayAll();

    _processInstance.run(request);
    Response response = (Response) request.getResponse();

    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    assertEquals(StringConstants.NOK, result.getResultat());
    assertEquals(IMegConsts.CAT1, result.getCategorie());
    assertEquals(IMegConsts.CONFIGURATION_INVALIDE, result.getDiagnostic());

  }

  /**
   * Test StartProcess <br/>
   * Test failure on checkparameters - Parameter exists but is Empty <br/>
   *
   * <b>Expected:</b>Resultat = "NOK", Category = "CAT-1", Diagnostic = "Configuration_INVALIDE""
   *
   * @throws Throwable
   *           on errors
   *
   */
  @Test
  public void PP0241_NotificationSAP_Test_PARAM001() throws Throwable
  {

    final Map<String, String> map = new HashMap<>();
    map.put(PP0241_NotificationSAP.FICHIER_DE_CONFIGURATION, ""); //$NON-NLS-1$

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Request request = prepareRequest();

    PowerMock.replayAll();

    _processInstance.run(request);
    Response response = (Response) request.getResponse();

    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    assertEquals(StringConstants.NOK, result.getResultat());
    assertEquals(IMegConsts.CAT1, result.getCategorie());
    assertEquals(IMegConsts.CONFIGURATION_INVALIDE, result.getDiagnostic());

  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initializatioPn
    _processInstance = new PP0241_NotificationSAP();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(null);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    PowerMock.resetAll();
    PowerMock.mockStatic(GDRProxy.class);
    PowerMock.mockStaticStrict(BL900_ObtenirConfigurationEmissionFichier.class);
    PowerMock.mockStaticStrict(BL900_ObtenirConfigurationEmissionFichierBuilder.class);
    PowerMock.mockStatic(BL1300_CreerFichier.class);
    PowerMock.mockStatic(BL1300_CreerFichierBuilder.class);

    PowerMock.mockStatic(BL1200_DeplacerFichier.class);
    PowerMock.mockStatic(BL1200_DeplacerFichierBuilder.class);

    PowerMock.mockStatic(BL4300_EnvoyerFichier.class);
    PowerMock.mockStatic(BL4300_EnvoyerFichierBuilder.class);

    PowerMock.mockStaticNice(Path.class);
    PowerMock.mockStaticNice(Paths.class);
    PowerMock.mockStaticNice(Files.class);
    PowerMock.mockStaticNice(File.class);
    PowerMock.mockStaticNice(CSVFileWriter.class);

  }

  /**
   * @return Request
   * @throws RavelException
   *           Exception
   */
  private Request prepareRequest() throws RavelException
  {
    Request request = new Request(_processInstance.getName(), _processInstance.getMsgId(), _processInstance.getIdProcess());
    request.setHttpMethod(HttpMethod.POST);
    request.setMsgId(_tracabilite.getIdCorrelationSpirit());
    return request;
  }

  /**
   * @param response_p
   *          the response value
   * @return PP0224Retour
   * @throws RavelException
   *           in case error
   */
  private Retour prepareResponse(final Response response_p) throws RavelException
  {
    final Retour response = GsonTools.getIso8601Sec().fromJson(response_p.getGenericResponse().getResult(), Retour.class);

    return response;
  }
}
