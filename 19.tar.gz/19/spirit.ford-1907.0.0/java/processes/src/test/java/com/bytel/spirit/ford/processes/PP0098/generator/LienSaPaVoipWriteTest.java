/*******************************************************************************
* $Id: LienSaPaVoipWriteTest.java 14226 2018-12-06 15:29:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import com.bytel.spirit.ford.processes.TestUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0098.generator.LienSaPaVoipWriter.LienSAPAVOIPHeader;

/**
 *
 * @author vloureir
 * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
 */
public class LienSaPaVoipWriteTest
{

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-LIENSAPAVOIP.csv"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * The Writer to test
   */
  private LienSaPaVoipWriter _writer;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _writer = new LienSaPaVoipWriter(FILENAME, 1);
  }

  /**
   * Scenario: Create two lines<br>
   * Input: The PFI to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void lienSAPAVOIPWrapperTest_01() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienSAPAVOIP_Nominal.json"); //$NON-NLS-1$

    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "valIdSA1", "valIdPA1", "", "valIdSA1", "nomSC1", "VOIP", "0612345678", "1", "valIdPA3", "technologieAcces1", "codeInsee1", "20170518184337", "20170518184337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 12, 10));
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(LienSAPAVOIPHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: test OK with Valid Equipement VOIP but with some fields empty <br>
   * Input: Valid PFI with some empty fields <br>
   * Result: Create a complete line <br>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void lienSAPAVOIPWrapperTest_02() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienSAPAVOIP_WithEmptyFields.json"); //$NON-NLS-1$

    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "valIdSA1", "valIdPA1", "ACTIF", "valIdSA1", "nomSC1", "VOIP", "", "0", "valIdPA1", "technologieAcces1", "codeInsee1", "20170518184337", "20170518184337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2017,12,10));
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(LienSAPAVOIPHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: test OK with Invalid Equipement VOIP <br>
   * Input: Valid PFIof type IAD <br>
   * Result: No Lines created <br>
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void lienSAPAVOIPWrapperTest_03() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienSAPAVOIP_InvalidPFI.json"); //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2018,5,1));
    _writer.close();
  }

}
