/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0378.writers;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.ford.processes.TestUtils;
import com.bytel.spirit.ford.processes.PP0378.writers.CompteHssParFqdnWriter.CompteHssParFqdnHeader;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
public class CompteHssParFqdnWriterTest
{
  /**
   *
   */
  private static final String ESCAPED_QUOTES = "\""; //$NON-NLS-1$

  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-MIGRATION_VIMS.csv"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);
  }

  /**
   * the writer
   */
  CompteHssParFqdnWriter _writer;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Scenario: Create two lines.<br/>
   * Input: The StPfsHSSFixe to be set.<br/>
   * Result: 2 lines are created (Header + record)
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StPfsHSSFixe_Nominal_01() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0378/ServiceTechnique_PFS_HSSFixe.json", SpiritConstants.JSON_PROFILE_SAAB); //$NON-NLS-1$

    String line1 = new StringBuilder() //
        .append(ESCAPED_QUOTES).append("idCompteIms").append(ESCAPED_QUOTES).append(SEMICOLON) //$NON-NLS-1$
        .append(ESCAPED_QUOTES).append("impiFixe").append(ESCAPED_QUOTES).append(SEMICOLON) //$NON-NLS-1$
        .append(ESCAPED_QUOTES).append("sip:+33sipUri@fai.bouygtel.net").append(ESCAPED_QUOTES).append(SEMICOLON) //$NON-NLS-1$
        .append(ESCAPED_QUOTES).append("tel:+33telUri").append(ESCAPED_QUOTES).append(SEMICOLON) //$NON-NLS-1$
        .append(ESCAPED_QUOTES).append("motDePasseIms").append(ESCAPED_QUOTES).append(SEMICOLON) //$NON-NLS-1$
        .append(ESCAPED_QUOTES).append("nomPrenomCourt").append(ESCAPED_QUOTES).append(SEMICOLON) //$NON-NLS-1$
        .append(ESCAPED_QUOTES).append("xDSL;operator-specific-GI=63codeInsee00").append(ESCAPED_QUOTES) //$NON-NLS-1$
        .toString();

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationByTel(this.getClass().getName());
    _writer = new CompteHssParFqdnWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(CompteHssParFqdnHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).replaceAll(ESCAPED_QUOTES, StringConstants.EMPTY_STRING).split(SEMICOLON)).toString());
    assertEquals(line1, lines.get(1));
  }

  /**
   * Scenario: Create two lines.<br/>
   * Input: The StPfsHSSFixe to be set.<br/>
   * Result: 2 lines are created. 1 Header and another with some null and exception during password decryption
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StPfsHSSFixe_Nominal_02() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0378/ServiceTechnique_PFS_HSSFixe_EmptyFields.json", SpiritConstants.JSON_PROFILE_SAAB); //$NON-NLS-1$

    String line1 = new StringBuilder() //
        .append(ESCAPED_QUOTES).append(ESCAPED_QUOTES).append(SEMICOLON) //
        .append(ESCAPED_QUOTES).append("impiFixe").append(ESCAPED_QUOTES).append(SEMICOLON) //$NON-NLS-1$
        .append(ESCAPED_QUOTES).append(ESCAPED_QUOTES).append(SEMICOLON) //
        .append(ESCAPED_QUOTES).append(ESCAPED_QUOTES).append(SEMICOLON) //
        .append(ESCAPED_QUOTES).append(ESCAPED_QUOTES).append(SEMICOLON) //
        .append(ESCAPED_QUOTES).append("nomPrenomCourt").append(ESCAPED_QUOTES).append(SEMICOLON) //$NON-NLS-1$
        .append(ESCAPED_QUOTES).append(ESCAPED_QUOTES) //
        .toString();

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationByTel(this.getClass().getName());
    _writer = new CompteHssParFqdnWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(CompteHssParFqdnHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).replaceAll(ESCAPED_QUOTES, StringConstants.EMPTY_STRING).split(SEMICOLON)).toString());
    assertEquals(line1, lines.get(1));
  }

  /**
   * Scenario: Create zero lines.<br/>
   * Input: The StPfsHSSFixe to be set.<br/>
   * Result: 1 line is created. St is not written in file because DonneesProvisionnes is null
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StPfsHSSFixe_Nominal_03() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0378/ServiceTechnique_PFS_HSSFixe_DonneesProvisionnesNull.json", SpiritConstants.JSON_PROFILE_SAAB); //$NON-NLS-1$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationByTel(this.getClass().getName());
    _writer = new CompteHssParFqdnWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(CompteHssParFqdnHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(1, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).replaceAll(ESCAPED_QUOTES, StringConstants.EMPTY_STRING).split(SEMICOLON)).toString());
  }
}