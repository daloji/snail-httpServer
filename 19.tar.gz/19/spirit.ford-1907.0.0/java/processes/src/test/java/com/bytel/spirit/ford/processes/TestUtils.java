/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.csv.CSVFileReader;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.IRavelJsonAdapter;
import com.bytel.ravel.common.json.RavelJsonException;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.google.gson.JsonSyntaxException;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public final class TestUtils
{

  /**
   * Methode used to load a PFI from a json File
   *
   * @param pfiFile_p
   *          The file to read
   *
   * @return The PFI
   * @throws JsonSyntaxException
   *           Should not happen
   * @throws IOException
   *           Should not happen
   */
  public static PFI buildPFI(String pfiFile_p) throws JsonSyntaxException, IOException
  {
    PFI pfi = GsonTools.getIso8601Ms().fromJson(readFile(pfiFile_p, StandardCharsets.UTF_8), PFI.class);
    return pfi;
  }

  /**
   * Methode used to load a Ressource from a json File
   *
   * @param ressourceFile_p
   *          The file to read
   *
   * @return The Ressource
   * @throws JsonSyntaxException
   *           Should not happen
   * @throws IOException
   *           Should not happen
   */
  public static Ressource buildRessoource(String ressourceFile_p) throws JsonSyntaxException, IOException
  {
    Ressource ressource = GsonTools.getIso8601Ms().fromJson(readFile(ressourceFile_p, StandardCharsets.UTF_8), Ressource.class);
    return ressource;
  }

  /**
   * Methode used to load a ServiceTechnique from a json File
   *
   * @param stFile_p
   *          The file to read
   *
   * @return The ServiceTechnique
   * @throws RavelJsonException
   * @throws JsonSyntaxException
   *           Should not happen
   * @throws IOException
   *           Should not happen
   */
  public static ServiceTechnique buildServiceTechnique(String stFile_p, String jsonProfile_p) throws RavelException, IOException
  {
    ServiceTechnique st = RavelJsonTools.getInstance().fromJson(readFile(stFile_p, StandardCharsets.UTF_8), ServiceTechnique.class, jsonProfile_p);
    return st;
  }

  /**
   * Get datetime in format yyyyMMdd_yyyyMMdd
   *
   * @return The date
   */
  public static String getFileDateTime()
  {
    return DateTimeFormatPattern.yyyyMMdd_underscore_HHmmss.format(LocalDateTime.now());

  }

  /**
   * Get datetime in format yyyyMMddyyyyMMdd
   *
   * @return The date
   */
  public static String getFileDateTimeWithoutUnderscore()
  {
    return DateTimeFormatPattern.yyyyMMddHHmmss.format(LocalDateTime.now());
  }

  /**
   * Reads the CSV file.
   *
   * @param filename
   *          The filename
   *
   * @return the list with the lines that were read from the CSV file
   * @throws IOException
   *           on error
   */
  public static List<String> readFromCSV(String filename) throws IOException
  {
    File file = new File(filename);
    CSVFileReader csvFileReader = new CSVFileReader(file);
    String line;
    List<String> lines = new ArrayList<>();

    while (csvFileReader.hasNext())
    {
      line = csvFileReader.next().toString();
      lines.add(line);
    }

    csvFileReader.close();

    return lines;
  }

  /**
   *
   * @param path_p
   *          file path
   * @param encoding_p
   *          file encoding
   * @return file content
   * @throws IOException
   *           thrown exception
   */
  static String readFile(String path_p, Charset encoding_p) throws IOException
  {
    byte[] encoded = Files.readAllBytes(Paths.get(path_p));
    return new String(encoded, encoding_p);
  }

  IRavelJson _ravelJson = null;

  /**
   *
   */
  private TestUtils()
  {
  }

  /**
   * Serialize objet to jsonn string
   *
   * @param toSerialize_p
   * @return
   * @throws RavelJsonException
   */
  private <T> String serialize(T toSerialize_p) throws RavelException
  {
    IRavelJsonAdapter<Object> adapter = _ravelJson.adapter(Object.class);
    return adapter.toJson(toSerialize_p);
  }
}
