/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang3.RandomStringUtils;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.configuration.ConfigFileManager;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IUrlParameters;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier.BL1300_CreerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier.BL3400_SupprimerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder;
import com.bytel.spirit.common.ford.config.ConfigurationFluxExtraction;
import com.bytel.spirit.common.ford.config.GenericProcessConfig;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.ford.processes.PP0255.PP0255_ExtractionServicesTechniques.PP0255_ExtractionServicesTechniquesContext;
import com.bytel.spirit.saab.connectors.rst.RSTDatabaseProxy;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jbrites
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PP0255_ExtractionServicesTechniques.class, ProcessManager.class, RSTDatabaseProxy.class, BL1300_CreerFichierBuilder.class, BL3400_SupprimerFichier.class, BL3400_SupprimerFichierBuilder.class, BL4300_EnvoyerFichier.class, BL4300_EnvoyerFichierBuilder.class, MarshallTools.class })
public class PP0255_ExtractionServicesTechniquesTest
{

  /**
   *
   */
  private static final String TYPE_SERVICE_TECHNIQUE_ST_PFS = "ST-PFS"; //$NON-NLS-1$
  /**
   *
   */
  private static final String TYPE_SERVICE_TECHNIQUE_ST_LAC = "ST-LAC"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory _podam = new PodamFactoryImpl();

  /**
   * ConfigFileManager singleton
   */
  private static ConfigFileManager _configFileManager;

  /**
   * Path to config file
   */
  private static String _confFilePath;

  /**
   * Temp File Path
   */
  private static String _tempWorkFilePath = null;

  /**
   * Temp File Path
   */
  private static String _tempSuccessFilePath = null;

  /**
   * Temp File Path
   */
  private static String _tempErrorFilePath = null;

  /**
   * Temporary file for tests
   */
  private static File _temp = null;

  /**
   * Temporary file for tests
   */
  private static File _temp1 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp2 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp3 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp4 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp5 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp6 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp7 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp8 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp9 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp10 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp11 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp12 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp13 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp14 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp15 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp16 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp17 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp18 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp19 = null;
  /**
   * Temporary file for tests
   */
  private static File _temp20 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp21 = null;
  /**
   * Temporary file for tests
   */
  private static File _temp22 = null;
  /**
   * The CHAINE_CONNECTION constant
   */
  private static final String CHAINE_CONNECTION_DEFAULT = "sftp://spirittest@gas-y.pin.dolmen.bouyguestelecom.fr:2222/in/spiritqod/in/?sftpkeyfile=/var/run/secrets/TEST_GAS_KEY&auth=publickey"; //$NON-NLS-1$

  /**
   * The EMPTY_DIR constant.
   */
  private static final String EMPTY_DIR = "emptyDir"; //$NON-NLS-1$

  /**
   * Chain that defines the name of the extraction flux.
   */
  private static final String ID_FLUX_EXTRACTION = "idFluxExtraction"; //$NON-NLS-1$ _idFluxExtraction

  /**
   * Mode execution parameter name
   */
  private static final String MODE_EXECUTION_PARAM = "modeExecution"; //$NON-NLS-1$
  /**
   *
   */
  private static final String TYPE_SERVICE_TECHNIQUE_PARAM = "typeServiceTechnique"; //$NON-NLS-1$

  /**
   * The ProduireExtractions constant.
   */
  private static final String PRODUIRE_EXTRACTIONS = "ProduireExtractions"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-LAC constant.
   */
  private static final String SPIRIT_ST_LAC = "SPIRIT-ST-LAC"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-MAIL constant.
   */
  private static final String SPIRIT_ST_PFS_MAIL = "SPIRIT-ST-PFS-MAIL"; //$NON-NLS-1$
  /**
   * The SPIRIT-ST-PFS-OLT constant.
   */
  private static final String SPIRIT_ST_PFS_OLT = "SPIRIT-ST-PFS-OLT"; //$NON-NLS-1$
  /**
   * The SPIRIT-ST-PFS-SAM constant.
   */
  private static final String SPIRIT_ST_PFS_SAM = "SPIRIT-ST-PFS-SAM"; //$NON-NLS-1$
  /**
   * The SPIRIT-ST-PFS-CLF constant.
   */
  private static final String SPIRIT_ST_PFS_CLF = "SPIRIT-ST-PFS-CLF"; //$NON-NLS-1$
  /**
   * The SPIRIT-ST-PFS-PNF constant.
   */
  private static final String SPIRIT_ST_PFS_PNF = "SPIRIT-ST-PFS-PNF"; //$NON-NLS-1$
  /**
   * The SPIRIT-ST-PFS-STW constant.
   */
  private static final String SPIRIT_ST_PFS_VMS_STW = "SPIRIT-ST-PFS-VMS-STW"; //$NON-NLS-1$
  /**
   * The SPIRIT-ST-PFS-CVM constant.
   */
  private static final String SPIRIT_ST_PFS_VMS_CVM = "SPIRIT-ST-PFS-VMS-CVM"; //$NON-NLS-1$
  /**
   * The SPIRIT-ST-PFS-ACS_IAD constant.
   */
  private static final String SPIRIT_ST_PFS_ACS_IAD = "SPIRIT-ST-PFS-ACS_IAD"; //$NON-NLS-1$
  /**
   * The SPIRIT_ST_PFS_FQDN constant.
   */
  private static final String SPIRIT_ST_PFS_FQDN = "SPIRIT-ST-PFS-FQDN"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-HSS-FIXE constant.
   */
  private static final String SPIRIT_ST_PFS_HSS_FIXE = "SPIRIT-ST-PFS-HSS_FIXE"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-TAS-FIXE constant.
   */
  private static final String SPIRIT_ST_PFS_TAS_FIXE = "SPIRIT-ST-PFS-TAS_FIXE"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-ENUM constant.
   */
  private static final String SPIRIT_ST_PFS_ENUM = "SPIRIT-ST-PFS-ENUM"; //$NON-NLS-1$
  /**
   * The TransfererFichiers constant.
   */
  private static final String TRANSFERER_FICHIERS = "TransfererFichiers"; //$NON-NLS-1$

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    _configFileManager = new ConfigFileManager("."); //$NON-NLS-1$
    _podam = new PodamFactoryImpl();
  }

  /**
   * @return GenericProcessConfig
   */
  private static GenericProcessConfig createDefaultConfig()
  {
    GenericProcessConfig genericProcessConfig = new GenericProcessConfig();
    genericProcessConfig.setActivateMultiThread(true);
    genericProcessConfig.setCheminRepArchiveErreur(_tempErrorFilePath);
    genericProcessConfig.setCheminRepArchiveSucces(_tempSuccessFilePath);
    genericProcessConfig.setCheminRepTravail(_tempWorkFilePath);
    genericProcessConfig.setDureeRetentionTmp(0);
    genericProcessConfig.setEndingTimeout(1000);
    genericProcessConfig.setExtensionFichierTemporaire(".tmp"); //$NON-NLS-1$
    genericProcessConfig.setLinesToFlush(5);
    genericProcessConfig.setPoolSize(2);
    genericProcessConfig.setPushTimeout(1000);
    genericProcessConfig.setWaitingFileSize(2);

    ConfigurationFluxExtraction confFluxExtraction1 = new ConfigurationFluxExtraction();
    confFluxExtraction1.setIdFluxExtraction(SPIRIT_ST_LAC);
    confFluxExtraction1.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction1.setPattern(SPIRIT_ST_LAC + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction2 = new ConfigurationFluxExtraction();
    confFluxExtraction2.setIdFluxExtraction(SPIRIT_ST_PFS_MAIL);
    confFluxExtraction2.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction2.setPattern(SPIRIT_ST_PFS_MAIL + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction3 = new ConfigurationFluxExtraction();
    confFluxExtraction3.setIdFluxExtraction(SPIRIT_ST_PFS_OLT);
    confFluxExtraction3.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction3.setPattern(SPIRIT_ST_PFS_OLT + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction4 = new ConfigurationFluxExtraction();
    confFluxExtraction4.setIdFluxExtraction(SPIRIT_ST_PFS_SAM);
    confFluxExtraction4.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction4.setPattern(SPIRIT_ST_PFS_SAM + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction5 = new ConfigurationFluxExtraction();
    confFluxExtraction5.setIdFluxExtraction(SPIRIT_ST_PFS_CLF);
    confFluxExtraction5.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction5.setPattern(SPIRIT_ST_PFS_CLF + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction6 = new ConfigurationFluxExtraction();
    confFluxExtraction6.setIdFluxExtraction(SPIRIT_ST_PFS_PNF);
    confFluxExtraction6.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction6.setPattern(SPIRIT_ST_PFS_PNF + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction7 = new ConfigurationFluxExtraction();
    confFluxExtraction7.setIdFluxExtraction(SPIRIT_ST_PFS_VMS_STW);
    confFluxExtraction7.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction7.setPattern(SPIRIT_ST_PFS_VMS_STW + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction8 = new ConfigurationFluxExtraction();
    confFluxExtraction8.setIdFluxExtraction(SPIRIT_ST_PFS_ACS_IAD);
    confFluxExtraction8.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction8.setPattern(SPIRIT_ST_PFS_ACS_IAD + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction9 = new ConfigurationFluxExtraction();
    confFluxExtraction9.setIdFluxExtraction(SPIRIT_ST_PFS_FQDN);
    confFluxExtraction9.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction9.setPattern(SPIRIT_ST_PFS_FQDN + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction10 = new ConfigurationFluxExtraction();
    confFluxExtraction10.setIdFluxExtraction(SPIRIT_ST_PFS_VMS_CVM);
    confFluxExtraction10.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction10.setPattern(SPIRIT_ST_PFS_VMS_CVM + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction11 = new ConfigurationFluxExtraction();
    confFluxExtraction11.setIdFluxExtraction(SPIRIT_ST_PFS_HSS_FIXE);
    confFluxExtraction11.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction11.setPattern(SPIRIT_ST_PFS_HSS_FIXE + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confFluxExtraction12 = new ConfigurationFluxExtraction();
    confFluxExtraction12.setIdFluxExtraction(SPIRIT_ST_PFS_TAS_FIXE);
    confFluxExtraction12.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction12.setPattern(SPIRIT_ST_PFS_TAS_FIXE + ".*"); //$NON-NLS-1$

    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction1);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction2);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction3);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction4);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction5);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction6);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction7);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction8);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction9);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction10);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction11);
    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction12);
    genericProcessConfig.setIdFluxExtractionAutorises(SPIRIT_ST_LAC + ";" + SPIRIT_ST_PFS_MAIL + ";" + SPIRIT_ST_PFS_OLT + ";" + SPIRIT_ST_PFS_SAM + ";" + SPIRIT_ST_PFS_CLF + ";" + SPIRIT_ST_PFS_PNF + ";" + SPIRIT_ST_PFS_VMS_STW + ";" + SPIRIT_ST_PFS_ACS_IAD + ";" + SPIRIT_ST_PFS_FQDN + ";" + SPIRIT_ST_PFS_VMS_CVM + ";" + SPIRIT_ST_PFS_HSS_FIXE + ";" + SPIRIT_ST_PFS_TAS_FIXE); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$

    return genericProcessConfig;
  }

  /**
   * Create Dir for Tests
   *
   */
  private static void createDummieDirFilesAndConfig()
  {
    File classpath = new File(PP0255_ExtractionServicesTechniquesTest.class.getResource("/").getFile()); //$NON-NLS-1$
    _temp = new File(classpath, "temp" + RandomStringUtils.random(10)); //$NON-NLS-1$;
    _temp.mkdir();

    _temp1 = null;
    _temp2 = null;
    _temp3 = null;
    _temp4 = null;
    _temp5 = null;
    _temp6 = null;
    _temp7 = null;
    _temp8 = null;
    _temp9 = null;
    _temp10 = null;
    _temp11 = null;
    _temp12 = null;
    _temp13 = null;
    _temp14 = null;
    _temp15 = null;
    _temp16 = null;
    _temp17 = null;
    _temp18 = null;
    _temp19 = null;
    _temp20 = null;
    _temp21 = null;
    _temp22 = null;

    try
    {
      File confFile = new File(_temp, "conf.xml"); //$NON-NLS-1$
      confFile.createNewFile();

      File workFolder = new File(_temp, "work"); //$NON-NLS-1$
      workFolder.mkdir();
      File successFolder = new File(_temp, "success");//$NON-NLS-1$
      successFolder.mkdir();
      File errorFolder = new File(_temp, "error");//$NON-NLS-1$
      errorFolder.mkdir();

      _temp1 = File.createTempFile(SPIRIT_ST_LAC + "01", ".csv.tmp", workFolder); //$NON-NLS-1$ //$NON-NLS-2$
      _temp2 = File.createTempFile(SPIRIT_ST_LAC + "02", ".csv", workFolder); //$NON-NLS-1$ //$NON-NLS-2$
      _temp3 = File.createTempFile(SPIRIT_ST_PFS_MAIL + "01", ".csv.tmp", workFolder); //$NON-NLS-1$ //$NON-NLS-2$
      _temp4 = File.createTempFile(SPIRIT_ST_PFS_MAIL + "02", ".csv", workFolder); //$NON-NLS-1$ //$NON-NLS-2$
      _temp5 = File.createTempFile(SPIRIT_ST_PFS_OLT + "01", ".csv.tmp", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp6 = File.createTempFile(SPIRIT_ST_PFS_OLT + "02", ".csv", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp7 = File.createTempFile(SPIRIT_ST_PFS_SAM + "01", ".csv.tmp", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp8 = File.createTempFile(SPIRIT_ST_PFS_SAM + "02", ".csv", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp9 = File.createTempFile(SPIRIT_ST_PFS_CLF + "01", ".csv.tmp", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp10 = File.createTempFile(SPIRIT_ST_PFS_CLF + "02", ".csv", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp11 = File.createTempFile(SPIRIT_ST_PFS_PNF + "01", ".csv.tmp", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp12 = File.createTempFile(SPIRIT_ST_PFS_PNF + "02", ".csv", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp13 = File.createTempFile(SPIRIT_ST_PFS_VMS_STW + "01", ".csv.tmp", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp14 = File.createTempFile(SPIRIT_ST_PFS_VMS_STW + "02", ".csv", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp15 = File.createTempFile(SPIRIT_ST_PFS_ACS_IAD + "01", ".csv.tmp", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp16 = File.createTempFile(SPIRIT_ST_PFS_ACS_IAD + "02", ".csv", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp17 = File.createTempFile(SPIRIT_ST_PFS_FQDN + "01", ".csv.tmp", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp18 = File.createTempFile(SPIRIT_ST_PFS_FQDN + "02", ".csv", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp19 = File.createTempFile(SPIRIT_ST_PFS_ENUM + "01", ".csv.tmp", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp20 = File.createTempFile(SPIRIT_ST_PFS_ENUM + "02", ".csv", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp21 = File.createTempFile(SPIRIT_ST_PFS_VMS_CVM + "01", ".csv.tmp", workFolder); //$NON-NLS-1$//$NON-NLS-2$
      _temp22 = File.createTempFile(SPIRIT_ST_PFS_VMS_CVM + "02", ".csv", workFolder); //$NON-NLS-1$//$NON-NLS-2$

      //Get temporary file path
      _tempWorkFilePath = workFolder.getAbsolutePath() + File.separator;
      _tempSuccessFilePath = successFolder.getAbsolutePath() + File.separator;
      _tempErrorFilePath = errorFolder.getAbsolutePath() + File.separator;

      GenericProcessConfig genericProcessConfig = createDefaultConfig();

      JAXBContext jaxbContext = JAXBContext.newInstance(GenericProcessConfig.class);
      Marshaller marshaller = jaxbContext.createMarshaller();
      marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

      _confFilePath = confFile.getAbsolutePath();
      FileOutputStream fos = new FileOutputStream(confFile);
      marshaller.marshal(genericProcessConfig, fos);
    }
    catch (IOException exception)
    {
      exception.printStackTrace();
    }
    catch (JAXBException jaxbException)
    {
      jaxbException.printStackTrace();
    }
  }

  /**
   * Create Request for tests
   *
   * @param option_p
   *          test option
   * @param typeServiceTechnique_p
   *          typeServiceTechnique
   * @return return Request
   * @throws RavelException
   *           ravel Exception
   */
  private static Request createRequest(Integer option_p, String typeServiceTechnique_p) throws RavelException
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(IHttpHeadersConsts.X_REQUEST_ID);
    requestHeader.setValue("PP0255"); //$NON-NLS-1$

    Request request = new Request("PP0255_ExtractionServicesTechniques", StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING); //$NON-NLS-1$
    request.getRequestHeader().add(requestHeader);

    List<Parameter> parameters = new ArrayList<>();
    Parameter parameterModeExec = null;
    Parameter parameterIdFluxExtraction = null;
    IUrlParameters urlParameters = null;

    switch (option_p)
    {
      case 1:
        parameterModeExec = new Parameter(MODE_EXECUTION_PARAM, PRODUIRE_EXTRACTIONS);
        parameters.add(parameterModeExec);

        break;
      case 2:
        parameterModeExec = new Parameter(MODE_EXECUTION_PARAM, "X"); //$NON-NLS-1$
        parameters.add(parameterModeExec);

        break;
      case 3:
        parameterModeExec = new Parameter(MODE_EXECUTION_PARAM, TRANSFERER_FICHIERS);
        parameters.add(parameterModeExec);

        break;
      case 4:
        request.getRequestHeader().remove(0);
        break;
      default:
        break;
    }
    if (StringTools.isNotNullOrEmpty(typeServiceTechnique_p))
    {
      parameterIdFluxExtraction = new Parameter(TYPE_SERVICE_TECHNIQUE_PARAM, typeServiceTechnique_p);
      parameters.add(parameterIdFluxExtraction);
    }
    urlParameters = new UrlParameters(parameters);
    request.setUrlParameters(urlParameters);

    return request;
  }

  /**
   * RST database proxy mock
   */
  @MockStrict
  private RSTDatabaseProxy _rstDatabaseProxy;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  private ProcessManager _processManager;

  /**
   * process testé
   */
  private PP0255_ExtractionServicesTechniques _currentProcess;

  /**
   * Context of PP0255
   */
  PP0255_ExtractionServicesTechniquesContext _processContext;

  /**
   * Mock de {@link BL1300_CreerFichier}
   */
  @MockStrict
  BL1300_CreerFichier _bl1300Mock;

  /**
   * Mock de {@link BL1300_CreerFichierBuilder}
   */
  @MockStrict
  BL1300_CreerFichierBuilder _bl1300BuilderMock;

  /**
   * Mock de {@link BL3400_SupprimerFichier}
   */
  @MockStrict
  BL3400_SupprimerFichier _bl3400Mock;

  /**
   * Mock de {@link BL3400_SupprimerFichierBuilder}
   */
  @MockStrict
  BL3400_SupprimerFichierBuilder _bl3400BuilderMock;

  /**
   * Mock de {@link BL4300_EnvoyerFichier}
   */
  @MockStrict
  BL4300_EnvoyerFichier _bl4300Mock;

  /**
   * Mock de {@link BL4300_EnvoyerFichierBuilder}
   */
  @MockStrict
  BL4300_EnvoyerFichierBuilder _bl4300BuilderMock;

  /**
   * Cleans the Connector Mocks responses
   *
   * @throws Exception
   *           On Error
   */
  @Before
  public void beforeTest() throws Exception
  {
    _currentProcess = new PP0255_ExtractionServicesTechniques();
    _currentProcess.initializeContext();

    _processContext = (PP0255_ExtractionServicesTechniquesContext) JUnitTools.getInaccessibleFieldValue(_currentProcess, "_processContext"); //$NON-NLS-1$

    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(BL1300_CreerFichier.class);
    PowerMock.mockStaticStrict(BL1300_CreerFichierBuilder.class);
    PowerMock.mockStaticStrict(BL3400_SupprimerFichier.class);
    PowerMock.mockStaticStrict(BL3400_SupprimerFichierBuilder.class);
    PowerMock.mockStaticStrict(BL4300_EnvoyerFichier.class);
    PowerMock.mockStaticStrict(BL4300_EnvoyerFichierBuilder.class);
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStaticStrict(RSTDatabaseProxy.class);
    createDummieDirFilesAndConfig();
  }

  /**
   * Delete temp File
   */
  @After
  public void end()
  {
    _temp1.deleteOnExit();
    _temp2.deleteOnExit();
    _temp3.deleteOnExit();
    _temp4.deleteOnExit();
    _temp5.deleteOnExit();
    _temp6.deleteOnExit();
    _temp7.deleteOnExit();
    _temp8.deleteOnExit();
    _temp9.deleteOnExit();
    _temp10.deleteOnExit();
    _temp11.deleteOnExit();
    _temp12.deleteOnExit();
    _temp13.deleteOnExit();
    _temp14.deleteOnExit();
    _temp15.deleteOnExit();
    _temp16.deleteOnExit();
    _temp17.deleteOnExit();
    _temp18.deleteOnExit();
    _temp19.deleteOnExit();
    _temp20.deleteOnExit();
    _temp21.deleteOnExit();
    _temp22.deleteOnExit();
    _temp.deleteOnExit();
  }

  /**
   * Test case NOK BL001, No chaine de connexion on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0255_ExtractionServicesTechniques_Test_NOK_01() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    conf.getConfigurationFluxExtraction().get(0).setChaineConnexion(""); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(1).setChaineConnexion(""); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(2).setChaineConnexion(""); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(3).setChaineConnexion(""); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(4).setChaineConnexion(""); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(5).setChaineConnexion(""); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(6).setChaineConnexion(""); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(7).setChaineConnexion(""); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(8).setChaineConnexion(""); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(9).setChaineConnexion(""); //$NON-NLS-1$

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    PowerMock.replayAll();

    Request request = createRequest(3, null);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config chaineConnexion sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());
  }

  /**
   * Test case NOK BL001, no valid idFluxExtraction parameter </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0255_ExtractionServicesTechniques_Test_NOK_02() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    conf.setIdFluxExtractionAutorises("SPIRIT-ST-PFS-MAIL; ST-TOTO"); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(0).setIdFluxExtraction("invalid"); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(1).setIdFluxExtraction("invalid"); //$NON-NLS-1$

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    PowerMock.replayAll();

    Request request = createRequest(3, null);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Le paramètre de config idFluxExtraction ST-TOTO est invalide."; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());
  }

  /**
   * Test nominal case SPIRIT-ST-LAC, modeExecution=PRODUIRE_EXTRACTIONS, GenericProcessConfig with values, BL1200 OK
   * and Result OK.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0255_ExtractionServicesTechniques_Test_OK_01() throws Throwable
  {
    // Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    // Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    // BL1300 return OK
    mockBL1300(RetourFactory.createOkRetour(), 1);

    // RST returns OK
    mockRSTDatabaseProxygetAllActiveStLienAllocationCommercial(1);

    PowerMock.replayAll();

    //modeExecution=PRODUIRE_EXTRACTIONS, idFluxExtraction=SPIRIT-ST-LAC
    Request request = createRequest(1, TYPE_SERVICE_TECHNIQUE_ST_LAC);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test nominal case SPIRIT-ST-PFS, modeExecution=PRODUIRE_EXTRACTIONS, GenericProcessConfig with values, BL1200 OK
   * and Result OK.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0255_ExtractionServicesTechniques_Test_OK_02() throws Throwable
  {
    // Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    // Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    // BL1200 returns OK twice

    // BL1300 return OK
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-MAIL
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-OLT
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-SAM
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-CLF
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-PNF
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-VMS_STW
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-ACS_IAD
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-FQDN
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-VMS_CVM
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-HSS-FIXE
    mockBL1300(RetourFactory.createOkRetour(), 1);//call for ST-PFS-TAS-FIXE

    // RST returns OK
    mockRSTDatabaseProxygetAllActiveStPfs(1);

    PowerMock.replayAll();

    //modeExecution=PRODUIRE_EXTRACTIONS, typeServiceTechnique=ST-PFS
    Request request = createRequest(1, TYPE_SERVICE_TECHNIQUE_ST_PFS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test nominal case conf: SPIRIT-ST-LAC: SPIRIT-ST-PFS-MAIL, modeExecution=TRANSFERER_FICHIERS, GenericProcessConfig
   * with values, BL1200 OK and Result OK.</br>
   *
   * The temp dir contains the following files:
   *
   * SPIRIT_ST_LAC01.csv.tmp -> Mock BL3400 to delete tmp file </br>
   * SPIRIT_ST_LAC02.csv -> Mock BL4300 to send the file to repertoire cible</br>
   * SPIRIT_ST_PFS_MAIL01.csv.tmp -> Mock BL3400 to delete tmp file </br>
   * SPIRIT_ST_PFS_MAIL02.csv -> Mock BL4300 to send the file to repertoire cible</br>
   * SPIRIT_ST_PFS_OLT01.csv.tmp -> Mock BL3400 to delete tmp file </br>
   * SPIRIT_ST_PFS_OLT02.csv -> Mock BL4300 to send the file to repertoire cible</br>
   * SPIRIT_ST_PFS_SAM01.csv.tmp -> Mock BL3400 to delete tmp file </br>
   * SPIRIT_ST_PFS_SAM02.csv -> Mock BL4300 to send the file to repertoire cible</br>
   * SPIRIT_ST_PFS_CLF01.csv.tmp -> Mock BL3400 to delete tmp file </br>
   * SPIRIT_ST_PFS_CLF02.csv -> Mock BL4300 to send the file to repertoire cible</br>
   * SPIRIT_ST_PFS_PNF01.csv.tmp -> Mock BL3400 to delete tmp file </br>
   * SPIRIT_ST_PFS_PNF02.csv -> Mock BL4300 to send the file to repertoire cible</br>
   * SPIRIT_ST_PFS_VMS_STW01.csv.tmp -> Mock BL3400 to delete tmp file </br>
   * SPIRIT_ST_PFS_VMS_STW02.csv -> Mock BL4300 to send the file to repertoire cible</br>
   * SPIRIT_ST_PFS_ACS_IAD01.csv.tmp -> Mock BL3400 to delete tmp file </br>
   * SPIRIT_ST_PFS_ACS_IAD02.csv -> Mock BL4300 to send the file to repertoire cible</br>
   * SPIRIT_ST_PFS_FQDN01.csv.tmp -> Mock BL3400 to delete tmp file </br>
   * SPIRIT_ST_PFS_FQDN02.csv -> Mock BL4300 to send the file to repertoire cible</br>
   * SPIRIT_ST_PFS_VMS_CVM01.csv.tmp -> Mock BL3400 to delete tmp file </br>
   * SPIRIT_ST_PFS_VMS_CVM02.csv -> Mock BL4300 to send the file to repertoire cible</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0255_ExtractionServicesTechniques_Test_OK_03() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    //First File with .tmp extension found
    // BL3400 OK
    mockBL3400(RetourFactory.createOkRetour(), 1);

    //Second File without .tmp extension found
    // BL4300 OK
    mockBL4300(RetourFactory.createOkRetour(), 1);

    //Second File with .tmp extension found
    // BL3400 OK
    mockBL3400(RetourFactory.createOkRetour(), 1);

    //Second File without .tmp extension found
    // BL4300 OK
    mockBL4300(RetourFactory.createOkRetour(), 1);

    //Second File with .tmp extension found
    // BL3400 OK
    mockBL3400(RetourFactory.createOkRetour(), 1);

    //Second File without .tmp extension found
    // BL4300 OK
    mockBL4300(RetourFactory.createOkRetour(), 1);

    //Second File with .tmp extension found
    // BL3400 OK
    mockBL3400(RetourFactory.createOkRetour(), 1);

    //Second File without .tmp extension found
    // BL4300 OK
    mockBL4300(RetourFactory.createOkRetour(), 1);

    //Second File with .tmp extension found
    // BL3400 OK
    mockBL3400(RetourFactory.createOkRetour(), 1);

    //Second File without .tmp extension found
    // BL4300 OK
    mockBL4300(RetourFactory.createOkRetour(), 1);

    //Second File with .tmp extension found
    // BL3400 OK
    mockBL3400(RetourFactory.createOkRetour(), 1);

    //Second File without .tmp extension found
    // BL4300 OK
    mockBL4300(RetourFactory.createOkRetour(), 1);

    //Second File with .tmp extension found
    // BL3400 OK
    mockBL3400(RetourFactory.createOkRetour(), 1);

    //Second File without .tmp extension found
    // BL4300 OK
    mockBL4300(RetourFactory.createOkRetour(), 1);

    //Second File with .tmp extension found
    // BL3400 OK
    mockBL3400(RetourFactory.createOkRetour(), 1);

    //Second File without .tmp extension found
    // BL4300 OK
    mockBL4300(RetourFactory.createOkRetour(), 1);

    //Second File with .tmp extension found
    // BL3400 OK
    mockBL3400(RetourFactory.createOkRetour(), 1);

    //Second File without .tmp extension found
    // BL4300 OK
    mockBL4300(RetourFactory.createOkRetour(), 1);

    //Second File with .tmp extension found
    // BL3400 OK
    mockBL3400(RetourFactory.createOkRetour(), 1);

    //Second File without .tmp extension found
    // BL4300 OK
    mockBL4300(RetourFactory.createOkRetour(), 1);

    // BL1200 OK

    PowerMock.replayAll();

    //modeExecution=TRANSFERER_FICHIERS
    Request request = createRequest(3, null);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Delete dir of tests
   *
   * @param name_p
   *          Dir Name
   */
  private void deleteDummieDir(String name_p)
  {
    Path pathTests = Paths.get(name_p);

    //if file exists?
    if (Files.exists(pathTests))
    {
      try
      {
        Files.delete(pathTests);
      }
      catch (IOException exception)
      {
        exception.printStackTrace();
      }
    }
  }

  /**
   * Method for returning Retour from Request
   *
   * @param request
   *          Request
   * @return Retour
   */
  private com.bytel.ravel.types.Retour getRetourFromRequest(Request request)
  {
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    return GsonTools.getIso8601Ms().fromJson(resp, com.bytel.ravel.types.Retour.class);
  }

  /**
   * Load parameters for loadConfiguration values
   *
   * @param option
   *          option for specific alterations
   *
   * @return return Parameters
   */
  private ConcurrentHashMap<String, Map<String, String>> loadParameters(Integer option)
  {
    Map<String, String> myMap = new ConcurrentHashMap<>();

    myMap.put("FILE_PATH", _confFilePath); //$NON-NLS-1$

    switch (option)
    {
      case 0:
        myMap.clear();
        break;
      case 1:
        myMap.replace("cheminRepTravail", "targetx"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      case 2:
        myMap.replace("cheminRepArchiveSucces", "targetx"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      case 3:
        myMap.replace("cheminRepArchiveErreur", "targetx"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      case 4:
        myMap.replace("cheminRepTravail", EMPTY_DIR); //$NON-NLS-1$
        break;
      default:
        break;
    }

    ConcurrentHashMap<String, Map<String, String>> finalParameters = new ConcurrentHashMap<>();
    finalParameters.put("", myMap); //$NON-NLS-1$

    return finalParameters;
  }

  /**
   * Mock method of BL1300_CreerFichier
   *
   * @param bl1300Retour_p
   *          Retour of BL1300
   * @param optionRetour
   *          Type of Retour option
   * @throws Exception
   *           Exception
   */
  private void mockBL1300(Retour bl1300Retour_p, Integer optionRetour) throws Exception
  {
    PowerMock.expectNew(BL1300_CreerFichierBuilder.class).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.repertoire(EasyMock.anyString())).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.nomFichier(EasyMock.anyString())).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.build()).andReturn(_bl1300Mock);

    switch (optionRetour)
    {
      case 1:
        EasyMock.expect(_bl1300Mock.execute(_currentProcess)).andReturn(null);
        EasyMock.expect(_bl1300Mock.getRetour()).andReturn(bl1300Retour_p);
        break;
      case 2:
        EasyMock.expect(_bl1300Mock.execute(_currentProcess)).andThrow(new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));
        break;
      default:
        break;
    }
  }

  /**
   * Mock method of BL3400_SupprimerFichier
   *
   * @param bl3400Retour_p
   *          Retour of BL3400
   * @param optionRetour
   *          Type of Retour option
   * @throws Exception
   *           Exception
   */
  private void mockBL3400(Retour bl3400Retour_p, Integer optionRetour) throws Exception
  {
    PowerMock.expectNew(BL3400_SupprimerFichierBuilder.class).andReturn(_bl3400BuilderMock);
    EasyMock.expect(_bl3400BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl3400BuilderMock);
    EasyMock.expect(_bl3400BuilderMock.fileName(EasyMock.anyString())).andReturn(_bl3400BuilderMock);
    EasyMock.expect(_bl3400BuilderMock.repertoire(EasyMock.anyString())).andReturn(_bl3400BuilderMock);
    EasyMock.expect(_bl3400BuilderMock.build()).andReturn(_bl3400Mock);

    switch (optionRetour)
    {
      case 1:
        EasyMock.expect(_bl3400Mock.execute(_currentProcess)).andReturn(null);
        //EasyMock.expect(_bl3400Mock.getRetour()).andReturn(bl3400Retour_p);
        break;
      case 2:
        EasyMock.expect(_bl3400Mock.execute(_currentProcess)).andThrow(new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));
        break;
      default:
        break;
    }
  }

  /**
   * Mock method of BL4300_EnvoyerFichier
   *
   * @param bl4300Retour_p
   *          Retour of BL4300
   * @param optionRetour
   *          Type of Retour option
   * @throws Exception
   *           Exception
   */
  private void mockBL4300(Retour bl4300Retour_p, Integer optionRetour) throws Exception
  {
    PowerMock.expectNew(BL4300_EnvoyerFichierBuilder.class).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.chaineConnexion(EasyMock.anyString())).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.nomFichier(EasyMock.anyString())).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.repertoire(EasyMock.anyString())).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.build()).andReturn(_bl4300Mock);

    switch (optionRetour)
    {
      case 1:
        EasyMock.expect(_bl4300Mock.execute(_currentProcess)).andReturn(null);
        EasyMock.expect(_bl4300Mock.getRetour()).andReturn(bl4300Retour_p);
        break;
      case 2:
        EasyMock.expect(_bl4300Mock.execute(_currentProcess)).andThrow(new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));
        break;
      default:
        break;
    }
  }

  /**
   * Mock of method getAllActiveStLienAllocationCommercial of class RSTDatabaseProxy
   *
   * @param option
   *          option for Retour: 1 - OK; 2 - NOK; 3 - NOK TIMEOUT; 4 - NOK DONNEE_INCONNUE
   * @throws RavelException
   *           Ravel Exception
   */
  private void mockRSTDatabaseProxygetAllActiveStLienAllocationCommercial(Integer option) throws RavelException
  {

    ConnectorResponse<Retour, Nothing> response = null;
    switch (option)
    {
      case 1:
        response = new ConnectorResponse<>(RetourFactory.createOkRetour(), null);
        break;
      case 2:
        response = new ConnectorResponse<>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), null);
        break;
      case 3:
        response = new ConnectorResponse<>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, IMegSpiritConsts.TIMEOUT, StringConstants.EMPTY_STRING), null);
        break;
      case 4:
        response = new ConnectorResponse<>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING), null);
        break;
      default:
        break;
    }

    EasyMock.expect(RSTDatabaseProxy.getInstance()).andReturn(_rstDatabaseProxy);
    EasyMock.expect(_rstDatabaseProxy.getAllActiveStLienAllocationCommercial(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(response);
  }

  /**
   * Mock of method getAllActiveStPfsMail of class RSTDatabaseProxy
   *
   * @param option
   *          option for Retour: 1 - OK; 2 - NOK; 3 - NOK TIMEOUT; 4 - NOK DONNEE_INCONNUE
   * @throws RavelException
   *           Ravel Exception
   */
  private void mockRSTDatabaseProxygetAllActiveStPfs(Integer option) throws RavelException
  {

    ConnectorResponse<Retour, Nothing> response = null;
    switch (option)
    {
      case 1:
        response = new ConnectorResponse<>(RetourFactory.createOkRetour(), null);
        break;
      case 2:
        response = new ConnectorResponse<>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), null);
        break;
      case 3:
        response = new ConnectorResponse<>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, IMegSpiritConsts.TIMEOUT, StringConstants.EMPTY_STRING), null);
        break;
      case 4:
        response = new ConnectorResponse<>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING), null);
        break;
      default:
        break;
    }

    EasyMock.expect(RSTDatabaseProxy.getInstance()).andReturn(_rstDatabaseProxy);
    EasyMock.expect(_rstDatabaseProxy.getAllActiveStPfs(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(response);
  }
}