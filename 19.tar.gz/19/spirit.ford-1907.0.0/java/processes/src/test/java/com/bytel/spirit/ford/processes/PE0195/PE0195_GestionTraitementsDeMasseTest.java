/*******************************************************************************
* $Id: PE0195_GestionTraitementsDeMasseTest.java 23458 2019-07-02 10:48:53Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PE0195;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Stream;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.data.exchange.generated.RavelResponse.ResponseHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IUrlParameters;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1000_ObtenirConfigurationReceptionFichier;
import com.bytel.spirit.common.activities.shared.BL1000_ObtenirConfigurationReceptionFichier.BL1000_ObtenirConfigurationReceptionFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier.BL1300_CreerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.BL900_ObtenirConfigurationEmissionFichier;
import com.bytel.spirit.common.activities.shared.BL900_ObtenirConfigurationEmissionFichier.BL900_ObtenirConfigurationEmissionFichierBuilder;
import com.bytel.spirit.common.activities.shared.structs.ConfigurationEmission;
import com.bytel.spirit.common.activities.shared.structs.ConfigurationReception;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.connectors.rex.REXProxy;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.AssociationPfiReconcialitionCommerciale;
import com.bytel.spirit.common.shared.saab.rex.ReconciliationCommerciale;
import com.bytel.spirit.common.shared.saab.rex.Statut;
import com.bytel.spirit.common.shared.saab.rex.TraitementDeMasse;
import com.bytel.spirit.common.shared.saab.rex.TypeTraitement;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PE0195.PE0195_GestionTraitementsDeMasse.ParameterUrl;
import com.bytel.spirit.ford.processes.PE0195.structs.Link;
import com.bytel.spirit.ford.processes.PE0195.structs.PE0195_GestionTraitementsDeMasseResponse;
import com.bytel.spirit.ford.processes.PE0195.structs.PE0195_GestionTraitementsDeMasseUnitaireResponse;
import com.bytel.spirit.ford.processes.PE0195.structs.PE0195_PostBodyRequest;
import com.bytel.spirit.ford.processes.PE0195.structs.RelType;
import com.bytel.spirit.ford.processes.PE0195.structs.TraitementDeMasseIHM;

import spirit.saab.common.activities.shared.BL6401_GetTraitementDeMasseById;
import spirit.saab.common.activities.shared.BL6401_GetTraitementDeMasseById.BL6401_GetTraitementDeMasseByIdBuilder;
import spirit.saab.common.activities.shared.BL6402_GetTraitementDeMasseByStatut;
import spirit.saab.common.activities.shared.BL6402_GetTraitementDeMasseByStatut.BL6402_GetTraitementDeMasseByStatutBuilder;
import spirit.saab.common.activities.shared.BL6403_CreateTraitementDeMasse;
import spirit.saab.common.activities.shared.BL6403_CreateTraitementDeMasse.BL6403_CreateTraitementDeMasseBuilder;
import spirit.saab.common.activities.shared.BL6404_UpdateTraitementDeMasse;
import spirit.saab.common.activities.shared.BL6404_UpdateTraitementDeMasse.BL6404_UpdateTraitementDeMasseBuilder;
import spirit.saab.common.activities.shared.BL6501_GetReconciliationCommercialeEnMasse;
import spirit.saab.common.activities.shared.BL6501_GetReconciliationCommercialeEnMasse.BL6501_GetReconciliationCommercialeEnMasseBuilder;
import spirit.saab.common.activities.shared.BL6502_AjouterReconciliationCommercialeEnMasse;
import spirit.saab.common.activities.shared.BL6502_AjouterReconciliationCommercialeEnMasse.BL6502_AjouterReconciliationCommercialeEnMasseBuilder;
import spirit.saab.common.activities.shared.structs.BL6501_Response;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author lmerces
 * @version ($Revision: 23458 $ $Date: 2019-07-02 12:48:53 +0200 (mar. 02 juil. 2019) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ BL6502_AjouterReconciliationCommercialeEnMasse.class, BL6502_AjouterReconciliationCommercialeEnMasseBuilder.class, BL6404_UpdateTraitementDeMasse.class, BL6404_UpdateTraitementDeMasseBuilder.class, BL6403_CreateTraitementDeMasse.class, BL6403_CreateTraitementDeMasseBuilder.class, BL6402_GetTraitementDeMasseByStatut.class, BL6402_GetTraitementDeMasseByStatutBuilder.class, BL6501_GetReconciliationCommercialeEnMasse.class, BL6501_GetReconciliationCommercialeEnMasseBuilder.class, BL1200_DeplacerFichier.class, BL1200_DeplacerFichierBuilder.class, BL1300_CreerFichierBuilder.class, BL1300_CreerFichier.class, BL4300_EnvoyerFichier.class, BL4300_EnvoyerFichierBuilder.class, BL900_ObtenirConfigurationEmissionFichier.class, BL900_ObtenirConfigurationEmissionFichierBuilder.class,
    PE0195_GestionTraitementsDeMasse.class, REXProxy.class, BL1000_ObtenirConfigurationReceptionFichier.class, BL1000_ObtenirConfigurationReceptionFichierBuilder.class, BL800_ObtenirSequence.class, BL800_ObtenirSequenceBuilder.class, BL1700_AjouterRefFonc.class, BL1700_AjouterRefFoncBuilder.class, BL6401_GetTraitementDeMasseById.class, BL6401_GetTraitementDeMasseByIdBuilder.class })
public class PE0195_GestionTraitementsDeMasseTest
{
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam;

  static
  {
    __podam = new PodamFactoryImpl();
  }

  /**
   * FICHIER_DE_CONFIGURATION
   */
  private static final String FICHIER_DE_CONFIGURATION = "fichierConfiguration"; //$NON-NLS-1$

  /**
   * FILE_PREFIX
   */
  private static final String FILE_PREFIX = "Reconciliations_Masse_"; //$NON-NLS-1$

  /**
   * TAILLE_MAX_BLOC
   */
  private static final String TAILLE_MAX_BLOC = "TailleMaxBloc"; //$NON-NLS-1$

  /**
   * IHM_UPLOAD
   */
  private static final String IHM_UPLOAD = "IHM_UPLOAD"; //$NON-NLS-1$

  /**
   * EXPLOIT_BSS
   */
  private static final String EXPLOIT_BSS = "EXPLOIT_BSS"; //$NON-NLS-1$

  /**
   * RECONCILIATION_MASSE
   */
  private static final String RECONCILIATION_MASSE = "RECONCILIATION_MASSE"; //$NON-NLS-1$

  /**
   * TRAITEMENT_MASSE
   */
  private static final String TRAITEMENT_MASSE = "TRAITEMENT_MASSE"; //$NON-NLS-1$

  /**
   * ID_TRAITEMENT
   */
  private static final String ID_TRAITEMENT = "ID_TRAITEMENT_DE_MASSE"; //$NON-NLS-1$

  /**
   * TRAITEMENT_DE_MASSE_PATH
   */
  private static final String TRAITEMENT_DE_MASSE_PATH = "traitementDeMassePath"; //$NON-NLS-1$

  /**
   * LOCATION
   */
  private static final String LOCATION = "Location"; //$NON-NLS-1$

  /**
   * PE0195_BL001_ACTIVITY_NAME
   */
  private static final String PE0195_BL001_ACTIVITY_NAME = "PE0195_BL001_VerifierDonneesCreation"; //$NON-NLS-1$

  /**
   * PE0195_BL001_HEADER_NULL_OR_EMPTY
   */
  private static final String PE0195_BL001_HEADER_NULL_OR_EMPTY = "PE0195.BL001.HeaderNullOrEmpty"; //$NON-NLS-1$

  /**
   * TRAITEMENT_DE_MASSE
   */
  private static final String TRAITEMENT_DE_MASSE = "traitementDeMasse"; //$NON-NLS-1$

  /**
   * PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY
   */
  private static final String PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY = "PE0195.BL001.BodyFieldNullOrEmpty"; //$NON-NLS-1$

  /**
   * CLIENT_OPERATEUR
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * TYPE_TRAITEMENT_DE_MASSE
   */
  private static final String TYPE_TRAITEMENT_DE_MASSE = "typeTraitementDeMasse"; //$NON-NLS-1$

  /**
   * NOM_FICHIER
   */
  private static final String NOM_FICHIER = "nomFichier"; //$NON-NLS-1$

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */

  private static ProcessManager _processManager;

  @BeforeClass
  public static void init() throws RavelException
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    _processManager = ProcessManager.getInstance();

    try
    {
      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());
      RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, "DateTimeManager is now initialized")); //$NON-NLS-1$
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SystemLogEvent(LogSeverity.DEBUG, "DateTimeManager instance is already initialized")); //$NON-NLS-1$
    }
  }

  /**
   * REX PRoxy
   */
  @MockStrict
  private REXProxy _rexProxy;

  /**
   * BL800_ObtenirSequence
   */
  @MockStrict
  private BL800_ObtenirSequence _bl800Mock;

  /**
   * BL800_ObtenirSequenceBuilder
   */
  @MockStrict
  private BL800_ObtenirSequenceBuilder _bl800BuilderMock;

  /**
   * BL1700_AjouterRefFonc
   */
  @MockStrict
  private BL1700_AjouterRefFonc _bl1700Mock;

  /**
   * BL1700_AjouterRefFoncBuilder
   */
  @MockStrict
  private BL1700_AjouterRefFoncBuilder _bl1700BuilderMock;

  /**
   * BL1200_DeplacerFichier
   */
  @MockStrict
  private BL1200_DeplacerFichier _bl1200Mock;

  /**
   * BL1200_DeplacerFichierBuilder
   */
  @MockStrict
  private BL1200_DeplacerFichierBuilder _bl1200BuilderMock;

  /**
   * BL1300_CreerFichier
   */
  @MockStrict
  private BL1300_CreerFichier _bl1300Mock;

  /**
   * BL1300_CreerFichierBuilder
   */
  @MockStrict
  private BL1300_CreerFichierBuilder _bl1300BuilderMock;

  /**
   * BL4300_EnvoyerFichier
   */
  @MockStrict
  private BL4300_EnvoyerFichier _bl4300Mock;

  /**
   * BL4300_EnvoyerFichierBuilder
   */
  @MockStrict
  private BL4300_EnvoyerFichierBuilder _bl4300BuilderMock;

  /**
   * BL1000_ObtenirConfigurationReceptionFichier
   */
  @MockStrict
  private BL1000_ObtenirConfigurationReceptionFichier _bl1000Mock;

  /**
   * BL900_ObtenirConfigurationEmissionFichier
   */
  @MockStrict
  private BL900_ObtenirConfigurationEmissionFichier _bl900Mock;

  /**
   * BL900_ObtenirConfigurationEmissionFichierBuilder
   */
  @MockStrict
  private BL900_ObtenirConfigurationEmissionFichierBuilder _bl900BuilderMock;

  /**
   * BL1000_ObtenirConfigurationReceptionFichierBuilder
   */
  @MockStrict
  private BL1000_ObtenirConfigurationReceptionFichierBuilder _bl1000BuilderMock;

  /**
   * BL6401_GetTraitementDeMasseById
   */
  @MockStrict
  private BL6401_GetTraitementDeMasseById _bl6401Mock;

  /**
   * BL6401_GetTraitementDeMasseByIdBuilder PRoxy
   */
  @MockStrict
  private BL6401_GetTraitementDeMasseByIdBuilder _bl6401BuilderMock;

  /**
   * BL6402_GetTraitementDeMasseByStatut
   */
  @MockStrict
  private BL6402_GetTraitementDeMasseByStatut _bl6402Mock;

  /**
   * BL6402_GetTraitementDeMasseByStatutBuilder PRoxy
   */
  @MockStrict
  private BL6402_GetTraitementDeMasseByStatutBuilder _bl6402BuilderMock;

  /**
   * BL6501_GetReconciliationCommercialeEnMasse
   */
  @MockStrict
  private BL6501_GetReconciliationCommercialeEnMasse _bl6501Mock;

  /**
   * BL6501_GetReconciliationCommercialeEnMasseBuilder PRoxy
   */
  @MockStrict
  private BL6501_GetReconciliationCommercialeEnMasseBuilder _bl6501BuilderMock;

  /**
   * BL6403_CreateTraitementDeMasse
   */
  @MockStrict
  private BL6403_CreateTraitementDeMasse _bl6403Mock;

  /**
   * BL6403_CreateTraitementDeMasseBuilder PRoxy
   */
  @MockStrict
  private BL6403_CreateTraitementDeMasseBuilder _bl6403BuilderMock;

  /**
   * BL6404_UpdateTraitementDeMasse
   */
  @MockStrict
  private BL6404_UpdateTraitementDeMasse _bl6404Mock;

  /**
   * BL6404_UpdateTraitementDeMasseBuilder PRoxy
   */
  @MockStrict
  private BL6404_UpdateTraitementDeMasseBuilder _bl6404BuilderMock;

  /**
   * BL6502_AjouterReconciliationCommercialeEnMasse
   */
  @MockStrict
  private BL6502_AjouterReconciliationCommercialeEnMasse _bl6502Mock;

  /**
   * BL6502_AjouterReconciliationCommercialeEnMasseBuilder PRoxy
   */
  @MockStrict
  private BL6502_AjouterReconciliationCommercialeEnMasseBuilder _bl6502BuilderMock;

  /**
   * Instance of {@link PE0195_GestionTraitementsDeMasse}
   */
  private PE0195_GestionTraitementsDeMasse _processInstance;

  /**
   * Executed before each test
   *
   * @throws Exception
   *           Exception
   */
  @Before
  public void beforeTest() throws Exception
  {
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(REXProxy.class);
    PowerMock.mockStaticStrict(BL800_ObtenirSequence.class);
    PowerMock.mockStaticStrict(BL800_ObtenirSequenceBuilder.class);
    PowerMock.mockStaticStrict(BL1700_AjouterRefFonc.class);
    PowerMock.mockStaticStrict(BL1700_AjouterRefFoncBuilder.class);
    PowerMock.mockStaticStrict(BL1200_DeplacerFichier.class);
    PowerMock.mockStaticStrict(BL1200_DeplacerFichierBuilder.class);
    PowerMock.mockStaticStrict(BL1000_ObtenirConfigurationReceptionFichier.class);
    PowerMock.mockStaticStrict(BL1000_ObtenirConfigurationReceptionFichierBuilder.class);
    PowerMock.mockStaticStrict(BL900_ObtenirConfigurationEmissionFichier.class);
    PowerMock.mockStaticStrict(BL900_ObtenirConfigurationEmissionFichierBuilder.class);
    PowerMock.mockStaticStrict(BL1300_CreerFichier.class);
    PowerMock.mockStaticStrict(BL1300_CreerFichierBuilder.class);
    PowerMock.mockStaticStrict(BL4300_EnvoyerFichier.class);
    PowerMock.mockStaticStrict(BL4300_EnvoyerFichierBuilder.class);
    PowerMock.mockStaticStrict(BL6401_GetTraitementDeMasseById.class);
    PowerMock.mockStaticStrict(BL6401_GetTraitementDeMasseByIdBuilder.class);
    PowerMock.mockStaticStrict(BL6402_GetTraitementDeMasseByStatut.class);
    PowerMock.mockStaticStrict(BL6402_GetTraitementDeMasseByStatutBuilder.class);
    PowerMock.mockStaticStrict(BL6501_GetReconciliationCommercialeEnMasse.class);
    PowerMock.mockStaticStrict(BL6501_GetReconciliationCommercialeEnMasseBuilder.class);
    PowerMock.mockStaticStrict(BL6403_CreateTraitementDeMasse.class);
    PowerMock.mockStaticStrict(BL6403_CreateTraitementDeMasseBuilder.class);
    PowerMock.mockStaticStrict(BL6404_UpdateTraitementDeMasse.class);
    PowerMock.mockStaticStrict(BL6404_UpdateTraitementDeMasseBuilder.class);
    PowerMock.mockStaticStrict(BL6502_AjouterReconciliationCommercialeEnMasse.class);
    PowerMock.mockStaticStrict(BL6502_AjouterReconciliationCommercialeEnMasseBuilder.class);

    // context initialization
    _processInstance = new PE0195_GestionTraitementsDeMasse();
    _processInstance.initializeContext();
    _processManager.getProcessParams().clear();
  }

  /**
   * <b>Scenario:</b> Tests invalid header.<br>
   * <b>Input:</b> Headers are empty<br>
   * <b>Result:</b> CAT-3 | NON_RESPECT_STI | Header X-Source null ou vide.
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_BL001_VerifierDonnees_Test_KO_001() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    request.setHttpMethod(HttpConstants.GET_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Header X-Source null ou vide.", "PE0195_BL001_VerifierDonneesSuivi"); //$NON-NLS-1$ //$NON-NLS-2$
    PE0195_GestionTraitementsDeMasseUnitaireResponse pe0195_retour = new PE0195_GestionTraitementsDeMasseUnitaireResponse(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0195_retour));

    final Response expected = new Response(ErrorCode.KO_00400, response);

    _processInstance.run(request);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    PE0195_GestionTraitementsDeMasseResponse result = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), PE0195_GestionTraitementsDeMasseResponse.class);
    assertEquals(StringConstants.NOK, result.getRetour().getResultat());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, result.getRetour().getDiagnostic());
    assertEquals(IMegConsts.CAT3, result.getRetour().getCategorie());
    assertEquals(retour.getLibelle(), result.getRetour().getLibelle());
  }

  /**
   * <b>Scenario:</b> Tests invalid header.<br>
   * <b>Input:</b> Headers are empty<br>
   * <b>Result:</b> CAT-3 | NON_RESPECT_STI | Header X-Request-Id null ou vide.
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_BL001_VerifierDonnees_Test_KO_002() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    request.getRequestHeader().remove(2);
    request.setHttpMethod(HttpConstants.GET_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Header " + IHttpHeadersConsts.X_REQUEST_ID + " null ou vide.", "PE0195_BL001_VerifierDonneesSuivi"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PE0195_GestionTraitementsDeMasseUnitaireResponse pe0195_retour = new PE0195_GestionTraitementsDeMasseUnitaireResponse(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0195_retour));

    final Response expected = new Response(ErrorCode.KO_00400, response);

    _processInstance.run(request);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    PE0195_GestionTraitementsDeMasseResponse result = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), PE0195_GestionTraitementsDeMasseResponse.class);
    assertEquals(StringConstants.NOK, result.getRetour().getResultat());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, result.getRetour().getDiagnostic());
    assertEquals(IMegConsts.CAT3, result.getRetour().getCategorie());
    assertEquals(retour.getLibelle(), result.getRetour().getLibelle());
  }

  /**
   * <b>Scenario:</b> Tests invalid header.<br>
   * <b>Input:</b> Headers are empty<br>
   * <b>Result:</b> CAT-3 | NON_RESPECT_STI | Header X-Process null ou vide.
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_BL001_VerifierDonnees_Test_KO_003() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    request.getRequestHeader().remove(1);
    request.setHttpMethod(HttpConstants.GET_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);

    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Header " + IHttpHeadersConsts.X_PROCESS + " null ou vide.", "PE0195_BL001_VerifierDonneesSuivi"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    PE0195_GestionTraitementsDeMasseUnitaireResponse pe0195_retour = new PE0195_GestionTraitementsDeMasseUnitaireResponse(RetourConverter.convertToJsonRetour(retour));
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0195_retour));

    final Response expected = new Response(ErrorCode.KO_00400, response);

    _processInstance.run(request);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    PE0195_GestionTraitementsDeMasseResponse result = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), PE0195_GestionTraitementsDeMasseResponse.class);
    assertEquals(StringConstants.NOK, result.getRetour().getResultat());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, result.getRetour().getDiagnostic());
    assertEquals(IMegConsts.CAT3, result.getRetour().getCategorie());
    assertEquals(retour.getLibelle(), result.getRetour().getLibelle());
  }

  /**
   * <b>Scenario:</b> Tests invalid header.<br>
   * <b>Input:</b> Headers are empty<br>
   * <b>Result:</b> NOK | CAT-4 | DONNEE_INVALIDE | Type traitement de masse <type> inconnu
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_GET_Test_KO_001() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    TraitementDeMasseIHM traitementDeMasseIHM = __podam.manufacturePojoWithFullData(TraitementDeMasseIHM.class);

    request.setHttpMethod(HttpConstants.GET_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    String idTraitementDeMasse = "/traitements-de-masse/" + traitementDeMasseIHM.getIdTraitementDeMasse(); //$NON-NLS-1$
    request.setUrlDynamicParameters(idTraitementDeMasse);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0195.BL002.TypeTraitementInconnu"), traitementDeMasseIHM.getTypeTraitementDeMasse()), PE0195_BL001_ACTIVITY_NAME); //$NON-NLS-1$
    PE0195_GestionTraitementsDeMasseUnitaireResponse pe0195_retour = new PE0195_GestionTraitementsDeMasseUnitaireResponse(RetourConverter.convertToJsonRetour(retour));
    PE0195_GestionTraitementsDeMasseUnitaireResponse.ReponseFonctionnelle reponseFonctionnelle = new PE0195_GestionTraitementsDeMasseUnitaireResponse.ReponseFonctionnelle();
    reponseFonctionnelle.setTraitementDeMasse(traitementDeMasseIHM);
    pe0195_retour.setReponseFonctionnelle(reponseFonctionnelle);

    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0195_retour));
    final Response expected = new Response(ErrorCode.OK_00200, response);

    Pair<Retour, TraitementDeMasse> retourTraitementDeMasseLireUn = new ConnectorResponse<Retour, TraitementDeMasse>(RetourFactoryForTU.createOkRetour(), traitementDeMasseIHM);

    PowerMock.expectNew(BL6401_GetTraitementDeMasseByIdBuilder.class).andReturn(_bl6401BuilderMock);
    EasyMock.expect(_bl6401BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6401BuilderMock);
    EasyMock.expect(_bl6401BuilderMock.idTraitementDeMasse(idTraitementDeMasse)).andReturn(_bl6401BuilderMock);
    EasyMock.expect(_bl6401BuilderMock.build()).andReturn(_bl6401Mock);
    EasyMock.expect(_bl6401Mock.execute(_processInstance)).andReturn(retourTraitementDeMasseLireUn);
    EasyMock.expect(_bl6401Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    _processInstance.run(request);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    PE0195_GestionTraitementsDeMasseUnitaireResponse result = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), PE0195_GestionTraitementsDeMasseUnitaireResponse.class);
    assertEquals(StringConstants.NOK, result.getRetour().getResultat());
    assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, result.getRetour().getDiagnostic());
    assertEquals(IMegConsts.CAT4, result.getRetour().getCategorie());
  }

  /**
   * <b>Scenario:</b> Lire tous : OK <br>
   * <b>Input:</b> Headers are empty<br>
   * <b>Result:</b> OK
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_GET_Test_OK_001() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);

    request.setHttpMethod(HttpConstants.GET_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);

    List<Parameter> parameters = new ArrayList<>();
    Parameter parameter = new Parameter(ParameterUrl.statut.name(), "statut"); //$NON-NLS-1$
    parameters.add(parameter);
    parameter = new Parameter(ParameterUrl.statutTraitementUnitaire.name(), "traitementUnitaire"); //$NON-NLS-1$
    parameters.add(parameter);
    IUrlParameters urlParameters = new UrlParameters(parameters);
    request.setUrlParameters(urlParameters);
    List<TraitementDeMasse> traitementDeMasseList = Arrays.asList(__podam.manufacturePojoWithFullData(TraitementDeMasse.class));
    List<TraitementDeMasseIHM> newList = new ArrayList<TraitementDeMasseIHM>();
    for (Iterator<TraitementDeMasse> iterator = traitementDeMasseList.iterator(); iterator.hasNext();)
    {
      newList.add(createTraitementDeMasse(iterator.next()));
    }

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    PE0195_GestionTraitementsDeMasseResponse pe0195_retour = new PE0195_GestionTraitementsDeMasseResponse(RetourConverter.convertToJsonRetour(RetourFactoryForTU.createOkRetour()));
    PE0195_GestionTraitementsDeMasseResponse.ReponseFonctionnelle reponseFonctionnelle = new PE0195_GestionTraitementsDeMasseResponse.ReponseFonctionnelle();
    reponseFonctionnelle.setTraitementsDeMasse(newList);
    pe0195_retour.setReponseFonctionnelle(reponseFonctionnelle);

    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0195_retour));
    final Response expected = new Response(ErrorCode.OK_00200, response);

    Pair<Retour, Pair<List<TraitementDeMasse>, Integer>> retourTraitementDeMasseLireTous = new Pair<>(RetourFactoryForTU.createOkRetour(), new Pair<>(traitementDeMasseList, traitementDeMasseList.size()));

    PowerMock.expectNew(BL6402_GetTraitementDeMasseByStatutBuilder.class).andReturn(_bl6402BuilderMock);
    EasyMock.expect(_bl6402BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6402BuilderMock);
    EasyMock.expect(_bl6402BuilderMock.statut(ParameterUrl.statut.name())).andReturn(_bl6402BuilderMock);
    EasyMock.expect(_bl6402BuilderMock.build()).andReturn(_bl6402Mock);
    EasyMock.expect(_bl6402Mock.execute(_processInstance)).andReturn(retourTraitementDeMasseLireTous);
    EasyMock.expect(_bl6402Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    _processInstance.run(request);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
    PE0195_GestionTraitementsDeMasseResponse result = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), PE0195_GestionTraitementsDeMasseResponse.class);
    assertNotNull(result.getReponseFonctionnelle());
    assertFalse(result.getReponseFonctionnelle().getTraitementsDeMasse().isEmpty());
    assertEquals(3, result.getReponseFonctionnelle().getTraitementsDeMasse().get(0).getLinks().size());
  }

  /**
   * <b>Scenario:</b> Unitaire : OK <br>
   * <b>Input:</b> id traitement masse <b>Result:</b> OK
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_GET_Test_OK_002() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    TraitementDeMasse traitementDeMasse = new TraitementDeMasse("1111-xxxx-1111", "110000012345", TypeTraitement.RECONCILIATION_COMMERCIALE.name(), "EN_COURS"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    request.setHttpMethod(HttpConstants.GET_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    String idTraitementDeMasse = "/traitements-de-masse/" + traitementDeMasse.getIdTraitementDeMasse(); //$NON-NLS-1$
    request.setUrlDynamicParameters(idTraitementDeMasse);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    List<ReconciliationCommerciale> reconciliationCommercialeListe = new ArrayList<ReconciliationCommerciale>();

    PE0195_GestionTraitementsDeMasseUnitaireResponse pe0195_retour = new PE0195_GestionTraitementsDeMasseUnitaireResponse(RetourConverter.convertToJsonRetour(RetourFactoryForTU.createOkRetour()));
    PE0195_GestionTraitementsDeMasseUnitaireResponse.ReponseFonctionnelle reponseFonctionnelle = new PE0195_GestionTraitementsDeMasseUnitaireResponse.ReponseFonctionnelle();
    reponseFonctionnelle.setTraitementDeMasse(createTraitementDeMasse(traitementDeMasse));
    reponseFonctionnelle.setListeTraitementsUnitaires(reconciliationCommercialeListe);
    reponseFonctionnelle.setNbTotalTraitementsUnitaires(reconciliationCommercialeListe.size());
    pe0195_retour.setReponseFonctionnelle(reponseFonctionnelle);

    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0195_retour));
    final Response expected = new Response(ErrorCode.OK_00200, response);

    Pair<Retour, TraitementDeMasse> retourTraitementDeMasseLireUn = new ConnectorResponse<Retour, TraitementDeMasse>(RetourFactoryForTU.createOkRetour(), traitementDeMasse);
    BL6501_Response retourReconciliationCommercialeEnMasseLireTous = new BL6501_Response();
    retourReconciliationCommercialeEnMasseLireTous.setListeReconciliationCommerciale(reconciliationCommercialeListe);
    retourReconciliationCommercialeEnMasseLireTous.setNbReconciliationsCommerciales(reconciliationCommercialeListe.size());

    PowerMock.expectNew(BL6401_GetTraitementDeMasseByIdBuilder.class).andReturn(_bl6401BuilderMock);
    EasyMock.expect(_bl6401BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6401BuilderMock);
    EasyMock.expect(_bl6401BuilderMock.idTraitementDeMasse(idTraitementDeMasse)).andReturn(_bl6401BuilderMock);
    EasyMock.expect(_bl6401BuilderMock.build()).andReturn(_bl6401Mock);
    EasyMock.expect(_bl6401Mock.execute(_processInstance)).andReturn(retourTraitementDeMasseLireUn);

    //    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy).times(2);
    //    ConnectorResponse<Retour, TraitementDeMasse> retourTraitementDeMasseLireUn = new ConnectorResponse<Retour, TraitementDeMasse>(RetourFactoryForTU.createOkRetour(), traitementDeMasse);
    //    EasyMock.expect(_rexProxy.traitementDeMasseLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.anyObject())).andReturn(retourTraitementDeMasseLireUn);
    PowerMock.expectNew(BL6501_GetReconciliationCommercialeEnMasseBuilder.class).andReturn(_bl6501BuilderMock);
    EasyMock.expect(_bl6501BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6501BuilderMock);
    EasyMock.expect(_bl6501BuilderMock.idTraitementDeMasse(traitementDeMasse.getIdTraitementDeMasse())).andReturn(_bl6501BuilderMock);
    EasyMock.expect(_bl6501BuilderMock.statut(null)).andReturn(_bl6501BuilderMock);
    EasyMock.expect(_bl6501BuilderMock.nbMaxReconciliationCommercialesLues(100)).andReturn(_bl6501BuilderMock);
    EasyMock.expect(_bl6501BuilderMock.build()).andReturn(_bl6501Mock);
    EasyMock.expect(_bl6501Mock.execute(_processInstance)).andReturn(retourReconciliationCommercialeEnMasseLireTous);
    EasyMock.expect(_bl6501Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());
    EasyMock.expect(_bl6401Mock.getRetour()).andReturn(RetourFactory.createOkRetour());

    // EasyMock.expect(_rexProxy.reconciliationCommercialeEnMasseLireTous(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(traitementDeMasse.getIdTraitementDeMasse()), EasyMock.anyString())).andReturn(retourReconciliationCommercialeEnMasseLireTous);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "100"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());

    PE0195_GestionTraitementsDeMasseUnitaireResponse result = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), PE0195_GestionTraitementsDeMasseUnitaireResponse.class);
    assertNotNull(result.getReponseFonctionnelle());
    assertNotNull(result.getReponseFonctionnelle().getTraitementDeMasse());
    assertEquals(3, result.getReponseFonctionnelle().getTraitementDeMasse().getLinks().size());
  }

  /**
   * <b>Input:</b> Missing source header<br>
   * <b>Result:</b> KO, CAT3, NON_RESPECT_STI
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_001() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    request.getRequestHeader().remove(0);
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_SOURCE), PE0195_BL001_ACTIVITY_NAME);

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("\\temp\\PE0195\\abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ko));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.KO_00400, response);

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);
    _processInstance.createDefaultFunctionalResponse(RetourFactory.createOkRetour());
    _processInstance.getInternalState();
    _processInstance.getSleepTime();
    _processInstance.isAsynchronous();
    _processInstance.isReplayable();
    try
    {
      _processInstance.continuePostProcess();
    }
    catch (RavelException ravelException)
    {
      //      throw new RavelException(, , ); //$NON-NLS-1$
      assertEquals(ravelException.getExceptionType(), ExceptionType.UNEXPECTED);
      assertEquals(ravelException.getErrorCode(), ErrorCode.PRCESS_00001);
      assertEquals(ravelException.getMessage(), Messages.getString("PE0195.UnexpectedContinuePostProcessReceived")); //$NON-NLS-1$
    }

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    BasicResponse basicResp = GsonTools.getIso8601Ms().fromJson(expected.getGenericResponse().getResult(), BasicResponse.class);
    assertEquals(basicResponse.getRetour().getDiagnostic(), basicResp.getRetour().getDiagnostic());
    assertEquals(basicResponse.getRetour().getCategorie(), basicResp.getRetour().getCategorie());
    assertEquals(basicResponse.getRetour().getLibelle(), basicResp.getRetour().getLibelle());
    assertEquals(basicResponse.getRetour().getResultat(), basicResp.getRetour().getResultat());
  }

  /**
   * <b>Input:</b> Missing process header<br>
   * <b>Result:</b> KO, CAT3, NON_RESPECT_STI
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_002() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    request.getRequestHeader().remove(1);
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_PROCESS), PE0195_BL001_ACTIVITY_NAME);

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("\\temp\\PE0195\\abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ko));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.KO_00400, response);

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    BasicResponse basicResp = GsonTools.getIso8601Ms().fromJson(expected.getGenericResponse().getResult(), BasicResponse.class);
    assertEquals(basicResponse.getRetour().getDiagnostic(), basicResp.getRetour().getDiagnostic());
    assertEquals(basicResponse.getRetour().getCategorie(), basicResp.getRetour().getCategorie());
    assertEquals(basicResponse.getRetour().getLibelle(), basicResp.getRetour().getLibelle());
    assertEquals(basicResponse.getRetour().getResultat(), basicResp.getRetour().getResultat());
  }

  /**
   * <b>Input:</b> Missing request ID header<br>
   * <b>Result:</b> KO, CAT3, NON_RESPECT_STI
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_003() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    request.getRequestHeader().remove(2);
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_REQUEST_ID), PE0195_BL001_ACTIVITY_NAME);

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("\\temp\\PE0195\\abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ko));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.KO_00400, response);

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    BasicResponse basicResp = GsonTools.getIso8601Ms().fromJson(expected.getGenericResponse().getResult(), BasicResponse.class);
    assertEquals(basicResponse.getRetour().getDiagnostic(), basicResp.getRetour().getDiagnostic());
    assertEquals(basicResponse.getRetour().getCategorie(), basicResp.getRetour().getCategorie());
    assertEquals(basicResponse.getRetour().getLibelle(), basicResp.getRetour().getLibelle());
    assertEquals(basicResponse.getRetour().getResultat(), basicResp.getRetour().getResultat());
  }

  /**
   * <b>Input:</b> The request body is empty <br>
   * <b>Result:</b> KO, CAT3, NON_RESPECT_STI
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_004() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), TRAITEMENT_DE_MASSE), PE0195_BL001_ACTIVITY_NAME);

    String jsonRequest = GsonTools.getIso8601Sec().toJson(null);

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ko));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.KO_00400, response);

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    BasicResponse basicResp = GsonTools.getIso8601Ms().fromJson(expected.getGenericResponse().getResult(), BasicResponse.class);
    assertEquals(basicResponse.getRetour().getDiagnostic(), basicResp.getRetour().getDiagnostic());
    assertEquals(basicResponse.getRetour().getCategorie(), basicResp.getRetour().getCategorie());
    assertEquals(basicResponse.getRetour().getLibelle(), basicResp.getRetour().getLibelle());
    assertEquals(basicResponse.getRetour().getResultat(), basicResp.getRetour().getResultat());
  }

  /**
   * <b>Input:</b> The request body is mising the clientOperator <br>
   * <b>Result:</b> KO, CAT3, NON_RESPECT_STI
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_005() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), CLIENT_OPERATEUR), PE0195_BL001_ACTIVITY_NAME);

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur(""); //$NON-NLS-1$
    pe0195Request.setNomFichier("\\temp\\PE0195\\abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ko));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.KO_00400, response);

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    BasicResponse basicResp = GsonTools.getIso8601Ms().fromJson(expected.getGenericResponse().getResult(), BasicResponse.class);
    assertEquals(basicResponse.getRetour().getDiagnostic(), basicResp.getRetour().getDiagnostic());
    assertEquals(basicResponse.getRetour().getCategorie(), basicResp.getRetour().getCategorie());
    assertEquals(basicResponse.getRetour().getLibelle(), basicResp.getRetour().getLibelle());
    assertEquals(basicResponse.getRetour().getResultat(), basicResp.getRetour().getResultat());
  }

  /**
   * <b>Input:</b> The request body is missing the typerTraitementDeMasse <br>
   * <b>Result:</b> KO, CAT3, NON_RESPECT_STI
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_006() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), TYPE_TRAITEMENT_DE_MASSE), PE0195_BL001_ACTIVITY_NAME);

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("\\temp\\PE0195\\abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse(""); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ko));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.KO_00400, response);

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    BasicResponse basicResp = GsonTools.getIso8601Ms().fromJson(expected.getGenericResponse().getResult(), BasicResponse.class);
    assertEquals(basicResponse.getRetour().getDiagnostic(), basicResp.getRetour().getDiagnostic());
    assertEquals(basicResponse.getRetour().getCategorie(), basicResp.getRetour().getCategorie());
    assertEquals(basicResponse.getRetour().getLibelle(), basicResp.getRetour().getLibelle());
    assertEquals(basicResponse.getRetour().getResultat(), basicResp.getRetour().getResultat());
  }

  /**
   * <b>Input:</b> The request body is missing the File Name <br>
   * <b>Result:</b> KO, CAT3, NON_RESPECT_STI
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_007() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), NOM_FICHIER), PE0195_BL001_ACTIVITY_NAME);

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier(""); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ko));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.KO_00400, response);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    BasicResponse basicResp = GsonTools.getIso8601Ms().fromJson(expected.getGenericResponse().getResult(), BasicResponse.class);
    assertEquals(basicResponse.getRetour().getDiagnostic(), basicResp.getRetour().getDiagnostic());
    assertEquals(basicResponse.getRetour().getCategorie(), basicResp.getRetour().getCategorie());
    assertEquals(basicResponse.getRetour().getLibelle(), basicResp.getRetour().getLibelle());
    assertEquals(basicResponse.getRetour().getResultat(), basicResp.getRetour().getResultat());
  }

  /**
   * <b>Input:</b> BL1000 fails <br>
   * <b>Result:</b> KO, CAT3, DONNEE_INVALIDE
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_009() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ko = RetourFactory.createKO(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled."); //$NON-NLS-1$
    Retour ok = RetourFactory.createOkRetour();

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("\\temp\\PE0195\\abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    String idTraitement = ID_TRAITEMENT;

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ResponseHeader responseHeader = new ResponseHeader();
    responseHeader.setName(LOCATION);
    responseHeader.setValue("/traitements-de-masse/" + idTraitement); //$NON-NLS-1$
    response.getResponseHeader().add(responseHeader);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ok));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.OK_00200, response);

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, pe0195Request.getClientOperateur());

    TraitementDeMasse traitementDeMasse = new TraitementDeMasse(idTraitement, pe0195Request.getClientOperateur(), pe0195Request.getTypeTraitementDeMasse(), Statut.INIT.toString());
    traitementDeMasse.setNbARealiser(0);
    traitementDeMasse.setNbDeclenches(0);
    traitementDeMasse.setNbTermines(0);
    traitementDeMasse.setNomFichierIn(pe0195Request.getNomFichier());
    traitementDeMasse.setNomFichierOut(FILE_PREFIX + DateTimeFormatPattern.yyyy_dash_MM_dash_dd_underscore_HH_h_mm_m_ss_s.format(DateTimeManager.getInstance().now()) + ".csv"); //$NON-NLS-1$
    traitementDeMasse.setDateCreation(DateTimeManager.getInstance().now());
    traitementDeMasse.setDateModification(DateTimeManager.getInstance().now());

    ConnectorResponse<Retour, Nothing> rexProxyRet = new ConnectorResponse<>(ok, null);

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_TRAITEMENT_MASSE)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn(idTraitement);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.refFonc(refFonc)).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.build()).andReturn(_bl1700Mock);
    EasyMock.expect(_bl1700Mock.execute(_processInstance)).andReturn(null);

    PowerMock.expectNew(BL6403_CreateTraitementDeMasseBuilder.class).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.traitementDeMasse(traitementDeMasse)).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.build()).andReturn(_bl6403Mock);
    EasyMock.expect(_bl6403Mock.execute(_processInstance)).andReturn(rexProxyRet);

    PowerMock.expectNew(BL1000_ObtenirConfigurationReceptionFichierBuilder.class).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.codeFlux(IHM_UPLOAD)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.configurationFile(".")).andReturn(_bl1000BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl1000BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.typeFichier(TRAITEMENT_MASSE)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.build()).andReturn(_bl1000Mock);
    EasyMock.expect(_bl1000Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1000Mock.getRetour()).andReturn(ko);
    EasyMock.expect(_bl1000Mock.getRetour()).andReturn(ko);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);
    _processInstance.continuePostProcess();

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * <b>Input:</b> BL900 fails <br>
   * <b>Result:</b> KO, CAT3, DONNEE_INVALIDE
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_010() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ko = RetourFactory.createKO(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled."); //$NON-NLS-1$
    Retour ok = RetourFactory.createOkRetour();

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("\\temp\\PE0195\\abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    String idTraitement = ID_TRAITEMENT;

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ResponseHeader responseHeader = new ResponseHeader();
    responseHeader.setName(LOCATION);
    responseHeader.setValue("/traitements-de-masse/" + idTraitement); //$NON-NLS-1$
    response.getResponseHeader().add(responseHeader);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ok));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.OK_00200, response);

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, pe0195Request.getClientOperateur());

    TraitementDeMasse traitementDeMasse = new TraitementDeMasse(idTraitement, pe0195Request.getClientOperateur(), pe0195Request.getTypeTraitementDeMasse(), Statut.INIT.toString());
    traitementDeMasse.setNbARealiser(0);
    traitementDeMasse.setNbDeclenches(0);
    traitementDeMasse.setNbTermines(0);
    traitementDeMasse.setNomFichierIn(pe0195Request.getNomFichier());
    traitementDeMasse.setNomFichierOut(FILE_PREFIX + DateTimeFormatPattern.yyyy_dash_MM_dash_dd_underscore_HH_h_mm_m_ss_s.format(DateTimeManager.getInstance().now()) + ".csv"); //$NON-NLS-1$
    traitementDeMasse.setDateCreation(DateTimeManager.getInstance().now());
    traitementDeMasse.setDateModification(DateTimeManager.getInstance().now());

    ConnectorResponse<Retour, Nothing> rexProxyRet = new ConnectorResponse<>(ok, null);

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_TRAITEMENT_MASSE)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn(idTraitement);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.refFonc(refFonc)).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.build()).andReturn(_bl1700Mock);
    EasyMock.expect(_bl1700Mock.execute(_processInstance)).andReturn(null);

    PowerMock.expectNew(BL6403_CreateTraitementDeMasseBuilder.class).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.traitementDeMasse(traitementDeMasse)).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.build()).andReturn(_bl6403Mock);
    EasyMock.expect(_bl6403Mock.execute(_processInstance)).andReturn(rexProxyRet);

    PowerMock.expectNew(BL1000_ObtenirConfigurationReceptionFichierBuilder.class).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.codeFlux(IHM_UPLOAD)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.configurationFile(".")).andReturn(_bl1000BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl1000BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.typeFichier(TRAITEMENT_MASSE)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.build()).andReturn(_bl1000Mock);
    EasyMock.expect(_bl1000Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1000Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(EXPLOIT_BSS)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile(".")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(RECONCILIATION_MASSE)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);
    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(ko);
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(ko);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);
    _processInstance.continuePostProcess();

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * <b>Input:</b> BL1200 fails <br>
   * <b>Result:</b> KO, CAT3, DONNEE_INVALIDE
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_011() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ko = RetourFactory.createKO(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled."); //$NON-NLS-1$
    Retour ok = RetourFactory.createOkRetour();

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("\\temp\\PE0195\\abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    String idTraitement = ID_TRAITEMENT;

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ResponseHeader responseHeader = new ResponseHeader();
    responseHeader.setName(LOCATION);
    responseHeader.setValue("/traitements-de-masse/" + idTraitement); //$NON-NLS-1$
    response.getResponseHeader().add(responseHeader);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ok));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.OK_00200, response);

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, pe0195Request.getClientOperateur());

    TraitementDeMasse traitementDeMasse = new TraitementDeMasse(idTraitement, pe0195Request.getClientOperateur(), pe0195Request.getTypeTraitementDeMasse(), Statut.INIT.toString());
    traitementDeMasse.setNbARealiser(0);
    traitementDeMasse.setNbDeclenches(0);
    traitementDeMasse.setNbTermines(0);
    traitementDeMasse.setNomFichierIn(pe0195Request.getNomFichier());
    traitementDeMasse.setNomFichierOut(FILE_PREFIX + DateTimeFormatPattern.yyyy_dash_MM_dash_dd_underscore_HH_h_mm_m_ss_s.format(DateTimeManager.getInstance().now()) + ".csv"); //$NON-NLS-1$
    traitementDeMasse.setDateCreation(DateTimeManager.getInstance().now());
    traitementDeMasse.setDateModification(DateTimeManager.getInstance().now());

    ConnectorResponse<Retour, Nothing> rexProxyRet = new ConnectorResponse<>(ok, null);

    ConfigurationReception configurationReception = new ConfigurationReception();
    configurationReception.setCodeFlux(IHM_UPLOAD);

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_TRAITEMENT_MASSE)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn(idTraitement);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.refFonc(refFonc)).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.build()).andReturn(_bl1700Mock);
    EasyMock.expect(_bl1700Mock.execute(_processInstance)).andReturn(null);

    PowerMock.expectNew(BL6403_CreateTraitementDeMasseBuilder.class).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.traitementDeMasse(traitementDeMasse)).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.build()).andReturn(_bl6403Mock);
    EasyMock.expect(_bl6403Mock.execute(_processInstance)).andReturn(rexProxyRet);

    PowerMock.expectNew(BL1000_ObtenirConfigurationReceptionFichierBuilder.class).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.codeFlux(IHM_UPLOAD)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.configurationFile(".")).andReturn(_bl1000BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl1000BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.typeFichier(TRAITEMENT_MASSE)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.build()).andReturn(_bl1000Mock);
    EasyMock.expect(_bl1000Mock.execute(_processInstance)).andReturn(configurationReception);
    EasyMock.expect(_bl1000Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(EXPLOIT_BSS)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile(".")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(RECONCILIATION_MASSE)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);
    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(ok);

    mockBL1200(traitementDeMasse.getNomFichierIn(), configurationReception.getRepertoireTemp(), configurationReception.getRepertoireRecu(), ko);
    EasyMock.expect(_bl1200Mock.getRetour()).andReturn(ko);
    EasyMock.expect(_bl1200Mock.getRetour()).andReturn(ko);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);
    _processInstance.continuePostProcess();

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * <b>Input:</b> BL1300 fails <br>
   * <b>Result:</b> KO, CAT3, DONNEE_INVALIDE
   *
   * @throws Throwable
   *           exception
   */
  //@Test
  public void PE0195_POST_Test_KO_012() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ko = RetourFactory.createKO(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled."); //$NON-NLS-1$
    Retour ok = RetourFactory.createOkRetour();

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("/temp/PE0195/abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    String idTraitement = ID_TRAITEMENT;

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ResponseHeader responseHeader = new ResponseHeader();
    responseHeader.setName(LOCATION);
    responseHeader.setValue("/traitements-de-masse/" + idTraitement); //$NON-NLS-1$
    response.getResponseHeader().add(responseHeader);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ok));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.OK_00200, response);

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, pe0195Request.getClientOperateur());

    TraitementDeMasse traitementDeMasse = new TraitementDeMasse(idTraitement, pe0195Request.getClientOperateur(), pe0195Request.getTypeTraitementDeMasse(), Statut.INIT.toString());
    traitementDeMasse.setNbARealiser(0);
    traitementDeMasse.setNbDeclenches(0);
    traitementDeMasse.setNbTermines(0);
    traitementDeMasse.setNomFichierIn(pe0195Request.getNomFichier());
    traitementDeMasse.setNomFichierOut(FILE_PREFIX + DateTimeFormatPattern.yyyy_dash_MM_dash_dd_underscore_HH_h_mm_m_ss_s.format(DateTimeManager.getInstance().now()) + ".csv"); //$NON-NLS-1$
    traitementDeMasse.setDateCreation(DateTimeManager.getInstance().now());
    traitementDeMasse.setDateModification(DateTimeManager.getInstance().now());

    ConnectorResponse<Retour, Nothing> rexProxyRet = new ConnectorResponse<>(ok, null);

    ConfigurationReception configurationReception = new ConfigurationReception();
    configurationReception.setCodeFlux(IHM_UPLOAD);

    ConfigurationEmission configurationEmission = new ConfigurationEmission();
    configurationEmission.setCodeFlux(EXPLOIT_BSS);

    Path pathIn = Paths.get(traitementDeMasse.getNomFichierIn());
    if (!pathIn.toFile().exists())
    {
      Files.createDirectories(pathIn.getParent());
      pathIn = Files.createFile(pathIn);
    }

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_TRAITEMENT_MASSE)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn(idTraitement);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.refFonc(refFonc)).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.build()).andReturn(_bl1700Mock);
    EasyMock.expect(_bl1700Mock.execute(_processInstance)).andReturn(null);

    PowerMock.expectNew(BL6403_CreateTraitementDeMasseBuilder.class).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.traitementDeMasse(traitementDeMasse)).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.build()).andReturn(_bl6403Mock);
    EasyMock.expect(_bl6403Mock.execute(_processInstance)).andReturn(rexProxyRet);

    PowerMock.expectNew(BL1000_ObtenirConfigurationReceptionFichierBuilder.class).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.codeFlux(IHM_UPLOAD)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.configurationFile(".")).andReturn(_bl1000BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl1000BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.typeFichier(TRAITEMENT_MASSE)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.build()).andReturn(_bl1000Mock);
    EasyMock.expect(_bl1000Mock.execute(_processInstance)).andReturn(configurationReception);
    EasyMock.expect(_bl1000Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(EXPLOIT_BSS)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile(".")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(RECONCILIATION_MASSE)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);
    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(configurationEmission);
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(ok);

    mockBL1200(traitementDeMasse.getNomFichierIn(), configurationReception.getRepertoireTemp(), configurationReception.getRepertoireRecu(), ok);
    EasyMock.expect(_bl1200Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL1300_CreerFichierBuilder.class).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.nomFichier(traitementDeMasse.getNomFichierOut())).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.repertoire(configurationEmission.getRepertoireTemp())).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.build()).andReturn(_bl1300Mock);
    EasyMock.expect(_bl1300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(ko);
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(ko);

    mockBL1200(traitementDeMasse.getNomFichierIn(), configurationReception.getRepertoireRecu(), configurationReception.getRepertoireEchec(), ok);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);
    _processInstance.continuePostProcess();

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());

    pathIn.toFile().delete();
    Files.delete(Paths.get(pathIn.getParent().toString()));
  }

  /**
   * <b>Input:</b> call to REX connector method reconciliationCommercialeEnMasseAjouter fails <br>
   * <b>Result:</b> KO, CAT3, DONNEE_INVALIDE
   *
   * @throws Throwable
   *           exception
   */
  //@Test
  public void PE0195_POST_Test_KO_013() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ko = RetourFactory.createKO(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, "Activity parameter not filled."); //$NON-NLS-1$
    Retour ok = RetourFactory.createOkRetour();

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("/temp/PE0195/abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    String idTraitement = ID_TRAITEMENT;

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ResponseHeader responseHeader = new ResponseHeader();
    responseHeader.setName(LOCATION);
    responseHeader.setValue("/traitements-de-masse/" + idTraitement); //$NON-NLS-1$
    response.getResponseHeader().add(responseHeader);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ok));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.OK_00200, response);

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, pe0195Request.getClientOperateur());

    TraitementDeMasse traitementDeMasse = new TraitementDeMasse(idTraitement, pe0195Request.getClientOperateur(), pe0195Request.getTypeTraitementDeMasse(), Statut.INIT.toString());
    traitementDeMasse.setNbARealiser(0);
    traitementDeMasse.setNbDeclenches(0);
    traitementDeMasse.setNbTermines(0);
    traitementDeMasse.setNomFichierIn(pe0195Request.getNomFichier());
    traitementDeMasse.setNomFichierOut(FILE_PREFIX + DateTimeFormatPattern.yyyy_dash_MM_dash_dd_underscore_HH_h_mm_m_ss_s.format(DateTimeManager.getInstance().now()) + ".csv"); //$NON-NLS-1$
    traitementDeMasse.setDateCreation(DateTimeManager.getInstance().now());
    traitementDeMasse.setDateModification(DateTimeManager.getInstance().now());

    ConnectorResponse<Retour, Nothing> rexProxyRet = new ConnectorResponse<>(ok, null);

    ConfigurationReception configurationReception = new ConfigurationReception();
    configurationReception.setCodeFlux(IHM_UPLOAD);

    ConfigurationEmission configurationEmission = new ConfigurationEmission();
    configurationEmission.setCodeFlux(EXPLOIT_BSS);

    Path pathIn = Paths.get(traitementDeMasse.getNomFichierIn());
    if (!pathIn.toFile().exists())
    {
      Files.createDirectories(pathIn.getParent());
      pathIn = Files.createFile(pathIn);
    }

    List<String> listeNoCompte = new ArrayList<>();
    listeNoCompte.add("11111"); //$NON-NLS-1$
    listeNoCompte.add("22222"); //$NON-NLS-1$
    listeNoCompte.add("12345"); //$NON-NLS-1$

    BufferedWriter writer = Files.newBufferedWriter(pathIn, Charset.forName("UTF-8")); //$NON-NLS-1$
    for (String s : listeNoCompte)
    {
      writer.write(s + StringConstants.WINDOWS_NEW_LINE);
    }
    writer.close();

    List<AssociationPfiReconcialitionCommerciale> associationList = new ArrayList<>();
    listeNoCompte.forEach(s -> associationList.add(new AssociationPfiReconcialitionCommerciale(s, traitementDeMasse.getIdTraitementDeMasse())));

    Path pathOut = Paths.get(traitementDeMasse.getNomFichierOut());

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_TRAITEMENT_MASSE)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn(idTraitement);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.refFonc(refFonc)).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.build()).andReturn(_bl1700Mock);
    EasyMock.expect(_bl1700Mock.execute(_processInstance)).andReturn(null);

    PowerMock.expectNew(BL6403_CreateTraitementDeMasseBuilder.class).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.traitementDeMasse(traitementDeMasse)).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.build()).andReturn(_bl6403Mock);
    EasyMock.expect(_bl6403Mock.execute(_processInstance)).andReturn(rexProxyRet);

    PowerMock.expectNew(BL1000_ObtenirConfigurationReceptionFichierBuilder.class).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.codeFlux(IHM_UPLOAD)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.configurationFile(".")).andReturn(_bl1000BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl1000BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.typeFichier(TRAITEMENT_MASSE)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.build()).andReturn(_bl1000Mock);
    EasyMock.expect(_bl1000Mock.execute(_processInstance)).andReturn(configurationReception);
    EasyMock.expect(_bl1000Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(EXPLOIT_BSS)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile(".")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(RECONCILIATION_MASSE)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);
    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(configurationEmission);
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(ok);

    mockBL1200(traitementDeMasse.getNomFichierIn(), configurationReception.getRepertoireTemp(), configurationReception.getRepertoireRecu(), ok);
    EasyMock.expect(_bl1200Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL1300_CreerFichierBuilder.class).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.nomFichier(traitementDeMasse.getNomFichierOut())).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.repertoire(configurationEmission.getRepertoireTemp())).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.build()).andReturn(_bl1300Mock);
    EasyMock.expect(_bl1300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL6404_UpdateTraitementDeMasseBuilder.class).andReturn(_bl6404BuilderMock);
    EasyMock.expect(_bl6404BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6404BuilderMock);
    EasyMock.expect(_bl6404BuilderMock.idTraitementDeMasse(traitementDeMasse.getIdTraitementDeMasse())).andReturn(_bl6404BuilderMock);
    EasyMock.expect(_bl6404BuilderMock.nbTraitementsARealiser(3)).andReturn(_bl6404BuilderMock);
    EasyMock.expect(_bl6404BuilderMock.build()).andReturn(_bl6404Mock);
    EasyMock.expect(_bl6404Mock.execute(_processInstance)).andReturn(rexProxyRet);

    PowerMock.expectNew(BL6502_AjouterReconciliationCommercialeEnMasseBuilder.class).andReturn(_bl6502BuilderMock);
    EasyMock.expect(_bl6502BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6502BuilderMock);
    EasyMock.expect(_bl6502BuilderMock.idTraitementDeMasse(traitementDeMasse.getIdTraitementDeMasse())).andReturn(_bl6502BuilderMock);
    EasyMock.expect(_bl6502BuilderMock.listNoCompte(listeNoCompte)).andReturn(_bl6502BuilderMock);
    EasyMock.expect(_bl6502BuilderMock.build()).andReturn(_bl6502Mock);
    EasyMock.expect(_bl6502Mock.execute(_processInstance)).andReturn(associationList);
    EasyMock.expect(_bl6502Mock.getRetour()).andReturn(ko);
    EasyMock.expect(_bl6502Mock.getRetour()).andReturn(ko);
    //
    //    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    //    EasyMock.expect(_rexProxy.traitementDeMasseModifierStatutEnCours(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(traitementDeMasse.getIdTraitementDeMasse()), EasyMock.eq(3))).andReturn(rexProxyRet);
    //
    //    EasyMock.expect(REXProxy.getInstance()).andReturn(_rexProxy);
    //    EasyMock.expect(_rexProxy.reconciliationCommercialeEnMasseAjouter(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(traitementDeMasse.getIdTraitementDeMasse()), EasyMock.eq(listeNoCompte))).andReturn(rexProxyRet2);

    mockBL1200(traitementDeMasse.getNomFichierIn(), configurationReception.getRepertoireRecu(), configurationReception.getRepertoireEchec(), ok);
    mockBL1200(traitementDeMasse.getNomFichierOut(), configurationEmission.getRepertoireTemp(), configurationEmission.getRepertoireEchec(), ok);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "abc"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);
    _processInstance.continuePostProcess();

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Stream<String> fileLines = Files.lines(pathOut);
    long lineNum = fileLines.count();
    fileLines.close();

    assertEquals(lineNum, 0);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());

    Files.delete(pathOut);
    pathIn.toFile().delete();
    Files.delete(Paths.get(pathIn.getParent().toString()));
  }

  /**
   * <b>Input:</b> Input file doesn't exist <br>
   * <b>Result:</b> RavelException
   *
   * @throws Throwable
   *           exception
   */
  @Test
  public void PE0195_POST_Test_KO_015() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ok = RetourFactory.createOkRetour();

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("/temp/PE0195/abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    String idTraitement = ID_TRAITEMENT;

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ResponseHeader responseHeader = new ResponseHeader();
    responseHeader.setName(LOCATION);
    responseHeader.setValue("/traitements-de-masse/" + idTraitement); //$NON-NLS-1$
    response.getResponseHeader().add(responseHeader);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ok));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.OK_00200, response);

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, pe0195Request.getClientOperateur());

    TraitementDeMasse traitementDeMasse = new TraitementDeMasse(idTraitement, pe0195Request.getClientOperateur(), pe0195Request.getTypeTraitementDeMasse(), Statut.INIT.toString());
    traitementDeMasse.setNbARealiser(0);
    traitementDeMasse.setNbDeclenches(0);
    traitementDeMasse.setNbTermines(0);
    traitementDeMasse.setNomFichierIn(pe0195Request.getNomFichier());
    traitementDeMasse.setNomFichierOut(FILE_PREFIX + DateTimeFormatPattern.yyyy_dash_MM_dash_dd_underscore_HH_h_mm_m_ss_s.format(DateTimeManager.getInstance().now()) + ".csv"); //$NON-NLS-1$
    traitementDeMasse.setDateCreation(DateTimeManager.getInstance().now());
    traitementDeMasse.setDateModification(DateTimeManager.getInstance().now());

    ConnectorResponse<Retour, Nothing> rexProxyRet = new ConnectorResponse<>(ok, null);

    Path pathIn = Paths.get(traitementDeMasse.getNomFichierIn());
    if (pathIn.toFile().exists())
    {
      pathIn.toFile().delete();
    }

    ConfigurationReception configurationReception = new ConfigurationReception();
    configurationReception.setCodeFlux(IHM_UPLOAD);

    ConfigurationEmission configurationEmission = new ConfigurationEmission();
    configurationEmission.setCodeFlux(EXPLOIT_BSS);

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_TRAITEMENT_MASSE)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn(idTraitement);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.refFonc(refFonc)).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.build()).andReturn(_bl1700Mock);
    EasyMock.expect(_bl1700Mock.execute(_processInstance)).andReturn(null);

    PowerMock.expectNew(BL6403_CreateTraitementDeMasseBuilder.class).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.traitementDeMasse(traitementDeMasse)).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.build()).andReturn(_bl6403Mock);
    EasyMock.expect(_bl6403Mock.execute(_processInstance)).andReturn(rexProxyRet);

    PowerMock.expectNew(BL1000_ObtenirConfigurationReceptionFichierBuilder.class).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.codeFlux(IHM_UPLOAD)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.configurationFile(".")).andReturn(_bl1000BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl1000BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.typeFichier(TRAITEMENT_MASSE)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.build()).andReturn(_bl1000Mock);
    EasyMock.expect(_bl1000Mock.execute(_processInstance)).andReturn(configurationReception);
    EasyMock.expect(_bl1000Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(EXPLOIT_BSS)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile(".")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(RECONCILIATION_MASSE)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);
    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(configurationEmission);
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(ok);

    mockBL1200(traitementDeMasse.getNomFichierIn(), configurationReception.getRepertoireTemp(), configurationReception.getRepertoireRecu(), ok);
    EasyMock.expect(_bl1200Mock.getRetour()).andReturn(ok);

    mockBL1200(traitementDeMasse.getNomFichierIn(), configurationReception.getRepertoireRecu(), configurationReception.getRepertoireEchec(), ok);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "3"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);
    try
    {
      _processInstance.continuePostProcess();
    }
    catch (RavelException ravelException)
    {
      assertEquals(ravelException.getExceptionType(), ExceptionType.DIRECTORY_ERROR);
      assertEquals(ravelException.getErrorCode(), ErrorCode.TECH_00001);
      assertEquals(ravelException.getMessage(), Paths.get(traitementDeMasse.getNomFichierIn()).toString());
    }

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * <b>Scenario:</b> Nominal test case<br>
   * <b>Input:</b> All ok<br>
   * <b>Result:</b> OK
   *
   * @throws Throwable
   *           exception
   */
  //@Test
  public void PE0195_POST_Test_OK_001() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    fillAllRequestHeaders(request);
    Retour ok = RetourFactory.createOkRetour();

    String idTraitement = ID_TRAITEMENT;

    PE0195_PostBodyRequest pe0195Request = new PE0195_PostBodyRequest();
    pe0195Request.setClientOperateur("Client Operateur"); //$NON-NLS-1$
    pe0195Request.setNomFichier("/temp/PE0195/abc.txt"); //$NON-NLS-1$
    pe0195Request.setTypeTraitementDeMasse("Type"); //$NON-NLS-1$
    String jsonRequest = GsonTools.getIso8601Sec().toJson(pe0195Request);

    request.setHttpMethod(HttpConstants.POST_METHOD);
    request.setContentType(HttpConstants.CONTENT_TYPE_JSON);
    request.setPayload(jsonRequest);

    TraitementDeMasse traitementDeMasse = new TraitementDeMasse(idTraitement, pe0195Request.getClientOperateur(), pe0195Request.getTypeTraitementDeMasse(), Statut.INIT.toString());
    traitementDeMasse.setNbARealiser(0);
    traitementDeMasse.setNbDeclenches(0);
    traitementDeMasse.setNbTermines(0);
    traitementDeMasse.setNomFichierIn(pe0195Request.getNomFichier());
    traitementDeMasse.setNomFichierOut(FILE_PREFIX + DateTimeFormatPattern.yyyy_dash_MM_dash_dd_underscore_HH_h_mm_m_ss_s.format(DateTimeManager.getInstance().now()) + ".csv"); //$NON-NLS-1$
    traitementDeMasse.setDateCreation(DateTimeManager.getInstance().now());
    traitementDeMasse.setDateModification(DateTimeManager.getInstance().now());

    Path pathIn = Paths.get(traitementDeMasse.getNomFichierIn());
    if (!pathIn.toFile().exists())
    {
      Files.createDirectories(pathIn.getParent());
      pathIn = Files.createFile(pathIn);
    }

    List<String> listeNoCompte = new ArrayList<>();
    listeNoCompte.add("11111"); //$NON-NLS-1$
    listeNoCompte.add("22222"); //$NON-NLS-1$
    listeNoCompte.add("12345"); //$NON-NLS-1$

    BufferedWriter writer = Files.newBufferedWriter(pathIn, Charset.forName("UTF-8")); //$NON-NLS-1$
    for (String s : listeNoCompte)
    {
      writer.write(s + StringConstants.WINDOWS_NEW_LINE);
    }
    writer.close();

    Path pathOut = Paths.get(traitementDeMasse.getNomFichierOut());

    List<AssociationPfiReconcialitionCommerciale> associationList = new ArrayList<>();
    listeNoCompte.forEach(s -> associationList.add(new AssociationPfiReconcialitionCommerciale(s, traitementDeMasse.getIdTraitementDeMasse())));

    ConnectorResponse<Retour, Nothing> rexProxyRet = new ConnectorResponse<>(ok, null);

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, pe0195Request.getClientOperateur());

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ResponseHeader responseHeader = new ResponseHeader();
    responseHeader.setName(LOCATION);
    responseHeader.setValue("/traitements-de-masse/" + traitementDeMasse.getIdTraitementDeMasse()); //$NON-NLS-1$
    response.getResponseHeader().add(responseHeader);

    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(ok));
    response.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    Response expected = new Response(ErrorCode.OK_00200, response);

    ConfigurationReception configurationReception = new ConfigurationReception();
    configurationReception.setCodeFlux(IHM_UPLOAD);

    ConfigurationEmission configurationEmission = new ConfigurationEmission();
    configurationEmission.setCodeFlux(EXPLOIT_BSS);

    PowerMock.expectNew(BL800_ObtenirSequenceBuilder.class).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.code(UniqueIdConstant.ID_TRAITEMENT_MASSE)).andReturn(_bl800BuilderMock);
    EasyMock.expect(_bl800BuilderMock.build()).andReturn(_bl800Mock);
    EasyMock.expect(_bl800Mock.execute(_processInstance)).andReturn(idTraitement);
    EasyMock.expect(_bl800Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.refFonc(refFonc)).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.build()).andReturn(_bl1700Mock);
    EasyMock.expect(_bl1700Mock.execute(_processInstance)).andReturn(null);

    PowerMock.expectNew(BL6403_CreateTraitementDeMasseBuilder.class).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.traitementDeMasse(traitementDeMasse)).andReturn(_bl6403BuilderMock);
    EasyMock.expect(_bl6403BuilderMock.build()).andReturn(_bl6403Mock);
    EasyMock.expect(_bl6403Mock.execute(_processInstance)).andReturn(rexProxyRet);

    PowerMock.expectNew(BL1000_ObtenirConfigurationReceptionFichierBuilder.class).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.codeFlux(IHM_UPLOAD)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.configurationFile(".")).andReturn(_bl1000BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl1000BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.typeFichier(TRAITEMENT_MASSE)).andReturn(_bl1000BuilderMock);
    EasyMock.expect(_bl1000BuilderMock.build()).andReturn(_bl1000Mock);
    EasyMock.expect(_bl1000Mock.execute(_processInstance)).andReturn(configurationReception);
    EasyMock.expect(_bl1000Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL900_ObtenirConfigurationEmissionFichierBuilder.class).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.codeFlux(EXPLOIT_BSS)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.configurationFile(".")).andReturn(_bl900BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_bl900BuilderMock.typeFichier(RECONCILIATION_MASSE)).andReturn(_bl900BuilderMock);
    EasyMock.expect(_bl900BuilderMock.build()).andReturn(_bl900Mock);
    EasyMock.expect(_bl900Mock.execute(_processInstance)).andReturn(configurationEmission);
    EasyMock.expect(_bl900Mock.getRetour()).andReturn(ok);

    mockBL1200(traitementDeMasse.getNomFichierIn(), configurationReception.getRepertoireTemp(), configurationReception.getRepertoireRecu(), ok);
    EasyMock.expect(_bl1200Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL1300_CreerFichierBuilder.class).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.nomFichier(traitementDeMasse.getNomFichierOut())).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.repertoire(configurationEmission.getRepertoireTemp())).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.build()).andReturn(_bl1300Mock);
    EasyMock.expect(_bl1300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL6404_UpdateTraitementDeMasseBuilder.class).andReturn(_bl6404BuilderMock);
    EasyMock.expect(_bl6404BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6404BuilderMock);
    EasyMock.expect(_bl6404BuilderMock.idTraitementDeMasse(traitementDeMasse.getIdTraitementDeMasse())).andReturn(_bl6404BuilderMock);
    EasyMock.expect(_bl6404BuilderMock.nbTraitementsARealiser(3)).andReturn(_bl6404BuilderMock);
    EasyMock.expect(_bl6404BuilderMock.build()).andReturn(_bl6404Mock);
    EasyMock.expect(_bl6404Mock.execute(_processInstance)).andReturn(rexProxyRet);

    PowerMock.expectNew(BL6502_AjouterReconciliationCommercialeEnMasseBuilder.class).andReturn(_bl6502BuilderMock);
    EasyMock.expect(_bl6502BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl6502BuilderMock);
    EasyMock.expect(_bl6502BuilderMock.idTraitementDeMasse(traitementDeMasse.getIdTraitementDeMasse())).andReturn(_bl6502BuilderMock);
    EasyMock.expect(_bl6502BuilderMock.listNoCompte(listeNoCompte)).andReturn(_bl6502BuilderMock);
    EasyMock.expect(_bl6502BuilderMock.build()).andReturn(_bl6502Mock);
    EasyMock.expect(_bl6502Mock.execute(_processInstance)).andReturn(associationList);
    EasyMock.expect(_bl6502Mock.getRetour()).andReturn(ok);

    PowerMock.expectNew(BL4300_EnvoyerFichierBuilder.class).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.chaineConnexion(configurationEmission.getChaineConnexion())).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.repertoire(configurationEmission.getRepertoireTemp())).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.nomFichier(traitementDeMasse.getNomFichierOut())).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.build()).andReturn(_bl4300Mock);
    EasyMock.expect(_bl4300Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_bl4300Mock.getRetour()).andReturn(ok);

    mockBL1200(traitementDeMasse.getNomFichierIn(), configurationReception.getRepertoireTemp(), configurationReception.getRepertoireTraite(), ok);

    mockBL1200(traitementDeMasse.getNomFichierOut(), configurationEmission.getRepertoireTemp(), configurationEmission.getRepertoireTraite(), ok);

    // On enregistre le scénario des appels avant de lancer le test
    PowerMock.replayAll();

    Map<String, String> map = new HashMap<>();
    map.put(FICHIER_DE_CONFIGURATION, "."); //$NON-NLS-1$
    map.put(TAILLE_MAX_BLOC, "5"); //$NON-NLS-1$
    map.put(TRAITEMENT_DE_MASSE_PATH, "/traitements-de-masse/"); //$NON-NLS-1$
    ConcurrentMap<String, Map<String, String>> processParams = _processManager.getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    _processInstance.run(request);
    _processInstance.continuePostProcess();

    // On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    BufferedReader reader = Files.newBufferedReader(pathOut, Charset.forName("UTF-8")); //$NON-NLS-1$
    Iterator<String> lines = reader.lines().iterator();
    int lineNum = 0;
    while (lines.hasNext())
    {
      String line = lines.next();
      if (lineNum <= associationList.size())
      {
        assertEquals(line, asFileString(associationList.get(lineNum)));
      }
      lineNum++;
    }
    assertEquals(lineNum, associationList.size());
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());

    Files.delete(pathOut);
    pathIn.toFile().delete();
    Files.delete(Paths.get(pathIn.getParent().toString()));
  }

  /**
   * Used to convert the association to the file format
   *
   * @param association
   *          The association to convert
   * @return {@link String}
   */
  private String asFileString(AssociationPfiReconcialitionCommerciale association)
  {
    return association.getNoCompte() + ";" + association.getIdReconciliationCommerciale(); //$NON-NLS-1$
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Creates a link
   *
   * @param idTraitementDeMasse_p
   *          id
   * @param relType_p
   *          rel
   * @return {@link Link}
   */
  private Link createLink(String idTraitementDeMasse_p, RelType relType_p)
  {
    StringBuffer sb = new StringBuffer(PE0195_GestionTraitementsDeMasse.URL);
    sb.append(idTraitementDeMasse_p);
    if (!RelType.SELF.equals(relType_p))
    {
      sb.append(PE0195_GestionTraitementsDeMasse.STATUT);
      sb.append(relType_p.name());
    }

    return new Link(relType_p.toString(), sb.toString());
  }

  /**
   * Creates list of links
   *
   * @param idTraitementDeMasse_p
   *          id
   * @return a list
   */
  private List<Link> createLinks(String idTraitementDeMasse_p)
  {
    List<Link> links = new ArrayList<>();
    links.add(createLink(idTraitementDeMasse_p, RelType.SELF));
    links.add(createLink(idTraitementDeMasse_p, RelType.TERMINE));
    links.add(createLink(idTraitementDeMasse_p, RelType.EN_COURS));
    return links;
  }

  /**
   * Create traitement de masse IHM
   *
   * @param traitementDeMasse_p
   *          {@link TraitementDeMasse}
   * @return {@link TraitementDeMasseIHM}
   */
  private TraitementDeMasseIHM createTraitementDeMasse(TraitementDeMasse traitementDeMasse_p)
  {
    TraitementDeMasseIHM traitementDeMasseIHM = new TraitementDeMasseIHM(traitementDeMasse_p);
    traitementDeMasseIHM.setLinks(createLinks(traitementDeMasse_p.getIdTraitementDeMasse()));
    return traitementDeMasseIHM;
  }

  /**
   * Fills all the request headers
   *
   * @param request_p
   *          The request
   */
  private void fillAllRequestHeaders(Request request_p)
  {
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_SPIRIT"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION_TRAITEMENT_MASSE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000874"); //$NON-NLS-1$

    fillRequestHeaders(request_p, xSource, xProcess, xRequestId);
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * Method used to mock the BL1200 activity
   *
   * @param nomFichier_p
   *          The file name
   * @param src_p
   *          The source folder
   * @param des_p
   *          The destination folder
   * @param retour_p
   *          The bl retour
   * @throws Exception
   *           Exception thrown if something goes wrong
   */
  private void mockBL1200(String nomFichier_p, String src_p, String des_p, Retour retour_p) throws Exception
  {
    PowerMock.expectNew(BL1200_DeplacerFichierBuilder.class).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.nomFichier(nomFichier_p)).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireSrc(src_p)).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireDes(des_p)).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.build()).andReturn(_bl1200Mock);
    EasyMock.expect(_bl1200Mock.execute(_processInstance)).andReturn(null);
  }
}
