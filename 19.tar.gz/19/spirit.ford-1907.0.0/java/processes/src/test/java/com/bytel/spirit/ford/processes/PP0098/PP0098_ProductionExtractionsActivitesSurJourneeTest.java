/*******************************************************************************
* $Id: PP0098_ProductionExtractionsActivitesSurJourneeTest.java 23458 2019-07-02 10:48:53Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicInteger;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.configuration.ConfigFileManager;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IUrlParameters;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1400_EmettreFichier;
import com.bytel.spirit.common.activities.shared.BL1400_EmettreFichier.BL1400_EmettreFichierBuilder;
import com.bytel.spirit.common.activities.shared.Messages;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.Entreprise;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.Titulaire;
import com.bytel.spirit.common.shared.saab.rpg.TypeTitulaire;
import com.bytel.spirit.ford.processes.PP0098.PP0098_ProductionExtractionsActivitesSurJournee.PFIWorker;
import com.bytel.spirit.ford.processes.PP0098.PP0098_ProductionExtractionsActivitesSurJournee.PP0098_ProductionExtractionsActivitesSurJourneeContext;
import com.bytel.spirit.ford.processes.PP0098.generator.INSFWriter;
import com.bytel.spirit.ford.processes.PP0098.generator.NSFWriterFactory;
import com.bytel.spirit.ford.processes.PP0098.generator.NSFWriterFactory.NSFWriterFactoryRetour;
import com.bytel.spirit.ford.processes.PP0098.structs.ConfigExtractionActiviteSurJournee;
import com.bytel.spirit.saab.connectors.rpg.RPGDatabaseProxy;
import com.bytel.spirit.saab.connectors.rpg.type.RefChangedIdPfi;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author vloureir
 * @version ($Revision: 23458 $ $Date: 2019-07-02 12:48:53 +0200 (mar. 02 juil. 2019) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PP0098_ProductionExtractionsActivitesSurJournee.class, NSFWriterFactory.class, BL1200_DeplacerFichier.class, BL1200_DeplacerFichierBuilder.class, BL1400_EmettreFichier.class, BL1400_EmettreFichierBuilder.class, ProcessManager.class, RPGDatabaseProxy.class })
public class PP0098_ProductionExtractionsActivitesSurJourneeTest
{

  /**
   * The TransfererFichiers constant.
   */
  private static final String TRANSFERER_FICHIERS = "TransfererFichiers"; //$NON-NLS-1$

  /**
   * The EMPTY_DIR constant.
   */
  private static final String EMPTY_DIR = "emptyDir"; //$NON-NLS-1$

  /**
   * The ProduireExtractions constant.
   */
  private static final String PRODUIRE_EXTRACTIONS = "ProduireExtractions"; //$NON-NLS-1$

  /**
   * Mode execution parameter name
   */
  private static final String MODE_EXECUTION_PARAM = "modeExecution"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory _podam = new PodamFactoryImpl();

  /**
   * ConfigFileManager singleton
   */
  private static ConfigFileManager _configFileManager;

  /**
   * Temp File Path
   */
  private static String tempWorkFilePath = null;

  /**
   * Temp File Path
   */
  private static String tempSuccessFilePath = null;

  /**
   * Temp File Path
   */
  private static String tempErrorFilePath = null;

  /**
   *
   */
  private static File temp = null;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    _configFileManager = new ConfigFileManager("."); //$NON-NLS-1$
    _podam = new PodamFactoryImpl();

  }

  /**
   * Create Dir for Tests
   *
   */
  private static void createDummieDir()
  {
    temp = null;
    TemporaryFolder tf = new TemporaryFolder();

    try
    {
      tf.create();
      File workFolder = tf.newFolder("work"); //$NON-NLS-1$
      File successFolder = tf.newFolder("success"); //$NON-NLS-1$
      File errorFolder = tf.newFolder("error"); //$NON-NLS-1$
      temp = File.createTempFile("SPIRIT-PFI", ".csv", workFolder); //$NON-NLS-1$ //$NON-NLS-2$

      //Get tempropary file path
      tempWorkFilePath = workFolder.getAbsolutePath() + File.separator;
      tempSuccessFilePath = successFolder.getAbsolutePath() + File.separator;
      tempErrorFilePath = errorFolder.getAbsolutePath() + File.separator;
    }
    catch (IOException exception)
    {
      // TODO Auto-generated catch block
      exception.printStackTrace();
    }
  }

  /**
   * Create Dir for Tests
   *
   */
  private static void createDummieDirEmpty()
  {
    Path pathTests = Paths.get(EMPTY_DIR);

    //if directory exists?
    if (!Files.exists(pathTests))
    {
      try
      {
        Files.createDirectories(pathTests);
      }
      catch (IOException e)
      {
        //fail to create directory
        e.printStackTrace();
      }
    }
  }

  /**
   * Create Request for tests
   *
   * @param option
   *          test option
   * @return return Request
   * @throws RavelException
   *           ravel Exception
   */
  private static Request createRequest(Integer option) throws RavelException
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(IHttpHeadersConsts.X_REQUEST_ID);
    requestHeader.setValue("PP0098"); //$NON-NLS-1$

    Request request = new Request("PP0098_ProductionExtractionsActivitesSurJournee", StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING); //$NON-NLS-1$
    request.getRequestHeader().add(requestHeader);

    List<Parameter> parameters = new ArrayList<>();
    Parameter parameter = null;
    IUrlParameters urlParameters = null;

    switch (option)
    {
      case 1:
        parameter = new Parameter(MODE_EXECUTION_PARAM, PRODUIRE_EXTRACTIONS);
        parameters.add(parameter);
        urlParameters = new UrlParameters(parameters);
        request.setUrlParameters(urlParameters);
        break;
      case 2:
        parameter = new Parameter(MODE_EXECUTION_PARAM, "X"); //$NON-NLS-1$
        parameters.add(parameter);
        urlParameters = new UrlParameters(parameters);
        request.setUrlParameters(urlParameters);
        break;
      case 3:
        parameter = new Parameter(MODE_EXECUTION_PARAM, TRANSFERER_FICHIERS);
        parameters.add(parameter);
        urlParameters = new UrlParameters(parameters);
        request.setUrlParameters(urlParameters);
        break;
      case 4:
        urlParameters = new UrlParameters(parameters);
        request.setUrlParameters(urlParameters);
        break;
      case 5:
        request.getRequestHeader().remove(0);
        break;
      default:
        break;
    }

    return request;
  }

  /**
   * RPG database proxy mock
   */
  @MockStrict
  private RPGDatabaseProxy _rpgDatabaseProxy;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  private ProcessManager _processManager;

  /**
   * process testée
   */
  private PP0098_ProductionExtractionsActivitesSurJournee _currentProcess;

  /**
   * Context of PP0098
   */
  PP0098_ProductionExtractionsActivitesSurJourneeContext _processContext;

  /**
   * Mock de {@link BL1400_EmettreFichier}
   */
  @MockStrict
  BL1400_EmettreFichier _bl1400Mock;

  /**
   * Mock de {@link BL1400_EmettreFichierBuilder}
   */
  @MockStrict
  BL1400_EmettreFichierBuilder _bl1400BuilderMock;

  /**
   * Mock de {@link BL1200_DeplacerFichier}
   */
  @MockStrict
  BL1200_DeplacerFichier _bl1200Mock;

  /**
   * Mock de {@link BL1200_DeplacerFichierBuilder}
   */
  @MockStrict
  BL1200_DeplacerFichierBuilder _bl1200BuilderMock;

  /**
   * Cleans the Connector Mocks responses
   *
   * @throws Exception
   *           On Error
   */
  @Before
  public void beforeTest() throws Exception
  {
    _currentProcess = new PP0098_ProductionExtractionsActivitesSurJournee();
    _currentProcess.initializeContext();

    _processContext = (PP0098_ProductionExtractionsActivitesSurJourneeContext) JUnitTools.getInaccessibleFieldValue(_currentProcess, "_processContext"); //$NON-NLS-1$

    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(BL1200_DeplacerFichier.class);
    PowerMock.mockStaticStrict(BL1200_DeplacerFichierBuilder.class);
    PowerMock.mockStaticStrict(BL1400_EmettreFichier.class);
    PowerMock.mockStaticStrict(BL1400_EmettreFichierBuilder.class);
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStaticStrict(RPGDatabaseProxy.class);
    PowerMock.mockStaticStrict(NSFWriterFactory.class);
    createDummieDir();
  }

  /**
   * Delete temp File
   */
  @After
  public void end()
  {
    temp.deleteOnExit();
  }

  /**
   * Test case Config Extraction Activite Sur Journee with values, BL1200 KO and Result OK.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_00() throws Throwable
  {
    //Prepare test
    NSFWriterFactoryRetour nsfWriterFactoryRetour = new NSFWriterFactoryRetour(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), null);
    Retour bl1200Retour = RetourFactory.createNOK(IMegConsts.CAT1, Messages.getString("BL1400_EmettreFichier.DeplacementFichierInvalide"), StringConstants.EMPTY_STRING); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    mockBL1200(bl1200Retour, 2);

    EasyMock.expect(NSFWriterFactory.getNSFWriter(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString())).andReturn(nsfWriterFactoryRetour);

    mockRPGDatabaseProxyGetIdPfiChangedOverGivenPeriod(1);

    EasyMock.expect(NSFWriterFactory.getNSFWriter(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString(), EasyMock.anyObject())).andReturn(nsfWriterFactoryRetour);

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case Config Extraction Activite Sur Journee with values, BL1200 KO and Result OK.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_01() throws Throwable
  {
    //Prepare test
    NSFWriterFactoryRetour nsfWriterFactoryRetour = new NSFWriterFactoryRetour(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), null);
    Retour bl1200Retour = RetourFactory.createNOK(IMegConsts.CAT1, Messages.getString("BL1400_EmettreFichier.DeplacementFichierInvalide"), StringConstants.EMPTY_STRING); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    mockBL1200(bl1200Retour, 1);

    EasyMock.expect(NSFWriterFactory.getNSFWriter(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString())).andReturn(nsfWriterFactoryRetour);

    mockRPGDatabaseProxyGetIdPfiChangedOverGivenPeriod(1);

    EasyMock.expect(NSFWriterFactory.getNSFWriter(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString(), EasyMock.anyObject())).andReturn(nsfWriterFactoryRetour);

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case Config Extraction Activite Sur Journee Invalid.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK - CAT4 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_02() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(0);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    String libelle = "Les paramètres de config poolSize;waitingFileSize;endingTimeout;pushTimeout;linesToFlush;chaineConnexion;cheminRepTravail;cheminRepArchiveSucces;cheminRepArchiveErreur;environnement;listeExtractionActiviteAProduire sont manquants"; //$NON-NLS-1$

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    Assert.assertEquals(libelle, jsonRetour.getLibelle());
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK but RPGDatabaseProxy KO (Generic KO).</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>KO - CAT1 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_03() throws Throwable
  {
    //Prepare test
    NSFWriterFactoryRetour nsfWriterFactoryRetour = new NSFWriterFactoryRetour(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), null);
    Retour bl1200Retour = RetourFactory.createNOK(IMegConsts.CAT1, Messages.getString("BL1400_EmettreFichier.DeplacementFichierInvalide"), StringConstants.EMPTY_STRING); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    mockBL1200(bl1200Retour, 1);

    EasyMock.expect(NSFWriterFactory.getNSFWriter(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString())).andReturn(nsfWriterFactoryRetour);

    mockRPGDatabaseProxyGetIdPfiChangedOverGivenPeriod(2);

    EasyMock.expect(NSFWriterFactory.getNSFWriter(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString(), EasyMock.anyObject())).andReturn(nsfWriterFactoryRetour);

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    String libelle = "Impossible de récupérer les données des PFI"; //$NON-NLS-1$

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.LECTURE_INDISPONIBLE, jsonRetour.getDiagnostic());
    Assert.assertEquals(libelle, jsonRetour.getLibelle());
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK but RPGDatabaseProxy KO (TIMEOUT).</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>KO - CAT1 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_04() throws Throwable
  {
    //Prepare test
    NSFWriterFactoryRetour nsfWriterFactoryRetour = new NSFWriterFactoryRetour(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), null);
    Retour bl1200Retour = RetourFactory.createNOK(IMegConsts.CAT1, Messages.getString("BL1400_EmettreFichier.DeplacementFichierInvalide"), StringConstants.EMPTY_STRING); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    mockBL1200(bl1200Retour, 1);

    EasyMock.expect(NSFWriterFactory.getNSFWriter(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString())).andReturn(nsfWriterFactoryRetour);

    mockRPGDatabaseProxyGetIdPfiChangedOverGivenPeriod(3);

    EasyMock.expect(NSFWriterFactory.getNSFWriter(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString(), EasyMock.anyObject())).andReturn(nsfWriterFactoryRetour);

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegSpiritConsts.TIMEOUT, jsonRetour.getDiagnostic());
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK but RPGDatabaseProxy KO (DONNEE_INCONNUE).</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_05() throws Throwable
  {
    //Prepare test
    NSFWriterFactoryRetour nsfWriterFactoryRetour = new NSFWriterFactoryRetour(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), null);
    Retour bl1200Retour = RetourFactory.createNOK(IMegConsts.CAT1, Messages.getString("BL1400_EmettreFichier.DeplacementFichierInvalide"), StringConstants.EMPTY_STRING); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    mockBL1200(bl1200Retour, 1);

    EasyMock.expect(NSFWriterFactory.getNSFWriter(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString())).andReturn(nsfWriterFactoryRetour);

    mockRPGDatabaseProxyGetIdPfiChangedOverGivenPeriod(4);

    EasyMock.expect(NSFWriterFactory.getNSFWriter(EasyMock.anyObject(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt(), EasyMock.anyString(), EasyMock.anyObject())).andReturn(nsfWriterFactoryRetour);

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK but modeExecution Not Valid.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK - CAT4 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_06() throws Throwable
  {
    genericTestValidateModeExecution(999, 2);
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK but pathCheminRepTravail Not Valid.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK - CAT4 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_07() throws Throwable
  {
    genericTestValidateChemins(1, 1);
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK but cheminRepArchiveSucces Not Valid.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK - CAT4 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_08() throws Throwable
  {
    genericTestValidateChemins(2, 3);
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK but cheminRepArchiveErreur Not Valid.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK - CAT4 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_09() throws Throwable
  {
    genericTestValidateChemins(3, 3);
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK and BL1400 OK.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_10() throws Throwable
  {
    //Prepare test
    Retour bl1400Retour = RetourFactory.createOkRetour();
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    mockBL1400(bl1400Retour, 1);

    PowerMock.replayAll();

    Request request = createRequest(3);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK and BL1400 KO.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>KO - Cat2 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_11() throws Throwable
  {
    //Prepare test
    Retour bl1400Retour = RetourFactory.createNOK(IMegConsts.CAT2, "SERVICE_TIERS_INDISPONIBLE", StringConstants.EMPTY_STRING); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    mockBL1400(bl1400Retour, 1);

    PowerMock.replayAll();

    Request request = createRequest(3);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT2, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.SERVICE_TIERS_INDISPONIBLE, jsonRetour.getDiagnostic());
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK and BL1400 Ravel Exception.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>KO - CAT10 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_12() throws Throwable
  {
    //Prepare test
    Retour bl1400Retour = RetourFactory.createNOK(IMegConsts.CAT2, "SERVICE_TIERS_INDISPONIBLE", StringConstants.EMPTY_STRING); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    mockBL1400(bl1400Retour, 2);

    PowerMock.replayAll();

    Request request = createRequest(3);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT10, jsonRetour.getCategorie());
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK and cheminRepTravail without files.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_13() throws Throwable
  {
    //Prepare test
    createDummieDirEmpty();
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(4);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(3);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());

    deleteDummieDir(EMPTY_DIR);
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK and BL1400 KO.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_14() throws Throwable
  {
    //Prepare test
    Retour bl1200Retour = RetourFactory.createOkRetour();
    Retour bl1400Retour = RetourFactory.createNOK(IMegConsts.CAT1, "DEPLACEMENT_FICHIER_INVALIDE", StringConstants.EMPTY_STRING); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    mockBL1400(bl1400Retour, 1);
    mockBL1200(bl1200Retour, 1);

    PowerMock.replayAll();

    Request request = createRequest(3);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK, compteDistant and cheminRepDepotDistant NULL.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>KO - CAT4 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_15() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(5);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(3);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    String libelle = "Les paramètres de connexion au serveur distant sont inconnus"; //$NON-NLS-1$

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.DONNEE_INCONNUE, jsonRetour.getDiagnostic());
    Assert.assertEquals(libelle, jsonRetour.getLibelle());
  }

  /**
   * Test case Config Extraction Activite Sur Journee OK but modeExecution null.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK - CAT4 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_16() throws Throwable
  {
    genericTestValidateModeExecution(999, 4);
  }

  /**
   * Test Comsume method case without _processContext.getPfiCounter()</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_17() throws Throwable
  {
    //Prepare test
    LocalDateTime now = LocalDateTime.now();
    Tracabilite tracabilite = new Tracabilite("idcorrelationBytel", "idcorrelation", "FORD", "processus", "1234", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$
    String noCompte = "xxxxx"; //$NON-NLS-1$

    //Prepare mock
    mockRPGDatabaseProxyGetPFI(1);

    ConfigExtractionActiviteSurJournee configExtractionActiviteSurJournee_p = new ConfigExtractionActiviteSurJournee();
    configExtractionActiviteSurJournee_p.setWaitingFileSize(100);
    configExtractionActiviteSurJournee_p.setPushTimeout(10);

    _processContext.setThreadPoolExecutor((ThreadPoolExecutor) Executors.newFixedThreadPool(10));
    _processContext.setNsfWriters(new ArrayList<>());
    _processContext.setConfigExtractionActiviteSurJournee(configExtractionActiviteSurJournee_p);

    PowerMock.replayAll();

    Retour retour = _currentProcess.consume(tracabilite, new RefChangedIdPfi(clientOperateur, noCompte, now));

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, retour.getResultat());
  }

  /**
   * Test Comsume method case with _processContext.getPfiCounter()</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_18() throws Throwable
  {
    //Prepare test
    LocalDateTime now = LocalDateTime.now();
    Tracabilite tracabilite = new Tracabilite("idcorrelationBytel", "idcorrelation", "FORD", "processus", "1234", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$
    String noCompte = "xxxxx"; //$NON-NLS-1$

    ConfigExtractionActiviteSurJournee configExtractionActiviteSurJournee_p = new ConfigExtractionActiviteSurJournee();
    configExtractionActiviteSurJournee_p.setPushTimeout(10);
    configExtractionActiviteSurJournee_p.setWaitingFileSize(100);
    Map<String, AtomicInteger> pfiCounter = new ConcurrentHashMap<>();
    pfiCounter.put("BSS_ENT;xxxxx", new AtomicInteger(1)); //$NON-NLS-1$

    _processContext.setThreadPoolExecutor((ThreadPoolExecutor) Executors.newFixedThreadPool(10));
    _processContext.setNsfWriters(new ArrayList<>());
    _processContext.setConfigExtractionActiviteSurJournee(configExtractionActiviteSurJournee_p);
    _processContext.setPfiCounter(pfiCounter);

    Retour retour = _currentProcess.consume(tracabilite, new RefChangedIdPfi(clientOperateur, noCompte, now));

    Assert.assertEquals(StringConstants.OK, retour.getResultat());
  }

  /**
   * Test PFIWorker case RPGDatabaseProxy method GetPFI OK.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_19() throws Throwable
  {
    //Prepare test
    LocalDateTime now = LocalDateTime.now();
    Tracabilite tracabilite = new Tracabilite("idcorrelationBytel", "idcorrelation", "FORD", "processus", "1234", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "xxxxx"; //$NON-NLS-1$
    List<INSFWriter> insfWriters = new ArrayList<>();

    RefChangedIdPfi refChangedIdPfi_p = new RefChangedIdPfi(clientOperateur, noCompte, now);

    //Prepare mock
    mockRPGDatabaseProxyGetPFI(1);

    PowerMock.replayAll();

    PFIWorker _pfiWorker = _currentProcess.new PFIWorker(tracabilite, refChangedIdPfi_p, insfWriters);
    _pfiWorker.run();

    PowerMock.verifyAll();
  }

  /**
   * Test PFIWorker case RPGDatabaseProxy method GetPFI KO.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>KO - CAT4 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_20() throws Throwable
  {
    //Prepare test
    LocalDateTime now = LocalDateTime.now();
    Tracabilite tracabilite = new Tracabilite("idcorrelationBytel", "idcorrelation", "FORD", "processus", "1234", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$
    String noCompte = "xxxxx"; //$NON-NLS-1$
    List<INSFWriter> insfWriters = new ArrayList<>();

    RefChangedIdPfi refChangedIdPfi_p = new RefChangedIdPfi(clientOperateur, noCompte, now);

    //Prepare mock
    mockRPGDatabaseProxyGetPFI(2);

    PowerMock.replayAll();

    PFIWorker _pfiWorker = _currentProcess.new PFIWorker(tracabilite, refChangedIdPfi_p, insfWriters);
    _pfiWorker.run();

    PowerMock.verifyAll();
  }

  /**
   * Test PFIWorker case RPGDatabaseProxy method GetPFI RavelException.</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>Ravel Exception </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_21() throws Throwable
  {
    //Prepare test
    LocalDateTime now = LocalDateTime.now();
    Tracabilite tracabilite = new Tracabilite("idcorrelationBytel", "idcorrelation", "FORD", "processus", "1234", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$
    String noCompte = "xxxxx"; //$NON-NLS-1$x
    List<INSFWriter> insfWriters = new ArrayList<>();

    RefChangedIdPfi refChangedIdPfi_p = new RefChangedIdPfi(clientOperateur, noCompte, now);

    //Prepare mock
    mockRPGDatabaseProxyGetPFI(3);

    PowerMock.replayAll();

    PFIWorker _pfiWorker = _currentProcess.new PFIWorker(tracabilite, refChangedIdPfi_p, insfWriters);
    _pfiWorker.run();

    PowerMock.verifyAll();
  }

  /**
   * Test case Config Extraction Activite Sur Journee Invalid : File not in authorized activities</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK - CAT4 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0098_ProductionExtractionsActivitesSurJourneeTest_22() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(6);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    Assert.assertEquals(MessageFormat.format(com.bytel.spirit.ford.processes.Messages.getString("PP0098.FichierImpossible"), "activite"), jsonRetour.getLibelle()); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * Delete dir of tests
   *
   * @param name_p
   *          Dir Name
   */
  private void deleteDummieDir(String name_p)
  {
    Path pathTests = Paths.get(name_p);

    //if file exists?
    if (Files.exists(pathTests))
    {
      try
      {
        Files.delete(pathTests);
      }
      catch (IOException exception)
      {
        exception.printStackTrace();
      }
    }
  }

  /**
   * Generic test to validate Chemins
   *
   * @param paramOption
   *          Load Parameters option
   * @param requestOption
   *          Create Request Option
   * @throws Throwable
   *           Error
   */
  private void genericTestValidateChemins(Integer paramOption, Integer requestOption) throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(paramOption);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(requestOption);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    Assert.assertEquals("Le répertoire targetx n'existe pas", jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * Generic test to validate Chemins
   *
   * @param paramOption
   *          Load Parameters option
   * @param requestOption
   *          Create Request Option
   * @throws Throwable
   *           Error
   */
  private void genericTestValidateModeExecution(Integer paramOption, Integer requestOption) throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(paramOption);

    //    createDummieDir(TESTS_DIR);
    //    createDummieFile(TESTS_DIR);

    //Prepare mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(13);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters);
    EasyMock.expectLastCall().anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(requestOption);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    String libelle = "Le mode d'exécution passée en entrée n'est pas connu de SPIRIT"; //$NON-NLS-1$

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, jsonRetour.getDiagnostic());
    Assert.assertEquals(libelle, jsonRetour.getLibelle());
    //    deleteDummieFile(TESTS_DIR);
    //    deleteDummieDir(TESTS_DIR);
  }

  /**
   * Method for returning Retour from Request
   *
   * @param request
   *          Request
   * @return Retour
   */
  private com.bytel.ravel.types.Retour getRetourFromRequest(Request request)
  {
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    return GsonTools.getIso8601Ms().fromJson(resp, com.bytel.ravel.types.Retour.class);
  }

  /**
   * Load parameters for loadConfiguration values
   *
   * @param option
   *          option for specific alterations
   *
   * @return return Parameters
   */
  private ConcurrentHashMap<String, Map<String, String>> loadParameters(Integer option)
  {
    Map<String, String> myMap = new ConcurrentHashMap<String, String>();

    myMap.put("poolSize", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("waitingFileSize", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("endingTimeout", "6000000"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("pushTimeout", "600000"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("cheminRepTravail", tempWorkFilePath); //$NON-NLS-1$
    myMap.put("cheminRepArchiveSucces", tempSuccessFilePath); //$NON-NLS-1$
    myMap.put("cheminRepArchiveErreur", tempErrorFilePath); //$NON-NLS-1$
    myMap.put("environnement", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("nomServeurDistant", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("compteDistant", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("cheminRepDepotDistant", tempWorkFilePath); //$NON-NLS-1$
    myMap.put("listeExtractionActiviteAProduire", "SPIRIT-PFI"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("linesToFlush", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("chaineConnexion", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("activateMultiThread", "true"); //$NON-NLS-1$ //$NON-NLS-2$

    switch (option)
    {
      case 0:
        myMap.clear();
        break;
      case 1:
        myMap.replace("cheminRepTravail", "targetx"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      case 2:
        myMap.replace("cheminRepArchiveSucces", "targetx"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      case 3:
        myMap.replace("cheminRepArchiveErreur", "targetx"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      case 4:
        myMap.replace("cheminRepTravail", EMPTY_DIR); //$NON-NLS-1$
        break;
      case 5:
        myMap.remove("compteDistant"); //$NON-NLS-1$
        myMap.remove("cheminRepDepotDistant"); //$NON-NLS-1$
        break;
      case 6:
        myMap.replace("listeExtractionActiviteAProduire", "activite"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      default:
        break;
    }

    ConcurrentHashMap<String, Map<String, String>> finalParameters = new ConcurrentHashMap<String, Map<String, String>>();
    finalParameters.put("", myMap); //$NON-NLS-1$

    return finalParameters;
  }

  /**
   * Mock method of BL1200
   *
   * @param bl1200Retour_p
   *          Retour of BL1200
   * @param optionRetour
   *          Option do define Retour
   * @throws Exception
   *           Exception
   */
  private void mockBL1200(Retour bl1200Retour_p, Integer optionRetour) throws Exception
  {
    PowerMock.expectNew(BL1200_DeplacerFichierBuilder.class).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.nomFichier(EasyMock.anyString())).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireSrc(EasyMock.anyString())).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.repertoireDes(EasyMock.anyString())).andReturn(_bl1200BuilderMock);
    EasyMock.expect(_bl1200BuilderMock.build()).andReturn(_bl1200Mock);
    //    _currentProcess.bl1200Builder = () -> _bl1200BuilderMock;

    switch (optionRetour)
    {
      case 1:
        EasyMock.expect(_bl1200Mock.execute(_currentProcess)).andReturn(null);
        //EasyMock.expect(_bl1200Mock.getRetour()).andReturn(bl1200Retour_p);
        break;
      case 2:
        EasyMock.expect(_bl1200Mock.execute(_currentProcess)).andThrow(new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));
        break;
      default:
        break;
    }
  }

  /**
   * Mock method of BL1400
   *
   * @param bl1400Retour_p
   *          Retour of BL1400
   * @param optionRetour
   *          Type of Retour option
   * @throws Exception
   *           Exception
   */
  private void mockBL1400(Retour bl1400Retour_p, Integer optionRetour) throws Exception
  {
    PowerMock.expectNew(BL1400_EmettreFichierBuilder.class).andReturn(_bl1400BuilderMock);
    EasyMock.expect(_bl1400BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_bl1400BuilderMock);
    EasyMock.expect(_bl1400BuilderMock.chaineConnexion(EasyMock.anyString())).andReturn(_bl1400BuilderMock);
    EasyMock.expect(_bl1400BuilderMock.nomFichier(EasyMock.anyString())).andReturn(_bl1400BuilderMock);
    EasyMock.expect(_bl1400BuilderMock.repertoireSrc(EasyMock.anyString())).andReturn(_bl1400BuilderMock);
    EasyMock.expect(_bl1400BuilderMock.repertoireArchiveSucces(EasyMock.anyString())).andReturn(_bl1400BuilderMock);
    EasyMock.expect(_bl1400BuilderMock.cheminRepDepotDistant(EasyMock.anyString())).andReturn(_bl1400BuilderMock);
    EasyMock.expect(_bl1400BuilderMock.build()).andReturn(_bl1400Mock);
    //    _currentProcess.bl1400Builder = () -> _bl1400BuilderMock;

    switch (optionRetour)
    {
      case 1:
        EasyMock.expect(_bl1400Mock.execute(_currentProcess)).andReturn(null);
        EasyMock.expect(_bl1400Mock.getRetour()).andReturn(bl1400Retour_p);
        break;
      case 2:
        EasyMock.expect(_bl1400Mock.execute(_currentProcess)).andThrow(new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));
        break;
      default:
        break;
    }
  }

  /**
   * Mock of method GetIdPfiChangedOverGivenPeriod of class RPGDatabaseProxy
   *
   * @param option
   *          option for Retour
   * @throws RavelException
   *           Ravel Exception
   */
  private void mockRPGDatabaseProxyGetIdPfiChangedOverGivenPeriod(Integer option) throws RavelException
  {

    ConnectorResponse<Retour, Nothing> response = null;
    switch (option)
    {
      case 1:
        response = new ConnectorResponse<Retour, Nothing>(RetourFactory.createOkRetour(), null);
        break;
      case 2:
        response = new ConnectorResponse<Retour, Nothing>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), null);
        break;
      case 3:
        response = new ConnectorResponse<Retour, Nothing>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, IMegSpiritConsts.TIMEOUT, StringConstants.EMPTY_STRING), null);
        break;
      case 4:
        response = new ConnectorResponse<Retour, Nothing>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, IMegConsts.DONNEE_INCONNUE, StringConstants.EMPTY_STRING), null);
        break;
      default:
        break;
    }

    EasyMock.expect(RPGDatabaseProxy.getInstance()).andReturn(_rpgDatabaseProxy);
    EasyMock.expect(_rpgDatabaseProxy.getIdPfiChangedOverGivenDate(EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(response);
  }

  /**
   * Mock RPGDatabaseProxy method GetPFI
   *
   * @param option
   *          Option for retour
   *
   * @throws RavelException
   *           Ravel Exception
   */
  private void mockRPGDatabaseProxyGetPFI(Integer option) throws RavelException
  {
    LocalDateTime now = LocalDateTime.now();
    Titulaire titu = new Titulaire(TypeTitulaire.ENTREPRISE, "111222333", null, null); //$NON-NLS-1$
    titu.setEmail("chuck.noris@gmail.com"); //$NON-NLS-1$
    titu.setNoTel("0955221122"); //$NON-NLS-1$
    titu.setEntreprise(new Entreprise("noSirentest", "raisonSocialetest")); //$NON-NLS-1$ //$NON-NLS-2$
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompte = "xxxxx"; //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite("idcorrelationBytel", "idcorrelation", "FORD", "processus", "1234", null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    SA sa1 = new SA("sa1", "sa1 xx", "sa1 service", "categorie test", Statut.ACTIF, now, now); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    PA pa1 = new PA("pa1", "LIGNE_FIXE", Statut.RESILIE, now, now); //$NON-NLS-1$ //$NON-NLS-2$
    PA pa2 = new PA("pa2", "LIGNE_FIXE", Statut.ACTIF, now, now); //$NON-NLS-1$ //$NON-NLS-2$
    PFI pfi = new PFI(clientOperateur, noCompte, Statut.ACTIF, "ENT", titu, now, now); //$NON-NLS-1$
    pfi.setSa(Arrays.asList(sa1));
    pfi.setPa(Arrays.asList(pa1, pa2));
    pfi.setLienSAPA(new ArrayList<>());
    pfi.setEquipementDeclare(new ArrayList<>());
    pfi.setLienEquipementPA(new ArrayList<>());

    PowerMock.mockStatic(RPGDatabaseProxy.class);
    EasyMock.expect(RPGDatabaseProxy.getInstance()).andReturn(_rpgDatabaseProxy);

    switch (option)
    {
      case 1:
        //        EasyMock.expect(_rpgDatabaseProxy.getPfi(EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andAnswer(() -> {
        //          return new ConnectorResponse<Retour, PFI>(RetourFactory.createOkRetour(), pfi);
        //        });
        EasyMock.expect(_rpgDatabaseProxy.getPfi(EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<Retour, PFI>(RetourFactory.createOkRetour(), pfi));
        ;
        break;
      case 2:
        //        EasyMock.expect(_rpgDatabaseProxy.getPfi(EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andAnswer(() -> {
        //          return new ConnectorResponse<Retour, PFI>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), pfi);
        //        });
        EasyMock.expect(_rpgDatabaseProxy.getPfi(EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<Retour, PFI>(RetourFactory.createNOK(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), pfi));
        break;
      case 3:
        EasyMock.expect(_rpgDatabaseProxy.getPfi(EasyMock.anyObject(), EasyMock.anyObject(), EasyMock.anyObject())).andThrow(new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));
        break;
      default:
        break;
    }
  }
}
