/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0378;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang3.RandomStringUtils;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IUrlParameters;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier.BL1300_CreerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder;
import com.bytel.spirit.common.ford.config.ConfigurationFluxExtraction;
import com.bytel.spirit.common.ford.config.GenericProcessConfig;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.saab.common.utils.FunctionalConst;
import com.bytel.spirit.saab.connectors.air.AIRDatabaseProxy;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PP0378_ExtractionMigrationAbonnesVIMS.class, ProcessManager.class, AIRDatabaseProxy.class, BL1300_CreerFichierBuilder.class, BL4300_EnvoyerFichier.class, BL4300_EnvoyerFichierBuilder.class, MarshallTools.class })
public class PP0378_ExtractionMigrationAbonnesVIMS_Test
{
  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   * Path to config file
   */
  private static String _confFilePath;

  /**
   * Temp File Path
   */
  private static String _tempWorkFilePath = null;

  /**
   * Temp File Path
   */
  private static String _tempSuccessFilePath = null;

  /**
   * Temp File Path
   */
  private static String _tempErrorFilePath = null;

  /**
   * Temporary file for tests
   */
  private static File _temp = null;

  /**
   * Temporary file for tests
   */
  private static File _temp1 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp2 = null;

  /**
   * The CHAINE_CONNECTION constant
   */
  private static final String CHAINE_CONNECTION_DEFAULT = "sftp://spirittest@gas-y.pin.dolmen.bouyguestelecom.fr:2222/in/spiritqod/in/?sftpkeyfile=/var/run/secrets/TEST_GAS_KEY&auth=publickey"; //$NON-NLS-1$

  /**
   * Mode execution parameter name
   */
  private static final String MODE_EXECUTION_PARAM = "modeExecution"; //$NON-NLS-1$

  /**
   * The ProduireExtractions constant.
   */
  private static final String PRODUIRE_EXTRACTIONS = "ProduireExtractions"; //$NON-NLS-1$

  /**
   * The TransfererFichiers constant.
   */
  private static final String TRANSFERER_FICHIERS = "TransfererFichiers"; //$NON-NLS-1$

  /**
   * The SPIRIT-MIGRATION_VIMS constant.
   */
  private static final String SPIRIT_MIGRATION_VIMS = "SPIRIT-MIGRATION_VIMS"; //$NON-NLS-1$

  /**
   *
   */
  private static final String LISTE_NOM_FQDN_PARAM = "listeNomFqdn"; //$NON-NLS-1$

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);
  }

  /**
   * @return GenericProcessConfig
   */
  private static GenericProcessConfig createDefaultConfig()
  {
    GenericProcessConfig genericProcessConfig = new GenericProcessConfig();
    genericProcessConfig.setActivateMultiThread(true);
    genericProcessConfig.setCheminRepArchiveErreur(_tempErrorFilePath);
    genericProcessConfig.setCheminRepArchiveSucces(_tempSuccessFilePath);
    genericProcessConfig.setCheminRepTravail(_tempWorkFilePath);
    genericProcessConfig.setDureeRetentionTmp(0);
    genericProcessConfig.setEndingTimeout(1000);
    genericProcessConfig.setExtensionFichierTemporaire(".tmp"); //$NON-NLS-1$
    genericProcessConfig.setLinesToFlush(5);
    genericProcessConfig.setPoolSize(2);
    genericProcessConfig.setPushTimeout(1000);
    genericProcessConfig.setWaitingFileSize(2);

    ConfigurationFluxExtraction confFluxExtraction1 = new ConfigurationFluxExtraction();
    confFluxExtraction1.setIdFluxExtraction(SPIRIT_MIGRATION_VIMS);
    confFluxExtraction1.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confFluxExtraction1.setPattern(SPIRIT_MIGRATION_VIMS + ".*"); //$NON-NLS-1$

    genericProcessConfig.getConfigurationFluxExtraction().add(confFluxExtraction1);
    genericProcessConfig.setIdFluxExtractionAutorises(SPIRIT_MIGRATION_VIMS);

    return genericProcessConfig;
  }

  /**
   * Create Dir for Tests
   *
   */
  private static void createDummieDirFilesAndConfig()
  {
    File classpath = new File(PP0378_ExtractionMigrationAbonnesVIMS_Test.class.getResource("/").getFile()); //$NON-NLS-1$
    _temp = new File(classpath, "temp" + RandomStringUtils.random(10)); //$NON-NLS-1$;
    _temp.mkdir();

    _temp1 = null;
    _temp2 = null;

    try
    {
      File confFile = new File(_temp, "conf.xml"); //$NON-NLS-1$
      confFile.createNewFile();

      File workFolder = new File(_temp, "work"); //$NON-NLS-1$
      workFolder.mkdir();
      File successFolder = new File(_temp, "success");//$NON-NLS-1$
      successFolder.mkdir();
      File errorFolder = new File(_temp, "error");//$NON-NLS-1$
      errorFolder.mkdir();

      _temp1 = File.createTempFile(SPIRIT_MIGRATION_VIMS + "01", ".csv.tmp", workFolder); //$NON-NLS-1$ //$NON-NLS-2$
      _temp2 = File.createTempFile(SPIRIT_MIGRATION_VIMS + "02", ".csv", workFolder); //$NON-NLS-1$ //$NON-NLS-2$

      //Get temporary file path
      _tempWorkFilePath = workFolder.getAbsolutePath() + File.separator;
      _tempSuccessFilePath = successFolder.getAbsolutePath() + File.separator;
      _tempErrorFilePath = errorFolder.getAbsolutePath() + File.separator;

      GenericProcessConfig genericProcessConfig = createDefaultConfig();

      JAXBContext jaxbContext = JAXBContext.newInstance(GenericProcessConfig.class);
      Marshaller marshaller = jaxbContext.createMarshaller();
      marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

      _confFilePath = confFile.getAbsolutePath();
      FileOutputStream fos = new FileOutputStream(confFile);
      marshaller.marshal(genericProcessConfig, fos);
    }
    catch (IOException exception)
    {
      exception.printStackTrace();
    }
    catch (JAXBException jaxbException)
    {
      jaxbException.printStackTrace();
    }
  }

  /**
   * Create Request for tests
   *
   * @param option_p
   *          test option
   * @param listeNomFqdn_p
   *          listeNomFqdn
   * @return return Request
   * @throws RavelException
   *           ravel Exception
   */
  private static Request createRequest(Integer option_p, String listeNomFqdn_p) throws RavelException
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(IHttpHeadersConsts.X_REQUEST_ID);
    requestHeader.setValue("PP0378"); //$NON-NLS-1$

    Request request = new Request("PP0378_ExtractionMigrationAbonnesVIMS", StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING); //$NON-NLS-1$
    request.getRequestHeader().add(requestHeader);

    List<Parameter> parameters = new ArrayList<>();
    Parameter parameterModeExec = null;
    Parameter parameterListeNomFqdn = null;
    IUrlParameters urlParameters = null;

    switch (option_p)
    {
      case 1:
        parameterModeExec = new Parameter(MODE_EXECUTION_PARAM, "X"); //$NON-NLS-1$
        parameters.add(parameterModeExec);
        break;
      case 2:
        parameterModeExec = new Parameter(MODE_EXECUTION_PARAM, PRODUIRE_EXTRACTIONS);
        parameters.add(parameterModeExec);
        break;
      case 3:
        parameterModeExec = new Parameter(MODE_EXECUTION_PARAM, TRANSFERER_FICHIERS);
        parameters.add(parameterModeExec);
        break;
      case 4:
        request.getRequestHeader().remove(0);
        break;
      default:
        break;
    }
    if (StringTools.isNotNullOrEmpty(listeNomFqdn_p))
    {
      parameterListeNomFqdn = new Parameter(LISTE_NOM_FQDN_PARAM, listeNomFqdn_p);
      parameters.add(parameterListeNomFqdn);
    }
    urlParameters = new UrlParameters(parameters);
    request.setUrlParameters(urlParameters);

    return request;
  }

  /**
   * Mock of {AIRDatabaseProxy}
   */
  @MockStrict
  private AIRDatabaseProxy _airDBMock;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  private ProcessManager _processManager;

  /**
   * process testé
   */
  private PP0378_ExtractionMigrationAbonnesVIMS _currentProcess;

  /**
   * Mock de {@link BL1300_CreerFichier}
   */
  @MockStrict
  BL1300_CreerFichier _bl1300Mock;

  /**
   * Mock de {@link BL1300_CreerFichierBuilder}
   */
  @MockStrict
  BL1300_CreerFichierBuilder _bl1300BuilderMock;

  /**
   * Mock de {@link BL4300_EnvoyerFichier}
   */
  @MockStrict
  BL4300_EnvoyerFichier _bl4300Mock;

  /**
   * Mock de {@link BL4300_EnvoyerFichierBuilder}
   */
  @MockStrict
  BL4300_EnvoyerFichierBuilder _bl4300BuilderMock;

  /**
   * Cleans the Connector Mocks responses
   *
   * @throws Exception
   *           On Error
   */
  @Before
  public void beforeTest() throws Exception
  {
    _currentProcess = new PP0378_ExtractionMigrationAbonnesVIMS();
    _currentProcess.initializeContext();

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(BL1300_CreerFichier.class);
    PowerMock.mockStaticStrict(BL1300_CreerFichierBuilder.class);
    PowerMock.mockStaticStrict(BL4300_EnvoyerFichier.class);
    PowerMock.mockStaticStrict(BL4300_EnvoyerFichierBuilder.class);
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStaticStrict(AIRDatabaseProxy.class);
    PowerMock.mockStaticStrict(MarshallTools.class);
    createDummieDirFilesAndConfig();

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
  }

  /**
   * Delete temp File
   */
  @After
  public void end()
  {
    _temp1.deleteOnExit();
    _temp2.deleteOnExit();
    _temp.deleteOnExit();
  }

  /**
   * Test case KO, request</br>
   *
   * <Enttrées>mode_execution is null </Entrées> </br>
   * <Attendus>NOK, NON_RESPECT_STI </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_001() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(5, null);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT3, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.NON_RESPECT_STI, jsonRetour.getDiagnostic());
  }

  /**
   * Test case KO, request</br>
   *
   * <Enttrées>mode_execution invalid </Entrées> </br>
   * <Attendus>NOK, NON_RESPECT_STI </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_002() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(1, null);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT3, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.NON_RESPECT_STI, jsonRetour.getDiagnostic());
  }

  /**
   * Test case KO, request</br>
   *
   * <Enttrées>mode_execution=PRODUIRE but listeNomFqdn is null</Entrées> </br>
   * <Attendus>NOK, NON_RESPECT_STI </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_003() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(2, null);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT3, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.NON_RESPECT_STI, jsonRetour.getDiagnostic());
  }

  /**
   * Test case KO, empty FILE_PATH</br>
   *
   * <Enttrées>valid input</Entrées> </br>
   * <Attendus>NOK, NON_RESPECT_STI </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_004() throws Throwable
  {
    //Prepare test
    _confFilePath = StringConstants.EMPTY_STRING;
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(2, FunctionalConst.NOM_FQDN);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
  }

  /**
   * Test case NOK BL001, cheminRepTravail parameter </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_005() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);

    GenericProcessConfig conf = createDefaultConfig();
    conf.setCheminRepTravail(StringConstants.EMPTY_STRING);
    conf.getConfigurationFluxExtraction().get(0).setIdFluxExtraction("invalid"); //$NON-NLS-1$

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    PowerMock.replayAll();

    Request request = createRequest(2, FunctionalConst.NOM_FQDN);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config cheminRepTravail sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());
  }

  /**
   * Test case NOK BL001, no valid idFluxExtraction parameter </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_006() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);

    GenericProcessConfig conf = createDefaultConfig();
    conf.setIdFluxExtractionAutorises("ST-TOTO"); //$NON-NLS-1$
    conf.getConfigurationFluxExtraction().get(0).setIdFluxExtraction("invalid"); //$NON-NLS-1$

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    PowerMock.replayAll();

    Request request = createRequest(2, FunctionalConst.NOM_FQDN);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Flux d'extraction ST-TOTO inconnu(s)."; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());
  }

  /**
   * Test case NOK BL001, no valid idFluxExtraction parameter </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_007() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);

    GenericProcessConfig conf = createDefaultConfig();
    conf.getConfigurationFluxExtraction().get(0).setIdFluxExtraction(null);

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    PowerMock.replayAll();

    Request request = createRequest(2, FunctionalConst.NOM_FQDN);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config idFluxExtraction sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());
  }

  /**
   * Test case NOK BL001, no valid idFluxExtraction parameter </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_008() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);

    GenericProcessConfig conf = createDefaultConfig();
    conf.getConfigurationFluxExtraction().get(0).setPattern(null);

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    PowerMock.replayAll();

    Request request = createRequest(2, FunctionalConst.NOM_FQDN);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config pattern sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());
  }

  /**
   * Test case NOK BL001, no valid idFluxExtraction parameter </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_009() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);

    GenericProcessConfig conf = createDefaultConfig();
    conf.getConfigurationFluxExtraction().get(0).setChaineConnexion(null);

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    PowerMock.replayAll();

    Request request = createRequest(2, FunctionalConst.NOM_FQDN);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config chaineConnexion sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());
  }

  /**
   * Test case NOK BL100->BL901 </br>
   *
   * <Enttrées>modeExecution=PRODUIRE_EXTRACTIONS </Entrées> </br>
   * <Attendus>Generic KO</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_010() throws Throwable
  {
    //Prepare test
    expectRequestAndConf();

    expectBL1300(RetourFactory.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE));

    PowerMock.replayAll();

    Request request = createRequest(2, FunctionalConst.NOM_FQDN);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CATEGORIE, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.DIAGNOSTIC, jsonRetour.getDiagnostic());
    Assert.assertEquals(IMegConsts.LIBELLE, jsonRetour.getLibelle());
  }

  /**
   * Test case NOK BL100->AIRConnector TIMEOUT </br>
   *
   * <Enttrées>modeExecution=PRODUIRE_EXTRACTIONS </Entrées> </br>
   * <Attendus>Generic KO WITH DIAGNOSTIC TIMEOUT</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_011() throws Throwable
  {
    //Prepare test
    expectRequestAndConf();

    expectBL1300(RetourFactory.createOkRetour());
    expectAIR(RetourFactory.createNOK(IMegConsts.CATEGORIE, IMegSpiritConsts.TIMEOUT, IMegConsts.LIBELLE));

    PowerMock.replayAll();

    Request request = createRequest(2, FunctionalConst.NOM_FQDN);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CATEGORIE, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TIMEOUT, jsonRetour.getDiagnostic());
    Assert.assertEquals(IMegConsts.LIBELLE, jsonRetour.getLibelle());
  }

  /**
   * Test case NOK BL200->BL4300 returns generic KO </br>
   *
   * <Enttrées>modeExecution=TRANSFERER_FICHIERS </Entrées> </br>
   * <Attendus>Generic KO</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_KO_012() throws Throwable
  {
    //Prepare test
    expectRequestAndConf();

    expectBL4300(1);

    PowerMock.replayAll();

    Request request = createRequest(3, null);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CATEGORIE, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.DIAGNOSTIC, jsonRetour.getDiagnostic());
    Assert.assertEquals(IMegConsts.LIBELLE, jsonRetour.getLibelle());
  }

  /**
   * Test case NOK BL100->BL901 </br>
   *
   * <Enttrées>modeExecution=PRODUIRE_EXTRACTIONS </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_OK_001() throws Throwable
  {
    //Prepare test
    expectRequestAndConf();

    expectBL1300(RetourFactory.createOkRetour());
    expectAIR(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(2, FunctionalConst.NOM_FQDN);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case NOK BL200->BL4300 returns generic KO|CAT-1 </br>
   *
   * <Enttrées>modeExecution=TRANSFERER_FICHIERS </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_OK_002() throws Throwable
  {
    //Prepare test
    expectRequestAndConf();

    expectBL4300(2);

    PowerMock.replayAll();

    Request request = createRequest(3, null);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case NOK BL200->BL4300 returns generic OK </br>
   *
   * <Enttrées>modeExecution=TRANSFERER_FICHIERS </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0378_ExtractionsMigrationAbonnesVIMS_Test_OK_003() throws Throwable
  {
    //Prepare test
    expectRequestAndConf();

    expectBL4300(3);

    PowerMock.replayAll();

    Request request = createRequest(3, null);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Expect the call to AIRDatabaseConnector
   *
   * @param retour_p
   *          Retour to be returned
   * @throws Exception
   *           Unexpected error
   */
  private void expectAIR(Retour retour_p) throws Exception
  {
    EasyMock.expect(AIRDatabaseProxy.getInstance()).andReturn(_airDBMock);
    EasyMock.expect(_airDBMock.getAllIndexRecherchePfiByCleRecherche(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("NOM_FQDN"), EasyMock.eq(FunctionalConst.NOM_FQDN), EasyMock.eq(_currentProcess))).andReturn(new ConnectorResponse<>(retour_p, null)); //$NON-NLS-1$
  }

  /**
   * Expect the call to BL1300_CreerFichier
   *
   * @param retour_p
   *          Retour to be returned
   * @throws Exception
   *           Unexpected error
   */
  private void expectBL1300(Retour retour_p) throws Exception
  {
    PowerMock.expectNew(BL1300_CreerFichierBuilder.class).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.repertoire(_tempWorkFilePath)).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.nomFichier(EasyMock.anyString())).andReturn(_bl1300BuilderMock);
    EasyMock.expect(_bl1300BuilderMock.build()).andReturn(_bl1300Mock);
    EasyMock.expect(_bl1300Mock.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl1300Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Expect call to BL4300
   *
   * @param case_p
   *          test case. 1-KO|CATEGORIE, 2-KO|CAT1, 3-OK
   * @throws Exception
   *           Unexpected error
   */
  private void expectBL4300(int case_p) throws Exception
  {
    PowerMock.expectNew(BL4300_EnvoyerFichierBuilder.class).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.chaineConnexion(EasyMock.anyString())).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.nomFichier(EasyMock.anyString())).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.repertoire(EasyMock.anyString())).andReturn(_bl4300BuilderMock);
    EasyMock.expect(_bl4300BuilderMock.build()).andReturn(_bl4300Mock);
    EasyMock.expect(_bl4300Mock.execute(_currentProcess)).andReturn(null);

    switch (case_p)
    {
      case 1:
        EasyMock.expect(_bl4300Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE));
        break;
      case 2:
        EasyMock.expect(_bl4300Mock.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE));
        break;
      default:
        EasyMock.expect(_bl4300Mock.getRetour()).andReturn(RetourFactory.createOkRetour());
        break;
    }
  }

  /**
   * @throws RavelException
   *           Unexpected error
   */
  private void expectRequestAndConf() throws RavelException
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
  }

  /**
   * Method for returning Retour from Request
   *
   * @param request
   *          Request
   * @return Retour
   */
  private com.bytel.ravel.types.Retour getRetourFromRequest(Request request)
  {
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    return GsonTools.getIso8601Ms().fromJson(resp, com.bytel.ravel.types.Retour.class);
  }

  /**
   * Load parameters for loadConfiguration values
   *
   * @return return Parameters
   */
  private ConcurrentHashMap<String, Map<String, String>> loadParameters()
  {
    Map<String, String> myMap = new ConcurrentHashMap<>();
    myMap.put("FILE_PATH", _confFilePath); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> finalParameters = new ConcurrentHashMap<>();
    finalParameters.put("", myMap); //$NON-NLS-1$

    return finalParameters;
  }
}
