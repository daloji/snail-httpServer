/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0257;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.concurrent.ConcurrentUtils;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.configuration.ConfigFileManager;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IUrlParameters;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.JUnitTools;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier.BL1300_CreerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier.BL3400_SupprimerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder;
import com.bytel.spirit.common.ford.config.ConfigurationFluxExtraction;
import com.bytel.spirit.common.ford.config.GenericProcessConfig;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.ford.processes.PP0257.PP0257_ExtrationRessources.PP0257_ExtrationRessourcesContext;
import com.bytel.spirit.ford.processes.PP0257.writers.CompteImsWriter;
import com.bytel.spirit.ford.shared.misc.processes.FordProcessSkeleton;
import com.bytel.spirit.ford.shared.misc.processes.Messages;
import com.bytel.spirit.saab.connectors.res.RESDatabaseProxy;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author fmonteir
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PP0257_ExtrationRessources.class, RESDatabaseProxy.class, BL1300_CreerFichierBuilder.class, BL1300_CreerFichier.class, //
    BL4300_EnvoyerFichierBuilder.class, BL4300_EnvoyerFichier.class, //
    BL3400_SupprimerFichierBuilder.class, BL3400_SupprimerFichier.class, //
    BL1300_CreerFichierBuilder.class, BL1300_CreerFichier.class, //
    RESDatabaseProxy.class, //
    ProcessManager.class, MarshallTools.class//
})
public class PP0257_ExtrationRessourcesTest
{
  private static class CustomFuture implements Future<Retour>
  {
    /**
     *
     */
    private static final String NESTED_EXCEPTION = "nested exception"; //$NON-NLS-1$
    int _option;

    /**
     * @param option_p
     */
    public CustomFuture(int option_p)
    {
      _option = option_p;
    }

    @Override
    public boolean cancel(boolean mayInterruptIfRunning_p)
    {
      // TODO Auto-generated method stub
      return false;
    }

    @Override
    public Retour get() throws InterruptedException, ExecutionException
    {
      // TODO Auto-generated method stub
      return null;
    }

    @Override
    public Retour get(long timeout_p, TimeUnit unit_p) throws InterruptedException, ExecutionException, TimeoutException
    {
      switch (_option)
      {
        case 0:
          throw new TimeoutException();
        case 1:
          throw new ExecutionException(new Exception(NESTED_EXCEPTION));
        case 2:
          return RetourFactory.createNOK("xxx", "xxx", "xxx"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
        default:
          return RetourFactory.createOkRetour();
      }
    }

    @Override
    public boolean isCancelled()
    {
      // TODO Auto-generated method stub
      return false;
    }

    @Override
    public boolean isDone()
    {
      // TODO Auto-generated method stub
      return false;
    }

  }

  /**
   *
   */
  private static final String CHAINE_CONNECTION_DEFAULT = "sftp://spirittest@gas-y.pin.dolmen.bouyguestelecom.fr:2222/in/spiritqod/in/?sftpkeyfile=/var/run/secrets/TEST_GAS_KEY&auth=publickey"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ID_FLUX_EXTRACTION = "idFluxExtraction"; //$NON-NLS-1$

  /**
   * The SPIRIT-RES-COMPTEMAIL flux id
   */
  private static final String SPIRIT_RES_COMPTEMAIL = "SPIRIT-RES-COMPTEMAIL"; //$NON-NLS-1$

  /**
   * The SPIRIT-RES-COMPTEIMS flux id
   */
  private static final String SPIRIT_RES_COMPTEIMS = "SPIRIT-RES-COMPTEIMS"; //$NON-NLS-1$

  /**
   * The SPIRIT-RES-IMPIFIXE flux id
   */
  private static final String SPIRIT_RES_IMPIFIXE = "SPIRIT-RES-IMPIFIXE"; //$NON-NLS-1$

  /**
   * The SPIRIT-RES-ADRIPCLF flux id
   */
  private static final String SPIRIT_RES_ADRIPCLF = "SPIRIT-RES-ADRIPCLF"; //$NON-NLS-1$

  /**
   * SPIRIT_RES_MOTDEPASSEIMS
   */
  private static final String SPIRIT_RES_MOTDEPASSEIMS = "SPIRIT-RES-MOTDEPASSEIMS"; //$NON-NLS-1$

  /**
   * The ProduireExtractions constant.
   */
  private static final String PRODUIRE_EXTRACTIONS = "ProduireExtractions"; //$NON-NLS-1$

  /**
   * Mode execution parameter name
   */
  private static final String MODE_EXECUTION_PARAM = "modeExecution"; //$NON-NLS-1$

  /**
   * ConfigFileManager singleton
   */
  private static ConfigFileManager _configFileManager;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory _podam = new PodamFactoryImpl();
  /**
  *
  */
  private static File _temp = null;

  /**
   * Temporary file for tests
   */
  private static File _temp1 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp2 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp3 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp4 = null;

  /**
   * Temporary file for tests
   */
  private static File _temp5 = null;

  private static String _tempWorkFilePath;

  private static String _tempSuccessFilePath;
  private static String _tempErrorFilePath;

  private static String _confFilePath;

  /**
   * The EMPTY_DIR constant.
   */
  private static final String EMPTY_DIR = "emptyDir"; //$NON-NLS-1$

  /**
   * The TransfererFichiers constant.
   */
  private static final String TRANSFERER_FICHIERS = "TransfererFichiers"; //$NON-NLS-1$

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    _configFileManager = new ConfigFileManager("."); //$NON-NLS-1$
    _podam = new PodamFactoryImpl();

  }

  /**
   * @return
   */
  private static GenericProcessConfig createDefaultConfig()
  {
    GenericProcessConfig genericProcessConfig = new GenericProcessConfig();
    genericProcessConfig.setActivateMultiThread(true);
    genericProcessConfig.setCheminRepArchiveErreur(_tempErrorFilePath);
    genericProcessConfig.setCheminRepArchiveSucces(_tempSuccessFilePath);
    genericProcessConfig.setCheminRepTravail(_tempWorkFilePath);
    genericProcessConfig.setDureeRetentionTmp(0);
    genericProcessConfig.setEndingTimeout(1000);
    genericProcessConfig.setExtensionFichierTemporaire(".tmp"); //$NON-NLS-1$
    genericProcessConfig.setLinesToFlush(10);
    genericProcessConfig.setPoolSize(2);
    genericProcessConfig.setPushTimeout(1000);
    genericProcessConfig.setWaitingFileSize(2);

    ConfigurationFluxExtraction confConfExtraction = new ConfigurationFluxExtraction();
    confConfExtraction.setIdFluxExtraction(SPIRIT_RES_COMPTEMAIL);
    confConfExtraction.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confConfExtraction.setPattern(SPIRIT_RES_COMPTEMAIL + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confConfExtraction2 = new ConfigurationFluxExtraction();
    confConfExtraction2.setIdFluxExtraction(SPIRIT_RES_COMPTEIMS);
    confConfExtraction2.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confConfExtraction2.setPattern(SPIRIT_RES_COMPTEIMS + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confConfExtraction3 = new ConfigurationFluxExtraction();
    confConfExtraction3.setIdFluxExtraction(SPIRIT_RES_IMPIFIXE);
    confConfExtraction3.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confConfExtraction3.setPattern(SPIRIT_RES_IMPIFIXE + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confConfExtraction4 = new ConfigurationFluxExtraction();
    confConfExtraction4.setIdFluxExtraction(SPIRIT_RES_ADRIPCLF);
    confConfExtraction4.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confConfExtraction4.setPattern(SPIRIT_RES_ADRIPCLF + ".*"); //$NON-NLS-1$

    ConfigurationFluxExtraction confConfExtraction5 = new ConfigurationFluxExtraction();
    confConfExtraction5.setIdFluxExtraction(SPIRIT_RES_MOTDEPASSEIMS);
    confConfExtraction5.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confConfExtraction5.setPattern(SPIRIT_RES_MOTDEPASSEIMS + ".*"); //$NON-NLS-1$

    genericProcessConfig.getConfigurationFluxExtraction().add(confConfExtraction);
    genericProcessConfig.getConfigurationFluxExtraction().add(confConfExtraction2);
    genericProcessConfig.getConfigurationFluxExtraction().add(confConfExtraction3);
    genericProcessConfig.getConfigurationFluxExtraction().add(confConfExtraction4);
    genericProcessConfig.getConfigurationFluxExtraction().add(confConfExtraction5);

    genericProcessConfig.setIdFluxExtractionAutorises(SPIRIT_RES_COMPTEMAIL + ";" + SPIRIT_RES_COMPTEIMS + ";" + SPIRIT_RES_IMPIFIXE + ";" + SPIRIT_RES_ADRIPCLF + ";" + SPIRIT_RES_MOTDEPASSEIMS); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    return genericProcessConfig;
  }

  /**
   * Create Request for tests
   *
   * @param option_p
   *          test option: 1 - TransfererFichiers; 2 - ProduireExtractions
   * @param idFluxExtraction_p
   *          allowed values: SPIRIT-RES-COMPTEMAIL, SPIRIT-RES-COMPTEIMS, SPIRIT-RES-IMPIFIXE or SPIRIT-RES-ADRIPCLF
   * @return return Request
   * @throws RavelException
   *           ravel Exception
   */
  private static Request createRequest(Integer option_p, String idFluxExtraction_p) throws RavelException
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(IHttpHeadersConsts.X_REQUEST_ID);
    requestHeader.setValue("PP0257"); //$NON-NLS-1$

    Request request = new Request(PP0257_ExtrationRessources.class.getSimpleName(), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().add(requestHeader);

    List<Parameter> parameters = new ArrayList<>();
    Parameter parameterModeExec = null;
    Parameter parameterIdFluxExtraction = null;
    IUrlParameters urlParameters = null;

    switch (option_p)
    {
      case 1:
        parameterModeExec = new Parameter(MODE_EXECUTION_PARAM, TRANSFERER_FICHIERS);
        parameters.add(parameterModeExec);

        break;
      case 2:
        parameterModeExec = new Parameter(MODE_EXECUTION_PARAM, PRODUIRE_EXTRACTIONS);
        parameters.add(parameterModeExec);
        break;
      default:
        break;
    }

    if (StringTools.isNotNullOrEmpty(idFluxExtraction_p))
    {
      parameterIdFluxExtraction = new Parameter(ID_FLUX_EXTRACTION, idFluxExtraction_p);
      parameters.add(parameterIdFluxExtraction);
    }

    urlParameters = new UrlParameters(parameters);
    request.setUrlParameters(urlParameters);

    return request;
  }

  /**
   * Create Dir for Tests
   *
   * @throws JAXBException
   *           on error
   * @throws IOException
   *           on error
   *
   */
  private static void createTempDirsAndFiles() throws JAXBException, IOException
  {
    File classpath = new File(PP0257_ExtrationRessourcesTest.class.getResource("/").getFile()); //$NON-NLS-1$

    _temp = new File(classpath, "temp" + RandomStringUtils.randomAlphanumeric(5)); //$NON-NLS-1$;
    _temp.mkdir();
    File confFile = new File(_temp, "conf.xml"); //$NON-NLS-1$
    confFile.createNewFile();

    File workFolder = new File(_temp, "work"); //$NON-NLS-1$
    workFolder.mkdir();
    File successFolder = new File(_temp, "success");//$NON-NLS-1$
    successFolder.mkdir();
    File errorFolder = new File(_temp, "error");//$NON-NLS-1$
    errorFolder.mkdir();

    _temp = File.createTempFile(SPIRIT_RES_COMPTEMAIL, ".xxx", workFolder); //$NON-NLS-1$
    _temp2 = File.createTempFile(SPIRIT_RES_COMPTEIMS, ".xxx", workFolder); //$NON-NLS-1$
    _temp3 = File.createTempFile(SPIRIT_RES_IMPIFIXE, ".xxx", workFolder); //$NON-NLS-1$
    _temp4 = File.createTempFile(SPIRIT_RES_ADRIPCLF, ".xxx", workFolder); //$NON-NLS-1$
    _temp5 = File.createTempFile(SPIRIT_RES_MOTDEPASSEIMS, ".xxx", workFolder); //$NON-NLS-1$

    //Get temporary file path
    _tempWorkFilePath = workFolder.getAbsolutePath() + File.separator;
    _tempSuccessFilePath = successFolder.getAbsolutePath() + File.separator;
    _tempErrorFilePath = errorFolder.getAbsolutePath() + File.separator;

    GenericProcessConfig genericProcessConfig = createDefaultConfig();

    JAXBContext jaxbContext = JAXBContext.newInstance(GenericProcessConfig.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

    _confFilePath = confFile.getAbsolutePath();
    FileOutputStream fos = new FileOutputStream(confFile);
    marshaller.marshal(genericProcessConfig, fos);
  }

  /**
   *
   */
  PP0257_ExtrationRessourcesContext _processContext;

  /**
   * RES database proxy mock
   */
  @MockStrict
  private RESDatabaseProxy _resDatabaseProxy;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  private ProcessManager _processManager;

  /**
   * Mock de {@link BL4300_EnvoyerFichier}
   */
  @MockStrict
  private BL4300_EnvoyerFichier _bl4300_EnvoyerFichier;

  /**
   * Mock de {@link BL4300_EnvoyerFichier}
   */
  @MockStrict
  private BL1300_CreerFichier _bl1300_CreerFichier;

  /**
   * Mock de {@link BL4300_EnvoyerFichier}
   */
  @MockStrict
  private BL3400_SupprimerFichier _bl3400_SupprimerFichier;

  /**
   * extraction ressources
   */
  private PP0257_ExtrationRessources _currentProcess;

  /**
   * Cleans the Connector Mocks responses
   *
   * @throws Exception
   *           On Error
   */
  @Before
  public void beforeTest() throws Exception
  {
    createTempDirsAndFiles();
    _currentProcess = new PP0257_ExtrationRessources();
    _currentProcess.initializeContext();

    _processContext = PP0257_ExtrationRessourcesContext.class.cast(JUnitTools.getInaccessibleFieldValue(_currentProcess, "_processContext")); //$NON-NLS-1$

    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.resetAll();

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
  }

  /**
   * Test case OK BL001, BL200, date retained in file, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest01() throws Throwable
  {

    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);

    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-COMPTEMAIL is moved to success folder
    Assert.assertEquals(1, new File(_tempSuccessFilePath).listFiles().length);

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case OK BL001, BL200, retained date, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest02() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-COMPTEMAIL is moved to success folder
    Assert.assertEquals(1, new File(_tempSuccessFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case OK BL001, BL200, retained date, BL4300=CAT-1/NOK, BL1200=NOK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest03() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, "xxx", "xxx")); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-COMPTEMAIL is moved to success folder
    Assert.assertEquals(1, new File(_tempErrorFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case NOK BL001, BL200, not retained date, BL4300=CAT-1/NOK, BL1200=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest04() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, "xxx", "xxx")); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-COMPTEMAIL is moved to success folder
    Assert.assertEquals(1, new File(_tempErrorFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case NOK BL001, No pattern on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest05() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(0).setPattern(null);

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config pattern sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * Test case NOK BL001, BL200, retained date, BL3400</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest06() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();
    conf.setExtensionFichierTemporaire(".xxx"); //$NON-NLS-1$
    conf.setDureeRetentionTmp(-10000);

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL3400_SupprimerFichierBuilder mockBL3400Builder = PowerMock.createMockAndExpectNew(BL3400_SupprimerFichierBuilder.class);
    EasyMock.expect(mockBL3400Builder.fileName(_temp.getName())).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.repertoire(_tempWorkFilePath)).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.build()).andReturn(_bl3400_SupprimerFichier);
    EasyMock.expect(_bl3400_SupprimerFichier.execute(_currentProcess)).andReturn(null);

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case NOK BL001, No chaine de connexion on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest07() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(0).setChaineConnexion(""); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config chaineConnexion sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * Test case NOK BL001, No confFluxExtraction parameter</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest08() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(0).setIdFluxExtraction("anotherone"); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config confFluxExtraction sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());
  }

  /**
   * Test case OK BL001, BL100, BL101 </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest09() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceCompteMail(RetourFactory.createOkRetour());

    //add an "constant" future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(ConcurrentUtils.constantFuture(null))); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case OK BL100, BL101, Timeout </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest10() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceCompteMail(RetourFactory.createOkRetour());

    Future<Retour> future = new CustomFuture(0);//timeout future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TIMEOUT, jsonRetour.getDiagnostic());
    Assert.assertEquals(Messages.getString("FordProcessSkeleton.TimeoutError"), jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * Test case OK BL100, BL101, Traitement arreté </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest11() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceCompteMail(RetourFactory.createOkRetour());

    Future<Retour> future = new CustomFuture(1);//traitement arrete future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT10, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, jsonRetour.getDiagnostic());
  }

  /**
   * Test case OK BL100, BL101, async nok Retour from writer</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest12() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceCompteMail(RetourFactory.createOkRetour());

    CustomFuture future = new CustomFuture(2);//traitement arrete future

    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_COMPTEMAIL);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals("xxx", jsonRetour.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("xxx", jsonRetour.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("xxx", jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case OK BL001, BL200, date retained in file, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest13() throws Throwable
  {

    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp2.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp2.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);

    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-COMPTEMAIL is moved to success folder
    Assert.assertEquals(1, new File(_tempSuccessFilePath).listFiles().length);

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case OK BL001, BL200, retained date, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest14() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp2.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp2.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp2.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-COMPTEMAIL is moved to success folder
    Assert.assertEquals(1, new File(_tempSuccessFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case OK BL001, BL200, retained date, BL4300=CAT-1/NOK, BL1200=NOK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest15() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp2.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp2.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp2.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, "xxx", "xxx")); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-COMPTEMAIL is moved to success folder
    Assert.assertEquals(1, new File(_tempErrorFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case NOK BL001, No pattern on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest16() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp2.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(1).setPattern(null);

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config pattern sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case NOK BL001, BL200, retained date, BL3400</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest17() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp2.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();
    conf.setExtensionFichierTemporaire(".xxx"); //$NON-NLS-1$
    conf.setDureeRetentionTmp(-10000);

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL3400_SupprimerFichierBuilder mockBL3400Builder = PowerMock.createMockAndExpectNew(BL3400_SupprimerFichierBuilder.class);
    EasyMock.expect(mockBL3400Builder.fileName(_temp2.getName())).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.repertoire(_tempWorkFilePath)).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.build()).andReturn(_bl3400_SupprimerFichier);
    EasyMock.expect(_bl3400_SupprimerFichier.execute(_currentProcess)).andReturn(null);

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case NOK BL001, No chaine de connexion on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest18() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp2.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(1).setChaineConnexion(""); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config chaineConnexion sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case NOK BL001, No confFluxExtraction parameter</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest19() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp2.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(1).setIdFluxExtraction("anotherone"); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config confFluxExtraction sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case OK BL001, BL100, BL101 </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest20() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceCompteIms(RetourFactory.createOkRetour());

    //add an "constant" future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(ConcurrentUtils.constantFuture(null))); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case OK BL100, BL101, Timeout </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest21() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceCompteIms(RetourFactory.createOkRetour());

    Future<Retour> future = new CustomFuture(0);//timeout future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TIMEOUT, jsonRetour.getDiagnostic());
    Assert.assertEquals(Messages.getString("FordProcessSkeleton.TimeoutError"), jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case OK BL100, BL101, Traitement arreté </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest22() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceCompteIms(RetourFactory.createOkRetour());

    Future<Retour> future = new CustomFuture(1);//traitement arrete future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT10, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, jsonRetour.getDiagnostic());
  }

  /**
   * SPIRIT_RES_COMPTEIMS Test case OK BL100, BL101, async nok Retour from writer</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest23() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceCompteIms(RetourFactory.createOkRetour());

    CustomFuture future = new CustomFuture(2);//traitement arrete future

    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals("xxx", jsonRetour.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("xxx", jsonRetour.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("xxx", jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case OK BL001, BL200, date retained in file, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest24() throws Throwable
  {

    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp3.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp3.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);

    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-IMPIFIXE is moved to success folder
    Assert.assertEquals(1, new File(_tempSuccessFilePath).listFiles().length);

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case OK BL001, BL200, retained date, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest25() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp3.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp3.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp3.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-IMPIFIXE is moved to success folder
    Assert.assertEquals(1, new File(_tempSuccessFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case OK BL001, BL200, retained date, BL4300=CAT-1/NOK, BL1200=NOK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest26() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp3.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp3.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp3.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, "xxx", "xxx")); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-IMPIFIXE is moved to success folder
    Assert.assertEquals(1, new File(_tempErrorFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case NOK BL001, No pattern on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest27() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp3.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(2).setPattern(null);

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config pattern sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case NOK BL001, BL200, retained date, BL3400</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest28() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp3.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();
    conf.setExtensionFichierTemporaire(".xxx"); //$NON-NLS-1$
    conf.setDureeRetentionTmp(-10000);

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL3400_SupprimerFichierBuilder mockBL3400Builder = PowerMock.createMockAndExpectNew(BL3400_SupprimerFichierBuilder.class);
    EasyMock.expect(mockBL3400Builder.fileName(_temp3.getName())).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.repertoire(_tempWorkFilePath)).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.build()).andReturn(_bl3400_SupprimerFichier);
    EasyMock.expect(_bl3400_SupprimerFichier.execute(_currentProcess)).andReturn(null);

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case NOK BL001, No chaine de connexion on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest29() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp3.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(2).setChaineConnexion(""); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config chaineConnexion sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case NOK BL001, No confFluxExtraction parameter</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest30() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp3.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(2).setIdFluxExtraction("anotherone"); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config confFluxExtraction sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case OK BL001, BL100, BL101 </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest31() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceImpiFixe(RetourFactory.createOkRetour());

    //add an "constant" future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(ConcurrentUtils.constantFuture(null))); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case OK BL100, BL101, Timeout </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest32() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceImpiFixe(RetourFactory.createOkRetour());

    Future<Retour> future = new CustomFuture(0);//timeout future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TIMEOUT, jsonRetour.getDiagnostic());
    Assert.assertEquals(Messages.getString("FordProcessSkeleton.TimeoutError"), jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case OK BL100, BL101, Traitement arreté </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest33() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceImpiFixe(RetourFactory.createOkRetour());

    Future<Retour> future = new CustomFuture(1);//traitement arrete future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT10, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, jsonRetour.getDiagnostic());
  }

  /**
   * SPIRIT_RES_IMPIFIXE Test case OK BL100, BL101, async nok Retour from writer</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest34() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceImpiFixe(RetourFactory.createOkRetour());

    CustomFuture future = new CustomFuture(2);//traitement arrete future

    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_IMPIFIXE);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals("xxx", jsonRetour.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("xxx", jsonRetour.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("xxx", jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case OK BL001, BL200, date retained in file, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest35() throws Throwable
  {

    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp4.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp4.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);

    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-IMPIFIXE is moved to success folder
    Assert.assertEquals(1, new File(_tempSuccessFilePath).listFiles().length);

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case OK BL001, BL200, retained date, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest36() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp4.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp4.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp4.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-IMPIFIXE is moved to success folder
    Assert.assertEquals(1, new File(_tempSuccessFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case OK BL001, BL200, retained date, BL4300=CAT-1/NOK, BL1200=NOK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest37() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp4.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp4.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp4.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, "xxx", "xxx")); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-ADRIPCLF is moved to success folder
    Assert.assertEquals(1, new File(_tempErrorFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case NOK BL001, No pattern on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest38() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp4.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(3).setPattern(null);

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config pattern sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case NOK BL001, BL200, retained date, BL3400</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest39() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp4.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();
    conf.setExtensionFichierTemporaire(".xxx"); //$NON-NLS-1$
    conf.setDureeRetentionTmp(-10000);

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL3400_SupprimerFichierBuilder mockBL3400Builder = PowerMock.createMockAndExpectNew(BL3400_SupprimerFichierBuilder.class);
    EasyMock.expect(mockBL3400Builder.fileName(_temp4.getName())).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.repertoire(_tempWorkFilePath)).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.build()).andReturn(_bl3400_SupprimerFichier);
    EasyMock.expect(_bl3400_SupprimerFichier.execute(_currentProcess)).andReturn(null);

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case NOK BL001, No chaine de connexion on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest40() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp4.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(3).setChaineConnexion(""); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config chaineConnexion sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case NOK BL001, No confFluxExtraction parameter</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest41() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp4.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(3).setIdFluxExtraction("anotherone"); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config confFluxExtraction sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case OK BL001, BL100, BL101 </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest42() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceAdresseIpClf(RetourFactory.createOkRetour());

    //add an "constant" future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(ConcurrentUtils.constantFuture(null))); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case OK BL100, BL101, Timeout </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest43() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceAdresseIpClf(RetourFactory.createOkRetour());

    Future<Retour> future = new CustomFuture(0);//timeout future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TIMEOUT, jsonRetour.getDiagnostic());
    Assert.assertEquals(Messages.getString("FordProcessSkeleton.TimeoutError"), jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case OK BL100, BL101, Traitement arreté </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest44() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceAdresseIpClf(RetourFactory.createOkRetour());

    Future<Retour> future = new CustomFuture(1);//traitement arrete future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT10, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, jsonRetour.getDiagnostic());
  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case OK BL100, BL101, async nok Retour from writer</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest45() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceAdresseIpClf(RetourFactory.createOkRetour());

    CustomFuture future = new CustomFuture(2);//traitement arrete future

    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_ADRIPCLF);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals("xxx", jsonRetour.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("xxx", jsonRetour.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("xxx", jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * Test case NOK BL100 whilst creating a new CompteImsWriters </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-1/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest46() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp2.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    PowerMock.expectNew(CompteImsWriter.class, EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyInt()).andStubThrow(new IOException());
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_COMPTEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.CREATION_FICHIER_INVALIDE, jsonRetour.getDiagnostic());
  }

  /**
   * SPIRIT_RES_MOTDEPASSEIMS Test case OK BL001, BL200, date retained in file, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest47() throws Throwable
  {

    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp5.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp5.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);

    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-MOTDEPASSEIMS is moved to success folder
    Assert.assertEquals(1, new File(_tempSuccessFilePath).listFiles().length);

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_MOTDEPASSEIMS Test case OK BL001, BL200, retained date, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest48() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp5.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp5.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp5.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createOkRetour());

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-IMPIFIXE is moved to success folder
    Assert.assertEquals(1, new File(_tempSuccessFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_MOTDEPASSEIMS Test case OK BL001, BL200, retained date, BL4300=CAT-1/NOK, BL1200=NOK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest49() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp5.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, _temp5.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(_tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(_temp5.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);
    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, "xxx", "xxx")); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    // 3 files, with different namePatterns remain in working folder
    Assert.assertEquals(4, new File(_tempWorkFilePath).listFiles().length);

    // 1 file with namePattern SPIRIT-RES-ADRIPCLF is moved to success folder
    Assert.assertEquals(1, new File(_tempErrorFilePath).listFiles().length);
    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_MOTDEPASSEIMS Test case NOK BL001, No pattern on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest50() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp5.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(4).setPattern(null);

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config pattern sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_MOTDEPASSEIMS Test case NOK BL001, BL200, retained date, BL3400</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest51() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp5.lastModified()), ZoneId.systemDefault());
    GenericProcessConfig conf = createDefaultConfig();
    conf.setExtensionFichierTemporaire(".xxx"); //$NON-NLS-1$
    conf.setDureeRetentionTmp(-10000);

    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL3400_SupprimerFichierBuilder mockBL3400Builder = PowerMock.createMockAndExpectNew(BL3400_SupprimerFichierBuilder.class);
    EasyMock.expect(mockBL3400Builder.fileName(_temp5.getName())).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.repertoire(_tempWorkFilePath)).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL3400Builder);
    EasyMock.expect(mockBL3400Builder.build()).andReturn(_bl3400_SupprimerFichier);
    EasyMock.expect(_bl3400_SupprimerFichier.execute(_currentProcess)).andReturn(null);

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_MOTDEPASSEIMS Test case NOK BL001, No chaine de connexion on confFluxExtraction</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest52() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp5.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(4).setChaineConnexion(""); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config chaineConnexion sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_MOTDEPASSEIMS Test case NOK BL001, No confFluxExtraction parameter</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>CAT-4/NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest53() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    PowerMock.mockStaticStrict(MarshallTools.class);
    LocalDateTime.ofInstant(Instant.ofEpochMilli(_temp5.lastModified()), ZoneId.systemDefault());

    GenericProcessConfig conf = createDefaultConfig();
    EasyMock.expect(MarshallTools.unmarshall(EasyMock.eq(GenericProcessConfig.class), EasyMock.anyString())).andReturn(conf);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    conf.getConfigurationFluxExtraction().get(4).setIdFluxExtraction("anotherone"); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(1, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);
    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
    String error = "Les paramètres de config confFluxExtraction sont manquants"; //$NON-NLS-1$
    Assert.assertEquals(error, jsonRetour.getLibelle());

  }

  /**
   * SPIRIT_RES_ADRIPCLF Test case OK BL001, BL100, BL101 </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest54() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceMotDePasseIms(RetourFactory.createOkRetour());

    //add an "constant" future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(ConcurrentUtils.constantFuture(null))); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * SPIRIT_RES_MOTDEPASSEIMS Test case OK BL100, BL101, Timeout </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest55() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceMotDePasseIms(RetourFactory.createOkRetour());

    Future<Retour> future = new CustomFuture(0);//timeout future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TIMEOUT, jsonRetour.getDiagnostic());
    Assert.assertEquals(Messages.getString("FordProcessSkeleton.TimeoutError"), jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * SPIRIT_RES_MOTDEPASSEIMS Test case OK BL100, BL101, Traitement arreté </br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest56() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceMotDePasseIms(RetourFactory.createOkRetour());

    Future<Retour> future = new CustomFuture(1);//traitement arrete future
    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT10, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, jsonRetour.getDiagnostic());
  }

  /**
   * SPIRIT_RES_MOTDEPASSEIMS Test case OK BL100, BL101, async nok Retour from writer</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0257_ExtrationRessourcesTest57() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters();

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();
    mockResGetAllRessourceMotDePasseIms(RetourFactory.createOkRetour());

    CustomFuture future = new CustomFuture(2);//traitement arrete future

    JUnitTools.setInaccessibleFieldValue(_processContext, "_threadPoolExecutorResult", Arrays.asList(future)); //$NON-NLS-1$
    PowerMock.replayAll();

    Request request = createRequest(2, SPIRIT_RES_MOTDEPASSEIMS);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();
    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals("xxx", jsonRetour.getCategorie()); //$NON-NLS-1$
    Assert.assertEquals("xxx", jsonRetour.getDiagnostic()); //$NON-NLS-1$
    Assert.assertEquals("xxx", jsonRetour.getLibelle()); //$NON-NLS-1$
  }

  /**
   * Method for returning Retour from Request
   *
   * @param request
   *          Request
   * @return Retour
   */
  private com.bytel.ravel.types.Retour getRetourFromRequest(Request request)
  {
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    return GsonTools.getIso8601Ms().fromJson(resp, com.bytel.ravel.types.Retour.class);
  }

  /**
   * Load parameters for loadConfiguration values
   *
   * @return return Parameters
   */
  private ConcurrentHashMap<String, Map<String, String>> loadParameters()
  {
    Map<String, String> myMap = new ConcurrentHashMap<String, String>();

    myMap.put("FILE_PATH", _confFilePath); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> finalParameters = new ConcurrentHashMap<String, Map<String, String>>();
    finalParameters.put("", myMap); //$NON-NLS-1$

    return finalParameters;
  }

  /**
   * @param retour_p
   * @throws RavelException
   */
  private void mockResGetAllRessourceAdresseIpClf(Retour retour_p) throws RavelException
  {
    PowerMock.mockStatic(RESDatabaseProxy.class);
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resDatabaseProxy);
    EasyMock.expect(_resDatabaseProxy.getAllRessourceAdresseIpClf(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<Retour, Nothing>(retour_p, null));
  }

  /**
   * @param retour_p
   * @throws RavelException
   */
  private void mockResGetAllRessourceCompteIms(Retour retour_p) throws RavelException
  {
    PowerMock.mockStatic(RESDatabaseProxy.class);
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resDatabaseProxy);
    EasyMock.expect(_resDatabaseProxy.getAllRessourceCompteIms(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<Retour, Nothing>(retour_p, null));
  }

  /**
   * @param retour_p
   * @throws RavelException
   */
  private void mockResGetAllRessourceCompteMail(Retour retour_p) throws RavelException
  {
    PowerMock.mockStatic(RESDatabaseProxy.class);
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resDatabaseProxy);
    EasyMock.expect(_resDatabaseProxy.getAllRessourceCompteMail(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<Retour, Nothing>(retour_p, null));
  }

  /**
   * @param retour_p
   * @throws RavelException
   */
  private void mockResGetAllRessourceImpiFixe(Retour retour_p) throws RavelException
  {
    PowerMock.mockStatic(RESDatabaseProxy.class);
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resDatabaseProxy);
    EasyMock.expect(_resDatabaseProxy.getAllRessourceImpiFixe(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<Retour, Nothing>(retour_p, null));
  }

  /**
   * @param retour_p
   * @throws RavelException
   */
  private void mockResGetAllRessourceMotDePasseIms(Retour retour_p) throws RavelException
  {
    PowerMock.mockStatic(RESDatabaseProxy.class);
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resDatabaseProxy);
    EasyMock.expect(_resDatabaseProxy.getAllRessourceMotDePasseIms(EasyMock.anyObject(), EasyMock.anyObject())).andReturn(new ConnectorResponse<Retour, Nothing>(retour_p, null));
  }

}