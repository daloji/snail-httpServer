/*******************************************************************************
* $Id: StPfsVmsStwWriterTest.java 15957 2019-01-17 14:57:50Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Test;

import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.ford.processes.TestUtils;

/**
 *
 * @author pcarreir
 * @version ($Revision: 15957 $ $Date: 2019-01-17 15:57:50 +0100 (jeu. 17 janv. 2019) $)
 */
public class StPfsVmsStwWriterTest
{
  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-ST-PFS-VMS_STW.csv"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * the writer
   */
  StPfsVmsStwWriter _writer;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Scenario: Create one line<br>
   * Input: The StPfsVmsStw to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StPfsVmsStwWriter_Nominal_01() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0255/ServiceTechnique_PfsVmsStw.json", SpiritConstants.JSON_PROFILE_SAAB); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idSt", "ACTIF", "", "", "610000012345", "idPa", "+33123123123", "VOIX", "FAX", "adresseMail", "nomPrenomUtilisateur", "20180510174337", "20181014174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new StPfsVmsStwWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(StPfsVmsStwWriter.StPfsVmsStwHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: Test OK with some null fields: typeMessagerie, adresseMail<br>
   * Input: The StPfsVmsStw to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StPfsVmsStwWriter_Nominal_02() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0255/ServiceTechnique_PfsVmsStw_EmptyFields.json", SpiritConstants.JSON_PROFILE_SAAB); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idSt", "ACTIF", "", "", "610000012345", "idPa", "+33123123123", "", "ligneMarche", "", "nomPrenomUtilisateur", "20180510174337", "20181014174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new StPfsVmsStwWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(StPfsVmsStwWriter.StPfsVmsStwHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: Test OK with some null fields: donneesProvisionnes<br>
   * Input: The StPfsVmsStw to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StPfsVmsStwWriter_Nominal_03() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0255/ServiceTechnique_PfsVmsStw_DonneesProvisionnesNull.json", SpiritConstants.JSON_PROFILE_SAAB); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idSt", "ACTIF", "", "", "610000012345", "idPa", "", "", "", "", "", "20180510174337", "20181014174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new StPfsVmsStwWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(StPfsVmsStwWriter.StPfsVmsStwHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }
}
