/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import com.bytel.spirit.ford.processes.TestUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0098.generator.LienEqtPaCarteThdWriter.LienEqtPACarteTHDHeader;
import com.bytel.spirit.ford.processes.PP0098.generator.LienEqtPaOntWriter.LienEqtPAONHeader;

/**
 *
 * @author jsantos
 * @version ($Revision$ $Date$)
 */
public class LienEqtPaCarteThdWriterTest
{
  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-LIENEQTPACARTETHD.csv"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * The Writer to test
   */
  private LienEqtPaCarteThdWriter _currentInstance;

  /**
   * Deletes the CSV file after each test.
   *
   * @throws Exception
   *           Should not happen
   */
  @After
  public void afterTest() throws Exception
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _currentInstance = new LienEqtPaCarteThdWriter(FILENAME, 1);
  }

  /**
   * Scenario: test OK with Valid Equipement CARTE_THD <br>
   * Input: Valid PFI <br>
   * Result: Write a complete line <br>
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void testNominal() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienEqtPACarteTHD_Nominal.json"); //$NON-NLS-1$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _currentInstance.dumpPFI(tracabilite, pfi, LocalDate.of(2017,12,10));
    _currentInstance.close();

    List<String> expectedLine = Arrays.asList("BSS_GP", "610000012345", "valIdEqt1", "valIdPA1", "ACTIF", "id111", "CARTE_THD", "MODELE", "codeEAN", "FABRICANT", "THD", "12345", "20170518174337", "20171210164337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(LienEqtPACarteTHDHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(expectedLine.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: test OK with Valid Equipement CARTE_THD but with some fields empty <br>
   * Input: Valid PFI with some empty fields <br>
   * Result: Write a complete line <br>
   *
   * @throws Exception
   *           should not happen
   */
  @Test
  public void testWithEmptyFields() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienEqtPACarteTHD_WithEmptyFields.json"); //$NON-NLS-1$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _currentInstance.dumpPFI(tracabilite, pfi, LocalDate.of(2017,12,10));
    _currentInstance.close();

    List<String> expectedLine = Arrays.asList("BSS_GP", "610000012345", "valIdEqt1", "valIdPA1", "ACTIF", "id111", "CARTE_THD", "MODELE", "codeEAN", "FABRICANT", "", "", "20170518174337", "20171210164337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$
    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(LienEqtPAONHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(expectedLine.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: test OK with Invalid Equipement IAD <br>
   * Input: Valid PFIof type IAD <br>
   * Result: No Lines writed <br>
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void testWithInvalidPFI() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienEqtPACarteTHD_InvalidPFI.json"); //$NON-NLS-1$
    _currentInstance.dumpPFI(new Tracabilite(), pfi, LocalDate.of(2018,5,1));
    _currentInstance.close();
  }

}
