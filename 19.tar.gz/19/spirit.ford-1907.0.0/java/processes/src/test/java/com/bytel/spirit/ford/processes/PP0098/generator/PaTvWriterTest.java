/*******************************************************************************
* $Id: PaTvWriterTest.java 14226 2018-12-06 15:29:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.bytel.spirit.ford.processes.TestUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeTv;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0098.generator.PaTvWriter.PATVHeader;

/**
 *
 * @author asoares
 * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
 */
public class PaTvWriterTest
{
  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-PATV.csv"; //$NON-NLS-1$

  /**
   * The TV constant.
   */
  private static final String TV = "TV"; //$NON-NLS-1$

  /**
   * Date of PA creation.
   */
  private LocalDateTime _dateCreation;

  /**
   * Date of PA modification.
   */
  private LocalDateTime _dateMofification;

  /**
   * The PaTvWriter to be tested.
   */
  private PaTvWriter _paTvWriter;

  /**
   * The tracabilite.
   */
  private Tracabilite _tracabilite;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Tests initialization.
   *
   * @throws Exception
   *           on error
   */
  @Before
  public void beforeTest() throws Exception
  {
    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _paTvWriter = new PaTvWriter(FILENAME, 2);

    _dateCreation = LocalDateTime.now();
    _dateMofification = LocalDateTime.now().plusDays(1);
  }

  /**
   * Nominal test case with two PA.<br/>
   *
   * <b>Input:</b>Valid PFI with two valid PA and with PA.getType = "TV"<br/>
   * <b>Expected:</b>Header + 2 lines created<br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void paTVWriterTest_01() throws Exception
  {
    PFI pfi = createPFI(TV, TV);

    _paTvWriter.dumpPFI(_tracabilite, pfi, _dateMofification.toLocalDate());
    _paTvWriter.close();

    List<String> expectedLine1 = Arrays.asList("BSS_GP", "610000012345", "idPA1", "idPALie1", "ACTIF", "idCompteTv1", "idContenuTv1", (DateTimeFormatPattern.yyyyMMddHHmmss).format(_dateCreation), (DateTimeFormatPattern.yyyyMMddHHmmss).format(_dateMofification)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    List<String> expectedLine2 = Arrays.asList("BSS_GP", "610000012345", "idPA2", "idPALie2", "RESILIE", "idCompteTv2", "idContenuTv2", (DateTimeFormatPattern.yyyyMMddHHmmss).format(_dateCreation), (DateTimeFormatPattern.yyyyMMddHHmmss).format(_dateMofification)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PATVHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(3, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(expectedLine1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
    assertEquals(expectedLine2.toString(), Arrays.asList(lines.get(2).split(SEMICOLON)).toString());
  }

  /**
   * Test case with two invalid PA.<br/>
   *
   * <b>Input:</b>PFI with two invalid PA. PA.getType != "TV"<br/>
   * <b>Expected:</b>Header line<br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void paTVWriterTest_02() throws Exception
  {
    PFI pfi = createPFI(StringUtils.EMPTY, StringUtils.EMPTY);

    _paTvWriter.dumpPFI(_tracabilite, pfi, _dateMofification.toLocalDate());
    _paTvWriter.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PATVHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(1, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
  }

  /**
   * Test case with one valid PA and one invalid PA.<br/>
   *
   * <b>Input:</b>PFI with two PA. Valid PA with PA.getType = "TV". Invalid PA with PA.getType != "TV"<br/>
   * <b>Expected:</b>Header + 1 line created<br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void paTVWriterTest_03() throws Exception
  {
    PFI pfi = createPFI(TV, StringUtils.EMPTY);

    _paTvWriter.dumpPFI(_tracabilite, pfi, _dateMofification.toLocalDate());
    _paTvWriter.close();

    List<String> expectedLine1 = Arrays.asList("BSS_GP", "610000012345", "idPA1", "idPALie1", "ACTIF", "idCompteTv1", "idContenuTv1", (DateTimeFormatPattern.yyyyMMddHHmmss).format(_dateCreation), (DateTimeFormatPattern.yyyyMMddHHmmss).format(_dateMofification)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PATVHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(expectedLine1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Test case with null objects.<br/>
   *
   * <b>Input:</b>PA1 valid, PA2.getPaTypeTv = null, PA3 = null<br/>
   * <b>Expected:</b>Header + 2 lines created<br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void paTVWriterTest_04() throws Exception
  {
    PFI pfi = createPFI(TV, TV);

    pfi.getPa().get(1).setPaTypeTv(null);
    pfi.getPa().add(null);

    _paTvWriter.dumpPFI(_tracabilite, pfi, _dateMofification.toLocalDate());
    _paTvWriter.close();

    List<String> expectedLine1 = Arrays.asList("BSS_GP", "610000012345", "idPA1", "idPALie1", "ACTIF", "idCompteTv1", "idContenuTv1", (DateTimeFormatPattern.yyyyMMddHHmmss).format(_dateCreation), (DateTimeFormatPattern.yyyyMMddHHmmss).format(_dateMofification)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    List<String> expectedLine2 = Arrays.asList("BSS_GP", "610000012345", "idPA2", "idPALie2", "RESILIE", StringUtils.EMPTY, StringUtils.EMPTY, (DateTimeFormatPattern.yyyyMMddHHmmss).format(_dateCreation), (DateTimeFormatPattern.yyyyMMddHHmmss).format(_dateMofification)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-8

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PATVHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(3, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(expectedLine1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
    assertEquals(expectedLine2.toString(), Arrays.asList(lines.get(2).split(SEMICOLON)).toString());
  }

  /**
   * Creates the PFI.
   *
   * @param pa1Type_p
   *          the type of PA1
   * @param pa2ype_p
   *          the type of PA2
   *
   * @return PFI
   */
  private PFI createPFI(String pa1Type_p, String pa2ype_p)
  {
    PA pa1 = new PA("idPA1", pa1Type_p, Statut.ACTIF, _dateCreation, _dateMofification); //$NON-NLS-1$
    pa1.setIdentifiantFonctionnelPALie("idPALie1"); //$NON-NLS-1$
    pa1.setPaTypeTv(new PaTypeTv("idCompteTv1", "idContenuTv1")); //$NON-NLS-1$ //$NON-NLS-2$

    PA pa2 = new PA("idPA2", pa2ype_p, Statut.RESILIE, _dateCreation, _dateMofification); //$NON-NLS-1$
    pa2.setIdentifiantFonctionnelPALie("idPALie2"); //$NON-NLS-1$
    pa2.setPaTypeTv(new PaTypeTv("idCompteTv2", "idContenuTv2")); //$NON-NLS-1$ //$NON-NLS-2$

    List<PA> paList = new ArrayList<>();
    paList.add(pa1);
    paList.add(pa2);

    PFI pfi = new PFI();
    pfi.setClientOperateur("BSS_GP"); //$NON-NLS-1$
    pfi.setNoCompte("610000012345"); //$NON-NLS-1$
    pfi.setPa(paList);

    return pfi;
  }
}
