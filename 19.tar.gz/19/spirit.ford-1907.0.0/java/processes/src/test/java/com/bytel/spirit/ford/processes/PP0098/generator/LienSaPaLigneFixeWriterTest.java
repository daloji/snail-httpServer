/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import com.bytel.spirit.ford.processes.TestUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0098.generator.LienSaPaLigneFixeWriter.Header;

/**
 *
 * @author asoares
 * @version ($Revision$ $Date$)
 */
public class LienSaPaLigneFixeWriterTest
{
  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-LIENSAPALF.csv"; //$NON-NLS-1$

  /**
   * The PaVoipWriter to be tested.
   */
  private LienSaPaLigneFixeWriter _lienSaPaLigneFixeWriter;

  /**
   * The tracabilite.
   */
  private Tracabilite _tracabilite;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Tests initialization.
   *
   * @throws Exception
   *           on error
   */
  @Before
  public void beforeTest() throws Exception
  {
    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _lienSaPaLigneFixeWriter = new LienSaPaLigneFixeWriter(FILENAME, 2);
  }

  /**
   * Nominal test case.<br/>
   *
   * <b>Input:</b>Valid PFI<br/>
   * <b>Expected:</b>Header + 1 line created<br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void lienSAPALFWriterTest_01() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/pfi.json"); //$NON-NLS-1$
    _lienSaPaLigneFixeWriter.dumpPFI(_tracabilite, pfi, LocalDate.of(2018,5,1));
    _lienSaPaLigneFixeWriter.close();

    List<String> expectedLine1 = Arrays.asList("BSS_GP", "612104018213", "LRSETIAR", "PALF01", "RESILIE", "6201631", "LR_SETIAR", "LIGNE_FIXE", "", "80012506", "", "3357159", "XDSL", "31", "24", "75105", "20180501131559", "20180501131606"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$ //$NON-NLS-18$
    List<String> expectedLine2 = Arrays.asList("BSS_GP", "612104018213", "PROSPECT01", "PALF01", "RESILIE", "6300006", "PROSPECT", "LIGNE_FIXE", "", "80012506", "", "3357159", "XDSL", "31", "24", "75105", "20180501131559", "20180501131606"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$ //$NON-NLS-18$
    List<String> expectedLine3 = Arrays.asList("BSS_GP", "612104018213", "LRSETIAR", "PALF02", "ACTIF", "6201631", "LR_SETIAR", "LIGNE_FIXE", "", "80015508", "", "3357159", "XDSL", "31", "24", "75105", "20180501131606", "20180501131606"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$ //$NON-NLS-18$
    List<String> expectedLine4 = Arrays.asList("BSS_GP", "612104018213", "PROSPECT01", "PALF02", "ACTIF", "6300006", "PROSPECT", "LIGNE_FIXE", "", "80015508", "", "3357159", "XDSL", "31", "24", "75105", "20180501131606", "20180501131606"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$ //$NON-NLS-18$

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(Header.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(5, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(expectedLine1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
    assertEquals(expectedLine2.toString(), Arrays.asList(lines.get(2).split(SEMICOLON)).toString());
    assertEquals(expectedLine3.toString(), Arrays.asList(lines.get(3).split(SEMICOLON)).toString());
    assertEquals(expectedLine4.toString(), Arrays.asList(lines.get(4).split(SEMICOLON)).toString());
  }

}