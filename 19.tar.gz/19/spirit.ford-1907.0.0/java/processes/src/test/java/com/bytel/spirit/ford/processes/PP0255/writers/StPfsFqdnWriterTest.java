/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Test;

import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.ford.processes.TestUtils;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class StPfsFqdnWriterTest
{
  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-ST-PFS-FQDN.csv"; //$NON-NLS-1$

  /**
   * The writer.
   */
  StPfsFqdnWriter _writer;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Scenario: Create one line.<br/>
   * Input: The StPsFqdn to be set.<br/>
   * Result: 1 line is created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StPfsFqdnWriter_Nominal_01() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0255/ServiceTechnique_PfsFqdn.json", SpiritConstants.JSON_PROFILE_SAAB); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idSt", "ACTIF", "", "clientOperateur", "610000012345", "nomFqdn", "1", "20180510174337", "20181014174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new StPfsFqdnWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(StPfsFqdnWriter.StPfsFqdnHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(StringConstants.SEMICOLON_SEPARATOR)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(StringConstants.SEMICOLON_SEPARATOR)).toString());
  }

  /**
   * Scenario: Test OK with some null fields: nomFQDN<br>
   * Input: The StPsFqdn to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StPfsFqdnWriter_Nominal_02() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0255/ServiceTechnique_PfsFqdn_EmptyFields.json", SpiritConstants.JSON_PROFILE_SAAB); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idSt", "ACTIF", "", "clientOperateur", "610000012345", "", "1", "20180510174337", "20181014174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new StPfsFqdnWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(StPfsFqdnWriter.StPfsFqdnHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(StringConstants.SEMICOLON_SEPARATOR)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(StringConstants.SEMICOLON_SEPARATOR)).toString());
  }

  /**
   * Scenario: Test OK with some null fields: donneesProvisionnes<br>
   * Input: The StPsFqdn to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StPfsFqdnWriter_Nominal_03() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0255/ServiceTechnique_PfsFqdn_DonneesProvisionnesNull.json", SpiritConstants.JSON_PROFILE_SAAB); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idSt", "ACTIF", "", "clientOperateur", "610000012345", "nomFqdn", "", "20180510174337", "20181014174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new StPfsFqdnWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(StPfsFqdnWriter.StPfsFqdnHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(StringConstants.SEMICOLON_SEPARATOR)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(StringConstants.SEMICOLON_SEPARATOR)).toString());
  }
}
