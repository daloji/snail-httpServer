/*******************************************************************************
* $Id: LienSaPaTvWriterTest.java 14226 2018-12-06 15:29:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import com.bytel.spirit.ford.processes.TestUtils;
import org.easymock.EasyMockSupport;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0098.generator.LienSaPaTvWriter.LienSaPaTVHeader;

/**
 *
 * @author pcarreir
 * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest()
public class LienSaPaTvWriterTest extends EasyMockSupport
{

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-LIENSAPATV.csv"; //$NON-NLS-1$

  /**
   * The csv field separator
   */
  private static final String SEPARATOR = "" + LienSaPaTvWriter.CSV_SEPARATOR; //$NON-NLS-1$

  /**
   * The Writer to test
   */
  private LienSaPaTvWriter _currentInstance;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _currentInstance = new LienSaPaTvWriter(FILENAME, 1);
  }

  /**
   * Scenario: test OK with Invalid PA TV <br>
   * Input: Valid PFI of type VOIP <br>
   * Result: No Lines created <br>
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void LienSaPaTVWriterTest_KO_00() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienSaPaTVWriter_Nominal.json"); //$NON-NLS-1$
    pfi.getPa().get(0).setTypePA("VOIP"); //$NON-NLS-1$
    pfi.getPa().get(1).setTypePA("VOIP"); //$NON-NLS-1$
    pfi.getPa().get(2).setTypePA("VOIP"); //$NON-NLS-1$
    _currentInstance.dumpPFI(new Tracabilite(), pfi, LocalDate.of(2017,12,10));
    _currentInstance.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(LienSaPaTVHeader.class.getEnumConstants()).map(Enum::toString).toArray(String[]::new);

    assertEquals(1, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEPARATOR)).toString());
  }

  /**
   * Scenario: test OK with Valid PA TV <br>
   * Input: Valid PFI <br>
   * Result: Write two complete lines <br>
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void LienSaPaTVWriterTest_OK_00() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienSaPaTVWriter_Nominal.json"); //$NON-NLS-1$

    _currentInstance.dumpPFI(new Tracabilite(), pfi, LocalDate.of(2017,12,10));

    String[] line1 = { "BSS_GP", "610000012345", "valIdSA1", "valIdPA1", "ACTIF", "valIdSC1", "nomSC1", "TV", "compteTV1", "valIdPA2", "technologieAcces1", "idOperateurCollecte1", "codeInsee1", "20170518184337", "20171210174337" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$
    String[] line2 = { "BSS_GP", "610000012345", "valIdSA3", "valIdPA3", "ACTIF", "valIdSC3", "nomSC3", "TV", "compteTV2", "", "", "", "", "20170518184337", "20171210174339" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$
    _currentInstance.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(LienSaPaTVHeader.class.getEnumConstants()).map(Enum::toString).toArray(String[]::new);

    assertEquals(3, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEPARATOR)).toString());
    assertEquals(Arrays.asList(line1).toString(), Arrays.asList(lines.get(1).split(SEPARATOR)).toString());
    assertEquals(Arrays.asList(line2).toString(), Arrays.asList(lines.get(2).split(SEPARATOR)).toString());
  }
}
