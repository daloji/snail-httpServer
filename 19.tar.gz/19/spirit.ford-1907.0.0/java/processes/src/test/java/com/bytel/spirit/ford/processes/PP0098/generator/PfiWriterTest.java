/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import com.bytel.spirit.ford.processes.TestUtils;
import org.junit.After;
import org.junit.Test;

import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0098.generator.PfiWriter.PFIHeader;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PfiWriterTest
{

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-PFI.csv"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * Writer
   */
  PfiWriter _writer;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Scenario: Create one line<br>
   * Input: The PFI to be set<br>
   * Result: 1 line are created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void PFIWriter_Nominal_01() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/PFI_nominal.json"); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "ACTIF", "GP", "INDIVIDU", "1234", "Jhon", "Travolta", "123", "M", "20170518174337", "20171020174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new PfiWriter(FILENAME, 1);
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 10, 20));
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PFIHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: Create one line<br>
   * Input: The PFI to be set<br>
   * Result: 1 line is created with null values
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void PFIWriter_Nominal_02() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/PFI_nominal.json"); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "ACTIF", "GP", "INDIVIDU", "1234", "Jhon", "Travolta", "123", "M", "20170518174337", "20171020174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new PfiWriter(FILENAME, 1);
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 10, 20));
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PFIHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: Dump 15 PFI with a flush of 5 lines. Input: The PFI to dump Result: 15 PFI are dumped
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void PFIWriter_Nominal_03() throws Exception
  {
    int timesToDump = 15;

    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/PFI_nominal.json"); //$NON-NLS-1$

    _writer = new PfiWriter(FILENAME, 5);

    int count = 0;
    List<String> lines = null;
    do
    {
      Tracabilite tracabilite = new Tracabilite();
      tracabilite.setIdCorrelationSpirit(this.getClass().getName());
      _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 10, 20));

      lines = TestUtils.readFromCSV(FILENAME);
      if (count < 3)
      {
        assertEquals(0, lines.size());
      }
    }
    while (++count < timesToDump);
    _writer.close();
    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "ACTIF", "GP", "INDIVIDU", "1234", "Jhon", "Travolta", "123", "M", "20170518174337", "20171020174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$
    String[] header = Arrays.stream(PFIHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);
    lines = TestUtils.readFromCSV(FILENAME);
    assertEquals(16, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: Dump 0 PFI with a flush of 5 lines. Input: The PFI to dump Result: 10 PFI are dumped
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void PFIWriter_Nominal_04() throws Exception
  {
    int timesToDump = 15;

    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/PFI_nominal.json"); //$NON-NLS-1$

    _writer = new PfiWriter(FILENAME, 5);

    int count = 0;
    List<String> lines = null;
    do
    {
      Tracabilite tracabilite = new Tracabilite();
      tracabilite.setIdCorrelationSpirit(this.getClass().getName());
      _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 11, 20));

      lines = TestUtils.readFromCSV(FILENAME);
      if (count < 3)
      {
        assertEquals(0, lines.size());
      }
    }
    while (++count < timesToDump);
    _writer.close();
    String[] header = Arrays.stream(PFIHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);
    lines = TestUtils.readFromCSV(FILENAME);
    assertEquals(1, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
  }
}
