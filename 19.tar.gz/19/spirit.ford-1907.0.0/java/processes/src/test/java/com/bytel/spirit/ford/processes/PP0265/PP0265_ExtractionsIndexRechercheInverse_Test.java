/*******************************************************************************
* $Id: PP0265_ExtractionsIndexRechercheInverse_Test.java 23458 2019-07-02 10:48:53Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0265;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.configuration.ConfigFileManager;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IUrlParameters;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder;
import com.bytel.spirit.common.ford.config.ConfigurationFluxExtraction;
import com.bytel.spirit.common.ford.config.GenericProcessConfig;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.ford.shared.misc.processes.FordProcessSkeleton;
import com.bytel.spirit.saab.connectors.air.AIRDatabaseProxy;

/**
 *
 * @author pcarreir
 * @version ($Revision: 23458 $ $Date: 2019-07-02 12:48:53 +0200 (mar. 02 juil. 2019) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ ProcessManager.class, AIRDatabaseProxy.class, BL4300_EnvoyerFichier.class, PP0265_ExtractionsIndexRechercheInverse.class })
public class PP0265_ExtractionsIndexRechercheInverse_Test extends EasyMockSupport
{
  /**
   * ConfigFileManager singleton
   */
  private static ConfigFileManager _configFileManager;

  /**
   * The SPIRIT-AIR-PFI flux id
   */
  private static final String SPIRIT_AIR_PFI = "SPIRIT-AIR-PFI"; //$NON-NLS-1$

  /**
  *
  */
  private static final String CHAINE_CONNECTION_DEFAULT = "sftp://spirittest@gas-y.pin.dolmen.bouyguestelecom.fr:2222/in/spiritqod/in/?sftpkeyfile=/var/run/secrets/TEST_GAS_KEY&auth=publickey"; //$NON-NLS-1$

  /**
   * The temprary folder
   */
  private static TemporaryFolder _tf;

  /**
   * The .csv file
   */
  private static File temp = null;

  /**
   * The working file path
   */
  private static String tempWorkFilePath;

  /**
   * The success file path
   */
  private static String tempSuccessFilePath;

  /**
   * The error file path
   */
  private static String tempErrorFilePath;

  /**
   * The configuration file path
   */
  private static String _confFilePath;

  /**
   * The EMPTY_DIR constant.
   */
  private static final String EMPTY_DIR = "emptyDir"; //$NON-NLS-1$

  /**
   * Mode execution parameter name
   */
  private static final String MODE_EXECUTION_PARAM = "modeExecution"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ID_FLUX_EXTRACTION = "idFluxExtraction"; //$NON-NLS-1$

  /**
   * The ProduireExtractions constant.
   */
  private static final String PRODUIRE_EXTRACTIONS = "ProduireExtractions"; //$NON-NLS-1$

  /**
   * The TransfererFichiers constant.
   */
  private static final String TRANSFERER_FICHIERS = "TransfererFichiers"; //$NON-NLS-1$

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    _configFileManager = new ConfigFileManager("."); //$NON-NLS-1$
    //    _podam = new PodamFactoryImpl();
  }

  /**
   * @return {@link GenericProcessConfig}
   */
  private static GenericProcessConfig createDefaultConfig()
  {
    GenericProcessConfig genericProcessConfig = new GenericProcessConfig();
    genericProcessConfig.setActivateMultiThread(true);
    genericProcessConfig.setCheminRepArchiveErreur(tempErrorFilePath);
    genericProcessConfig.setCheminRepArchiveSucces(tempSuccessFilePath);
    genericProcessConfig.setCheminRepTravail(tempWorkFilePath);
    genericProcessConfig.setDureeRetentionTmp(1000);
    genericProcessConfig.setEndingTimeout(1000);
    genericProcessConfig.setExtensionFichierTemporaire(".tmp"); //$NON-NLS-1$
    genericProcessConfig.setLinesToFlush(10);
    genericProcessConfig.setPoolSize(2);
    genericProcessConfig.setPushTimeout(1000);
    genericProcessConfig.setWaitingFileSize(2);
    ConfigurationFluxExtraction confConfExtraction = new ConfigurationFluxExtraction();
    confConfExtraction.setIdFluxExtraction(SPIRIT_AIR_PFI);
    confConfExtraction.setChaineConnexion(CHAINE_CONNECTION_DEFAULT);
    confConfExtraction.setPattern(SPIRIT_AIR_PFI + ".*"); //$NON-NLS-1$
    genericProcessConfig.getConfigurationFluxExtraction().add(confConfExtraction);
    genericProcessConfig.setIdFluxExtractionAutorises(SPIRIT_AIR_PFI);

    return genericProcessConfig;
  }

  /**
   * Create Request for tests
   *
   * @param option
   *          test option
   * @return return Request
   * @throws RavelException
   *           ravel Exception
   */
  private static Request createRequest(Integer option) throws RavelException
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(IHttpHeadersConsts.X_REQUEST_ID);
    requestHeader.setValue("PP0265"); //$NON-NLS-1$

    Request request = new Request(PP0265_ExtractionsIndexRechercheInverse.class.getSimpleName(), StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().add(requestHeader);

    List<Parameter> parameters = new ArrayList<>();
    Parameter parameter = null;
    IUrlParameters urlParameters = null;

    switch (option)
    {
      case 1:
        parameter = new Parameter(MODE_EXECUTION_PARAM, PRODUIRE_EXTRACTIONS);
        parameters.add(parameter);
        parameter = new Parameter(ID_FLUX_EXTRACTION, SPIRIT_AIR_PFI);
        parameters.add(parameter);
        urlParameters = new UrlParameters(parameters);
        request.setUrlParameters(urlParameters);
        break;
      case 2:
        parameter = new Parameter(MODE_EXECUTION_PARAM, TRANSFERER_FICHIERS);
        parameters.add(parameter);
        parameter = new Parameter(ID_FLUX_EXTRACTION, SPIRIT_AIR_PFI);
        parameters.add(parameter);
        urlParameters = new UrlParameters(parameters);
        request.setUrlParameters(urlParameters);
        break;
      case 4:
        urlParameters = new UrlParameters(parameters);
        request.setUrlParameters(urlParameters);
        break;
      case 5:
        request.getRequestHeader().remove(0);
        break;
      default:
        break;
    }

    return request;
  }

  /**
   * Create Dir for Tests
   *
   * @throws JAXBException
   *           on error
   * @throws IOException
   *           on error
   *
   */
  private static void createTempDirsAndFiles() throws JAXBException, IOException
  {
    temp = null;

    _tf.create();
    File workFolder = _tf.newFolder("work"); //$NON-NLS-1$
    File successFolder = _tf.newFolder("success"); //$NON-NLS-1$
    File errorFolder = _tf.newFolder("error"); //$NON-NLS-1$

    temp = File.createTempFile(SPIRIT_AIR_PFI, ".tmp", workFolder); //$NON-NLS-1$
    temp.setLastModified(DateTimeTools.toEpochMilli(DateTimeManager.getInstance().now().minusSeconds(2000)));
    temp = File.createTempFile(SPIRIT_AIR_PFI, ".csv", workFolder); //$NON-NLS-1$

    //Get tempropary file path
    tempWorkFilePath = workFolder.getAbsolutePath() + File.separator;
    tempSuccessFilePath = successFolder.getAbsolutePath() + File.separator;
    tempErrorFilePath = errorFolder.getAbsolutePath() + File.separator;

    GenericProcessConfig genericProcessConfig = createDefaultConfig();

    JAXBContext jaxbContext = JAXBContext.newInstance(GenericProcessConfig.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
    File confFile = _tf.newFile("conf.xml"); //$NON-NLS-1$
    _confFilePath = confFile.getAbsolutePath();
    FileOutputStream fos = new FileOutputStream(confFile);
    marshaller.marshal(genericProcessConfig, fos);
    fos.close();
  }

  /**
   * extraction ressources
   */
  private PP0265_ExtractionsIndexRechercheInverse _currentProcess;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  private ProcessManager _processManager;

  /**
   * Mock de {@link AIRDatabaseProxy}
   */
  @MockStrict
  private AIRDatabaseProxy _airDbProxy;

  /**
   * Mock de {@link BL4300_EnvoyerFichier}
   */
  @MockStrict
  private BL4300_EnvoyerFichier _bl4300_EnvoyerFichier;

  /**
   * Cleans the Connector Mocks responses
   *
   * @throws Exception
   *           On Error
   */
  @Before
  public void beforeTest() throws Exception
  {
    _tf = new TemporaryFolder();
    createTempDirsAndFiles();
    _currentProcess = new PP0265_ExtractionsIndexRechercheInverse();
    _currentProcess.initializeContext();

    //    _processContext = PP0257_ExtrationRessourcesContext.class.cast(JUnitTools.getInaccessibleFieldValue(_currentProcess, "_processContext")); //$NON-NLS-1$

    // désactivation du cache podam
    //    _podam.getStrategy().setMemoization(false);

    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStaticStrict(AIRDatabaseProxy.class);
    PowerMock.mockStaticStrict(BL4300_EnvoyerFichier.class);
    PowerMock.resetAll();

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
  }

  /**
   * Create Dir for Tests
   *
   * @throws JAXBException
   *           on error
   * @throws IOException
   *           on error
   *
   */
  @After
  public void deleteTempDirsAndFiles() throws JAXBException, IOException
  {
    _tf.delete();
  }

  /**
   * Test case OK BL200, date expired in file, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0265_ExtractionsIndexRechercheInverse_Test_KO_000() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, temp.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(temp.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);

    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.FILE_NOT_FOUND, "File not found")); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(2);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
  }

  /**
   * Test case OK BL200, modeExecution = PRODUIRE_EXTRACTIONS</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>KO - TIMEOUT</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0265_ExtractionsIndexRechercheInverse_Test_KO_001() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);
    ConnectorResponse<Retour, Nothing> airConnectorResponse = new ConnectorResponse<>(RetourFactory.createKO(IMegConsts.CAT1, IMegSpiritConsts.TIMEOUT, "Operation timedout"), null); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    EasyMock.expect(AIRDatabaseProxy.getInstance()).andReturn(_airDbProxy);
    EasyMock.expect(_airDbProxy.getAllIndexRecherchePfi(EasyMock.anyObject(), EasyMock.eq(_currentProcess))).andReturn(airConnectorResponse);

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.KO, jsonRetour.getResultat());
  }

  /**
   * Test case OK BL200, modeExecution = PRODUIRE_EXTRACTIONS</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK - DONNEES_INVALIDES</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0265_ExtractionsIndexRechercheInverse_Test_KO_002() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);
    ConnectorResponse<Retour, Nothing> airConnectorResponse = new ConnectorResponse<>(RetourFactory.createKO(IMegConsts.CAT1, IMegConsts.DONNEE_INCONNUE, "Operation timedout"), null); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    EasyMock.expect(AIRDatabaseProxy.getInstance()).andReturn(_airDbProxy);
    EasyMock.expect(_airDbProxy.getAllIndexRecherchePfi(EasyMock.anyObject(), EasyMock.eq(_currentProcess))).andReturn(airConnectorResponse);

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case OK BL200, modeExecution = PRODUIRE_EXTRACTIONS</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>KO - LECTURE_INDISPONIBLE</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0265_ExtractionsIndexRechercheInverse_Test_KO_003() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);
    ConnectorResponse<Retour, Nothing> airConnectorResponse = new ConnectorResponse<>(RetourFactory.createKO(IMegConsts.CAT1, IMegConsts.PROBLEME_INCONNU, "Unknown Problem."), null); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    EasyMock.expect(AIRDatabaseProxy.getInstance()).andReturn(_airDbProxy);
    EasyMock.expect(_airDbProxy.getAllIndexRecherchePfi(EasyMock.anyObject(), EasyMock.eq(_currentProcess))).andReturn(airConnectorResponse);

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.LECTURE_INDISPONIBLE, jsonRetour.getDiagnostic());
  }

  /**
   * Test case OK BL200, modeExecution = PRODUIRE_EXTRACTIONS</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>KO - LECTURE_INDISPONIBLE</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0265_ExtractionsIndexRechercheInverse_Test_KO_004() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);
    RavelException re = new RavelException(ExceptionType.CONNECTOR_DATA_VALIDATION_ERROR, ErrorCode.CNCTOR_00020, "Unknown error."); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    EasyMock.expect(AIRDatabaseProxy.getInstance()).andReturn(_airDbProxy);
    EasyMock.expect(_airDbProxy.getAllIndexRecherchePfi(EasyMock.anyObject(), EasyMock.eq(_currentProcess))).andThrow(re);

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.LECTURE_INDISPONIBLE, jsonRetour.getDiagnostic());
  }

  /**
   * Test case OK BL200, date expired in file, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>KO - CAT10 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0265_ExtractionsIndexRechercheInverse_Test_KO_005() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);
    RavelException re = new RavelException(ExceptionType.UNEXPECTED, ErrorCode.TECH_00001, "Unknown error."); //$NON-NLS-1$

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, temp.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(temp.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);

    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andThrow(re);
    //    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.FILE_NOT_FOUND, "File not found")); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(2);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT10, jsonRetour.getCategorie());
    Assert.assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, jsonRetour.getDiagnostic());
  }

  /**
   * Test case KO, no configuration file</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK, CONFIGURATION_INVALIDE </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0265_ExtractionsIndexRechercheInverse_Test_KO_006() throws Throwable
  {
    //Prepare test
    _confFilePath = "error.xml"; //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
  }

  /**
   * Test case KO, no configuration file</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>NOK, CONFIGURATION_INVALIDE </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0265_ExtractionsIndexRechercheInverse_Test_KO_007() throws Throwable
  {
    //Prepare test
    _confFilePath = StringConstants.EMPTY_STRING;
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, jsonRetour.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, jsonRetour.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, jsonRetour.getDiagnostic());
  }

  /**
   * Test case OK BL200, modeExecution = PRODUIRE_EXTRACTIONS</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0265_ExtractionsIndexRechercheInverse_Test_OK_000() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);
    ConnectorResponse<Retour, Nothing> airConnectorResponse = new ConnectorResponse<>(RetourFactory.createOkRetour(), null);

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    EasyMock.expect(AIRDatabaseProxy.getInstance()).andReturn(_airDbProxy);
    EasyMock.expect(_airDbProxy.getAllIndexRecherchePfi(EasyMock.anyObject(), EasyMock.eq(_currentProcess))).andReturn(airConnectorResponse);

    PowerMock.replayAll();

    Request request = createRequest(1);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Test case OK BL200, date expired in file, BL4300=OK</br>
   *
   * <Enttrées>Entrées valides </Entrées> </br>
   * <Attendus>OK </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0265_ExtractionsIndexRechercheInverse_Test_OK_001() throws Throwable
  {
    //Prepare test
    ConcurrentHashMap<String, Map<String, String>> configParameters = loadParameters(999);

    //Prepare mock
    EasyMock.expect(_processManager.getProcessParams()).andReturn(configParameters).anyTimes();

    BL4300_EnvoyerFichierBuilder mockBL4300Builder = PowerMock.createMockAndExpectNew(BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder.class);
    EasyMock.expect(mockBL4300Builder.tracabilite(EasyMock.anyObject())).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.chaineConnexion(EasyMock.eq(FordProcessSkeleton.addFileToURI(CHAINE_CONNECTION_DEFAULT, temp.getName())))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.nomFichier(EasyMock.eq(temp.getName()))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.repertoire(EasyMock.eq(tempWorkFilePath))).andReturn(mockBL4300Builder);
    EasyMock.expect(mockBL4300Builder.build()).andReturn(_bl4300_EnvoyerFichier);

    EasyMock.expect(_bl4300_EnvoyerFichier.execute(_currentProcess)).andReturn(null);
    EasyMock.expect(_bl4300_EnvoyerFichier.getRetour()).andReturn(RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.FILE_NOT_FOUND, "File not found")); //$NON-NLS-1$

    PowerMock.replayAll();

    Request request = createRequest(2);
    _currentProcess.run(request);

    com.bytel.ravel.types.Retour jsonRetour = getRetourFromRequest(request);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.OK, jsonRetour.getResultat());
  }

  /**
   * Method for returning Retour from Request
   *
   * @param request
   *          Request
   * @return Retour
   */
  private com.bytel.ravel.types.Retour getRetourFromRequest(Request request)
  {
    Response response = (Response) request.getResponse();
    String resp = response.getGenericResponse().getResult();
    return GsonTools.getIso8601Ms().fromJson(resp, com.bytel.ravel.types.Retour.class);
  }

  /**
   * Load parameters for loadConfiguration values
   *
   * @param option
   *          option for specific alterations
   *
   * @return return Parameters
   */
  private ConcurrentHashMap<String, Map<String, String>> loadParameters(Integer option)
  {
    Map<String, String> myMap = new ConcurrentHashMap<String, String>();

    myMap.put("poolSize", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("waitingFileSize", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("endingTimeout", "6000000"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("pushTimeout", "600000"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("cheminRepTravail", tempWorkFilePath); //$NON-NLS-1$
    myMap.put("cheminRepArchiveSucces", tempSuccessFilePath); //$NON-NLS-1$
    myMap.put("cheminRepArchiveErreur", tempErrorFilePath); //$NON-NLS-1$
    myMap.put("environnement", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("nomServeurDistant", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("compteDistant", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("cheminRepDepotDistant", tempWorkFilePath); //$NON-NLS-1$
    myMap.put("listeExtractionActiviteAProduire", "SPIRIT-PFI"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("linesToFlush", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("chaineConnexion", "10"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("activateMultiThread", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    myMap.put("FILE_PATH", _confFilePath); //$NON-NLS-1$

    switch (option)
    {
      case 0:
        myMap.clear();
        break;
      case 1:
        myMap.replace("cheminRepTravail", "targetx"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      case 2:
        myMap.replace("cheminRepArchiveSucces", "targetx"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      case 3:
        myMap.replace("cheminRepArchiveErreur", "targetx"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      case 4:
        myMap.replace("cheminRepTravail", EMPTY_DIR); //$NON-NLS-1$
        break;
      case 5:
        myMap.remove("compteDistant"); //$NON-NLS-1$
        myMap.remove("cheminRepDepotDistant"); //$NON-NLS-1$
        break;
      case 6:
        myMap.replace("listeExtractionActiviteAProduire", "activite"); //$NON-NLS-1$ //$NON-NLS-2$
        break;
      default:
        break;
    }

    ConcurrentHashMap<String, Map<String, String>> finalParameters = new ConcurrentHashMap<String, Map<String, String>>();
    finalParameters.put("", myMap); //$NON-NLS-1$

    return finalParameters;
  }
}
