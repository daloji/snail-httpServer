/*******************************************************************************
 * $Id: PP0258_CreerFichierCPSTest.java 16454 2019-01-31 11:54:52Z sdiop $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.processes.PP0258;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.HttpMethod;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier.BL1300_CreerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1400_EmettreFichier;
import com.bytel.spirit.common.activities.shared.BL1400_EmettreFichier.BL1400_EmettreFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL3800_TrouverFichier;
import com.bytel.spirit.common.activities.shared.BL3800_TrouverFichier.BL3800_TrouverFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL3900_DeplacerEtRenommerFichier;
import com.bytel.spirit.common.activities.shared.BL3900_DeplacerEtRenommerFichier.BL3900_DeplacerEtRenommerFichierBuilder;
import com.bytel.spirit.common.connectors.gdr.GDRProxy;
import com.bytel.spirit.common.connectors.gdr.structs.CMDSIM;
import com.bytel.spirit.common.connectors.gdr.structs.Sim;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0258.structs.Action;
import com.bytel.spirit.ford.processes.PP0258.structs.ParametreSim;
import com.bytel.spirit.ford.processes.PP0258.structs.Vendeur;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author sdiop
 * @version ($Revision: 16454 $ $Date: 2019-01-31 12:54:52 +0100 (Thu, 31 Jan 2019) $)
 */

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ GDRProxy.class, BL3900_DeplacerEtRenommerFichier.class, BL3900_DeplacerEtRenommerFichierBuilder.class, BL3800_TrouverFichier.class, BL3800_TrouverFichierBuilder.class, PP0258_CreerFichierCPS.class, BL1300_CreerFichier.class, BL1300_CreerFichierBuilder.class, BL1400_EmettreFichier.class, BL1400_EmettreFichierBuilder.class, FileUtils.class, File.class, FileUtils.class })
public class PP0258_CreerFichierCPSTest extends EasyMockSupport
{

  /**
   * CHAINE_CONNEXION_PARAMETER
   */
  private static final String CHAINE_CONNEXION_PARAMETER = "ftp://cheminDistant.com"; //$NON-NLS-1$

  /**
   * CHEMIN_DEPOT_DISTANT_PARAMETER
   */
  private static final String CHEMIN_DEPOT_DISTANT_PARAMETER = "cheminRepDepotDistant"; //$NON-NLS-1$

  /**
   * NOM_FICHIER_PARAMETER
   */
  private static final String NOM_FICHIER_PARAMETER = "Bytel_PE_data_v1.0"; //$NON-NLS-1$

  /**
   * REPERTOIRE_SOURCE_PARAMETER
   */
  private static final String REPERTOIRE_SOURCE_PARAMETER = "repertoireSrc"; //$NON-NLS-1$

  /**
   * REPERTOIRE_ARCHIVE_SUCCES_PARAMETER
   */
  private static final String REPERTOIRE_ARCHIVE_SUCCES_PARAMETER = "repertoireArchiveSucces"; //$NON-NLS-1$

  /**
   * REPERTOIRE_ARCHIVE_ECHEC_PARAMETER
   */
  private static final String REPERTOIRE_ARCHIVE_ECHEC_PARAMETER = "repertoireArchiveEchec"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory _podam = new PodamFactoryImpl();

  /**
   *
   */

  private static Tracabilite _tracabilite;

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Pair<String, String> createParameter(String name_p, String value_p)
  {
    Pair<String, String> parameter = new Pair<String, String>(null, null);

    parameter._first = name_p;
    parameter._second = value_p;

    return parameter;
  }

  /**
   * @throws Exception
   *           exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
    _tracabilite = _podam.manufacturePojoWithFullData(Tracabilite.class);

    try
    {
      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(LocalDateTime.now());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager is now initialized")); //$NON-NLS-1$
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager instance is already initialized")); //$NON-NLS-1$
    }

  }

  //@Rule
  public TemporaryFolder _tempSrcFolder;

  /**
   * _GDRProxy Mock
   */
  @MockStrict
  private GDRProxy _GDRProxyMock;

  /**
   * File Mock
   */
  @MockStrict
  private File _File;

  /**
   * FileUtils Mock
   */
  @MockStrict
  private FileUtils _FileUtils;

  /**
   *
   */
  private PP0258_CreerFichierCPS _processInstance;

  /**
   * Mock de {@link BL3900_DeplacerEtRenommerFichier}
   */
  @MockStrict
  private BL3900_DeplacerEtRenommerFichier _Bl3900_deplacerEtRenommerFichier;

  /**
   * Mock de {@link BL3800_TrouverFichier}
   */
  @MockStrict
  private BL3800_TrouverFichier _Bl3800_trouverFichier;

  /**
   * Mock de {@link BL3800_TrouverFichierBuilder}
   */
  @MockStrict
  private BL3800_TrouverFichierBuilder _Bl3800_trouverFichierBuilder;

  /**
   * Mock de {@link BL1300_CreerFichier}
   */
  @MockStrict
  private BL1300_CreerFichier _Bl1300_creerFichier;

  /**
   * Mock de {@link BL1300_CreerFichierBuilder}
   */
  @MockStrict
  private BL1300_CreerFichierBuilder _Bl1300_creerFichierBuilder;

  /**
   * Mock de {@link BL1300_CreerFichier}
   */
  @MockStrict
  private BL1400_EmettreFichier _Bl1400_emettreFichier;

  /**
   * Mock de {@link BL1400_EmettreFichierBuilder}
   */
  @MockStrict
  private BL1400_EmettreFichierBuilder _Bl1400_emettreFichierBuilder;

  /**
   * Test case KO BL001_CtrlDonneesEntree</br>
   *
   * <Enttrées>Entrées manquantes (chaineConnexion cheminRepDepotDistant nomFichier repertoireSrc
   * repertoireArchiveSucces repertoireArchiveEchec)</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - CONFIGURATION_INVALIDE - the configuration parameter chaineConnexion is missing or null
   * - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL001_CtrlDonneesEntree_K0_001() throws Throwable
  {
    String action = "envoie"; //$NON-NLS-1$
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Request request = prepareRequest(action);
    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegConsts.CONFIGURATION_INVALIDE, retour.getDiagnostic());
    assertEquals("The configuration parameter chaineConnexion is missing or null", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL001_CtrlDonneesEntree</br>
   *
   * <Enttrées>Entrées manquantes (cheminRepDepotDistant nomFichier repertoireSrc repertoireArchiveSucces
   * repertoireArchiveEchec)</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - CONFIGURATION_INVALIDE - The configuration parameter cheminRepDepotDistant is missing
   * or null - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL001_CtrlDonneesEntree_K0_002() throws Throwable
  {
    String action = "envoie"; //$NON-NLS-1$
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegConsts.CONFIGURATION_INVALIDE, retour.getDiagnostic());
    assertEquals("The configuration parameter cheminRepDepotDistant is missing or null", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL001_CtrlDonneesEntree</br>
   *
   * <Enttrées>Entrées manquantes (nomFichier repertoireSrc repertoireArchiveSucces repertoireArchiveEchec)</Entrées>
   * </br>
   * <Attendus>NOK - ERROR 500 - CONFIGURATION_INVALIDE - The configuration parameter nomFichier is missing or null -
   * CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL001_CtrlDonneesEntree_K0_003() throws Throwable
  {
    String action = "envoie"; //$NON-NLS-1$
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegConsts.CONFIGURATION_INVALIDE, retour.getDiagnostic());
    assertEquals("The configuration parameter nomFichier is missing or null", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL001_CtrlDonneesEntree</br>
   *
   * <Enttrées>Entrées manquantes (repertoireSrc repertoireArchiveSucces repertoireArchiveEchec)</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - CONFIGURATION_INVALIDE - The configuration parameter repertoireSrc is missing or null -
   * CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL001_CtrlDonneesEntree_K0_004() throws Throwable
  {
    String action = "envoie"; //$NON-NLS-1$
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegConsts.CONFIGURATION_INVALIDE, retour.getDiagnostic());
    assertEquals("The configuration parameter repertoireSrc is missing or null", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL001_CtrlDonneesEntree</br>
   *
   * <Enttrées>Entrées manquantes (repertoireArchiveSucces repertoireArchiveEchec)</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - CONFIGURATION_INVALIDE - The configuration parameter repertoireArchiveSucces is missing
   * or null - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL001_CtrlDonneesEntree_K0_005() throws Throwable
  {
    String action = "envoie"; //$NON-NLS-1$
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegConsts.CONFIGURATION_INVALIDE, retour.getDiagnostic());
    assertEquals("The configuration parameter repertoireArchiveSucces is missing or null", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL001_CtrlDonneesEntree</br>
   *
   * <Enttrées>Entrées manquantes (repertoireArchiveEchec)</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - CONFIGURATION_INVALIDE - The configuration parameter repertoireArchiveEchec is missing
   * or null - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL001_CtrlDonneesEntree_K0_006() throws Throwable
  {
    String action = "envoie"; //$NON-NLS-1$
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegConsts.CONFIGURATION_INVALIDE, retour.getDiagnostic());
    assertEquals("The configuration parameter repertoireArchiveEchec is missing or null", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL001_CtrlDonneesEntree</br>
   *
   * <Enttrées>Entrées manquantes (action)</Entrées> </br>
   * <Attendus>NOK - ERROR 400 - DONNEE_INVALIDE - Le format des données en entrée n'est pas correct - CAT4</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL001_CtrlDonneesEntree_K0_007() throws Throwable
  {
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(null);
    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.DONNEE_INVALIDE, retour.getDiagnostic());
    assertEquals("Le format des données en entrée n'est pas correct", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT4, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL100_RecupererDonnees</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - TRAITEMENT_ARRETE - Ravel Exception - CAT10</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL100_RecupererDonnees_K0_000() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1,1,1,1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps014GetIdentifiantsCommande(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("1"))) //$NON-NLS-1$
        .andThrow(new RavelException(null, null, "Ravel Exception")); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.TRAITEMENT_ARRETE, retour.getDiagnostic());
    assertEquals("Ravel Exception", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT10, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL100_RecupererDonnees</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - LECTURE_INDISPONIBLE - Consultation impossible - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL100_RecupererDonnees_K0_001() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1,1,1,1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = new ConnectorResponse<>(null, retourKo);
    ConnectorResponse<String, Retour> gdrPEparIdentifiant = new ConnectorResponse<>(null, retourKo);
    prepareGDRps014GetIdentifiantsCommande(gdrIdentifiantsCommande, "1"); //$NON-NLS-1$
    prepareGDRgetProfilElectriqueParIdentifiant(gdrPEparIdentifiant, "1"); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.LECTURE_INDISPONIBLE, retour.getDiagnostic());
    assertEquals("Consultation impossible", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL100_RecupererDonnees</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - LECTURE_INDISPONIBLE - Consultation impossible - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL100_RecupererDonnees_K0_002() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1,1,1,1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String idcommande = "IdCommande1"; //$NON-NLS-1$
    List<String> listIdcommande = new ArrayList<>();
    listIdcommande.add(idcommande);
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = new ConnectorResponse<>(listIdcommande, retourOK);
    ConnectorResponse<String, Retour> gdrPEparIdentifiant = new ConnectorResponse<>(null, retourKo);
    prepareGDRps014GetIdentifiantsCommande(gdrIdentifiantsCommande, "1"); //$NON-NLS-1$
    prepareGDRgetProfilElectriqueParIdentifiant(gdrPEparIdentifiant, "1"); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.LECTURE_INDISPONIBLE, retour.getDiagnostic());
    assertEquals("Consultation impossible", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL100_RecupererDonnees</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - LECTURE_INDISPONIBLE - Consultation impossible - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL100_RecupererDonnees_K0_003() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1,1,1,1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String idcommande = "IdCommande1"; //$NON-NLS-1$
    String pe = "17.10"; //$NON-NLS-1$
    List<String> listIdcommande = new ArrayList<>();
    listIdcommande.add(idcommande);
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = new ConnectorResponse<>(listIdcommande, retourOK);
    ConnectorResponse<String, Retour> gdrPEparIdentifiant = new ConnectorResponse<>(pe, retourOK);
    ConnectorResponse<List<Sim>, Retour> gdrSim = new ConnectorResponse<>(null, retourKo);
    ConnectorResponse<CMDSIM, Retour> gdrCmd = new ConnectorResponse<>(null, retourKo);
    prepareGDRps014GetIdentifiantsCommande(gdrIdentifiantsCommande, "1"); //$NON-NLS-1$
    prepareGDRgetProfilElectriqueParIdentifiant(gdrPEparIdentifiant, "1"); //$NON-NLS-1$
    prepareGDRgetSimsNonPreProvisionnes(gdrSim, idcommande);
    prepareGDRps022GetCommande(gdrCmd, idcommande);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.LECTURE_INDISPONIBLE, retour.getDiagnostic());
    assertEquals("Consultation impossible", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL100_RecupererDonnees</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - LECTURE_INDISPONIBLE - Consultation impossible - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL100_RecupererDonnees_K0_004() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1,1,1,1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String idcommande = "IdCommande1"; //$NON-NLS-1$
    String pe = "17.10"; //$NON-NLS-1$
    List<String> listIdcommande = new ArrayList<>();
    listIdcommande.add(idcommande);

    Sim sim = new Sim();
    sim.setIms("imsi"); //$NON-NLS-1$
    sim.setSim("8933201234568790123"); //$NON-NLS-1$
    List<Sim> listSim = new ArrayList<>();
    listSim.add(sim);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = new ConnectorResponse<>(listIdcommande, retourOK);
    ConnectorResponse<String, Retour> gdrPEparIdentifiant = new ConnectorResponse<>(pe, retourOK);
    ConnectorResponse<List<Sim>, Retour> gdrSim = new ConnectorResponse<>(listSim, retourOK);
    ConnectorResponse<CMDSIM, Retour> gdrCmd = new ConnectorResponse<>(null, retourKo);
    prepareGDRps014GetIdentifiantsCommande(gdrIdentifiantsCommande, "1"); //$NON-NLS-1$
    prepareGDRgetProfilElectriqueParIdentifiant(gdrPEparIdentifiant, "1"); //$NON-NLS-1$
    prepareGDRgetSimsNonPreProvisionnes(gdrSim, idcommande);
    prepareGDRps022GetCommande(gdrCmd, idcommande);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.LECTURE_INDISPONIBLE, retour.getDiagnostic());
    assertEquals("Consultation impossible", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case OK BL100_RecupererDonnees</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>OK - 240 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL100_RecupererDonnees_OK() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String idcommande = "IdCommande1"; //$NON-NLS-1$
    String pe = "17.10"; //$NON-NLS-1$
    List<String> listIdcommande = new ArrayList<>();
    listIdcommande.add(idcommande);

    List<Sim> listSim = new ArrayList<>();

    CMDSIM cmdsim = new CMDSIM();
    cmdsim.setIdtFAB("Giesecke+Devrient"); //$NON-NLS-1$

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = new ConnectorResponse<>(listIdcommande, retourOK);
    ConnectorResponse<String, Retour> gdrPEparIdentifiant = new ConnectorResponse<>(pe, retourOK);
    ConnectorResponse<List<Sim>, Retour> gdrSim = new ConnectorResponse<>(listSim, retourOK);
    ConnectorResponse<CMDSIM, Retour> gdrCmd = new ConnectorResponse<>(cmdsim, retourOK);
    prepareGDRps014GetIdentifiantsCommande(gdrIdentifiantsCommande, "1"); //$NON-NLS-1$
    prepareGDRgetProfilElectriqueParIdentifiant(gdrPEparIdentifiant, "1"); //$NON-NLS-1$
    prepareGDRgetSimsNonPreProvisionnes(gdrSim, idcommande);
    prepareGDRps022GetCommande(gdrCmd, idcommande);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.OK_00204, request.getResponse().getErrorCode());
    assertNull(retour);
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL200_CreerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - DROIT_FICHIER_INVALIDE - Impossible d'accéder au fichier CPS en écriture -
   * CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL200_CreerFichierCPS_K0_001() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String idcommande = "IdCommande1"; //$NON-NLS-1$
    String pe = "17.10"; //$NON-NLS-1$
    List<String> listIdcommande = new ArrayList<>();
    listIdcommande.add(idcommande);

    Sim sim = new Sim();
    sim.setIms("imsi"); //$NON-NLS-1$
    sim.setSim("8933201234568790123"); //$NON-NLS-1$
    List<Sim> listSim = new ArrayList<>();
    listSim.add(sim);

    CMDSIM cmdsim = new CMDSIM();
    cmdsim.setIdtFAB("Giesecke+Devrient"); //$NON-NLS-1$

    String filename = NOM_FICHIER_PARAMETER.replace("_PE_", "_" + pe + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename; //$NON-NLS-1$

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur"); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = new ConnectorResponse<>(listIdcommande, retourOK);
    ConnectorResponse<String, Retour> gdrPEparIdentifiant = new ConnectorResponse<>(pe, retourOK);
    ConnectorResponse<List<Sim>, Retour> gdrSim = new ConnectorResponse<>(listSim, retourOK);
    ConnectorResponse<CMDSIM, Retour> gdrCmd = new ConnectorResponse<>(cmdsim, retourOK);
    prepareGDRps014GetIdentifiantsCommande(gdrIdentifiantsCommande, "1"); //$NON-NLS-1$
    prepareGDRgetProfilElectriqueParIdentifiant(gdrPEparIdentifiant, "1"); //$NON-NLS-1$
    prepareGDRgetSimsNonPreProvisionnes(gdrSim, idcommande);
    prepareGDRps022GetCommande(gdrCmd, idcommande);

    prepareBL3800_TrouverFichier(REPERTOIRE_SOURCE_PARAMETER, filename, retourOK);
    prepareBL3900_DeplacerEtRenommerFichier(REPERTOIRE_SOURCE_PARAMETER, filename, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER, filenameDes, retourKo);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.DROIT_FICHIER_INVALIDE, retour.getDiagnostic());
    assertEquals("Impossible d'accéder au fichier CPS en écriture", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL200_CreerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - DROIT_FICHIER_INVALIDE - Impossible d'accéder au fichier CPS en écriture -
   * CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL200_CreerFichierCPS_K0_002() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String idcommande = "IdCommande1"; //$NON-NLS-1$
    String pe = "17.10"; //$NON-NLS-1$
    List<String> listIdcommande = new ArrayList<>();
    listIdcommande.add(idcommande);

    Sim sim = new Sim();
    sim.setIms("imsi"); //$NON-NLS-1$
    sim.setSim("8933201234568790122"); //$NON-NLS-1$
    List<Sim> listSim = new ArrayList<>();
    listSim.add(sim);

    CMDSIM cmdsim = new CMDSIM();
    cmdsim.setIdtFAB("Giesecke+Devrient"); //$NON-NLS-1$

    String filename = NOM_FICHIER_PARAMETER.replace("_PE_", "_" + pe + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename; //$NON-NLS-1$

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur"); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = new ConnectorResponse<>(listIdcommande, retourOK);
    ConnectorResponse<String, Retour> gdrPEparIdentifiant = new ConnectorResponse<>(pe, retourOK);
    ConnectorResponse<List<Sim>, Retour> gdrSim = new ConnectorResponse<>(listSim, retourOK);
    ConnectorResponse<CMDSIM, Retour> gdrCmd = new ConnectorResponse<>(cmdsim, retourOK);
    prepareGDRps014GetIdentifiantsCommande(gdrIdentifiantsCommande, "1"); //$NON-NLS-1$
    prepareGDRgetProfilElectriqueParIdentifiant(gdrPEparIdentifiant, "1"); //$NON-NLS-1$
    prepareGDRgetSimsNonPreProvisionnes(gdrSim, idcommande);
    prepareGDRps022GetCommande(gdrCmd, idcommande);

    prepareBL3800_TrouverFichier(REPERTOIRE_SOURCE_PARAMETER, filename, retourOK);
    prepareBL3900_DeplacerEtRenommerFichier(REPERTOIRE_SOURCE_PARAMETER, filename, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER, filenameDes, retourOK);
    prepareBL1300_CreerFichier(REPERTOIRE_SOURCE_PARAMETER, filename, retourKo);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.DROIT_FICHIER_INVALIDE, retour.getDiagnostic());
    assertEquals("Impossible d'accéder au fichier CPS en écriture", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL200_CreerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - DROIT_FICHIER_INVALIDE - Impossible d'accéder au fichier CPS en écriture -
   * CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL200_CreerFichierCPS_K0_003() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String idcommande = "IdCommande1"; //$NON-NLS-1$
    String pe = "17.10"; //$NON-NLS-1$
    List<String> listIdcommande = new ArrayList<>();
    listIdcommande.add(idcommande);

    Sim sim = new Sim();
    sim.setIms("imsi"); //$NON-NLS-1$
    sim.setSim("8933201234568790123"); //$NON-NLS-1$
    List<Sim> listSim = new ArrayList<>();
    listSim.add(sim);

    CMDSIM cmdsim = new CMDSIM();
    cmdsim.setIdtFAB("Giesecke+Devrient"); //$NON-NLS-1$

    ParametreSim parametreSim = new ParametreSim();
    parametreSim.setImsi("imsi"); //$NON-NLS-1$;

    String filename = NOM_FICHIER_PARAMETER.replace("_PE_", "_" + pe + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename; //$NON-NLS-1$
    LocalDateTime localdate = DateTimeManager.getInstance().now();
    String date = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(localdate);

    StringBuilder content = new StringBuilder().append("FORMAT_VERSION:01.03") //$NON-NLS-1$
        .append("\nFILE_DATE:").append(date) //$NON-NLS-1$
        .append("\nSIMCardDataFormatVersion(05.30)") //$NON-NLS-1$
        .append("\nSIMCardData(").append(Vendeur.getValueByVendeur(cmdsim.getIdtFAB())).append(")") //$NON-NLS-1$  //$NON-NLS-2$
        .append("\n{\nCardProfile(").append(pe.replace(".", "_")).append(")")//$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        .append("\nCard()") //$NON-NLS-1$
        .append("\n{\nApplicationDf(3F00)") //$NON-NLS-1$
        .append("\n{\n BinaryFile(3F002FE2)") //$NON-NLS-1$
        .append("\n{\n BinaryRec(983302214365780921F3)") //$NON-NLS-1$
        .append("\n}\n}") //$NON-NLS-1$
        .append("\nSubscription()") //$NON-NLS-1$
        .append("\n{\nImsi(").append(parametreSim.getImsi()).append(")") //$NON-NLS-1$ //$NON-NLS-2$
        .append("\n}\n}") //$NON-NLS-1$
        .append("\n}"); //$NON-NLS-1$

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = new ConnectorResponse<>(listIdcommande, retourOK);
    ConnectorResponse<String, Retour> gdrPEparIdentifiant = new ConnectorResponse<>(pe, retourOK);
    ConnectorResponse<List<Sim>, Retour> gdrSim = new ConnectorResponse<>(listSim, retourOK);
    ConnectorResponse<CMDSIM, Retour> gdrCmd = new ConnectorResponse<>(cmdsim, retourOK);

    prepareGDRps014GetIdentifiantsCommande(gdrIdentifiantsCommande, "1"); //$NON-NLS-1$
    prepareGDRgetProfilElectriqueParIdentifiant(gdrPEparIdentifiant, "1"); //$NON-NLS-1$
    prepareGDRgetSimsNonPreProvisionnes(gdrSim, idcommande);
    prepareGDRps022GetCommande(gdrCmd, idcommande);

    prepareBL3800_TrouverFichier(REPERTOIRE_SOURCE_PARAMETER, filename, retourOK);
    prepareBL3900_DeplacerEtRenommerFichier(REPERTOIRE_SOURCE_PARAMETER, filename, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER, filenameDes, retourOK);
    prepareBL1300_CreerFichier(REPERTOIRE_SOURCE_PARAMETER, filename, retourOK);
    File filesource = PowerMock.createMockAndExpectNew(File.class, new Class[] { String.class }, REPERTOIRE_SOURCE_PARAMETER + File.separator + filename);
    FileUtils.writeStringToFile(filesource, content.toString());
    EasyMock.expectLastCall().andThrow(new IOException());
    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.DROIT_FICHIER_INVALIDE, retour.getDiagnostic());
    assertEquals("Impossible d'accéder au fichier CPS en écriture", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL200_CreerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - MISE_A_JOUR_INDISPONIBLE - GDR indisponible - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL200_CreerFichierCPS_K0_004() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String idcommande = "IdCommande1"; //$NON-NLS-1$
    String pe = "17.10"; //$NON-NLS-1$
    List<String> listIdcommande = new ArrayList<>();
    listIdcommande.add(idcommande);

    Sim sim = new Sim();
    sim.setIms("imsi"); //$NON-NLS-1$
    sim.setSim("89332012345687901233"); //$NON-NLS-1$
    List<Sim> listSim = new ArrayList<>();
    listSim.add(sim);

    CMDSIM cmdsim = new CMDSIM();
    cmdsim.setIdtFAB("Giesecke+Devrient"); //$NON-NLS-1$

    ParametreSim parametreSim = new ParametreSim();
    parametreSim.setImsi("imsi"); //$NON-NLS-1$;

    String filename = NOM_FICHIER_PARAMETER.replace("_PE_", "_" + pe + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename; //$NON-NLS-1$
    LocalDateTime localdate = DateTimeManager.getInstance().now();
    String date = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(localdate);

    StringBuilder content = new StringBuilder().append("FORMAT_VERSION:01.03") //$NON-NLS-1$
        .append("\nFILE_DATE:").append(date) //$NON-NLS-1$
        .append("\nSIMCardDataFormatVersion(05.30)") //$NON-NLS-1$
        .append("\nSIMCardData(").append(Vendeur.getValueByVendeur(cmdsim.getIdtFAB())).append(")") //$NON-NLS-1$  //$NON-NLS-2$
        .append("\n{\nCardProfile(").append(pe.replace(".", "_")).append(")")//$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        .append("\nCard()") //$NON-NLS-1$
        .append("\n{\nApplicationDf(3F00)") //$NON-NLS-1$
        .append("\n{\n BinaryFile(3F002FE2)") //$NON-NLS-1$
        .append("\n{\n BinaryRec(98330221436578092133)") //$NON-NLS-1$
        .append("\n}\n}") //$NON-NLS-1$
        .append("\nSubscription()") //$NON-NLS-1$
        .append("\n{\nImsi(").append(parametreSim.getImsi()).append(")") //$NON-NLS-1$ //$NON-NLS-2$
        .append("\n}\n}") //$NON-NLS-1$
        .append("\n}"); //$NON-NLS-1$

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur"); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = new ConnectorResponse<>(listIdcommande, retourOK);
    ConnectorResponse<String, Retour> gdrPEparIdentifiant = new ConnectorResponse<>(pe, retourOK);
    ConnectorResponse<List<Sim>, Retour> gdrSim = new ConnectorResponse<>(listSim, retourOK);
    ConnectorResponse<CMDSIM, Retour> gdrCmd = new ConnectorResponse<>(cmdsim, retourOK);
    ConnectorResponse<Nothing, Retour> gdrUpdate = new ConnectorResponse<>(null, retourKo);

    prepareGDRps014GetIdentifiantsCommande(gdrIdentifiantsCommande, "1"); //$NON-NLS-1$
    prepareGDRgetProfilElectriqueParIdentifiant(gdrPEparIdentifiant, "1"); //$NON-NLS-1$
    prepareGDRgetSimsNonPreProvisionnes(gdrSim, idcommande);
    prepareGDRps022GetCommande(gdrCmd, idcommande);

    prepareBL3800_TrouverFichier(REPERTOIRE_SOURCE_PARAMETER, filename, retourOK);
    prepareBL3900_DeplacerEtRenommerFichier(REPERTOIRE_SOURCE_PARAMETER, filename, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER, filenameDes, retourOK);
    prepareBL1300_CreerFichier(REPERTOIRE_SOURCE_PARAMETER, filename, retourOK);
    File filesource = PowerMock.createMockAndExpectNew(File.class, new Class[] { String.class }, REPERTOIRE_SOURCE_PARAMETER + File.separator + filename);
    FileUtils.writeStringToFile(filesource, content.toString());
    EasyMock.expectLastCall().once();
    prepareGDRupdateSimEtatMocImsi(gdrUpdate, parametreSim.getImsi());

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.MISE_A_JOUR_INDISPONIBLE, retour.getDiagnostic());
    assertEquals("GDR indisponible", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case OK BL200_CreerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>OK - 240 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL200_CreerFichierCPS_OK() throws Throwable
  {
    String action = Action.CREATION.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String idcommande = "IdCommande1"; //$NON-NLS-1$
    String pe = "17.10"; //$NON-NLS-1$
    List<String> listIdcommande = new ArrayList<>();
    listIdcommande.add(idcommande);

    Sim sim = new Sim();
    sim.setIms("imsi"); //$NON-NLS-1$
    sim.setSim("8933201234568790123"); //$NON-NLS-1$
    List<Sim> listSim = new ArrayList<>();
    listSim.add(sim);

    CMDSIM cmdsim = new CMDSIM();
    cmdsim.setIdtFAB("Giesecke+Devrient"); //$NON-NLS-1$

    ParametreSim parametreSim = new ParametreSim();
    parametreSim.setImsi("imsi"); //$NON-NLS-1$;

    String filename = NOM_FICHIER_PARAMETER.replace("_PE_", "_" + pe + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    LocalDateTime localdate = DateTimeManager.getInstance().now();
    String date = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(localdate);

    StringBuilder content = new StringBuilder().append("FORMAT_VERSION:01.03") //$NON-NLS-1$
        .append("\nFILE_DATE:").append(date) //$NON-NLS-1$
        .append("\nSIMCardDataFormatVersion(05.30)") //$NON-NLS-1$
        .append("\nSIMCardData(").append(Vendeur.getValueByVendeur(cmdsim.getIdtFAB())).append(")") //$NON-NLS-1$  //$NON-NLS-2$
        .append("\n{\nCardProfile(").append(pe.replace(".", "_")).append(")")//$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
        .append("\nCard()") //$NON-NLS-1$
        .append("\n{\nApplicationDf(3F00)") //$NON-NLS-1$
        .append("\n{\n BinaryFile(3F002FE2)") //$NON-NLS-1$
        .append("\n{\n BinaryRec(983302214365780921F3)") //$NON-NLS-1$
        .append("\n}\n}") //$NON-NLS-1$
        .append("\nSubscription()") //$NON-NLS-1$
        .append("\n{\nImsi(").append(parametreSim.getImsi()).append(")") //$NON-NLS-1$ //$NON-NLS-2$
        .append("\n}\n}") //$NON-NLS-1$
        .append("\n}"); //$NON-NLS-1$

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur"); //$NON-NLS-1$ //$NON-NLS-2$
    Retour retourOK = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = new ConnectorResponse<>(listIdcommande, retourOK);
    ConnectorResponse<String, Retour> gdrPEparIdentifiant = new ConnectorResponse<>(pe, retourOK);
    ConnectorResponse<List<Sim>, Retour> gdrSim = new ConnectorResponse<>(listSim, retourOK);
    ConnectorResponse<CMDSIM, Retour> gdrCmd = new ConnectorResponse<>(cmdsim, retourOK);
    ConnectorResponse<Nothing, Retour> gdrUpdate = new ConnectorResponse<>(null, retourOK);

    prepareGDRps014GetIdentifiantsCommande(gdrIdentifiantsCommande, "1"); //$NON-NLS-1$
    prepareGDRgetProfilElectriqueParIdentifiant(gdrPEparIdentifiant, "1"); //$NON-NLS-1$
    prepareGDRgetSimsNonPreProvisionnes(gdrSim, idcommande);
    prepareGDRps022GetCommande(gdrCmd, idcommande);

    prepareBL3800_TrouverFichier(REPERTOIRE_SOURCE_PARAMETER, filename, retourKo);
    prepareBL1300_CreerFichier(REPERTOIRE_SOURCE_PARAMETER, filename, retourOK);
    File filesource = PowerMock.createMockAndExpectNew(File.class, new Class[] { String.class }, REPERTOIRE_SOURCE_PARAMETER + File.separator + filename);
    FileUtils.writeStringToFile(filesource, content.toString());
    EasyMock.expectLastCall().once();
    prepareGDRupdateSimEtatMocImsi(gdrUpdate, parametreSim.getImsi());

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.OK_00204, request.getResponse().getErrorCode());
    assertNull(retour);
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL300_EnvoyerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - LECTURE_INDISPONIBLE - Consultation impossible - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL300_EnvoyerFichierCPS_K0_001() throws Throwable
  {
    String action = Action.ENVOIE.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1;1;1;1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String filename = "Bytelv1.0"; //$NON-NLS-1$
    Collection files = new java.util.LinkedList();
    ((LinkedList) files).add(0, new File(filename));
    File source = PowerMock.createMockAndExpectNew(File.class, new Class[] { String.class }, REPERTOIRE_SOURCE_PARAMETER);
    EasyMock.expect(FileUtils.listFiles(source, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE)).andReturn(files);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.LECTURE_INDISPONIBLE, retour.getDiagnostic());
    assertEquals("Consultation impossible", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL300_EnvoyerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - LECTURE_INDISPONIBLE - Consultation impossible - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL300_EnvoyerFichierCPS_K0_002() throws Throwable
  {
    String action = Action.ENVOIE.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1,1,1,1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String pe = "17.10"; //$NON-NLS-1$
    String filename = NOM_FICHIER_PARAMETER.replace("_PE_", "_" + pe + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename; //$NON-NLS-1$

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur"); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Nothing, Retour> gdrUpdate = new ConnectorResponse<>(null, retourKo);
    Collection files = new java.util.LinkedList();
    ((LinkedList) files).add(0, new File(filename));
    File source = PowerMock.createMockAndExpectNew(File.class, new Class[] { String.class }, REPERTOIRE_SOURCE_PARAMETER);
    EasyMock.expect(FileUtils.listFiles(source, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE)).andReturn(files);

    prepareGDRupdateSimEtatMoc(gdrUpdate, pe);
    prepareBL3900_DeplacerEtRenommerFichier(REPERTOIRE_SOURCE_PARAMETER, filename, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER, filenameDes, retourKo);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.LECTURE_INDISPONIBLE, retour.getDiagnostic());
    assertEquals("Consultation impossible", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL300_EnvoyerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - LECTURE_INDISPONIBLE - Consultation impossible - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL300_EnvoyerFichierCPS_K0_003() throws Throwable
  {
    String action = Action.ENVOIE.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1,1,1,1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String pe = "17.10"; //$NON-NLS-1$
    String filename = NOM_FICHIER_PARAMETER.replace("_PE_", "_" + pe + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename; //$NON-NLS-1$

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur"); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Nothing, Retour> gdrUpdate = new ConnectorResponse<>(null, retourKo);
    Collection files = new java.util.LinkedList();
    ((LinkedList) files).add(0, new File(filename));
    File source = PowerMock.createMockAndExpectNew(File.class, new Class[] { String.class }, REPERTOIRE_SOURCE_PARAMETER);
    EasyMock.expect(FileUtils.listFiles(source, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE)).andReturn(files);

    prepareGDRupdateSimEtatMoc(gdrUpdate, pe);
    prepareBL3900_DeplacerEtRenommerFichier(REPERTOIRE_SOURCE_PARAMETER, filename, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER, filenameDes, retourOK);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.LECTURE_INDISPONIBLE, retour.getDiagnostic());
    assertEquals("Consultation impossible", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();

  }

  /**
   * Test case KO BL300_EnvoyerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - LECTURE_INDISPONIBLE - Problème lors d'un déplacement d'un fichier - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL300_EnvoyerFichierCPS_K0_004() throws Throwable
  {
    String action = Action.ENVOIE.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1,1,1,1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String pe = "17.10"; //$NON-NLS-1$
    String filename = NOM_FICHIER_PARAMETER.replace("_PE_", "_" + pe + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur"); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Nothing, Retour> gdrUpdate = new ConnectorResponse<>(null, retourOK);
    Collection files = new java.util.LinkedList();
    ((LinkedList) files).add(0, new File(filename));
    File source = PowerMock.createMockAndExpectNew(File.class, new Class[] { String.class }, REPERTOIRE_SOURCE_PARAMETER);
    EasyMock.expect(FileUtils.listFiles(source, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE)).andReturn(files);

    prepareGDRupdateSimEtatMoc(gdrUpdate, pe);
    prepareBL1400_EmettreFichierBuilder(CHAINE_CONNEXION_PARAMETER, REPERTOIRE_SOURCE_PARAMETER, filename, CHEMIN_DEPOT_DISTANT_PARAMETER, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER, retourKo);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.DEPLACEMENT_FICHIER_INVALIDE, retour.getDiagnostic());
    assertEquals("Problème lors d'un déplacement d'un fichier", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();
  }

  /**
   * Test case KO BL300_EnvoyerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>NOK - ERROR 500 - LECTURE_INDISPONIBLE - Problème lors d'un déplacement d'un fichier - CAT1</Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL300_EnvoyerFichierCPS_K0_005() throws Throwable
  {
    String action = Action.ENVOIE.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1,1,1,1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String pe = "17.10"; //$NON-NLS-1$
    String filename = NOM_FICHIER_PARAMETER.replace("_PE_", "_" + pe + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$

    String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename; //$NON-NLS-1$

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, "ERREUR", "Erreur"); //$NON-NLS-1$ //$NON-NLS-2$
    ConnectorResponse<Nothing, Retour> gdrUpdate = new ConnectorResponse<>(null, retourOK);
    Collection files = new java.util.LinkedList();
    ((LinkedList) files).add(0, new File(filename));
    File source = PowerMock.createMockAndExpectNew(File.class, new Class[] { String.class }, REPERTOIRE_SOURCE_PARAMETER);
    EasyMock.expect(FileUtils.listFiles(source, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE)).andReturn(files);

    prepareGDRupdateSimEtatMoc(gdrUpdate, pe);
    prepareBL1400_EmettreFichierBuilder(CHAINE_CONNEXION_PARAMETER, REPERTOIRE_SOURCE_PARAMETER, filename, CHEMIN_DEPOT_DISTANT_PARAMETER, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER, retourOK);
    prepareBL3900_DeplacerEtRenommerFichier(REPERTOIRE_ARCHIVE_SUCCES_PARAMETER, filename, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER, filenameDes, retourKo);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.KO_00500, request.getResponse().getErrorCode());
    assertEquals(StringConstants.NOK, retour.getResultat());
    assertEquals(IMegSpiritConsts.DEPLACEMENT_FICHIER_INVALIDE, retour.getDiagnostic());
    assertEquals("Problème lors d'un déplacement d'un fichier", retour.getLibelle()); //$NON-NLS-1$
    assertEquals(IMegConsts.CAT1, retour.getCategorie());
    PowerMock.verifyAll();
  }

  /**
   * Test case OK BL300_EnvoyerFichierCPS</br>
   *
   * <Enttrées>Entrées valides</Entrées> </br>
   * <Attendus>OK - 240 </Attendus>
   *
   * @throws Throwable
   *           throwable
   */
  @Test
  public void PP0258_BL300_EnvoyerFichierCPS_OK() throws Throwable
  {
    String action = Action.ENVOIE.value();
    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    Map<String, String> param = new ConcurrentHashMap<>();
    param.put(PP0258_CreerFichierCPS.CHAINE_CONNEXION, CHAINE_CONNEXION_PARAMETER);
    param.put(PP0258_CreerFichierCPS.CHEMIN_DEPOT_DISTANT, CHEMIN_DEPOT_DISTANT_PARAMETER);
    param.put(PP0258_CreerFichierCPS.NOM_FICHIER, NOM_FICHIER_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_SRC, REPERTOIRE_SOURCE_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_SUCCES, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER);
    param.put(PP0258_CreerFichierCPS.REPERTOIRE_ARCHIVE_ECHEC, REPERTOIRE_ARCHIVE_ECHEC_PARAMETER);
    param.put(PP0258_CreerFichierCPS.IDENTIFIANT_PROFIL, "1,1,1,1"); //$NON-NLS-1$

    processParams.put(StringConstants.EMPTY_STRING, param);
    Request request = prepareRequest(action);
    String pe = "17.10"; //$NON-NLS-1$
    String filename = NOM_FICHIER_PARAMETER.replace("_PE_", "_" + pe + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$

    String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename; //$NON-NLS-1$

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    ConnectorResponse<Nothing, Retour> gdrUpdate = new ConnectorResponse<>(null, retourOK);
    Collection files = new java.util.LinkedList();
    ((LinkedList) files).add(0, new File(filename));
    File source = PowerMock.createMockAndExpectNew(File.class, new Class[] { String.class }, REPERTOIRE_SOURCE_PARAMETER);
    EasyMock.expect(FileUtils.listFiles(source, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE)).andReturn(files);

    prepareGDRupdateSimEtatMoc(gdrUpdate, pe);
    prepareBL1400_EmettreFichierBuilder(CHAINE_CONNEXION_PARAMETER, REPERTOIRE_SOURCE_PARAMETER, filename, CHEMIN_DEPOT_DISTANT_PARAMETER, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER, retourOK);
    prepareBL3900_DeplacerEtRenommerFichier(REPERTOIRE_ARCHIVE_SUCCES_PARAMETER, filename, REPERTOIRE_ARCHIVE_SUCCES_PARAMETER, filenameDes, retourOK);

    PowerMock.replayAll();
    _processInstance.run(request);
    String result = request.getResponse().getGenericResponse().getResult();
    Retour retour = GsonTools.getIso8601Ms().fromJson(result, Retour.class);
    assertEquals(ErrorCode.OK_00204, request.getResponse().getErrorCode());
    assertNull(retour);
    PowerMock.verifyAll();
  }

  /**
   *
   */
  @Before
  public void setUp()
  {
    _processInstance = new PP0258_CreerFichierCPS();
    _processInstance.initializeContext();

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(BL3900_DeplacerEtRenommerFichier.class);
    PowerMock.mockStaticStrict(BL3900_DeplacerEtRenommerFichierBuilder.class);
    PowerMock.mockStaticStrict(BL3800_TrouverFichier.class);
    PowerMock.mockStaticStrict(BL3800_TrouverFichierBuilder.class);
    PowerMock.mockStaticStrict(GDRProxy.class);
    PowerMock.mockStaticStrict(File.class);
    PowerMock.mockStaticStrict(FileUtils.class);
    PowerMock.mockStaticStrict(BL1300_CreerFichier.class);
    PowerMock.mockStaticStrict(BL1300_CreerFichierBuilder.class);
    PowerMock.mockStaticStrict(BL1400_EmettreFichier.class);
    PowerMock.mockStaticStrict(BL1400_EmettreFichierBuilder.class);
    PowerMock.mockStaticStrict(FileUtils.class);

  }

  /**
   * prepare BL1300_CreerFichier
   *
   * @param repertoire_p
   *          repertoire
   * @param nomFichier_p
   *          nomFichier
   * @param retour_p
   *          retour
   * @throws Exception
   *           exception
   */
  private void prepareBL1300_CreerFichier(String repertoire_p, String nomFichier_p, Retour retour_p) throws Exception
  {
    BL1300_CreerFichierBuilder bl1300_creerFichierBuilder = PowerMock.createMockAndExpectNew(BL1300_CreerFichierBuilder.class);
    EasyMock.expect(bl1300_creerFichierBuilder.repertoire(repertoire_p)).andReturn(bl1300_creerFichierBuilder);
    EasyMock.expect(bl1300_creerFichierBuilder.nomFichier(nomFichier_p)).andReturn(bl1300_creerFichierBuilder);
    EasyMock.expect(bl1300_creerFichierBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(bl1300_creerFichierBuilder);
    EasyMock.expect(bl1300_creerFichierBuilder.build()).andReturn(_Bl1300_creerFichier);

    EasyMock.expect(_Bl1300_creerFichier.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_Bl1300_creerFichier.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * prepare BL1400_EmettreFichier
   *
   * @param chaineConnexion_p
   *          chaineConnexion
   * @param repertoireSrc_p
   *          repertoireSrc
   * @param nomFichier_p
   *          nomFichier
   * @param cheminRepDepotDistant_p
   *          cheminRepDepotDistant
   * @param repertoireArchiveSucces_p
   *          repertoireArchiveSucces
   * @param retour_p
   *          retour
   * @throws Exception
   *           exception
   */
  private void prepareBL1400_EmettreFichierBuilder(String chaineConnexion_p, String repertoireSrc_p, String nomFichier_p, String cheminRepDepotDistant_p, String repertoireArchiveSucces_p, Retour retour_p) throws Exception
  {
    BL1400_EmettreFichierBuilder bl1400_emettreFichierBuilder = PowerMock.createMockAndExpectNew(BL1400_EmettreFichierBuilder.class);
    EasyMock.expect(bl1400_emettreFichierBuilder.chaineConnexion(chaineConnexion_p)).andReturn(bl1400_emettreFichierBuilder);
    EasyMock.expect(bl1400_emettreFichierBuilder.repertoireSrc(repertoireSrc_p)).andReturn(bl1400_emettreFichierBuilder);
    EasyMock.expect(bl1400_emettreFichierBuilder.nomFichier(nomFichier_p)).andReturn(bl1400_emettreFichierBuilder);
    EasyMock.expect(bl1400_emettreFichierBuilder.cheminRepDepotDistant(cheminRepDepotDistant_p)).andReturn(bl1400_emettreFichierBuilder);
    EasyMock.expect(bl1400_emettreFichierBuilder.repertoireArchiveSucces(repertoireArchiveSucces_p)).andReturn(bl1400_emettreFichierBuilder);
    EasyMock.expect(bl1400_emettreFichierBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(bl1400_emettreFichierBuilder);
    EasyMock.expect(bl1400_emettreFichierBuilder.build()).andReturn(_Bl1400_emettreFichier);

    EasyMock.expect(_Bl1400_emettreFichier.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_Bl1400_emettreFichier.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * prepare BL3800_TrouverFichier
   *
   * @param repertoire_p
   *          repertoire
   * @param nomFichier_p
   *          nomFichier
   * @param retour_p
   *          retour
   * @throws Exception
   *           exception
   */
  private void prepareBL3800_TrouverFichier(String repertoire_p, String nomFichier_p, Retour retour_p) throws Exception
  {
    BL3800_TrouverFichierBuilder bl3800_trouverFichierBuilder = PowerMock.createMockAndExpectNew(BL3800_TrouverFichierBuilder.class);
    EasyMock.expect(bl3800_trouverFichierBuilder.repertoire(repertoire_p)).andReturn(bl3800_trouverFichierBuilder);
    EasyMock.expect(bl3800_trouverFichierBuilder.masqueNomFichier(nomFichier_p)).andReturn(bl3800_trouverFichierBuilder);
    EasyMock.expect(bl3800_trouverFichierBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(bl3800_trouverFichierBuilder);
    EasyMock.expect(bl3800_trouverFichierBuilder.logSeverity(LogSeverity.INFO)).andReturn(bl3800_trouverFichierBuilder);
    EasyMock.expect(bl3800_trouverFichierBuilder.build()).andReturn(_Bl3800_trouverFichier);

    EasyMock.expect(_Bl3800_trouverFichier.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_Bl3800_trouverFichier.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * prepare BL3900_DeplacerEtRenommerFichier
   *
   * @param repertoireSrc_p
   *          repertoireSrc
   * @param nomFichierSrc_p
   *          nomFichierSrc
   * @param repertoireDes_p
   *          repertoireDes
   * @param nomFichierDes_p
   *          nomFichierDes
   * @param retour_p
   *          retour
   * @throws Exception
   *           exception
   */
  private void prepareBL3900_DeplacerEtRenommerFichier(String repertoireSrc_p, String nomFichierSrc_p, String repertoireDes_p, String nomFichierDes_p, Retour retour_p) throws Exception
  {
    BL3900_DeplacerEtRenommerFichierBuilder mockBL3900Builder = PowerMock.createMockAndExpectNew(BL3900_DeplacerEtRenommerFichierBuilder.class);
    EasyMock.expect(mockBL3900Builder.repertoireSrc(repertoireSrc_p)).andReturn(mockBL3900Builder);
    EasyMock.expect(mockBL3900Builder.nomFichierSrc(nomFichierSrc_p)).andReturn(mockBL3900Builder);
    EasyMock.expect(mockBL3900Builder.repertoireDes(repertoireDes_p)).andReturn(mockBL3900Builder);
    EasyMock.expect(mockBL3900Builder.nomFichierDes(nomFichierDes_p)).andReturn(mockBL3900Builder);
    EasyMock.expect(mockBL3900Builder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(mockBL3900Builder);
    EasyMock.expect(mockBL3900Builder.build()).andReturn(_Bl3900_deplacerEtRenommerFichier);

    EasyMock.expect(_Bl3900_deplacerEtRenommerFichier.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_Bl3900_deplacerEtRenommerFichier.getRetour()).andReturn(retour_p);

  }

  /**
   * GDR Connector getProfilElectriqueParIdentifiant
   *
   * @param connectRep_p
   *          ConnectorResponse<String, Retour>
   * @param identProfile_p
   *          identProfil
   * @throws RavelException
   *           exception
   */
  private void prepareGDRgetProfilElectriqueParIdentifiant(ConnectorResponse<String, Retour> connectRep_p, String identProfile_p) throws RavelException
  {
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.getProfilElectriqueParIdentifiant(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(identProfile_p), EasyMock.eq("E"))).andReturn(connectRep_p); //$NON-NLS-1$

  }

  /**
   * Prepare GDR getSimsNonPreProvisionnes
   *
   * @param connectorRep_p
   *          ConnectorResponse<List<Sim>, Retour>
   * @param identCommande_p
   *          identCommande_p
   * @throws RavelException
   *           exception
   */
  private void prepareGDRgetSimsNonPreProvisionnes(ConnectorResponse<List<Sim>, Retour> connectorRep_p, String identCommande_p) throws RavelException
  {
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.getSimsNonPreProvisionnes(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(identCommande_p), EasyMock.eq("preprovisionne"))).andReturn(connectorRep_p); //$NON-NLS-1$

  }

  /**
   * prepareGDR Connector
   *
   * @param connectorRep_p
   *          connectorRep
   * @param idprofile_p
   *          idprofile
   * @throws RavelException
   *           exception
   */
  private void prepareGDRps014GetIdentifiantsCommande(ConnectorResponse<List<String>, Retour> connectorRep_p, String idprofile_p) throws RavelException
  {
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps014GetIdentifiantsCommande(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idprofile_p))).andReturn(connectorRep_p);
  }

  /**
   * Prepare GDR getSimsNonPreProvisionnes
   *
   * @param connectorRep_p
   *          ConnectorResponse<List<Sim>, Retour>
   * @param identCommande_p
   *          identCommande_p
   * @throws RavelException
   *           exception
   */
  private void prepareGDRps022GetCommande(ConnectorResponse<CMDSIM, Retour> connectorRep_p, String identCommande_p) throws RavelException
  {
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.ps022GetCommande(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(identCommande_p))).andReturn(connectorRep_p);

  }

  /**
   * prepareGDR Connector
   *
   * @param connectorRep_p
   *          connectorRep
   * @param pe_p
   *          imsi
   * @throws RavelException
   *           exception
   */
  private void prepareGDRupdateSimEtatMoc(ConnectorResponse<Nothing, Retour> connectorRep_p, String pe_p) throws RavelException
  {
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.updateSimEtatMoc(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(pe_p), EasyMock.eq("preprovisionne"))) //$NON-NLS-1$
        .andReturn(connectorRep_p);
  }

  /**
   * prepareGDR Connector
   *
   * @param connectorRep_p
   *          connectorRep
   * @param imsi_p
   *          imsi
   * @throws RavelException
   *           exception
   */
  private void prepareGDRupdateSimEtatMocImsi(ConnectorResponse<Nothing, Retour> connectorRep_p, String imsi_p) throws RavelException
  {
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.updateSimEtatMocImsi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(imsi_p), EasyMock.eq("temporaire"))).andReturn(connectorRep_p); //$NON-NLS-1$
  }

  /**
   * @param action
   *          action
   * @return Request
   */
  private Request prepareRequest(String action)
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod(HttpMethod.POST);
    request.setMsgId(_tracabilite.getIdCorrelationSpirit());

    List<Parameter> parameters = new ArrayList<>();
    if (action != null)
    {
      Parameter parameter = new Parameter(PP0258_CreerFichierCPS.URL_PARAM, action);
      parameters.add(parameter);
    }

    UrlParameters urlParametersType = new UrlParameters();
    urlParametersType.setUrlParameters(parameters);
    request.setUrlParameters(urlParametersType);
    return request;
  }

}
