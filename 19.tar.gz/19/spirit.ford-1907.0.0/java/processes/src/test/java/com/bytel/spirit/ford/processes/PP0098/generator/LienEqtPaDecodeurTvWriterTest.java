/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import com.bytel.spirit.ford.processes.TestUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0098.generator.LienEqtPaDecodeurTvWriter.Header;

/**
 *
 * @author asoares
 * @version ($Revision$ $Date$)
 */
public class LienEqtPaDecodeurTvWriterTest
{
  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-LIENEQTPADECODEURTV.csv"; //$NON-NLS-1$

  /**
   * The PaVoipWriter to be tested.
   */
  private LienEqtPaDecodeurTvWriter _lienEqtPaDecodeurTvWriter;

  /**
   * The tracabilite.
   */
  private Tracabilite _tracabilite;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Tests initialization.
   *
   * @throws Exception
   *           on error
   */
  @Before
  public void beforeTest() throws Exception
  {
    _tracabilite = new Tracabilite();
    _tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _lienEqtPaDecodeurTvWriter = new LienEqtPaDecodeurTvWriter(FILENAME, 2);
  }

  /**
   * Nominal test case.<br/>
   *
   * <b>Input:</b>Valid PFI<br/>
   * <b>Expected:</b>Header + 1 line created<br/>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void lienEqtPADecodeurTVWriterTest_01() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/pfi.json"); //$NON-NLS-1$
    _lienEqtPaDecodeurTvWriter.dumpPFI(_tracabilite, pfi, LocalDate.of(2018,5,1));
    _lienEqtPaDecodeurTvWriter.close();

    List<String> expectedLine1 = Arrays.asList("BSS_GP", "612104018213", "610006280137", "PALF01", "RESILIE", "EQDECOTV01", "DECODEUR_TV", "MX200","", "3526350070663", "ARCADYAN", "XDSL", "75105", "20180501131559", "20180501131606"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$
    List<String> expectedLine2 = Arrays.asList("BSS_GP", "612104018213", "610006280137", "PALF02", "ACTIF", "EQDECOTV01", "DECODEUR_TV", "MX200","", "3526350070663", "ARCADYAN", "XDSL", "75105", "20180501131606", "20180501131606"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(Header.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(3, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(expectedLine1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
    assertEquals(expectedLine2.toString(), Arrays.asList(lines.get(2).split(SEMICOLON)).toString());
  }

  /**
   * Test case with EquipementDeclare.type != DECODEUR_TV.<br/>
   *
   * <b>Input:</b>EquipementDeclare.type != DECODEUR_TV<br/>
   * <b>Expected:</b>Header created<br/>
   *
   * @throws Exception
   *           on error
   */
  //@Test
  public void lienEqtPADecodeurTVWriterTest_02() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienEqtPADecodeurTV_EqtDeclareTypeNotDECODEUR_TV.json"); //$NON-NLS-1$
    _lienEqtPaDecodeurTvWriter.dumpPFI(_tracabilite, pfi, LocalDate.of(2018,5,1));
    _lienEqtPaDecodeurTvWriter.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(Header.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(1, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
  }

  /**
   * Test case with PA.type != LIGNE_FIXE.<br/>
   *
   * <b>Input:</b>PA.type != LIGNE_FIXE<br/>
   * <b>Expected:</b>Header + 1 line created<br/>
   *
   * @throws Exception
   *           on error
   */
  //@Test
  public void lienEqtPADecodeurTVWriterTest_03() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienEqtPADecodeurTV_PATypeNotLIGNE_FIXE.json"); //$NON-NLS-1$
    _lienEqtPaDecodeurTvWriter.dumpPFI(_tracabilite, pfi, LocalDate.of(2018,5,1));
    _lienEqtPaDecodeurTvWriter.close();

    List<String> expectedLine1 = Arrays.asList("BSS_ENT", "610000012345", "valIdEqt2", "valIdPA1", "ACTIF", "1234567890", "DECODEUR_TV", "MX200", "1DE4HFF80896A", "8F9", "SAMSUNG", StringUtils.EMPTY, StringUtils.EMPTY, "20170518174337", "20170613174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(Header.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(expectedLine1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

}
