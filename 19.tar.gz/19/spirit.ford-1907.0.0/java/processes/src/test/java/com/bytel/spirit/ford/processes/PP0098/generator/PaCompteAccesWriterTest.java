/*******************************************************************************
* $Id: PaCompteAccesWriterTest.java 14226 2018-12-06 15:29:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import com.bytel.spirit.ford.processes.TestUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0098.generator.PaCompteAccesWriter.PacaHeader;

/**
 *
 * @author vloureir
 * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
 */
public class PaCompteAccesWriterTest
{

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-PACA.csv"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * The Writer to test
   */
  private PaCompteAccesWriter _writer;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _writer = new PaCompteAccesWriter(FILENAME, 2);
  }

  /**
   * Scenario: Create two lines<br>
   * Input: The PFI to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void paca_spirit356() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/PFI_spirit356.json"); //$NON-NLS-1$

    List<String> line1 = Arrays.asList("BSS_GP", "610030396932", "6730396932000000000", "ACTIF", "jeanfrancois.sauvageot", "20180612145441", "20180612145442"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2018, 06, 12));
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PacaHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    for (String line : lines)
    {
      System.out.print(line + "\n");
    }

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: Create two lines<br>
   * Input: The PFI to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void pacaWritterTest_01() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/Paca_Nominal.json"); //$NON-NLS-1$

    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "valIdPA1", "ACTIF", "john.doe@monmail.fr", "20170518184337", "20170518184337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    List<String> line2 = Arrays.asList("BSS_GP", "610000012345", "valIdPA2", "ACTIF", "john.doe@monmail.fr", "20170518184337", "20170518184337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 05, 18));
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PacaHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    for (String line : lines)
    {
      System.out.print(line + "\n");
    }

    assertEquals(3, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
    assertEquals(line2.toString(), Arrays.asList(lines.get(2).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: test OK with Valid Equipement COMPTE_ACCES but with some fields empty <br>
   * Input: Valid PFI with some empty fields <br>
   * Result: Create a complete line <br>
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void pacaWritterTest_02() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/Paca_WithEmptyFields.json"); //$NON-NLS-1$

    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "valIdPA1", "ACTIF", "", "20170518184337", "20170518184337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
    List<String> line2 = Arrays.asList("BSS_GP", "610000012345", "valIdPA2", "", "john.doe@monmail.fr", "20170518184337", "20170518184337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 05, 18));
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PacaHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(3, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
    assertEquals(line2.toString(), Arrays.asList(lines.get(2).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: test OK with Invalid Equipement COMPTE_ACCES <br>
   * Input: Valid PFIof type IAD <br>
   * Result: No Lines created <br>
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void pacaWritterTest_03() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/Paca_InvalidPFI.json"); //$NON-NLS-1$
    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2018, 5, 1));
    _writer.close();
  }

}
