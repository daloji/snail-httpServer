/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207;

import java.io.File;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.csv.CSVFileReader;
import com.bytel.ravel.common.csv.CSVFileWriter;
import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IRavelRequest;
import com.bytel.ravel.common.factory.request.IUrlParameters;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.RavelRequestFactory;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.ftp.FTPProxy;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.eligprev.config.ConfigFichier;
import com.bytel.spirit.common.eligprev.config.ConfigGroupeFichier;
import com.bytel.spirit.common.eligprev.config.ConfigGroupeFichierListe;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.EtatReferentiel;
import com.bytel.spirit.common.shared.saab.res.FichierOrigine;
import com.bytel.spirit.common.shared.saab.res.FichierReferentielComposite;
import com.bytel.spirit.common.shared.saab.res.GestionReferentiel;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.saab.connectors.res.RESDatabaseProxy;
import com.bytel.spirit.saab.connectors.res.geod.type.TypeReferentiel;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PP0207_IntegrationReferentiel.class, RESDatabaseProxy.class, DateTimeManager.class, Files.class, File.class, FTPProxy.class, Messages.class, ProcessManager.class, BL1200_DeplacerFichierBuilder.class, BL1200_DeplacerFichier.class, CSVFileReader.class })
public class PP0207_IntegrationReferentiel_Test extends EasyMockSupport
{
  /**
   * Factory to generate beans
   */
  private static PodamFactory _podam;

  /**
   * ConfigGroupeFichier Param
   */
  private static final String CONF_PARAM = "FILE_PATH"; //$NON-NLS-1$

  /**
   * ID_CORRELATION
   */
  private static final String ID_CORRELATION = "PP0207"; //$NON-NLS-1$

  /**
   * REP_TRAVAIL
   */
  @SuppressWarnings("nls")
  private static final String REP_TRAVAIL = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "PP0207";

  /**
   * REP_ARCHIVE
   */
  @SuppressWarnings("nls")
  private static final String REP_ARCHIVE = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "repArchive";

  /**
   * REP_ARCHIVE
   */
  @SuppressWarnings("nls")
  private static final String REP_CR = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "repCR" + File.separator + "CR1.csv";

  /**
   * CHEMIN
   */
  @SuppressWarnings("nls")
  private static final String REPO = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "repo";

  /**
   * The constant for PP0207.BL001_VerifierDonnes message
   */
  private static final String MESSAGE_BL001_VERIFIER_DONNES = Messages.getString("PP0207.BL001_VerifierDonnes"); //$NON-NLS-1$

  /**
   * The constant for PP0207._BL001_VerifierDonnesGeneric message
   */
  private static final String MESSAGE_BL001_VERIFIER_DONNES_GENERIC = Messages.getString("PP0207.BL001_VerifierDonnesGeneric"); //$NON-NLS-1$

  /**
   * The constant for PP0207._BL0100_MissingFiles message
   */
  private static final String MESSAGE_BL100_MISSING_FLES = Messages.getString("PP0207.BL100_MissingFiles"); //$NON-NLS-1$

  /**
   * The constant for PP0207._BL0100_Indexincoherent message
   */
  private static final String MESSAGE_BL100_INCOHERENT_INDEX = Messages.getString("PP0207.BL100_Indexincoherent"); //$NON-NLS-1$

  /**
   * The constant for PP0207._BL100_GroupeFichiersObsolete message
   */
  private static final String MESSAGE_BL100_OBSOLETE = Messages.getString("PP0207.BL100_GroupeFichiersObsolete"); //$NON-NLS-1$

  /**
   * The constant for PP0207.FileError message
   */
  private static final String MESSAGE_FILE_ERROR = Messages.getString("PP0207.FileError"); //$NON-NLS-1$

  /**
   * The constant for PP0207.NoParam message
   */
  private static final String MESSAGE_NO_PARAM = Messages.getString("PP0207.NoParam"); //$NON-NLS-1$

  /**
   * The type referentiel parameter constant
   */
  private static final String TYPE_REFERENTIEL_PARAMETER = "typeReferentiel"; //$NON-NLS-1$

  /**
   * NOM_CONNECTEUR
   */
  private static final String NOM_CONNECTEUR = "PP0207_FTPConnector"; //$NON-NLS-1$

  /**
   * Initialization method
   */
  @BeforeClass
  public static void init()
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    _podam = new PodamFactoryImpl();
  }

  /**
   * Mock de {@link DateTimeManager}
   */
  @MockStrict
  private DateTimeManager _dateTimeManagerMock;

  /**
   * Mock de {@link RESProxy}
   */
  @MockStrict
  private RESDatabaseProxy _resProxyMock;

  /**
   * Mock de {@link CSVFileReader}
   */
  @MockNice
  private CSVFileReader _csvFileReader;
  /**
   * Mock de {@link CSVFileWriter}
   */
  @MockNice
  private CSVFileWriter _csvFileWriter;

  /**
   * Instance of {@link PP0207_IntegrationReferentiel}
   */
  private PP0207_IntegrationReferentiel _processInstance;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  private ProcessManager _processManager;

  /**
   * Mock de {@link BL1200_DeplacerFichierBuilder}
   */
  @MockStrict
  private BL1200_DeplacerFichierBuilder _res1200BuilderMock;

  /**
   * Mock de {@link BL1200_DeplacerFichier}
   */
  @MockStrict
  private BL1200_DeplacerFichier _res1200Builder;

  /**
   * Mock de {@link FTPProxy}
   */
  @MockStrict
  private FTPProxy _ftpProxyMock;

  /**
   * Clear configuration
   */
  @Before
  public void beforeTest()
  {
    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // on indique que la classe de log sera mocké de façon statique dans le test à venir
    PowerMock.mockStaticNice(Files.class);
    PowerMock.mockStaticNice(File.class);
    PowerMock.mockStaticNice(CSVFileWriter.class);
    PowerMock.mockStaticNice(CSVFileReader.class);
    PowerMock.mockStaticStrict(FTPProxy.class);

    // On initialise toutes les classes à mocker comportant un appel à un eméthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et le getInstance)
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStaticStrict(DateTimeManager.class);
    PowerMock.mockStaticStrict(RESDatabaseProxy.class);
    PowerMock.mockStaticStrict(BL1200_DeplacerFichierBuilder.class);
    PowerMock.mockStaticStrict(BL1200_DeplacerFichier.class);
  }

  /**
   * Tests failed entry parameter check, No typeRef <br/>
   *
   * <b> Entries: </ b> Invalid entry data. <br/>
   * <b> Expected: </ b> Return NOK (CAT10, TRAITEMENT_ARRETE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_001() throws Throwable
  {
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "La configuration est absente pour typeReferentiel"); //$NON-NLS-1$
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(null, null));
    checkResponse(resp, expected);
  }

  /**
   * Tests failed entry parameter check, Invalid typeRef <br/>
   *
   * <b> Entries: </ b> Invalid entry data. <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_002() throws Throwable
  {
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "La configuration est absente pour typeReferentiel"); //$NON-NLS-1$
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest("wrong type", "incorrect")); //$NON-NLS-1$ //$NON-NLS-2$
    checkResponse(resp, expected);
  }

  /**
   * Tests failed entry parameter check, No conf file <br/>
   *
   * <b> Entries: </ b> Invalid entry data. <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_003() throws Throwable
  {
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "Type referentiel inconnu pour : invalid"); //$NON-NLS-1$
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, "invalid")); //$NON-NLS-1$
    checkResponse(resp, expected);
  }

  /**
   * Tests failed entry parameter check, No Path <br/>
   *
   * <b> Entries: </ b> Invalid entry data. <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_004() throws Throwable
  {
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "cannot find param FILE_PATH in process configuration"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams("invalid", "invalid"); //$NON-NLS-1$ //$NON-NLS-2$
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, TypeReferentiel.COUV_FTTO.name()));
    checkResponse(resp, expected);
  }

  /**
   * Tests failed entry parameter check, Invalid typeRef inside the ConfigurationGroupFichier<br/>
   *
   * <b> Entries: </ b> Invalid entry data. <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_005() throws Throwable
  {
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "La configuration est absente pour COUV_FTTO"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(new ConfigGroupeFichierListe()).getBytes()); //ERROR
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, TypeReferentiel.COUV_FTTO.name()));
    checkResponse(resp, expected);
  }

  /**
   * Tests failed entry parameter check, Inchoerent typeRef in ConfigurationGroupFichier<br/>
   *
   * <b> Entries: </ b> Invalid entry data. <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_006() throws Throwable
  {
    ConfigGroupeFichier configGroupeFichier = new ConfigGroupeFichier();
    configGroupeFichier.setTypeReferentiel("something else"); //$NON-NLS-1$
    ConfigGroupeFichierListe configGroupeFichierListe = new ConfigGroupeFichierListe();
    configGroupeFichierListe.getConfigGroupeFichier().add(configGroupeFichier);
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "La configuration est absente pour COUV_FTTO"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configGroupeFichierListe).getBytes()); //ERROR
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, TypeReferentiel.COUV_FTTO.name()));
    checkResponse(resp, expected);
  }

  /**
   * Tests failed entry parameter check, Invalid typeRef <br/>
   *
   * <b> Entries: </ b> Invalid entry data. <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_007() throws Throwable
  {
    ConfigGroupeFichier configGroupeFichier = new ConfigGroupeFichier();
    configGroupeFichier.setTypeReferentiel("COUV_FTTO"); //$NON-NLS-1$
    ConfigGroupeFichierListe configGroupeFichierListe = new ConfigGroupeFichierListe();
    configGroupeFichierListe.getConfigGroupeFichier().add(configGroupeFichier);
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "Le configuration est invalide"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configGroupeFichierListe).getBytes()); //ERROR
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, TypeReferentiel.COUV_FTTO.name()));
    checkResponse(resp, expected);
  }

  /**
   * Tests failed entry parameter check, Missing CheminRepTravail <br/>
   *
   * <b> Entries: </ b> Invalid entry data. <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_008() throws Throwable
  {
    ConfigGroupeFichier configGroupeFichier = new ConfigGroupeFichier();
    configGroupeFichier.setTypeReferentiel("COUV_FTTO"); //$NON-NLS-1$
    ConfigGroupeFichierListe configGroupeFichierListe = new ConfigGroupeFichierListe();
    configGroupeFichierListe.getConfigGroupeFichier().add(configGroupeFichier);
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "Le configuration est invalide"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configGroupeFichierListe).getBytes()); //ERROR
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, "COUV_FTTO")); //$NON-NLS-1$
    checkResponse(resp, expected);
  }

  /**
   * Tests failed entry parameter check, Missing cheminRepArchive <br/>
   *
   * <b> Entries: </ b> Invalid entry data. <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_009() throws Throwable
  {
    ConfigGroupeFichier configGroupeFichier = new ConfigGroupeFichier();
    configGroupeFichier.setTypeReferentiel("COUV_FTTO"); //$NON-NLS-1$
    configGroupeFichier.setCheminRepTravail("travaille"); //$NON-NLS-1$
    ConfigGroupeFichierListe configGroupeFichierListe = new ConfigGroupeFichierListe();
    configGroupeFichierListe.getConfigGroupeFichier().add(configGroupeFichier);
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "Le configuration est invalide"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configGroupeFichierListe).getBytes()); //ERROR
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, "COUV_FTTO")); //$NON-NLS-1$
    checkResponse(resp, expected);
  }

  /**
   * Tests failed entry parameter check, Missing List conf fichier <br/>
   *
   * <b> Entries: </ b> Invalid entry data. <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_010() throws Throwable
  {
    ConfigGroupeFichier configGroupeFichier = new ConfigGroupeFichier();
    configGroupeFichier.setTypeReferentiel("COUV_FTTO"); //$NON-NLS-1$
    configGroupeFichier.setCheminRepTravail("travaille"); //$NON-NLS-1$
    configGroupeFichier.setCheminRepArchive("archive"); //$NON-NLS-1$
    ConfigGroupeFichierListe configGroupeFichierListe = new ConfigGroupeFichierListe();
    configGroupeFichierListe.getConfigGroupeFichier().add(configGroupeFichier);
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, "Le configuration est invalide"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configGroupeFichierListe).getBytes()); //ERROR
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, "COUV_FTTO")); //$NON-NLS-1$
    checkResponse(resp, expected);
  }

  /**
   * Tests failed <br/>
   *
   * <b> Entries: </ b> Can't find a file in directory <br/>
   * <b> Expected: </ b> Return NOK (CAT3, FICHIERS_INCOHERENTS) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_011() throws Throwable
  {
    TypeReferentiel typeReferentiel = TypeReferentiel.COUV_FTTO;
    ConfigGroupeFichier configGroupeFichier = createConfigGroupeFichier(typeReferentiel);
    ConfigFichier configFichier = new ConfigFichier();
    configFichier.setPattern("COUVERTURE_FTTO_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configGroupeFichier.getConfigFichier().add(configFichier);
    ConfigFichier configFichier2 = new ConfigFichier();
    configFichier2.setPattern("COUVERTURE_FTTO2_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configGroupeFichier.getConfigFichier().add(configFichier2);
    ConfigGroupeFichierListe configGroupeFichierListe = new ConfigGroupeFichierListe();
    configGroupeFichierListe.getConfigGroupeFichier().add(configGroupeFichier);

    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT3, IMegSpiritConsts.FICHIERS_INCOHERENTS, MessageFormat.format(MESSAGE_BL100_MISSING_FLES, typeReferentiel));
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);
    final File fileMock = EasyMock.createMock(File.class);
    String[] fileNameList = new String[2];
    fileNameList[0] = "COUVERTURE_FTTO_ECOSPIRIT_20180811_2.csv"; //$NON-NLS-1$
    fileNameList[1] = "COUVERTURE_FTTO_ECOSPIRIT_20180811_3.csv"; //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configGroupeFichierListe).getBytes());

    EasyMock.expect(fileMock.list()).andReturn(fileNameList);
    // EasyMock.replay(fileMock);

    Class<?>[] parameterTypes = new Class[] { String.class };
    PowerMock.expectNew(File.class, parameterTypes, EasyMock.isA(String.class)).andReturn(fileMock);
    PowerMock.replay(File.class);
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, typeReferentiel.name()));
    checkResponse(resp, expected);
  }

  /**
   * Tests failed <br/>
   *
   * <b> Entries: </ b> File index no coherent <br/>
   * <b> Expected: </ b> Return NOK (CAT3, FICHIERS_INCOHERENTS) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_012() throws Throwable
  {
    TypeReferentiel typeReferentiel = TypeReferentiel.COUV_FTTO;
    ConfigGroupeFichier configGroupeFichier = createConfigGroupeFichier(typeReferentiel);
    ConfigFichier configFichier = new ConfigFichier();
    configFichier.setPattern("COUVERTURE_FTTO_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configGroupeFichier.getConfigFichier().add(configFichier);
    ConfigFichier configFichier2 = new ConfigFichier();
    configFichier2.setPattern("COUVERTURE_FTTO2_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configGroupeFichier.getConfigFichier().add(configFichier2);
    ConfigGroupeFichierListe configGroupeFichierListe = new ConfigGroupeFichierListe();
    configGroupeFichierListe.getConfigGroupeFichier().add(configGroupeFichier);

    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT3, IMegSpiritConsts.FICHIERS_INCOHERENTS, MessageFormat.format(MESSAGE_BL100_INCOHERENT_INDEX, typeReferentiel));
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);
    final File fileMock = EasyMock.createMock(File.class);
    String[] fileNameList = new String[3];
    fileNameList[0] = "COUVERTURE_FTTO_ECOSPIRIT_20180811_2.csv"; //$NON-NLS-1$
    fileNameList[1] = "COUVERTURE_FTTO_ECOSPIRIT_20180811_3.csv"; //$NON-NLS-1$
    fileNameList[2] = "COUVERTURE_FTTO2_ECOSPIRIT_20180811_2.csv"; //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configGroupeFichierListe).getBytes());

    EasyMock.expect(fileMock.list()).andReturn(fileNameList);
    EasyMock.replay(fileMock);

    Class<?>[] parameterTypes = new Class[] { String.class };
    PowerMock.expectNew(File.class, parameterTypes, EasyMock.isA(String.class)).andReturn(fileMock);
    PowerMock.replay(File.class);
    _processInstance = new PP0207_IntegrationReferentiel();
    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, typeReferentiel.name()));
    checkResponse(resp, expected);
  }

  /**
   * Tests failed <br/>
   *
   * <b> Entries: </ b> File index in db is higher <br/>
   * <b> Expected: </ b> Return NOK (CAT3, FICHIERS_INCOHERENTS) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_013() throws Throwable
  {
    TypeReferentiel typeReferentiel = TypeReferentiel.COUV_FTTO;
    ConfigGroupeFichier configGroupeFichier = createConfigGroupeFichier(typeReferentiel);
    ConfigFichier configFichier = new ConfigFichier();
    configFichier.setPattern("COUVERTURE_FTTO_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configGroupeFichier.getConfigFichier().add(configFichier);
    ConfigFichier configFichier2 = new ConfigFichier();
    configFichier2.setPattern("COUVERTURE_FTTO2_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configGroupeFichier.getConfigFichier().add(configFichier2);
    ConfigGroupeFichierListe configGroupeFichierListe = new ConfigGroupeFichierListe();
    configGroupeFichierListe.getConfigGroupeFichier().add(configGroupeFichier);

    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegSpiritConsts.FICHIERS_OBSOLETES, MessageFormat.format(MESSAGE_BL100_OBSOLETE, typeReferentiel));
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);
    final File fileMock = EasyMock.createMock(File.class);
    String[] fileNameList = new String[3];
    fileNameList[0] = "COUVERTURE_FTTO_ECOSPIRIT_20180811_2.csv"; //$NON-NLS-1$
    fileNameList[1] = "COUVERTURE_FTTO_ECOSPIRIT_20180811_3.csv"; //$NON-NLS-1$
    fileNameList[2] = "COUVERTURE_FTTO2_ECOSPIRIT_20180811_3.csv"; //$NON-NLS-1$

    List<FichierReferentielComposite> listFichComposite = new ArrayList<>();
    List<FichierOrigine> listeFichierOrigine = new ArrayList<>();
    listeFichierOrigine.add(new FichierOrigine("nom_p", "typeFichier_p", 8888, null, "3", "idRef_p", "typeReferentiel_p")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    GestionReferentiel referentiel = new GestionReferentiel("idRef_p", "typeReferentiel_p", EtatReferentiel.ACTIVE); //$NON-NLS-1$ //$NON-NLS-2$
    referentiel.setListeNomFichierOrigine(Arrays.asList("nom_p")); //$NON-NLS-1$
    listFichComposite.add(new FichierReferentielComposite(referentiel, listeFichierOrigine));

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configGroupeFichierListe).getBytes());

    EasyMock.expect(fileMock.list()).andReturn(fileNameList).anyTimes();
    EasyMock.replay(fileMock);

    Class<?>[] parameterTypes = new Class[] { String.class };
    PowerMock.expectNew(File.class, parameterTypes, EasyMock.isA(String.class)).andReturn(fileMock).anyTimes();
    PowerMock.replay(File.class);

    expectGetListGestionReferentiel(RetourFactory.createOkRetour(), RetourFactory.createOkRetour(), typeReferentiel, listFichComposite);
    _processInstance = new PP0207_IntegrationReferentiel();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();

    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, typeReferentiel.name()));
    checkResponse(resp, expected);
  }

  /**
   * Tests failed BL200, problem calling gestionReferentielCreer<br/>
   *
   * <b> Entries: </ b> <br/>
   * <b> Expected: </ b> Return NOK (CAT3, FICHIERS_INCOHERENTS) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_KO_014() throws Throwable
  {
    TypeReferentiel typeReferentiel = TypeReferentiel.COUV_FTTO;
    ConfigGroupeFichier configGroupeFichier = createConfigGroupeFichier(typeReferentiel);
    ConfigFichier configFichier = new ConfigFichier();
    configFichier.setPattern("COUVERTURE_FTTO_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configGroupeFichier.getConfigFichier().add(configFichier);
    ConfigFichier configFichier2 = new ConfigFichier();
    configFichier2.setPattern("COUVERTURE_FTTO2_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configGroupeFichier.getConfigFichier().add(configFichier2);
    ConfigGroupeFichierListe configGroupeFichierListe = new ConfigGroupeFichierListe();
    configGroupeFichierListe.getConfigGroupeFichier().add(configGroupeFichier);

    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.ACCES_NON_AUTORISE, "some message res"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);
    final File fileMock = EasyMock.createMock(File.class);
    String[] fileNameList = new String[3];
    fileNameList[0] = "COUVERTURE_FTTO_ECOSPIRIT_[20180811]_[2].csv"; //$NON-NLS-1$
    fileNameList[1] = "COUVERTURE_FTTO_ECOSPIRIT_[20180812]_[3].csv"; //$NON-NLS-1$
    fileNameList[2] = "COUVERTURE_FTTO2_ECOSPIRIT_[20180811]_[3].csv"; //$NON-NLS-1$

    List<FichierReferentielComposite> listFichComposite = new ArrayList<>();
    List<FichierOrigine> listeFichierOrigine = new ArrayList<>();
    listeFichierOrigine.add(new FichierOrigine("nom_p", "typeFichier_p", 8888, null, "4", "idRef_p", "typeReferentiel_p")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    listFichComposite.add(new FichierReferentielComposite(null, listeFichierOrigine));

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configGroupeFichierListe).getBytes());

    EasyMock.expect(fileMock.list()).andReturn(fileNameList).anyTimes();
    EasyMock.replay(fileMock);

    Class<?>[] parameterTypes = new Class[] { String.class };
    PowerMock.expectNew(File.class, parameterTypes, EasyMock.isA(String.class)).andReturn(fileMock).anyTimes();
    PowerMock.replay(File.class);

    Retour retourRes = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "some message res"); //$NON-NLS-1$
    expectGetListGestionReferentiel(retourRes, null, typeReferentiel, listFichComposite);

    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createGestionReferentiel(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel))).andReturn(new ConnectorResponse<>(expected, null));
    _processInstance = new PP0207_IntegrationReferentiel();

    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, typeReferentiel.name()));
    checkResponse(resp, expected);
  }

  /**
   * Tests nominal<br/>
   *
   * <b> Entries: </ b> <br/>
   * <b> Expected: </ b> Return OK <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_OK_Cuivre() throws Throwable
  {
    TypeReferentiel typeReferentiel = TypeReferentiel.COUV_CUIVRE;
    ConfigGroupeFichier configGroupeFichier = createConfigGroupeFichier(typeReferentiel);
    ConfigFichier configFichier = new ConfigFichier();
    configFichier.setPattern("COUVERTURE_CUIVRE_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configFichier.setTailleListe(50);
    configFichier.setTauxMinLignesOK(0);
    configFichier.setTauxMaxEvolNbLignes(100);
    configFichier.setChemin(REPO);
    configFichier.setCheminCR(REP_CR);
    configGroupeFichier.getConfigFichier().add(configFichier);

    //BL100
    bl100(typeReferentiel, configGroupeFichier);

    //BL200
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createGestionReferentiel(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    //BL300
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createCouvertureCuivre(EasyMock.isA(Tracabilite.class), EasyMock.isA(List.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), 37));

    //BL200
    Retour retourRes = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "some message res"); //$NON-NLS-1$
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.getListGestionReferentiel(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel))).andReturn(new ConnectorResponse<>(retourRes, null));

    //BL400
    mock_write_CSV();

    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.updateGestionReferentielAddFichierOrigine(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel), EasyMock.isA(FichierOrigine.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    _processInstance = new PP0207_IntegrationReferentiel();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();

    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, typeReferentiel.name()));
    checkResponse(resp, RetourFactory.createOkRetour());
  }

  /**
   * Tests nominal<br/>
   *
   * <b> Entries: </ b> <br/>
   * <b> Expected: </ b> Return OK <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_OK_Fibre() throws Throwable
  {
    TypeReferentiel typeReferentiel = TypeReferentiel.COUV_FTTO;
    ConfigGroupeFichier configGroupeFichier = createConfigGroupeFichier(typeReferentiel);
    ConfigFichier configFichier = new ConfigFichier();
    configFichier.setPattern("COUVERTURE_FTTO_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configFichier.setTailleListe(2);
    configFichier.setTauxMinLignesOK(0);
    configFichier.setTauxMaxEvolNbLignes(100);
    configFichier.setChemin(REPO);
    configFichier.setCheminCR(REP_CR);
    configGroupeFichier.getConfigFichier().add(configFichier);
    ConfigFichier configFichier2 = new ConfigFichier();
    configFichier2.setPattern("COUVERTURE_FTTO2_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configFichier2.setTailleListe(2);
    configFichier2.setTauxMinLignesOK(200);
    configFichier2.setTauxMaxEvolNbLignes(0);
    configFichier2.setChemin(REPO);
    configFichier2.setCheminCR(REP_CR);
    configGroupeFichier.getConfigFichier().add(configFichier2);
    configGroupeFichier.setGenerationCR(true);

    //BL100
    bl100(typeReferentiel, configGroupeFichier);

    //BL200
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createGestionReferentiel(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    //BL300
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createCouvertureFtto(EasyMock.isA(Tracabilite.class), EasyMock.isA(List.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), 1));

    //BL200
    Retour retourRes = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "some message res"); //$NON-NLS-1$
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.getListGestionReferentiel(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel))).andReturn(new ConnectorResponse<>(retourRes, null));

    //BL300
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createCouvertureFtto(EasyMock.isA(Tracabilite.class), EasyMock.isA(List.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), 2));

    List<FichierReferentielComposite> listFichComposite = new ArrayList<>();
    List<FichierOrigine> listeFichierOrigine = new ArrayList<>();
    listeFichierOrigine.add(new FichierOrigine("nom_p", "COUV_FTTO", 1, null, "1", "idRef_p", typeReferentiel.name())); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    GestionReferentiel referentiel = new GestionReferentiel("idRef_p", typeReferentiel.name(), EtatReferentiel.ACTIVE); //$NON-NLS-1$
    referentiel.setListeNomFichierOrigine(Arrays.asList("nom_p")); //$NON-NLS-1$
    listFichComposite.add(new FichierReferentielComposite(referentiel, listeFichierOrigine));
    expectGetListGestionReferentiel(RetourFactory.createOkRetour(), RetourFactory.createOkRetour(), typeReferentiel, listFichComposite);

    //BL400
    mock_write_CSV();
    mock_write_CSV();

    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.updateGestionReferentielAddFichierOrigine(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel), EasyMock.isA(FichierOrigine.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.updateGestionReferentielAddFichierOrigine(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel), EasyMock.isA(FichierOrigine.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    _processInstance = new PP0207_IntegrationReferentiel();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();

    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, typeReferentiel.name()));
    checkResponse(resp, RetourFactory.createOkRetour());
  }

  /**
   * Tests nominal<br/>
   *
   * <b> Entries: </ b> <br/>
   * <b> Expected: </ b> Return OK <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_OK_SPIRIT1393() throws Throwable
  {
    TypeReferentiel typeReferentiel = TypeReferentiel.COUV_CUIVRE;
    ConfigGroupeFichier configGroupeFichier = createConfigGroupeFichier(typeReferentiel);
    ConfigFichier configFichier = new ConfigFichier();
    configFichier.setPattern("COUVERTURE_CUIVRE_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configFichier.setTailleListe(50);
    configFichier.setTauxMinLignesOK(0);
    configFichier.setTauxMaxEvolNbLignes(100);
    configFichier.setChemin(REPO);
    configFichier.setCheminCR(REP_CR);
    configGroupeFichier.getConfigFichier().add(configFichier);

    //BL100
    bl100(typeReferentiel, configGroupeFichier);

    //BL200
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createGestionReferentiel(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    //BL300
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createCouvertureCuivre(EasyMock.isA(Tracabilite.class), EasyMock.isA(List.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), 37));

    //BL200
    Retour retourRes = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "some message res"); //$NON-NLS-1$
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.getListGestionReferentiel(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel))).andReturn(new ConnectorResponse<>(retourRes, null));

    //BL400
    mock_write_CSV();

    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.updateGestionReferentielAddFichierOrigine(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel), EasyMock.isA(FichierOrigine.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    _processInstance = new PP0207_IntegrationReferentiel();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();

    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, typeReferentiel.name()));
    checkResponse(resp, RetourFactory.createOkRetour());
  }

  /**
   * Tests nominal<br/>
   *
   * <b> Entries: </ b> <br/>
   * <b> Expected: </ b> Return OK <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0207_IntegrationReferentiel_Test_OK_Tokyo() throws Throwable
  {
    TypeReferentiel typeReferentiel = TypeReferentiel.COUV_TOKYO;
    ConfigGroupeFichier configGroupeFichier = createConfigGroupeFichier(typeReferentiel);
    ConfigFichier configFichier = new ConfigFichier();
    configFichier.setPattern("COUVERTURE_TOKYO_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configFichier.setTailleListe(2);
    configFichier.setTauxMinLignesOK(0);
    configFichier.setTauxMaxEvolNbLignes(100);
    configFichier.setChemin(REPO);
    configFichier.setCheminCR(REP_CR);
    configGroupeFichier.getConfigFichier().add(configFichier);
    ConfigFichier configFichier2 = new ConfigFichier();
    configFichier2.setPattern("COUVERTURE_TOKYO2_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    configFichier2.setTailleListe(2);
    configFichier2.setTauxMinLignesOK(200);
    configFichier2.setTauxMaxEvolNbLignes(0);
    configFichier2.setChemin(REPO);
    configFichier2.setCheminCR(REP_CR);
    configGroupeFichier.getConfigFichier().add(configFichier2);
    configGroupeFichier.setGenerationCR(true);

    //BL100
    bl100(typeReferentiel, configGroupeFichier);

    //BL200
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createGestionReferentiel(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    //BL300
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createCouvertureTokyo(EasyMock.isA(Tracabilite.class), EasyMock.isA(List.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), 1));

    //BL200
    Retour retourRes = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "some message res"); //$NON-NLS-1$
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.getListGestionReferentiel(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel))).andReturn(new ConnectorResponse<>(retourRes, null));

    //BL300
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.createCouvertureTokyo(EasyMock.isA(Tracabilite.class), EasyMock.isA(List.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), 2));

    List<FichierReferentielComposite> listFichComposite = new ArrayList<>();
    List<FichierOrigine> listeFichierOrigine = new ArrayList<>();
    listeFichierOrigine.add(new FichierOrigine("nom_p", "COUV_TOKYO", 1, null, "1", "idRef_p", typeReferentiel.name())); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    GestionReferentiel referentiel = new GestionReferentiel("idRef_p", typeReferentiel.name(), EtatReferentiel.ACTIVE); //$NON-NLS-1$
    referentiel.setListeNomFichierOrigine(Arrays.asList("nom_p")); //$NON-NLS-1$
    listFichComposite.add(new FichierReferentielComposite(referentiel, listeFichierOrigine));
    expectGetListGestionReferentiel(RetourFactory.createOkRetour(), RetourFactory.createOkRetour(), typeReferentiel, listFichComposite);

    //BL400
    mock_write_CSV();
    mock_write_CSV();

    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.updateGestionReferentielAddFichierOrigine(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel), EasyMock.isA(FichierOrigine.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.updateGestionReferentielAddFichierOrigine(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel), EasyMock.isA(FichierOrigine.class))).andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), null));

    _processInstance = new PP0207_IntegrationReferentiel();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();
    mock_BL1200_DeplacerFichier();

    // Execute the process
    Response resp = executeProcess(_processInstance, createRequest(TYPE_REFERENTIEL_PARAMETER, typeReferentiel.name()));
    checkResponse(resp, RetourFactory.createOkRetour());
  }

  /**
   * @param processParams_p
   */
  private void addNominalThreadingParam(ConcurrentHashMap<String, Map<String, String>> processParams_p)
  {
    Map<String, String> params = processParams_p.get(StringConstants.EMPTY_STRING);
    params.put("CUIVRE_THREAD_CORE", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("CUIVRE_THREAD_MAX", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("CUIVRE_THREAD_QUEUE", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("CUIVRE_TIMEOUT_GLOBAL_SEC", "5"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("CUIVRE_TIMEOUT_TASK_SEC", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("FTTO_THREAD_CORE", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("FTTO_THREAD_MAX", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("FTTO_THREAD_QUEUE", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("FTTO_TIMEOUT_GLOBAL_SEC", "5"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("FTTO_TIMEOUT_TASK_SEC", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("TOKYO_THREAD_CORE", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("TOKYO_THREAD_MAX", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("TOKYO_THREAD_QUEUE", "1"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("TOKYO_TIMEOUT_GLOBAL_SEC", "5"); //$NON-NLS-1$ //$NON-NLS-2$
    params.put("TOKYO_TIMEOUT_TASK_SEC", "1"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * @param typeReferentiel_p
   *          typeReferentiel
   * @param configGroupeFichier
   *          configGroupeFichier
   * @throws Throwable
   *           on error
   */
  private void bl100(TypeReferentiel typeReferentiel_p, ConfigGroupeFichier configGroupeFichier) throws Throwable
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);
    addNominalThreadingParam(processParams);

    List<FichierReferentielComposite> listFichComposite = new ArrayList<>();
    List<FichierOrigine> listeFichierOrigine = new ArrayList<>();
    listeFichierOrigine.add(new FichierOrigine("nom_p", "typeFichier_p", 8888, null, "4", "idRef_p", "typeReferentiel_p")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    GestionReferentiel referentiel = new GestionReferentiel("idRef_p", typeReferentiel_p.name(), EtatReferentiel.ACTIVE); //$NON-NLS-1$
    referentiel.setListeNomFichierOrigine(Arrays.asList("nom_p")); //$NON-NLS-1$
    listFichComposite.add(new FichierReferentielComposite(referentiel, listeFichierOrigine));
    ConfigGroupeFichierListe configGroupeFichierListe = new ConfigGroupeFichierListe();
    configGroupeFichierListe.getConfigGroupeFichier().add(configGroupeFichier);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configGroupeFichierListe).getBytes());

    Retour retourRes = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "some message res"); //$NON-NLS-1$
    expectGetListGestionReferentiel(retourRes, null, typeReferentiel_p, listFichComposite);
  }

  /**
   * @param response_p
   *          Expected response
   * @param retour_p
   *          Exopeted Retour
   * @throws Throwable
   *           In case of error
   */
  private void checkResponse(Response response_p, Retour retour_p) throws Throwable
  {
    Retour retour = MarshallTools.unmarshall(Retour.class, response_p.getGenericResponse().getResult());
    Assert.assertEquals(retour_p.getResultat(), retour.getResultat());
    Assert.assertEquals(retour_p.getCategorie(), retour.getCategorie());
    Assert.assertEquals(retour_p.getDiagnostic(), retour.getDiagnostic());
    Assert.assertEquals(retour_p.getLibelle(), retour.getLibelle());
  }

  /**
   * @param typeReferentiel_p
   *          The typeReferentiel
   * @return ConfigFichier
   */
  private ConfigGroupeFichier createConfigGroupeFichier(TypeReferentiel typeReferentiel_p)
  {
    ConfigGroupeFichier configGroupeFichier = new ConfigGroupeFichier();
    configGroupeFichier.setTypeReferentiel(typeReferentiel_p.name());
    configGroupeFichier.setCheminRepTravail(REP_TRAVAIL);
    configGroupeFichier.setCheminRepArchive(REP_ARCHIVE);
    configGroupeFichier.setGenerationCR(true);

    return configGroupeFichier;
  }

  /**
   * @param key_p
   *          The key
   * @param value_p
   *          The value
   * @return process params
   */
  private ConcurrentHashMap<String, Map<String, String>> createProcessParams(String key_p, String value_p)
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    map.put(key_p, value_p);
    processParams.put(StringConstants.EMPTY_STRING, map);
    return processParams;
  }

  /**
   * Create a request with given param
   *
   * @param typePram_p
   *          param key
   * @param typeRef_p
   *          param value
   * @return request
   */
  private Request createRequest(String typePram_p, String typeRef_p)
  {
    List<Parameter> parameters = new ArrayList<>();
    if ((typeRef_p != null) && (typePram_p != null))
    {
      Parameter parameter = new Parameter(typePram_p, typeRef_p);
      parameters.add(parameter);
    }

    IUrlParameters urlParameters = new UrlParameters(parameters);

    IRavelRequest ravelRequest = RavelRequestFactory.getInstance().createRequest();
    ravelRequest.setUrlParameters(urlParameters);

    Request request = new Request("", "", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    RavelRequest.RequestHeader requestHeader = new RavelRequest.RequestHeader();
    requestHeader.setName("X-Source"); //$NON-NLS-1$
    request.setUrlParameters(urlParameters);
    request.getRequestHeader().add(requestHeader);
    return request;
  }

  /**
   * @param processInstance_p
   *          the process
   * @param request_p
   *          the request
   * @return the response
   * @throws Throwable
   *           In case of error
   */
  private Response executeProcess(SpiritProcessSkeleton processInstance_p, Request request_p) throws Throwable
  {
    request_p.setMsgId(ID_CORRELATION);

    PowerMock.replayAll();
    processInstance_p.initializeContext();
    processInstance_p.run(request_p);
    PowerMock.verifyAll();

    return (Response) request_p.getResponse();
  }

  /**
   * Reproduce inverse expects based on list of {@link FichierReferentielComposite}, after migration of the PAD 3006
   * behavior into the process.
   *
   * @param expectedRetourReferentiel_p
   *          expected return on getListGestionReferentiel
   * @param expectedRetourFichierOrigine_p
   *          expected return on first getFichierOrigine
   * @param typeReferentiel_p
   *          typeReferentiel to return
   * @param listFichComposite
   *          list fichierComposite to return
   * @throws RavelException
   *           on error
   */
  private void expectGetListGestionReferentiel(Retour expectedRetourReferentiel_p, Retour expectedRetourFichierOrigine_p, TypeReferentiel typeReferentiel_p, List<FichierReferentielComposite> listFichComposite) throws RavelException
  {
    Map<GestionReferentiel, List<FichierOrigine>> composition = new HashMap<>();
    for (FichierReferentielComposite composite : listFichComposite)
    {
      composition.put(composite.getGestionReferentiel(), composite.getListeFichierOrigine());
    }
    EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
    EasyMock.expect(_resProxyMock.getListGestionReferentiel(EasyMock.isA(Tracabilite.class), EasyMock.eq(typeReferentiel_p)))
        // Mock getListGestionReferentiel response
        .andReturn(new ConnectorResponse<>(expectedRetourReferentiel_p, new ArrayList<>(composition.keySet())));

    if (expectedRetourFichierOrigine_p != null)
    {
      // Mock origine queries
      for (Map.Entry<GestionReferentiel, List<FichierOrigine>> compositionEntry : composition.entrySet())
      {
        for (String nomFichierOrigine : compositionEntry.getKey().getListeNomFichierOrigine())
        {
          Optional<FichierOrigine> origine = compositionEntry.getValue().stream().filter(o -> o.getNom().equals(nomFichierOrigine)).findFirst();
          EasyMock.expect(RESDatabaseProxy.getInstance()).andReturn(_resProxyMock);
          EasyMock.expect(_resProxyMock.getFichierOrigine(EasyMock.isA(Tracabilite.class), EasyMock.eq(nomFichierOrigine)))
              // Mock getFichierOrigine response
              .andReturn(new ConnectorResponse<>(RetourFactory.createOkRetour(), origine.get()));
        }
      }
    }
  }

  /**
   *
   * @throws Throwable
   *           on error
   */
  private void mock_BL1200_DeplacerFichier() throws Throwable
  {
    // mock activity RES1200
    PowerMock.expectNew(BL1200_DeplacerFichierBuilder.class).andReturn(_res1200BuilderMock);
    EasyMock.expect(_res1200BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_res1200BuilderMock);
    EasyMock.expect(_res1200BuilderMock.nomFichier(EasyMock.anyString())).andReturn(_res1200BuilderMock);
    EasyMock.expect(_res1200BuilderMock.repertoireDes(EasyMock.anyString())).andReturn(_res1200BuilderMock);
    EasyMock.expect(_res1200BuilderMock.repertoireSrc(EasyMock.anyString())).andReturn(_res1200BuilderMock);
    EasyMock.expect(_res1200BuilderMock.build()).andReturn(_res1200Builder);
    EasyMock.expect(_res1200Builder.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_res1200Builder.getRetour()).andReturn(RetourFactory.createOkRetour());
  }

  /**
   * mock write CSV
   *
   * @throws Throwable
   *           In case of error
   */
  private void mock_write_CSV() throws Throwable
  {
    PowerMock.expectNew(CSVFileWriter.class, EasyMock.anyObject(File.class), EasyMock.anyObject(Charset.class)).andReturn(_csvFileWriter);
    EasyMock.expect(_csvFileWriter.append(EasyMock.anyObject(CSVLine.class))).andReturn(null);
    EasyMock.expect(FTPProxy.getInstance()).andReturn(_ftpProxyMock);
    EasyMock.expect(_ftpProxyMock.uploadFile(EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString())).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour()));
  }

}
