/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0287;

import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.ALERTE;
import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.CC_ADDRESS;
import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.CODE_ARTICLE_SAP;
import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.FROM_ADDRESS;
import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.LISTE_DIFFUSION;
import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.RAPPORT_ETAT;
import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.RAPPORT_FLUX;
import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.REPERTOIRE_ARCHIVE;
import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.REPERTOIRE_WORK;
import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.REPLY_TO_ADDRESS;
import static com.bytel.spirit.ford.processes.PP0287.PP0287_CreerFichiersKPI.SUIVI_CONSOMMATION_ESIM;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.HttpMethod;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IUrlParameters;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.net.smtp.IMail.MediaType;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.GenericError;
import com.bytel.ravel.services.connector.smtp.SMTPProxy;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.connectors.gdr.GDRProxy;
import com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0287.structs.Action;
import com.bytel.spirit.ford.processes.PP0287.structs.ParameterUri;
import com.bytel.spirit.ford.processes.PP0287.structs.Periodicite;

/**
 *
 * @author asoares
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ GDRProxy.class, SMTPProxy.class })
public class PP0287_CreerFichiersKPI_Test extends EasyMockSupport
{
  /**
   * The profil type constant
   */
  private static final String PROFIL_TYPE = "profilType"; //$NON-NLS-1$

  /**
   * The encarteur constant
   */
  private static final String ENCARTEUR = "encarteur"; //$NON-NLS-1$

  /**
   * The typeComptage constant
   */
  private static final String TYPE_COMPTAGE = "typeComptage"; //$NON-NLS-1$

  /**
   * The ".csv" string that is part of the file name
   */
  private static final String CSV = ".csv"; //$NON-NLS-1$

  /**
   * Work directory
   */
  private static final String TEMP_WORK_DIR = "src/test/tmp/work/"; //$NON-NLS-1$

  /**
   * Archive directory
   */
  private static final String TEMP_ARCHIVE_DIR = "src/test/tmp/archive/"; //$NON-NLS-1$

  /**
   * Email constant
   */
  private static final String EMAIL = "xxxx@bouyguestelecom.fr"; //$NON-NLS-1$

  /**
   * SPRING Context
   */
  private static ClassPathXmlApplicationContext _context;

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * The liste diffusion constant
   */
  static final String STATISTIQUES_ESIM = "statistiquesEsim"; //$NON-NLS-1$

  /**
   * Closes any used resources.<br/>
   */
  @AfterClass
  public static void close()
  {
    _context.close();
  }

  /**
   * @throws RavelException
   *           RavelException
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    ACManagerUtil.resetACManager();
    _context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    try
    {
      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(LocalDateTime.now());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager is now initialized")); //$NON-NLS-1$
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager instance is already initialized")); //$NON-NLS-1$
    }
  }

  /**
   * The process parameters
   */
  private ConcurrentHashMap<String, Map<String, String>> _processParams;

  /**
   * An instance of {@PP0287_CreerFichiersKPI}
   */
  private PP0287_CreerFichiersKPI _currentProcess;

  /**
   * GDRProxy Mock
   */
  @MockStrict
  private GDRProxy _GDRProxyMock;

  /**
   * SMTPProxy Mock
   */
  @MockStrict
  private SMTPProxy _SMTPProxyMock;

  /**
   * Initialization of tests.
   */
  @Before
  public void beforeTest()
  {
    // context initializatioPn
    _currentProcess = new PP0287_CreerFichiersKPI();
    _currentProcess.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_currentProcess.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(null);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(GDRProxy.class);
    PowerMock.mockStaticStrict(SMTPProxy.class);

    HashMap<String, String> map = new HashMap<String, String>();
    map.put(LISTE_DIFFUSION, EMAIL);
    map.put(REPERTOIRE_WORK, TEMP_WORK_DIR);
    map.put(REPERTOIRE_ARCHIVE, TEMP_ARCHIVE_DIR);
    map.put(FROM_ADDRESS, EMAIL);
    map.put(CC_ADDRESS, EMAIL);
    map.put(REPLY_TO_ADDRESS, EMAIL);
    _processParams = ProcessManager.getInstance().getProcessParams();
    _processParams.put(StringConstants.EMPTY_STRING, map);
  }

  /**
   * Delete all files created in the work and archive directories.
   */
  @After
  public void deleteFiles()
  {
    File workDir = new File(TEMP_WORK_DIR);
    File archiveDir = new File(TEMP_ARCHIVE_DIR);

    File[] listOfFiles = workDir.listFiles();
    File[] listArchivedFiles = archiveDir.listFiles();

    for (File file : listOfFiles)
    {
      file.delete();
    }

    for (File file : listArchivedFiles)
    {
      file.delete();
    }
  }

  /**
   * Nominal test case.<br/>
   * Tests if the email is sent and the files are moved to the archive folder.<br/>
   *
   * <b>Entrees:</b>Action=Envoie<br/>
   * <b>Attendu:</b>response.errorCode=ErrorCode.OK_00204<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_001() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.ENVOIE, Periodicite.DATE_COURANTE));

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    File workDir = new File(TEMP_WORK_DIR);
    workDir.mkdirs();
    File fileRapport = new File(workDir, RAPPORT_ETAT + DateTimeFormatPattern.yyyyMMdd.format(DateTimeManager.getInstance().now()) + ".csv"); //$NON-NLS-1$
    fileRapport.createNewFile();

    //Call SMTPProxy
    ConnectorResponse<Boolean, GenericError<Integer>> sendMailResp = new ConnectorResponse<>(true, null);

    EasyMock.expect(SMTPProxy.getInstance()).andReturn(_SMTPProxyMock);
    EasyMock.expect(_SMTPProxyMock.sendMail(_tracabilite.getIdCorrelationSpirit(), EMAIL, EMAIL, EMAIL, EMAIL, SUIVI_CONSOMMATION_ESIM, StringConstants.EMPTY_STRING, fileRapport.getAbsolutePath(), MediaType.TEXT_CSV)).andReturn(sendMailResp);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);
    Response expected = new Response(ErrorCode.OK_00204, response);

    PowerMock.verifyAll();

    assertNull(result);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * Test if OK when there are no files to send.<br/>
   *
   * <b>Entrees:</b>Action=Envoie<br/>
   * <b>Attendu:</b>response.errorCode=ErrorCode.OK_00204<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_002() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.ENVOIE, Periodicite.DATE_COURANTE));

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);
    Response expected = new Response(ErrorCode.OK_00204, response);

    PowerMock.verifyAll();

    assertNull(result);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * Nominal test case.<br/>
   * Tests if the file RapportEtat is created with several lines and if the null properties appear as empty string.<br/>
   * Tests if etatEsim="en commande" when profilType="etatCourantCommandee".<br/>
   * Tests if etatEsim="disponible" when profilType="etatCourantDisponible".<br/>
   *
   * <b>Entrees:</b>Action=Extraction; Periodicite=Date Courant<br/>
   * <b>Attendu:</b>response.errorCode=ErrorCode.OK_00204<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_003() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.EXTRACTION, Periodicite.DATE_COURANTE));

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    StatistiqueEsim statistiqueEsim1 = new StatistiqueEsim(DateTimeTools.toDate(DateTimeManager.getInstance().now()), "etatCourantCommandee", 123456789L, "11.11", CODE_ARTICLE_SAP, PROFIL_TYPE, ENCARTEUR, 2, ALERTE); //$NON-NLS-1$ //$NON-NLS-2$
    StatistiqueEsim statistiqueEsim2 = new StatistiqueEsim(DateTimeTools.toDate(DateTimeManager.getInstance().now()), TYPE_COMPTAGE, 123456789L, "22.22", CODE_ARTICLE_SAP, null, ENCARTEUR, 0, ALERTE); //$NON-NLS-1$
    StatistiqueEsim statistiqueEsim3 = new StatistiqueEsim(DateTimeTools.toDate(DateTimeManager.getInstance().now()), TYPE_COMPTAGE, null, "33.33", CODE_ARTICLE_SAP, null, ENCARTEUR, 0, ALERTE); //$NON-NLS-1$
    StatistiqueEsim statistiqueEsim4 = new StatistiqueEsim(DateTimeTools.toDate(DateTimeManager.getInstance().now()), "etatCourantDisponible", 123456789L, "44.44", CODE_ARTICLE_SAP, PROFIL_TYPE, ENCARTEUR, 0, ALERTE); //$NON-NLS-1$ //$NON-NLS-2$

    List<StatistiqueEsim> statistiquesEsim = new ArrayList<>();
    statistiquesEsim.add(statistiqueEsim1);
    statistiquesEsim.add(statistiqueEsim2);
    statistiquesEsim.add(statistiqueEsim3);
    statistiquesEsim.add(statistiqueEsim4);

    //Call GDRProxy
    ConnectorResponse<List<StatistiqueEsim>, Retour> statistiquesEsimResp = new ConnectorResponse<>(statistiquesEsim, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.getStatistiquesEsim(_tracabilite, Periodicite.DATE_COURANTE.value())).andReturn(statistiquesEsimResp);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);
    Response expected = new Response(ErrorCode.OK_00204, response);

    PowerMock.verifyAll();

    File workDir = new File(TEMP_WORK_DIR);
    File[] listOfFiles = workDir.listFiles();

    for (File file : listOfFiles)
    {
      assertTrue(file.getName().startsWith(RAPPORT_ETAT));
      assertTrue(file.getName().endsWith(CSV));
    }

    assertNull(result);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * Nominal test case.<br/>
   * Tests if the file RapportFlux is created with several lines and if the null properties appear as empty string.<br/>
   * Tests if etatEsim="en commande" when profilType="etatChangementCommandee".<br/>
   * Tests if etatEsim="disponible" when profilType="etatChangementDisponible".<br/>
   *
   * <b>Entrees:</b>Action=Extraction; Periodicite=CHANGEMENT_ETAT_MOIS<br/>
   * <b>Attendu:</b>response.errorCode=ErrorCode.OK_00204<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_004() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.EXTRACTION, Periodicite.CHANGEMENT_ETAT_MOIS));

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    StatistiqueEsim statistiqueEsim1 = new StatistiqueEsim(DateTimeTools.toDate(DateTimeManager.getInstance().now()), "etatChangementCommandee", 123456789L, "11.11", CODE_ARTICLE_SAP, PROFIL_TYPE, ENCARTEUR, 2, ALERTE); //$NON-NLS-1$ //$NON-NLS-2$
    StatistiqueEsim statistiqueEsim2 = new StatistiqueEsim(DateTimeTools.toDate(DateTimeManager.getInstance().now()), TYPE_COMPTAGE, 123456789L, "22.22", CODE_ARTICLE_SAP, null, ENCARTEUR, 0, ALERTE); //$NON-NLS-1$
    StatistiqueEsim statistiqueEsim3 = new StatistiqueEsim(DateTimeTools.toDate(DateTimeManager.getInstance().now()), TYPE_COMPTAGE, null, "33.33", CODE_ARTICLE_SAP, null, ENCARTEUR, 0, ALERTE); //$NON-NLS-1$
    StatistiqueEsim statistiqueEsim4 = new StatistiqueEsim(DateTimeTools.toDate(DateTimeManager.getInstance().now()), "etatChangementDisponible", 123456789L, "44.44", CODE_ARTICLE_SAP, PROFIL_TYPE, ENCARTEUR, 0, ALERTE); //$NON-NLS-1$ //$NON-NLS-2$

    List<StatistiqueEsim> statistiquesEsim = new ArrayList<>();
    statistiquesEsim.add(statistiqueEsim1);
    statistiquesEsim.add(statistiqueEsim2);
    statistiquesEsim.add(statistiqueEsim3);
    statistiquesEsim.add(statistiqueEsim4);

    //Call GDRProxy
    ConnectorResponse<List<StatistiqueEsim>, Retour> statistiquesEsimResp = new ConnectorResponse<>(statistiquesEsim, RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.getStatistiquesEsim(_tracabilite, Periodicite.CHANGEMENT_ETAT_MOIS.value())).andReturn(statistiquesEsimResp);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);
    Response expected = new Response(ErrorCode.OK_00204, response);

    PowerMock.verifyAll();

    File workDir = new File(TEMP_WORK_DIR);
    File[] listOfFiles = workDir.listFiles();

    for (File file : listOfFiles)
    {
      assertTrue(file.getName().startsWith(RAPPORT_FLUX));
      assertTrue(file.getName().substring(12, 18).length() == 6);

      assertTrue(file.getName().endsWith(CSV));
    }

    assertNull(result);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * Tests if NOK when the Action uri parameter is invalid.<br/>
   *
   * <b>Entrees:</b>Action uri parameter non-existent<br/>
   * <b>Attendu:</b>Retour=NOK, CAT4, DONNEE_INVALIDE<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_005() throws Throwable
  {
    Request request = prepareRequest();

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, result.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, result.getCategorie());
    Assert.assertEquals(IMegConsts.DONNEE_INVALIDE, result.getDiagnostic());
  }

  /**
   * Tests if NOK when the Periodicite uri parameter is invalid.<br/>
   *
   * <b>Entrees:</b>Action=Extraction; Periodicite uri parameter non-existent<br/>
   * <b>Attendu:</b>Retour=NOK, CAT4, DONNEE_INVALIDE<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_006() throws Throwable
  {
    List<Parameter> parameters = new ArrayList<>();
    Parameter parameter = new Parameter(ParameterUri.ACTION.name(), Action.EXTRACTION.value());
    parameters.add(parameter);
    IUrlParameters urlParameters = new UrlParameters(parameters);

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, result.getResultat());
    Assert.assertEquals(IMegConsts.CAT4, result.getCategorie());
    Assert.assertEquals(IMegConsts.DONNEE_INVALIDE, result.getDiagnostic());
  }

  /**
   * Tests if NOK when when liste diffusion process parameter is invalid.<br/>
   *
   * <b>Entrees:</b>listeDiffusion non-existent<br/>
   * <b>Attendu:</b>Retour=NOK, CAT1<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_007() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.ENVOIE, Periodicite.DATE_COURANTE));

    _processParams.get(StringConstants.EMPTY_STRING).put(LISTE_DIFFUSION, StringConstants.EMPTY_STRING);

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, result.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, result.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, result.getDiagnostic());
  }

  /**
   * Tests if NOK when fromAddress process parameter is invalid.<br/>
   *
   * <b>Entrees:</b>fromAddress non-existent<br/>
   * <b>Attendu:</b>Retour=NOK, CAT1<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_008() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.ENVOIE, Periodicite.DATE_COURANTE));

    _processParams.get(StringConstants.EMPTY_STRING).put(FROM_ADDRESS, StringConstants.EMPTY_STRING);

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, result.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, result.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, result.getDiagnostic());
  }

  /**
   * Tests if NOK when repertoireWork process parameter is invalid.<br/>
   *
   * <b>Entrees:</b>repertoireWork non-existent<br/>
   * <b>Attendu:</b>Retour=NOK, CAT1<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_009() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.ENVOIE, Periodicite.DATE_COURANTE));

    _processParams.get(StringConstants.EMPTY_STRING).put(REPERTOIRE_WORK, StringConstants.EMPTY_STRING);

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, result.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, result.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, result.getDiagnostic());
  }

  /**
   * Tests if a "/" is added to the end of the repertoireWork path when he does not have it.<br/>
   *
   * <b>Entrees:</b>repertoireWork without "/"<br/>
   * <b>Attendu:</b>Retour=NOK, CAT1<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_010() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.ENVOIE, Periodicite.DATE_COURANTE));

    _processParams.get(StringConstants.EMPTY_STRING).put(REPERTOIRE_WORK, "src/test/tmp/work"); //$NON-NLS-1$

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);
    Response expected = new Response(ErrorCode.OK_00204, response);

    PowerMock.verifyAll();

    assertNull(result);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * Tests if NOK when repertoireArchive process parameter is invalid.<br/>
   *
   * <b>Entrees:</b>repertoireArchive non-existent<br/>
   * <b>Attendu:</b>Retour=NOK, CAT1<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_011() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.ENVOIE, Periodicite.DATE_COURANTE));

    _processParams.get(StringConstants.EMPTY_STRING).put(REPERTOIRE_ARCHIVE, StringConstants.EMPTY_STRING);

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);

    PowerMock.verifyAll();

    Assert.assertEquals(StringConstants.NOK, result.getResultat());
    Assert.assertEquals(IMegConsts.CAT1, result.getCategorie());
    Assert.assertEquals(IMegConsts.CONFIGURATION_INVALIDE, result.getDiagnostic());
  }

  /**
   * Tests if a "/" is added to the end of the repertoireArchive path when he does not have it.<br/>
   *
   * <b>Entrees:</b>repertoireArchive without "/"<br/>
   * <b>Attendu:</b>Retour=NOK, CAT1<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_012() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.ENVOIE, Periodicite.DATE_COURANTE));

    _processParams.get(StringConstants.EMPTY_STRING).put(REPERTOIRE_ARCHIVE, "src/test/tmp/archive"); //$NON-NLS-1$

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);
    Response expected = new Response(ErrorCode.OK_00204, response);

    PowerMock.verifyAll();

    assertNull(result);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * Test if NOK when GDRProxy fails.<br/>
   *
   * <b>Entrees:</b>GDRProxy.getStatistiquesEsim = NOK<br/>
   * <b>Attendu:</b>response.errorCode=ErrorCode.KO_00500; Retour=NOK, CAT-10, TRAITEMENT_ARRETE<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_013() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.EXTRACTION, Periodicite.DATE_COURANTE));

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    //Call GDRProxy
    ConnectorResponse<List<StatistiqueEsim>, Retour> statistiquesEsimResp = new ConnectorResponse<>(new ArrayList<>(), RetourFactory.createNOK(IMegConsts.CATEGORIE, IMegConsts.DIAGNOSTIC, IMegConsts.LIBELLE));

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.getStatistiquesEsim(_tracabilite, Periodicite.DATE_COURANTE.value())).andReturn(statistiquesEsimResp);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Response expected = new Response(ErrorCode.KO_00500, response);

    PowerMock.verifyAll();

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expected.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expected.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * Test if NOK when a created file already exists.<br/>
   *
   * <b>Entrees:</b>Action=Extraction; Periodicite=CHANGEMENT_ETAT_MOIS<br/>
   * <b>Attendu:</b>response.errorCode=ErrorCode.KO_00500; Retour=NOK, CAT-1, CREATION_FICHIER_INVALIDE<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0287_CreerFichiersKPI_Test_014() throws Throwable
  {
    IUrlParameters urlParameters = new UrlParameters(prepareUriParameters(Action.EXTRACTION, Periodicite.CHANGEMENT_ETAT_MOIS));

    Request request = prepareRequest();
    request.setUrlParameters(urlParameters);

    File workDir = new File(TEMP_WORK_DIR);
    workDir.mkdirs();
    File fileRapport = new File(workDir, RAPPORT_FLUX + DateTimeFormatPattern.yyyyMMdd.format(DateTimeManager.getInstance().now()).substring(0, 6) + ".csv"); //$NON-NLS-1$
    fileRapport.createNewFile();

    //Call GDRProxy
    ConnectorResponse<List<StatistiqueEsim>, Retour> statistiquesEsimResp = new ConnectorResponse<>(new ArrayList<>(), RetourFactory.createOkRetour());

    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.getStatistiquesEsim(_tracabilite, Periodicite.CHANGEMENT_ETAT_MOIS.value())).andReturn(statistiquesEsimResp);

    PowerMock.replayAll();

    _currentProcess.run(request);

    Response response = (Response) request.getResponse();
    Retour result = prepareResponse(response);
    Response expectedResp = new Response(ErrorCode.KO_00500, response);

    PowerMock.verifyAll();

    assertEquals(IMegConsts.CAT1, result.getCategorie());
    assertEquals(IMegSpiritConsts.CREATION_FICHIER_INVALIDE, result.getDiagnostic());
    assertEquals(expectedResp.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expectedResp.getGenericResponse().getDataType(), request.getResponse().getGenericResponse().getDataType());
    assertEquals(expectedResp.getGenericResponse().getResponseHeader(), request.getResponse().getGenericResponse().getResponseHeader());
    assertEquals(expectedResp.getGenericResponse().getResult(), request.getResponse().getGenericResponse().getResult());
  }

  /**
   * Prepares the request.
   *
   * @return {@link Request}
   * @throws RavelException
   *           Exception
   */
  private Request prepareRequest() throws RavelException
  {
    Request request = new Request(_currentProcess.getName(), _currentProcess.getMsgId(), _currentProcess.getIdProcess());
    request.setHttpMethod(HttpMethod.POST);
    request.setMsgId(_tracabilite.getIdCorrelationSpirit());
    return request;
  }

  /**
   * Prepares the response.
   *
   * @param response_p
   *          the response value
   * @return {@link Retour}
   * @throws RavelException
   *           in case error
   */
  private Retour prepareResponse(final Response response_p) throws RavelException
  {
    final Retour response = GsonTools.getIso8601Sec().fromJson(response_p.getGenericResponse().getResult(), Retour.class);

    return response;
  }

  /**
   * Prepares the uri parameters.
   *
   * @param action_p
   *          the action parameter uri
   * @param periodicite_p
   *          the periodicite parameter uri
   * @return A list of {@link Parameter}
   */
  private List<Parameter> prepareUriParameters(Action action_p, Periodicite periodicite_p)
  {
    List<Parameter> parameters = new ArrayList<>();
    Parameter parameter = new Parameter(ParameterUri.ACTION.name(), action_p.value());
    parameters.add(parameter);
    parameter = new Parameter(ParameterUri.PERIODICITE.name(), periodicite_p.value());
    parameters.add(parameter);

    return parameters;
  }
}
