/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.processes.PP0239;

import static org.junit.Assert.assertEquals;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.csv.CSVFileWriter;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IRavelRequest;
import com.bytel.ravel.common.factory.request.IUrlParameters;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.RavelRequestFactory;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.ftp.FTPProxy;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.eligprev.config.ConfigRepertoireSource;
import com.bytel.spirit.common.eligprev.config.Pattern;
import com.bytel.spirit.common.eligprev.config.RepertoireSource;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.ford.processes.Messages;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * @author mlamy
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PP0239_TransfertReferentiel.class, DateTimeManager.class, Files.class, FTPProxy.class, Messages.class, Path.class, Paths.class, ProcessManager.class })
public class PP0239_TransfertReferentielTest extends EasyMockSupport
{
  /**
   * Factory to generate beans
   */
  private static PodamFactory _podam;

  /**
   * ConfigGroupeFichier Param
   */
  private static final String CONF_PARAM = "FILE_PATH"; //$NON-NLS-1$

  /**
   * ID_CORRELATION
   */
  private static final String ID_CORRELATION = "PP0239"; //$NON-NLS-1$

  /**
   * NOM_CONNECTEUR
   */
  private static final String NOM_CONNECTEUR = "PP0239_FTPConnector"; //$NON-NLS-1$

  /**
   * REP_ECHEC
   */
  private static final String REP_ECHEC = "src\\test\\resources\\repEchec"; //$NON-NLS-1$

  /**
   * REP_TRAVAIL
   */
  private static final String REP_TRAVAIL = "src\\test\\resources\\repTravail"; //$NON-NLS-1$

  /**
   * CHEMIN
   */
  private static final String REPO = "/in"; //$NON-NLS-1$

  /**
   * SOURCE
   */
  private static final String SOURCE = "SOURCE"; //$NON-NLS-1$

  /**
   * ConfigRepertoireSource Param
   */
  private static final String PARAM_FILE_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * The constant for PP0239.PasDeTmpFilesExistant message
   */
  private static final String MESSAGE_NO_TMP_FILES_EXISTENT = Messages.getString("PP0239.PasDeTmpFilesExistant"); //$NON-NLS-1$

  /**
   * The constant for PP0239.SeulementTmpFilesExistant message
   */
  private static final String MESSAGE_ONLY_TMP_FILES_EXISTENT = Messages.getString("PP0239.SeulementTmpFilesExistant"); //$NON-NLS-1$

  /**
   * The constant for PP0239.TmpEtAutresFilesExistant message
   */
  private static final String MESSAGE_BOTH_TMP_AND_OTHER_FILES_EXISTENT = Messages.getString("PP0239.TmpEtAutresFilesExistant"); //$NON-NLS-1$

  /**
   * The constant for PP0239.RecuperationListeFichiersImpossible message
   */
  private static final String MESSAGE_RECUPERATION_LISTE_FICHIERS_IMPOSSIBLE = Messages.getString("PP0239.RecuperationListeFichiersImpossible"); //$NON-NLS-1$

  /**
   * The constant for PP0239.ConfigurationInvalide message
   */
  private static final String MESSAGE_CONFIGURATION_INVALIDE = Messages.getString("PP0239.ConfigurationInvalide"); //$NON-NLS-1$

  /**
   * The constant for PP0239.NoParam message
   */
  private static final String MESSAGE_NO_PARAMETER = Messages.getString("PP0239.NoParam"); //$NON-NLS-1$

  /**
   * The constant for PP0239.FileError message
   */
  private static final String MESSAGE_FILE_ERROR = Messages.getString("PP0239.FileError"); //$NON-NLS-1$

  /**
   * Initialization method
   */
  @BeforeClass
  public static void init()
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    _podam = new PodamFactoryImpl();
  }

  /**
   * Mock de {@link DateTimeManager}
   */
  @MockStrict
  private DateTimeManager _dateTimeManagerMock;

  /**
   * Mock de {@link FTPProxy}
   */
  @MockStrict
  private FTPProxy _ftpProxyMock;

  /**
   * Mock de {@link Path}
   */
  @MockNice
  private Path _path;

  /**
   * Mock de {@link CSVFileWriter}
   */
  @MockNice
  private CSVFileWriter _csvFileWriter;

  /**
   * Instance of {@link PP0239_TransfertReferentiel}
   */
  private PP0239_TransfertReferentiel _processInstance;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  private ProcessManager _processManager;

  /**
   * Clear configuration
   */
  @Before
  public void beforeTest()
  {
    // désactivation du cache podam
    _podam.getStrategy().setMemoization(false);

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // on indique que la classe de log sera mocké de façon statique dans le test à venir
    PowerMock.mockStaticNice(Path.class);
    PowerMock.mockStaticNice(Paths.class);
    PowerMock.mockStaticNice(Files.class);

    // On initialise toutes les classes à mocker comportant un appel à un eméthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et le getInstance)
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStaticStrict(DateTimeManager.class);
    PowerMock.mockStaticStrict(FTPProxy.class);
  }

  /**
   * Tests failed entry parameter check <br/>
   *
   * <b> Entries: </ b> Invalid entry data. Unmarshall fails. <br/>
   * <b> Expected: </ b> Return NOK (CAT10, TRAITEMENT_ARRETE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_KO_001() throws Throwable
  {
    //Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "ExceptionMessage"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(CONF_PARAM, CONF_PARAM);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams);
    EasyMock.expect(Paths.get(CONF_PARAM)).andReturn(_path);
    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(null); //ERROR

    _processInstance = new PP0239_TransfertReferentiel();

    try
    {
      // Execute the process
      executeProcess(_processInstance);
    }
    catch (RavelException ravelException)
    {
      // Asserts
      assertEquals(ExceptionType.INTERNAL_ERROR, ravelException.getExceptionType());
      assertEquals(ErrorCode.KO_00000, ravelException.getErrorCode());
      assertEquals(MessageFormat.format(MESSAGE_FILE_ERROR, PARAM_FILE_PATH), ravelException.getMessage());
      assertEquals(MessageFormat.format(MESSAGE_FILE_ERROR, PARAM_FILE_PATH), ravelException.getSourceComponentName());
    }
  }

  /**
   * Tests entry parameter null<br/>
   *
   * <b> Entries: </ b> Invalid entry data. Unmarshall fails. <br/>
   * <b> Expected: </ b> Return NOK (CAT10, TRAITEMENT_ARRETE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_KO_002() throws Throwable
  {
    //Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, "ExceptionMessage"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager);
    String confParameterErronee = "confParameterErronee"; //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(confParameterErronee, confParameterErronee);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams);

    _processInstance = new PP0239_TransfertReferentiel();

    try
    {
      // Execute the process
      executeProcess(_processInstance);
    }
    catch (RavelException ravelException)
    {
      // Asserts
      assertEquals(ExceptionType.INTERNAL_ERROR, ravelException.getExceptionType());
      assertEquals(ErrorCode.KO_00000, ravelException.getErrorCode());
      assertEquals(MessageFormat.format(MESSAGE_NO_PARAMETER, PARAM_FILE_PATH), ravelException.getMessage());
      assertEquals(MessageFormat.format(MESSAGE_NO_PARAMETER, PARAM_FILE_PATH), ravelException.getSourceComponentName());
    }
  }

  /**
   * Tests the case when any repertoire source matches the source identifier passed as an input to the process. <br/>
   *
   * <b> Entries: </ b> Invalid data <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_KO_003() throws Throwable
  {
    String wrongSource = "Wrong Source"; //$NON-NLS-1$
    ConfigRepertoireSource configRepertoireSource = createConfigRepertoireSource(1);
    configRepertoireSource.getRepertoireSource().get(0).setSource(wrongSource);
    prepareProcess(CONF_PARAM, CONF_PARAM, configRepertoireSource);
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MESSAGE_CONFIGURATION_INVALIDE);
    _processInstance = new PP0239_TransfertReferentiel();

    // Execute the process
    Response resp = executeProcess(_processInstance);

    // Asserts
    Retour retourUnmarshalled = checkResponse(resp, expected);
    assertEquals(expected.getLibelle(), retourUnmarshalled.getLibelle());
  }

  /**
   * Tests the case when the repertoire source has a null field and so is invalid. <br/>
   *
   * <b> Entries: </ b> Invalid data <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_KO_004() throws Throwable
  {
    ConfigRepertoireSource configRepertoireSource = createConfigRepertoireSource(1);
    configRepertoireSource.getRepertoireSource().get(0).setNomConnecteur(null);
    prepareProcess(CONF_PARAM, CONF_PARAM, configRepertoireSource);
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MESSAGE_CONFIGURATION_INVALIDE);
    _processInstance = new PP0239_TransfertReferentiel();

    // Execute the process
    Response resp = executeProcess(_processInstance);

    // Asserts
    Retour retourUnmarshalled = checkResponse(resp, expected);
    assertEquals(expected.getLibelle(), retourUnmarshalled.getLibelle());
  }

  /**
   * Tests the case when the repertoire source has a pattern that has a null field and so is invalid. <br/>
   *
   * <b> Entries: </ b> Invalid data <br/>
   * <b> Expected: </ b> Return NOK (CAT4, CONFIGURATION_INVALIDE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_KO_005() throws Throwable
  {
    ConfigRepertoireSource configRepertoireSource = createConfigRepertoireSource(1);
    configRepertoireSource.getRepertoireSource().get(0).getPattern().get(0).setPattern(null);
    prepareProcess(CONF_PARAM, CONF_PARAM, configRepertoireSource);
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MESSAGE_CONFIGURATION_INVALIDE);
    _processInstance = new PP0239_TransfertReferentiel();

    // Execute the process
    Response resp = executeProcess(_processInstance);

    // Asserts
    Retour retourUnmarshalled = checkResponse(resp, expected);
    assertEquals(expected.getLibelle(), retourUnmarshalled.getLibelle());
  }

  /**
   * Test the case when filenames recovery from repository is impossible <br/>
   *
   * <b> Entries: </ b> Invalid data <br/>
   * <b> Expected: </ b> Return NOK (CAT1, LECTURE_INDISPONIBLE) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_KO_006() throws Throwable
  {
    ConfigRepertoireSource configRepertoireSource = createConfigRepertoireSource(1);
    prepareProcess(CONF_PARAM, CONF_PARAM, configRepertoireSource);
    Retour expected = RetourFactory.createRetour(StringConstants.NOK, IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_RECUPERATION_LISTE_FICHIERS_IMPOSSIBLE);
    _processInstance = new PP0239_TransfertReferentiel();

    mock_BL100_KO_getFileNameList(expected);

    // Execute the process
    Response resp = executeProcess(_processInstance);

    // Asserts
    Retour retourUnmarshalled = checkResponse(resp, expected);
    assertEquals(expected.getLibelle(), retourUnmarshalled.getLibelle());
  }

  /**
   * Tests the case where there are .txt files in the repository that are supposed to be downloaded. Besides that, there
   * are .log files that are not supposed to be downloaded, because there is no pattern in the repertoire source that
   * indicates that. There are no .tmp files. Should return NOK. pattern. <br/>
   *
   * <b> Entries: </ b> Valid data <br/>
   * <b> Expected: </ b> Return NOK (CAT6, TRAITEMENT_PARTIEL) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_KO_007() throws Throwable
  {
    ConfigRepertoireSource configRepertoireSource = createConfigRepertoireSource(1);
    prepareProcess(CONF_PARAM, CONF_PARAM, configRepertoireSource);
    String sourceIdentifier = configRepertoireSource.getRepertoireSource().get(0).getSource();
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.TRAITEMENT_PARTIEL, MessageFormat.format(MESSAGE_NO_TMP_FILES_EXISTENT, sourceIdentifier));
    _processInstance = new PP0239_TransfertReferentiel();
    List<String> fileNameList = new ArrayList<>();
    buildFileNameList(fileNameList, "NoTmpDifferentPatterns"); //$NON-NLS-1$

    // Mock getFileName FTP connector method
    mock_BL100_OK_getFileNameList(fileNameList);

    // First file .txt with a matching pattern (supposed to downloaded). So we download it to the local working repository and remove it from the source repository
    EasyMock.expect(_ftpProxyMock.downloadFile(NOM_CONNECTEUR, ID_CORRELATION, REPO, fileNameList.get(0), REP_TRAVAIL)).andReturn(new ConnectorResponse<>(null, RetourFactory.createOkRetour()));
    EasyMock.expect(_ftpProxyMock.removeFile(NOM_CONNECTEUR, ID_CORRELATION, configRepertoireSource.getRepertoireSource().get(0).getCheminSource() + "/" + fileNameList.get(0))).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour())); //$NON-NLS-1$

    // Second file .log without a matching pattern (not supposed to downloaded). So we download it to the local failure repository and remove it from the source repository
    EasyMock.expect(_ftpProxyMock.downloadFile(NOM_CONNECTEUR, ID_CORRELATION, REPO, fileNameList.get(1), REP_TRAVAIL)).andReturn(new ConnectorResponse<>(null, RetourFactory.createOkRetour()));
    EasyMock.expect(_ftpProxyMock.removeFile(NOM_CONNECTEUR, ID_CORRELATION, configRepertoireSource.getRepertoireSource().get(0).getCheminSource() + "/" + fileNameList.get(1))).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour())); //$NON-NLS-1$

    // Third file .txt with a matching pattern (supposed to downloaded). So we download it to the local working repository and remove it from the source repository
    EasyMock.expect(_ftpProxyMock.downloadFile(NOM_CONNECTEUR, ID_CORRELATION, REPO, fileNameList.get(2), REP_ECHEC)).andReturn(new ConnectorResponse<>(null, RetourFactory.createOkRetour()));
    EasyMock.expect(_ftpProxyMock.removeFile(NOM_CONNECTEUR, ID_CORRELATION, configRepertoireSource.getRepertoireSource().get(0).getCheminSource() + "/" + fileNameList.get(2))).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour())); //$NON-NLS-1$

    // Fourth file .log without a matching pattern (not supposed to be downloaded). So we download it to the local failure repository and remove it from the source repository
    EasyMock.expect(_ftpProxyMock.downloadFile(NOM_CONNECTEUR, ID_CORRELATION, REPO, fileNameList.get(3), REP_ECHEC)).andReturn(new ConnectorResponse<>(null, RetourFactory.createOkRetour()));
    EasyMock.expect(_ftpProxyMock.removeFile(NOM_CONNECTEUR, ID_CORRELATION, configRepertoireSource.getRepertoireSource().get(0).getCheminSource() + "/" + fileNameList.get(3))).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour())); //$NON-NLS-1$

    // Execute the process
    Response resp = executeProcess(_processInstance);

    // Asserts
    Retour retourUnmarshalled = checkResponse(resp, expected);
    assertEquals(expected.getLibelle(), retourUnmarshalled.getLibelle());
  }

  /**
   * Tests the case where there are .txt files in the repository that are supposed to be downloaded. Besides that, there
   * are only .tmp files that are not supposed to be downloaded, because there is no pattern in the repertoire source
   * that indicates that. Should return NOK. pattern. <br/>
   *
   * <b> Entries: </ b> Valid data <br/>
   * <b> Expected: </ b> Return NOK (CAT6, TRAITEMENT_PARTIEL) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_KO_008() throws Throwable
  {
    ConfigRepertoireSource configRepertoireSource = createConfigRepertoireSource(1);
    prepareProcess(CONF_PARAM, CONF_PARAM, configRepertoireSource);
    String sourceIdentifier = configRepertoireSource.getRepertoireSource().get(0).getSource();
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.TRAITEMENT_PARTIEL, MessageFormat.format(MESSAGE_BOTH_TMP_AND_OTHER_FILES_EXISTENT, sourceIdentifier));
    _processInstance = new PP0239_TransfertReferentiel();
    List<String> fileNameList = new ArrayList<>();
    buildFileNameList(fileNameList, "WithTmpAndOtherPatternOnly"); //$NON-NLS-1$

    // Mock getFileName FTP connector method
    mock_BL100_OK_getFileNameList(fileNameList);

    // First file .csv with a no matching pattern (supposed to downloaded). So we download it to the local failure repository and remove it from the source repository
    EasyMock.expect(_ftpProxyMock.downloadFile(NOM_CONNECTEUR, ID_CORRELATION, REPO, fileNameList.get(0), REP_ECHEC)).andReturn(new ConnectorResponse<>(null, RetourFactory.createOkRetour()));
    EasyMock.expect(_ftpProxyMock.removeFile(NOM_CONNECTEUR, ID_CORRELATION, configRepertoireSource.getRepertoireSource().get(0).getCheminSource() + "/" + fileNameList.get(0))).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour())); //$NON-NLS-1$

    // Second file .csv with a no matching pattern (supposed to downloaded). So we download it to the local failure repository and remove it from the source repository
    EasyMock.expect(_ftpProxyMock.downloadFile(NOM_CONNECTEUR, ID_CORRELATION, REPO, fileNameList.get(1), REP_ECHEC)).andReturn(new ConnectorResponse<>(null, RetourFactory.createOkRetour()));
    EasyMock.expect(_ftpProxyMock.removeFile(NOM_CONNECTEUR, ID_CORRELATION, configRepertoireSource.getRepertoireSource().get(0).getCheminSource() + "/" + fileNameList.get(1))).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour())); //$NON-NLS-1$

    // The other two files are .tmp files, so we should not download them from the source repoistory. The only thing to be done is to output a retour that describes that scenario.

    // Execute the process
    Response resp = executeProcess(_processInstance);

    // Asserts
    Retour retourUnmarshalled = checkResponse(resp, expected);
    assertEquals(expected.getLibelle(), retourUnmarshalled.getLibelle());
  }

  /**
   * Tests the case where there are .txt files in the repository that are supposed to be downloaded. Besides that, there
   * are .tmp files that are not supposed to be downloaded, Finally, there are .log files that are not supposed to be
   * downloaded too, because there is no pattern in the repertoire source that indicates that. Should return NOK.
   * pattern. <br/>
   *
   * <b> Entries: </ b> Valid data <br/>
   * <b> Expected: </ b> Return NOK (CAT6, TRAITEMENT_PARTIEL) <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_KO_009() throws Throwable
  {
    ConfigRepertoireSource configRepertoireSource = createConfigRepertoireSource(1);
    prepareProcess(CONF_PARAM, CONF_PARAM, configRepertoireSource);
    String sourceIdentifier = configRepertoireSource.getRepertoireSource().get(0).getSource();
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.TRAITEMENT_PARTIEL, MessageFormat.format(MESSAGE_BOTH_TMP_AND_OTHER_FILES_EXISTENT, sourceIdentifier));
    _processInstance = new PP0239_TransfertReferentiel();
    List<String> fileNameList = new ArrayList<>();
    buildFileNameList(fileNameList, "WithTmpAndOtherPatterns"); //$NON-NLS-1$

    // Mock getFileName FTP connector method
    mock_BL100_OK_getFileNameList(fileNameList);

    // The other two files are .tmp files, so we should not download them from the source repository. The only thing to be done is to output a retour that describes that scenario.

    // First file .csv with no a matching pattern (supposed to downloaded). So we download it to the local failure repository and remove it from the source repository
    EasyMock.expect(_ftpProxyMock.downloadFile(NOM_CONNECTEUR, ID_CORRELATION, REPO, fileNameList.get(2), REP_TRAVAIL)).andReturn(new ConnectorResponse<>(null, RetourFactory.createOkRetour()));
    EasyMock.expect(_ftpProxyMock.removeFile(NOM_CONNECTEUR, ID_CORRELATION, configRepertoireSource.getRepertoireSource().get(0).getCheminSource() + "/" + fileNameList.get(2))).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour())); //$NON-NLS-1$

    // Second file .csv without no a matching pattern (not supposed to downloaded). So we download it to the local failure repository and remove it from the source repository
    EasyMock.expect(_ftpProxyMock.downloadFile(NOM_CONNECTEUR, ID_CORRELATION, REPO, fileNameList.get(3), REP_TRAVAIL)).andReturn(new ConnectorResponse<>(null, RetourFactory.createOkRetour()));
    EasyMock.expect(_ftpProxyMock.removeFile(NOM_CONNECTEUR, ID_CORRELATION, configRepertoireSource.getRepertoireSource().get(0).getCheminSource() + "/" + fileNameList.get(3))).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour())); //$NON-NLS-1$

    // Second file .log without no a matching pattern (not supposed to downloaded). So we download it to the local failure repository and remove it from the source repository
    EasyMock.expect(_ftpProxyMock.downloadFile(NOM_CONNECTEUR, ID_CORRELATION, REPO, fileNameList.get(4), REP_ECHEC)).andReturn(new ConnectorResponse<>(null, RetourFactory.createOkRetour()));
    EasyMock.expect(_ftpProxyMock.removeFile(NOM_CONNECTEUR, ID_CORRELATION, configRepertoireSource.getRepertoireSource().get(0).getCheminSource() + "/" + fileNameList.get(4))).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour())); //$NON-NLS-1$

    //Execute the process
    Response resp = executeProcess(_processInstance);

    // Asserts
    Retour retourUnmarshalled = checkResponse(resp, expected);
    assertEquals(expected.getLibelle(), retourUnmarshalled.getLibelle());
  }

  /**
   * Tests a more complex nominal case where there are three repertoires source and only two of them have a source
   * identifier that matches the source identifier passed as an input to the process. The two repertoires source that
   * have the matching source identifier contain patterns for .txt and .log files. So these are the only patterns that
   * should be moved from the respective source repositories to the working local repositories. The other patterns found
   * in the source repository that don't match the correspondent patterns of the repertoires source should be moved to a
   * well defined failure repository. Nothing should happen to the .tmp files.<br/>
   *
   * <b> Entries: </ b> Valid data <br/>
   * <b> Expected: </ b> Return OK <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_OK_001() throws Throwable
  {
    ConfigRepertoireSource configRepertoireSource = createConfigRepertoireSource(2);

    //We set the second repertoire source to not have a matching source identifier, in order to verify that the code successfully ignores it in all the processing
    configRepertoireSource.getRepertoireSource().get(1).setSource("wrongSourceIdentifier"); //$NON-NLS-1$

    prepareProcess(CONF_PARAM, CONF_PARAM, configRepertoireSource);

    // We get the source identifier of the last repertoire source that originates a NOK, since it is indeed that NOK that will be returned in the end.
    // ALl the other retours NOK will only be logged.
    //String lastIdentifierSource = configRepertoireSource.getRepertoireSource().get(1).getSource();
    //Retour expected = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.TRAITEMENT_PARTIEL, MessageFormat.format(MESSAGE_BOTH_TMP_AND_OTHER_FILES_EXISTENT, lastIdentifierSource));
    Retour expected = RetourFactory.createOkRetour();

    _processInstance = new PP0239_TransfertReferentiel();

    // We build the file name list that contains the file names that correspond to the first repertoire source. Only .txt files are present in this source repository.
    List<String> firstFileNameList = new ArrayList<>();
    String criteriaToBuildFileList = "NoTmpAllSamePattern"; //$NON-NLS-1$
    buildFileNameList(firstFileNameList, criteriaToBuildFileList);

    // Mock getFileName FTP connector method with the the first file name list that corresponds to the first repertoire source.
    EasyMock.expect(_ftpProxyMock.getFileNameList(NOM_CONNECTEUR, ID_CORRELATION, REPO, new ArrayList<>())).andReturn(new ConnectorResponse<>(firstFileNameList, RetourFactory.createOkRetour()));

    // The first repertoire source has a .txt pattern and finds a source repository with only .txt files. All of them should be downloaded to the working local repository.

    // Mock downloadFile and removeFile FTP connector method
    mock_BL100_OK_downloadFile_removeFile(firstFileNameList, REP_TRAVAIL);

    // The second repository source doesn't match the source identifier so it should not be processed at all.

    // The third repository source matches the source identifier, has a .log pattern and finds a repository source with .tmp, .txt, .log and .xml files.

    // Execute the process
    Response resp = executeProcess(_processInstance);

    // Asserts
    Retour retourUnmarshalled = checkResponse(resp, expected);
    assertEquals(expected.getLibelle(), retourUnmarshalled.getLibelle());
  }

  /**
   * Tests the nominal case in which there are 4 files .txt in the remote repository and there is a pattern for the .txt
   * pattern. There is only one repertoire source that matches the source parameter passed as an input to the process.
   * <br/>
   *
   * <b> Entries: </ b> Valid data <br/>
   * <b> Expected: </ b> Return KO <br/>
   *
   * @throws Throwable
   *           In case of error
   */
  @Test
  public void PP0239_TransfertReferentiel_Test_OK_002() throws Throwable
  {
    ConfigRepertoireSource configRepertoireSource = createConfigRepertoireSource(1);
    prepareProcess(CONF_PARAM, CONF_PARAM, configRepertoireSource);
    String lastIdentifierSource = configRepertoireSource.getRepertoireSource().get(0).getSource();
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.TRAITEMENT_PARTIEL, MessageFormat.format(MESSAGE_ONLY_TMP_FILES_EXISTENT, lastIdentifierSource));
    _processInstance = new PP0239_TransfertReferentiel();
    List<String> fileNameList = new ArrayList<>();
    buildFileNameList(fileNameList, "WithTmpOnly"); //$NON-NLS-1$

    //Mock getFileName FTP connector method
    mock_BL100_OK_getFileNameList(fileNameList);

    // The other two files are .tmp files, so we should not download them from the source repoistory. The only thing to be done is to output a retour that describes that scenario.

    // Execute the process
    Response resp = executeProcess(_processInstance);

    // Asserts
    Retour retourUnmarshalled = checkResponse(resp, expected);
    assertEquals(expected.getLibelle(), retourUnmarshalled.getLibelle());
  }

  /**
   * @param configRepertoireSource_p
   *          cobnfiguration de la source
   * @param numberOfRepertoiresSource_p
   *          nombre de sources
   */
  private void buildConfigRepertoireSource(ConfigRepertoireSource configRepertoireSource_p, int numberOfRepertoiresSource_p)
  {
    RepertoireSource repertoireSource = new RepertoireSource();
    repertoireSource.setCheminEchec(REP_ECHEC);
    repertoireSource.setCheminSource(REPO);
    repertoireSource.setNomConnecteur(NOM_CONNECTEUR);
    repertoireSource.setSource("COUVERTURE_FTTO"); //$NON-NLS-1$
    Pattern pattern = new Pattern();
    pattern.setCheminDest(REP_TRAVAIL);
    pattern.setPattern("COUVERTURE_FTTO_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    repertoireSource.getPattern().add(pattern);
    configRepertoireSource_p.getRepertoireSource().add(repertoireSource);

    repertoireSource = new RepertoireSource();
    repertoireSource.setCheminEchec(REP_ECHEC);
    repertoireSource.setCheminSource(REPO);
    repertoireSource.setNomConnecteur(NOM_CONNECTEUR);
    repertoireSource.setSource("COUVERTURE_CUIVRE"); //$NON-NLS-1$
    pattern = new Pattern();
    pattern.setCheminDest(REP_TRAVAIL);
    pattern.setPattern("COUVERTURE_CUIVRE_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv"); //$NON-NLS-1$
    repertoireSource.getPattern().add(pattern);
    configRepertoireSource_p.getRepertoireSource().add(repertoireSource);
  }

  /**
   * @param fileNameList
   *          Liste des fichiers sur le FTP GAS
   * @param criteriaToBuildFileList
   *          critères NoTmpAllSamePattern/NoTmpDifferentPatterns/WithTmpAndOtherPatternOnly/WithTmpAndOtherPatterns
   */
  private void buildFileNameList(List<String> fileNameList, String criteriaToBuildFileList)
  {
    switch (criteriaToBuildFileList)
    {
      case "NoTmpAllSamePattern": //$NON-NLS-1$
        fileNameList.add("COUVERTURE_FTTO_ECOSPIRIT_20180913_1.csv"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_FTTO_ECOSPIRIT_20180913_2.csv"); //$NON-NLS-1$
        //fileNameList.add("COUVERTURE_CUIVRE_ECOSPIRIT_20180913_1.csv"); //$NON-NLS-1$
        //fileNameList.add("COUVERTURE_CUIVRE_ECOSPIRIT_20180913_2.csv"); //$NON-NLS-1$
        break;

      case "NoTmpDifferentPatterns": //$NON-NLS-1$
        fileNameList.add("COUVERTURE_FTTO_ECOSPIRIT_20180913_1.csv"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_FTTO_ECOSPIRIT_20180913_2.csv"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_CUIVRE_ECOSPIRIT_20180913_2.csv"); //$NON-NLS-1$
        fileNameList.add("error.log"); //$NON-NLS-1$
        break;

      case "WithTmpAndOtherPatternOnly": //$NON-NLS-1$
        fileNameList.add("COUVERTURE_CUIVRE_ECOSPIRIT_20180913_1.csv"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_CUIVRE_ECOSPIRIT_20180913_2.csv"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_FTTO_ECOSPIRIT_20180913_1.tmp"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_FTTO_ECOSPIRIT_20180913_2.tmp"); //$NON-NLS-1$
        break;

      case "WithTmpAndOtherPatterns": //$NON-NLS-1$
        fileNameList.add("COUVERTURE_CUIVRE_ECOSPIRIT_20180913_1.tmp"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_CUIVRE_ECOSPIRIT_20180913_2.tmp"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_FTTO_ECOSPIRIT_20180913_1.csv"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_FTTO_ECOSPIRIT_20180913_2.csv"); //$NON-NLS-1$
        fileNameList.add("error.log"); //$NON-NLS-1$
        break;

      case "WithTmpOnly": //$NON-NLS-1$
        fileNameList.add("COUVERTURE_CUIVRE_ECOSPIRIT_20180913_1.tmp"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_CUIVRE_ECOSPIRIT_20180913_2.tmp"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_FTTO_ECOSPIRIT_20180913_1.tmp"); //$NON-NLS-1$
        fileNameList.add("COUVERTURE_FTTO_ECOSPIRIT_20180913_2.tmp"); //$NON-NLS-1$
        break;

      default:
        break;
    }
  }

  /**
   * @param response_p
   *          Expected response
   * @param retour_p
   *          Expeted Retour
   * @return the object {@Code Retour}
   * @throws Throwable
   *           In case of error
   */
  private Retour checkResponse(Response response_p, Retour retour_p) throws Throwable
  {
    Retour retour = MarshallTools.unmarshall(Retour.class, response_p.getGenericResponse().getResult());
    assertEquals(retour_p.getResultat(), retour.getResultat());
    assertEquals(retour_p.getCategorie(), retour.getCategorie());
    assertEquals(retour_p.getDiagnostic(), retour.getDiagnostic());
    return retour;
  }

  /**
   * @param numberOfRepertoiresSource_p
   *          Number of source
   * @return expected sources
   */
  private ConfigRepertoireSource createConfigRepertoireSource(int numberOfRepertoiresSource_p)
  {
    ConfigRepertoireSource configRepertoireSource = new ConfigRepertoireSource();
    buildConfigRepertoireSource(configRepertoireSource, numberOfRepertoiresSource_p);
    return configRepertoireSource;
  }

  /**
   * @param key_p
   *          The key
   * @param value_p
   *          The value
   * @return process params
   */
  private ConcurrentHashMap<String, Map<String, String>> createProcessParams(String key_p, String value_p)
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    Map<String, String> map = new HashMap<>();
    map.put(key_p, value_p);
    processParams.put(StringConstants.EMPTY_STRING, map);
    return processParams;
  }

  /**
   * create request
   *
   * @return request
   */
  private Request createRequest()
  {
    List<Parameter> parameters = new ArrayList<>();
    final String sourceIdentifier = "COUVERTURE_FTTO"; //$NON-NLS-1$
    Parameter parameter = new Parameter(SOURCE, sourceIdentifier);
    parameters.add(parameter);
    IUrlParameters urlParameters = new UrlParameters(parameters);

    IRavelRequest ravelRequest = RavelRequestFactory.getInstance().createRequest();
    ravelRequest.setUrlParameters(urlParameters);

    Request request = new Request("", "", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    RavelRequest.RequestHeader requestHeader = new RavelRequest.RequestHeader();
    requestHeader.setName(IHttpHeadersConsts.X_SOURCE);
    request.setUrlParameters(urlParameters);
    request.getRequestHeader().add(requestHeader);
    return request;
  }

  /**
   * @param processInstance_p
   *          the process
   * @return the response
   * @throws Throwable
   *           In case of error
   */
  private Response executeProcess(SpiritProcessSkeleton processInstance_p) throws Throwable
  {
    Request request = createRequest();
    request.setMsgId(ID_CORRELATION);

    PowerMock.replayAll();
    processInstance_p.initializeContext();
    processInstance_p.run(request);
    PowerMock.verifyAll();

    return (Response) request.getResponse();
  }

  /**
   * @param expected_p
   *          Expected return
   * @throws Throwable
   *           In case of error
   */
  private void mock_BL100_KO_getFileNameList(Retour expected_p) throws Throwable
  {
    //call FTPConnector.getFileNameList return an error on first call
    EasyMock.expect(_ftpProxyMock.getFileNameList(NOM_CONNECTEUR, ID_CORRELATION, REPO, new ArrayList<>())).andReturn(new ConnectorResponse<>(null, expected_p));
  }

  /**
   * @param fileNameList_p
   *          the list with the file names to download
   * @param chemin_p
   *          chmin temporaire ou echec
   * @throws Throwable
   *           In case of error
   */
  private void mock_BL100_OK_downloadFile_removeFile(List<String> fileNameList_p, String chemin_p) throws Throwable
  {
    for (String fileName : fileNameList_p)
    {
      EasyMock.expect(_ftpProxyMock.downloadFile(NOM_CONNECTEUR, ID_CORRELATION, REPO, fileName, chemin_p)).andReturn(new ConnectorResponse<>(null, RetourFactory.createOkRetour()));
      EasyMock.expect(_ftpProxyMock.removeFile(NOM_CONNECTEUR, ID_CORRELATION, "/in/" + fileName)).andReturn(new ConnectorResponse<>(true, RetourFactory.createOkRetour())); //$NON-NLS-1$

    }
  }

  /**
   * @param fileNameList_p
   *          the list with the file names to download
   * @throws Throwable
   *           In case of error
   */
  private void mock_BL100_OK_getFileNameList(List<String> fileNameList_p) throws Throwable
  {
    //call FTPConnector.getFileNameList return an error on first call
    EasyMock.expect(_ftpProxyMock.getFileNameList(NOM_CONNECTEUR, ID_CORRELATION, REPO, new ArrayList<>())).andReturn(new ConnectorResponse<>(fileNameList_p, RetourFactory.createOkRetour()));
  }

  /**
   * @param key_p
   *          The key
   * @param value_p
   *          The value The file group name
   * @param configRepertoireSource_p
   *          configuration de la source
   * @return The ConfigGroupeFichier object
   * @throws Throwable
   *           In case of error
   */
  private ConfigRepertoireSource prepareProcess(String key_p, String value_p, ConfigRepertoireSource configRepertoireSource_p) throws Throwable
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(key_p, value_p);

    // Process Manager Mock
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams);
    EasyMock.expect(Paths.get(value_p)).andReturn(_path);

    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject(Path.class))).andReturn(MarshallTools.marshall(configRepertoireSource_p).getBytes());

    // Prepare access to singleton instances
    EasyMock.expect(FTPProxy.getInstance()).andReturn(_ftpProxyMock);
    EasyMock.expectLastCall().anyTimes();
    EasyMock.expect(DateTimeManager.getInstance()).andReturn(_dateTimeManagerMock);
    EasyMock.expectLastCall().anyTimes();

    return configRepertoireSource_p;
  }

}