/*******************************************************************************
* $Id: IndexRecherchePfiWriterTest.java 14226 2018-12-06 15:29:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0265.writers;

import static org.junit.Assert.assertEquals;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.easymock.EasyMockSupport;
import org.junit.After;
import org.junit.Test;

import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.saab.air.CleRecherche;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.TestUtils;

/**
 *
 * @author pcarreir
 * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
 */
public class IndexRecherchePfiWriterTest extends EasyMockSupport
{
  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-AIR-PFI.tmp"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * The compte mail writer
   */
  private IndexRecherchePfiWriter _writer;

  @After
  public void afterTest()
  {
    Path p = Paths.get(FILENAME);
    p.toFile().delete();
  }

  /**
   * Scenario: Create one line<br>
   * Input: The StLienAllocationCommercial to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void ressourceWriter_Nominal_01() throws Exception
  {
    IndexRecherchePfi irp = new IndexRecherchePfi("clientOperateur", "noCompte"); //$NON-NLS-1$ //$NON-NLS-2$
    List<CleRecherche> cleRechercheList = new ArrayList<>();
    CleRecherche cr = new CleRecherche("type", "valeur1"); //$NON-NLS-1$ //$NON-NLS-2$
    cleRechercheList.add(cr);
    cr = new CleRecherche("type", "valeur2"); //$NON-NLS-1$ //$NON-NLS-2$
    cleRechercheList.add(cr);
    irp.setListeCleRecherche(cleRechercheList);

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("type", "valeur1", "clientOperateur", "noCompte"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$
    List<String> line2 = Arrays.asList("type", "valeur2", "clientOperateur", "noCompte"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new IndexRecherchePfiWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, irp);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(IndexRecherchePfiWriter.IndexRecherchePfiHeader.class.getEnumConstants())//
        .map(Enum::name)//
        .toArray(String[]::new);

    assertEquals(3, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    System.out.println(lines.get(1));
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
    System.out.println(lines.get(2));
    assertEquals(line2.toString(), Arrays.asList(lines.get(2).split(SEMICOLON)).toString());
  }
}
