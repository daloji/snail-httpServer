/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0257.writers;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Test;

import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.ford.processes.TestUtils;

/**
 *
 * @author jbrites
 * @version ($Revision$ $Date$)
 */
public class ImpiFixeWriterTest
{
  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-RES-IMPIFIXE.tmp"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * The ImpiFixe writer
   */
  private ImpiFixeWriter _writer;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Scenario: Create one line<br>
   * Input: The Ressource ImpiFixe to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void impiFixeWriter_Nominal_01() throws Exception
  {
    Ressource ressource = TestUtils.buildRessoource("src/test/resources/PP0257/ImpiFixe_nominal.json"); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idImpiFixe", "ALLOUE", "idSt", "20181212010100", "20181212010200"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$//$NON-NLS-5$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new ImpiFixeWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, ressource);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(ImpiFixeWriter.ImpiFixeHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    System.out.println(lines.get(1));
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: Create one line<br>
   * Input: Test OK, with null idSt<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void impiFixeWriter_Nominal_02() throws Exception
  {
    Ressource ressource = TestUtils.buildRessoource("src/test/resources/PP0257/ImpiFixe_EmptyIdSt.json"); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idImpiFixe", "ALLOUE", "", "20181212010100", "20181212010200"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$//$NON-NLS-4$//$NON-NLS-5$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new ImpiFixeWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, ressource);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(ImpiFixeWriter.ImpiFixeHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    System.out.println(lines.get(1));
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }
}
