/*******************************************************************************
* $Id: LienEqtPaModemWriterTest.java 14226 2018-12-06 15:29:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import com.bytel.spirit.ford.processes.TestUtils;
import org.easymock.EasyMockSupport;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.PP0098.generator.LienEqtPaModemWriter.LienEqtPaModemHeader;

/**
 *
 * @author pcarreir
 * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
 */
public class LienEqtPaModemWriterTest extends EasyMockSupport
{

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-LIENEQTPAMODEM.csv"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * The Writer to test
   */
  private LienEqtPaModemWriter _currentInstance;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _currentInstance = new LienEqtPaModemWriter(FILENAME, 1);
  }

  /**
   * Scenario: test OK with Invalid Equipement CARTE_THD <br>
   * Input: Valid PFI of type VOIP <br>
   * Result: No Lines created <br>
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void LienEqtPaModemWriterTest_KO_00() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienSaPaTVWriter_Nominal.json"); //$NON-NLS-1$
    _currentInstance.dumpPFI(new Tracabilite(), pfi, LocalDate.of(2018, 5, 1));
    _currentInstance.close();
  }

  /**
   * Scenario: test OK with Valid Equipment MODEM <br>
   * Input: Valid PFI <br>
   * Result: Write two complete lines <br>
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void LienEqtPaModemWriterTest_OK_00() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienEqtPaModemWriter_Nominal.json"); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "valIdEqt1", "valIdPA1", "ACTIF", "id111", "MODEM", "MODELE", "00:19:B9:FB:E2:58", "00:19:B9:FB:E2:48", "00:19:B9:FB:E2:38", "codeEAN", "FABRICANT", "THD", "12345", "20170518174337", "20171210164337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _currentInstance.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 12, 10));
    _currentInstance.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(LienEqtPaModemHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: test OK with Valid Equipment MODEM <br>
   * Input: Valid PFI with empty fields <br>
   * Result: Write two complete lines <br>
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void LienEqtPaModemWriterTest_OK_01() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/LienEqtPaModemWriter_WithEmptyFields.json"); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "valIdEqt1", "valIdPA1", "ACTIF", "id111", "MODEM", "", "00:19:B9:FB:E2:58", "00:19:B9:FB:E2:48", "", "codeEAN", "FABRICANT", "THD", "12345", "20170518174337", "20171210164337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _currentInstance.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 12, 10));
    _currentInstance.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(LienEqtPaModemHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: test OK with Valid Equipment MODEM <br>
   * Input: Valid PFI with multiple lien <br>
   * Result: Write two complete lines <br>
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void LienEqtPaModemWriterTest_OK_02() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/pfi.json"); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("BSS_GP", "612104018213", "610006280136", "PALF01", "RESILIE", "EQSAGEMMOD01", "MODEM", "#tmodem#", "", "", "", "3526350060015", "SAGEMCOM", "XDSL", "75105", "20180501131559", "20180501131606"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$
    List<String> line2 = Arrays.asList("BSS_GP", "612104018213", "610006280136", "PALF02", "ACTIF", "EQSAGEMMOD01", "MODEM", "#tmodem#", "", "", "", "3526350060015", "SAGEMCOM", "XDSL", "75105", "20180501131559", "20180501131606"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _currentInstance.dumpPFI(tracabilite, pfi, LocalDate.of(2018, 5, 1));
    _currentInstance.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(LienEqtPaModemHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(3, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
    assertEquals(line2.toString(), Arrays.asList(lines.get(2).split(SEMICOLON)).toString());
  }

}
