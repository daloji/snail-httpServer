package com.bytel.spirit.ford.processes.PP0293;

/*******************************************************************************
* $Id: PP0293_CompterEtatSim_Test.java 23458 2019-07-02 10:48:53Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.HttpMethod;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.connectors.gdr.GDRProxy;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 *
 * @author rrosa
 * @version ($Revision: 23458 $ $Date: 2019-07-02 12:48:53 +0200 (mar. 02 juil. 2019) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ GDRProxy.class })
public class PP0293_CompterEtatSim_Test
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   *
   */
  private static final String PROCESS_NAME = PP0293_CompterEtatSim.class.getSimpleName();

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    final Map<String, String> map = new HashMap<>();

    final Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.clear();
    processParams.put(StringConstants.EMPTY_STRING, map);
  }

  /**
   * _GDRProxy Mock
   */
  @MockStrict
  private GDRProxy _GDRProxyMock;

  /**
   * The _current process.
   */
  PP0293_CompterEtatSim _currentInstance;

  /**
   * Called before each test with the annotation @Before to clean the connectors.
   */
  @Before
  public void beforeTest()
  {
    // Initialize the context
    _currentInstance = new PP0293_CompterEtatSim();
    _currentInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_currentInstance.getIdProcess());
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(GDRProxy.class);
  }

  /**
   * BL001_CtrlDonneesEntree: teste le cas oú les conf paramètres sont vides<br/>
   *
   * <b>Entrées:</b>Vide conf paramètres.<br/>
   * <b>Attendu:</b> KO | CAT-4 | La conf n'est pas définie. <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0293_compterEtatSim_001() throws Throwable
  {
    HashMap<String, String> map = new HashMap<>();
    map.put(PP0293_CompterEtatSim.PE_CONSUMER, ""); //$NON-NLS-1$
    map.put(PP0293_CompterEtatSim.PE_M2M, ""); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, "La conf n'est pas définie", "PP0293_BL001_CtrlDonneesEntree"); //$NON-NLS-1$
    Response response = executeStartProcess();
    Retour retour = prepareResponse(response);
    checkRetour(retourExpected, retour);
    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
  }

  /**
   * BL001_CtrlDonneesEntree: teste le cas oú le paramètre pe_consumer a des valeurs invalides.<br/>
   *
   * <b>Entrées:</b>Invalid pe_consumer.<br/>
   * <b>Attendu:</b> KO | CAT-4 | La conf n'est pas définie. <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0293_compterEtatSim_002() throws Throwable
  {
    HashMap<String, String> map = new HashMap<>();
    map.put(PP0293_CompterEtatSim.PE_CONSUMER, "1,A,3"); //$NON-NLS-1$
    map.put(PP0293_CompterEtatSim.PE_M2M, "4,5,6"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, "La conf n'est pas définie", "PP0293_BL001_CtrlDonneesEntree"); //$NON-NLS-1$
    Response response = executeStartProcess();
    Retour retour = prepareResponse(response);
    checkRetour(retourExpected, retour);
    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
  }

  /**
   * BL001_CtrlDonneesEntree: teste le cas oú le paramètre pe_m2m a des valeurs invalides.<br/>
   *
   * <b>Entrées:</b>Invalid pe_m2m.<br/>
   * <b>Attendu:</b> KO | CAT-4 | La conf n'est pas définie. <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0293_compterEtatSim_003() throws Throwable
  {
    HashMap<String, String> map = new HashMap<>();
    map.put(PP0293_CompterEtatSim.PE_CONSUMER, "1,2,3"); //$NON-NLS-1$
    map.put(PP0293_CompterEtatSim.PE_M2M, "4,A,6"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, "La conf n'est pas définie", "PP0293_BL001_CtrlDonneesEntree"); //$NON-NLS-1$
    Response response = executeStartProcess();
    Retour retour = prepareResponse(response);
    checkRetour(retourExpected, retour);
    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
  }

  /**
   * BL001_CtrlDonneesEntree: teste le cas oú le paramètre pe_consumer est vide.<br/>
   *
   * <b>Entrées:</b>KO CAT-1 à la sortie du connecteur.<br/>
   * <b>Attendu:</b> KO. <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0293_compterEtatSim_004() throws Throwable
  {
    HashMap<String, String> map = new HashMap<>();
    map.put(PP0293_CompterEtatSim.PE_M2M, "4,5,6"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    ConnectorResponse<Nothing, Retour> resp = new ConnectorResponse<>(null, RetourFactoryForTU.createKO(IMegConsts.CAT1, null, null, null));
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.compterEtatESim(_tracabilite, new ArrayList<Integer>(), Arrays.asList(4, 5, 6))).andReturn(resp);

    PowerMock.replayAll();
    Response response = executeStartProcess();
    PowerMock.verifyAll();

    Retour retour = prepareResponse(response);
    checkRetour(resp._second, retour);
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
  }

  /**
   * BL001_CtrlDonneesEntree: teste le cas oú le paramètre pe_m2m est vide.<br/>
   *
   * <b>Entrées:</b>pe_m2m vide.<br/>
   * <b>Attendu:</b> OK. <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0293_compterEtatSim_005() throws Throwable
  {
    HashMap<String, String> map = new HashMap<>();
    map.put(PP0293_CompterEtatSim.PE_CONSUMER, "1,2,3"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    ConnectorResponse<Nothing, Retour> resp = new ConnectorResponse<>(null, RetourFactoryForTU.createOkRetour());
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.compterEtatESim(_tracabilite, Arrays.asList(1, 2, 3), new ArrayList<Integer>())).andReturn(resp);

    PowerMock.replayAll();
    Response response = executeStartProcess();
    PowerMock.verifyAll();

    Retour retour = prepareResponse(response);
    checkRetour(resp._second, retour);
    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
  }

  /**
   * BL001_CtrlDonneesEntree: teste le cas oú le paramètre pe_consumer est vide.<br/>
   *
   * <b>Entrées:</b>pe_consumer vide.<br/>
   * <b>Attendu:</b> OK. <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PP0293_compterEtatSim_006() throws Throwable
  {
    HashMap<String, String> map = new HashMap<>();
    map.put(PP0293_CompterEtatSim.PE_M2M, "4,5,6"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    ConnectorResponse<Nothing, Retour> resp = new ConnectorResponse<>(null, RetourFactoryForTU.createOkRetour());
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_GDRProxyMock);
    EasyMock.expect(_GDRProxyMock.compterEtatESim(_tracabilite, new ArrayList<Integer>(), Arrays.asList(4, 5, 6))).andReturn(resp);

    PowerMock.replayAll();
    Response response = executeStartProcess();
    PowerMock.verifyAll();

    Retour retour = prepareResponse(response);
    Assert.assertEquals(resp._second, retour);
    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
  }

  /**
   * @param retourExpected
   * @param retourActual
   */
  private void checkRetour(Retour retourExpected, Retour retourActual)
  {
    Assert.assertEquals(retourExpected.getResultat(), retourActual.getResultat());
    Assert.assertEquals(retourExpected.getCategorie(), retourActual.getCategorie());
    Assert.assertEquals(retourExpected.getDiagnostic(), retourActual.getDiagnostic());
    Assert.assertEquals(retourExpected.getLibelle(), retourActual.getLibelle());
  }

  /**
   * Execute start process.
   *
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess() throws Throwable
  {
    Request request = prepareRequest();
    Response ret = null;
    request.setOperation(PROCESS_NAME);
    _currentInstance.run(request);
    ret = (Response) request.getResponse();
    return ret;
  }

  /**
   * Create a Generic Request to call PP0293_compterEtatSim.
   *
   * @return Request
   * @throws RavelException
   *           RavelException
   */
  private Request prepareRequest() throws RavelException
  {
    Request request = new Request(PROCESS_NAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.POST);
    request.setMsgId(_tracabilite.getIdCorrelationSpirit());
    return request;
  }

  /**
   * @param response_p
   *          the response value
   * @return Retour
   * @throws RavelException
   *           in case error
   */
  private Retour prepareResponse(final Response response_p) throws RavelException
  {
    final Retour response = GsonTools.getIso8601Sec().fromJson(response_p.getGenericResponse().getResult(), Retour.class);
    return response;
  }
}
