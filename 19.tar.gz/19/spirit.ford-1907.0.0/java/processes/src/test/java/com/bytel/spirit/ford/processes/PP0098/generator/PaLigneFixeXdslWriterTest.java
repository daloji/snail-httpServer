/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.ford.processes.TestUtils;
import com.bytel.spirit.ford.processes.PP0098.generator.PaLigneFixeXdslWriter.PALFXDSLHeader;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PaLigneFixeXdslWriterTest
{

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-PALFXDSL.csv"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * Writer
   */
  PaLigneFixeXdslWriter _writer;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Initialize before tests
   *
   * @throws Exception
   *           Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void beforeTest() throws Exception
  {
    _writer = new PaLigneFixeXdslWriter(FILENAME, 2);
  }

  /**
   * Test of CSV extraction with 3 XDSL PA with empty contexteInstallation
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void PALFXDSLWriter_EmptyContextInstallation_02() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/PALFXDSL_PFI_EmptyContexteInstallation.json"); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "valIdPA1", "ACTIF", "2017-05-18 17:43:37.320", "12345", "", "", "", "", "999", "777", "", "", "", "", "XDSL", "idProfilTechnique1", "idOperateurCollecte1", "", "", "", "", "", "", "codeInsee1", "", "", "", "", "", "", "", "", "", "", "", "", "", "20170518174337", "20170518174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$ //$NON-NLS-18$ //$NON-NLS-19$ //$NON-NLS-20$ //$NON-NLS-21$ //$NON-NLS-22$ //$NON-NLS-23$ //$NON-NLS-24$ //$NON-NLS-25$ //$NON-NLS-26$ //$NON-NLS-27$ //$NON-NLS-28$ //$NON-NLS-29$ //$NON-NLS-30$ //$NON-NLS-31$ //$NON-NLS-32$ //$NON-NLS-33$ //$NON-NLS-34$ //$NON-NLS-35$ //$NON-NLS-36$ //$NON-NLS-37$ //$NON-NLS-38$ //$NON-NLS-39$ //$NON-NLS-40$ //$NON-NLS-41$
    List<String> line2 = Arrays.asList("BSS_GP", "610000012345", "valIdPA3", "ACTIF", "2017-05-18 17:43:37.320", "67890", "", "", "", "", "222", "444", "", "", "", "", "XDSL", "idProfilTechnique2", "idOperateurCollecte2", "", "", "", "", "", "", "codeInsee2", "", "", "", "", "", "", "", "", "", "", "", "", "", "20170518174337", "20170518174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$ //$NON-NLS-18$ //$NON-NLS-19$ //$NON-NLS-20$ //$NON-NLS-21$ //$NON-NLS-22$ //$NON-NLS-23$ //$NON-NLS-24$ //$NON-NLS-25$ //$NON-NLS-26$ //$NON-NLS-27$ //$NON-NLS-28$ //$NON-NLS-29$ //$NON-NLS-30$ //$NON-NLS-31$ //$NON-NLS-32$ //$NON-NLS-33$ //$NON-NLS-34$ //$NON-NLS-35$ //$NON-NLS-36$ //$NON-NLS-37$ //$NON-NLS-38$ //$NON-NLS-39$ //$NON-NLS-40$ //$NON-NLS-41$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 05, 18));
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PALFXDSLHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(3, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
    assertEquals(line2.toString(), Arrays.asList(lines.get(2).split(SEMICOLON)).toString());
  }

  /**
   * Test of CSV extraction with 3 XDSL PA
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void PALFXDSLWriter_Nominal_01() throws Exception
  {
    PFI pfi = TestUtils.buildPFI("src/test/resources/PP0098/PALFXDSL_PFI_Nominal.json"); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "valIdPA1", "ACTIF", "2017-05-18 17:43:37.320", "12345", "", "", "", "", "999", "777", "", "", "", "", "XDSL", "idProfilTechnique1", "idOperateurCollecte1", "", "", "", "", "", "", "codeInsee1", "", "", "", "", "", "", "", "1", "H", "2017-11-18", "h15_17h", "xxx", "Aucun commentaire", "20170518174337", "20170518174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$ //$NON-NLS-18$ //$NON-NLS-19$ //$NON-NLS-20$ //$NON-NLS-21$ //$NON-NLS-22$ //$NON-NLS-23$ //$NON-NLS-24$ //$NON-NLS-25$ //$NON-NLS-26$ //$NON-NLS-27$ //$NON-NLS-28$ //$NON-NLS-29$ //$NON-NLS-30$ //$NON-NLS-31$ //$NON-NLS-32$ //$NON-NLS-33$ //$NON-NLS-34$ //$NON-NLS-35$ //$NON-NLS-36$ //$NON-NLS-37$ //$NON-NLS-38$ //$NON-NLS-39$ //$NON-NLS-40$ //$NON-NLS-41$
    List<String> line2 = Arrays.asList("BSS_GP", "610000012345", "valIdPA3", "ACTIF", "2017-05-18 17:43:37.320", "67890", "", "", "", "", "222", "444", "", "", "", "", "XDSL", "idProfilTechnique2", "idOperateurCollecte2", "", "", "", "", "", "", "codeInsee2", "", "", "", "", "", "", "", "1", "H", "2017-11-18", "h15_17h", "xxx", "Aucun commentaire", "20170518174337", "20170518174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$ //$NON-NLS-16$ //$NON-NLS-17$ //$NON-NLS-18$ //$NON-NLS-19$ //$NON-NLS-20$ //$NON-NLS-21$ //$NON-NLS-22$ //$NON-NLS-23$ //$NON-NLS-24$ //$NON-NLS-25$ //$NON-NLS-26$ //$NON-NLS-27$ //$NON-NLS-28$ //$NON-NLS-29$ //$NON-NLS-30$ //$NON-NLS-31$ //$NON-NLS-32$ //$NON-NLS-33$ //$NON-NLS-34$ //$NON-NLS-35$ //$NON-NLS-36$ //$NON-NLS-37$ //$NON-NLS-38$ //$NON-NLS-39$ //$NON-NLS-40$ //$NON-NLS-41$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer.dumpPFI(tracabilite, pfi, LocalDate.of(2017, 05, 18));
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(PALFXDSLHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(3, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
    assertEquals(line2.toString(), Arrays.asList(lines.get(2).split(SEMICOLON)).toString());
  }
}
