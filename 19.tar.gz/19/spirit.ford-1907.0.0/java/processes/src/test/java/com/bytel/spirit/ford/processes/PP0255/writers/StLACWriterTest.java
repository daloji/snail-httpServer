/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Test;

import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.ford.processes.TestUtils;

/**
 *
 * @author jbrites
 * @version ($Revision$ $Date$)
 */
public class StLACWriterTest
{

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-ST-LAC.csv"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * the writer
   */
  StLACWriter _writer;

  /**
   * Deletes the CSV file after each test.
   */
  @After
  public void afterTest()
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Scenario: Create one line<br>
   * Input: The StLienAllocationCommercial to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StLACWriter_Nominal_01() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0255/ServiceTechnique_LAC.json", SpiritConstants.JSON_PROFILE_STARK); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idSt", "ACTIF", "", "", "610000012345", "typeRessource", "idRessource", "typeObjetCommercial", "ocClientOperateur", "ocNoCompte", "ocIdentifiantFonctionnelPA", "ocNoServiceAccessible", "ocNoEquipement", "20180510164337", "20181014164337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new StLACWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(StLACWriter.StLACHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: test OK with null stLienAllocationCommercial<br>
   * Input: Valid ServiceTechnique with empty fields<br>
   * Result: Write 2 complete lines <br>
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StLACWriter_Nominal_02() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0255/StLAC_nominal_WithEmptyFields.json", SpiritConstants.JSON_PROFILE_STARK); //$NON-NLS-1$

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idSt", "ACTIF", "", "", "610000012345", "", "", "", "", "", "", "", "", "20180510174337", "20181014174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new StLACWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(StLACWriter.StLACHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }

  /**
   * Scenario: test OK with null stLienAllocationCommercial<br>
   * Input: Valid ServiceTechnique with empty fields<br>
   * Result: Write 2 complete lines <br>
   *
   * @throws Exception
   *           Should not happen
   */
  @Test
  public void StLACWriter_TestReturnInLine() throws Exception
  {
    ServiceTechnique st = TestUtils.buildServiceTechnique("src/test/resources/PP0255/StLAC_nominal_WithEmptyFields.json", SpiritConstants.JSON_PROFILE_STARK); //$NON-NLS-1$

    st.setCommentaire("Part 1\nPart 2\r\nPart 3");

    //date creation and date modification are adjusted to expect the date value in the timezone Europe/Paris
    List<String> line1 = Arrays.asList("idSt", "ACTIF", "Part 1Part 2Part 3", "", "610000012345", "", "", "", "", "", "", "", "", "20180510174337", "20181014174337"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _writer = new StLACWriter(StringConstants.EMPTY_STRING, FILENAME, 1);
    _writer.dump(tracabilite, st);
    _writer.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);
    String[] header = Arrays.stream(StLACWriter.StLACHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());
  }
}
