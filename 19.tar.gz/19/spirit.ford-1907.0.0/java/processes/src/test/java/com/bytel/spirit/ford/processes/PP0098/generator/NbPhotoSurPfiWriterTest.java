/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.After;
import org.junit.Test;

import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.TestUtils;
import com.bytel.spirit.ford.processes.PP0098.generator.NbPhotoSurPfiWriter.NbPhotoSurPFIHeader;

import net.sf.ehcache.util.concurrent.ConcurrentHashMap;

/**
 *
 * @author jsantos
 * @version ($Revision$ $Date$)
 */
public class NbPhotoSurPfiWriterTest
{

  /**
   * The CSV filename.
   */
  private static final String FILENAME = "SPIRIT-NBPHOTOSURPFI.csv"; //$NON-NLS-1$

  /**
   * The semicolon constant.
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * The Writer to test
   */
  private NbPhotoSurPfiWriter _currentInstance;

  /**
   * Deletes the CSV file after each test.
   *
   * @throws Exception
   *           Should not happen
   */
  @After
  public void afterTest() throws Exception
  {
    File csvFile = new File(FILENAME);
    csvFile.delete();
  }

  /**
   * Scenario: Create One line<br>
   * Input: The Map Counter to be set<br>
   * Result: 1 line is created
   *
   * @throws Exception
   *           on error
   */
  @Test
  public void nbPhotoSurPFIWriterTest_01() throws Exception
  {
    Map<String, AtomicInteger> hashMap = new ConcurrentHashMap<>();
    String key = "BSS_GP;610000012345"; //$NON-NLS-1$
    AtomicInteger value = new AtomicInteger(2);
    hashMap.put(key, value);

    Tracabilite tracabilite = new Tracabilite();
    tracabilite.setIdCorrelationSpirit(this.getClass().getName());
    _currentInstance = new NbPhotoSurPfiWriter(FILENAME, 1, hashMap);
    _currentInstance.dumpPFI(tracabilite, null, null);
    _currentInstance.close();

    List<String> lines = TestUtils.readFromCSV(FILENAME);

    String[] header = Arrays.stream(NbPhotoSurPFIHeader.class.getEnumConstants()).map(Enum::name).toArray(String[]::new);
    List<String> line1 = Arrays.asList("BSS_GP", "610000012345", "2"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    assertEquals(2, lines.size());
    assertEquals(Arrays.asList(header).toString(), Arrays.asList(lines.get(0).split(SEMICOLON)).toString());
    assertEquals(line1.toString(), Arrays.asList(lines.get(1).split(SEMICOLON)).toString());

    Files.delete(Paths.get(FILENAME));
  }
}
