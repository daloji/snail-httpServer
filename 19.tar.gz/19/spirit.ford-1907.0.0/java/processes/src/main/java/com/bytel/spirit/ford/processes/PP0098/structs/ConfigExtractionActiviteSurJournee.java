/*******************************************************************************
* $Id: ConfigExtractionActiviteSurJournee.java 12092 2018-10-23 09:01:29Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.structs;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author asoares
 * @version ($Revision: 12092 $ $Date: 2018-10-23 11:01:29 +0200 (mar. 23 oct. 2018) $)
 */
public class ConfigExtractionActiviteSurJournee
{
  /**
   * The poolSize.
   */
  private Integer _poolSize;

  /**
   * The waitingFileSize.
   */
  private Integer _waitingFileSize;

  /**
   * The endingTimeout.
   */
  private Integer _endingTimeout;

  /**
   * The pushTimeout.
   */
  private Integer _pushTimeout;

  /**
   * The linesToFlush
   */
  private Integer _linesToFlush;

  /**
   * The chaineConnexion
   */
  private String _chaineConnexion;

  /**
   * The cheminRepTravail.
   */
  private String _cheminRepTravail;

  /**
   * The cheminRepArchiveSucces.
   */
  private String _cheminRepArchiveSucces;

  /**
   * The cheminRepArchiveErreur.
   */
  private String _cheminRepArchiveErreur;

  /**
   * The environnement.
   */
  private String _environnement;

  /**
   * The cheminRepDepotDistant.
   */
  private String _cheminRepDepotDistant;

  /**
   * The listeExtractionActiviteAProduire.
   */
  private List<String> _listeExtractionActiviteAProduire;

  /**
   * @return the chaineConnexion
   */
  public String getChaineConnexion()
  {
    return _chaineConnexion;
  }

  /**
   * @return the cheminRepArchiveErreur
   */
  public String getCheminRepArchiveErreur()
  {
    return _cheminRepArchiveErreur;
  }

  /**
   * @return the cheminRepArchiveSucces
   */
  public String getCheminRepArchiveSucces()
  {
    return _cheminRepArchiveSucces;
  }

  /**
   * @return the cheminRepDepotDistant
   */
  public String getCheminRepDepotDistant()
  {
    return _cheminRepDepotDistant;
  }

  /**
   * @return the cheminRepTravail
   */
  public String getCheminRepTravail()
  {
    return _cheminRepTravail;
  }

  /**
   * @return the endingTimeout
   */
  public Integer getEndingTimeout()
  {
    return _endingTimeout;
  }

  /**
   * @return the environnement
   */
  public String getEnvironnement()
  {
    return _environnement;
  }

  /**
   * @return the linesToFlush
   */
  public Integer getLinesToFlush()
  {
    return _linesToFlush;
  }

  /**
   * @return the listeExtractionActiviteAProduire
   */
  public List<String> getListeExtractionActiviteAProduire()
  {
    return _listeExtractionActiviteAProduire != null ? new ArrayList<>(_listeExtractionActiviteAProduire) : new ArrayList<>();
  }

  /**
   * @return the poolSize
   */
  public Integer getPoolSize()
  {
    return _poolSize;
  }

  /**
   * @return the pushTimeout
   */
  public Integer getPushTimeout()
  {
    return _pushTimeout;
  }

  /**
   * @return the waitingFileSize
   */
  public Integer getWaitingFileSize()
  {
    return _waitingFileSize;
  }

  /**
   * @param chaineConnexion_p
   *          the chaineConnexion to set
   */
  public void setChaineConnexion(String chaineConnexion_p)
  {
    _chaineConnexion = chaineConnexion_p;
  }

  /**
   * @param cheminRepArchiveErreur_p
   *          the cheminRepArchiveErreur to set
   */
  public void setCheminRepArchiveErreur(String cheminRepArchiveErreur_p)
  {
    _cheminRepArchiveErreur = cheminRepArchiveErreur_p;
  }

  /**
   * @param cheminRepArchiveSucces_p
   *          the cheminRepArchiveSucces to set
   */
  public void setCheminRepArchiveSucces(String cheminRepArchiveSucces_p)
  {
    _cheminRepArchiveSucces = cheminRepArchiveSucces_p;
  }

  /**
   * @param cheminRepDepotDistant_p
   *          the cheminRepDepotDistant to set
   */
  public void setCheminRepDepotDistant(String cheminRepDepotDistant_p)
  {
    _cheminRepDepotDistant = cheminRepDepotDistant_p;
  }

  /**
   * @param cheminRepTravail_p
   *          the cheminRepTravail to set
   */
  public void setCheminRepTravail(String cheminRepTravail_p)
  {
    _cheminRepTravail = cheminRepTravail_p;
  }

  /**
   * @param endingTimeout_p
   *          the endingTimeout to set
   */
  public void setEndingTimeout(Integer endingTimeout_p)
  {
    _endingTimeout = endingTimeout_p;
  }

  /**
   * @param environnement_p
   *          the environnement to set
   */
  public void setEnvironnement(String environnement_p)
  {
    _environnement = environnement_p;
  }

  /**
   * @param linesToFlush_p
   *          the linesToFlush to set
   */
  public void setLinesToFlush(Integer linesToFlush_p)
  {
    _linesToFlush = linesToFlush_p;
  }

  /**
   * @param listeExtractionActiviteAProduire_p
   *          the listeExtractionActiviteAProduire to set
   */
  public void setListeExtractionActiviteAProduire(List<String> listeExtractionActiviteAProduire_p)
  {
    _listeExtractionActiviteAProduire = new ArrayList<>(listeExtractionActiviteAProduire_p);
  }

  /**
   * @param poolSize_p
   *          the poolSize to set
   */
  public void setPoolSize(Integer poolSize_p)
  {
    _poolSize = poolSize_p;
  }

  /**
   * @param pushTimeout_p
   *          the pushTimeout to set
   */
  public void setPushTimeout(Integer pushTimeout_p)
  {
    _pushTimeout = pushTimeout_p;
  }

  /**
   * @param waitingFileSize_p
   *          the waitingFileSize to set
   */
  public void setWaitingFileSize(Integer waitingFileSize_p)
  {
    _waitingFileSize = waitingFileSize_p;
  }

  @Override
  public String toString()
  {
    return "ConfigExtractionActiviteSurJournee [_poolSize=" + _poolSize + ", _waitingFileSize=" + _waitingFileSize + ", _endingTimeout=" + _endingTimeout + ", _pushTimeout=" + _pushTimeout + ", _linesToFlush=" + _linesToFlush + ", _chaineConnexion=" + _chaineConnexion + ", _cheminRepTravail=" + _cheminRepTravail + ", _cheminRepArchiveSucces=" + _cheminRepArchiveSucces + ", _cheminRepArchiveErreur=" + _cheminRepArchiveErreur + ", _environnement=" + _environnement + ", _cheminRepDepotDistant=" + _cheminRepDepotDistant + ", _listeExtractionActiviteAProduire=" + _listeExtractionActiviteAProduire + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$ //$NON-NLS-14$ //$NON-NLS-15$
  }

}
