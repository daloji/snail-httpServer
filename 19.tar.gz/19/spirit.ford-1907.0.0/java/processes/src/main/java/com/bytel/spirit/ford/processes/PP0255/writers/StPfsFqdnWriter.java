/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static java.util.Objects.nonNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.fqdn.StPfsFqdn;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class StPfsFqdnWriter extends STWriter
{
  /**
   * Class containing the StPfsFQDN entete to write in CSV file.
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  public enum StPfsFqdnHeader
  {
    /**
     * ID_ST
     */
    ID_ST(0),

    /**
     * STATUT
     */
    STATUT(1),

    /**
     * COMMENTAIRE
     */
    COMMENTAIRE(2),

    /**
     * CLIENT_OPERATEUR
     */
    CLIENT_OPERATEUR(3),

    /**
     * NO_COMPTE
     */
    NO_COMPTE(4),

    /**
     * NOM_FQDN
     */
    NOM_FQDN(5),

    /**
     * NOMBRE_SESSION
     */
    NOMBRE_SESSION(6),

    /**
     * DATE_CREATION
     */
    DATE_CREATION(7),

    /**
     * DATE_MODIFICATION
     */
    DATE_MODIFICATION(8);

    /**
     * The header size
     */
    static final int ST_PFS_FQDN_HEADER_SIZE = 9;

    /**
     * The index of the column in the header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    StPfsFqdnHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public StPfsFqdnWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    super(filePath_p, fileName_p, linesToFlush_p);
    createFile(filePath_p + fileName_p, StPfsFqdnHeader.class);
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique objectToWrite_p)
  {
    if (shouldExecuteDump(objectToWrite_p))
    {
      executeDumpAction(tracabilite_p, objectToWrite_p);
    }
  }

  @Override
  protected void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    StPfsGenerique stPfsGenerique = StPfsGenerique.class.cast(serviceTechnique_p);
    StPfsFqdn stPfsFqdn = deserializeRawFields(tracabilite_p, stPfsGenerique);//because of raw json fields from SAAB
    List<String> record = this.getRecord(stPfsFqdn);

    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  protected boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p)
  {
    if (serviceTechnique_p != null)
    {
      if (TypeST.PFS.name().equals(serviceTechnique_p.getTypeServiceTechnique()))
      {
        return TypePFS.FQDN.name().equals(StPfsGenerique.class.cast(serviceTechnique_p).getTypePfs());
      }
    }
    return false;
  }

  /**
   * Convert an instance of StPfsGenerique object (having json raw fields) to an instance of StPfsFqdn.
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @param stPfsGenerique_p
   *          Instance of StPfsGenerique
   * @return An instance of StPfsFqdn if deserialization succeeds, null otherwise.
   */
  private StPfsFqdn deserializeRawFields(Tracabilite tracabilite_p, StPfsGenerique stPfsGenerique_p)
  {
    StPfsFqdn stPfsFqdn = null;
    try
    {
      stPfsFqdn = stPfsGenerique_p != null ? StPfsFqdn.buildFromStPfsGenerique(stPfsGenerique_p) : null;
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
    }
    return stPfsFqdn;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param stPfsFqdn_p
   *          The ServiceTechnique
   *
   * @return List of values
   */
  private List<String> getRecord(StPfsFqdn stPfsFqdn_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[StPfsFqdnHeader.ST_PFS_FQDN_HEADER_SIZE]));
    if (nonNull(stPfsFqdn_p))
    {
      record.set(StPfsFqdnHeader.ID_ST.getIndex(), stPfsFqdn_p.getIdSt());
      record.set(StPfsFqdnHeader.STATUT.getIndex(), stPfsFqdn_p.getStatut());
      record.set(StPfsFqdnHeader.COMMENTAIRE.getIndex(), stPfsFqdn_p.getCommentaire());
      record.set(StPfsFqdnHeader.CLIENT_OPERATEUR.getIndex(), stPfsFqdn_p.getClientOperateur());
      record.set(StPfsFqdnHeader.NO_COMPTE.getIndex(), stPfsFqdn_p.getNoCompte());

      if (nonNull(stPfsFqdn_p.getDonneesIdentificationSTPfsFqdn()))
      {
        record.set(StPfsFqdnHeader.NOM_FQDN.getIndex(), stPfsFqdn_p.getDonneesIdentificationSTPfsFqdn().getNomFQDN());
      }

      if (nonNull(stPfsFqdn_p.getDonneesProvisionneesSTPfsFqdn()))
      {
        record.set(StPfsFqdnHeader.NOMBRE_SESSION.getIndex(), String.valueOf(stPfsFqdn_p.getDonneesProvisionneesSTPfsFqdn().getNombreSession()));
      }

      record.set(StPfsFqdnHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsFqdn_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
      record.set(StPfsFqdnHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsFqdn_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
      return record;
    }

    return Collections.emptyList();
  }
}
