/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static java.util.Objects.nonNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesIdentificationSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesProvisionneesSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author jbrites
 * @version ($Revision$ $Date$)
 */
public class StPfsMailWriter extends STWriter
{

  /**
   * Class containing the StLienAllocationCommercial entete to write in CSV File.
   *
   * @author jbrites
   * @version ($Revision$ $Date$)
   */
  public enum StPfsMailHeader
  {
    /**
     *
     */
    ID_ST(0),

    /**
     *
     */
    STATUT(1),

    /**
     *
     */
    COMMENTAIRE(2),

    /**
     *
     */
    CLIENT_OPERATEUR(3),

    /**
     *
     */
    NO_COMPTE(4),

    /**
     *
     */
    ID_COMPTE_MAIL(5),

    /**
     *
     */
    ADRESSE_MAIL(6),

    /**
     *
     */
    TYPE_SERVICE_MAIL(7),

    /**
     *
     */
    TAILLE_PIECE_JOINTE(8),

    /**
     *
     */
    VOLUME_BOITE(9),

    /**
     *
     */
    ID_COMPTE_MAIL_PRINCIPAL(10),

    /**
     *
     */
    NIVEAU_RESTRICTION(11),

    /**
     *
     */
    DATE_CREATION(12),

    /**
     *
     */
    DATE_MODIFICATION(13);

    /**
     * The header size
     */
    static final int ST_PFS_MAIL_HEADER_SIZE = 14;

    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    StPfsMailHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public StPfsMailWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    super(filePath_p, fileName_p, linesToFlush_p);
    createFile(filePath_p + fileName_p, StPfsMailHeader.class);
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique objectToWrite_p)
  {
    if (shouldExecuteDump(objectToWrite_p))
    {
      executeDumpAction(tracabilite_p, objectToWrite_p);
    }
  }

  @Override
  protected void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    StPfsGenerique stPfsGenerique = StPfsGenerique.class.cast(serviceTechnique_p);
    StPfsMail stPfsMail = deserializeRawFields(tracabilite_p, stPfsGenerique);//because of raw json fields from SAAB
    List<String> record = this.getRecord(stPfsMail);

    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  protected boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p)
  {
    if (serviceTechnique_p != null)
    {
      if (TypeST.PFS.name().equals(serviceTechnique_p.getTypeServiceTechnique()))
      {
        return TypePFS.MAIL.name().equals(StPfsGenerique.class.cast(serviceTechnique_p).getTypePfs());
      }
    }
    return false;
  }

  /**
   * Convert an instance of StPfsGenerique object (having json raw fields) to an instance of StPfsMail.
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @param stPfsGenerique_p
   *          Instance of StPfsGenerique
   * @return An instance of StPfsMail if deserialization succeeds, null otherwise.
   */
  private StPfsMail deserializeRawFields(Tracabilite tracabilite_p, StPfsGenerique stPfsGenerique_p)
  {
    StPfsMail stPfsMail = null;
    try
    {
      stPfsMail = stPfsGenerique_p != null ? StPfsMail.buildFromStPfsGenerique(stPfsGenerique_p) : null;
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
    }
    return stPfsMail;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param stPfsMail_p
   *          The ServiceTechnique
   *
   * @return List of values
   */
  private List<String> getRecord(StPfsMail stPfsMail_p)
  {
    if (nonNull(stPfsMail_p))
    {
      List<String> record = new ArrayList<>(Arrays.asList(new String[StPfsMailHeader.ST_PFS_MAIL_HEADER_SIZE]));
      record.set(StPfsMailHeader.ID_ST.getIndex(), stPfsMail_p.getIdSt());
      record.set(StPfsMailHeader.STATUT.getIndex(), stPfsMail_p.getStatut());
      record.set(StPfsMailHeader.COMMENTAIRE.getIndex(), stPfsMail_p.getCommentaire());
      record.set(StPfsMailHeader.CLIENT_OPERATEUR.getIndex(), stPfsMail_p.getClientOperateur());
      record.set(StPfsMailHeader.NO_COMPTE.getIndex(), stPfsMail_p.getNoCompte());
      if (stPfsMail_p.getDonneesProvisionneesStPfsMail() != null)
      {
        DonneesProvisionneesSTPfsMail donneesStps = stPfsMail_p.getDonneesProvisionneesStPfsMail();
        record.set(StPfsMailHeader.TAILLE_PIECE_JOINTE.getIndex(), String.valueOf(donneesStps.getTaillePieceJointe()));
        record.set(StPfsMailHeader.VOLUME_BOITE.getIndex(), String.valueOf(donneesStps.getVolumeBoite()));
        record.set(StPfsMailHeader.ID_COMPTE_MAIL_PRINCIPAL.getIndex(), donneesStps.getIdCompteMailPrincipal());
        record.set(StPfsMailHeader.NIVEAU_RESTRICTION.getIndex(), donneesStps.getNiveauRestriction());
        record.set(StPfsMailHeader.ADRESSE_MAIL.getIndex(), donneesStps.getAdresseMail());

      }

      if (stPfsMail_p.getDonneesIdentificationStPfsMail() != null)
      {
        DonneesIdentificationSTPfsMail donneesIdentPfsMail = stPfsMail_p.getDonneesIdentificationStPfsMail();
        record.set(StPfsMailHeader.ID_COMPTE_MAIL.getIndex(), donneesIdentPfsMail.getIdCompteMail());
        record.set(StPfsMailHeader.TYPE_SERVICE_MAIL.getIndex(), donneesIdentPfsMail.getTypeServiceMail());

      }

      record.set(StPfsMailHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsMail_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
      record.set(StPfsMailHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsMail_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
      return record;
    }
    return Collections.emptyList();
  }

}
