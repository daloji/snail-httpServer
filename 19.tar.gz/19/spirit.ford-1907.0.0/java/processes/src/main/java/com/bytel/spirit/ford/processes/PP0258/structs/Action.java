/*******************************************************************************
* $Id: Action.java 16726 2019-02-05 15:45:56Z sdiop $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0258.structs;

/**
 *
 * @author sdiop
 * @version ($Revision: 16726 $ $Date: 2019-02-05 16:45:56 +0100 (mar. 05 févr. 2019) $)
 */
public enum Action
{

  /**
   * extraction
   */
  CREATION("creation"), //$NON-NLS-1$

  /**
   * envoie
   */
  ENVOIE("envoie"); //$NON-NLS-1$

  /**
   *
   */
  private final String _value;

  /**
   * The constructor.
   *
   * @param value_p
   *          the value
   */
  private Action(String value_p)
  {
    _value = value_p;
  }

  /**
   * @return value
   */
  public String value()
  {
    return _value;
  }


  public static Action getAction(String value_p)
  {
    for (Action action : Action.values())
    {
      if (action.value().equals(value_p))
      {
        return action;
      }
    }
    return null;
  }

}
