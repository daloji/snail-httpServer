/*******************************************************************************
* $Id: AbstractRESImportTask.java 13266 2018-11-16 10:41:55Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.task;

import java.text.MessageFormat;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.task.IRavelTask;
import com.bytel.ravel.services.process.task.ITransitionData;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.ford.processes.Messages;

/**
 * Common abstract task implementation for RES import task. <br />
 * One task will import a bloc into RES and update KO counter on error.
 *
 * @author jstrub
 * @version ($Revision: 13266 $ $Date: 2018-11-16 11:41:55 +0100 (ven. 16 nov. 2018) $)
 * @param <T>
 *          Type of data to import
 */
public abstract class AbstractRESImportTask<T> implements IRavelTask
{

  /** Data to import. */
  protected final IBlocImportData<T> _dataToImport;
  /** Import context. */
  protected final ImportContext _context;
  /** State. */
  protected State _state;

  /**
   * @param dataToImport_p
   *          the bloc data to import
   * @param context_p
   *          the context
   */
  public AbstractRESImportTask(IBlocImportData<T> dataToImport_p, ImportContext context_p)
  {
    _dataToImport = dataToImport_p;
    _context = context_p;
    _state = State.EXECUTING;
  }

  @Override
  public ITransitionData execute() throws RavelException
  {
    ConnectorResponse<Retour, Integer> retour = importData();

    // Task has an unique execution and no return
    _state = State.ENDED;

    if (retour == null)
    {
      _context.incremementLineKO(_dataToImport.size());
      return null;
    }

    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, _context.getTracabilite(), MessageFormat.format(Messages.getString("PP0207.RESImportConnectorResponse"), retour._second, retour._first))); //$NON-NLS-1$
    if (!RetourFactory.isRetourOK(retour._first))
    {
      // If we have a total KO
      _context.incremementLineKO(_dataToImport.size());
    }
    else if ((retour._second != null) && (retour._second != 0))
    {
      // If we got an OK, but with some errors
      _context.incremementLineKO(retour._second);
    }

    return null;
  }

  @Override
  public State state()
  {
    return _state;
  }

  /**
   * Import data into RES
   *
   * @return RES Database connector response
   */
  protected abstract ConnectorResponse<Retour, Integer> importData();

}
