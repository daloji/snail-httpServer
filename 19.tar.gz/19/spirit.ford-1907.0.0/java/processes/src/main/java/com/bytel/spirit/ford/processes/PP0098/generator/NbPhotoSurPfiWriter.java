/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static java.util.Objects.nonNull;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.ford.processes.Messages;

/**
 *
 * @author jsantos
 * @version ($Revision$ $Date$)
 */
public class NbPhotoSurPfiWriter implements INSFWriter
{
  /**
   * Header Enum
   *
   * @author jsantos
   * @version ($Revision$ $Date$)
   */
  public enum NbPhotoSurPFIHeader
  {
    /**
     * CLIENT_OPERATEUR
     */
    CLIENT_OPERATEUR(0),
    /**
     * NO_COMPTE
     */
    NO_COMPTE(1),
    /**
     * NBRE_CHGT_PFI
     */
    NBRE_CHGT_PFI(2);

    /**
     * The position in CSV
     */
    private int _position;

    /**
     * Default constructor
     *
     * @param position_p
     *          The position
     */
    NbPhotoSurPFIHeader(int position_p)
    {
      _position = position_p;
    }

    /**
     * @return the position
     */
    public int getPosition()
    {
      return _position;
    }
  }

  /**
   * The Writer
   */
  private BufferedWriter _writer;

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;

  /**
   * Writer retour
   */
  private Retour _retour;

  /**
   * File Name
   */
  private String _fileName;

  /**
   * Current line in buffer
   */
  private Integer _lineCount;

  /**
   * Number of lines permitted on buffer to call flush
   */
  private int _linesToFlush;

  /**
   * PFI counter
   */
  private Map<String, AtomicInteger> _pfiCounter;

  /**
   * Default Constructor
   *
   * @param fileName_p
   *          The filename
   * @param linesToFlush_p
   *          The number of lines to call flush
   * @param pfiCounter_p
   *          The counter pfi
   * @throws IOException
   *           IOException
   */
  public NbPhotoSurPfiWriter(String fileName_p, int linesToFlush_p, Map<String, AtomicInteger> pfiCounter_p) throws IOException
  {
    _retour = RetourFactory.createOkRetour();
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    _pfiCounter = pfiCounter_p;
    _lineCount = 0;
    _writer = Files.newBufferedWriter(Paths.get(fileName_p));
    _csvPrinter = new CSVPrinter(_writer, CSVFormat.newFormat(';').withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(NbPhotoSurPFIHeader.class));

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
    _writer.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    //PFI is always NULL
    if (nonNull(_pfiCounter))
    {
      for (Map.Entry<String, AtomicInteger> entry : _pfiCounter.entrySet())
      {
        List<String> csvLine = new ArrayList<>();
        csvLine.add(entry.getKey());
        csvLine.add(Integer.toString(entry.getValue().get()));
        write(tracabilite_p, csvLine);
      }
    }
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Add lines to buffer or write them on file if buffer size is greater then max permited
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param line_p
   *          the line to write
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> line_p)
  {
    try
    {
      _csvPrinter.printRecord(line_p);
      _lineCount++;
      if (_lineCount >= _linesToFlush)
      {
        _csvPrinter.flush();
        _lineCount = 0;
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }

}
