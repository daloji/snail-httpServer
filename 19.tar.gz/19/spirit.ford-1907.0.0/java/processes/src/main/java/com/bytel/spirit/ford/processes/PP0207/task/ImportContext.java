package com.bytel.spirit.ford.processes.PP0207.task;

import java.util.concurrent.atomic.AtomicInteger;

import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

/**
 * Context for import task : MUST be thread-safe !
 *
 * @author jstrub
 * @version ($Revision: 13245 $ $Date: 2018-11-15 17:04:05 +0100 (jeu. 15 nov. 2018) $)
 */
public class ImportContext
{

  /** Number of line read. */
  private final AtomicInteger _nbLigne = new AtomicInteger();
  /** Number of line KO. */
  private final AtomicInteger _nbLigneKO = new AtomicInteger();
  /** Tracabilite object. */
  private final Tracabilite _tracabilite;

  /**
   * @param tracabilite_p
   *          the tracabilite
   */
  public ImportContext(Tracabilite tracabilite_p)
  {
    _tracabilite = tracabilite_p;
  }

  /**
   * @return the nbLigne
   */
  public AtomicInteger getNbLigne()
  {
    return _nbLigne;
  }

  /**
   * @return the nbLigneKO
   */
  public AtomicInteger getNbLigneKO()
  {
    return _nbLigneKO;
  }

  /**
   * @return the tracabilite
   */
  public Tracabilite getTracabilite()
  {
    return _tracabilite;
  }

  /**
   * Increment Line number.
   */
  public void incremementLine()
  {
    _nbLigne.incrementAndGet();
  }

  /**
   * Increment Line KO number.
   */
  public void incremementLineKO()
  {
    _nbLigneKO.incrementAndGet();
  }

  /**
   * Increment Line number, by delta.
   *
   * @param delta_p
   *          the delta to add
   */
  public void incremementLineKO(int delta_p)
  {
    _nbLigneKO.addAndGet(delta_p);
  }

}
