/*******************************************************************************
* $Id: PaVoipWriter.java 19207 2019-03-28 13:17:54Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static java.util.Objects.nonNull;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author asoares
 * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
 */
public class PaVoipWriter implements INSFWriter
{

  /**
   * Header enum.
   *
   * @author asoares
   * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
   */
  public enum PAVOIPHeader
  {
    /**
     * CLIENT_OPERATEUR
     */
    CLIENT_OPERATEUR(0),

    /**
     * NO_COMPTE
     */
    NO_COMPTE(1),

    /**
     * ID_PA
     */
    ID_PA(2),

    /**
     * ID_PA_LIE
     */
    ID_PA_LIE(3),

    /**
     * STATUT
     */
    STATUT(4),

    /**
     * NUMERO_TELEPHONE
     */
    NUMERO_TELEPHONE(5),

    /**
     * CODE_RIO
     */
    CODE_RIO(6),

    /**
     * NUM_PORT_TELEPHONIQUE
     */
    NUM_PORT_TELEPHONIQUE(7),

    /**
     * DATE_CREATION
     */
    DATE_CREATION(8),

    /**
     * DATE_MODIFICATION
     */
    DATE_MODIFICATION(9);

    /**
     * The position of each object in each line of the CSV file.
     */
    private int _position;

    /**
     * Default constructor.
     *
     * @param position
     *          The position
     */
    PAVOIPHeader(int position)
    {
      _position = position;
    }

    /**
     * @return the position
     */
    public int getPosition()
    {
      return _position;
    }
  }

  /**
   * The VOIP constant.
   */
  private static final String VOIP = "VOIP"; //$NON-NLS-1$

  /**
   * The Writer
   */
  private BufferedWriter _writer;

  /**
   * The CSVPrinter.
   */
  private CSVPrinter _csvPrinter;

  /**
   * Current line in the buffer.
   */
  private Integer _linesCounter;

  /**
   * Number of lines permitted on buffer to call flush.
   */
  private Integer _linesToFlush;

  /**
   * Writer retour.
   */
  private Retour _retour;

  /**
   * Filename.
   */
  private String _fileName;

  /**
   * The constructor.
   *
   * @param filename_p
   *          the filename
   * @param linesToFlush_p
   *          the number of lines to call flush
   * @throws IOException
   *           IOException
   */
  public PaVoipWriter(String filename_p, Integer linesToFlush_p) throws IOException
  {
    _retour = RetourFactory.createOkRetour();
    _fileName = filename_p;
    _linesCounter = 0;
    _linesToFlush = linesToFlush_p;

    _writer = Files.newBufferedWriter(Paths.get(filename_p));
    _csvPrinter = new CSVPrinter(_writer, CSVFormat.newFormat(';').withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(PaVoipWriter.PAVOIPHeader.class));

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
    _writer.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> linesInCSV = this.getRecords(pfi_p, dateDemande_p);

    for (List<String> line : linesInCSV)
    {
      write(tracabilite_p, line);
    }
  }

  /**
   * Builds a list of string lines to be writen in the CSV file.
   *
   * @param pfi_p
   *          the pfi_p
   *
   * @return the string lines
   */
  public List<List<String>> getRecords(PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> linesInCSV = new ArrayList<>();

    if (nonNull(pfi_p.getPa()))
    {
      List<PA> paLIst = pfi_p.getPa();
      for (PA pa : paLIst)
      {
        if (nonNull(pa) //
            && VOIP.equals(pa.getTypePA()) //
            && "BSS_GP".equals(pfi_p.getClientOperateur()) //$NON-NLS-1$
            && (dateDemande_p.isEqual(pa.getDateCreation().toLocalDate()) //
                || dateDemande_p.isEqual(pa.getDateModification().toLocalDate())))
        {
          List<String> line = new ArrayList<>(Arrays.asList(new String[PAVOIPHeader.values().length]));

          line.set(PAVOIPHeader.CLIENT_OPERATEUR.getPosition(), pfi_p.getClientOperateur());
          line.set(PAVOIPHeader.NO_COMPTE.getPosition(), pfi_p.getNoCompte());
          line.set(PAVOIPHeader.ID_PA.getPosition(), pa.getIdentifiantFonctionnelPA());
          line.set(PAVOIPHeader.ID_PA_LIE.getPosition(), pa.getIdentifiantFonctionnelPALie());
          line.set(PAVOIPHeader.STATUT.getPosition(), CSVWriterUtils.getCsvValue(pa.getStatut()));
          line.set(PAVOIPHeader.DATE_CREATION.getPosition(), CSVWriterUtils.getCsvValue(pa.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
          line.set(PAVOIPHeader.DATE_MODIFICATION.getPosition(), CSVWriterUtils.getCsvValue(pa.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));

          if (nonNull(pa.getPaTypeVoip()))
          {
            line.set(PAVOIPHeader.NUMERO_TELEPHONE.getPosition(), pa.getPaTypeVoip().getNumeroTelephone());
            line.set(PAVOIPHeader.CODE_RIO.getPosition(), pa.getPaTypeVoip().getCodeRio());
            line.set(PAVOIPHeader.NUM_PORT_TELEPHONIQUE.getPosition(), String.valueOf(pa.getPaTypeVoip().getNumeroPortTelephonique()));
          }

          linesInCSV.add(line);
        }
      }
    }
    return linesInCSV;
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Add lines to buffer or write them on file if buffer size is greater then max permitted.
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param line_p
   *          the line to write
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> line_p)
  {
    try
    {
      _csvPrinter.printRecord(line_p);
      _linesCounter++;

      if (_linesCounter >= _linesToFlush)
      {
        _csvPrinter.flush();
        _linesCounter = 0;
      }

    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }

}
