/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.structs;

import java.util.concurrent.ThreadPoolExecutor;

import com.bytel.ravel.common.business.generated.Retour;

/**
 *
 * @author jbrites
 * @version ($Revision$ $Date$)
 */
public class PP0255_BL104_Return
{
  /**
   * The retour of the BL104.
   */
  private Retour _retour;

  /**
   * Extraction execution pool.
   */
  private ThreadPoolExecutor _stPoolExecutor;

  /**
   * Constructor
   *
   * @param retour_p
   *          Retour
   *
   * @param stPoolExecutor_p
   *          ThreadPoolExecutor
   */
  public PP0255_BL104_Return(Retour retour_p, ThreadPoolExecutor stPoolExecutor_p)
  {
    _retour = retour_p;
    _stPoolExecutor = stPoolExecutor_p;
  }

  /**
   * @return value of _retour
   */
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * @return value of stPoolExecutor
   */
  public ThreadPoolExecutor getStPoolExecutor()
  {
    return _stPoolExecutor;
  }
}
