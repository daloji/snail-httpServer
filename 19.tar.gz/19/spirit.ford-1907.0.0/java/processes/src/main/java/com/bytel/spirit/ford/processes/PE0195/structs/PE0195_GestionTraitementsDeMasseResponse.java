/*******************************************************************************
* $Id: PE0195_GestionTraitementsDeMasseResponse.java 7839 2018-07-13 10:14:50Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PE0195.structs;

import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.types.Retour;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author lmerces
 * @version ($Revision: 7839 $ $Date: 2018-07-13 12:14:50 +0200 (ven. 13 juil. 2018) $)
 */
public class PE0195_GestionTraitementsDeMasseResponse extends BasicResponse
{

  /**
   * ReponseFonctionnelle
   *
   * @author lmerces
   * @version ($Revision: 7839 $ $Date: 2018-07-13 12:14:50 +0200 (ven. 13 juil. 2018) $)
   */
  public static class ReponseFonctionnelle
  {
    /**
     * List de traitements de masse
     */
    @SerializedName("listeTraitementDeMasse")
    @Expose
    private List<TraitementDeMasseIHM> _traitementsDeMasse;

    /**
     * @return the traitementsDeMasse
     */
    public List<TraitementDeMasseIHM> getTraitementsDeMasse()
    {
      return new ArrayList<>(_traitementsDeMasse);
    }

    /**
     * @param traitementsDeMasse_p
     *          the traitementsDeMasse to set
     */
    public void setTraitementsDeMasse(List<TraitementDeMasseIHM> traitementsDeMasse_p)
    {
      _traitementsDeMasse = new ArrayList<>(traitementsDeMasse_p);
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = -6161024298878042546L;

  /**
   * reponseFonctionnelle
   */
  @SerializedName("reponseFonctionnelle")
  @Expose
  private ReponseFonctionnelle _reponseFonctionnelle;

  /**
   * @param retour_p
   *          {@link Retour}
   */
  public PE0195_GestionTraitementsDeMasseResponse(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @return the reponseFonctionnelle
   */
  public ReponseFonctionnelle getReponseFonctionnelle()
  {
    return _reponseFonctionnelle;
  }

  /**
   * @param reponseFonctionnelle_p
   *          the reponseFonctionnelle to set
   */
  public void setReponseFonctionnelle(ReponseFonctionnelle reponseFonctionnelle_p)
  {
    _reponseFonctionnelle = reponseFonctionnelle_p;
  }

}
