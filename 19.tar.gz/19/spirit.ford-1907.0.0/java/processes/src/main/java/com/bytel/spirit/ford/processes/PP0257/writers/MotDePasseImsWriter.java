/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0257.writers;

import static java.util.Objects.nonNull;

import java.io.Closeable;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.csv.CSVPrinter;
import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.ford.processes.PP0257.writers.CompteImsWriter.CompteImsHeader;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;
import com.bytel.spirit.ford.shared.misc.processes.writers.IGenericWriter;

/**
 *
 * @author bvilela
 * @version ($Revision$ $Date$)
 */
public class MotDePasseImsWriter implements IGenericWriter<Ressource>, Closeable
{

  /**
   * Class containing the Fichier entete to write in CSV File.
   *
   * @author bvilela
   * @version ($Revision$ $Date$)
   */
  public enum MotDePasseImsHeader
  {
    /**
    *
    */
    MOT_DE_PASSE_IMS(0),
    /**
    *
    */
    STATUT(1),
    /**
    *
    */
    ID_ST_LAC(2),
    /**
    *
    */
    DATE_CREATION(3),
    /**
    *
    */
    DATE_MODIFICATION(4);
    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    MotDePasseImsHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;

  /**
   * Number of maximum lines to write without performing a flush on the CSV file.
   */
  private int _linesToFlush;

  /**
   * The path of CSV file.
   */
  private String _filePath;

  /**
   * The name of CSV file.
   */
  private String _fileName;

  /**
   * Number of lines dumped in the CSV file.
   */
  private int _currentDumpedLines = 0;

  /**
   * retour
   */
  private Retour _retour;

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public MotDePasseImsWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    _filePath = filePath_p;
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    _retour = RetourFactory.createOkRetour();

    createFile(filePath_p + fileName_p, MotDePasseImsHeader.class);
  }

  @Override
  public void close() throws IOException
  {
    _csvPrinter.flush();
    _csvPrinter.close();
  }

  @Override
  public void dump(Tracabilite tracabilite_p, Ressource ressource_p)
  {
    if (shouldExecuteDump(ressource_p))
    {
      List<String> record = this.getRecord(ressource_p);
      if (!CollectionUtils.isEmpty(record))
      {
        write(tracabilite_p, record);
      }
    }
  }

  @Override
  public String getFileName()
  {
    return _fileName;
  }

  @Override
  public String getFilePath()
  {
    return _filePath;
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  @Override
  public void setCSVPrinter(CSVPrinter csvPrinter_p)
  {
    this._csvPrinter = csvPrinter_p;
  }

  /**
   * Check if the Ressource object in the parameter has the correct type, in order to know if the writer should execute
   * the dump operation
   *
   * @param ressource_p
   *          The Ressource object
   * @return true if dump operation is to be performed
   */
  protected boolean shouldExecuteDump(Ressource ressource_p)
  {
    if (ressource_p != null)
    {
      return TypeRessource.MOT_DE_PASSE_IMS.name().equals(ressource_p.getTypeRessource());
    }
    return false;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param ressourceCompteIms_p
   *
   *          The ressource of CompteIms type
   *
   * @return List of values
   */
  private List<String> getRecord(Ressource ressourceCompteIms_p)
  {

    List<String> record = new ArrayList<>(Arrays.asList(new String[CompteImsHeader.values().length]));
    if (nonNull(ressourceCompteIms_p))
    {
      record.set(MotDePasseImsHeader.MOT_DE_PASSE_IMS.getIndex(), ressourceCompteIms_p.getIdRessource());
      record.set(MotDePasseImsHeader.STATUT.getIndex(), ressourceCompteIms_p.getStatut());
      record.set(MotDePasseImsHeader.ID_ST_LAC.getIndex(), ressourceCompteIms_p.getIdSt());
      record.set(MotDePasseImsHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(ressourceCompteIms_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
      record.set(MotDePasseImsHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(ressourceCompteIms_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
      return record;
    }
    return Collections.emptyList();
  }

  /**
   * Write in the CSV file the list of records. Each record corresponds to a line.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param record_p
   *          The list of records.
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> record_p)
  {
    try
    {
      _csvPrinter.printRecord(record_p);
      //check if a flush is needed
      if ((++_currentDumpedLines % this._linesToFlush) == 0)
      {
        _csvPrinter.flush();
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, _fileName, exception.getMessage())));
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, _fileName, exception.getMessage()));
    }
  }

}
