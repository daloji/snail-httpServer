/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PaLigneFixeFtthWriter implements INSFWriter
{
  /**
   * Enum containing the Header specification for a PALFXDSL CSV file type.
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public enum PALFFTTHHeader
  {

    /**
     *
     */
    CLIENT_OPERATEUR(0),

    /**
     *
     */
    NO_COMPTE(1),

    /**
     *
     */
    ID_PA(2),

    /**
     *
     */
    STATUT(3),
    /**
     *
     */
    ID_RACCO(4),

    /**
     *
     */
    IS_PA_CIBLE(5),

    /**
     *
     */
    IS_PA_PRINCIPAL(6),

    /**
     *
     */
    PTO(7),

    /**
     *
     */
    ID_OSS(8),

    /**
     *
     */
    IS_PRO(9),

    /**
     *
     */
    REFERENCE_PM_OI(10),

    /**
     *
     */
    TECHNO_RACCO(11),

    /**
     *
     */
    ID_PROFIL_TECH(12),
    /**
    *
    */
    CODE_OI(13),
    /**
    *
    */
    ADR_NUMERO(14),
    /**
    *
    */
    ADR_IND_REPETITION(15),
    /**
    *
    */
    ADR_NOM_VOIE(16),
    /**
    *
    */
    ADR_CODE_POSTAL(17),
    /**
    *
    */
    ADR_VILLE(18),
    /**
    *
    */
    ADR_CODE_INSEE(19),
    /**
    *
    */
    ADR_CODE_RIVOLI(20),
    /**
    *
    */
    ADR_PORTE(21),
    /**
    *
    */
    ADR_LOGO(22),
    /**
    *
    */
    ADR_BATIMENT(23),
    /**
    *
    */
    ADR_ESCALIER(24),
    /**
    *
    */
    ADR_ETAGE(25),
    /**
    *
    */
    ADR_HEXACLE(26),
    /**
    *
    */
    INST_TYPE_MES(27),
    /**
    *
    */
    INST_DATE_CLIENT(28),
    /**
    *
    */
    INST_CRENEAU_CLIENT(29),
    /**
    *
    */
    INST_ID_RDV(30),
    /**
    *
    */
    INST_PRESTATAIRE(31),
    /**
    *
    */
    INST_COMMENTAIRE(32),
    /**
    *
    */
    DATE_CREATION(33),
    /**
    *
    */
    DATE_MODIFICATION(34);
    /**
     * Header size of PALFXDSL CSV file type.
     */
    private static final int PALFFTTH_HEADER_SIZE = 37;
    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index_p
     *          The index
     */
    PALFFTTHHeader(int index_p)
    {
      _index = index_p;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * LIGNE_FIXE PA type
   */
  private static final String PA_TYPE_LIGNE_FIXE = "LIGNE_FIXE"; //$NON-NLS-1$

  /**
   * TECNOLOGIE FTTH
   */
  private static final String ACCES_TECHNIQUE_FTTH = "FTTH"; //$NON-NLS-1$

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;
  /**
   * Number of maximum lines to write without performing a flush on the CSV file.
   */
  private int _linesToFlush;

  /**
   * The name of CSV PFI file.
   */
  private String _fileName;
  /**
   * Number of lines dumped in the CSV file.
   */
  private int _currentDumpedLines = 0;
  /**
   * retour
   */
  private Retour _retour;

  /**
   * @param fileName_p
   *          File name
   * @param linesToFlush_p
   *          Number of lines to flush
   *
   * @throws IOException
   *           IOException
   */
  public PaLigneFixeFtthWriter(String fileName_p, int linesToFlush_p) throws IOException
  {
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    initCsvPrinter();

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> records = this.getRecords(pfi_p, dateDemande_p);
    for (List<String> record : records)
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param pfi_p
   *          The PFI
   *
   * @return listr returned
   */
  private List<List<String>> getRecords(PFI pfi_p, LocalDate dateDemande_p)
  {

    List<List<String>> records = new ArrayList<>();

    List<PA> lPALigneFixe = pfi_p.getPa().stream().filter(pa -> pa.getTypePA().equals(PA_TYPE_LIGNE_FIXE))//filter PA of type LIGNE_FIXE
        .filter(pa -> pa.getPaTypeLigneFixe() != null)//only want non null PATypeLigneFixed
        .collect(Collectors.toList());

    for (PA pa : lPALigneFixe)
    {
      PaTypeLigneFixe paLigneFixe = pa.getPaTypeLigneFixe();
      if (isPALigneFixeFTTH(paLigneFixe) //
          && "BSS_GP".equals(pfi_p.getClientOperateur()) //$NON-NLS-1$
          && (dateDemande_p.isEqual(pa.getDateCreation().toLocalDate()) //
              || dateDemande_p.isEqual(pa.getDateModification().toLocalDate())))
      {
        List<String> record = new ArrayList<>(Arrays.asList(new String[PALFFTTHHeader.PALFFTTH_HEADER_SIZE]));

        record.set(PALFFTTHHeader.CLIENT_OPERATEUR.getIndex(), pfi_p.getClientOperateur());
        record.set(PALFFTTHHeader.NO_COMPTE.getIndex(), pfi_p.getNoCompte());
        record.set(PALFFTTHHeader.ID_PA.getIndex(), pa.getIdentifiantFonctionnelPA());
        record.set(PALFFTTHHeader.STATUT.getIndex(), CSVWriterUtils.getCsvValue(pa.getStatut()));
        record.set(PALFFTTHHeader.ID_RACCO.getIndex(), paLigneFixe.getIdRaccordement());
        record.set(PALFFTTHHeader.IS_PA_CIBLE.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getInfoBrutBssGp().isIndicateurPACible()));
        record.set(PALFFTTHHeader.IS_PA_PRINCIPAL.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getInfoBrutBssGp().isIndicateurPAPrincipal()));
        record.set(PALFFTTHHeader.PTO.getIndex(), paLigneFixe.getInfoBrutBssGp().getIdPrise());
        record.set(PALFFTTHHeader.ID_OSS.getIndex(), paLigneFixe.getInfoBrutBssGp().getIdRessourceReseauFTTX());
        record.set(PALFFTTHHeader.IS_PRO.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getInfoBrutBssGp().getIndicateurAccesPRO()));
        record.set(PALFFTTHHeader.REFERENCE_PM_OI.getIndex(), paLigneFixe.getInfoBrutBssGp().getReferencePmOi());
        record.set(PALFFTTHHeader.TECHNO_RACCO.getIndex(), paLigneFixe.getInfoBrutBssGp().getAccesTechnique().getTechnologieAcces());
        record.set(PALFFTTHHeader.ID_PROFIL_TECH.getIndex(), paLigneFixe.getInfoBrutBssGp().getAccesTechnique().getIdProfilTechnique());
        record.set(PALFFTTHHeader.CODE_OI.getIndex(), paLigneFixe.getInfoBrutBssGp().getAccesTechnique().getCodeOperateurImmeuble());

        if (paLigneFixe.getInfoBrutBssGp().getAdresseInstallation() != null)
        {
          record.set(PALFFTTHHeader.ADR_NUMERO.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getNumero());
          record.set(PALFFTTHHeader.ADR_IND_REPETITION.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getIndiceRepetition());
          record.set(PALFFTTHHeader.ADR_NOM_VOIE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getNomVoie());
          record.set(PALFFTTHHeader.ADR_CODE_POSTAL.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getCodePostal());
          record.set(PALFFTTHHeader.ADR_VILLE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getVille());
          record.set(PALFFTTHHeader.ADR_CODE_INSEE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getCodeInsee());
          record.set(PALFFTTHHeader.ADR_CODE_RIVOLI.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getCodeRivoli());
          record.set(PALFFTTHHeader.ADR_PORTE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getPorte());
          record.set(PALFFTTHHeader.ADR_LOGO.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getLogo());
          record.set(PALFFTTHHeader.ADR_BATIMENT.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getBatiment());
          record.set(PALFFTTHHeader.ADR_ESCALIER.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getEscalier());
          record.set(PALFFTTHHeader.ADR_ETAGE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getEtage());
          record.set(PALFFTTHHeader.ADR_HEXACLE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getHexacle());

        }

        if (paLigneFixe.getContexteInstallation() != null)
        {
          record.set(PALFFTTHHeader.INST_TYPE_MES.getIndex(), paLigneFixe.getContexteInstallation().getTypeMes());
          record.set(PALFFTTHHeader.INST_DATE_CLIENT.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getContexteInstallation().getDateClient(), DateTimeFormatPattern.yyyy_dash_MM_dash_dd));
          record.set(PALFFTTHHeader.INST_CRENEAU_CLIENT.getIndex(), paLigneFixe.getContexteInstallation().getCreneauClient());
          record.set(PALFFTTHHeader.INST_ID_RDV.getIndex(), paLigneFixe.getContexteInstallation().getIdRdv());
          record.set(PALFFTTHHeader.INST_PRESTATAIRE.getIndex(), paLigneFixe.getContexteInstallation().getPrestataire());
          if (paLigneFixe.getContexteInstallation().getCommentaire() != null)
          {
            record.set(PALFFTTHHeader.INST_COMMENTAIRE.getIndex(), paLigneFixe.getContexteInstallation().getCommentaire().replaceAll("[\r\n]+", " ")); //$NON-NLS-1$ //$NON-NLS-2$
          }
          else
          {
            record.set(PALFFTTHHeader.INST_COMMENTAIRE.getIndex(), null);
          }
        }
        record.set(PALFFTTHHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(pa.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
        record.set(PALFFTTHHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(pa.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
        records.add(record);
      }
    }
    return records;
  }

  /**
   * Constructs and configures a new instance of CSVFormat
   *
   *
   * @throws IOException
   *           exception
   */
  private void initCsvPrinter() throws IOException
  {

    BufferedWriter bf = Files.newBufferedWriter(Paths.get(_fileName)); //bf is closed in method close by CSVPrinter
    CSVFormat csvFormat = CSVFormat.newFormat(CSV_SEPARATOR).withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(PALFFTTHHeader.class);
    _csvPrinter = new CSVPrinter(bf, csvFormat);

  }

  /**
   * Check if a PaTypeLigneFixe is of type XDSL
   *
   * @param paLigneFixe_p
   *          The PaTypeLigneFixe parameter
   * @return true if PaTypeLigneFixe is of type XDSL
   */
  private boolean isPALigneFixeFTTH(PaTypeLigneFixe paLigneFixe_p)
  {
    if (paLigneFixe_p != null)
    {
      if ((paLigneFixe_p.getInfoBrutBssGp() != null) && (paLigneFixe_p.getInfoBrutBssGp().getAccesTechnique() != null))
      {
        if (ACCES_TECHNIQUE_FTTH.equals(paLigneFixe_p.getInfoBrutBssGp().getAccesTechnique().getTechnologieAcces()))
        {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Write in the CSV file the list of records. Each record corresponds to a line.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param record_p
   *          List of values
   *
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> record_p)
  {

    try
    {
      _csvPrinter.printRecord(record_p);
      //check if a flush is needed
      if ((++_currentDumpedLines % this._linesToFlush) == 0)
      {
        _csvPrinter.flush();
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }

  }
}
