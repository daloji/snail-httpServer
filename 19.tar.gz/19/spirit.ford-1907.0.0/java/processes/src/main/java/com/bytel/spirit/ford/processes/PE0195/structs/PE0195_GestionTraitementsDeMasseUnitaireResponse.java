/*******************************************************************************
* $Id: PE0195_GestionTraitementsDeMasseUnitaireResponse.java 14226 2018-12-06 15:29:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PE0195.structs;

import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.types.Retour;
import com.bytel.spirit.common.shared.saab.rex.ReconciliationCommerciale;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author lmerces
 * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
 */
public class PE0195_GestionTraitementsDeMasseUnitaireResponse extends BasicResponse
{

  /**
   * ReponseFonctionnelle
   *
   * @author lmerces
   * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
   */
  public static class ReponseFonctionnelle
  {
    /**
     * traitement de masse
     */
    @SerializedName("traitementDeMasse")
    @Expose
    private TraitementDeMasseIHM _traitementDeMasse;

    /**
     * List de traitements unitaires
     */
    @SerializedName("listeTraitementsUnitaires")
    @Expose
    private List<ReconciliationCommerciale> _listeTraitementsUnitaires;

    /**
     * Total traitements unitaires
     */
    @SerializedName("nbTotalTraitementsUnitaires")
    @Expose
    private int _nbTotalTraitementsUnitaires;

    /**
     * @return the listeTraitementsUnitaires
     */
    public List<ReconciliationCommerciale> getListeTraitementsUnitaires()
    {
      return new ArrayList<>(_listeTraitementsUnitaires);
    }

    /**
     * @return the nbTotalTraitementsUnitaires
     */
    public int getNbTotalTraitementsUnitaires()
    {
      return _nbTotalTraitementsUnitaires;
    }

    /**
     * @return the traitementDeMasse
     */
    public TraitementDeMasseIHM getTraitementDeMasse()
    {
      return _traitementDeMasse;
    }

    /**
     * @param listeTraitementsUnitaires_p
     *          the listeTraitementsUnitaires to set
     */
    public void setListeTraitementsUnitaires(List<ReconciliationCommerciale> listeTraitementsUnitaires_p)
    {
      _listeTraitementsUnitaires = new ArrayList<>(listeTraitementsUnitaires_p);
    }

    /**
     * @param nbTotalTraitementsUnitaires_p
     *          the nbTotalTraitementsUnitaires to set
     */
    public void setNbTotalTraitementsUnitaires(int nbTotalTraitementsUnitaires_p)
    {
      _nbTotalTraitementsUnitaires = nbTotalTraitementsUnitaires_p;
    }

    /**
     * @param traitementDeMasse_p
     *          the traitementDeMasse to set
     */
    public void setTraitementDeMasse(TraitementDeMasseIHM traitementDeMasse_p)
    {
      _traitementDeMasse = traitementDeMasse_p;
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = 8682573113274716864L;

  /**
   * reponseFonctionnelle
   */
  @SerializedName("reponseFonctionnelle")
  @Expose
  private ReponseFonctionnelle _reponseFonctionnelle;

  /**
   * @param retour_p
   *          retour
   */
  public PE0195_GestionTraitementsDeMasseUnitaireResponse(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @return the reponseFonctionnelle
   */
  public ReponseFonctionnelle getReponseFonctionnelle()
  {
    return _reponseFonctionnelle;
  }

  /**
   * @param reponseFonctionnelle_p
   *          the reponseFonctionnelle to set
   */
  public void setReponseFonctionnelle(ReponseFonctionnelle reponseFonctionnelle_p)
  {
    _reponseFonctionnelle = reponseFonctionnelle_p;
  }
}