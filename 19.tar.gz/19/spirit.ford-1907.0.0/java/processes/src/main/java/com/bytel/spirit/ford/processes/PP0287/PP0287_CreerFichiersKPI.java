/*******************************************************************************
* $Id: PP0287_CreerFichiersKPI.java 23267 2019-06-28 07:38:20Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0287;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.csv.CSVFileWriter;
import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.net.smtp.IMail.MediaType;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.GenericError;
import com.bytel.ravel.services.connector.smtp.SMTPProxy;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier.BL1300_CreerFichierBuilder;
import com.bytel.spirit.common.connectors.gdr.GDRProxy;
import com.bytel.spirit.common.connectors.gdr.structs.StatistiqueEsim;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0287.structs.Action;
import com.bytel.spirit.ford.processes.PP0287.structs.ParameterUri;
import com.bytel.spirit.ford.processes.PP0287.structs.Periodicite;
import com.google.gson.Gson;

/**
 * This process is triggered by STARK to populate the STATISTICS_ESIM table to create the KPI files once a week and once
 * a month.
 *
 * @author asoares
 * @version ($Revision: 23267 $ $Date: 2019-06-28 09:38:20 +0200 (ven. 28 juin 2019) $)
 */
public class PP0287_CreerFichiersKPI extends SpiritRestApiProcessSkeleton
{
  /**
   * The Enum containing all process states.
   *
   * @author asoares
   * @version ($Revision: 23267 $ $Date: 2019-06-28 09:38:20 +0200 (ven. 28 juin 2019) $)
   */
  public enum State
  {
    /**
     * Ctrl Donnees Entree
     */
    PP0287_BL001(MandatoryProcessState.PRC_START),

    /**
     * Recuperer donnees
     */
    PP0287_BL100(MandatoryProcessState.PRC_RUNNING),

    /**
     * Creer Fichier Date Courante
     */
    PP0287_BL200(MandatoryProcessState.PRC_RUNNING),

    /**
     * Creer Fichier Changement Etat
     */
    PP0287_BL300(MandatoryProcessState.PRC_RUNNING),

    /**
     * Envoi Mail
     */
    PP0287_BL400(MandatoryProcessState.PRC_RUNNING),

    /**
     * Formater Response
     */
    PP0287_BL002(MandatoryProcessState.PRC_RUNNING),

    /**
     * Terminal state
     */
    ENDED(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state
     */
    protected boolean _replayableState = false;

    /**
     * The constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }
  }

  /**
   * The context of the process PP0287_CreerFichiersKPI.
   *
   * @author asoares
   * @version ($Revision: 23267 $ $Date: 2019-06-28 09:38:20 +0200 (ven. 28 juin 2019) $)
   */
  static final class PP0287_CreerFichiersKPIContext extends Context
  {
    /**
     * The serial version UID
     */
    private static final long serialVersionUID = 5439111361648201917L;

    /***
     * Contains the next step to execute. Initialized with the first step to execute
     */
    private State _state = State.PP0287_BL001;

    /**
     * The Action parameter uri
     */
    private Action _action;

    /**
     * The periodicite parameter uri
     */
    private Periodicite _periodicite;

    /**
     * The list of the statistics Esim
     */
    private List<StatistiqueEsim> _statistiquesEsim;

    /**
     * The param liste diffusion of the config file that contains the mailing list
     */
    private String _listeDiffusion;

    /**
     * The directory name in which the files will be created
     */
    private String _repertoireWork;

    /**
     * The directory name to which the files will be moved after being sent
     */
    private String _repertoireArchive;

    /**
     * The replyToAdress
     */
    private String _replyToAddress;

    /**
     * The fromAdress
     */
    private String _fromAddress;

    /**
     * The ccAdress
     */
    private String _ccAddress;

    /**
     * @return the action
     */
    public Action getAction()
    {
      return _action;
    }

    /**
     * @return the ccAddress
     */
    public String getCcAddress()
    {
      return _ccAddress;
    }

    /**
     * @return the fromAddress
     */
    public String getFromAddress()
    {
      return _fromAddress;
    }

    /**
     * @return the listeDiffusion
     */
    public String getListeDiffusion()
    {
      return _listeDiffusion;
    }

    /**
     * @return the periodicite
     */
    public Periodicite getPeriodicite()
    {
      return _periodicite;
    }

    /**
     * @return the repertoireArchive
     */
    public String getRepertoireArchive()
    {
      return _repertoireArchive;
    }

    /**
     * @return the repertoireWork
     */
    public String getRepertoireWork()
    {
      return _repertoireWork;
    }

    /**
     * @return the replyToAddress
     */
    public String getReplyToAddress()
    {
      return _replyToAddress;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the statistiquesEsim
     */
    public List<StatistiqueEsim> getStatistiquesEsim()
    {
      return _statistiquesEsim != null ? new ArrayList<>(_statistiquesEsim) : null;
    }

    /**
     * @param action_p
     *          the action to set
     */
    public void setAction(Action action_p)
    {
      _action = action_p;
    }

    /**
     * @param ccAddress_p
     *          the ccAddress to set
     */
    public void setCcAddress(String ccAddress_p)
    {
      _ccAddress = ccAddress_p;
    }

    /**
     * @param fromAddress_p
     *          the fromAddress to set
     */
    public void setFromAddress(String fromAddress_p)
    {
      _fromAddress = fromAddress_p;
    }

    /**
     * @param listeDiffusion_p
     *          the listeDiffusion to set
     */
    public void setListeDiffusion(String listeDiffusion_p)
    {
      _listeDiffusion = listeDiffusion_p;
    }

    /**
     * @param periodicite_p
     *          the periodicite to set
     */
    public void setPeriodicite(Periodicite periodicite_p)
    {
      _periodicite = periodicite_p;
    }

    /**
     * @param repertoireArchive_p
     *          the repertoireArchive to set
     */
    public void setRepertoireArchive(String repertoireArchive_p)
    {
      _repertoireArchive = repertoireArchive_p;
    }

    /**
     * @param repertoireWork_p
     *          the repertoireWork to set
     */
    public void setRepertoireWork(String repertoireWork_p)
    {
      _repertoireWork = repertoireWork_p;
    }

    /**
     * @param replyToAddress_p
     *          the replyToAddress to set
     */
    public void setReplyToAddress(String replyToAddress_p)
    {
      _replyToAddress = replyToAddress_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param statistiquesEsim_p
     *          the statistiquesEsim to set
     */
    public void setStatistiquesEsim(List<StatistiqueEsim> statistiquesEsim_p)
    {
      _statistiquesEsim = new ArrayList<>(statistiquesEsim_p);
    }
  }

  /**
   * The constant DateFin
   */
  public static final String DATE_FIN = "DateFin"; //$NON-NLS-1$

  /**
   * The constant DateDebut
   */
  public static final String DATE_DEBUT = "DateDebut"; //$NON-NLS-1$

  /**
   * The constant LigneDeMarche
   */
  public static final String LIGNE_DE_MARCHE = "LigneDeMarche"; //$NON-NLS-1$

  /**
   * The constant RapportFlux_
   */
  public static final String RAPPORT_FLUX = "RapportFlux_"; //$NON-NLS-1$

  /**
   * The constant RapportEtat_
   */
  public static final String RAPPORT_ETAT = "RapportEtat_"; //$NON-NLS-1$

  /**
   * The Alerte constant.
   */
  public static final String ALERTE = "Alerte"; //$NON-NLS-1$

  /**
   * The Nombre constant.
   */
  public static final String NOMBRE = "Nombre"; //$NON-NLS-1$

  /**
   * The etatEsim constant.
   */
  public static final String ETAT_ESIM = "etatESim"; //$NON-NLS-1$

  /**
   * The Date constant.
   */
  public static final String DATE = "Date"; //$NON-NLS-1$

  /**
   * The Fournisseur constant.
   */
  public static final String FOURNISSEUR = "Fournisseur"; //$NON-NLS-1$

  /**
   * The PE constant.
   */
  public static final String PE = "PE"; //$NON-NLS-1$

  /**
   * The CodeArticleSAP constant.
   */
  public static final String CODE_ARTICLE_SAP = "CodeArticleSAP"; //$NON-NLS-1$

  /**
   * The TypeEsim constant.
   */
  public static final String TYPE_ESIM = "TypeEsim"; //$NON-NLS-1$

  /**
   * The Gencod constant.
   */
  public static final String GENCOD = "Gencod"; //$NON-NLS-1$

  /**
   * The replyToAddress constant
   */
  public static final String REPLY_TO_ADDRESS = "replyToAddress"; //$NON-NLS-1$

  /**
   * The ccAddress constant
   */
  public static final String CC_ADDRESS = "ccAddress"; //$NON-NLS-1$

  /**
   * The fromAddress constant
   */
  public static final String FROM_ADDRESS = "fromAddress"; //$NON-NLS-1$

  /**
   * The repertoire constant
   */
  public static final String REPERTOIRE_WORK = "repertoireWork"; //$NON-NLS-1$

  /**
   * The repertoire constant
   */
  public static final String REPERTOIRE_ARCHIVE = "repertoireArchive"; //$NON-NLS-1$

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = 8551421946772294854L;

  /**
   * The subject of the email
   */
  public static final String SUIVI_CONSOMMATION_ESIM = "suivi de consommation des eSim"; //$NON-NLS-1$

  /**
   * The liste diffusion constant
   */
  public static final String LISTE_DIFFUSION = "listeDiffusion"; //$NON-NLS-1$

  /**
   * @param obj1_p
   *          objet 1
   * @param obj2_p
   *          objet 2
   * @return true/false
   */
  private static boolean checkEquality(Object obj1_p, Object obj2_p)
  {

    if (obj1_p == null)
    {
      return (obj2_p == null);
    }
    return (obj1_p.equals(obj2_p));
  }

  /**
   * The process Context
   */
  private PP0287_CreerFichiersKPIContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    // Initialization of the context cannot be done in the constructor
    // because
    // processes are allocated only at startup and cloned when a new process
    // is expected.
    _processContext = new PP0287_CreerFichiersKPIContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    // Not required for now in Ravel
  }

  /**
   * @param request_p
   *          request
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @throws RavelException
   *           Ravel
   */
  protected void handlePostRequest(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    getProcessConfigParameters(tracabilite_p);
    getUrlparametersIntoProcessContext(request_p);

    // Call BL001
    _processContext.setState(State.PP0287_BL001);
    Retour retour = PP287_BL001_CtrlDonneesEntree(tracabilite_p);

    if (isRetourOK(retour))
    {
      try
      {
        if (Action.ENVOIE.equals(_processContext.getAction()))
        {
          // Call BL400
          _processContext.setState(State.PP0287_BL400);
          retour = PP287_BL400_EnvoiMail(tracabilite_p);
        }
        else
        {
          // Call BL100
          _processContext.setState(State.PP0287_BL100);
          retour = PP287_BL100_RecupererDonnees(_processContext.getPeriodicite(), tracabilite_p);

          //Call BL200 or BL300
          retour = callBL200OrBL300(retour, tracabilite_p);
        }
      }
      catch (Exception ex)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
        retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, ex.getMessage());
      }
    }

    PP287_BL002_FormaterReponse(request_p, retour, tracabilite_p);
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @LogStartProcess
  @Override
  protected void startPostProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, "STARTPROCESS")); //$NON-NLS-1$

    try
    {
      handlePostRequest(request_p, tracabilite_p);
    }
    finally
    {
      _processContext.setState(State.ENDED);
    }
  }

  /**
   * Calculates the date of the first and last day of the week.
   *
   * @param date_p
   *          the date to be calculated
   * @param dayOfWeek_p
   *          the day of the week to use to calculate the date
   * @return the date calculated
   */
  private String calculateDate(Date date_p, DayOfWeek dayOfWeek_p)
  {
    LocalDateTime localDateTime = DateTimeTools.toLocalDateTime(date_p).with(dayOfWeek_p);
    return formatDate(DateTimeTools.toDate(localDateTime));
  }

  /**
   * Calls the BL200 or the BL300 according to the type of the periodicite.
   *
   * @param retour_p
   *          the retour in
   * @param tracabilite_p
   *          the tracabilite
   * @return {@link Retour}
   * @throws RavelException
   *           on error
   */
  private Retour callBL200OrBL300(Retour retour_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = retour_p;

    if (isRetourOK(retour_p))
    {
      switch (_processContext.getPeriodicite())
      {
        case DATE_COURANTE:

          // Call BL200
          _processContext.setState(State.PP0287_BL200);
          retour = PP287_BL200_CreerFichierDateCourante(tracabilite_p);
          break;
        case CHANGEMENT_ETAT_MOIS:
        case CHANGEMENT_ETAT_SEMAINE:

          // Call BL300
          _processContext.setState(State.PP0287_BL300);
          retour = PP287_BL300_CreerFichierChangementEtat(tracabilite_p);
          break;
        default:
          break;
      }
    }

    return retour;
  }

  /**
   * Creates the header of the file.
   *
   * @param typeReport_p
   *          the type of report to add to the file name
   * @return {@link CSVLine} the header
   */
  private CSVLine createHeaderLine(String typeReport_p)
  {
    StringBuilder headers = new StringBuilder();
    headers.append(GENCOD).append(StringConstants.SEMICOLON_SEPARATOR);
    headers.append(TYPE_ESIM).append(StringConstants.SEMICOLON_SEPARATOR);
    headers.append(CODE_ARTICLE_SAP).append(StringConstants.SEMICOLON_SEPARATOR);

    if (RAPPORT_ETAT.equals(typeReport_p))
    {
      headers.append(PE).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(FOURNISSEUR).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(DATE).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(ETAT_ESIM).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(NOMBRE).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(ALERTE).append(StringConstants.WINDOWS_NEW_LINE);
    }
    else
    {
      headers.append(LIGNE_DE_MARCHE).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(PE).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(FOURNISSEUR).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(ETAT_ESIM).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(DATE_DEBUT).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(DATE_FIN).append(StringConstants.SEMICOLON_SEPARATOR);
      headers.append(NOMBRE).append(StringConstants.WINDOWS_NEW_LINE);
    }

    CSVLine header = new CSVLine(headers.toString());
    return header;
  }

  /**
   * Creates the values of the file.
   *
   * @param statistiqueEsim_p
   *          the statistiqueEsim
   * @param typeReport_p
   *          the typeReport
   * @return {@link StringBuilder} the line with values
   */
  private StringBuilder createValuesLine(StatistiqueEsim statistiqueEsim_p, String typeReport_p)
  {
    StringBuilder values = new StringBuilder();
    values.append(statistiqueEsim_p.getGencod() == null ? StringConstants.EMPTY_STRING : String.valueOf(statistiqueEsim_p.getGencod()));
    values.append(StringConstants.SEMICOLON_SEPARATOR);
    values.append(StringTools.defaultString(statistiqueEsim_p.getProfileType(), StringConstants.EMPTY_STRING));
    values.append(StringConstants.SEMICOLON_SEPARATOR);
    values.append(StringTools.defaultString(statistiqueEsim_p.getCodeArticleSAP(), StringConstants.EMPTY_STRING));
    values.append(StringConstants.SEMICOLON_SEPARATOR);

    if (RAPPORT_ETAT.equals(typeReport_p))
    {
      values.append(statistiqueEsim_p.getProfilElectrique());
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(StringTools.defaultString(statistiqueEsim_p.getEncarteur(), StringConstants.EMPTY_STRING));
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(formatDate(statistiqueEsim_p.getDateComptage()));
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(getEtatEsim(statistiqueEsim_p.getTypeComptage()));
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(statistiqueEsim_p.getQuantite());
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(StringTools.defaultString(statistiqueEsim_p.getAlert(), StringConstants.EMPTY_STRING));
    }
    else
    {

      String ligneDeMarche = ""; //$NON-NLS-1$
      if (statistiqueEsim_p.getProfilElectrique() != null)
      {
        String peSub = statistiqueEsim_p.getProfilElectrique().substring(0, 2);
        if ("24".equals(peSub) || "26".equals(peSub)) //$NON-NLS-1$ //$NON-NLS-2$
        {
          ligneDeMarche = "GP"; //$NON-NLS-1$
        }
        else if ("23".equals(peSub) || "25".equals(peSub)) //$NON-NLS-1$ //$NON-NLS-2$
        {
          ligneDeMarche = "M2M"; //$NON-NLS-1$
        }
      }
      values.append(ligneDeMarche);
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(statistiqueEsim_p.getProfilElectrique());
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(StringTools.defaultString(statistiqueEsim_p.getEncarteur(), StringConstants.EMPTY_STRING));
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(getEtatEsim(statistiqueEsim_p.getTypeComptage()));
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(calculateDate(statistiqueEsim_p.getDateComptage(), DayOfWeek.MONDAY));
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(calculateDate(statistiqueEsim_p.getDateComptage(), DayOfWeek.SUNDAY));
      values.append(StringConstants.SEMICOLON_SEPARATOR);
      values.append(statistiqueEsim_p.getQuantite());
    }

    values.append(StringConstants.WINDOWS_NEW_LINE);

    return values;
  }

  /**
   * Formats the date as dd/mm/aaaa.
   *
   * @param date_p
   *          the date to be formated
   * @return the date formated and converted to string
   */
  private String formatDate(Date date_p)
  {
    return DateTimeFormatPattern.dd_slash_MM_slash_yyyy.format(DateTimeTools.toLocalDateTime(date_p));
  }

  /**
   * Gets the etatEsim according to the type comptage.
   *
   * @param typeComptage_p
   *          the type comptage
   * @return the etatEsim
   */
  private String getEtatEsim(String typeComptage_p)
  {
    if ("etatCourantCommandee".equals(typeComptage_p) || "etatChangementCommandee".equals(typeComptage_p)) //$NON-NLS-1$ //$NON-NLS-2$
    {
      return "en commande"; //$NON-NLS-1$
    }

    return "disponible"; //$NON-NLS-1$
  }

  /**
   * Get configuration parameters.
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   */
  private void getProcessConfigParameters(Tracabilite tracabilite_p)
  {
    _processContext.setListeDiffusion(getConfigParameter(LISTE_DIFFUSION));
    _processContext.setRepertoireWork(getConfigParameter(REPERTOIRE_WORK));
    _processContext.setRepertoireArchive(getConfigParameter(REPERTOIRE_ARCHIVE));
    _processContext.setFromAddress(getConfigParameter(FROM_ADDRESS));
    _processContext.setCcAddress(getConfigParameter(CC_ADDRESS));
    _processContext.setReplyToAddress(getConfigParameter(REPLY_TO_ADDRESS));
  }

  /**
   * Gets the URL parameters into the ProcessContext.
   *
   * @param request_p
   *          request
   */
  private void getUrlparametersIntoProcessContext(Request request_p)
  {
    List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();

    for (Parameter parametre : urlParametersType)
    {
      if (parametre.getName().equalsIgnoreCase(ParameterUri.ACTION.name()))
      {
        _processContext.setAction(Action.fromValue(parametre.getValue()));
        continue;
      }

      if (parametre.getName().equalsIgnoreCase(ParameterUri.PERIODICITE.name()))
      {
        _processContext.setPeriodicite(Periodicite.fromValue(parametre.getValue()));
        continue;
      }
    }
  }

  /**
   * This activity aims to control the format and cardinality of the input data.
   *
   * @param tracabilite_p
   *          The {@link Tracabilite}
   * @return The {@link Retour}
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Retour PP287_BL001_CtrlDonneesEntree(Tracabilite tracabilite_p) throws RavelException
  {
    if (_processContext.getAction() == null)
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, Messages.getString("PP0287_CreerFichiersKPI.InvalidDataFormat")); //$NON-NLS-1$);
    }

    if (Action.EXTRACTION.equals(_processContext.getAction()) && (_processContext.getPeriodicite() == null))
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.DONNEE_INVALIDE, Messages.getString("PP0287_CreerFichiersKPI.InvalidDataFormat")); //$NON-NLS-1$);
    }

    if (StringTools.isNullOrEmpty(_processContext.getListeDiffusion()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0287_CreerFichiersKPI.IncorrectEntry"), LISTE_DIFFUSION)); //$NON-NLS-1$
    }

    if (StringTools.isNullOrEmpty(_processContext.getFromAddress()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0287_CreerFichiersKPI.IncorrectEntry"), FROM_ADDRESS)); //$NON-NLS-1$
    }

    if (StringTools.isNullOrEmpty(_processContext.getRepertoireWork()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0287_CreerFichiersKPI.IncorrectEntry"), REPERTOIRE_WORK)); //$NON-NLS-1$
    }
    else if (!_processContext.getRepertoireWork().endsWith("/")) //$NON-NLS-1$
    {
      _processContext.setRepertoireWork(_processContext.getRepertoireWork().concat("/")); //$NON-NLS-1$
    }

    if (StringTools.isNullOrEmpty(_processContext.getRepertoireArchive()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0287_CreerFichiersKPI.IncorrectEntry"), REPERTOIRE_ARCHIVE)); //$NON-NLS-1$
    }
    else if (!_processContext.getRepertoireArchive().endsWith("/")) //$NON-NLS-1$
    {
      _processContext.setRepertoireArchive(_processContext.getRepertoireArchive().concat("/")); //$NON-NLS-1$
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * This activity aims to format the response.
   *
   * @param request_p
   *          The request
   * @param retour_p
   *          The {@link Retour}
   * @param tracabilite_p
   *          The {@link Tracabilite}
   *
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private void PP287_BL002_FormaterReponse(Request request_p, Retour retour_p, Tracabilite tracabilite_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response response;
      ravelResponse.setDataType("application/json"); //$NON-NLS-1$

      if (StringConstants.OK.equals(retour_p.getResultat()))
      {
        response = new Response(ErrorCode.OK_00204, ravelResponse);
      }
      else
      {
        response = new Response(ErrorCode.KO_00500, ravelResponse);
        ravelResponse.setResult(new Gson().toJson(retour_p));
      }

      request_p.setResponse(response);
    }
  }

  /**
   * This activity creates the current stock and consumption monitoring files.
   *
   * @param periodicite_p
   *          The periodecite
   * @param tracabilite_p
   *          The {@link Tracabilite}
   * @return The {@link Retour}
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP287_BL100_RecupererDonnees(Periodicite periodicite_p, Tracabilite tracabilite_p) throws RavelException
  {
    ConnectorResponse<List<StatistiqueEsim>, Retour> statistiquesEsimResp = GDRProxy.getInstance().getStatistiquesEsim(tracabilite_p, periodicite_p.value());

    if (!isRetourOK(statistiquesEsimResp._second))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, statistiquesEsimResp._second.getLibelle()));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, Messages.getString("PP0287_CreerFichiersKPI.ImpossibleConsultation")); //$NON-NLS-1$
    }

    // tri des doublons avec les mêmes type Comptage / PE / Gencode / code artice SAP
    // en conservant le plus récent des deux
    if ((statistiquesEsimResp._first != null) && !statistiquesEsimResp._first.isEmpty())
    {
      List<StatistiqueEsim> statistiquesEsimTriees = new LinkedList<>();
      for (StatistiqueEsim statistiqueEsim : statistiquesEsimResp._first)
      {
        StatistiqueEsim doublon = null;
        for (StatistiqueEsim statistiqueEsimTriee : statistiquesEsimResp._first)
        {
          if (checkEquality(statistiqueEsim.getTypeComptage(), statistiqueEsimTriee.getTypeComptage()) //
              && checkEquality(statistiqueEsim.getCodeArticleSAP(), statistiqueEsimTriee.getCodeArticleSAP()) //
              && checkEquality(statistiqueEsim.getGencod(), statistiqueEsimTriee.getGencod()) //
              && checkEquality(statistiqueEsim.getProfilElectrique(), statistiqueEsimTriee.getProfilElectrique()))
          {
            doublon = statistiqueEsimTriee;
            break;
          }
        }
        if (doublon == null)
        {
          statistiquesEsimTriees.add(statistiqueEsim);
        }
        else if (statistiqueEsim.getDateComptage().after(doublon.getDateComptage()))
        {
          statistiquesEsimTriees.remove(doublon);
          statistiquesEsimTriees.add(statistiqueEsim);
        }
      }
      _processContext.setStatistiquesEsim(statistiquesEsimTriees);
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * This activity calls the common activity of spirit BL1300_CreerFichier.
   *
   * @param tracabilite_p
   *          The tracabilite
   * @return The {@link Retour}
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP287_BL200_CreerFichierDateCourante(Tracabilite tracabilite_p) throws RavelException
  {
    String nomFichier = RAPPORT_ETAT + DateTimeFormatPattern.yyyyMMdd.format(DateTimeManager.getInstance().now()) + ".csv"; //$NON-NLS-1$

    BL1300_CreerFichier bl1300Return = new BL1300_CreerFichierBuilder().tracabilite(tracabilite_p).nomFichier(nomFichier).repertoire(_processContext.getRepertoireWork()).build();
    bl1300Return.execute(this);

    if (isRetourOK(bl1300Return.getRetour()))
    {
      return writeStatsEsimToFile(RAPPORT_ETAT, bl1300Return.getNomFichier(), tracabilite_p);
    }

    return bl1300Return.getRetour();
  }

  /**
   * This activity calls the common activity of spirit BL1300_CreerFichier.
   *
   * @param tracabilite_p
   *          The {@link Tracabilite}
   * @return The {@link Retour}
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP287_BL300_CreerFichierChangementEtat(Tracabilite tracabilite_p) throws RavelException
  {
    BL1300_CreerFichier bl1300Return;
    String nomFichier = null;

    if (Periodicite.CHANGEMENT_ETAT_SEMAINE.equals(_processContext.getPeriodicite()))
    {
      nomFichier = RAPPORT_FLUX + DateTimeFormatPattern.yyyyMMdd.format(DateTimeManager.getInstance().now()) + ".csv"; //$NON-NLS-1$
    }
    else
    {
      nomFichier = RAPPORT_FLUX + DateTimeFormatPattern.yyyyMMdd.format(DateTimeManager.getInstance().now()).substring(0, 6) + ".csv"; //$NON-NLS-1$
    }

    bl1300Return = new BL1300_CreerFichierBuilder().tracabilite(tracabilite_p).nomFichier(nomFichier).repertoire(_processContext.getRepertoireWork()).build();
    bl1300Return.execute(this);

    if (isRetourOK(bl1300Return.getRetour()))
    {
      return writeStatsEsimToFile(RAPPORT_FLUX, bl1300Return.getNomFichier(), tracabilite_p);
    }

    return bl1300Return.getRetour();
  }

  /**
   * This activity sends the files by mail.
   *
   * @param tracabilite_p
   *          The {@link Tracabilite}
   * @return The {@link Retour}
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP287_BL400_EnvoiMail(Tracabilite tracabilite_p) throws RavelException
  {
    File directory = new File(_processContext.getRepertoireWork());
    File[] listOfFiles = directory.listFiles();
    boolean unsentFiles = false;
    Retour retour = RetourFactory.createOkRetour();
    ConnectorResponse<Boolean, GenericError<Integer>> sendMailResp = null;

    for (File file : listOfFiles)
    {
      sendMailResp = SMTPProxy.getInstance().sendMail(tracabilite_p.getIdCorrelationSpirit(), _processContext.getFromAddress(), _processContext.getReplyToAddress(), _processContext.getListeDiffusion(), _processContext.getCcAddress(), SUIVI_CONSOMMATION_ESIM, StringConstants.EMPTY_STRING, file.getAbsolutePath(), MediaType.TEXT_CSV);

      if (sendMailResp._first)
      {
        BL1200_DeplacerFichier bl1200Resp = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(file.getName()).repertoireDes(_processContext.getRepertoireArchive()).repertoireSrc(_processContext.getRepertoireWork()).build();
        bl1200Resp.execute(this);

        retour = bl1200Resp.getRetour();

        if (!isRetourOK(retour))
        {
          unsentFiles = true;
          retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DEPLACEMENT_FICHIER_INVALIDE, Messages.getString("PP0287_CreerFichiersKPI.ImpossibleMoveFile")); //$NON-NLS-1$
        }
      }
      else
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, sendMailResp._second.getReason()));
        unsentFiles = true;
      }
    }

    if (unsentFiles)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, Messages.getString("PP0287_CreerFichiersKPI.ImpossibleSendEmail")); //$NON-NLS-1$
    }

    return retour;
  }

  /**
   * Gets the statisques Esim and write them to the created file.
   *
   * @param typeReport_p
   *          the type of report to add to the file name
   * @param fileName_p
   *          the file name
   * @param tracabilite_p
   *          the tracabilite
   * @return {@link Retour}
   */
  private Retour writeStatsEsimToFile(String typeReport_p, String fileName_p, Tracabilite tracabilite_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    CSVLine body = null;
    CSVFileWriter writer = null;

    try
    {
      writer = new CSVFileWriter(Paths.get(_processContext.getRepertoireWork() + fileName_p).toFile());

      CSVLine header = createHeaderLine(typeReport_p);
      writer.append(header);
      StringBuilder values = null;

      for (StatistiqueEsim statistiqueEsim : _processContext.getStatistiquesEsim())
      {
        values = createValuesLine(statistiqueEsim, typeReport_p);
        body = new CSVLine(values.toString());
        writer.append(body);
      }

      writer.flush();
      writer.close();
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception.getMessage()));
      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, fileName_p);
    }
    return retour;
  }
}
