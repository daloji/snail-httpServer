/*******************************************************************************
* $Id: RelType.java 7839 2018-07-13 10:14:50Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PE0195.structs;

/**
 *
 * @author lmerces
 * @version ($Revision: 7839 $ $Date: 2018-07-13 12:14:50 +0200 (ven. 13 juil. 2018) $)
 */
public enum RelType
{
  /**
   *
   */
  SELF("self"), //$NON-NLS-1$

  /**
   *
   */
  TERMINE("termines"), //$NON-NLS-1$

  /**
   *
   */
  EN_COURS("enCours"); //$NON-NLS-1$

  /**
   * constString variable
   */
  private final String _constString;

  /**
   * Enum Constructor with a string as parameter
   *
   * @param constString_p
   *          constString
   */
  RelType(String constString_p)
  {
    this._constString = constString_p;
  }

  @Override
  public String toString()
  {
    return this._constString;
  }
}
