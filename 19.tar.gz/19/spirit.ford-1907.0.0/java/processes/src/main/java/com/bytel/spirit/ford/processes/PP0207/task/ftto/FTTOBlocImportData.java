/*******************************************************************************
* $Id: FTTOBlocImportData.java 14226 2018-12-06 15:29:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.task.ftto;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.spirit.common.shared.saab.res.CouvertureFtto;
import com.bytel.spirit.ford.processes.PP0207.task.IBlocImportData;

/**
 * Transition data for FTTO couverture multi-threaded import.
 *
 * @author jstrub
 * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
 */
public class FTTOBlocImportData implements IBlocImportData<CouvertureFtto>
{
  /** Simple list : will be used by one thread at a time. */
  private final List<CouvertureFtto> _blocLines = new ArrayList<>();

  @Override
  public void addLine(CSVLine line_p)
  {
    CouvertureFtto couvertureFtto = new CouvertureFtto(line_p.getString(0));
    couvertureFtto.setNroFTTOoA(line_p.getString(1));
    couvertureFtto.setNroFTTOoH(line_p.getString(2));
    _blocLines.add(couvertureFtto);
  }

  @Override
  public List<CouvertureFtto> getBloc()
  {
    return Collections.unmodifiableList(_blocLines);
  }

  @Override
  public boolean isEmpty()
  {
    return _blocLines.isEmpty();
  }

  @Override
  public int size()
  {
    return _blocLines.size();
  }

}
