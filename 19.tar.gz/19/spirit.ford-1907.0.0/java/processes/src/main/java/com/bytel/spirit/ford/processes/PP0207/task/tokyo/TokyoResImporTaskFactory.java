/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.task.tokyo;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.task.ITransitionData;
import com.bytel.spirit.common.shared.saab.res.CouvertureTokyo;
import com.bytel.spirit.ford.processes.PP0207.task.AbstractRESImportTask;
import com.bytel.spirit.ford.processes.PP0207.task.AbstractRESImportTaskFactory;
import com.bytel.spirit.ford.processes.PP0207.task.ImportContext;
import com.bytel.spirit.ford.processes.PP0207.task.tokyo.TokyoResImporTaskFactory.TokyoResImporTask;
import com.bytel.spirit.saab.connectors.res.RESDatabaseProxy;

/**
 *
 * RES import task factory for Tokyo couverture multi-threaded import.<br />
 * See {@link AbstractRESImportTaskFactory} for more information.
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class TokyoResImporTaskFactory extends AbstractRESImportTaskFactory<TokyoResImporTask>
{

  /**
   * RES import task for Tokyo couverture multi-threaded import.<br />
   * See {@link AbstractRESImportTask} for more information.
   *
   * @author pescudei
   * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
   */
  public static class TokyoResImporTask extends AbstractRESImportTask<CouvertureTokyo>
  {

    /** DESCRIPTION */
    private static final String TASK_DESCRIPTION = FACTORY_DESCRIPTION + "-Task"; //$NON-NLS-1$

    /**
     * @param dataToImport_p
     *          the bloc data to import
     * @param context_p
     *          the context
     */
    public TokyoResImporTask(TokyoBlocImportData dataToImport_p, ImportContext context_p)
    {
      super(dataToImport_p, context_p);
    }

    @Override
    public String description()
    {
      return TASK_DESCRIPTION;
    }

    @Override
    protected ConnectorResponse<Retour, Integer> importData()
    {
      try
      {
        return RESDatabaseProxy.getInstance().createCouvertureTokyo(_context.getTracabilite(), _dataToImport.getBloc());
      }
      catch (RavelException e_p)
      {
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), _dataToImport.size());
      }
    }

  }

  /** DESCRIPTION */
  private static final String FACTORY_DESCRIPTION = "RES-Import-Tokyo"; //$NON-NLS-1$

  /**
   * @param context_p
   *          the context
   */
  public TokyoResImporTaskFactory(ImportContext context_p)
  {
    super(context_p);
  }

  @Override
  public String description()
  {
    return FACTORY_DESCRIPTION;
  }

  @Override
  public TokyoResImporTask newTask(ITransitionData transitionData_p) throws RavelException
  {
    if (TokyoBlocImportData.class.isInstance(transitionData_p))
    {
      return new TokyoResImporTask((TokyoBlocImportData) transitionData_p, _context);
    }

    return null;
  }

}
