/*******************************************************************************
* $Id: Periodicite.java 15669 2019-01-11 10:46:05Z asoares $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0287.structs;

/**
 * The enum of the uri parameter periodicité.
 *
 * @author asoares
 * @version ($Revision: 15669 $ $Date: 2019-01-11 11:46:05 +0100 (ven. 11 janv. 2019) $)
 */
public enum Periodicite
{
  /**
   * Date Courante
   */
  DATE_COURANTE("dateCourante"), //$NON-NLS-1$

  /**
   * Changement Etat Semaine
   */
  CHANGEMENT_ETAT_SEMAINE("changementEtatSemaine"), //$NON-NLS-1$

  /**
   * Changement Etat Mois
   */
  CHANGEMENT_ETAT_MOIS("changementEtatMois"); //$NON-NLS-1$

  /**
   * Compares the input value against the values of the {@link Periodicite}.
   *
   * @param value_p
   *          the value to compare
   * @return {@link Periodicite}
   */
  public static Periodicite fromValue(String value_p)
  {
    for (Periodicite periodicite : Periodicite.values())
    {
      if (periodicite._value.equalsIgnoreCase(value_p))
      {
        return periodicite;
      }
    }
    return null;
  }

  /**
   * The value
   */
  private final String _value;

  /**
   * The constructor.
   *
   * @param value_p
   *          the value
   */
  private Periodicite(String value_p)
  {
    _value = value_p;
  }

  /**
   * @return value
   */
  public String value()
  {
    return _value;
  }
}
