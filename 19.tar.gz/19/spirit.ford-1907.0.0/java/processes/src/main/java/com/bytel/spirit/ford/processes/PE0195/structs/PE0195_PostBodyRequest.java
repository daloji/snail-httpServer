/*******************************************************************************
* $Id: PE0195_PostBodyRequest.java 7839 2018-07-13 10:14:50Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PE0195.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author pcarreir
 * @version ($Revision: 7839 $ $Date: 2018-07-13 12:14:50 +0200 (ven. 13 juil. 2018) $)
 */
public class PE0195_PostBodyRequest implements Serializable
{

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = -8456815812598112432L;

  /**
   * clientOperateur attribute
   */
  @SerializedName("clientOperateur")
  @Expose
  private String _clientOperateur;

  /**
   * typeTraitementDeMasse attribute
   */
  @SerializedName("typeTraitementDeMasse")
  @Expose
  private String _typeTraitementDeMasse;

  /**
   * nomFichier attribute
   */
  @SerializedName("nomFichier")
  @Expose
  private String _nomFichier;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0195_PostBodyRequest other = (PE0195_PostBodyRequest) obj;
    if (_clientOperateur == null)
    {
      if (other._clientOperateur != null)
      {
        return false;
      }
    }
    else if (!_clientOperateur.equals(other._clientOperateur))
    {
      return false;
    }
    if (_nomFichier == null)
    {
      if (other._nomFichier != null)
      {
        return false;
      }
    }
    else if (!_nomFichier.equals(other._nomFichier))
    {
      return false;
    }
    if (_typeTraitementDeMasse == null)
    {
      if (other._typeTraitementDeMasse != null)
      {
        return false;
      }
    }
    else if (!_typeTraitementDeMasse.equals(other._typeTraitementDeMasse))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the nomFichier
   */
  public String getNomFichier()
  {
    return _nomFichier;
  }

  /**
   * @return the typeTraitementDeMasse
   */
  public String getTypeTraitementDeMasse()
  {
    return _typeTraitementDeMasse;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_clientOperateur == null) ? 0 : _clientOperateur.hashCode());
    result = (prime * result) + ((_nomFichier == null) ? 0 : _nomFichier.hashCode());
    result = (prime * result) + ((_typeTraitementDeMasse == null) ? 0 : _typeTraitementDeMasse.hashCode());
    return result;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param nomFichier_p
   *          the nomFichier to set
   */
  public void setNomFichier(String nomFichier_p)
  {
    _nomFichier = nomFichier_p;
  }

  /**
   * @param typeTraitementDeMasse_p
   *          the typeTraitementDeMasse to set
   */
  public void setTypeTraitementDeMasse(String typeTraitementDeMasse_p)
  {
    _typeTraitementDeMasse = typeTraitementDeMasse_p;
  }

  @Override
  public String toString()
  {
    return "PE0195_PostBodyRequest [_clientOperateur=" + _clientOperateur + ", _typeTraitementDeMasse=" + _typeTraitementDeMasse + ", _nomFichier=" + _nomFichier + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
  }
}
