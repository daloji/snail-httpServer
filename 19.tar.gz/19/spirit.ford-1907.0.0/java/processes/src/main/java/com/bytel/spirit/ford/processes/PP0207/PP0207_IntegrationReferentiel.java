/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207;

import static java.util.Objects.nonNull;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringJoiner;

import com.bytel.spirit.saab.connectors.res.geod.type.TypeReferentiel;
import org.apache.commons.io.FilenameUtils;
import org.apache.cxf.common.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.csv.CSVFileWriter;
import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.IUrlParameters;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.ftp.FTPProxy;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.ravel.services.process.task.IRavelThreadedEngine;
import com.bytel.ravel.services.process.task.RavelTaskConfig.RavelTaskConfigBuilder;
import com.bytel.ravel.services.process.task.RavelThreadedEngineManager;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.eligprev.config.ConfigFichier;
import com.bytel.spirit.common.eligprev.config.ConfigGroupeFichier;
import com.bytel.spirit.common.eligprev.config.ConfigGroupeFichierListe;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.EtatReferentiel;
import com.bytel.spirit.common.shared.saab.res.FichierOrigine;
import com.bytel.spirit.common.shared.saab.res.FichierReferentielComposite;
import com.bytel.spirit.common.shared.saab.res.GestionReferentiel;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0207.structs.FichierAIntegrer;
import com.bytel.spirit.ford.processes.PP0207.task.ImportContext;
import com.bytel.spirit.ford.processes.PP0207.task.cuivre.CuivreCSVReaderTask;
import com.bytel.spirit.ford.processes.PP0207.task.cuivre.CuivreCSVReaderTaskFactory;
import com.bytel.spirit.ford.processes.PP0207.task.cuivre.CuivreResImporTaskFactory;
import com.bytel.spirit.ford.processes.PP0207.task.cuivre.CuivreResImporTaskFactory.CuivreResImporTask;
import com.bytel.spirit.ford.processes.PP0207.task.ftto.FTTOCSVReaderTask;
import com.bytel.spirit.ford.processes.PP0207.task.ftto.FTTOCSVReaderTaskFactory;
import com.bytel.spirit.ford.processes.PP0207.task.ftto.FTTOResImporTaskFactory;
import com.bytel.spirit.ford.processes.PP0207.task.ftto.FTTOResImporTaskFactory.FTTOResImporTask;
import com.bytel.spirit.ford.processes.PP0207.task.tokyo.TokyoCSVReaderTask;
import com.bytel.spirit.ford.processes.PP0207.task.tokyo.TokyoCSVReaderTaskFactory;
import com.bytel.spirit.ford.processes.PP0207.task.tokyo.TokyoResImporTaskFactory;
import com.bytel.spirit.ford.processes.PP0207.task.tokyo.TokyoResImporTaskFactory.TokyoResImporTask;
import com.bytel.spirit.saab.connectors.res.RESDatabaseProxy;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PP0207_IntegrationReferentiel extends SpiritProcessSkeleton
{
  /**
   * Holds context data for PP0207_IntegrationReferentielContext
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public static final class PP0207_IntegrationReferentielContext extends Context
  {
    /**
     * Serial UID
     */
    private static final long serialVersionUID = -8276312806798359736L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PP0207_START;

    /**
     * Contains the process retour.
     */
    private Retour _processRetour;

    /**
     * ReponseErreur from BL002
     */
    private ReponseErreur _reponseErreur;

    /**
     * The tracability
     */
    private Tracabilite _tracabilite;

    /**
     * The type referentiel
     */
    private TypeReferentiel _typeReferentiel;

    /**
     * List of the Name of files to integrate
     */
    private List<String> _listeNameFichiersAIntegrer;

    /**
     * ConfigGroupeFichier
     */
    private transient ConfigGroupeFichier _configGroupeFichier;

    /**
     * @return value of _configGroupeFichier
     */
    public ConfigGroupeFichier getConfigGroupeFichier()
    {
      return _configGroupeFichier;
    }

    /**
     * @return the listeFichiersAIntegrer
     */
    public List<String> getListeNameFichiersAIntegrer()
    {
      return new ArrayList<>(_listeNameFichiersAIntegrer);
    }

    /**
     * @return value of _processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the reponseErreur
     */
    public ReponseErreur getReponseErreur()
    {
      return _reponseErreur;
    }

    /**
     * @return value of state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return value of _tracabilite
     */
    public Tracabilite getTracabilite()
    {
      return _tracabilite;
    }

    /**
     * @return value of _typeReferentiel
     */
    public TypeReferentiel getTypeReferentiel()
    {
      return _typeReferentiel;
    }

    /**
     * @param configGroupeFichier_p
     *          The _configGroupeFichier to set.
     */
    public void setConfigGroupeFichier(ConfigGroupeFichier configGroupeFichier_p)
    {
      _configGroupeFichier = configGroupeFichier_p;
    }

    /**
     * @param listeNameFichiersAIntegrer_p
     *          the listeFichiersAIntegrer to set
     */
    public void setListeNameFichiersAIntegrer(List<String> listeNameFichiersAIntegrer_p)
    {
      _listeNameFichiersAIntegrer = listeNameFichiersAIntegrer_p == null ? new ArrayList<>() : new ArrayList<>(listeNameFichiersAIntegrer_p);
    }

    /**
     * @param processRetour_p
     *          The _processRetour to set.
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param reponseErreur_p
     *          the reponseErreur to set
     */
    public void setReponseErreur(ReponseErreur reponseErreur_p)
    {
      _reponseErreur = reponseErreur_p;
    }

    /**
     * @param state_p
     *          The state to set.
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param tracabilite_p
     *          The _tracabilite to set.
     */
    public void setTracabilite(Tracabilite tracabilite_p)
    {
      _tracabilite = tracabilite_p;
    }

    /**
     * @param typeReferentiel_p
     *          The _typeReferentiel to set.
     */
    public void setTypeReferentiel(TypeReferentiel typeReferentiel_p)
    {
      _typeReferentiel = typeReferentiel_p;
    }
  }

  /**
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * Step to call START
     */
    PP0207_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call BL001
     */
    PP0207_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL100
     */
    PP0207_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PP0207_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL400
     */
    PP0207_BL400(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL002
     */
    PP0207_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call END
     */
    PP0207_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }

  }

  /**
   * Serial UID
   */
  private static final long serialVersionUID = 6872387934921691598L;

  /**
   * The constant for PP0207.BL001_VerifierDonnes message
   */
  private static final String MESSAGE_BL001_VERIFIER_DONNES = Messages.getString("PP0207.BL001_VerifierDonnes"); //$NON-NLS-1$

  /**
   * The constant for PP0207._BL001_VerifierDonnesGeneric message
   */
  private static final String MESSAGE_BL001_VERIFIER_DONNES_GENERIC = Messages.getString("PP0207.BL001_VerifierDonnesGeneric"); //$NON-NLS-1$

  /**
   * The constant for PP0207.VerifierParam message
   */
  private static final String MESSAGE_VERIFIER_PARAM = Messages.getString("PP0207.VerifierParam"); //$NON-NLS-1$

  /**
   * The constant for PP0207._BL0100_MissingFiles message
   */
  private static final String MESSAGE_BL100_MISSING_FLES = Messages.getString("PP0207.BL100_MissingFiles"); //$NON-NLS-1$

  /**
   * The constant for PP0207._BL0100_Indexincoherent message
   */
  private static final String MESSAGE_BL100_INCOHERENT_INDEX = Messages.getString("PP0207.BL100_Indexincoherent"); //$NON-NLS-1$

  /**
   * The constant for PP0207._BL100_GroupeFichiersObsolete message
   */
  private static final String MESSAGE_BL100_OBSOLETE = Messages.getString("PP0207.BL100_GroupeFichiersObsolete"); //$NON-NLS-1$

  /**
   * LOG_DELTA_LIGNE
   */
  private static final String LOG_DELTA_LIGNE = Messages.getString("PP0207.LOG_DELTA_LIGNE"); //$NON-NLS-1$
  /**
   * LOG_CONFIG
   */
  private static final String LOG_CONFIG = Messages.getString("PP0207.LOG_CONFIG"); //$NON-NLS-1$
  /**
   * LOG_NBLIGNES_OK
   */
  private static final String LOG_NBLIGNES_OK = Messages.getString("PP0207.LOG_NBLIGNES_OK"); //$NON-NLS-1$
  /**
   * LOG_NBLIGNES_EVOL
   */
  private static final String LOG_NBLIGNES_EVOL = Messages.getString("PP0207.LOG_NBLIGNES_EVOL"); //$NON-NLS-1$
  /**
   * LOG_BASCULE_OK
   */
  private static final String LOG_BASCULE_OK = Messages.getString("PP0207.LOG_BASCULE_OK"); //$NON-NLS-1$

  /**
   * The constant for PP0207.FileError message
   */
  private static final String MESSAGE_FILE_ERROR = Messages.getString("PP0207.FileError"); //$NON-NLS-1$

  /**
   * The constant for PP0207.NoParam message
   */
  private static final String MESSAGE_NO_PARAM = Messages.getString("PP0207.NoParam"); //$NON-NLS-1$

  /**
   * The constant for PP0207.UnexpectedContinueProcessReceived message
   */
  private static final String MESSAGE_UNEXPECTED_CONTINUE_PROCESS_RECEIVED = Messages.getString("PP0207.UnexpectedContinueProcessReceived"); //$NON-NLS-1$

  /**
   * The type referentiel parameter constant
   */
  private static final String TYPE_REFERENTIEL_PARAMETER = "typeReferentiel"; //$NON-NLS-1$

  /**
   * ConfigGroupeFichier Param
   */
  private static final String CONFGF_PARAM = "FILE_PATH"; //$NON-NLS-1$

  /**
   * CUIVRE_THREAD_CORE
   */
  private static final String CONFG_CUIVRE_THREAD_CORE = "CUIVRE_THREAD_CORE"; //$NON-NLS-1$

  /**
   * CONFG_CUIVRE_THREAD_MAX
   */
  private static final String CONFG_CUIVRE_THREAD_MAX = "CUIVRE_THREAD_MAX"; //$NON-NLS-1$

  /**
   * CUIVRE_THREAD_QUEUE
   */
  private static final String CONFG_CUIVRE_THREAD_QUEUE = "CUIVRE_THREAD_QUEUE"; //$NON-NLS-1$

  /**
   * CONFG_CUIVRE_TIMEOUT_GLOBAL
   */
  private static final String CONFG_CUIVRE_TIMEOUT_GLOBAL_SEC = "CUIVRE_TIMEOUT_GLOBAL_SEC"; //$NON-NLS-1$

  /**
   * CONFG_CUIVRE_TIMEOUT_TASK
   */
  private static final String CONFG_CUIVRE_TIMEOUT_TASK_SEC = "CUIVRE_TIMEOUT_TASK_SEC"; //$NON-NLS-1$

  /**
   * FTTO_THREAD_CORE
   */
  private static final String CONFG_FTTO_THREAD_CORE = "FTTO_THREAD_CORE"; //$NON-NLS-1$

  /**
   * CONFG_FTTO_THREAD_MAX
   */
  private static final String CONFG_FTTO_THREAD_MAX = "FTTO_THREAD_MAX"; //$NON-NLS-1$

  /**
   * FTTO_THREAD_QUEUE
   */
  private static final String CONFG_FTTO_THREAD_QUEUE = "FTTO_THREAD_QUEUE"; //$NON-NLS-1$

  /**
   * CONFG_FTTO_TIMEOUT_GLOBAL
   */
  private static final String CONFG_FTTO_TIMEOUT_GLOBAL_SEC = "FTTO_TIMEOUT_GLOBAL_SEC"; //$NON-NLS-1$

  /**
   * CONFG_FTTO_TIMEOUT_TASK
   */
  private static final String CONFG_FTTO_TIMEOUT_TASK_SEC = "FTTO_TIMEOUT_TASK_SEC"; //$NON-NLS-1$

  /**
   * TOKYO_THREAD_CORE
   */
  private static final String CONFG_TOKYO_THREAD_CORE = "TOKYO_THREAD_CORE"; //$NON-NLS-1$

  /**
   * CONFG_TOKYO_THREAD_MAX
   */
  private static final String CONFG_TOKYO_THREAD_MAX = "TOKYO_THREAD_MAX"; //$NON-NLS-1$

  /**
   * TOKYO_THREAD_QUEUE
   */
  private static final String CONFG_TOKYO_THREAD_QUEUE = "TOKYO_THREAD_QUEUE"; //$NON-NLS-1$

  /**
   * CONFG_TOKYO_TIMEOUT_GLOBAL
   */
  private static final String CONFG_TOKYO_TIMEOUT_GLOBAL_SEC = "TOKYO_TIMEOUT_GLOBAL_SEC"; //$NON-NLS-1$

  /**
   * CONFG_TOKYO_TIMEOUT_TASK
   */
  private static final String CONFG_TOKYO_TIMEOUT_TASK_SEC = "TOKYO_TIMEOUT_TASK_SEC"; //$NON-NLS-1$

  /**
   * FILE_SEPARATOR
   */
  private static final String FILE_SEPARATOR = File.separator;

  /**
   * CSV File separator
   */
  private static final String SEMICOLON = ";"; //$NON-NLS-1$

  /**
   * TAUX_LIGNES_KO
   */
  private static final String TAUX_LIGNES_KO = " Taux lignes de KO "; //$NON-NLS-1$

  /**
   * TAUX_DE_EVOLUTION
   */
  private static final String TAUX_DE_EVOLUTION = " Taux d'evolution "; //$NON-NLS-1$

  /**
   * The constant for PP0207.Exception message
   */
  private static final String MESSAGE_PROCESS_EXCEPTION = Messages.getString("PP0207.Exception"); //$NON-NLS-1$

  /**
   * Authorized values for typeReferentiel
   */
  private String[] _typeReferentielAuthorizedValues = { "COUV_FTTO", "COUV_CUIVRE", "COUV_TOKYO" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

  /**
   * Process context instance
   */
  private PP0207_IntegrationReferentielContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    if (retour_p != null)
    {
      return MarshallTools.marshall(retour_p);
    }
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PP0207_IntegrationReferentielContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, MESSAGE_UNEXPECTED_CONTINUE_PROCESS_RECEIVED);
  }

  @Override
  protected void exitKOMetroLog(String s_p)
  {
    // Not required for now in Ravel
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      // Get traçabilite
      _processContext.setTracabilite(tracabilite_p);

      // Get the process parameters
      IUrlParameters parameters = request_p.getUrlParameters();
      _processContext.setTypeReferentiel(null);
      for (Parameter parameter : parameters.getUrlParameters())
      {
        if (TYPE_REFERENTIEL_PARAMETER.equals(parameter.getName()))
        {
          try
          {
            _processContext.setTypeReferentiel(TypeReferentiel.valueOf(parameter.getValue()));
          }
          catch (Exception exception)
          {
            String libelle = MessageFormat.format(MESSAGE_VERIFIER_PARAM, parameter.getValue());
            _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, libelle));
          }
          break;
        }
      }

      if (_processContext.getProcessRetour() == null)
      {
        // Call BL001
        _processContext.setState(State.PP0207_BL001);
        Pair<Retour, ConfigGroupeFichier> retourBl001 = PP0207_BL001_VerifierDonnes(tracabilite_p);
        _processContext.setConfigGroupeFichier(retourBl001._second);
        _processContext.setProcessRetour(retourBl001._first);

        if (RetourFactory.isRetourOK(retourBl001._first))
        {
          // Call BL100
          _processContext.setState(State.PP0207_BL100);
          Retour retourBL100 = PP0207_BL100_RecupererFichiers(tracabilite_p, _processContext.getConfigGroupeFichier(), _processContext.getTypeReferentiel());
          _processContext.setProcessRetour(retourBL100);

          if (RetourFactory.isRetourOK(retourBL100))
          {
            // Call BL200
            _processContext.setState(State.PP0207_BL200);
            Pair<Retour, List<FichierAIntegrer>> retourBl200 = PP0207_BL200_CreerReference(tracabilite_p, _processContext.getConfigGroupeFichier(), _processContext.getTypeReferentiel());
            _processContext.setProcessRetour(retourBl200._first);
            if (RetourFactory.isRetourOK(retourBl200._first))
            {
              // Call BL400
              _processContext.setState(State.PP0207_BL400);
              Retour retourBl400 = PP0207_BL400_GererCR(tracabilite_p, retourBl200._second, _processContext.getTypeReferentiel());
              _processContext.setProcessRetour(retourBl400);
            }
          }
        }
      }

      //Call BL002 FormaterReponse
      _processContext.setState(State.PP0207_BL002);
      Pair<ReponseErreur, Retour> retourBL002 = PP0207_BL002_FormaterReponse(tracabilite_p, _processContext.getProcessRetour());
      _processContext.setProcessRetour(retourBL002._second);
      _processContext.setReponseErreur(retourBL002._first);

    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, e));
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_PROCESS_EXCEPTION, e.getMessage())));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()));
    }

    finally
    {
      endSynchronousProcess(request_p, _processContext.getProcessRetour());
    }

    // Result for auto logging.
    setRetour(_processContext.getProcessRetour());

    // Set end state
    _processContext.setState(State.PP0207_END);
  }

  /**
   * This method archives all the files manipulated by the process
   *
   * @param configGroupeFichier_p
   *          configGroupeFichier
   * @param tracabilite_p
   *          tracabilite
   * @param oknokString_p
   *          ok or nok
   * @return retour
   * @throws RavelException
   *           on error
   */
  private Retour archiverFichiers(ConfigGroupeFichier configGroupeFichier_p, Tracabilite tracabilite_p, String oknokString_p) throws RavelException
  {
    // Moving files from the working directory to the archive
    String repArchiveDest = configGroupeFichier_p.getCheminRepArchive() + FILE_SEPARATOR + oknokString_p + FILE_SEPARATOR;
    String repTravailSrc = configGroupeFichier_p.getCheminRepTravail() + FILE_SEPARATOR;

    //Retrieve the name of all files in work directory, in order to move them to KO directory
    String[] fileNameList = new File(configGroupeFichier_p.getCheminRepTravail()).list();
    for (String fichierName : fileNameList)
    {
      // Call BL1200
      BL1200_DeplacerFichier resBL1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(fichierName).repertoireDes(repArchiveDest).repertoireSrc(repTravailSrc).build();
      resBL1200.execute(this);
      if (!isRetourOK(resBL1200.getRetour()))
      {
        return resBL1200.getRetour();
      }

    }
    return RetourFactory.createOkRetour();
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param paramName_p
   *          param name
   * @return retour
   */
  private Retour checkParameter(Tracabilite tracabilite_p, String paramName_p)
  {
    Integer value = getIntConfigParameter(paramName_p);
    if (value == null)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(MESSAGE_NO_PARAM, CONFGF_PARAM)));
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, CONFGF_PARAM));
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Method to end synchronous process
   *
   * @param request_p
   *          Request parameter
   * @param retour_p
   *          Retour parameter
   * @throws RavelException
   *           RavelException
   */
  private void endSynchronousProcess(Request request_p, Retour retour_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ravelResponse.setResult(createDefaultFunctionalResponse(retour_p));

      Response response = new Response(isRetourOK(retour_p) ? ErrorCode.OK_00000 : ErrorCode.PRCESS_00002, ravelResponse);
      request_p.setResponse(response);
    }
  }

  /**
   * Get and parse as an integer a parameter from his name.
   *
   * @param paramName_p
   *          parameter name
   * @return parameter value as parsed as Integer
   */
  private Integer getIntConfigParameter(String paramName_p)
  {
    String paramValue = getConfigParameter(paramName_p);
    if (paramValue == null)
    {
      return null;
    }

    return Integer.valueOf(paramValue);
  }

  /**
   * This small method extracts the file name from the pattern. The pattern should follow
   * COUVERTURE_FTTO_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv // COUVERTURE_CUIVRE_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv
   *
   * @param fileName_p
   *          fileName
   * @return name
   */
  private String getPattern(String fileName_p)
  {
    final String[] values = fileName_p.substring(0, fileName_p.lastIndexOf(".")).split("_"); //$NON-NLS-1$ //$NON-NLS-2$
    final StringJoiner joiner = new StringJoiner("_"); //$NON-NLS-1$
    for (int i = 0; i < (values.length - 2); i++)
    {
      joiner.add(values[i]);
    }

    return 0 == joiner.length() ? null : joiner.toString();
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @return ConfigGroupeFichier
   */
  @LogProcessBL
  private Pair<Retour, ConfigGroupeFichier> PP0207_BL001_VerifierDonnes(Tracabilite tracabilite_p)
  {
    // check Type referential
    if (_processContext.getTypeReferentiel() == null)
    {
      String libelle = MessageFormat.format(MESSAGE_BL001_VERIFIER_DONNES, TYPE_REFERENTIEL_PARAMETER);
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, libelle), null);
    }

    // Check multi-threading configuration
    try
    {
      if (TypeReferentiel.COUV_CUIVRE.equals(_processContext.getTypeReferentiel()))
      {
        Retour retour = checkParameter(tracabilite_p, CONFG_CUIVRE_THREAD_MAX);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_CUIVRE_THREAD_CORE);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_CUIVRE_THREAD_QUEUE);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_CUIVRE_TIMEOUT_GLOBAL_SEC);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_CUIVRE_TIMEOUT_TASK_SEC);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
      }
      else if (TypeReferentiel.COUV_FTTO.equals(_processContext.getTypeReferentiel()))
      {
        Retour retour = checkParameter(tracabilite_p, CONFG_FTTO_THREAD_MAX);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_FTTO_THREAD_CORE);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_FTTO_THREAD_QUEUE);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_FTTO_TIMEOUT_GLOBAL_SEC);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_FTTO_TIMEOUT_TASK_SEC);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
      }
      else if (TypeReferentiel.COUV_TOKYO.equals(_processContext.getTypeReferentiel()))
      {
        Retour retour = checkParameter(tracabilite_p, CONFG_TOKYO_THREAD_MAX);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_TOKYO_THREAD_CORE);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_TOKYO_THREAD_QUEUE);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_TOKYO_TIMEOUT_GLOBAL_SEC);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
        retour = checkParameter(tracabilite_p, CONFG_TOKYO_TIMEOUT_TASK_SEC);
        if (RetourFactory.isRetourKO(retour))
        {
          return new ConnectorResponse<>(retour, null);
        }
      }
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, exception));
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_FILE_ERROR, exception.getMessage())), null);
    }

    String configGroupeFichierParam = getConfigParameter(CONFGF_PARAM);

    if (!StringTools.isNullOrEmpty(configGroupeFichierParam))
    {
      try
      {
        Path configGroupeFichierPath = Paths.get(configGroupeFichierParam);
        String configGroupeFichierFile = new String(Files.readAllBytes(configGroupeFichierPath));
        ConfigGroupeFichierListe configGroupeFichierListe = MarshallTools.unmarshall(ConfigGroupeFichierListe.class, configGroupeFichierFile);
        for (ConfigGroupeFichier element : configGroupeFichierListe.getConfigGroupeFichier())
        {
          if (_processContext.getTypeReferentiel().name().equals(element.getTypeReferentiel()))
          {
            _processContext.setConfigGroupeFichier(element);
            break;
          }
        }
      }
      catch (Exception exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, exception));
        return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_FILE_ERROR, exception.getMessage())), null);
      }
    }
    else
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, CONFGF_PARAM)), null);
    }

    //Validate ConfigGroupeFichier

    // check Type referential
    if (((_processContext.getConfigGroupeFichier()) == null) || StringTools.isNullOrEmpty(_processContext.getConfigGroupeFichier().getTypeReferentiel()) || !_processContext.getTypeReferentiel().name().equals(_processContext.getConfigGroupeFichier().getTypeReferentiel()))
    {
      String libelle = MessageFormat.format(MESSAGE_BL001_VERIFIER_DONNES, _processContext.getTypeReferentiel().name());
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, libelle), null);
    }
    if (!Arrays.asList(_typeReferentielAuthorizedValues).contains(_processContext.getTypeReferentiel().name()))
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MESSAGE_BL001_VERIFIER_DONNES_GENERIC), null);
    }

    // check cheminRepTravail
    if (StringTools.isNullOrEmpty(_processContext.getConfigGroupeFichier().getCheminRepTravail()))
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MESSAGE_BL001_VERIFIER_DONNES_GENERIC), null);
    }

    // check cheminRepArchive
    if (StringTools.isNullOrEmpty(_processContext.getConfigGroupeFichier().getCheminRepArchive()))
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MESSAGE_BL001_VERIFIER_DONNES_GENERIC), null);
    }

    // check listeConfigFichiers
    if (CollectionUtils.isEmpty(_processContext.getConfigGroupeFichier().getConfigFichier()))
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MESSAGE_BL001_VERIFIER_DONNES_GENERIC), null);
    }

    // Return OK
    return new ConnectorResponse<>(RetourFactory.createOkRetour(), _processContext.getConfigGroupeFichier());
  }

  /**
   * Format response to the client
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param inRetour
   *          Retour to be formatted
   * @return {@link ReponseErreur}
   */
  @LogProcessBL
  private Pair<ReponseErreur, Retour> PP0207_BL002_FormaterReponse(Tracabilite tracabilite_p, Retour inRetour)
  {
    if (!RetourFactory.isRetourOK(inRetour))
    {
      ReponseErreur responseErreur = new ReponseErreur();
      responseErreur.setError(inRetour.getDiagnostic());
      responseErreur.setErrorDescription(inRetour.getLibelle());

      return new Pair<>(responseErreur, inRetour);
    }
    return new Pair<>(null, RetourFactory.createOkRetour());
  }

  /**
   * This activity validates the coherence between the files in the process workspace according to the protocol and
   * parameters defined by the operator.
   *
   * @param configGroupeFichier_p
   *          configGroupeFichier
   * @param typeReferentiel_p
   *          typeReferentiel
   *
   * @param tracabilite_p
   *          tracabilite
   *
   * @return List of files to integrate and the {@link Retour} object
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP0207_BL100_RecupererFichiers(Tracabilite tracabilite_p, ConfigGroupeFichier configGroupeFichier_p, TypeReferentiel typeReferentiel_p) throws RavelException
  {
    File folder = new File(configGroupeFichier_p.getCheminRepTravail());

    // Here we will store the highest index for each configFile
    String[] listIndex = new String[configGroupeFichier_p.getConfigFichier().size()];

    // Here we will store the names of the latest files
    List<String> filesAIntegrer = new ArrayList<>();
    String[] fileNameList = folder.list();
    for (int i = 0; i < configGroupeFichier_p.getConfigFichier().size(); i++)
    {
      ConfigFichier configFile = configGroupeFichier_p.getConfigFichier().get(i);
      String pattern = getPattern(configFile.getPattern());
      boolean foundFile = false;
      if ((fileNameList != null) && (fileNameList.length != 0))
      {
        for (String fileName : fileNameList)
        {
          final String expected = FilenameUtils.getExtension(configFile.getPattern());
          final String actual = FilenameUtils.getExtension(fileName);
          if (expected.equals(actual) && nonNull(pattern) && fileName.contains(pattern))
          {
            foundFile = true;
            //Retrieve file index
            String[] values = fileName.substring(0, fileName.lastIndexOf('.')).split("_"); //$NON-NLS-1$
            String index = (values[values.length - 1]).replaceAll("\\s*\\[(.*?)\\].*", "$1"); //$NON-NLS-1$ //$NON-NLS-2$
            if ((listIndex[i] == null) || (Integer.valueOf(index) > Integer.valueOf(listIndex[i])))
            {
              listIndex[i] = index;

              //Store file name
              if (filesAIntegrer.size() == i)
              {
                filesAIntegrer.add(fileName);
              }
              else
              {
                filesAIntegrer.set(i, fileName);
              }
            }
          }
        }
      }

      // If a file is missing
      if (!foundFile)
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.FICHIERS_INCOHERENTS, MessageFormat.format(MESSAGE_BL100_MISSING_FLES, typeReferentiel_p));
      }
    }
    // Check if all index are the same
    if (Arrays.stream(listIndex).distinct().count() != 1)
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.FICHIERS_INCOHERENTS, MessageFormat.format(MESSAGE_BL100_INCOHERENT_INDEX, typeReferentiel_p));
    }

    // We check that the files are newer (based on the index) than those already embedded in the repository
    ConnectorResponse<Retour, List<FichierReferentielComposite>> responseLireTous;
    try
    {
      responseLireTous = resfichierReferentielCompositeLireTous(tracabilite_p, typeReferentiel_p);
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, exception));
      throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, exception.getMessage(), exception.getCause());
    }

    if (isRetourOK(responseLireTous._first))
    {
      for (FichierReferentielComposite fichierReferentielComposite : responseLireTous._second)
      {
        if (!CollectionUtils.isEmpty(fichierReferentielComposite.getListeFichierOrigine()) && (Integer.valueOf(listIndex[0]) <= Integer.valueOf(fichierReferentielComposite.getListeFichierOrigine().get(0).getIndexFichier())))
        {
          //Move files to NOK repository
          Retour resBL1200 = archiverFichiers(configGroupeFichier_p, tracabilite_p, StringConstants.NOK);

          if (!isRetourOK(resBL1200))
          {
            return resBL1200;
          }
          return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.FICHIERS_OBSOLETES, MessageFormat.format(MESSAGE_BL100_OBSOLETE, typeReferentiel_p));
        }
      }
    }
    else if (IMegConsts.CAT4.equals(responseLireTous._first.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(responseLireTous._first.getDiagnostic()))
    {
      // This should be the first integration of this group of files. RAF
      // retour OK
    }
    else
    {
      // There's an execution error. Return NOK
      return responseLireTous._first;
    }

    _processContext.setListeNameFichiersAIntegrer(filesAIntegrer);
    return RetourFactory.createOkRetour();
  }

  /**
   * This activity initializes the integration on the database. parameters defined by the operator.
   *
   * @param configGroupeFichier_p
   *          configGroupeFichier
   * @param typeReferentiel_p
   *          typeReferentiel
   * @param tracabilite_p
   *          tracabilite
   *
   * @return List of files to integrate and the {@link Retour} object
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Pair<Retour, List<FichierAIntegrer>> PP0207_BL200_CreerReference(Tracabilite tracabilite_p, ConfigGroupeFichier configGroupeFichier_p, TypeReferentiel typeReferentiel_p) throws RavelException
  {
    List<FichierAIntegrer> listFichierAIntegrer = new ArrayList<>();

    ConnectorResponse<Retour, String> retourCreateReferentiel;
    try
    {
      retourCreateReferentiel = RESDatabaseProxy.getInstance().createGestionReferentiel(tracabilite_p, typeReferentiel_p);

      if (!isRetourOK(retourCreateReferentiel._first))
      {
        return new ConnectorResponse<>(retourCreateReferentiel._first, null);
      }
      for (int i = 0; i < configGroupeFichier_p.getConfigFichier().size(); i++)
      {
        FichierAIntegrer fichierAIntegrer = new FichierAIntegrer();
        String fileName = _processContext.getListeNameFichiersAIntegrer().get(i);
        String[] values = fileName.substring(0, fileName.lastIndexOf('.')).split("_"); //$NON-NLS-1$

        fichierAIntegrer.setTypeFichier(typeReferentiel_p.name());
        fichierAIntegrer.setFichierNom(fileName);
        String index = (values[values.length - 1]).replaceAll("\\s*\\[(.*?)\\].*", "$1"); //$NON-NLS-1$ //$NON-NLS-2$
        String date = (values[values.length - 2]).replaceAll("\\s*\\[(.*?)\\].*", "$1"); //$NON-NLS-1$ //$NON-NLS-2$
        fichierAIntegrer.setIndex(Integer.valueOf(index));
        fichierAIntegrer.setDate(DateTimeFormatPattern.yyyyMMdd.parse(date));
        fichierAIntegrer.setNbLignes(0);
        fichierAIntegrer.setNbLignesKO(0);
        fichierAIntegrer.setDeltaDeLigne(0);

        Pair<Retour, FichierAIntegrer> responseBl300 = PP0207_BL300_ImporterFichier(tracabilite_p, fichierAIntegrer, typeReferentiel_p, configGroupeFichier_p.getConfigFichier().get(i).getTailleListe());
        listFichierAIntegrer.add(responseBl300._second);
      }
      return new ConnectorResponse<>(RetourFactory.createOkRetour(), listFichierAIntegrer);

    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, exception));
      throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, exception.getMessage(), exception.getCause());
    }
  }

  /**
   * This activity parses and integrates the files in the database.
   *
   * @param fichierAIntegrer_p
   *          fichierAIntegrer
   * @param typeReferentiel_p
   *          typeReferentiel
   * @param tailleListe_p
   *          tailleListe
   *
   * @param tracabilite_p
   *          tracabilite
   *
   * @return List of files to integrate and the {@link Retour} object
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Pair<Retour, FichierAIntegrer> PP0207_BL300_ImporterFichier(Tracabilite tracabilite_p, FichierAIntegrer fichierAIntegrer_p, TypeReferentiel typeReferentiel_p, int tailleListe_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();

    File csvFile = Paths.get(_processContext.getConfigGroupeFichier().getCheminRepTravail() + FILE_SEPARATOR + fichierAIntegrer_p.getFichierNom()).toFile();
    ImportContext context = new ImportContext(tracabilite_p);
    IRavelThreadedEngine engine = RavelThreadedEngineManager.getInstance().newEngine();

    if (TypeReferentiel.COUV_FTTO.equals(typeReferentiel_p))
    {
      // Configure first step : read the file, validate STI and build blocs
      engine.addTask(new RavelTaskConfigBuilder<FTTOCSVReaderTask>()
          // Factory
          .factory(new FTTOCSVReaderTaskFactory(csvFile, SEMICOLON.charAt(0), StandardCharsets.UTF_8, tailleListe_p, typeReferentiel_p, context))
          // Technical configuration : use default value (1) for threading as file are read one by one ; use only global timeout
          .globalTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_FTTO_TIMEOUT_GLOBAL_SEC))).taskTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_FTTO_TIMEOUT_GLOBAL_SEC)))
          // Build
          .build());

      // Configure second step : receive bloc and try insert data through the RES-database proxy
      engine.addTask(new RavelTaskConfigBuilder<FTTOResImporTask>()
          // Factory
          .factory(new FTTOResImporTaskFactory(context))
          // Threads from process parameter
          .coreThreadNumber(getIntConfigParameter(CONFG_FTTO_THREAD_CORE)).maxThreadQueue(getIntConfigParameter(CONFG_FTTO_THREAD_QUEUE)).maxThreadNumber(getIntConfigParameter(CONFG_FTTO_THREAD_MAX))
          // Timeouts from process parameter
          .globalTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_FTTO_TIMEOUT_GLOBAL_SEC))).taskTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_FTTO_TIMEOUT_TASK_SEC)))
          // Build
          .build());
    }
    else if (TypeReferentiel.COUV_CUIVRE.equals(typeReferentiel_p))
    {
      // Configure first step : read the file, validate STI and build blocs
      engine.addTask(new RavelTaskConfigBuilder<CuivreCSVReaderTask>()
          // Factory
          .factory(new CuivreCSVReaderTaskFactory(csvFile, SEMICOLON.charAt(0), StandardCharsets.UTF_8, tailleListe_p, typeReferentiel_p, context))
          // Technical configuration : use default value (1) for threading as file are read one by one ; use only global timeout
          .globalTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_CUIVRE_TIMEOUT_GLOBAL_SEC))).taskTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_CUIVRE_TIMEOUT_GLOBAL_SEC)))
          // Build
          .build());

      // Configure second step : receive bloc and try insert data through the RES-database proxy
      engine.addTask(new RavelTaskConfigBuilder<CuivreResImporTask>()
          // Factory
          .factory(new CuivreResImporTaskFactory(context))
          // Threads from process parameter
          .coreThreadNumber(getIntConfigParameter(CONFG_CUIVRE_THREAD_CORE)).maxThreadQueue(getIntConfigParameter(CONFG_CUIVRE_THREAD_QUEUE)).maxThreadNumber(getIntConfigParameter(CONFG_CUIVRE_THREAD_MAX))
          // Timeouts from process parameter
          .globalTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_CUIVRE_TIMEOUT_GLOBAL_SEC))).taskTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_CUIVRE_TIMEOUT_TASK_SEC)))
          // Build
          .build());
    }
    else if (TypeReferentiel.COUV_TOKYO.equals(typeReferentiel_p))
    {
      // Configure first step : read the file, validate STI and build blocs
      engine.addTask(new RavelTaskConfigBuilder<TokyoCSVReaderTask>()
          // Factory
          .factory(new TokyoCSVReaderTaskFactory(csvFile, SEMICOLON.charAt(0), StandardCharsets.UTF_8, tailleListe_p, typeReferentiel_p, context))
          // Technical configuration : use default value (1) for threading as file are read one by one ; use only global timeout
          .globalTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_TOKYO_TIMEOUT_GLOBAL_SEC))).taskTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_TOKYO_TIMEOUT_GLOBAL_SEC)))
          // Build
          .build());

      // Configure second step : receive bloc and try insert data through the RES-database proxy
      engine.addTask(new RavelTaskConfigBuilder<TokyoResImporTask>()
          // Factory
          .factory(new TokyoResImporTaskFactory(context))
          // Threads from process parameter
          .coreThreadNumber(getIntConfigParameter(CONFG_TOKYO_THREAD_CORE)).maxThreadQueue(getIntConfigParameter(CONFG_TOKYO_THREAD_QUEUE)).maxThreadNumber(getIntConfigParameter(CONFG_TOKYO_THREAD_MAX))
          // Timeouts from process parameter
          .globalTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_TOKYO_TIMEOUT_GLOBAL_SEC))).taskTimeout(Duration.ofSeconds(getIntConfigParameter(CONFG_TOKYO_TIMEOUT_TASK_SEC)))
          // Build
          .build());
    }

    try
    {
      // Start multi-threading engine and wait for normal completion
      engine.start();
    }
    finally
    {
      // Stop the engine in a finally clause to ensure thread cleaning
      engine.stop();
    }

    try
    {
      fichierAIntegrer_p.setNbLignes(context.getNbLigne().get());
      fichierAIntegrer_p.setNbLignesKO(context.getNbLigneKO().get());

      // Here we determine the delta of line from the active reference
      //FIXME
      ConnectorResponse<Retour, List<FichierReferentielComposite>> responseLireTous = resfichierReferentielCompositeLireTous(tracabilite_p, typeReferentiel_p);

      int numblinesReferencial = 0;
      if (isRetourOK(responseLireTous._first))
      {
        for (FichierReferentielComposite fichierReferentielComposite : responseLireTous._second)
        {
          if (EtatReferentiel.ACTIVE.equals(fichierReferentielComposite.getGestionReferentiel().getEtat()))
          {
            for (FichierOrigine fichierOrigine : fichierReferentielComposite.getListeFichierOrigine())
            {
              if (fichierAIntegrer_p.getTypeFichier().equals(fichierOrigine.getTypeFichier()))
              {
                numblinesReferencial = fichierOrigine.getNbDeLigne();
              }
            }
          }
        }
      }
      fichierAIntegrer_p.setDeltaDeLigne(Math.abs(fichierAIntegrer_p.getNbLignes() - numblinesReferencial));
      fichierAIntegrer_p.setNbLigneRef(numblinesReferencial);

      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, MessageFormat.format(LOG_DELTA_LIGNE, fichierAIntegrer_p.getNbLignes(), numblinesReferencial)));

    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, exception));
      throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, exception.getMessage(), exception.getCause());
    }
    return new ConnectorResponse<>(retour, fichierAIntegrer_p);
  }

  /**
   * This activity calculates the Integration Metrics of all the files, generates the CR, and switches the reference to
   * the base.
   *
   * @param listFichierAIntegrer_p
   *          listFichierAIntegrer
   * @param typeReferentiel_p
   *          typeReferentiel
   *
   * @param tracabilite_p
   *          tracabilite
   *
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP0207_BL400_GererCR(Tracabilite tracabilite_p, List<FichierAIntegrer> listFichierAIntegrer_p, TypeReferentiel typeReferentiel_p) throws RavelException
  {

    Retour retour = RetourFactory.createOkRetour();
    boolean bascule = true;
    StringBuilder libelleBuilder = new StringBuilder(StringConstants.EMPTY_STRING);

    // Determine value of bascule and libelleligne3
    for (int i = 0; i < listFichierAIntegrer_p.size(); i++)
    {
      FichierAIntegrer fichierAIntegrer = listFichierAIntegrer_p.get(i);
      ConfigFichier configFichier = _processContext.getConfigGroupeFichier().getConfigFichier().get(i);

      // calcul minLigneOk
      int minLigneOK = fichierAIntegrer.getNbLignes();
      if (configFichier.getTauxMinLignesOK() != null)
      {
        long minLigneOKLong = configFichier.getTauxMinLignesOK() * (long) fichierAIntegrer.getNbLignes();
        minLigneOK = (int) (minLigneOKLong / 100);
      }

      // calcul maxLigneEvo
      int maxLigneEvo = fichierAIntegrer.getNbLigneRef();
      if (configFichier.getTauxMaxEvolNbLignes() != null)
      {
        long maxLigneEvoLong = configFichier.getTauxMaxEvolNbLignes() * (long) fichierAIntegrer.getNbLigneRef();
        maxLigneEvo = (int) (maxLigneEvoLong / 100);
      }

      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, MessageFormat.format(LOG_CONFIG, minLigneOK, maxLigneEvo)));

      // if the number of integrated lines OK is less then the minimum value
      if ((fichierAIntegrer.getNbLignes() - fichierAIntegrer.getNbLignesKO()) < minLigneOK)
      {
        bascule = false;
        //Max size of libelle
        if (libelleBuilder.length() <= 256)
        {
          libelleBuilder.append(TAUX_LIGNES_KO).append(fichierAIntegrer.getNbLignesKO()).append(" " + fichierAIntegrer.getFichierNom()); //$NON-NLS-1$
        }
        RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, MessageFormat.format(LOG_NBLIGNES_OK, fichierAIntegrer.getNbLignes() - fichierAIntegrer.getNbLignesKO())));
      }
      // if the number of line variation is greater then max value
      //FIXME validate that it is deltaDeLigne and the libelle receives TAUXLigne KO
      if (fichierAIntegrer.getDeltaDeLigne() > maxLigneEvo)
      {
        bascule = false;
        //Max size of libelle
        if (libelleBuilder.length() <= 256)
        {
          libelleBuilder.append(TAUX_DE_EVOLUTION).append(fichierAIntegrer.getDeltaDeLigne()).append(" pour " + fichierAIntegrer.getFichierNom()); //$NON-NLS-1$
        }
        RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, MessageFormat.format(LOG_NBLIGNES_EVOL, fichierAIntegrer.getDeltaDeLigne())));
      }
    }

    // Construction of a detailed CR file of this process
    String libelleligne3 = libelleBuilder.toString();
    if (_processContext.getConfigGroupeFichier().isGenerationCR())
    {
      for (int i = 0; i < listFichierAIntegrer_p.size(); i++)
      {
        FichierAIntegrer fichierAIntegrer = listFichierAIntegrer_p.get(i);
        ConfigFichier configFichier = _processContext.getConfigGroupeFichier().getConfigFichier().get(i);

        // build CR Filename à partir du nom de fichier
        String filenameCR = "CR_" + fichierAIntegrer.getFichierNom(); //$NON-NLS-1$
        Path pathCR = Paths.get(configFichier.getCheminCR(), filenameCR);
        File fileCR = pathCR.toFile();

        // ecriture du CR
        try (CSVFileWriter writer = new CSVFileWriter(fileCR, StandardCharsets.UTF_8))
        {
          writer.append(new CSVLine("INTEGRATION;OK;")); //$NON-NLS-1$
          writer.newLine();
          writer.append(new CSVLine("COMPTEUR;" + fichierAIntegrer.getNbLignes() + SEMICOLON + fichierAIntegrer.getDeltaDeLigne() + SEMICOLON)); //$NON-NLS-1$
          writer.newLine();
          if (bascule)
          {
            writer.append(new CSVLine("BASCULE;OK;")); //$NON-NLS-1$

            RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, MessageFormat.format(LOG_BASCULE_OK, fichierAIntegrer.getNbLignes() - fichierAIntegrer.getNbLignesKO(), fichierAIntegrer.getDeltaDeLigne())));
          }
          else
          {
            writer.append(new CSVLine("BASCULE;KO;" + libelleligne3 + SEMICOLON)); //$NON-NLS-1$
          }

        }
        catch (Exception exception)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, exception));
          throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, exception.getMessage(), exception.getCause());
        }

        try
        {
          Path pathDest = Paths.get(configFichier.getChemin(), fileCR.getName());
          FTPProxy.getInstance().uploadFile(configFichier.getNomConnecteur(), getTracabilite().getIdCorrelationSpirit(), pathCR.toString(), pathDest.toString());
        }
        catch (Exception exception)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, exception));
          throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, exception.getMessage(), exception.getCause());
        }

      }
    }

    // Add fichierOrigine in the database
    for (FichierAIntegrer fichierAIntegrer : listFichierAIntegrer_p)
    {
      FichierOrigine fichierOrigine = new FichierOrigine(fichierAIntegrer.getFichierNom(), fichierAIntegrer.getTypeFichier(), fichierAIntegrer.getNbLignes() - fichierAIntegrer.getNbLignesKO(), fichierAIntegrer.getDate(), fichierAIntegrer.getIndex().toString(), StringConstants.EMPTY_STRING, typeReferentiel_p.name());
      ConnectorResponse<Retour, Nothing> responseAjouterFichierOrigine = resFichierReferentielCompositeGererAjoutFichierOrigine(tracabilite_p, typeReferentiel_p, fichierOrigine);
      if (!isRetourOK(responseAjouterFichierOrigine._first))
      {
        retour = responseAjouterFichierOrigine._first;
      }
    }

    // on déplace systématiquement le fichier en archive OK (si la bascule est nok cela est géré coté base de données.
    //Move files to NOK repository
    Retour resBL1200 = archiverFichiers(_processContext.getConfigGroupeFichier(), tracabilite_p, StringConstants.OK);
    if (!isRetourOK(resBL1200))
    {
      return resBL1200;
    }

    if (bascule)
    {
      ConnectorResponse<Retour, Nothing> responseGererBascule = resGestionReferentielGererBascule(tracabilite_p, typeReferentiel_p);
      if (!isRetourOK(responseGererBascule._first))
      {
        retour = responseGererBascule._first;
      }
    }
    return retour;
  }

  /**
   * Reproduce old PAD 3006 behavior on PUT request.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typeReferentiel_p
   *          referentiel type
   * @param fichierOrigine
   *          the fichier origine
   * @return ConnectorResponse
   */
  private ConnectorResponse<Retour, Nothing> resFichierReferentielCompositeGererAjoutFichierOrigine(Tracabilite tracabilite_p, TypeReferentiel typeReferentiel_p, FichierOrigine fichierOrigine)
  {
    try
    {
      return RESDatabaseProxy.getInstance().updateGestionReferentielAddFichierOrigine(tracabilite_p, typeReferentiel_p, fichierOrigine);
    }
    catch (RavelException e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
  }

  /**
   * Reproduce old PAD 3006 behavior on GET request.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typeReferentiel_p
   *          referentiel type
   * @return ConnectorResponse
   */
  private ConnectorResponse<Retour, List<FichierReferentielComposite>> resfichierReferentielCompositeLireTous(Tracabilite tracabilite_p, TypeReferentiel typeReferentiel_p)
  {
    try
    {
      List<FichierReferentielComposite> listeFichierReferentielComposite = new ArrayList<>();

      // SAAB request
      ConnectorResponse<Retour, List<GestionReferentiel>> responseGetListGestionReferentiel = RESDatabaseProxy.getInstance().getListGestionReferentiel(tracabilite_p, typeReferentiel_p);
      Retour retour = responseGetListGestionReferentiel._first;
      if (!RetourFactory.isRetourOK(retour))
      {
        return new ConnectorResponse<>(retour, listeFichierReferentielComposite);
      }

      List<GestionReferentiel> listeGestionReferentiel = responseGetListGestionReferentiel._second;
      for (GestionReferentiel gestionReferentiel : listeGestionReferentiel)
      {
        List<FichierOrigine> listFichierOrigine = new ArrayList<>();
        for (String nomFichierOrigine : gestionReferentiel.getListeNomFichierOrigine())
        {
          // SAAB request
          ConnectorResponse<Retour, FichierOrigine> responseGetFichierOrigine = RESDatabaseProxy.getInstance().getFichierOrigine(tracabilite_p, nomFichierOrigine);
          retour = responseGetFichierOrigine._first;

          if (!RetourFactory.isRetourOK(retour))
          {
            return new ConnectorResponse<>(retour, listeFichierReferentielComposite);
          }
          listFichierOrigine.add(responseGetFichierOrigine._second);
        }
        listeFichierReferentielComposite.add(new FichierReferentielComposite(gestionReferentiel, listFichierOrigine));
      }

      return new ConnectorResponse<>(RetourFactory.createOkRetour(), listeFichierReferentielComposite);
    }
    catch (RavelException e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
  }

  /**
   * Reproduce old PAD 3005 behavior on PUT request.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typeReferentiel_p
   *          referentiel type
   * @return ConnectorResponse
   */
  private ConnectorResponse<Retour, Nothing> resGestionReferentielGererBascule(Tracabilite tracabilite_p, TypeReferentiel typeReferentiel_p)
  {
    try
    {
      return RESDatabaseProxy.getInstance().updateGestionAiguillageBasculeActive(tracabilite_p, typeReferentiel_p);
    }
    catch (RavelException e_p)
    {
      return new ConnectorResponse<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, e_p.getMessage()), null);
    }
  }

}
