/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0241.structs;

import java.io.Serializable;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class CommandeESim implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;
  /**
   * idCmdSap
   */
  String _idCmdSap;
  /**
   * codeArticleSap
   */
  String _codeArticleSap;
  /**
   * quantite
   */
  Long _quantite;

  /**
   *
   */
  public CommandeESim()
  {
    // TODO Auto-generated constructor stub
  }

  /**
   * @param idCmdSap_p
   *          idCmdSap_p
   * @param codeArticleSap_p
   *          codeArticleSap_p
   * @param quantite_p
   *          quantite
   */
  public CommandeESim(String idCmdSap_p, String codeArticleSap_p, Long quantite_p)
  {
    super();
    _idCmdSap = idCmdSap_p;
    _codeArticleSap = codeArticleSap_p;
    _quantite = quantite_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    CommandeESim other = (CommandeESim) obj;
    if (_codeArticleSap == null)
    {
      if (other._codeArticleSap != null)
      {
        return false;
      }
    }
    else if (!_codeArticleSap.equals(other._codeArticleSap))
    {
      return false;
    }
    if (_idCmdSap == null)
    {
      if (other._idCmdSap != null)
      {
        return false;
      }
    }
    else if (!_idCmdSap.equals(other._idCmdSap))
    {
      return false;
    }
    if (_quantite == null)
    {
      if (other._quantite != null)
      {
        return false;
      }
    }
    else if (!_quantite.equals(other._quantite))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the codeArticleSap
   */
  public String getCodeArticleSap()
  {
    return _codeArticleSap;
  }

  /**
   * @return the idCmdSap
   */
  public String getIdCmdSap()
  {
    return _idCmdSap;
  }

  /**
   * @return the quantite
   */
  public Long getQuantite()
  {
    return _quantite;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_codeArticleSap == null) ? 0 : _codeArticleSap.hashCode());
    result = (prime * result) + ((_idCmdSap == null) ? 0 : _idCmdSap.hashCode());
    result = (prime * result) + ((_quantite == null) ? 0 : _quantite.hashCode());
    return result;
  }

  /**
   * @param codeArticleSap_p
   *          the codeArticleSap to set
   */
  public void setCodeArticleSap(String codeArticleSap_p)
  {
    _codeArticleSap = codeArticleSap_p;
  }

  /**
   * @param idCmdSap_p
   *          the idCmdSap to set
   */
  public void setIdCmdSap(String idCmdSap_p)
  {
    _idCmdSap = idCmdSap_p;
  }

  /**
   * @param quantite_p
   *          the quantite to set
   */
  public void setQuantite(Long quantite_p)
  {
    _quantite = quantite_p;
  }

}
