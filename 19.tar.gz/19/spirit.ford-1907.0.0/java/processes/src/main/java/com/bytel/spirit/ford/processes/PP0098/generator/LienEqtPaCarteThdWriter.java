/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static java.util.Objects.nonNull;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author jsantos
 * @version ($Revision$ $Date$)
 */
public class LienEqtPaCarteThdWriter implements INSFWriter
{

  /**
   * Header Enum
   *
   * @author jsantos
   * @version ($Revision$ $Date$)
   */
  public enum LienEqtPACarteTHDHeader
  {
    /**
     * CLIENT_OPERATEUR
     */
    CLIENT_OPERATEUR(0),
    /**
     * NO_COMPTE
     */
    NO_COMPTE(1),
    /**
     * NO_EQUIPEMENT
     */
    NO_EQUIPEMENT(2),
    /**
     * ID_PA
     */
    ID_PA(3),
    /**
     * STATUT
     */
    STATUT(4),
    /**
     * SERIAL_NUMBER
     */
    SERIAL_NUMBER(5),
    /**
     * TYPE
     */
    TYPE(6),
    /**
     * MODELE
     */
    MODELE(7),
    /**
     * CODE_EAN
     */
    CODE_EAN(8),
    /**
     * NOM_FABRICANT
     */
    NOM_FABRICANT(9),
    /**
     * TECHNO_RACCO
     */
    TECHNO_RACCO(10),
    /**
     * ADR_CODE_INSEE
     */
    ADR_CODE_INSEE(11),
    /**
     * DATE_CREATION
     */
    DATE_CREATION(12),
    /**
     * DATE_MODIFICATION
     */
    DATE_MODIFICATION(13);

    /**
     * The position in CSV
     */
    private int _position;

    /**
     * Default constructor
     *
     * @param position_p
     *          The position
     */
    LienEqtPACarteTHDHeader(int position_p)
    {
      _position = position_p;
    }

    /**
     * @return the position
     */
    public int getPosition()
    {
      return _position;
    }
  }

  /**
   * CARTE_THD
   */
  private static final String CARTE_THD = "CARTE_THD"; //$NON-NLS-1$

  /**
   * The Writer
   */
  private BufferedWriter _writer;

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;

  /**
   * Current line in buffer
   */
  private Integer _lineCount;

  /**
   * Number of lines permitted on buffer to call flush
   */
  private Integer _linesToFlush;

  /**
   * Writer retour
   */
  private Retour _retour;

  /**
   * File Name
   */
  private String _fileName;

  /**
   * Default Constructor
   *
   * @param fileName_p
   *          The filename
   * @param linesToFlush_p
   *          The number of lines to call flush
   *
   * @throws IOException
   *           IOException
   */
  public LienEqtPaCarteThdWriter(String fileName_p, Integer linesToFlush_p) throws IOException
  {
    _retour = RetourFactory.createOkRetour();
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    _lineCount = 0;
    _writer = Files.newBufferedWriter(Paths.get(fileName_p));
    _csvPrinter = new CSVPrinter(_writer, CSVFormat.newFormat(';').withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(LienEqtPACarteTHDHeader.class));
  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
    _writer.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> records = getRecords(pfi_p, dateDemande_p);
    for (List<String> line : records)
    {
      write(tracabilite_p, line);
    }
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Build a CSV line to be written.
   *
   * @param pfi_p
   *          The PFI
   *
   * @return The String list representing a line
   */
  private List<List<String>> getRecords(PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> records = new ArrayList<>();
    if (nonNull(pfi_p.getEquipementDeclare()))
    {
      List<EquipementDeclare> eqptDeclareCarteThd = pfi_p.getEquipementDeclare().stream().filter(p -> CARTE_THD.equals(p.getTypeEquipement())).collect(Collectors.toList());
      if (nonNull(eqptDeclareCarteThd))
      {
        for (EquipementDeclare equipementDeclare : eqptDeclareCarteThd)
        {
          //Find LienEqptPa
          if (nonNull(pfi_p.getLienEquipementPA()))
          {
            List<LienEquipementPA> lienEquipementPAList = pfi_p.getLienEquipementPA().stream().filter(eqtPa -> equipementDeclare.getNoEquipement().equals(eqtPa.getNoEquipement())).collect(Collectors.toList());
            if (nonNull(lienEquipementPAList) && nonNull(pfi_p.getPa()))
            {
              for (LienEquipementPA lienEqPa : lienEquipementPAList)
              {
                if (nonNull(lienEqPa) //
                    && "BSS_GP".equals(pfi_p.getClientOperateur()) //$NON-NLS-1$
                    && dateDemande_p.isEqual(lienEqPa.getDateModification().toLocalDate()))
                {
                  List<String> csvLine = new ArrayList<>(Arrays.asList(new String[LienEqtPACarteTHDHeader.values().length]));
                  csvLine.set(LienEqtPACarteTHDHeader.CLIENT_OPERATEUR.getPosition(), pfi_p.getClientOperateur());
                  csvLine.set(LienEqtPACarteTHDHeader.NO_COMPTE.getPosition(), pfi_p.getNoCompte());
                  csvLine.set(LienEqtPACarteTHDHeader.NO_EQUIPEMENT.getPosition(), lienEqPa.getNoEquipement());
                  csvLine.set(LienEqtPACarteTHDHeader.ID_PA.getPosition(), lienEqPa.getIdFonctionnelPa());
                  csvLine.set(LienEqtPACarteTHDHeader.STATUT.getPosition(), CSVWriterUtils.getCsvValue(lienEqPa.getStatut()));
                  csvLine.set(LienEqtPACarteTHDHeader.SERIAL_NUMBER.getPosition(), equipementDeclare.getNoIdentifiant());
                  csvLine.set(LienEqtPACarteTHDHeader.TYPE.getPosition(), equipementDeclare.getTypeEquipement());
                  csvLine.set(LienEqtPACarteTHDHeader.MODELE.getPosition(), equipementDeclare.getModele());
                  csvLine.set(LienEqtPACarteTHDHeader.CODE_EAN.getPosition(), equipementDeclare.getCodeEan());
                  csvLine.set(LienEqtPACarteTHDHeader.NOM_FABRICANT.getPosition(), equipementDeclare.getNomFabricant());
                  //Find PA<
                  PA paFound = pfi_p.getPa().stream().filter(pa -> lienEqPa.getIdFonctionnelPa().equals(pa.getIdentifiantFonctionnelPA())).findFirst().orElseGet(null);
                  if (nonNull(paFound) && nonNull(paFound.getPaTypeLigneFixe()) && nonNull(paFound.getPaTypeLigneFixe().getInfoBrutBssGp()))
                  {
                    if (nonNull(paFound.getPaTypeLigneFixe().getInfoBrutBssGp().getAccesTechnique()))
                    {
                      csvLine.set(LienEqtPACarteTHDHeader.TECHNO_RACCO.getPosition(), paFound.getPaTypeLigneFixe().getInfoBrutBssGp().getAccesTechnique().getTechnologieAcces());
                    }
                    if (nonNull(paFound.getPaTypeLigneFixe().getInfoBrutBssGp().getAdresseInstallation()))
                    {
                      csvLine.set(LienEqtPACarteTHDHeader.ADR_CODE_INSEE.getPosition(), paFound.getPaTypeLigneFixe().getInfoBrutBssGp().getAdresseInstallation().getCodeInsee());
                    }
                  }
                  csvLine.set(LienEqtPACarteTHDHeader.DATE_CREATION.getPosition(), CSVWriterUtils.getCsvValue(equipementDeclare.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
                  csvLine.set(LienEqtPACarteTHDHeader.DATE_MODIFICATION.getPosition(), CSVWriterUtils.getCsvValue(lienEqPa.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
                  records.add(csvLine);
                }
              }
            }
          }
        }
      }
    }
    return records;
  }

  /**
   * Add lines to buffer or write them on file if buffer size is greater then max permited
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param line_p
   *          the line to write
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> line_p)
  {
    try
    {
      _csvPrinter.printRecord(line_p);
      _lineCount++;
      if (_lineCount >= _linesToFlush)
      {
        _csvPrinter.flush();
        _lineCount = 0;
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }

}
