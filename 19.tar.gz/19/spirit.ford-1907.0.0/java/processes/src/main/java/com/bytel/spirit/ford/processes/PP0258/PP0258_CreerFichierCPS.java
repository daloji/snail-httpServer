/*******************************************************************************
 * $Id: PP0258_CreerFichierCPS.java 16885 2019-02-08 14:10:26Z lmerces $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.processes.PP0258;

import static org.apache.commons.io.FileUtils.listFiles;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ws.rs.core.MediaType;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier.BL1300_CreerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1400_EmettreFichier;
import com.bytel.spirit.common.activities.shared.BL1400_EmettreFichier.BL1400_EmettreFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL3800_TrouverFichier;
import com.bytel.spirit.common.activities.shared.BL3800_TrouverFichier.BL3800_TrouverFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL3900_DeplacerEtRenommerFichier;
import com.bytel.spirit.common.activities.shared.BL3900_DeplacerEtRenommerFichier.BL3900_DeplacerEtRenommerFichierBuilder;
import com.bytel.spirit.common.connectors.gdr.GDRProxy;
import com.bytel.spirit.common.connectors.gdr.structs.CMDSIM;
import com.bytel.spirit.common.connectors.gdr.structs.Sim;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0258.structs.Action;
import com.bytel.spirit.ford.processes.PP0258.structs.ParametreSim;
import com.bytel.spirit.ford.processes.PP0258.structs.Vendeur;
import com.google.gson.Gson;

/**
 *
 * @author sdiop
 * @version ($Revision: 16885 $ $Date: 2019-02-08 15:10:26 +0100 (ven. 08 févr. 2019) $)
 */
public class PP0258_CreerFichierCPS extends SpiritRestApiProcessSkeleton
{

  /**
   * PP0258_CreerFichierCPSContext context
   *
   * @author sdiop
   * @version ($Revision: 16885 $ $Date: 2019-02-08 15:10:26 +0100 (ven. 08 févr. 2019) $)
   */
  public static final class PP0258_CreerFichierCPSContext extends Context
  {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * Step to call START
     */
    State _state = State.PP0258_START;

    /**
     * url parameteres action
     */
    Action _action;

    /**
     * Liste d'identifiant de profil
     */
    List<String> _identifiantProfil;

    /**
     * Chaine définissant l'accès aux serveurs de fichier dit " distant ". cette chaine contient les infos compte et mot
     * de passe d'accès et adresse du serveur distant
     */
    String _chaineConnexion;

    /**
     * Chemin d'accès au répertoire du serveur distant
     */
    String _cheminRepDepotDistant;

    /**
     * Nom du fichier à transférer
     */
    String _nomFichier;

    /**
     * Le répertoire source du fichier
     */
    String _repertoireSource;

    /**
     * Le répertoire d'archivage local du fichier transféré avec succès sur le serveur distant
     */
    String _repertoireArchiveSucces;

    /**
     * Le répertoire d'archivage local du fichier en cas d'erreur rencontré
     */
    String _repertoireArchiveEchec;

    /**
     * @return the action
     */
    public Action getAction()
    {
      return _action;
    }

    /**
     * @return the chaineConnexion
     */
    public String getChaineConnexion()
    {
      return _chaineConnexion;
    }

    /**
     * @return the cheminRepDepotDistant
     */
    public String getCheminRepDepotDistant()
    {
      return _cheminRepDepotDistant;
    }

    /**
     * @return the identifiantProfil
     */
    public List<String> getIdentifiantProfil()
    {
      return _identifiantProfil;
    }

    /**
     * @return the nomFichier
     */
    public String getNomFichier()
    {
      return _nomFichier;
    }

    /**
     * @return the repertoireArchiveEchec
     */
    public String getRepertoireArchiveEchec()
    {
      return _repertoireArchiveEchec;
    }

    /**
     * @return the repertoireArchiceSucces
     */
    public String getRepertoireArchiveSucces()
    {
      return _repertoireArchiveSucces;
    }

    /**
     * @return the repertoireSource
     */
    public String getRepertoireSource()
    {
      return _repertoireSource;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param action_p
     *          the action to set
     */
    public void setAction(Action action_p)
    {
      _action = action_p;
    }

    /**
     * @param chaineConnexion_p
     *          the chaineConnexion to set
     */
    public void setChaineConnexion(String chaineConnexion_p)
    {
      _chaineConnexion = chaineConnexion_p;
    }

    /**
     * @param cheminRepDepotDistant_p
     *          the cheminRepDepotDistant to set
     */
    public void setCheminRepDepotDistant(String cheminRepDepotDistant_p)
    {
      _cheminRepDepotDistant = cheminRepDepotDistant_p;
    }

    /**
     * @param identifiantProfil_p
     *          the identifiantProfil to set
     */
    public void setIdentifiantProfil(List<String> identifiantProfil_p)
    {
      _identifiantProfil = identifiantProfil_p;
    }

    /**
     * @param nomFichier_p
     *          the nomFichier to set
     */
    public void setNomFichier(String nomFichier_p)
    {
      _nomFichier = nomFichier_p;
    }

    /**
     * @param repertoireArchiveEchec_p
     *          the repertoireArchiveEchec to set
     */
    public void setRepertoireArchiveEchec(String repertoireArchiveEchec_p)
    {
      _repertoireArchiveEchec = repertoireArchiveEchec_p;
    }

    /**
     * @param repertoireArchiceSucces_p
     *          the repertoireArchiceSucces to set
     */
    public void setRepertoireArchiveSucce(String repertoireArchiceSucces_p)
    {
      _repertoireArchiveSucces = repertoireArchiceSucces_p;
    }

    /**
     * @param repertoireSource_p
     *          the repertoireSource to set
     */
    public void setRepertoireSource(String repertoireSource_p)
    {
      _repertoireSource = repertoireSource_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

  }

  /**
   *
   * @author sdiop
   * @version ($Revision: 16885 $ $Date: 2019-02-08 15:10:26 +0100 (ven. 08 févr. 2019) $)
   */
  private enum State
  {

    /**
     * BL002
     */
    PP0258_START(MandatoryProcessState.PRC_START),

    /**
    *
    */
    PP0258_BL001(MandatoryProcessState.PRC_RUNNING),

    /**
    *
    */
    PP0258_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     *
     */
    PP0258_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
    *
    */
    PP0258_BL101(MandatoryProcessState.PRC_RUNNING),
    /**
     *
     */
    PP0258_BL200(MandatoryProcessState.PRC_RUNNING),

    /**
     *
     */
    PP0258_BL300(MandatoryProcessState.PRC_RUNNING),

    /**
     *
     */
    PP0258_ENDED(MandatoryProcessState.PRC_STOP);
    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * VIRGULE
   */
  protected static final String VIRGULE = ","; //$NON-NLS-1$

  /**
   * point virgule
   */
  protected static final String POINT_VIRGULE = ";"; //$NON-NLS-1$

  /**
   * REGEX
   */
  protected static final String REGEX = "(?<=\\G.{2})"; //$NON-NLS-1$
  /**
   *
   */
  protected static final long serialVersionUID = 1L;

  /**
   * url param
   */
  protected static final String URL_PARAM = "action"; //$NON-NLS-1$

  /**
   * PRE_PROVISIONNE
   */
  protected static final String PRE_PROVISIONNE = "preprovisionne"; //$NON-NLS-1$

  /**
   * TEMPORAIRE
   */
  protected static final String TEMPORAIRE = "temporaire"; //$NON-NLS-1$
  /**
   * CHAINE_CONNEXION
   */
  protected static final String CHAINE_CONNEXION = "chaineConnexion"; //$NON-NLS-1$

  /**
   * IDENTIFIANT_PROFIL
   */
  protected static final String IDENTIFIANT_PROFIL = "identifiantProfil"; //$NON-NLS-1$

  /**
   * CHEMIN_DEPOT_DISTANT
   */
  protected static final String CHEMIN_DEPOT_DISTANT = "cheminRepDepotDistant"; //$NON-NLS-1$

  /**
   * NOM_FICHIER
   */
  protected static final String NOM_FICHIER = "nomFichier"; //$NON-NLS-1$

  /**
   * REPERTOIRE_SOURCE
   */
  protected static final String REPERTOIRE_SRC = "repertoireSrc"; //$NON-NLS-1$

  /**
   * REPERTOIRE_ARCHIVE_SUCCES
   */
  protected static final String REPERTOIRE_ARCHIVE_SUCCES = "repertoireArchiveSucces"; //$NON-NLS-1$

  /**
   * REPERTOIRE_ARCHIVE_ECHEC
   */
  protected static final String REPERTOIRE_ARCHIVE_ECHEC = "repertoireArchiveEchec"; //$NON-NLS-1$

  /**
   * Context
   */
  private PP0258_CreerFichierCPSContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return MarshallTools.marshall(retour_p);
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ZERO;
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PP0258_CreerFichierCPSContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    //NOOp

  }

  @Override
  protected void startMetroLog()
  {
    //NOOp

  }

  @Override
  @LogStartProcess
  protected void startPostProcess(Request request_p, Tracabilite tracabilite_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    try
    {
      _processContext.setState(State.PP0258_START);
      retour = PP0258_BL001_CtrlDonneesEntree(request_p, tracabilite_p);
      if (isRetourOK(retour))
      {
        switch (_processContext.getAction())
        {
          case CREATION:
            retour = PP0258_BL100_RecupererDonnees(tracabilite_p);
            break;
          case ENVOIE:
            retour = PP0258_BL300_EnvoyerFichierCPS(tracabilite_p);
            break;
          default:
            break;
        }
      }

    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage());
    }
    finally
    {

      PP0258_BL002_FormaterReponse(request_p, retour);
      _processContext.setState(State.PP0258_ENDED);
      setRetour(retour);
    }
  }

  /**
   * createHeaderCpsData
   *
   * @param vendeur_p
   *          vendeur
   * @return header
   */
  private String createHeaderCpsData(String vendeur_p)
  {

    LocalDateTime localdate = DateTimeManager.getInstance().now();
    String date = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(localdate);

    return new StringBuilder().append("FORMAT_VERSION:01.03") //$NON-NLS-1$
        .append("\nFILE_DATE:").append(date) //$NON-NLS-1$
        .append("\nSIMCardDataFormatVersion(05.30)") //$NON-NLS-1$
        .append("\nSIMCardData(").append(vendeur_p).append(")") //$NON-NLS-1$  //$NON-NLS-2$
        .toString();
  }

  /**
   * createIccdSwappe
   *
   * @param iccd_p
   *          iccd_p
   * @return iccid
   */
  private String createIccdSwappe(String iccd_p)
  {
    String iccdSwaap = StringConstants.EMPTY_STRING;
    if (iccd_p != null)
    {
      String[] arrays = iccd_p.split(REGEX);
      StringBuilder stringbuilder = new StringBuilder();
      for (String value : arrays)
      {
        StringBuilder info = new StringBuilder(value);
        stringbuilder.append(info.reverse().toString());
      }
      iccdSwaap = stringbuilder.toString();
    }
    return iccdSwaap;
  }

  /**
   * extraction PE a partir du nom de fichier
   *
   * @param filename_p
   *          filename
   * @param tracabilite_p
   *          tracabilite
   * @return string
   */
  private String extractPeValue(String filename_p, Tracabilite tracabilite_p)
  {
    String pe = StringConstants.EMPTY_STRING;
    String filename = filename_p;
    if (filename != null)
    {
      try
      {
        int index = filename.indexOf("_"); //$NON-NLS-1$
        filename = filename.substring(index + 1, filename.length());
        index = filename.indexOf("_"); //$NON-NLS-1$
        filename = filename.substring(0, index);
        pe = filename;
      }
      catch (Exception e)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));

      }
    }
    return pe;
  }

  /**
   * generateParameterSim
   *
   * @param tracabilite_p
   *          tracabilite
   * @param listSim_p
   *          List<Sim>
   * @return List<ParametreSim>
   */
  private List<ParametreSim> generateParameterSim(Tracabilite tracabilite_p, List<Sim> listSim_p)
  {
    List<ParametreSim> listParamSim = new ArrayList<>();

    if (listSim_p != null)
    {
      for (Sim sim : listSim_p)
      {
        ParametreSim paramSim = new ParametreSim();
        paramSim.setIccid(sim.getSim());
        paramSim.setImsi(sim.getIms());
        String iccdSwappe = PP0258_BL101_TraitementSwapICCID(sim.getSim(), tracabilite_p);
        paramSim.setIccidSwappe(iccdSwappe);
        listParamSim.add(paramSim);
      }
    }

    return listParamSim;
  }

  /**
   * Recuperation de la configuration du processus
   *
   */
  private void getProcessConfigParameters()
  {
    String identProfil = getConfigParameter(IDENTIFIANT_PROFIL);
    if (StringTools.isNotNullOrEmpty(identProfil))
    {
      List<String> listident = new ArrayList<>();
      if (identProfil.contains(VIRGULE))
      {
        String[] items = identProfil.split(VIRGULE);
        listident = Arrays.asList(items);
      }
      else if (identProfil.contains(POINT_VIRGULE))
      {
        String[] items = identProfil.split(POINT_VIRGULE);
        listident = Arrays.asList(items);
      }
      else
      {
        listident.add(identProfil);
      }
      _processContext.setIdentifiantProfil(listident);
    }

    _processContext.setChaineConnexion(getConfigParameter(CHAINE_CONNEXION));
    _processContext.setCheminRepDepotDistant(getConfigParameter(CHEMIN_DEPOT_DISTANT));
    _processContext.setNomFichier(getConfigParameter(NOM_FICHIER));
    _processContext.setRepertoireSource(getConfigParameter(REPERTOIRE_SRC));
    _processContext.setRepertoireArchiveSucce(getConfigParameter(REPERTOIRE_ARCHIVE_SUCCES));
    _processContext.setRepertoireArchiveEchec(getConfigParameter(REPERTOIRE_ARCHIVE_ECHEC));
  }

  /**
   * Gets the URL parameters into the ProcessContext
   *
   * @param request_p
   *          request
   */
  private void getUrlparametersIntoProcessContext(Request request_p)
  {
    // get url parameters
    List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();
    for (Parameter parametre : urlParametersType)
    {
      if (URL_PARAM.equals(parametre.getName()))
      {
        _processContext.setAction(Action.getAction(parametre.getValue()));

      }
    }
  }

  /**
   * PP0258_BL001_CtrlDonneesEntree
   *
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @return Retour
   */
  @LogProcessBL
  private Retour PP0258_BL001_CtrlDonneesEntree(Request request_p, Tracabilite tracabilite_p)
  {
    _processContext.setState(State.PP0258_BL001);
    getProcessConfigParameters();
    getUrlparametersIntoProcessContext(request_p);

    if (StringTools.isNullOrEmpty(_processContext.getChaineConnexion()))
    {
      String message = MessageFormat.format(Messages.getString("PP0258.MissingConfigurationParameter"), CHAINE_CONNEXION); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, message);
    }

    if (StringTools.isNullOrEmpty(_processContext.getCheminRepDepotDistant()))
    {
      String message = MessageFormat.format(Messages.getString("PP0258.MissingConfigurationParameter"), CHEMIN_DEPOT_DISTANT); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, message);
    }

    if (StringTools.isNullOrEmpty(_processContext.getNomFichier()))
    {
      String message = MessageFormat.format(Messages.getString("PP0258.MissingConfigurationParameter"), NOM_FICHIER); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, message);
    }

    if (StringTools.isNullOrEmpty(_processContext.getRepertoireSource()))
    {
      String message = MessageFormat.format(Messages.getString("PP0258.MissingConfigurationParameter"), REPERTOIRE_SRC); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, message);
    }

    if (StringTools.isNullOrEmpty(_processContext.getRepertoireArchiveSucces()))
    {
      String message = MessageFormat.format(Messages.getString("PP0258.MissingConfigurationParameter"), REPERTOIRE_ARCHIVE_SUCCES); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, message);
    }

    if (StringTools.isNullOrEmpty(_processContext.getRepertoireArchiveEchec()))
    {
      String message = MessageFormat.format(Messages.getString("PP0258.MissingConfigurationParameter"), REPERTOIRE_ARCHIVE_ECHEC); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, message);
    }

    if (_processContext.getAction() == null)
    {
      String message = MessageFormat.format(Messages.getString("PP0258.UrlConfigurationMissing"), URL_PARAM); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, Messages.getString("PP0258.InvalidDataFormat"));//$NON-NLS-1$
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * PP0258_BL002_FormaterReponse
   *
   * @param request_p
   *          request
   * @param retour
   *          retour
   */
  @LogProcessBL
  private void PP0258_BL002_FormaterReponse(Request request_p, Retour retour)
  {
    _processContext.setState(State.PP0258_BL002);
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response response;
      ravelResponse.setDataType(MediaType.APPLICATION_JSON);

      if (StringConstants.OK.equals(retour.getResultat()))
      {
        response = new Response(ErrorCode.OK_00204, ravelResponse);
      }
      else
      {
        if (IMegConsts.DONNEE_INVALIDE.equals(retour.getDiagnostic()))
        {
          response = new Response(ErrorCode.KO_00400, ravelResponse);
        }
        else
        {
          response = new Response(ErrorCode.KO_00500, ravelResponse);
        }

        ravelResponse.setResult(new Gson().toJson(retour));
      }
      request_p.setResponse(response);
    }
  }

  /**
   * PP0258_BL005_GererErreurPROSPER
   */
  @LogProcessBL
  private void PP0258_BL005_GererErreurPROSPER()
  {
    //NOOp
  }

  /**
   * PP0258_BL100_recupererDonneess
   *
   * @param tracabilite_p
   *          tracabilite
   * @return Retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PP0258_BL100_RecupererDonnees(Tracabilite tracabilite_p) throws RavelException
  {
    _processContext.setState(State.PP0258_BL100);
    Retour retour = RetourFactory.createOkRetour();

    for (String identProfile : _processContext.getIdentifiantProfil())
    {
      ConnectorResponse<List<String>, Retour> gdrIdentifiantsCommande = GDRProxy.getInstance().ps014GetIdentifiantsCommande(tracabilite_p, identProfile);
      ConnectorResponse<String, Retour> gdrPEparIdentifiant = GDRProxy.getInstance().getProfilElectriqueParIdentifiant(tracabilite_p, identProfile, "E"); //$NON-NLS-1$

      if (!isRetourOK(gdrIdentifiantsCommande._second) || !isRetourOK(gdrPEparIdentifiant._second))
      {
        //cas ou GDR connector retourne KO
        String message = Messages.getString("PP0258.ConsultationKO"); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message);
      }
      List<ParametreSim> listparam = new ArrayList<>();
      Set<String> setIdtFAB = new HashSet<>();
      for (String identCommande : gdrIdentifiantsCommande._first)
      {
        ConnectorResponse<List<Sim>, Retour> gdrSim = GDRProxy.getInstance().getSimsNonPreProvisionnes(tracabilite_p, identCommande, PRE_PROVISIONNE);
        ConnectorResponse<CMDSIM, Retour> gdrCmd = GDRProxy.getInstance().ps022GetCommande(tracabilite_p, identCommande);

        if (!isRetourOK(gdrSim._second) || !isRetourOK(gdrCmd._second))
        {
          //cas ou GDR connector retourne KO
          String message = Messages.getString("PP0258.ConsultationKO"); //$NON-NLS-1$
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
          return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message);
        }
        setIdtFAB.add(Vendeur.getValueByVendeur(gdrCmd._first.getIdtFAB()));
        listparam.addAll(generateParameterSim(tracabilite_p, gdrSim._first));
      }
      if (!listparam.isEmpty())
      {
        List<String> listIdtFAB = new ArrayList<>(setIdtFAB);
        retour = PP0258_BL200_CreerFichierCPS(gdrPEparIdentifiant._first, listparam, listIdtFAB, tracabilite_p);
      }
    }
    return retour;
  }

  /**
   * PP0258_BL101_Traitement_Swap_ICCID
   *
   * @param iccd_p
   *          iccd
   * @param tracabilite_p
   *          tracabilite
   * @return String
   */
  @LogProcessBL
  private String PP0258_BL101_TraitementSwapICCID(String iccd_p, Tracabilite tracabilite_p)
  {
    _processContext.setState(State.PP0258_BL101);
    String iccd = StringConstants.EMPTY_STRING;
    String iccdSwappe = StringConstants.EMPTY_STRING;
    if (iccd_p != null)
    {
      int iccdLong = iccd_p.length();
      //regle 1 si impair on rajoute un F
      if ((iccdLong % 2) == 0)
      {
        iccd = iccd_p;
      }
      else
      {
        iccd = iccd_p + "F"; //$NON-NLS-1$
      }
      //regle 2
      iccdSwappe = createIccdSwappe(iccd);
    }
    return iccdSwappe;
  }

  /**
   * PP0258_BL200_CreerFichierCPS
   *
   * @param pe_p
   *          profil electrique
   * @param listParamSim_p
   *          liste parametre SiM
   * @param listIdtFAB_p
   *          liste identifiants FAB
   * @param tracabilite_p
   *          tracabilite
   * @return Retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PP0258_BL200_CreerFichierCPS(String pe_p, List<ParametreSim> listParamSim_p, List<String> listIdtFAB_p, Tracabilite tracabilite_p) throws RavelException
  {
    _processContext.setState(State.PP0258_BL200);
    String filename = _processContext.getNomFichier().replace("_PE_", "_" + pe_p + "_"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$

    BL3800_TrouverFichier bl3800_trouverFichier = new BL3800_TrouverFichierBuilder().repertoire(_processContext.getRepertoireSource()).masqueNomFichier(filename).tracabilite(tracabilite_p).logSeverity(LogSeverity.INFO).build();
    bl3800_trouverFichier.execute(this);

    if (isRetourOK(bl3800_trouverFichier.getRetour()))
    {
      String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename;
      // Call BL3900_DeplacerEtRenommerFichier
      BL3900_DeplacerEtRenommerFichier deplacerEtRenommerFichier = new BL3900_DeplacerEtRenommerFichierBuilder().repertoireSrc(_processContext.getRepertoireSource()).nomFichierSrc(filename).repertoireDes(_processContext.getRepertoireArchiveEchec()).nomFichierDes(filenameDes).tracabilite(tracabilite_p).build();

      deplacerEtRenommerFichier.execute(this);

      if (!isRetourOK(deplacerEtRenommerFichier.getRetour()))
      {

        String message = Messages.getString("PP0258.CreateFile"); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DROIT_FICHIER_INVALIDE, message);
      }
    }
    String header = createHeaderCpsData(listIdtFAB_p.get(0));

    StringBuilder content = new StringBuilder();
    content.append(header).append("\n{\nCardProfile(").append(pe_p.replace(".", "_")).append(")");//$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    for (ParametreSim paramSim : listParamSim_p)
    {
      content.append("\nCard()") //$NON-NLS-1$
          .append("\n{\nApplicationDf(3F00)") //$NON-NLS-1$
          .append("\n{\n BinaryFile(3F002FE2)") //$NON-NLS-1$
          .append("\n{\n BinaryRec(").append(paramSim.getIccidSwappe()).append(")") //$NON-NLS-1$ //$NON-NLS-2$
          .append("\n}\n}") //$NON-NLS-1$
          .append("\nSubscription()") //$NON-NLS-1$
          .append("\n{\nImsi(").append(paramSim.getImsi()).append(")") //$NON-NLS-1$ //$NON-NLS-2$
          .append("\n}\n}"); //$NON-NLS-1$
    }
    content.append("\n}"); //$NON-NLS-1$

    BL1300_CreerFichier creerFichier = new BL1300_CreerFichierBuilder().repertoire(_processContext.getRepertoireSource()).nomFichier(filename).tracabilite(tracabilite_p).build();

    creerFichier.execute(this);
    if (!isRetourOK(creerFichier.getRetour()))
    {
      String message = Messages.getString("PP0258.CreateFile"); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DROIT_FICHIER_INVALIDE, message);
    }
    try
    {
      FileUtils.writeStringToFile(new File(_processContext.getRepertoireSource() + File.separator + filename), content.toString());
    }
    catch (IOException exception)
    {
      String message = Messages.getString("PP0258.CreateFile"); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DROIT_FICHIER_INVALIDE, message);
    }
    ConnectorResponse<Nothing, Retour> gdrUpdate;

    for (ParametreSim paramSim : listParamSim_p)
    {
      gdrUpdate = GDRProxy.getInstance().updateSimEtatMocImsi(tracabilite_p, paramSim.getImsi(), TEMPORAIRE);

      if (!isRetourOK(gdrUpdate._second))
      {
        String message = Messages.getString("PP0258.GdrKO"); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.MISE_A_JOUR_INDISPONIBLE, message);
      }
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * PP0258 BL300
   *
   * @param tracabilite_p
   *          tracabilite
   *
   * @return Retour
   * @throws RavelException
   *           exception throw
   */
  @LogProcessBL
  private Retour PP0258_BL300_EnvoyerFichierCPS(Tracabilite tracabilite_p) throws RavelException
  {
    _processContext.setState(State.PP0258_BL300);
    File source = new File(_processContext.getRepertoireSource());
    Collection listFiles = listFiles(source, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
    List<File> files = new ArrayList<>(listFiles);
    String filename;
    String pe;
    for (File file : files)
    {
      filename = file.getName();
      pe = extractPeValue(filename, tracabilite_p);
      if (StringTools.isNullOrEmpty(pe))
      {
        String message = Messages.getString("PP0258.ConsultationKO"); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message);
      }
      ConnectorResponse<Nothing, Retour> gdrUpdate = GDRProxy.getInstance().updateSimEtatMoc(tracabilite_p, pe, PRE_PROVISIONNE);
      if (!isRetourOK(gdrUpdate._second))
      {
        String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename;
        // Call BL3900_DeplacerEtRenommerFichier
        BL3900_DeplacerEtRenommerFichier deplacerEtRenommerFichier = new BL3900_DeplacerEtRenommerFichierBuilder().repertoireSrc(_processContext.getRepertoireSource()).nomFichierSrc(filename).repertoireDes(_processContext.getRepertoireArchiveEchec()).nomFichierDes(filenameDes).tracabilite(tracabilite_p).build();

        deplacerEtRenommerFichier.execute(this);

        if (!isRetourOK(deplacerEtRenommerFichier.getRetour()))
        {

          String message = Messages.getString("PP0258.ConsultationKO"); //$NON-NLS-1$
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
          return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message);
        }

        String message = Messages.getString("PP0258.ConsultationKO"); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, message);
      }
      // Call BL1400_EmettreFichier
      BL1400_EmettreFichier emettreFichier = new BL1400_EmettreFichierBuilder().chaineConnexion(_processContext.getChaineConnexion()).repertoireSrc(_processContext.getRepertoireSource()).nomFichier(filename).cheminRepDepotDistant(_processContext.getCheminRepDepotDistant()).repertoireArchiveSucces(_processContext.getRepertoireArchiveSucces()).tracabilite(tracabilite_p).build();
      emettreFichier.execute(this);
      if (!isRetourOK(emettreFichier.getRetour()))
      {
        String message = Messages.getString("PP0258.ErrorMoveFile"); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DEPLACEMENT_FICHIER_INVALIDE, message);
      }
      String filenameDes = DateTimeTools.DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now()) + "_" + filename; //$NON-NLS-1$
      // Call BL3900_DeplacerEtRenommerFichier
      BL3900_DeplacerEtRenommerFichier deplacerEtRenommerFichier = new BL3900_DeplacerEtRenommerFichierBuilder().repertoireSrc(_processContext.getRepertoireArchiveSucces()).nomFichierSrc(filename).repertoireDes(_processContext.getRepertoireArchiveSucces()).nomFichierDes(filenameDes).tracabilite(tracabilite_p).build();

      deplacerEtRenommerFichier.execute(this);

      if (!isRetourOK(deplacerEtRenommerFichier.getRetour()))
      {
        String message = Messages.getString("PP0258.ErrorMoveFile"); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DEPLACEMENT_FICHIER_INVALIDE, message);
      }
    }

    return RetourFactory.createOkRetour();
  }

}
