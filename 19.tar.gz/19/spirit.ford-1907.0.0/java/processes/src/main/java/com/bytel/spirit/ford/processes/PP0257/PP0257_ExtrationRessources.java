/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0257;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.cxf.helpers.FileUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.ford.config.ConfigurationFluxExtraction;
import com.bytel.spirit.common.ford.config.GenericProcessConfig;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0257.writers.AdrIpClfWriter;
import com.bytel.spirit.ford.processes.PP0257.writers.CompteImsWriter;
import com.bytel.spirit.ford.processes.PP0257.writers.CompteMailWriter;
import com.bytel.spirit.ford.processes.PP0257.writers.ImpiFixeWriter;
import com.bytel.spirit.ford.processes.PP0257.writers.MotDePasseImsWriter;
import com.bytel.spirit.ford.shared.misc.processes.FordProcessSkeleton;
import com.bytel.spirit.ford.shared.misc.processes.writers.IGenericWriter;
import com.bytel.spirit.ford.shared.types.GenericProcessConfigValidator;
import com.bytel.spirit.ford.shared.types.GenericRequestParameters;
import com.bytel.spirit.saab.connectors.res.IRessourceCallback;
import com.bytel.spirit.saab.connectors.res.RESDatabaseProxy;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PP0257_ExtrationRessources extends FordProcessSkeleton<IGenericWriter<Ressource>, Ressource> implements IRessourceCallback
{

  /**
   * @author pescudei
   * @version ($Revision$ $Date$)
   */
  public static final class PP0257_ExtrationRessourcesContext extends Context
  {

    /**
     * The generated UUID
     */
    private static final long serialVersionUID = 4848488300930030490L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PP0257_BL001;

    /**
     * Contains the process retour.
     */
    private Retour _processRetour;

    /**
     * Contains the process configuration
     */
    private transient GenericProcessConfig _configurationPP0257;

    /**
     * Contains the execution mode.
     */
    private String _modeExecution;

    /**
     * Contains the id of the extraction flux.
     */
    private String _idFluxExtraction;

    /**
     * Constains the ThreadPoolExecutor.
     */
    private ThreadPoolExecutor _threadPoolExecutor;

    /**
     * Contains the future result of the submitted task for the ThreadPoolExecutor
     */
    List<Future<Retour>> _threadPoolExecutorResult = Collections.synchronizedList(new ArrayList<>());

    /**
     * Constains the compteMailWriter list.
     */
    private List<IGenericWriter<Ressource>> _writers = new ArrayList<>(1);

    /**
     * @return the configurationPP0257
     */
    public GenericProcessConfig getConfigurationPP0257()
    {
      return _configurationPP0257;
    }

    /**
     * @return the idFluxExtraction
     */
    public String getIdFluxExtraction()
    {
      return _idFluxExtraction;
    }

    /**
     * @return value of modeExecution
     */
    public String getModeExecution()
    {
      return _modeExecution;
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the state
     */
    public final State getState()
    {
      return _state;
    }

    /**
     * @return value of threadPoolExecutor
     */
    public ThreadPoolExecutor getThreadPoolExecutor()
    {
      return _threadPoolExecutor;
    }

    /**
     * @return the configurationPP0257
     */
    public List<IGenericWriter<Ressource>> getWriters()
    {
      return new ArrayList<>(_writers);
    }

    /**
     * @param configurationPP0257_p
     *          the configurationPP0257 to set
     */
    public void setConfigurationPP0257(GenericProcessConfig configurationPP0257_p)
    {
      _configurationPP0257 = configurationPP0257_p;
    }

    /**
     * @param idFluxExtraction_p
     *          the idFluxExtraction to set
     */
    public void setIdFluxExtraction(String idFluxExtraction_p)
    {
      _idFluxExtraction = idFluxExtraction_p;
    }

    /**
     * @param modeExecution_p
     *          The modeExecution to set.
     */
    public void setModeExecution(String modeExecution_p)
    {
      _modeExecution = modeExecution_p;
    }

    /**
     * @param processRetour_p
     *          the processRetour to set
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public final void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param threadPoolExecutor_p
     *          The threadPoolExecutor to set.
     */
    public void setThreadPoolExecutor(ThreadPoolExecutor threadPoolExecutor_p)
    {
      _threadPoolExecutor = threadPoolExecutor_p;
    }

    /**
     * @param writers_p
     *          the nfsWriters to set
     */
    public void setWriters(List<IGenericWriter<Ressource>> writers_p)
    {
      _writers = new ArrayList<>(writers_p);
    }
  }

  /**
   * PP0257 states
   *
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PP0257_BL001(MandatoryProcessState.PRC_START),

    /**
     * The next step to execute is: BL100
     */
    PP0257_BL100(MandatoryProcessState.PRC_RUNNING),

    /**
     * The next step to execute is: BL101
     */
    PP0257_BL101(MandatoryProcessState.PRC_RUNNING),

    /**
     * The next step to execute is: BL200
     */
    PP0257_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL902
     */
    PP0257_BL901(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL902
     */
    PP0257_BL902(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL903
     */
    PP0257_BL903(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL904
     */
    PP0257_BL904(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL910
     */
    PP0257_BL910(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL920
     */
    PP0257_BL920(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PP0257_CALLBACK(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PP0257_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * ID Flux ExtractionAutorisees possibles
   *
   * @author jbrites
   * @version ($Revision$ $Date$)
   */
  protected enum IdFluxExtraction
  {

    /**
     * SPIRIT-RES-COMPTEMAIL
     */
    SPIRIT_RES_COMPTEMAIL("SPIRIT-RES-COMPTEMAIL"), //$NON-NLS-1$
    /**
     * SPIRIT-RES-COMPTEIMS
     */
    SPIRIT_RES_COMPTEIMS("SPIRIT-RES-COMPTEIMS"), //$NON-NLS-1$
    /**
     * SPIRIT-RES-IMPIFIXE
     */
    SPIRIT_RES_IMPIFIXE("SPIRIT-RES-IMPIFIXE"), //$NON-NLS-1$
    /**
     * SPIRIT-RES-ADRIPCLF
     */
    SPIRIT_RES_ADRIPCLF("SPIRIT-RES-ADRIPCLF"), //$NON-NLS-1$
    /**
     * SPIRIT_RES_MOTDEPASSEIMS
     */
    SPIRIT_RES_MOTDEPASSEIMS("SPIRIT-RES-MOTDEPASSEIMS"); //$NON-NLS-1$

    //...
    //Add new types of Ressources here, if the extraction is required

    /**
     * Validate if the idFlux parameter is valid. To evaluate, check that the value is one of the values present in this
     * enum.
     *
     * @param idFlux_p
     *          The Id Flux to validate
     * @return True if valid, false otherwise
     */
    public static boolean isValidIdFluxAutorisee(String idFlux_p)
    {
      for (IdFluxExtraction idFlux : IdFluxExtraction.values())
      {
        if (idFlux.getIdFluxExtractionAutoriseConf().equals(idFlux_p))
        {
          return true;
        }
      }
      return false;
    }

    /**
     * Name of idFluxExtractionAutorise possible in the configuration file
     */
    private String _idFluxExtractionAutoriseConf;

    /**
     *
     * @param idFluxExtractionAutoriseConf_p
     *          idFlux autorisee
     */
    private IdFluxExtraction(String idFluxExtractionAutoriseConf_p)
    {
      _idFluxExtractionAutoriseConf = idFluxExtractionAutoriseConf_p;
    }

    /**
     * @return the idFluxExtractionAutoriseConf
     */
    public String getIdFluxExtractionAutoriseConf()
    {
      return _idFluxExtractionAutoriseConf;
    }
  }

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = -2632420651709893823L;

  /**
   * The message for MESSAGE_AUCUNE_RESSOURCE log.
   */
  private static final String MESSAGE_AUCUNE_RESSOURCE = Messages.getString("PP0257.AucuneRessource"); //$NON-NLS-1$

  /**
   * The message for Unauthorized Ressource type
   */
  protected static final String MESSAGE_UNAUTHORIZED_RESSOURCE = Messages.getString("PP0257.UnauthorizedRessource"); //$NON-NLS-1$

  /**
   * The SPIRIT-RES-COMPTEMAIL flux id
   */
  private static final String SPIRIT_RES_COMPTEMAIL = "SPIRIT-RES-COMPTEMAIL"; //$NON-NLS-1$

  /**
   * The SPIRIT-RES-COMPTEIMS flux id
   */
  private static final String SPIRIT_RES_COMPTEIMS = "SPIRIT-RES-COMPTEIMS"; //$NON-NLS-1$

  /**
   * The SPIRIT-RES-IMPIFIXE flux id
   */
  private static final String SPIRIT_RES_IMPIFIXE = "SPIRIT-RES-IMPIFIXE"; //$NON-NLS-1$

  /**
   * The SPIRIT-RES-ADRIPCLF flux id
   */
  private static final String SPIRIT_RES_ADRIPCLF = "SPIRIT-RES-ADRIPCLF"; //$NON-NLS-1$

  /**
   * The SPIRIT-RES-MOTDEPASSEIMS flux id
   */
  private static final String SPIRIT_RES_MOTDEPASSEIMS = "SPIRIT-RES-MOTDEPASSEIMS"; //$NON-NLS-1$

  /**
   * process context
   */
  private PP0257_ExtrationRessourcesContext _processContext;

  @Override
  public Retour consume(Tracabilite tracabilite_p, Ressource ressource_p) throws RavelException
  {
    //Cette méthode est appélée par un seul thread dans le connecteur Cassandra (c'est le même thread que celui qui exécute
    //ce processus).
    //Plus cette méthode est appelée, plus la liste _processContext._threadPoolExecutorResult grossit.
    //Pour donner un ordre d'idée, un fichier d'extract de ST PFS MAIL de 600 Mo contient 4 millions de lignes.
    //Il n'est donc pas raisonnable de stocker 4 millions de Future dans la liste  _processContext._threadPoolExecutorResult.
    //Une solution simple à ce problème: si la liste _processContext._threadPoolExecutorResult atteind la taille de la blocking queue (waitingFileSize = 100),
    //alors  on attend le resultat de ces 100 taches. Une fois les 100 taches terminées, on vide la liste _processContext._threadPoolExecutorResult
    //avant de rappeler le BL910_PushIdInExecutor.
    //Ainsi, la taille de liste _processContext._threadPoolExecutorResult sera toujours limitée en mémoire et puis on evite le risque de pousser dans une file pleine.
    //Quoi qu'il en soit:
    // - Si les writers sont rapides, la fonction d'attente BL903_WaitForTasksCompletion sera rapide également.
    // - Si les writers sont  lents, la fonction BL903_WaitForTasksCompletion attendra plus longtemps la fin des tâches.
    if (_processContext._threadPoolExecutorResult.size() == _processContext.getConfigurationPP0257().getWaitingFileSize())
    {
      Retour retour = BL903_WaitForTasksCompletion(tracabilite_p, _processContext.getConfigurationPP0257(), _processContext._threadPoolExecutorResult);
      if (!RetourFactory.isRetourOK(retour))
      {
        _processContext.setProcessRetour(retour);
        return retour;
      }

      _processContext._threadPoolExecutorResult.clear();
    }

    // Call BL110
    _processContext.setState(State.PP0257_BL910);
    Retour retourBL910 = BL910_PushIdInExecutor(tracabilite_p, _processContext.getConfigurationPP0257(), ressource_p, _processContext.getWriters(), _processContext.getThreadPoolExecutor(), _processContext._threadPoolExecutorResult);
    _processContext.setProcessRetour(retourBL910);

    return retourBL910;
  }

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    if (retour_p != null)
    {
      return MarshallTools.marshall(retour_p);
    }
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PP0257_ExtrationRessourcesContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return true;
  }

  @Override
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, MESSAGE_UNEXPECTED_CONTINUE);
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel
  }

  @Override
  protected Pair<Retour, IGenericWriter<Ressource>> getWriter(Tracabilite tracabilite_p, String extractionName_p, String filePath_p, String fileName_p, int nbLinesToFlush_p)
  {
    try
    {
      switch (extractionName_p)
      {
        case SPIRIT_RES_COMPTEMAIL:
          return new Pair<>(RetourFactory.createOkRetour(), new CompteMailWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_RES_COMPTEIMS:
          return new Pair<>(RetourFactory.createOkRetour(), new CompteImsWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_RES_IMPIFIXE:
          return new Pair<>(RetourFactory.createOkRetour(), new ImpiFixeWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_RES_ADRIPCLF:
          return new Pair<>(RetourFactory.createOkRetour(), new AdrIpClfWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_RES_MOTDEPASSEIMS:
          return new Pair<>(RetourFactory.createOkRetour(), new MotDePasseImsWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        default:
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_INVALID_EXTRACTION_NAME, extractionName_p)), null);
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, fileName_p, e.getMessage())));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, fileName_p, e.getMessage())), null);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      // Call BL001
      _processContext.setState(State.PP0257_BL001);
      Pair<Retour, GenericRequestParameters> bl001Return = PP0257_BL001_VerifierDonnees(tracabilite_p, request_p);
      _processContext.setProcessRetour(bl001Return._first);

      if (RetourFactory.isRetourOK(bl001Return._first))
      {
        _processContext.setModeExecution(bl001Return._second.getModeExecution());
        _processContext.setIdFluxExtraction(bl001Return._second.getIdFluxExtraction());

        if (PRODUIRE_EXTRACTIONS.equals(_processContext.getModeExecution()))
        {
          // Call BL100
          _processContext.setState(State.PP0257_BL100);
          Retour retourBL100 = PP0257_BL100_ProduireFicheirExtraction(tracabilite_p, _processContext.getIdFluxExtraction());
          _processContext.setProcessRetour(retourBL100);

          if (RetourFactory.isRetourKO(retourBL100))
          {
            // if extraction errors, we should erase the previously created files
            deleteAllFilesInWorkPath(tracabilite_p, _processContext.getConfigurationPP0257().getCheminRepTravail(), _processContext.getModeExecution(), _processContext.getConfigurationPP0257().getExtensionFichierTemporaire());
          }
        }
        else
        {
          // Call BL200
          _processContext.setState(State.PP0257_BL200);
          Retour retourBL200 = PP0257_BL200_TransfererFichierExtraction(tracabilite_p, _processContext.getIdFluxExtraction());
          _processContext.setProcessRetour(retourBL200);
        }
      }
    }
    catch (Exception ex)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, ex.getMessage()));
    }
    finally
    {
      endSynchronousProcess(request_p, _processContext.getProcessRetour());
    }

    // Set Process Retour
    this.setRetour(_processContext.getProcessRetour());
    _processContext.setState(State.PP0257_END);
  }

  /**
   * Call RES database connector
   *
   * @param tracabilite_p
   *          Tracabilite
   * @return Retour OK if database connector invoked with success, KO otherwise
   * @throws RavelException
   *           Thrown by Database connector
   */
  private Retour callRESDatabase(Tracabilite tracabilite_p) throws RavelException
  {
    //Call RES to get the right type of Ressource
    switch (_processContext.getIdFluxExtraction())
    {
      case SPIRIT_RES_COMPTEMAIL:
        return RESDatabaseProxy.getInstance().getAllRessourceCompteMail(tracabilite_p, this).getResult();
      case SPIRIT_RES_COMPTEIMS:
        return RESDatabaseProxy.getInstance().getAllRessourceCompteIms(tracabilite_p, this).getResult();
      case SPIRIT_RES_IMPIFIXE:
        return RESDatabaseProxy.getInstance().getAllRessourceImpiFixe(tracabilite_p, this).getResult();
      case SPIRIT_RES_ADRIPCLF:
        return RESDatabaseProxy.getInstance().getAllRessourceAdresseIpClf(tracabilite_p, this).getResult();
      case SPIRIT_RES_MOTDEPASSEIMS:
        return RESDatabaseProxy.getInstance().getAllRessourceMotDePasseIms(tracabilite_p, this).getResult();
      default:
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_UNAUTHORIZED_RESSOURCE, _processContext.getIdFluxExtraction()));
    }
  }

  /**
   * Porte la vérification que l’ensemble des paramètres obligatoires de la configuration du processus sont définies.
   *
   * @param request_p
   *          request
   * @return OK/NOK retour
   */
  @LogProcessBL
  private Pair<Retour, GenericRequestParameters> PP0257_BL001_VerifierDonnees(Tracabilite tracabilite_p, Request request_p)
  {
    // Get url parameters
    Pair<Retour, GenericRequestParameters> paramsFromRequest = getParamsFromRequest(request_p);

    if (RetourFactory.isRetourNOK(paramsFromRequest._first))
    {
      return new Pair<>(paramsFromRequest._first, null);
    }

    /// Load config
    String configPP0257Param = getConfigParameter(PARAM_CONFIG_PATH);

    if (!StringTools.isNullOrEmpty(configPP0257Param))
    {
      try
      {
        Path configPP0257Path = Paths.get(configPP0257Param);
        String configPP0257File = new String(Files.readAllBytes(configPP0257Path));
        _processContext.setConfigurationPP0257(MarshallTools.unmarshall(GenericProcessConfig.class, configPP0257File));
      }
      catch (Exception exception)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_FILE_ERROR, exception.getMessage())), null);
      }
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, PARAM_CONFIG_PATH)), null);
    }

    // Check config parameters
    String chaineNomParam = GenericProcessConfigValidator.checkInexistantParams(_processContext.getConfigurationPP0257());
    if (chaineNomParam.length() > 0)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, chaineNomParam)), null);
    }

    // Check flux ids - FROM CONFIG
    String chaineNomFlux = GenericProcessConfigValidator.checkFluxId(_processContext.getConfigurationPP0257(), SPIRIT_RES_COMPTEMAIL, SPIRIT_RES_COMPTEIMS, SPIRIT_RES_IMPIFIXE, SPIRIT_RES_ADRIPCLF, SPIRIT_RES_MOTDEPASSEIMS);
    if (chaineNomFlux.length() > 0)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_UNAUTHORIZED_FLUX_ID, chaineNomFlux)), null);
    }
    String[] idFluxAutorisees = _processContext.getConfigurationPP0257().getIdFluxExtractionAutorises().split(";"); //$NON-NLS-1$

    for (String idFlux : idFluxAutorisees)
    {
      String idFluxAutorise = idFlux.trim();
      if (!IdFluxExtraction.isValidIdFluxAutorisee(idFluxAutorise))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_UNAUTHORIZED_FLUX_ID, idFluxAutorise)), null);
      }
    }

    // Validate flux id from Parameters
    boolean idFluxExtractionValid = GenericProcessConfigValidator.isIdFluxExtractionValid(paramsFromRequest._second.getIdFluxExtraction(), SPIRIT_RES_COMPTEMAIL, SPIRIT_RES_COMPTEIMS, SPIRIT_RES_IMPIFIXE, SPIRIT_RES_ADRIPCLF, SPIRIT_RES_MOTDEPASSEIMS);
    if (!idFluxExtractionValid)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_UNAUTHORIZED_FLUX_ID, paramsFromRequest._second.getIdFluxExtraction())), null);
    }

    return new Pair<>(RetourFactory.createOkRetour(), paramsFromRequest._second);
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param idFluxExtraction_p
   *          id flux extraction
   * @return Retour
   * @throws IOException
   *           ioException
   * @throws RavelException
   *           ravelException
   */
  @LogProcessBL
  private Retour PP0257_BL100_ProduireFicheirExtraction(Tracabilite tracabilite_p, String idFluxExtraction_p) throws RavelException, IOException
  {
    try
    {
      // Call BL901
      _processContext.setState(State.PP0257_BL901);
      Pair<Retour, List<IGenericWriter<Ressource>>> retourBL901 = BL901_InitWriters(tracabilite_p, _processContext.getConfigurationPP0257(), Collections.singletonList(idFluxExtraction_p), PRODUIRE_EXTRACTIONS);
      _processContext.setProcessRetour(retourBL901._first);

      if (RetourFactory.isRetourNOK(retourBL901._first))
      {
        return retourBL901._first;
      }

      // Store writers on context
      _processContext.setWriters(retourBL901._second);

      // Call BL102
      _processContext.setState(State.PP0257_BL902);
      Pair<Retour, ThreadPoolExecutor> retourBL902 = BL902_InitExecutor(tracabilite_p, _processContext.getConfigurationPP0257());
      _processContext.setProcessRetour(retourBL902._first);
      _processContext.setThreadPoolExecutor(retourBL902._second);

      if (RetourFactory.isRetourNOK(retourBL902._first))
      {
        return retourBL902._first;
      }

      // Invoke RESDatabaseConnector dynamically depending on the idFluxExtraction in the process context
      _processContext.setState(State.PP0257_CALLBACK);
      Retour retourRES = callRESDatabase(tracabilite_p);
      _processContext.setProcessRetour(retourRES);

      // Call BL903
      _processContext.setState(State.PP0257_BL903);
      Retour retourBL903 = BL903_WaitExecutor(tracabilite_p, _processContext.getConfigurationPP0257(), retourBL902._second, _processContext._threadPoolExecutorResult);
      _processContext.setProcessRetour(retourBL903);

      // Check Returns
      if (RetourFactory.isRetourNOK(retourRES))
      {
        if (IMegSpiritConsts.TIMEOUT.equals(retourRES.getDiagnostic()))
        {
          return retourRES;
        }
        else if (IMegConsts.DONNEE_INCONNUE.equals(retourRES.getDiagnostic()))
        {
          // Log
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(MESSAGE_AUCUNE_RESSOURCE, _processContext.getModeExecution(), tracabilite_p.getIdCorrelationByTel())));
          return RetourFactory.createOkRetour();
        }
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_LECTURE_IMPOSSIBLE);
      }
      else if (RetourFactory.isRetourKO(retourBL903))
      {
        return retourBL903;
      }
    }
    catch (RavelException re)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, re));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_LECTURE_IMPOSSIBLE);
    }
    finally
    {
      // Call BL904
      _processContext.setState(State.PP0257_BL904);
      BL904_CloseWriters(tracabilite_p, _processContext.getWriters(), _processContext.getConfigurationPP0257().getExtensionFichierTemporaire());
    }
    // Return OK
    return RetourFactory.createOkRetour();
  }

  /**
   * @param idFluxExtraction_p
   *          id extraction
   * @param tracabilite_p
   *          tracabilite
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP0257_BL200_TransfererFichierExtraction(Tracabilite tracabilite_p, String idFluxExtraction_p) throws RavelException
  {
    // Get configuration
    GenericProcessConfig configurationPP0257 = _processContext.getConfigurationPP0257();
    Pair<Retour, ConfigurationFluxExtraction> fluxExtraction = getConfigurationFluxExtraction(configurationPP0257, idFluxExtraction_p);

    if (RetourFactory.isRetourNOK(fluxExtraction._first))
    {
      return fluxExtraction._first;
    }

    // Get file list
    ConfigurationFluxExtraction matchingConfigFlux = fluxExtraction._second;

    String cheminRepTravail = configurationPP0257.getCheminRepTravail();

    File directory = new File(cheminRepTravail);
    if (directory.list().length >= 1)
    {
      List<File> files = FileUtils.getFiles(new File(cheminRepTravail), matchingConfigFlux.getPattern());

      // Process file list
      for (File file : files)
      {
        try
        {
          if (file.getName().endsWith(configurationPP0257.getExtensionFichierTemporaire()))
          {
            LocalDateTime modifiedDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(file.lastModified()), ZoneId.systemDefault());
            LocalDateTime retentionDate = DateTimeManager.getInstance().now().minusSeconds(configurationPP0257.getDureeRetentionTmp());

            // Check date
            if (modifiedDate.isBefore(retentionDate))
            {
              // Call BL3400
              BL3400_SupprimerFichier bl3400 = new BL3400_SupprimerFichier.BL3400_SupprimerFichierBuilder()//
                  .fileName(file.getName()) //
                  .repertoire(cheminRepTravail) //
                  .tracabilite(tracabilite_p) //
                  .build();
              bl3400.execute(this);
            }
          }
          else
          {
            // Call BL4300_EnvoyerFichier
            BL4300_EnvoyerFichier envoyerFichier = new BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder() //
                .tracabilite(tracabilite_p) //
                .chaineConnexion(addFileToURI(matchingConfigFlux.getChaineConnexion(), file.getName())) //
                .nomFichier(file.getName()) //
                .repertoire(cheminRepTravail) //
                .build();
            envoyerFichier.execute(this);
            Retour bl4300Retour = envoyerFichier.getRetour();

            if (RetourFactory.isRetourNOK(bl4300Retour))
            {
              if (IMegConsts.CAT1.equals(bl4300Retour.getCategorie()))
              {
                // Call BL1200_DeplacerFichier
                BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder() //
                    .tracabilite(tracabilite_p) //
                    .nomFichier(file.getName()) //
                    .repertoireSrc(configurationPP0257.getCheminRepTravail()) //
                    .repertoireDes(configurationPP0257.getCheminRepArchiveErreur()) //
                    .build();
                deplacerFichier.execute(this);
              }
              else
              {
                // Renvoyer Erreur et Sortir du traitement
                return bl4300Retour;
              }
            }
            else
            {
              // Call BL1200_DeplacerFichier
              BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder() //
                  .tracabilite(tracabilite_p) //
                  .nomFichier(file.getName()) //
                  .repertoireSrc(configurationPP0257.getCheminRepTravail()) //
                  .repertoireDes(configurationPP0257.getCheminRepArchiveSucces()) //
                  .build();
              deplacerFichier.execute(this);
            }
          }
        }
        catch (Exception exception)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
          return RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage());
        }
      }
    }
    return RetourFactory.createOkRetour();
  }
}