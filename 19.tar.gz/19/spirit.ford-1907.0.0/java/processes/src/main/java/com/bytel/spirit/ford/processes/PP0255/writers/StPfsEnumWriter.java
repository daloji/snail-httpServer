/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static java.util.Objects.nonNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pfs_enum.StPfsEnum;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class StPfsEnumWriter extends STWriter
{
  /**
   *
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  public enum StPfsEnumHeader
  {
    /**
     *
     */
    ID_ST(0),

    /**
     *
     */
    STATUT(1),

    /**
     *
     */
    COMMENTAIRE(2),

    /**
     *
     */
    CLIENT_OPERATEUR(3),

    /**
     *
     */
    NO_COMPTE(4),

    /**
     *
     */
    ID_PA(5),

    /**
     *
     */
    NO_TELEPHONE(6),

    /**
     *
     */
    SIP_URI(7),

    /**
     *
     */
    DATE_CREATION(8),

    /**
     *
     */
    DATE_MODIFICATION(9);

    /**
     * The header size
     */
    static final int ST_PFS_ENUM_HEADER_SIZE = 10;

    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    StPfsEnumHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public StPfsEnumWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    super(filePath_p, fileName_p, linesToFlush_p);
    createFile(filePath_p + fileName_p, StPfsEnumHeader.class);
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique objectToWrite_p)
  {
    if (shouldExecuteDump(objectToWrite_p))
    {
      executeDumpAction(tracabilite_p, objectToWrite_p);
    }
  }

  @Override
  protected void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    StPfsGenerique stPfsGenerique = StPfsGenerique.class.cast(serviceTechnique_p);
    StPfsEnum stPfsEnum = deserializeRawFields(tracabilite_p, stPfsGenerique);//because of raw json fields from SAAB
    List<String> record = this.getRecord(stPfsEnum);

    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  protected boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p)
  {
    if (serviceTechnique_p != null)
    {
      if (TypeST.PFS.name().equals(serviceTechnique_p.getTypeServiceTechnique()))
      {
        return TypePFS.ENUM.name().equals(StPfsGenerique.class.cast(serviceTechnique_p).getTypePfs());
      }
    }
    return false;
  }

  /**
   * Convert an instance of StPfsGenerique object (having json raw fields) to an instance of StPfsEnum.
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @param stPfsGenerique_p
   *          Instance of StPfsGenerique
   * @return An instance of StPfsEnum if deserialization succeeds, null otherwise.
   */
  private StPfsEnum deserializeRawFields(Tracabilite tracabilite_p, StPfsGenerique stPfsGenerique_p)
  {
    StPfsEnum stPfsEnum = null;
    try
    {
      stPfsEnum = stPfsGenerique_p != null ? StPfsEnum.buildFromStPfsGenerique(stPfsGenerique_p) : null;
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
    }
    return stPfsEnum;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param stPfsEnum_p
   *          The ServiceTechnique
   *
   * @return List of values
   */
  private List<String> getRecord(StPfsEnum stPfsEnum_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[StPfsEnumHeader.ST_PFS_ENUM_HEADER_SIZE]));

    if (nonNull(stPfsEnum_p))
    {
      record.set(StPfsEnumHeader.ID_ST.getIndex(), stPfsEnum_p.getIdSt());
      record.set(StPfsEnumHeader.STATUT.getIndex(), stPfsEnum_p.getStatut());
      record.set(StPfsEnumHeader.COMMENTAIRE.getIndex(), stPfsEnum_p.getCommentaire());
      record.set(StPfsEnumHeader.CLIENT_OPERATEUR.getIndex(), stPfsEnum_p.getClientOperateur());
      record.set(StPfsEnumHeader.NO_COMPTE.getIndex(), stPfsEnum_p.getNoCompte());

      if (stPfsEnum_p.getDonneesIdentification() != null)
      {
        record.set(StPfsEnumHeader.ID_PA.getIndex(), stPfsEnum_p.getDonneesIdentificationStPfsEnum().getIdentifiantFonctionnelPa());
      }

      if (stPfsEnum_p.getDonneesProvisionnees() != null)
      {
        record.set(StPfsEnumHeader.NO_TELEPHONE.getIndex(), stPfsEnum_p.getDonneesProvisionneesStPfsEnum().getNoTelephone());
        record.set(StPfsEnumHeader.SIP_URI.getIndex(), stPfsEnum_p.getDonneesProvisionneesStPfsEnum().getSipUri());
      }

      record.set(StPfsEnumHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsEnum_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
      record.set(StPfsEnumHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsEnum_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
      return record;
    }

    return Collections.emptyList();
  }
}
