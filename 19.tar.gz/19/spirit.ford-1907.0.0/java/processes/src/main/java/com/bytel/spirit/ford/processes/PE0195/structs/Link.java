/*******************************************************************************
* $Id: Link.java 7839 2018-07-13 10:14:50Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PE0195.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author lmerces
 * @version ($Revision: 7839 $ $Date: 2018-07-13 12:14:50 +0200 (ven. 13 juil. 2018) $)
 */
public class Link implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -4255576549052643440L;

  /**
   * rel attribute
   */
  @SerializedName("rel")
  @Expose
  private String _rel;

  /**
   * href attribute
   */
  @SerializedName("href")
  @Expose
  private String _href;

  /**
   * Constructor
   */
  public Link()
  {
    super();
  }

  /**
   * Constructor
   *
   * @param rel_p
   *          rel
   * @param href_p
   *          href
   */
  public Link(String rel_p, String href_p)
  {
    super();
    _rel = rel_p;
    _href = href_p;
  }

  /**
   * @return the href
   */
  public String getHref()
  {
    return _href;
  }

  /**
   * @return the rel
   */
  public String getRel()
  {
    return _rel;
  }

  /**
   * @param href_p
   *          the href to set
   */
  public void setHref(String href_p)
  {
    _href = href_p;
  }

  /**
   * @param rel_p
   *          the rel to set
   */
  public void setRel(String rel_p)
  {
    _rel = rel_p;
  }
}
