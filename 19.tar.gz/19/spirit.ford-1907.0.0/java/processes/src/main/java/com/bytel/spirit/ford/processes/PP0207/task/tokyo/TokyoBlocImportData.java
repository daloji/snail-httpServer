/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.task.tokyo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.spirit.common.shared.saab.res.CouvertureTokyo;
import com.bytel.spirit.ford.processes.PP0207.task.IBlocImportData;

/**
 * Transition data for Tokyo couverture multi-threaded import.
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class TokyoBlocImportData implements IBlocImportData<CouvertureTokyo>
{
  /** Simple list : will be used by one thread at a time. */
  private final List<CouvertureTokyo> _blocLines = new ArrayList<>();

  @Override
  public void addLine(CSVLine line_p)
  {
    CouvertureTokyo couvertureTokyo = new CouvertureTokyo(line_p.getString(0), line_p.getString(1));
    _blocLines.add(couvertureTokyo);
  }

  @Override
  public List<CouvertureTokyo> getBloc()
  {
    return Collections.unmodifiableList(_blocLines);
  }

  @Override
  public boolean isEmpty()
  {
    return _blocLines.isEmpty();
  }

  @Override
  public int size()
  {
    return _blocLines.size();
  }

}