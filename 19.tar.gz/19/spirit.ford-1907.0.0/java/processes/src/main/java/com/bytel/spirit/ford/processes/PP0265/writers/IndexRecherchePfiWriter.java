/*******************************************************************************
* $Id: IndexRecherchePfiWriter.java 19207 2019-03-28 13:17:54Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0265.writers;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.csv.CSVPrinter;
import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.CleRecherche;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0098.structs.AirPfiWriter.PFIHeader;
import com.bytel.spirit.ford.shared.misc.processes.writers.IGenericWriter;

/**
 *
 * @author pcarreir
 * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
 */
public class IndexRecherchePfiWriter implements IGenericWriter<IndexRecherchePfi>
{
  /**
   * Class containing the Index Recherche PFI entete to write in CSV File.
   *
   * @author pcarreir
   * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
   */
  public enum IndexRecherchePfiHeader
  {
    /**
     *
     */
    TYPE_CLE(0),

    /**
     *
     */
    VALEUR_CLE(1),

    /**
     *
     */
    CLIENT_OPERATEUR(2),

    /**
     *
     */
    NO_COMPTE(3);

    /**
     * The header size
     */
    static final int PFI_HEADER_SIZE = 4;

    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    IndexRecherchePfiHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }

  }

  /**
   * CSV values separator
   */
  public static final char CSV_SEPARATOR = ';';

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;

  /**
   * Number of maximum lines to write without performing a flush on the CSV file.
   */
  private int _linesToFlush;

  /**
   * The path of CSV file.
   */
  private String _filePath;

  /**
   * The name of CSV file.
   */
  private String _fileName;

  /**
   * Number of lines dumped in the CSV file.
   */
  private int _currentDumpedLines = 0;

  /**
   * retour
   */
  private Retour _retour;

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public IndexRecherchePfiWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    _filePath = filePath_p;
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    _retour = RetourFactory.createOkRetour();

    createFile(filePath_p + fileName_p, IndexRecherchePfiHeader.class);
  }

  @Override
  public void close() throws IOException
  {
    _csvPrinter.flush();
    _csvPrinter.close();
  }

  @Override
  public void dump(Tracabilite tracabilite_p, IndexRecherchePfi objectToWrite_p)
  {
    for (CleRecherche cle : objectToWrite_p.getListeCleRecherche())
    {
      List<String> record = this.getRecord(objectToWrite_p, cle);
      if (!CollectionUtils.isEmpty(record))
      {
        write(tracabilite_p, record);
      }
    }
  }

  @Override
  public String getFileName()
  {
    return _fileName;
  }

  @Override
  public String getFilePath()
  {
    return _filePath;
  }

  /**
   * This method will return the dump execution result
   *
   * @return {@link Retour}
   */
  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  @Override
  public void setCSVPrinter(CSVPrinter csvPrinter_p)
  {
    this._csvPrinter = csvPrinter_p;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param indexRecherchePfi_p
   *          The index recherche pfi
   * @param cleRecherche_p
   *          The search key
   *
   * @return List of values
   */
  private List<String> getRecord(IndexRecherchePfi indexRecherchePfi_p, CleRecherche cleRecherche_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[IndexRecherchePfiHeader.values().length]));

    record.set(PFIHeader.TYPE_CLE.getIndex(), cleRecherche_p.getType());
    record.set(PFIHeader.VALEUR_CLE.getIndex(), cleRecherche_p.getValeur());
    record.set(PFIHeader.CLIENT_OPERATEUR.getIndex(), indexRecherchePfi_p.getClientOperateur());
    record.set(PFIHeader.NO_COMPTE.getIndex(), indexRecherchePfi_p.getNoCompte());

    return record;
  }

  /**
   * Write in the CSV file the list of records. Each record corresponds to a line.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param record_p
   *          The list of records.
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> record_p)
  {
    try
    {
      _csvPrinter.printRecord(record_p);
      //check if a flush is needed
      if ((++_currentDumpedLines % this._linesToFlush) == 0)
      {
        _csvPrinter.flush();
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }

}
