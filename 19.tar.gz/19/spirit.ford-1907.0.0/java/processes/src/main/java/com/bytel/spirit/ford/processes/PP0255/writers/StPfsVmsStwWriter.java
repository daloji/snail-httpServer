/*******************************************************************************
* $Id: StPfsVmsStwWriter.java 18813 2019-03-21 09:58:12Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static java.util.Objects.nonNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.StPfsVmsStw;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author pcarreir
 * @version ($Revision: 18813 $ $Date: 2019-03-21 10:58:12 +0100 (jeu. 21 mars 2019) $)
 */
public class StPfsVmsStwWriter extends STWriter
{
  /**
   * Class containing the StLienAllocationCommercial entete to write in CSV File.
   *
   * @author pcarreir
   * @version ($Revision: 18813 $ $Date: 2019-03-21 10:58:12 +0100 (jeu. 21 mars 2019) $)
   */
  public enum StPfsVmsStwHeader
  {
    /**
     *
     */
    ID_ST(0),

    /**
     *
     */
    STATUT(1),

    /**
     *
     */
    COMMENTAIRE(2),

    /**
     *
     */
    CLIENT_OPERATEUR(3),

    /**
     *
     */
    NO_COMPTE(4),

    /**
     *
     */
    ID_PA(5),

    /**
     *
     */
    NO_TELEPHONE(6),

    /**
     *
     */
    TYPE_USAGE(7),

    /**
    *
    */
    LIGNE_MARCHE(8),

    /**
    *
    */
    ADRESSE_MAIL(9),

    /**
    *
    */
    NOM_PRENOM_UTILISATEUR(10),

    /**
     *
     */
    DATE_CREATION(11),

    /**
     *
     */
    DATE_MODIFICATION(12);

    /**
     * The header size
     */
    static final int ST_PFS_VMS_STW_HEADER_SIZE = 13;

    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    StPfsVmsStwHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public StPfsVmsStwWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    super(filePath_p, fileName_p, linesToFlush_p);
    createFile(filePath_p + fileName_p, StPfsVmsStwHeader.class);
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique objectToWrite_p)
  {
    if (shouldExecuteDump(objectToWrite_p))
    {
      executeDumpAction(tracabilite_p, objectToWrite_p);
    }
  }

  @Override
  protected void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    StPfsGenerique stPfsGenerique = StPfsGenerique.class.cast(serviceTechnique_p);
    StPfsVmsStw stPfsVmsStw = deserializeRawFields(tracabilite_p, stPfsGenerique);//because of raw json fields from SAAB
    List<String> record = this.getRecord(stPfsVmsStw);

    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  protected boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p)
  {
    if (serviceTechnique_p != null)
    {
      if (TypeST.PFS.name().equals(serviceTechnique_p.getTypeServiceTechnique()))
      {
        return TypePFS.VMS_STW.name().equals(StPfsGenerique.class.cast(serviceTechnique_p).getTypePfs());
      }
    }
    return false;
  }

  /**
   * Convert an instance of StPfsGenerique object (having json raw fields) to an instance of StPfsVmsStw.
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @param stPfsGenerique_p
   *          Instance of StPfsGenerique
   * @return An instance of StPfsVmsStw if deserialization succeeds, null otherwise.
   */
  private StPfsVmsStw deserializeRawFields(Tracabilite tracabilite_p, StPfsGenerique stPfsGenerique_p)
  {
    StPfsVmsStw stPfsVmsStw = null;
    try
    {
      stPfsVmsStw = stPfsGenerique_p != null ? StPfsVmsStw.buildFromStPfsGenerique(stPfsGenerique_p) : null;
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
    }
    return stPfsVmsStw;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param stPfsVmsStw_p
   *          The ServiceTechnique
   *
   * @return List of values
   */
  private List<String> getRecord(StPfsVmsStw stPfsVmsStw_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[StPfsVmsStwHeader.ST_PFS_VMS_STW_HEADER_SIZE]));

    if (nonNull(stPfsVmsStw_p))
    {
      record.set(StPfsVmsStwHeader.ID_ST.getIndex(), stPfsVmsStw_p.getIdSt());
      record.set(StPfsVmsStwHeader.STATUT.getIndex(), stPfsVmsStw_p.getStatut());
      record.set(StPfsVmsStwHeader.COMMENTAIRE.getIndex(), stPfsVmsStw_p.getCommentaire());
      record.set(StPfsVmsStwHeader.CLIENT_OPERATEUR.getIndex(), stPfsVmsStw_p.getClientOperateur());
      record.set(StPfsVmsStwHeader.NO_COMPTE.getIndex(), stPfsVmsStw_p.getNoCompte());

      if (stPfsVmsStw_p.getDonneesIdentificationSTPfsVmsStw() != null)
      {
        record.set(StPfsVmsStwHeader.ID_PA.getIndex(), stPfsVmsStw_p.getDonneesIdentificationSTPfsVmsStw().getIdentifiantFonctionnelPa());
      }

      if (stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw() != null)
      {
        record.set(StPfsVmsStwHeader.NO_TELEPHONE.getIndex(), stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw().getNoTelephone());
        record.set(StPfsVmsStwHeader.TYPE_USAGE.getIndex(), stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw().getTypeUsage());
        record.set(StPfsVmsStwHeader.LIGNE_MARCHE.getIndex(), stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw().getLigneMarche());
        record.set(StPfsVmsStwHeader.ADRESSE_MAIL.getIndex(), stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw().getAdresseMail());
        record.set(StPfsVmsStwHeader.NOM_PRENOM_UTILISATEUR.getIndex(), stPfsVmsStw_p.getDonneesProvisionneesSTPfsVmsStw().getNomPrenomUtilisateur());
      }

      record.set(StPfsVmsStwHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsVmsStw_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
      record.set(StPfsVmsStwHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsVmsStw_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
      return record;
    }

    return Collections.emptyList();
  }
}
