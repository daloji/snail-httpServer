/*******************************************************************************
* $Id: CuivreBlocImportData.java 14226 2018-12-06 15:29:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.task.cuivre;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.spirit.common.shared.saab.res.CouvertureCuivre;
import com.bytel.spirit.ford.processes.PP0207.task.IBlocImportData;

/**
 * Transition data for Cuivre couverture multi-threaded import.
 *
 * @author jstrub
 * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
 */
public class CuivreBlocImportData implements IBlocImportData<CouvertureCuivre>
{
  /** Simple list : will be used by one thread at a time. */
  private final List<CouvertureCuivre> _blocLines = new ArrayList<>();

  @Override
  public void addLine(CSVLine line_p)
  {
    CouvertureCuivre couvertureCuivre = new CouvertureCuivre(line_p.getString(0), line_p.getString(1), line_p.getString(2), line_p.getString(4), line_p.getString(5), line_p.getString(6));
    couvertureCuivre.setNumeroComplement(line_p.getString(3));
    couvertureCuivre.setLibelleCommune2(line_p.getString(7));
    _blocLines.add(couvertureCuivre);
  }

  @Override
  public List<CouvertureCuivre> getBloc()
  {
    return Collections.unmodifiableList(_blocLines);
  }

  @Override
  public boolean isEmpty()
  {
    return _blocLines.isEmpty();
  }

  @Override
  public int size()
  {
    return _blocLines.size();
  }

}
