/*******************************************************************************
* $Id: AbstractRESImportTaskFactory.java 13227 2018-11-15 13:48:27Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.task;

import com.bytel.ravel.services.process.task.IRavelTaskFactory;

/**
 * Common abstract task factory implementation for RES import tasks. <br />
 * One task should be created for every non-null/non-empty transition data .
 *
 * @author jstrub
 * @version ($Revision: 13227 $ $Date: 2018-11-15 14:48:27 +0100 (jeu. 15 nov. 2018) $)
 * @param <T>
 *          Type of imported file
 */
public abstract class AbstractRESImportTaskFactory<T extends AbstractRESImportTask<?>> implements IRavelTaskFactory<T>
{

  /** Import context. */
  protected final ImportContext _context;

  /**
   * @param context_p
   *          the context
   */
  public AbstractRESImportTaskFactory(ImportContext context_p)
  {
    _context = context_p;
  }

}
