/*******************************************************************************
* $Id: StPfsSamWriter.java 19383 2019-04-01 09:14:12Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static java.util.Objects.nonNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.StPfsSam;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author pcarreir
 * @version ($Revision: 19383 $ $Date: 2019-04-01 11:14:12 +0200 (lun. 01 avril 2019) $)
 */
public class StPfsSamWriter extends STWriter
{
  /**
   * Class containing the StLienAllocationCommercial entete to write in CSV File.
   *
   * @author pcarreir
   * @version ($Revision: 19383 $ $Date: 2019-04-01 11:14:12 +0200 (lun. 01 avril 2019) $)
   */
  public enum StPfsSamHeader
  {
    /**
     *
     */
    ID_ST(0),

    /**
     *
     */
    STATUT(1),

    /**
     *
     */
    COMMENTAIRE(2),

    /**
     *
     */
    CLIENT_OPERATEUR(3),

    /**
     *
     */
    NO_COMPTE(4),

    /**
     *
     */
    ID_PA(5),

    /**
     *
     */
    ID_COMPTE_IMS(6),

    /**
     *
     */
    NO_TELEPHONE(7),

    /**
     *
     */
    TYPE_USAGE(8),

    /**
     *
     */
    IMPI_FIXE(9),

    /**
     *
     */
    MOT_DE_PASSE_IMS(10),

    /**
     *
     */
    SIP_URI(11),

    /**
     *
     */
    TEL_URI(12),

    /**
     *
     */
    NOM(13),

    /**
     *
     */
    PRENOM(14),

    /**
     *
     */
    NOM_PRENOM_COURT(15),

    /**
     *
     */
    NIVEAU_RESTRICTION(16),

    /**
     *
     */
    NOTIFICATION_SUPENSION(17),

    /**
     *
     */
    OPTION_APPEL_SURTAXES(18),

    /**
     *
     */
    DATE_CREATION(19),

    /**
     *
     */
    DATE_MODIFICATION(20);

    /**
     * The header size
     */
    static final int ST_PFS_SAM_HEADER_SIZE = 21;

    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    StPfsSamHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public StPfsSamWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    super(filePath_p, fileName_p, linesToFlush_p);
    createFile(filePath_p + fileName_p, StPfsSamHeader.class);
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique objectToWrite_p)
  {
    if (shouldExecuteDump(objectToWrite_p))
    {
      executeDumpAction(tracabilite_p, objectToWrite_p);
    }
  }

  @Override
  protected void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    StPfsGenerique stPfsGenerique = StPfsGenerique.class.cast(serviceTechnique_p);
    StPfsSam stPfsSam = deserializeRawFields(tracabilite_p, stPfsGenerique);//because of raw json fields from SAAB
    List<String> record = this.getRecord(stPfsSam);

    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  protected boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p)
  {
    if (serviceTechnique_p != null)
    {
      if (TypeST.PFS.name().equals(serviceTechnique_p.getTypeServiceTechnique()))
      {
        return TypePFS.SAM.name().equals(StPfsGenerique.class.cast(serviceTechnique_p).getTypePfs());
      }
    }
    return false;
  }

  /**
   * Convert an instance of StPfsGenerique object (having json raw fields) to an instance of StPfsSam.
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @param stPfsGenerique_p
   *          Instance of StPfsGenerique
   * @return An instance of StPfsSam if deserialization succeeds, null otherwise.
   */
  private StPfsSam deserializeRawFields(Tracabilite tracabilite_p, StPfsGenerique stPfsGenerique_p)
  {
    StPfsSam stPfsSam = null;
    try
    {
      stPfsSam = stPfsGenerique_p != null ? StPfsSam.buildFromStPfsGenerique(stPfsGenerique_p) : null;
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
    }
    return stPfsSam;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param stPfsSam_p
   *          The ServiceTechnique
   *
   * @return List of values
   */
  private List<String> getRecord(StPfsSam stPfsSam_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[StPfsSamHeader.ST_PFS_SAM_HEADER_SIZE]));

    if (nonNull(stPfsSam_p))
    {
      record.set(StPfsSamHeader.ID_ST.getIndex(), stPfsSam_p.getIdSt());
      record.set(StPfsSamHeader.STATUT.getIndex(), stPfsSam_p.getStatut());
      record.set(StPfsSamHeader.COMMENTAIRE.getIndex(), stPfsSam_p.getCommentaire());
      record.set(StPfsSamHeader.CLIENT_OPERATEUR.getIndex(), stPfsSam_p.getClientOperateur());
      record.set(StPfsSamHeader.NO_COMPTE.getIndex(), stPfsSam_p.getNoCompte());

      if (stPfsSam_p.getDonneesIdentificationStPfsSam() != null)
      {
        record.set(StPfsSamHeader.ID_PA.getIndex(), stPfsSam_p.getDonneesIdentificationStPfsSam().getIdentifiantFonctionnelPa());
      }

      if (stPfsSam_p.getDonneesProvisionneesStPfsSam() != null)
      {
        record.set(StPfsSamHeader.ID_COMPTE_IMS.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getIdCompteIms());
        record.set(StPfsSamHeader.NO_TELEPHONE.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getNoTelephone());
        record.set(StPfsSamHeader.TYPE_USAGE.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getTypeUsage());
        record.set(StPfsSamHeader.IMPI_FIXE.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getImpiFixe());
        record.set(StPfsSamHeader.MOT_DE_PASSE_IMS.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getMotDePasseIms());
        record.set(StPfsSamHeader.SIP_URI.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getSipUri());
        record.set(StPfsSamHeader.TEL_URI.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getTelUri());
        record.set(StPfsSamHeader.NOM.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getNom());
        record.set(StPfsSamHeader.PRENOM.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getPrenom());
        record.set(StPfsSamHeader.NOM_PRENOM_COURT.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getNomPrenomCourt());
        record.set(StPfsSamHeader.NIVEAU_RESTRICTION.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getNiveauRestriction());
        record.set(StPfsSamHeader.NOTIFICATION_SUPENSION.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getNotificationSuspension());
        record.set(StPfsSamHeader.OPTION_APPEL_SURTAXES.getIndex(), stPfsSam_p.getDonneesProvisionneesStPfsSam().getOptionAppelSurTaxes());
      }

      record.set(StPfsSamHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsSam_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
      record.set(StPfsSamHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsSam_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
      return record;
    }

    return Collections.emptyList();
  }
}
