/*******************************************************************************
* $Id: PE0195_GestionTraitementsDeMasse.java 16383 2019-01-28 16:01:56Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PE0195;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.data.exchange.generated.RavelResponse.ResponseHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.files.FileTransferResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1000_ObtenirConfigurationReceptionFichier;
import com.bytel.spirit.common.activities.shared.BL1000_ObtenirConfigurationReceptionFichier.BL1000_ObtenirConfigurationReceptionFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier.BL1300_CreerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence;
import com.bytel.spirit.common.activities.shared.BL800_ObtenirSequence.BL800_ObtenirSequenceBuilder;
import com.bytel.spirit.common.activities.shared.BL900_ObtenirConfigurationEmissionFichier;
import com.bytel.spirit.common.activities.shared.BL900_ObtenirConfigurationEmissionFichier.BL900_ObtenirConfigurationEmissionFichierBuilder;
import com.bytel.spirit.common.activities.shared.structs.ConfigurationEmission;
import com.bytel.spirit.common.activities.shared.structs.ConfigurationReception;
import com.bytel.spirit.common.activities.shared.structs.UniqueIdConstant;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.BasicResponse;
import com.bytel.spirit.common.shared.misc.ressources.RetourConverter;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rex.AssociationPfiReconcialitionCommerciale;
import com.bytel.spirit.common.shared.saab.rex.ReconciliationCommerciale;
import com.bytel.spirit.common.shared.saab.rex.Statut;
import com.bytel.spirit.common.shared.saab.rex.TraitementDeMasse;
import com.bytel.spirit.common.shared.saab.rex.TypeTraitement;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PE0195.structs.Link;
import com.bytel.spirit.ford.processes.PE0195.structs.PE0195_GestionTraitementsDeMasseResponse;
import com.bytel.spirit.ford.processes.PE0195.structs.PE0195_GestionTraitementsDeMasseUnitaireResponse;
import com.bytel.spirit.ford.processes.PE0195.structs.PE0195_PostBodyRequest;
import com.bytel.spirit.ford.processes.PE0195.structs.RelType;
import com.bytel.spirit.ford.processes.PE0195.structs.TraitementDeMasseIHM;

import spirit.saab.common.activities.shared.BL6401_GetTraitementDeMasseById;
import spirit.saab.common.activities.shared.BL6401_GetTraitementDeMasseById.BL6401_GetTraitementDeMasseByIdBuilder;
import spirit.saab.common.activities.shared.BL6402_GetTraitementDeMasseByStatut;
import spirit.saab.common.activities.shared.BL6402_GetTraitementDeMasseByStatut.BL6402_GetTraitementDeMasseByStatutBuilder;
import spirit.saab.common.activities.shared.BL6403_CreateTraitementDeMasse;
import spirit.saab.common.activities.shared.BL6403_CreateTraitementDeMasse.BL6403_CreateTraitementDeMasseBuilder;
import spirit.saab.common.activities.shared.BL6404_UpdateTraitementDeMasse;
import spirit.saab.common.activities.shared.BL6404_UpdateTraitementDeMasse.BL6404_UpdateTraitementDeMasseBuilder;
import spirit.saab.common.activities.shared.BL6501_GetReconciliationCommercialeEnMasse;
import spirit.saab.common.activities.shared.BL6501_GetReconciliationCommercialeEnMasse.BL6501_GetReconciliationCommercialeEnMasseBuilder;
import spirit.saab.common.activities.shared.BL6502_AjouterReconciliationCommercialeEnMasse;
import spirit.saab.common.activities.shared.BL6502_AjouterReconciliationCommercialeEnMasse.BL6502_AjouterReconciliationCommercialeEnMasseBuilder;
import spirit.saab.common.activities.shared.structs.BL6501_Response;

/**
 *
 * @author lmerces
 * @version ($Revision: 16383 $ $Date: 2019-01-28 17:01:56 +0100 (lun. 28 janv. 2019) $)
 */
public class PE0195_GestionTraitementsDeMasse extends SpiritRestApiProcessSkeleton
{
  /**
   * The enum to input Parameters Url
   *
   * @author lmerces
   * @version ($Revision: 16383 $ $Date: 2019-01-28 17:01:56 +0100 (lun. 28 janv. 2019) $)
   */
  public enum ParameterUrl
  {
    /**
     * Statut des traitements de masse qu'on veut lister
     */
    statut,

    /**
     * Statut des traitements unitaires déclenchés dans le cadre du traitement de masse
     */
    statutTraitementUnitaire
  }

  /**
   * The Enum containing all process states
   *
   * @author lmerces
   * @version ($Revision: 16383 $ $Date: 2019-01-28 17:01:56 +0100 (lun. 28 janv. 2019) $)
   */
  public enum State
  {
    /**
     * Verifier_Donnes
     */
    PE0195_BL001(MandatoryProcessState.PRC_START, false, false),
    /**
     * Formater_Reponse
     */
    PE0195_BL002(MandatoryProcessState.PRC_RUNNING, false, true),
    /**
     * Creation_Traitement_Masse
     */
    PE0195_BL100(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * Process context
   *
   * @author lmerces
   * @version ($Revision: 16383 $ $Date: 2019-01-28 17:01:56 +0100 (lun. 28 janv. 2019) $)
   */
  static final class PE0195_GestionTraitementsDeMasseContext extends Context
  {

    /**
     *
     */
    private static final long serialVersionUID = 2638688953456277806L;

    /***
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    State _state = State.PE0195_BL001;

    /**
     * The source from header
     */
    String _xSource;

    /**
     * The process from header
     */
    String _xProcess;

    /**
     * The requestId from header
     */
    String _xRequestId;

    /**
     * The statut.
     */
    String _statut;

    /**
     * The configuration file
     */
    String _fichierDeConfiguration;

    /**
     * The id traitement de masse.
     */
    String _idTraitementDeMasse;

    /**
     * Statut traitement unitaire
     */
    String _statutTraitementUnitaire;

    /**
     * Traitement de masse
     */
    TraitementDeMasse _traitementDeMasse;
  }

  /**
   * URL
   */
  public static final String URL = "traitements-de-masse/"; //$NON-NLS-1$

  /**
   * Statut
   */
  public static final String STATUT = "?statutTraitementUnitaire="; //$NON-NLS-1$

  /**
   * PE0195_BL001_HEADER_NULL_OR_EMPTY
   */
  private static final String PE0195_BL001_HEADER_NULL_OR_EMPTY = "PE0195.BL001.HeaderNullOrEmpty"; //$NON-NLS-1$

  /**
   * CLIENT_OPERATEUR
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * TYPE_TRAITEMENT_DE_MASSE
   */
  private static final String TYPE_TRAITEMENT_DE_MASSE = "typeTraitementDeMasse"; //$NON-NLS-1$

  /**
   * TRAITEMENT_DE_MASSE
   */
  private static final String TRAITEMENT_DE_MASSE = "traitementDeMasse"; //$NON-NLS-1$

  /**
   * TRAITEMENT_DE_MASSE_PATH
   */
  private static final String TRAITEMENT_DE_MASSE_PATH = "traitementDeMassePath"; //$NON-NLS-1$

  /**
   * NOM_FICHIER
   */
  private static final String NOM_FICHIER = "nomFichier"; //$NON-NLS-1$

  /**
   * LOCATION
   */
  private static final String LOCATION = "Location"; //$NON-NLS-1$

  /**
   * IHM_UPLOAD
   */
  private static final String IHM_UPLOAD = "IHM_UPLOAD"; //$NON-NLS-1$

  /**
   * EXPLOIT_BSS
   */
  private static final String EXPLOIT_BSS = "EXPLOIT_BSS"; //$NON-NLS-1$

  /**
   * RECONCILIATION_MASSE
   */
  private static final String RECONCILIATION_MASSE = "RECONCILIATION_MASSE"; //$NON-NLS-1$

  /**
   * TRAITEMENT_MASSE
   */
  private static final String TRAITEMENT_MASSE = "TRAITEMENT_MASSE"; //$NON-NLS-1$

  /**
   * FICHIER_DE_CONFIGURATION
   */
  private static final String FICHIER_DE_CONFIGURATION = "fichierConfiguration"; //$NON-NLS-1$

  /**
   * FILE_PREFIX
   */
  private static final String FILE_PREFIX = "Reconciliations_Masse_"; //$NON-NLS-1$

  /**
   * TAILLE_MAX_BLOC
   */
  private static final String TAILLE_MAX_BLOC = "TailleMaxBloc"; //$NON-NLS-1$

  /**
   * PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY
   */
  private static final String PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY = "PE0195.BL001.BodyFieldNullOrEmpty"; //$NON-NLS-1$

  /**
   * MAX_BLOCK_SIZE
   */
  private static final int MAX_BLOCK_SIZE = 1000;

  /**
   *
   */
  private static final long serialVersionUID = 4639593999172320998L;

  /**
   * The constant for MissingConfigurationParameter
   */
  private static final String MESSAGE_MISSING_CONFIGURATION_PARAMETER = Messages.getString("PE0195.GestionTraitementsDeMasse.MissingConfigurationParameter"); //$NON-NLS-1$

  /**
   * The constant for MissingConfigurationParameter
   */
  private static final String MESSAGE_MISSING_CONFIGURATION_FILE = Messages.getString("PE0195.GestionTraitementsDeMasse.MissingConfigurationFile"); //$NON-NLS-1$

  /**
   * Object _processContext
   */
  private PE0195_GestionTraitementsDeMasseContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext._state.toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext._state._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0195_GestionTraitementsDeMasseContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext._state._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext._state._replayableState;
  }

  @Override
  protected void continueGetProcess(Tracabilite tracabilite_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, Messages.getString("PE0195.UnexpectedContinueGetProcessReceived")); //$NON-NLS-1$
  }

  @Override
  protected void continuePostProcess() throws RavelException
  {
    super.continuePostProcess();
  }

  @LogContinueProcess
  @Override
  protected void continuePostProcess(Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    try
    {
      switch (_processContext._state)
      {
        case PE0195_BL002:
          _processContext._state = State.PE0195_BL100;
          Pair<TraitementDeMasse, Retour> pe195Ret = PE0195_BL100_CreationTraitementMasse(tracabilite_p, _processContext._traitementDeMasse);
          retour = pe195Ret._second;
          break;
        default:
          throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, Messages.getString("PE0195.UnexpectedContinuePostProcessReceived")); //$NON-NLS-1$
      }
    }
    catch (Exception exception)
    {
      // Always catch exception in continueProcess
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, exception.getMessage());
    }

    setRetour(retour);
    _processContext._state = State.ENDED;
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    handleGetRequest(request_p, tracabilite_p);
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startPostProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    handlePostRequest(request_p, tracabilite_p);
  }

  /**
   * Check headers
   *
   * @param request_p
   *          The request
   * @param tracabilite_p
   *          The trace
   *
   * @return {@link Retour}
   */
  private Retour checkHeaders(Request request_p, Tracabilite tracabilite_p)
  {
    String source = null;
    String process = null;
    String requestId = null;

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        process = header.getValue();
      }
      else if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        source = header.getValue();
      }
      else if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()))
      {
        requestId = header.getValue();
      }
    }

    if (StringTools.isNullOrEmpty(source))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_SOURCE)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_SOURCE));
    }
    if (StringTools.isNullOrEmpty(process))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_PROCESS)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_PROCESS));
    }
    if (StringTools.isNullOrEmpty(requestId))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_REQUEST_ID)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_REQUEST_ID));
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Converts data
   *
   * @param listTraitementDeMasse_p
   *          list
   * @return a list
   */
  private List<TraitementDeMasseIHM> convertList(List<TraitementDeMasse> listTraitementDeMasse_p)
  {
    List<TraitementDeMasseIHM> newList = new ArrayList<TraitementDeMasseIHM>();
    for (Iterator<TraitementDeMasse> iterator = listTraitementDeMasse_p.iterator(); iterator.hasNext();)
    {
      newList.add(createTraitementDeMasse(iterator.next()));
    }
    return newList;
  }

  /**
   * Creates a link
   *
   * @param idTraitementDeMasse_p
   *          id
   * @param relType_p
   *          rel
   * @return {@link Link}
   */
  private Link createLink(String idTraitementDeMasse_p, RelType relType_p)
  {
    StringBuffer sb = new StringBuffer(URL);
    sb.append(idTraitementDeMasse_p);
    if (!RelType.SELF.equals(relType_p))
    {
      sb.append(STATUT);
      sb.append(relType_p.name());
    }

    return new Link(relType_p.toString(), sb.toString());
  }

  /**
   * Creates list of links
   *
   * @param idTraitementDeMasse_p
   *          id
   * @return a list
   */
  private List<Link> createLinks(String idTraitementDeMasse_p)
  {
    List<Link> links = new ArrayList<>();
    links.add(createLink(idTraitementDeMasse_p, RelType.SELF));
    links.add(createLink(idTraitementDeMasse_p, RelType.TERMINE));
    links.add(createLink(idTraitementDeMasse_p, RelType.EN_COURS));
    return links;
  }

  /**
   * Create traitement de masse IHM
   *
   * @param traitementDeMasse_p
   *          {@link TraitementDeMasse}
   * @return {@link TraitementDeMasseIHM}
   */
  private TraitementDeMasseIHM createTraitementDeMasse(TraitementDeMasse traitementDeMasse_p)
  {
    TraitementDeMasseIHM traitementDeMasseIHM = new TraitementDeMasseIHM(traitementDeMasse_p);
    traitementDeMasseIHM.setLinks(createLinks(traitementDeMasse_p.getIdTraitementDeMasse()));
    return traitementDeMasseIHM;
  }

  /**
   * Gets the URL parameters into the ProcessContext
   *
   * @param request_p
   *          request
   */
  private void getUrlparametersIntoProcessContext(Request request_p)
  {
    // get url parameters
    List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();
    _processContext._idTraitementDeMasse = request_p.getUrlDynamicParameters();

    // idAppelant and idFlux are mandatory.
    for (Parameter parametre : urlParametersType)
    {
      if (parametre.getName().equalsIgnoreCase(ParameterUrl.statut.name()))
      {
        _processContext._statut = parametre.getValue();
        continue;
      }

      if (parametre.getName().equalsIgnoreCase(ParameterUrl.statutTraitementUnitaire.name()))
      {
        _processContext._statutTraitementUnitaire = parametre.getValue();
        continue;
      }
    }
  }

  /**
   * Handle GET request
   *
   * @param request_p
   *          http get request
   * @param tracabilite_p
   *          log object
   * @throws RavelException
   *           internal error
   */
  private void handleGetRequest(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = null;
    Pair<Response, Retour> retourBL002 = null;
    try
    {
      getUrlparametersIntoProcessContext(request_p);
      retour = PE0195_BL001_VerifierDonneesSuivi(request_p, tracabilite_p);

      if (isRetourOK(retour))
      {
        _processContext._state = State.PE0195_BL002;
        if (StringTools.isNullOrEmpty(_processContext._idTraitementDeMasse))
        {
          //        BL6402_GetTraitementDeMasseByStatutBuilder
          BL6402_GetTraitementDeMasseByStatut bl6402 = new BL6402_GetTraitementDeMasseByStatutBuilder().tracabilite(tracabilite_p).statut(_processContext._statut).build();
          Pair<Retour, Pair<List<TraitementDeMasse>, Integer>> traitementsDeMasse = bl6402.execute(this);
          if (isRetourOK(bl6402.getRetour()))
          {
            retourBL002 = PE0195_BL002_FormaterReponseSuivi(traitementsDeMasse._second._first, traitementsDeMasse._second._second, traitementsDeMasse._first);
          }
          else
          {
            // SPIRIT 575 - Erreur 400 après la connexion
            if (IMegConsts.DONNEE_INCONNUE.equals(bl6402.getRetour().getDiagnostic()))
            {
              retourBL002 = PE0195_BL002_FormaterReponseSuivi(new ArrayList<>(), 0, RetourFactory.createOkRetour());
            }
            else
            {
              retourBL002 = PE0195_BL002_FormaterReponseSuiviUnitaire(tracabilite_p, null, bl6402.getRetour());
            }
          }

        }
        else
        {
          BL6401_GetTraitementDeMasseById bl6401 = new BL6401_GetTraitementDeMasseByIdBuilder().tracabilite(tracabilite_p).idTraitementDeMasse(_processContext._idTraitementDeMasse).build();
          Pair<Retour, TraitementDeMasse> traitementDeMasse = bl6401.execute(this);
          if (isRetourOK(bl6401.getRetour()))
          {
            retourBL002 = PE0195_BL002_FormaterReponseSuiviUnitaire(tracabilite_p, traitementDeMasse._second, traitementDeMasse._first);
          }
          else
          {
            retourBL002 = PE0195_BL002_FormaterReponseSuiviUnitaire(tracabilite_p, null, bl6401.getRetour());
          }
        }
      }
      else
      {
        retourBL002 = PE0195_BL002_FormaterReponseSuiviUnitaire(tracabilite_p, null, retour);
      }
    }
    catch (Exception exception)
    {
      // Always catch exception in startProcess
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, exception.getMessage());
      retourBL002 = PE0195_BL002_FormaterReponseSuiviUnitaire(tracabilite_p, null, retour);
    }

    request_p.setResponse(retourBL002._first);
    setRetour(retourBL002._second);
    _processContext._state = State.ENDED;
  }

  /**
   * Handle POST request
   *
   * @param request_p
   *          http get request
   * @param tracabilite_p
   *          log object
   * @throws RavelException
   *           internal error
   */
  private void handlePostRequest(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = null;
    try
    {
      _processContext._fichierDeConfiguration = getConfigParameter(FICHIER_DE_CONFIGURATION);
      if (StringTools.isNullOrEmpty(_processContext._fichierDeConfiguration))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_PARAMETER, FICHIER_DE_CONFIGURATION));
      }

      File file = Paths.get(_processContext._fichierDeConfiguration).toFile();
      if (!file.exists())
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.CNCTOR_00020, MessageFormat.format(MESSAGE_MISSING_CONFIGURATION_FILE, _processContext._fichierDeConfiguration));
      }

      getUrlparametersIntoProcessContext(request_p);

      retour = PE0195_BL001_VerifierDonneesCreation(request_p, tracabilite_p);

      if (RetourFactory.isRetourOK(retour))
      {
        _processContext._state = State.PE0195_BL002;
      }
      else
      {
        _processContext._state = State.ENDED;
      }

    }
    catch (Exception exception)
    {
      // Always catch exception in startProcess
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, exception.getMessage());
      _processContext._state = State.ENDED;
    }

    Pair<Response, Retour> retourBL002 = PE0195_BL002_FormaterReponseCreation(retour);
    request_p.setResponse(retourBL002._first);
    setRetour(retourBL002._second);
  }

  /**
   * Checks if retour means no data found
   *
   * @param retour_p
   *          retour
   * @return true or false
   */
  private boolean noTraitementsUnitairesFound(Retour retour_p)
  {
    return StringConstants.NOK.equals(retour_p.getResultat()) && IMegConsts.CAT4.equals(retour_p.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(retour_p.getDiagnostic());
  }

  /**
   * Validates Json object received in the request parameter.
   *
   * @param request_p
   *          {@link Request}
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PE0195_BL001_VerifierDonneesCreation(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    String source = null;
    String process = null;
    String requestId = null;

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        process = header.getValue();
      }
      else if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        source = header.getValue();
      }
      else if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()))
      {
        requestId = header.getValue();
      }
    }

    if (StringTools.isNullOrEmpty(source))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_SOURCE)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_SOURCE));
    }
    if (StringTools.isNullOrEmpty(process))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_PROCESS)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_PROCESS));
    }
    if (StringTools.isNullOrEmpty(requestId))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_REQUEST_ID)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_HEADER_NULL_OR_EMPTY), IHttpHeadersConsts.X_REQUEST_ID));
    }

    PE0195_PostBodyRequest request = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).fromJson(request_p.getPayload(), PE0195_PostBodyRequest.class);

    if (request == null)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), TRAITEMENT_DE_MASSE)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), TRAITEMENT_DE_MASSE));
    }
    if (StringTools.isNullOrEmpty(request.getClientOperateur()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), CLIENT_OPERATEUR)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), CLIENT_OPERATEUR));
    }
    if (StringTools.isNullOrEmpty(request.getTypeTraitementDeMasse()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), TYPE_TRAITEMENT_DE_MASSE)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), TYPE_TRAITEMENT_DE_MASSE));
    }
    if (StringTools.isNullOrEmpty(request.getNomFichier()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), NOM_FICHIER)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString(PE0195_BL001_BODY_FIELD_NULL_OR_EMPTY), NOM_FICHIER));
    }

    BL800_ObtenirSequence bl800 = new BL800_ObtenirSequenceBuilder().tracabilite(tracabilite_p).code(UniqueIdConstant.ID_TRAITEMENT_MASSE).build();
    String idTraitement = bl800.execute(this);

    if (RetourFactory.isRetourKO(bl800.getRetour()))
    {
      return bl800.getRetour();
    }

    _processContext._traitementDeMasse = new TraitementDeMasse(idTraitement, request.getClientOperateur(), request.getTypeTraitementDeMasse(), Statut.INIT.toString());
    _processContext._traitementDeMasse.setNbARealiser(0);
    _processContext._traitementDeMasse.setNbDeclenches(0);
    _processContext._traitementDeMasse.setNbTermines(0);
    _processContext._traitementDeMasse.setNomFichierIn(request.getNomFichier());
    _processContext._traitementDeMasse.setNomFichierOut(FILE_PREFIX + DateTimeFormatPattern.yyyy_dash_MM_dash_dd_underscore_HH_h_mm_m_ss_s.format(DateTimeManager.getInstance().now()) + ".csv"); //$NON-NLS-1$
    _processContext._traitementDeMasse.setDateCreation(DateTimeManager.getInstance().now());
    _processContext._traitementDeMasse.setDateModification(DateTimeManager.getInstance().now());

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, request.getClientOperateur());
    // TODO add traitement de masse map
    //    refFonc.put(IRefFoncConstants.ID_TRA, _processContext._traitementDeMasse.toString());

    BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
    bl1700.execute(this);

    BL6403_CreateTraitementDeMasse bl6403 = new BL6403_CreateTraitementDeMasseBuilder().tracabilite(tracabilite_p).traitementDeMasse(_processContext._traitementDeMasse).build();
    return bl6403.execute(this)._first;
  }

  /**
   * Validates Json object received in the request parameter.
   *
   * @param request_p
   *          {@link Request}
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link Retour}
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PE0195_BL001_VerifierDonneesSuivi(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    return checkHeaders(request_p, tracabilite_p);
  }

  /**
   * PE0195_BL002_FormaterReponseCreation
   *
   * @param retour_p
   *          Object retour
   *
   * @return Response of BL002
   */
  @LogProcessBL
  private Pair<Response, Retour> PE0195_BL002_FormaterReponseCreation(Retour retour_p)
  {
    BasicResponse basicResponse = new BasicResponse(RetourConverter.convertToJsonRetour(retour_p));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    ErrorCode error = ErrorCode.KO_00400;

    if (RetourFactory.isRetourOK(retour_p))
    {
      ResponseHeader responseHeader = new ResponseHeader();
      responseHeader.setName(LOCATION);
      responseHeader.setValue(getConfigParameter(TRAITEMENT_DE_MASSE_PATH) + _processContext._traitementDeMasse.getIdTraitementDeMasse());
      ravelResponse.getResponseHeader().add(responseHeader);
      error = ErrorCode.OK_00200;
    }
    // Return the error retour
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(basicResponse));
    return new Pair<>(new Response(error, ravelResponse), retour_p);
  }

  /**
   * PE0195_BL002_FormaterReponseSuivi
   *
   * @param listTraitementDeMasse_p
   *          List containing the traitements de masse
   * @param nbTraitementMasse_p
   *          The number of traitements de masse with the requested status
   * @param retour_p
   *          Object retour
   *
   * @return Response of BL002
   */
  @LogProcessBL
  private Pair<Response, Retour> PE0195_BL002_FormaterReponseSuivi(List<TraitementDeMasse> listTraitementDeMasse_p, Integer nbTraitementMasse_p, Retour retour_p)
  {
    PE0195_GestionTraitementsDeMasseResponse pe0195_retour = new PE0195_GestionTraitementsDeMasseResponse(RetourConverter.convertToJsonRetour(retour_p));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    if (RetourFactory.isRetourOK(retour_p))
    {
      PE0195_GestionTraitementsDeMasseResponse.ReponseFonctionnelle reponseFonctionnelle = new PE0195_GestionTraitementsDeMasseResponse.ReponseFonctionnelle();
      reponseFonctionnelle.setTraitementsDeMasse(convertList(listTraitementDeMasse_p));
      pe0195_retour.setReponseFonctionnelle(reponseFonctionnelle);

      ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0195_retour));
      if (listTraitementDeMasse_p.size() != nbTraitementMasse_p)
      {
        return new Pair<>(new Response(ErrorCode.OK_00206, ravelResponse), retour_p);
      }
      return new Pair<>(new Response(ErrorCode.OK_00200, ravelResponse), retour_p);
    }
    // Return the error retour
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0195_retour));
    return new Pair<>(new Response(ErrorCode.KO_00400, ravelResponse), retour_p);
  }

  /**
   * PE0195_BL002_FormaterReponseSuivi
   *
   * @param tracabilite_p
   *          tracabilite
   * @param traitementDeMasse_p
   *          the traitement de masse
   * @param retour_p
   *          Object retour
   *
   * @return Response of BL002
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Response, Retour> PE0195_BL002_FormaterReponseSuiviUnitaire(Tracabilite tracabilite_p, TraitementDeMasse traitementDeMasse_p, Retour retour_p) throws RavelException
  {
    PE0195_GestionTraitementsDeMasseUnitaireResponse pe0195_retour = new PE0195_GestionTraitementsDeMasseUnitaireResponse(RetourConverter.convertToJsonRetour(retour_p));
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    if (RetourFactory.isRetourOK(retour_p))
    {
      int maxSize = MAX_BLOCK_SIZE;
      try
      {
        maxSize = Integer.parseInt(getConfigParameter(TAILLE_MAX_BLOC));
      }
      catch (NumberFormatException ex)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
      }

      PE0195_GestionTraitementsDeMasseUnitaireResponse.ReponseFonctionnelle reponseFonctionnelle = new PE0195_GestionTraitementsDeMasseUnitaireResponse.ReponseFonctionnelle();
      reponseFonctionnelle.setTraitementDeMasse(createTraitementDeMasse(traitementDeMasse_p));

      if (TypeTraitement.RECONCILIATION_COMMERCIALE.name().equals(traitementDeMasse_p.getTypeTraitementDeMasse()))
      {
        BL6501_GetReconciliationCommercialeEnMasse bl6501 = new BL6501_GetReconciliationCommercialeEnMasseBuilder().tracabilite(tracabilite_p).idTraitementDeMasse(traitementDeMasse_p.getIdTraitementDeMasse()).statut(_processContext._statutTraitementUnitaire).nbMaxReconciliationCommercialesLues(maxSize).build();
        BL6501_Response reconciliationCommercialeEnMasseLireTous = bl6501.execute(this);
        if (isRetourOK(bl6501.getRetour()) && (reconciliationCommercialeEnMasseLireTous.getListeReconciliationCommerciale() != null))
        {
          reponseFonctionnelle.setListeTraitementsUnitaires(reconciliationCommercialeEnMasseLireTous.getListeReconciliationCommerciale());
          reponseFonctionnelle.setNbTotalTraitementsUnitaires(reconciliationCommercialeEnMasseLireTous.getListeReconciliationCommerciale().size());
        }
        else if (noTraitementsUnitairesFound(bl6501.getRetour()))
        {
          reponseFonctionnelle.setListeTraitementsUnitaires(new ArrayList<ReconciliationCommerciale>());
          reponseFonctionnelle.setNbTotalTraitementsUnitaires(0);
        }
        else
        {
          pe0195_retour = new PE0195_GestionTraitementsDeMasseUnitaireResponse(RetourConverter.convertToJsonRetour(bl6501.getRetour()));
        }
      }
      else
      {
        pe0195_retour = new PE0195_GestionTraitementsDeMasseUnitaireResponse(RetourConverter.convertToJsonRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, MessageFormat.format(Messages.getString("PE0195.BL002.TypeTraitementInconnu"), traitementDeMasse_p.getTypeTraitementDeMasse())))); //$NON-NLS-1$
        reponseFonctionnelle = null;
      }

      pe0195_retour.setReponseFonctionnelle(reponseFonctionnelle);

      ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0195_retour));
      return new Pair<>(new Response(ErrorCode.OK_00200, ravelResponse), retour_p);
    }

    // Return the error retour
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0195_retour));
    return new Pair<>(new Response(ErrorCode.KO_00400, ravelResponse), retour_p);
  }

  /**
   * PE0195_BL100_CreationTraitementMasse
   *
   * @param tracabilite_p
   *          The tracabilite object
   *
   * @param traitementDeMasse_p
   *          object traitement de Masse
   *
   * @return Pair<TraitementDeMasse, Retour>
   * @throws RavelException
   *           Exception thrown if something fails
   */
  @LogProcessBL
  private Pair<TraitementDeMasse, Retour> PE0195_BL100_CreationTraitementMasse(Tracabilite tracabilite_p, TraitementDeMasse traitementDeMasse_p) throws RavelException
  {
    BL1000_ObtenirConfigurationReceptionFichier bl1000 = new BL1000_ObtenirConfigurationReceptionFichierBuilder().codeFlux(IHM_UPLOAD).configurationFile(_processContext._fichierDeConfiguration).tracabilite(tracabilite_p).typeFichier(TRAITEMENT_MASSE).build();
    ConfigurationReception configurationReception = bl1000.execute(this);

    if (!RetourFactory.isRetourOK(bl1000.getRetour()))
    {
      return new Pair<>(null, bl1000.getRetour());
    }

    BL900_ObtenirConfigurationEmissionFichier bl900 = new BL900_ObtenirConfigurationEmissionFichierBuilder().tracabilite(tracabilite_p).codeFlux(EXPLOIT_BSS).configurationFile(_processContext._fichierDeConfiguration).typeFichier(RECONCILIATION_MASSE).build();
    ConfigurationEmission configurationEmission = bl900.execute(this);

    if (!RetourFactory.isRetourOK(bl900.getRetour()))
    {
      return new Pair<>(null, bl900.getRetour());
    }

    BL1200_DeplacerFichier bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierIn()).repertoireSrc(configurationReception.getRepertoireTemp()).repertoireDes(configurationReception.getRepertoireRecu()).build();
    bl1200.execute(this);

    if (!RetourFactory.isRetourOK(bl1200.getRetour()))
    {
      return new Pair<>(null, bl1200.getRetour());
    }

    Path pathIn = Paths.get(configurationReception.getRepertoireRecu(), traitementDeMasse_p.getNomFichierIn());
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(Messages.getString("PE0195.GestionTraitementsDeMasse.OpenFichierIn"), pathIn.toString()))); //$NON-NLS-1$
    try (BufferedReader reader = Files.newBufferedReader(pathIn, Charset.forName("UTF-8"))) //$NON-NLS-1$
    {
      BL1300_CreerFichier bl1300 = new BL1300_CreerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierOut()).repertoire(configurationEmission.getRepertoireTemp()).build();
      bl1300.execute(this);

      if (!RetourFactory.isRetourOK(bl1300.getRetour()))
      {
        reader.close();
        bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierIn()).repertoireSrc(configurationReception.getRepertoireRecu()).repertoireDes(configurationReception.getRepertoireEchec()).build();
        bl1200.execute(this);
        return new Pair<>(null, bl1300.getRetour());
      }

      Path pathOut = Paths.get(configurationEmission.getRepertoireTemp(), traitementDeMasse_p.getNomFichierOut());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(Messages.getString("PE0195.GestionTraitementsDeMasse.OpenFichierOut"), pathOut.toString()))); //$NON-NLS-1$
      try (BufferedWriter writer = Files.newBufferedWriter(pathOut, Charset.forName("UTF-8"))) //$NON-NLS-1$
      {
        Stream<String> linesStream = Files.lines(pathIn);
        Long noLines = linesStream.count();
        Iterator<String> lines = reader.lines().iterator();
        linesStream.close();
        BL6404_UpdateTraitementDeMasse bl6404 = new BL6404_UpdateTraitementDeMasseBuilder().tracabilite(tracabilite_p).idTraitementDeMasse(traitementDeMasse_p.getIdTraitementDeMasse()).nbTraitementsARealiser(noLines.intValue()).build();
        bl6404.execute(this);
        List<String> listeNoCompte = new ArrayList<>();

        int bufferSize = 0;
        int maxSize = MAX_BLOCK_SIZE;
        try
        {
          maxSize = Integer.parseInt(getConfigParameter(TAILLE_MAX_BLOC));
        }
        catch (NumberFormatException ex)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
        }

        while (lines.hasNext())
        {
          String noCompte = lines.next();

          listeNoCompte.add(noCompte);
          bufferSize++;
          if ((bufferSize > maxSize) || (!lines.hasNext()))
          {
            bufferSize = 0;
            BL6502_AjouterReconciliationCommercialeEnMasse bl6502 = new BL6502_AjouterReconciliationCommercialeEnMasseBuilder().tracabilite(tracabilite_p).idTraitementDeMasse(traitementDeMasse_p.getIdTraitementDeMasse()).listNoCompte(listeNoCompte).build();
            List<AssociationPfiReconcialitionCommerciale> retourAjouter = bl6502.execute(this);

            if (!RetourFactory.isRetourOK(bl6502.getRetour()))
            {
              reader.close();
              writer.close();
              bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierIn()).repertoireSrc(configurationReception.getRepertoireRecu()).repertoireDes(configurationReception.getRepertoireEchec()).build();
              bl1200.execute(this);
              bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierOut()).repertoireSrc(configurationEmission.getRepertoireTemp()).repertoireDes(configurationEmission.getRepertoireEchec()).build();
              bl1200.execute(this);
              return new Pair<>(null, bl6502.getRetour());
            }

            listeNoCompte.clear();
            for (AssociationPfiReconcialitionCommerciale association : retourAjouter)
            {
              writer.write(association.getNoCompte() + StringConstants.SEMICOLON_SEPARATOR + association.getIdReconciliationCommerciale() + StringConstants.UNIX_NEW_LINE);
            }
          }
        }
        writer.flush();

        // Send the output file
        BL4300_EnvoyerFichier bl4300 = new BL4300_EnvoyerFichierBuilder().tracabilite(tracabilite_p).chaineConnexion(configurationEmission.getChaineConnexion()).repertoire(configurationEmission.getRepertoireTemp()).nomFichier(traitementDeMasse_p.getNomFichierOut()).build();
        FileTransferResponse response = bl4300.execute(this);

        if (!RetourFactory.isRetourOK(bl4300.getRetour()))
        {
          bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierIn()).repertoireSrc(configurationReception.getRepertoireRecu()).repertoireDes(configurationReception.getRepertoireEchec()).build();
          bl1200.execute(this);
          bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierOut()).repertoireSrc(configurationEmission.getRepertoireTemp()).repertoireDes(configurationEmission.getRepertoireEchec()).build();
          bl1200.execute(this);
          return new Pair<>(null, bl4300.getRetour());
        }

        if (response != null)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(Messages.getString("PE0195.GestionTraitementsDeMasse.FileSent"), response.getFichierTraite()))); //$NON-NLS-1$
        }

        // Store the files
        bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierIn()).repertoireSrc(configurationReception.getRepertoireRecu()).repertoireDes(configurationReception.getRepertoireTraite()).build();
        bl1200.execute(this);
        bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierOut()).repertoireSrc(configurationEmission.getRepertoireTemp()).repertoireDes(configurationEmission.getRepertoireTraite()).build();
        bl1200.execute(this);
      }
      catch (IOException ex)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
        bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierIn()).repertoireSrc(configurationReception.getRepertoireRecu()).repertoireDes(configurationReception.getRepertoireEchec()).build();
        bl1200.execute(this);
        bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierOut()).repertoireSrc(configurationEmission.getRepertoireTemp()).repertoireDes(configurationEmission.getRepertoireEchec()).build();
        bl1200.execute(this);

        throw new RavelException(ExceptionType.DIRECTORY_ERROR, ErrorCode.TECH_00001, ex.getMessage());
      }
      catch (RavelException ex)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
        bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierIn()).repertoireSrc(configurationReception.getRepertoireRecu()).repertoireDes(configurationReception.getRepertoireEchec()).build();
        bl1200.execute(this);
        bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierOut()).repertoireSrc(configurationEmission.getRepertoireTemp()).repertoireDes(configurationEmission.getRepertoireEchec()).build();
        bl1200.execute(this);
        throw ex;
      }
    }
    catch (IOException ex)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
      bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(traitementDeMasse_p.getNomFichierIn()).repertoireSrc(configurationReception.getRepertoireRecu()).repertoireDes(configurationReception.getRepertoireEchec()).build();
      bl1200.execute(this);
      throw new RavelException(ExceptionType.DIRECTORY_ERROR, ErrorCode.TECH_00001, ex.getMessage());
    }

    return new Pair<>(traitementDeMasse_p, RetourFactory.createOkRetour());
  }
}