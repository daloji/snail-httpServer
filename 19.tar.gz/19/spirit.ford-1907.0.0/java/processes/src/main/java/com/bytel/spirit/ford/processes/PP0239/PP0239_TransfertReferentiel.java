/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.processes.PP0239;

import static java.util.Objects.nonNull;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.StringJoiner;

import org.apache.commons.io.FilenameUtils;
import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.ftp.FTPProxy;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.eligprev.config.ConfigRepertoireSource;
import com.bytel.spirit.common.eligprev.config.Pattern;
import com.bytel.spirit.common.eligprev.config.RepertoireSource;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.Messages;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PP0239_TransfertReferentiel extends SpiritProcessSkeleton
{

  /**
   * Holds context data for PP0239_TransfertReferentielContext
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public static final class PP0239_TransfertReferentielContext extends Context
  {
    /**
     * Serial UID
     */
    private static final long serialVersionUID = 8194119576880787082L;
    /**
     * ConfigRepertoireSource
     */
    private ConfigRepertoireSource _configRepertoireSource;

    /**
     * Contains the process retour.
     */
    private Retour _processRetour;

    /**
     * ReponseErreur from BL002
     */
    private ReponseErreur _reponseErreur;

    /**
     * The source identifier
     */
    private String _source;

    /**
     * Repertoire Source
     */
    private RepertoireSource _repertoireSource;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PP0239_START;

    /**
     * @return the configRepertoireSource
     */
    public final ConfigRepertoireSource getConfigRepertoireSource()
    {
      return _configRepertoireSource;
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the repertoireSource
     */
    public RepertoireSource getRepertoireSource()
    {
      return _repertoireSource;
    }

    /**
     * @return the reponseErreur
     */
    public ReponseErreur getReponseErreur()
    {
      return _reponseErreur;
    }

    /**
     * @return value of source
     */
    public String getSource()
    {
      return _source;
    }

    /**
     * @return value of state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param configRepertoireSource_p
     *          the configRepertoireSource to set
     */
    public final void setConfigRepertoireSource(ConfigRepertoireSource configRepertoireSource_p)
    {
      _configRepertoireSource = configRepertoireSource_p;
    }

    /**
     * @param processRetour_p
     *          The _processRetour to set.
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param repertoireSource_p
     *          the repertoireSource to set
     */
    public void setRepertoireSource(RepertoireSource repertoireSource_p)
    {
      _repertoireSource = repertoireSource_p;
    }

    /**
     * @param reponseErreur_p
     *          the reponseErreur to set
     */
    public void setReponseErreur(ReponseErreur reponseErreur_p)
    {
      _reponseErreur = reponseErreur_p;
    }

    /**
     * @param source_p
     *          The source to set.
     */
    public void setSource(String source_p)
    {
      _source = source_p;
    }

    /**
     * @param state_p
     *          The state to set.
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }
  }

  /**
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * Step to call START
     */
    PP0239_START(MandatoryProcessState.PRC_START),

    /**
     * Step to call BL001
     */
    PP0239_BL001(MandatoryProcessState.PRC_RUNNING),

    /**
     * Step to call BL100
     */
    PP0239_BL100(MandatoryProcessState.PRC_RUNNING),

    /**
     * Step to call BL002
     */
    PP0239_BL002(MandatoryProcessState.PRC_RUNNING),

    /**
     * Step to call END
     */
    PP0239_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * Serial UID
   */
  private static final long serialVersionUID = 6002064010013655752L;

  /**
   * ConfigRepertoireSource Param
   */
  private static final String PARAM_FILE_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * The constant for PP0239.NoParam message
   */
  private static final String MESSAGE_NO_PARAMETER = Messages.getString("PP0239.NoParam"); //$NON-NLS-1$

  /**
   * The constant for PP0239.FileError message
   */
  private static final String MESSAGE_FILE_ERROR = Messages.getString("PP0239.FileError"); //$NON-NLS-1$

  /**
   * The constant for PP0239.UnexpectedContinueProcessReceived message
   */
  private static final String MESSAGE_UNEXPECTED_CONTINUE_PROCESS_RECEIVED = Messages.getString("PP0239.UnexpectedContinueProcessReceived"); //$NON-NLS-1$

  /**
   * The constant for PP0239.ConfigurationInvalide message
   */
  private static final String MESSAGE_CONFIGURATION_INVALIDE = Messages.getString("PP0239.ConfigurationInvalide"); //$NON-NLS-1$

  /**
   * The constant for PP0239.RecuperationFichierImpossible message
   */
  private static final String MESSAGE_RECUPERATION_FICHIER_IMPOSSIBLE = Messages.getString("PP0239.RecuperationFichierImpossible"); //$NON-NLS-1$

  /**
   * The constant for PP0239.RecuperationListeFichiersImpossible message
   */
  private static final String MESSAGE_RECUPERATION_LISTE_FICHIERS_IMPOSSIBLE = Messages.getString("PP0239.RecuperationListeFichiersImpossible"); //$NON-NLS-1$

  /**
   * .TMP pattern
   */
  private static final String TMP_PATTERN = "TMP"; //$NON-NLS-1$

  /**
   * The constant for PP0239.PasDeTmpFilesExistant message
   */
  private static final String MESSAGE_NO_TMP_FILES_EXISTENT = Messages.getString("PP0239.PasDeTmpFilesExistant"); //$NON-NLS-1$

  /**
   * The constant for PP0239.SeulementTmpFilesExistant message
   */
  private static final String MESSAGE_ONLY_TMP_FILES_EXISTENT = Messages.getString("PP0239.SeulementTmpFilesExistant"); //$NON-NLS-1$

  /**
   * The constant for PP0239.TmpEtAutresFilesExistant message
   */
  private static final String MESSAGE_BOTH_TMP_AND_OTHER_FILES_EXISTENT = Messages.getString("PP0239.TmpEtAutresFilesExistant"); //$NON-NLS-1$

  /**
   * The source parameter constant
   */
  private static final String SOURCE = "SOURCE"; //$NON-NLS-1$

  /**
   * Process context instance
   */
  private PP0239_TransfertReferentielContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    if (retour_p != null)
    {
      return MarshallTools.marshall(retour_p);
    }
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PP0239_TransfertReferentielContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, MESSAGE_UNEXPECTED_CONTINUE_PROCESS_RECEIVED);
  }

  @Override
  protected void exitKOMetroLog(String s_p)
  {
    // Not required for now in Ravel
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    // Load process parameters
    loadProcessParameters();

    try
    {
      // Get Request parameter
      getUrlparametersIntoProcessContext(request_p);

      // Call BL001 VerifierDonnees
      _processContext.setState(State.PP0239_BL001);
      Retour retourBL001 = PP0239_BL001_VerifierDonnees(tracabilite_p, _processContext.getSource());
      _processContext.setProcessRetour(retourBL001);

      if (RetourFactory.isRetourOK(retourBL001))
      {
        // Call BL100 TransfererFichier
        _processContext.setState(State.PP0239_BL100);
        Retour retourBL100 = PP0239_BL100_TransfererFichier(tracabilite_p, _processContext.getSource());
        _processContext.setProcessRetour(retourBL100);
      }
      // Call BL002 FormaterReponse
      _processContext.setState(State.PP0239_BL002);
      Pair<ReponseErreur, Retour> retourBL002 = PP0239_BL002_FormaterReponse(tracabilite_p, _processContext.getProcessRetour());
      _processContext.setProcessRetour(retourBL002._second);
      _processContext.setReponseErreur(retourBL002._first);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()));
    }
    finally
    {
      endSynchronousProcess(request_p, _processContext.getProcessRetour());
    }

    // Set Process retour
    setRetour(_processContext.getProcessRetour());

    // Set process end state
    _processContext.setState(State.PP0239_END);
  }

  /**
   * Auxiliary method to download one file from the source to the destination repository.
   *
   * @param config_p
   *          The repertoire source.
   * @param destinationPath_p
   *          The destination path.
   * @param fileName_p
   *          The file to be downloaded.
   * @return The connector response.
   */
  private Retour downloadFile(RepertoireSource config_p, String destinationPath_p, String fileName_p)
  {
    ConnectorResponse<String, Retour> fileResponse = null;
    try
    {
      fileResponse = FTPProxy.getInstance().downloadFile(config_p.getNomConnecteur(), getTracabilite().getIdCorrelationSpirit(), config_p.getCheminSource(), fileName_p, destinationPath_p);
      return fileResponse._second;
    }
    catch (RavelException e_p)
    {
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MessageFormat.format(MESSAGE_RECUPERATION_FICHIER_IMPOSSIBLE, config_p.getSource()));
    }
  }

  /**
   * Method to end synchronous process
   *
   * @param request_p
   *          Request parameter
   * @param retour_p
   *          Retour parameter
   *
   * @throws RavelException
   *           RavelException
   */
  private void endSynchronousProcess(Request request_p, Retour retour_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ravelResponse.setResult(createDefaultFunctionalResponse(retour_p));

      Response response = new Response(isRetourOK(retour_p) ? ErrorCode.OK_00000 : ErrorCode.PRCESS_00002, ravelResponse);
      request_p.setResponse(response);
    }
  }

  /**
   * Auxiliary method to get the repertoire source that matches the source passed as an input to the process.
   *
   * @param repertoiresSourceList_p
   *          repertoire source
   * @param source_p
   *          The source repository
   * @return The correspondent repertoire source.
   */
  private RepertoireSource getCorrespondantRepertoireSource(List<RepertoireSource> repertoiresSourceList_p, String source_p)
  {
    for (RepertoireSource repertoireSource : repertoiresSourceList_p)
    {
      if (repertoireSource.getSource().equals(source_p))
      {
        return repertoireSource;
      }
    }
    return null;
  }

  /**
   * Auxiliary method to get the file list of the source repository.
   *
   * @param config_p
   *          The repertoire source.
   * @return The connector response.
   */
  private ConnectorResponse<List<String>, Retour> getFileList(RepertoireSource config_p)
  {
    try
    {
      return FTPProxy.getInstance().getFileNameList(config_p.getNomConnecteur(), getTracabilite().getIdCorrelationSpirit(), config_p.getCheminSource(), new ArrayList<>());
    }
    catch (Exception e_p)
    {
      return new ConnectorResponse<>(Collections.emptyList(), RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_RECUPERATION_LISTE_FICHIERS_IMPOSSIBLE));
    }
  }

  /**
   * This small method extracts the file name from the pattern. The pattern should follow
   * COUVERTURE_FTTO_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv // COUVERTURE_CUIVRE_ECOSPIRIT_[YYYYMMDD]_[INDEX].csv
   *
   * @param fileName_p
   *          fileName
   * @return name
   */
  private String getPattern(final String fileName_p)
  {
    int index = fileName_p.lastIndexOf("."); //$NON-NLS-1$
    if (index <= 0)
    {
      return null;
    }

    final String[] values = fileName_p.substring(0, index).split("_"); //$NON-NLS-1$
    if (values.length <= 2)
    {
      return null;
    }

    final StringJoiner joiner = new StringJoiner("_"); //$NON-NLS-1$
    for (int i = 0; i < (values.length - 2); i++)
    {
      joiner.add(values[i]);
    }

    return joiner.length() == 0 ? null : joiner.toString();
  }

  /**
   * Gets the URL parameters into the ProcessContext
   *
   * @param request_p
   *          request
   */
  private void getUrlparametersIntoProcessContext(Request request_p)
  {
    // get url parameters
    List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();
    for (Parameter parameter : urlParametersType)
    {
      // Check for the source identifier
      if (SOURCE.equalsIgnoreCase(parameter.getName()))
      {
        _processContext.setSource(parameter.getValue());
      }
    }
  }

  /**
   * Checks if any entry parameter is missing and loads them.
   *
   * @throws RavelException
   *           on error
   */
  private void loadProcessParameters() throws RavelException
  {
    // Get the config parameter
    String configRepertoireSourceParam = getConfigParameter(PARAM_FILE_PATH);

    if (!StringTools.isNullOrEmpty(configRepertoireSourceParam))
    {
      try
      {
        Path configRepertoireSourcePath = Paths.get(configRepertoireSourceParam);
        String configRepertoireSourceFile = new String(Files.readAllBytes(configRepertoireSourcePath));

        _processContext.setConfigRepertoireSource(MarshallTools.unmarshall(ConfigRepertoireSource.class, configRepertoireSourceFile));
      }
      catch (Exception exception)
      {
        String errorString = MessageFormat.format(MESSAGE_FILE_ERROR, configRepertoireSourceParam);
        throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, errorString, errorString);
      }
    }
    else
    {
      String errorString = MessageFormat.format(MESSAGE_NO_PARAMETER, PARAM_FILE_PATH);
      throw new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, errorString, errorString);
    }
  }

  /**
   * @param tracabilite_p
   *          The tracability
   * @param source_p
   *          The source repository
   * @return The retour
   */
  @LogProcessBL
  private Retour PP0239_BL001_VerifierDonnees(@SuppressWarnings("unused") Tracabilite tracabilite_p, String source_p)
  {
    //Verify that the configuration file corresponds to the objects description
    List<RepertoireSource> repertoiresSourceList = _processContext.getConfigRepertoireSource().getRepertoireSource();
    RepertoireSource repertoireSource = getCorrespondantRepertoireSource(repertoiresSourceList, source_p);
    if ((repertoireSource == null) || !verifyIfRepertoiresSourceAreValid(repertoireSource, source_p))
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MESSAGE_CONFIGURATION_INVALIDE);
    }
    _processContext.setRepertoireSource(repertoireSource);
    return RetourFactory.createOkRetour();
  }

  /**
   * Format response to the client
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param inRetour
   *          Retour to be formatted
   * @return {@link ReponseErreur}
   */
  @LogProcessBL
  private Pair<ReponseErreur, Retour> PP0239_BL002_FormaterReponse(@SuppressWarnings("unused") Tracabilite tracabilite_p, Retour inRetour)
  {
    if (!RetourFactory.isRetourOK(inRetour))
    {
      ReponseErreur responseErreur = new ReponseErreur();
      responseErreur.setError(inRetour.getDiagnostic());
      responseErreur.setErrorDescription(inRetour.getLibelle());

      return new Pair<>(responseErreur, inRetour);
    }

    return new Pair<>(null, RetourFactory.createOkRetour());
  }

  /**
   * This activity allows to retrieve the files from their source repository to the local workspace repositories.
   *
   * @param tracabilite_p
   *          The tracability
   * @param source_p
   *          The source repository
   *
   * @return The retour
   * @throws RavelException
   *           In case something goes wrong.
   */
  @LogProcessBL
  private Retour PP0239_BL100_TransfererFichier(Tracabilite tracabilite_p, String source_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    RepertoireSource repertoireSource = _processContext.getRepertoireSource();

    // get patterns
    List<Pattern> listPatterns = repertoireSource.getPattern();

    // Flags to be used later while processing the files that don't correspond to any pattern
    boolean filesExist;
    boolean tmpFilesExist;
    boolean otherFilesExist;

    // Reset the flags to false for each repertoire source
    filesExist = false;
    tmpFilesExist = false;
    otherFilesExist = false;

    // Retrieve list of file names on given path
    ConnectorResponse<List<String>, Retour> getFileListResponse = getFileList(repertoireSource);
    retour = getFileListResponse._second;

    if (RetourFactory.isRetourNOK(retour))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, retour.getLibelle()));
      return retour;
    }

    List<String> fileList = getFileListResponse._first;
    if (fileList == null)
    {
      // no files in the directory
      return RetourFactory.createOkRetour();
    }

    // Iterate file names
    Iterator<String> fileListIterator = fileList.iterator();
    while (fileListIterator.hasNext())
    {
      String fileName = fileListIterator.next();
      String fileExtension = FilenameUtils.getExtension(fileName);

      // Check if the file is supposed to be downloaded, by its pattern. If it is, retrieve the correspondent pattern information
      Pattern patternRetrieved = retrieveCorrespondantPattern(fileName, listPatterns);

      // If the pattern is supposed to be downloaded, download the file to the destination repository and remove it from the source repository
      if (nonNull(patternRetrieved))
      {
        filesExist = true;

        // Download file to the destination path
        retour = downloadFile(repertoireSource, patternRetrieved.getCheminDest(), fileName);

        // Remove file from source repository
        if (RetourFactory.isRetourOK(retour))
        {
          FTPProxy.getInstance().removeFile(repertoireSource.getNomConnecteur(), getTracabilite().getIdCorrelationSpirit(), repertoireSource.getCheminSource() + "/" + fileName); //$NON-NLS-1$
        }
      }
      // If there is no correspondent pattern retrieved it means that the file should be downloaded to a failure path instead, but only if it is not a .tmp file,
      else
      {
        // We check if the file has a .tmp pattern or not. If the file doesn't have a .tmp pattern we should download it to a failure path. If it is a .tmp file, we do nothing.
        if (fileExtension.equalsIgnoreCase(TMP_PATTERN))
        {
          tmpFilesExist = true;
        }
        else
        {
          otherFilesExist = true;

          // Download file to a well defined failure path
          retour = downloadFile(repertoireSource, repertoireSource.getCheminEchec(), fileName);

          // Remove file from source repository
          if (RetourFactory.isRetourOK(retour))
          {
            FTPProxy.getInstance().removeFile(repertoireSource.getNomConnecteur(), getTracabilite().getIdCorrelationSpirit(), repertoireSource.getCheminSource() + "/" + fileName); //$NON-NLS-1$
          }
        }
      }
    }

    // Finally, we map the correct retour accordingly with the files that were in the source repository

    // If there are no .tmp files at all in the source repository and only other files were left there
    if (!tmpFilesExist && otherFilesExist)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.TRAITEMENT_PARTIEL, MessageFormat.format(MESSAGE_NO_TMP_FILES_EXISTENT, repertoireSource.getSource()));
    }
    // If there are only .tmp files left in the source repository
    else if (!otherFilesExist && tmpFilesExist)
    {
      if (filesExist)
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.TRAITEMENT_PARTIEL, MessageFormat.format(MESSAGE_BOTH_TMP_AND_OTHER_FILES_EXISTENT, repertoireSource.getSource()));
      }
      else
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.TRAITEMENT_PARTIEL, MessageFormat.format(MESSAGE_ONLY_TMP_FILES_EXISTENT, repertoireSource.getSource()));
      }
    }
    // If there are both .tmp and other files left in the repository
    else if (otherFilesExist)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.TRAITEMENT_PARTIEL, MessageFormat.format(MESSAGE_BOTH_TMP_AND_OTHER_FILES_EXISTENT, repertoireSource.getSource()));
    }

    // Log if there is an error
    if (RetourFactory.isRetourNOK(retour))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, retour.getLibelle()));
    }

    return retour;
  }

  /**
   * Auxiliary method to retrieve the correspondent pattern that matches the pattern passed as an input.
   *
   * @param filePattern_p
   *          The file pattern to be checked.
   * @param patterns_p
   *          The patterns list.
   * @return The correspondent pattern.
   */
  private Pattern retrieveCorrespondantPattern(String filePattern_p, List<Pattern> patterns_p)
  {
    for (Pattern pattern : patterns_p)
    {
      final String prefix = getPattern(filePattern_p);
      final String expected = FilenameUtils.getExtension(pattern.getPattern());
      final String actual = FilenameUtils.getExtension(filePattern_p);
      if (nonNull(prefix) && expected.equals(actual) && pattern.getPattern().contains(prefix))
      {
        return pattern;
      }
    }

    return null;
  }

  /**
   * Auxiliary method to verify if the pattern objects are valid.
   *
   * @param patterns_p
   *          The patterns list.
   * @return The flag that indicates if the pattern objects are valid or not.
   */
  private Boolean verifyIfPatternsAreValid(List<Pattern> patterns_p)
  {
    if (CollectionUtils.isEmpty(patterns_p))
    {
      return false;
    }
    for (Pattern pattern : patterns_p)
    {
      if (StringTools.isNullOrEmpty(pattern.getPattern()) || StringTools.isNullOrEmpty(pattern.getCheminDest()))
      {
        return false;
      }
    }
    return true;
  }

  /**
   * Auxiliary method to verify if the repertoire source object is valid.
   *
   * @param repertoireSource_p
   *          The repertoire source.
   * @param source_p
   *          The source repository identifier passed as input in the process.
   * @return The flag that indicates if the repertoire source is valid or not.
   */
  private Boolean verifyIfRepertoiresSourceAreValid(RepertoireSource repertoireSource_p, String source_p)
  {
    return !(StringTools.isNullOrEmpty(repertoireSource_p.getSource()) || StringTools.isNullOrEmpty(repertoireSource_p.getCheminSource()) || StringTools.isNullOrEmpty(repertoireSource_p.getNomConnecteur()) || StringTools.isNullOrEmpty(repertoireSource_p.getCheminEchec()) || !verifyIfPatternsAreValid(repertoireSource_p.getPattern()));
  }
}