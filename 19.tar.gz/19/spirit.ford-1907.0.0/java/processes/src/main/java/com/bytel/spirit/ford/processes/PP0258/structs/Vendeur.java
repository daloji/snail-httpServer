/*******************************************************************************
* $Id: Vendeur.java 16444 2019-01-31 11:08:50Z sdiop $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0258.structs;

/**
 *
 * @author sdiop
 * @version ($Revision: 16444 $ $Date: 2019-01-31 12:08:50 +0100 (Thu, 31 Jan 2019) $)
 */
public enum Vendeur
{

  /**
   * Giesecke+Devrient
   */
  GIESECKE_DEVRIENT("Giesecke+Devrient", "G+D"), //$NON-NLS-1$ //$NON-NLS-2$

  /**
   * Gemalto
   */
  GEMALTO("Gemalto", "GTO"), //$NON-NLS-1$ //$NON-NLS-2$

  /**
   * Morpho
   */
  MORPHO("Morpho", "MPO"), //$NON-NLS-1$  //$NON-NLS-2$

  /**
   * Oberthur
   */
  OBERTHUR("Oberthur", "OBT"), //$NON-NLS-1$ //$NON-NLS-2$

  /**
   * IDEMIA
   */
  IDEMIA("IDEMIA", "OBT"); //$NON-NLS-1$ //$NON-NLS-2$


  /**
   *
   */
  private final String _vendeur;

  /**
   *
   */
  private final String _value;

  /**
   * The constructor.
   *
   * @param vendeur_p
   *          the vendeur
   * @param value_p
   *          the value
   */
  private Vendeur(String vendeur_p, String value_p)
  {
    _vendeur = vendeur_p;
    _value = value_p;
  }

  /**
   * @return value
   */
  public String value()
  {
    return _value;
  }

  /**
   * @return value
   */
  public String vendeur()
  {
    return _vendeur;
  }


  public static String getValueByVendeur(String vendeur_p)
  {
    for (Vendeur vendeur : Vendeur.values())
    {
      if (vendeur.vendeur().equals(vendeur_p))
      {
        return vendeur.value();
      }
    }
    return vendeur_p;
  }

}
