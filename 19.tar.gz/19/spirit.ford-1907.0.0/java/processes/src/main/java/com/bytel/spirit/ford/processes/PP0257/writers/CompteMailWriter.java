/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0257.writers;

import static java.util.Objects.nonNull;

import java.io.Closeable;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.csv.CSVPrinter;
import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;
import com.bytel.spirit.ford.shared.misc.processes.writers.IGenericWriter;

/**
 *
 * @author fmonteir
 * @version ($Revision$ $Date$)
 */
public class CompteMailWriter implements IGenericWriter<Ressource>, Closeable
{
  /**
   * Class containing the CompteMail entete to write in CSV File.
   *
   * @author fmonteir
   * @version ($Revision$ $Date$)
   */
  public enum CompteMailHeader
  {
    /**
     *
     */
    ID_COMPTE_MAIL(0),
    /**
     *
     */
    STATUT(1),
    /**
     *
     */
    ID_ST_LAC(2),
    /**
     *
     */
    DATE_CREATION(3),
    /**
     *
     */
    DATE_MODIFICATION(4);
    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    CompteMailHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * CSV values separator
   */
  public static final char CSV_SEPARATOR = ';';

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;

  /**
   * Number of maximum lines to write without performing a flush on the CSV file.
   */
  private int _linesToFlush;

  /**
   * The path of CSV file.
   */
  private String _filePath;

  /**
   * The name of CSV file.
   */
  private String _fileName;

  /**
   * Number of lines dumped in the CSV file.
   */
  private int _currentDumpedLines = 0;

  /**
   * retour
   */
  private Retour _retour;

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public CompteMailWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    _filePath = filePath_p;
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    _retour = RetourFactory.createOkRetour();

    createFile(filePath_p + fileName_p, CompteMailHeader.class);
  }

  @Override
  public void close() throws IOException
  {
    _csvPrinter.flush();
    _csvPrinter.close();
  }

  @Override
  public void dump(Tracabilite tracabilite_p, Ressource ressource_p)
  {
    List<String> record = this.getRecord(ressource_p);
    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  public String getFileName()
  {
    return _fileName;
  }

  @Override
  public String getFilePath()
  {
    return _filePath;
  }

  /**
   * @return retour OK/NOK
   */
  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  @Override
  public void setCSVPrinter(CSVPrinter csvPrinter_p)
  {
    this._csvPrinter = csvPrinter_p;

  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param ressourceCompteMail_p
   *
   *          The ressource of CompteMail type
   *
   * @return List of values
   */
  private List<String> getRecord(Ressource ressourceCompteMail_p)
  {

    List<String> record = new ArrayList<>(Arrays.asList(new String[CompteMailHeader.values().length]));
    if (nonNull(ressourceCompteMail_p))
    {
      record.set(CompteMailHeader.ID_COMPTE_MAIL.getIndex(), ressourceCompteMail_p.getIdRessource());
      record.set(CompteMailHeader.STATUT.getIndex(), ressourceCompteMail_p.getStatut());
      record.set(CompteMailHeader.ID_ST_LAC.getIndex(), ressourceCompteMail_p.getIdSt());
      record.set(CompteMailHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(ressourceCompteMail_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
      record.set(CompteMailHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(ressourceCompteMail_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
      return record;
    }
    return Collections.emptyList();
  }

  /**
   * Write in the CSV file the list of records. Each record corresponds to a line.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param record_p
   *          The list of records.
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> record_p)
  {
    try
    {
      _csvPrinter.printRecord(record_p);
      //check if a flush is needed
      if ((++_currentDumpedLines % this._linesToFlush) == 0)
      {
        _csvPrinter.flush();
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("Common.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("Common.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }

}
