/*******************************************************************************
* $Id: LienSaPaTvWriter.java 19207 2019-03-28 13:17:54Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static java.util.Objects.nonNull;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.AccesTechnique;
import com.bytel.spirit.common.shared.saab.rpg.AdresseInstallation;
import com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssGp;
import com.bytel.spirit.common.shared.saab.rpg.LienSAPA;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0098.structs.Consts;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author pcarreir
 * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
 */
public class LienSaPaTvWriter implements INSFWriter
{
  /**
   *
   * @author pcarreir
   * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
   */
  public enum LienSaPaTVHeader
  {
    /**
     * CLIENT_OPERATEUR
     */
    CLIENT_OPERATEUR(0),
    /**
     * NO_COMPTE
     */
    NO_COMPTE(1),
    /**
     * NO_SA
     */
    NO_SA(2),
    /**
     * ID_PA
     */
    ID_PA(3),
    /**
     * STATUT
     */
    STATUT(4),
    /**
     * NO_SC
     */
    NO_SC(5),
    /**
     * NOM_SC
     */
    NOM_SC(6),
    /**
     * TYPE_PA
     */
    TYPE_PA(7),
    /**
     * COMPTE_TV
     */
    COMPTE_TV(8),
    /**
     * ID_PA_LIE
     */
    ID_PA_LIE(9),
    /**
     * TECHNO_RACCO
     */
    TECHNO_RACCO(10),
    /**
     * ID_OPE_COLLECTE
     */
    ID_OPE_COLLECTE(11),
    /**
     * ADR_CODE_INSEE
     */
    ADR_CODE_INSEE(12),
    /**
     * DATE_CREATION
     */
    DATE_CREATION(13),
    /**
     * DATE_MODIFICATION
     */
    DATE_MODIFICATION(14);

    /**
     * The position in CSV
     */
    private int _position;

    /**
     * Default constructor
     *
     * @param position
     *          The position
     */
    LienSaPaTVHeader(int position)
    {
      _position = position;
    }

    /**
     * @return the position
     */
    public int getPosition()
    {
      return _position;
    }
  }

  /**
   * The Writer
   */
  private BufferedWriter _writer;

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;

  /**
   * lines in buffer
   */
  private Integer _lineCount;

  /**
   * Max lines allowed in buffer before flush happens
   */
  private Integer _maxLines;

  /**
   * Writer retour
   */
  private Retour _retour;

  /**
   * File Name
   */
  private String _fileName;

  /**
   * @param filename_p
   *          The csv output file
   * @param maxLines_p
   *          The max number of lines in buffer
   * @throws IOException
   *           IOException
   */
  public LienSaPaTvWriter(String filename_p, Integer maxLines_p) throws IOException
  {
    _lineCount = 0;
    _maxLines = maxLines_p;
    _fileName = filename_p;
    _retour = RetourFactory.createOkRetour();
    _writer = Files.newBufferedWriter(Paths.get(filename_p));
    _csvPrinter = new CSVPrinter(_writer, CSVFormat.newFormat(';').withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(LienSaPaTVHeader.class));

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
    _writer.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> records = getRecords(pfi_p, dateDemande_p);
    for (List<String> list : records)
    {
      write(tracabilite_p, list);
    }
  }

  /**
   * Method used to convert pfi attributes to a String list
   *
   * @param pfi_p
   *          The pfi to process
   * @return List<List<String>>
   */
  public List<List<String>> getRecords(PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> records = new ArrayList<>();
    if (nonNull(pfi_p.getPa()))
    {
      List<PA> paFilter = pfi_p.getPa().stream().filter(p -> Consts.TV.equals(p.getTypePA())).collect(Collectors.toList());
      if (nonNull(paFilter))
      {
        for (PA pa : paFilter)
        {
          //Find LienEqptPa
          if (nonNull(pfi_p.getLienSAPA()))
          {
            List<LienSAPA> lienSaPaList = pfi_p.getLienSAPA().stream().filter(paArg -> pa.getIdentifiantFonctionnelPA().equals(paArg.getIdentifiantFonctionnelPA())).collect(Collectors.toList());
            if (nonNull(lienSaPaList) && nonNull(pfi_p.getPa()))
            {
              for (LienSAPA lienSaPa : lienSaPaList)
              {
                if (nonNull(lienSaPa) //
                    && "BSS_GP".equals(pfi_p.getClientOperateur()) //$NON-NLS-1$
                    && dateDemande_p.isEqual(lienSaPa.getDateModification().toLocalDate()))
                {
                  List<String> csvLine = new ArrayList<>(Arrays.asList(new String[LienSaPaTVHeader.values().length]));
                  csvLine.set(LienSaPaTVHeader.CLIENT_OPERATEUR.getPosition(), pfi_p.getClientOperateur());
                  csvLine.set(LienSaPaTVHeader.NO_COMPTE.getPosition(), pfi_p.getNoCompte());
                  csvLine.set(LienSaPaTVHeader.NO_SA.getPosition(), lienSaPa.getNoServiceAccessible());
                  csvLine.set(LienSaPaTVHeader.ID_PA.getPosition(), lienSaPa.getIdentifiantFonctionnelPA());
                  csvLine.set(LienSaPaTVHeader.STATUT.getPosition(), CSVWriterUtils.getCsvValue(lienSaPa.getStatut()));
                  SA saFound = pfi_p.getSa().stream().filter(sa -> lienSaPa.getNoServiceAccessible().equals(sa.getNoServiceAccessible())).findFirst().orElse(null);
                  if (nonNull(saFound))
                  {
                    csvLine.set(LienSaPaTVHeader.NO_SC.getPosition(), saFound.getNoServiceCommercial());
                    csvLine.set(LienSaPaTVHeader.NOM_SC.getPosition(), saFound.getNomServiceCommercial());
                  }
                  csvLine.set(LienSaPaTVHeader.TYPE_PA.getPosition(), pa.getTypePA());
                  csvLine.set(LienSaPaTVHeader.COMPTE_TV.getPosition(), pa.getPaTypeTv().getIdCompteTv());
                  csvLine.set(LienSaPaTVHeader.ID_PA_LIE.getPosition(), pa.getIdentifiantFonctionnelPALie());

                  PA paFoundLigneFixe = pfi_p.getPa().stream().filter(paToFind -> StringTools.isNotNullOrEmpty(pa.getIdentifiantFonctionnelPALie()) && pa.getIdentifiantFonctionnelPALie().equals(paToFind.getIdentifiantFonctionnelPA())).findFirst().orElse(null);
                  if (nonNull(paFoundLigneFixe) && nonNull(paFoundLigneFixe.getPaTypeLigneFixe()))
                  {
                    InfoBrutBssGp infoBBss = paFoundLigneFixe.getPaTypeLigneFixe().getInfoBrutBssGp();
                    if (nonNull(infoBBss))
                    {
                      AccesTechnique accesTechnique = infoBBss.getAccesTechnique();
                      if (nonNull(accesTechnique))
                      {
                        csvLine.set(LienSaPaTVHeader.TECHNO_RACCO.getPosition(), infoBBss.getAccesTechnique().getTechnologieAcces());
                        csvLine.set(LienSaPaTVHeader.ID_OPE_COLLECTE.getPosition(), infoBBss.getAccesTechnique().getIdOperateurCollecte());
                      }
                      AdresseInstallation adresseInstallation = infoBBss.getAdresseInstallation();
                      if (nonNull(adresseInstallation))
                      {
                        csvLine.set(LienSaPaTVHeader.ADR_CODE_INSEE.getPosition(), adresseInstallation.getCodeInsee());
                      }
                    }
                  }

                  csvLine.set(LienSaPaTVHeader.DATE_CREATION.getPosition(), CSVWriterUtils.getCsvValue(lienSaPa.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
                  csvLine.set(LienSaPaTVHeader.DATE_MODIFICATION.getPosition(), CSVWriterUtils.getCsvValue(lienSaPa.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
                  records.add(csvLine);
                }
              }
            }
          }
        }
      }
    }
    return records;
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Add lines to buffer or write them on file if buffer size is greater then max permited
   *
   * @param tracabilite_p
   *          The Tracabilite
   * @param line_p
   *          the line to write
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> line_p)
  {
    try
    {
      _csvPrinter.printRecord(line_p);
      _lineCount++;
      if (_lineCount >= _maxLines)
      {
        _csvPrinter.flush();
        _lineCount = 0;
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }
}
