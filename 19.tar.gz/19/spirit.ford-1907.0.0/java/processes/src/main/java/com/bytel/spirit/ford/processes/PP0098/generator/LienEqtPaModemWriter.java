/*******************************************************************************
* $Id: LienEqtPaModemWriter.java 19207 2019-03-28 13:17:54Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static java.util.Objects.nonNull;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0098.structs.Consts;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author pcarreir
 * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
 */
public class LienEqtPaModemWriter implements INSFWriter
{

  /**
   *
   * @author pcarreir
   * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
   */
  public enum LienEqtPaModemHeader
  {
    /**
     * CLIENT_OPERATEUR
     */
    CLIENT_OPERATEUR(0),
    /**
     * NO_COMPTE
     */
    NO_COMPTE(1),
    /**
     * NO_EQUIPEMENT
     */
    NO_EQUIPEMENT(2),
    /**
     * ID_PA
     */
    ID_PA(3),
    /**
     * STATUT
     */
    STATUT(4),
    /**
     * SERIAL_NUMBER
     */
    SERIAL_NUMBER(5),
    /**
     * TYPE
     */
    TYPE(6),
    /**
     * MODELE
     */
    MODELE(7),
    /**
     * ADR_MAC_MODEM
     */
    ADR_MAC_MODEM(8),
    /**
     * ADR_MAC_MTA
     */
    ADR_MAC_MTA(9),
    /**
     * ADR_MAC_GATEWAY
     */
    ADR_MAC_GATEWAY(10),
    /**
     * CODE_EAN
     */
    CODE_EAN(11),
    /**
     * NOM_FABRICANT
     */
    NOM_FABRICANT(12),
    /**
     * TECHNO_RACCO
     */
    TECHNO_RACCO(13),
    /**
     * ADR_CODE_INSEE
     */
    ADR_CODE_INSEE(14),
    /**
     * DATE_CREATION
     */
    DATE_CREATION(15),
    /**
     * DATE_MODIFICATION
     */
    DATE_MODIFICATION(16);

    /**
     * The position in CSV
     */
    private int _position;

    /**
     * Default constructor
     *
     * @param position
     *          The position
     */
    LienEqtPaModemHeader(int position)
    {
      _position = position;
    }

    /**
     * @return the position
     */
    public int getPosition()
    {
      return _position;
    }
  }

  /**
   * Writer retour
   */
  private Retour _retour;

  /**
   * File Name
   */
  private String _fileName;

  /**
   * The Writer
   */
  private BufferedWriter _writer;

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;

  /**
   * lines in buffer
   */
  private Integer _lineCount;

  /**
   * Max lines allowed in buffer before flush happens
   */
  private Integer _maxLines;

  /**
   * @param filename_p
   *          The csv output file
   * @param maxLines_p
   *          The max number of lines in buffer
   * @throws IOException
   *           IOException
   */
  public LienEqtPaModemWriter(String filename_p, Integer maxLines_p) throws IOException
  {
    _lineCount = 0;
    _maxLines = maxLines_p;
    _retour = RetourFactory.createOkRetour();
    _fileName = filename_p;

    _writer = Files.newBufferedWriter(Paths.get(filename_p));
    _csvPrinter = new CSVPrinter(_writer, CSVFormat.newFormat(';').withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(LienEqtPaModemHeader.class));

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
    _writer.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> records = getRecords(pfi_p, dateDemande_p);
    for (List<String> list : records)
    {
      write(tracabilite_p, list);
    }
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Method used to convert pfi attributes to a String list
   *
   * @param pfi_p
   *          The pfi to process
   * @return List<List<String>>
   */
  private List<List<String>> getRecords(PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> records = new ArrayList<>();
    if (nonNull(pfi_p.getEquipementDeclare()))
    {
      List<EquipementDeclare> eqptDeclareCarteThd = pfi_p.getEquipementDeclare().stream().filter(p -> Consts.MODEM.equals(p.getTypeEquipement())).collect(Collectors.toList());
      if (nonNull(eqptDeclareCarteThd))
      {
        for (EquipementDeclare equipementDeclare : eqptDeclareCarteThd)
        {
          //Find LienEqptPa
          if (nonNull(pfi_p.getLienEquipementPA()))
          {
            List<LienEquipementPA> lienEquipementPAList = pfi_p.getLienEquipementPA().stream().filter(eqtPa -> equipementDeclare.getNoEquipement().equals(eqtPa.getNoEquipement())).collect(Collectors.toList());
            if (nonNull(lienEquipementPAList) && nonNull(pfi_p.getPa()))
            {
              for (LienEquipementPA lienEqPa : lienEquipementPAList)
              {
                if (nonNull(lienEqPa) //
                    && "BSS_GP".equals(pfi_p.getClientOperateur()) //$NON-NLS-1$
                    && dateDemande_p.isEqual(lienEqPa.getDateModification().toLocalDate()))
                {
                  List<String> csvLine = new ArrayList<>(Arrays.asList(new String[LienEqtPaModemHeader.values().length]));
                  csvLine.set(LienEqtPaModemHeader.CLIENT_OPERATEUR.getPosition(), pfi_p.getClientOperateur());
                  csvLine.set(LienEqtPaModemHeader.NO_COMPTE.getPosition(), pfi_p.getNoCompte());
                  csvLine.set(LienEqtPaModemHeader.NO_EQUIPEMENT.getPosition(), lienEqPa.getNoEquipement());
                  csvLine.set(LienEqtPaModemHeader.ID_PA.getPosition(), lienEqPa.getIdFonctionnelPa());
                  csvLine.set(LienEqtPaModemHeader.STATUT.getPosition(), CSVWriterUtils.getCsvValue(lienEqPa.getStatut()));
                  csvLine.set(LienEqtPaModemHeader.SERIAL_NUMBER.getPosition(), equipementDeclare.getNoIdentifiant());
                  csvLine.set(LienEqtPaModemHeader.TYPE.getPosition(), equipementDeclare.getTypeEquipement());
                  csvLine.set(LienEqtPaModemHeader.MODELE.getPosition(), equipementDeclare.getModele());
                  csvLine.set(LienEqtPaModemHeader.ADR_MAC_MODEM.getPosition(), equipementDeclare.getMacAddressModem());
                  csvLine.set(LienEqtPaModemHeader.ADR_MAC_MTA.getPosition(), equipementDeclare.getMacAddressMta());
                  csvLine.set(LienEqtPaModemHeader.ADR_MAC_GATEWAY.getPosition(), equipementDeclare.getMacAddressGateway());
                  csvLine.set(LienEqtPaModemHeader.CODE_EAN.getPosition(), equipementDeclare.getCodeEan());
                  csvLine.set(LienEqtPaModemHeader.NOM_FABRICANT.getPosition(), equipementDeclare.getNomFabricant());

                  PA paFound = pfi_p.getPa().stream().filter(pa -> lienEqPa.getIdFonctionnelPa().equals(pa.getIdentifiantFonctionnelPA())).findFirst().orElseGet(null);
                  if ((paFound != null) && nonNull(paFound.getPaTypeLigneFixe()) && nonNull(paFound.getPaTypeLigneFixe().getInfoBrutBssGp()))
                  {
                    if (nonNull(paFound.getPaTypeLigneFixe().getInfoBrutBssGp().getAccesTechnique()))
                    {
                      csvLine.set(LienEqtPaModemHeader.TECHNO_RACCO.getPosition(), paFound.getPaTypeLigneFixe().getInfoBrutBssGp().getAccesTechnique().getTechnologieAcces());
                    }
                    if (nonNull(paFound.getPaTypeLigneFixe().getInfoBrutBssGp().getAdresseInstallation()))
                    {
                      csvLine.set(LienEqtPaModemHeader.ADR_CODE_INSEE.getPosition(), paFound.getPaTypeLigneFixe().getInfoBrutBssGp().getAdresseInstallation().getCodeInsee());
                    }
                  }
                  csvLine.set(LienEqtPaModemHeader.DATE_CREATION.getPosition(), CSVWriterUtils.getCsvValue(equipementDeclare.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
                  csvLine.set(LienEqtPaModemHeader.DATE_MODIFICATION.getPosition(), CSVWriterUtils.getCsvValue(lienEqPa.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
                  records.add(csvLine);
                }
              }
            }
          }
        }

      }
    }
    return records;
  }

  /**
   * Add lines to buffer or write them on file if buffer size is greater then max permited
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param line_p
   *          the line to write
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> line_p)
  {
    try
    {
      _csvPrinter.printRecord(line_p);
      _lineCount++;
      if (_lineCount >= _maxLines)
      {
        _csvPrinter.flush();
        _lineCount = 0;
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }
}
