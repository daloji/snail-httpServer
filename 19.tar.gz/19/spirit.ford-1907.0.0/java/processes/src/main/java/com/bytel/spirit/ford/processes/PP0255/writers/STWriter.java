/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.ford.shared.misc.processes.writers.IGenericWriter;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public abstract class STWriter implements IGenericWriter<ServiceTechnique>
{
  /**
   * Number of maximum lines to write without performing a flush on the CSV file.
   */
  private int _linesToFlush;

  /**
   * The path of CSV file.
   */
  private String _filePath;

  /**
   * The name of CSV file.
   */
  private String _fileName;

  /**
   * Number of lines dumped in the CSV file.
   */
  private int _currentDumpedLines = 0;

  /**
   * retour
   */
  private Retour _retour;

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;

  /**
   * @param linesToFlush_p
   * @param filePath_p
   * @param fileName_p
   */
  public STWriter(String filePath_p, String fileName_p, int linesToFlush_p)
  {
    super();
    _linesToFlush = linesToFlush_p;
    _filePath = filePath_p;
    _fileName = fileName_p;
    _retour = RetourFactory.createOkRetour();

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
  }

  @Override
  public String getFileName()
  {
    return _fileName;
  }

  @Override
  public String getFilePath()
  {
    return _filePath;
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  @Override
  public void setCSVPrinter(CSVPrinter csvPrinter_p)
  {
    this._csvPrinter = csvPrinter_p;
  }

  /**
   * Dump the object in serviceTechnique parameter
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param serviceTechnique_p
   *          ServiceTechnique object
   */
  protected abstract void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p);

  /**
   * Check if the ServiceTechnique object in the parameter has the correct type, in order to know if the writer should
   * execute the dump operation
   *
   * @param serviceTechnique_p
   *          The serviceTechnique object
   * @return true if dump operation is to be performed
   */
  protected abstract boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p);

  /**
   * Write in the CSV file the list of records. Each record corresponds to a line.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param record_p
   *          The list of records.
   */
  protected synchronized void write(Tracabilite tracabilite_p, List<String> record_p)
  {
    try
    {
      List<String> newRecords = new ArrayList<>();
      // remove endOfLine in fields
      for (String record : record_p)
      {
        if (record != null)
        {
          record = record.replace("\r\n", "").replace("\n", ""); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
          newRecords.add(record);
        }
        else
        {
          newRecords.add(null);
        }
      }
      _csvPrinter.printRecord(newRecords);
      //check if a flush is needed
      if ((++_currentDumpedLines % this._linesToFlush) == 0)
      {
        _csvPrinter.flush();
      }
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, _fileName, exception.getMessage())));
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, _fileName, exception.getMessage()));
    }
  }
}
