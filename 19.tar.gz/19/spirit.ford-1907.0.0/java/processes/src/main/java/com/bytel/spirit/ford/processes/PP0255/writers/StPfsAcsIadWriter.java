/*******************************************************************************
* $Id: StPfsAcsIadWriter.java 19167 2019-03-27 16:03:32Z jjoly $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static java.util.Objects.nonNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.acsiad.StPfsAcsIad;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author pcarreir
 * @version ($Revision: 19167 $ $Date: 2019-03-27 17:03:32 +0100 (mer. 27 mars 2019) $)
 */
public class StPfsAcsIadWriter extends STWriter
{
  /**
   * Class containing the StLienAllocationCommercial entete to write in CSV File.
   *
   * @author pcarreir
   * @version ($Revision: 19167 $ $Date: 2019-03-27 17:03:32 +0100 (mer. 27 mars 2019) $)
   */
  public enum StPfsAcsIadHeader
  {
    /**
     *
     */
    ID_ST(0),

    /**
     *
     */
    STATUT(1),

    /**
     *
     */
    COMMENTAIRE(2),

    /**
     *
     */
    CLIENT_OPERATEUR(3),

    /**
     *
     */
    NO_COMPTE(4),

    /**
     *
     */
    NO_EQUIPEMENT(5),

    /**
     *
     */
    NUMERO_SERIE(6),

    /**
     *
     */
    NOM_FABRICANT(7),

    /**
    *
    */
    MODELE_EQUIPEMENT(8),

    /**
    *
    */
    CODE_EAN(9),

    /**
    *
    */
    ADR_MAC_MODEM(10),

    /**
    *
    */
    ADR_MAC_MTA(11),

    /**
    *
    */
    ADR_MAC_GATEWAY(12),

    /**
    *
    */
    DOMAINE_IMS(13),

    /**
    *
    */
    NOM_FQDN(14),

    /**
    *
    */
    IMPI_PORT_VOIX1(15),

    /**
    *
    */
    MOT_DE_PASSE_PORT_VOIX1(16),

    /**
    *
    */
    TEL_URI_PORT_VOIX1(17),

    /**
    *
    */
    IMPI_PORT_VOIX2(18),

    /**
    *
    */
    MOT_DE_PASSE_PORT_VOIX2(19),

    /**
    *
    */
    TEL_URI_PORT_VOIX2(20),

    /**
     *
     */
    DATE_CREATION(21),

    /**
     *
     */
    DATE_MODIFICATION(22);

    /**
     * The header size
     */
    static final int ST_PFS_ACS_IAD_HEADER_SIZE = 23;

    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    StPfsAcsIadHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public StPfsAcsIadWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    super(filePath_p, fileName_p, linesToFlush_p);
    createFile(filePath_p + fileName_p, StPfsAcsIadHeader.class);
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique objectToWrite_p)
  {
    if (shouldExecuteDump(objectToWrite_p))
    {
      executeDumpAction(tracabilite_p, objectToWrite_p);
    }
  }

  @Override
  protected void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    StPfsGenerique stPfsGenerique = StPfsGenerique.class.cast(serviceTechnique_p);
    StPfsAcsIad stPfsAcsIad = deserializeRawFields(tracabilite_p, stPfsGenerique);//because of raw json fields from SAAB
    List<String> record = this.getRecord(stPfsAcsIad);

    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  protected boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p)
  {
    if (serviceTechnique_p != null)
    {
      if (TypeST.PFS.name().equals(serviceTechnique_p.getTypeServiceTechnique()))
      {
        return TypePFS.ACS_IAD.name().equals(StPfsGenerique.class.cast(serviceTechnique_p).getTypePfs());
      }
    }
    return false;
  }

  /**
   * Convert an instance of StPfsGenerique object (having json raw fields) to an instance of StPfsAcsIad.
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @param stPfsGenerique_p
   *          Instance of StPfsGenerique
   * @return An instance of StPfsAcsIad if deserialization succeeds, null otherwise.
   */
  private StPfsAcsIad deserializeRawFields(Tracabilite tracabilite_p, StPfsGenerique stPfsGenerique_p)
  {
    StPfsAcsIad stPfsAcsIad = null;
    try
    {
      stPfsAcsIad = stPfsGenerique_p != null ? StPfsAcsIad.buildFromStPfsGenerique(stPfsGenerique_p) : null;
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
    }
    return stPfsAcsIad;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param stPfsAcsIad_p
   *          The ServiceTechnique
   *
   * @return List of values
   */
  private List<String> getRecord(StPfsAcsIad stPfsAcsIad_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[StPfsAcsIadHeader.ST_PFS_ACS_IAD_HEADER_SIZE]));

    if (nonNull(stPfsAcsIad_p))
    {
      record.set(StPfsAcsIadHeader.ID_ST.getIndex(), stPfsAcsIad_p.getIdSt());
      record.set(StPfsAcsIadHeader.STATUT.getIndex(), stPfsAcsIad_p.getStatut());
      record.set(StPfsAcsIadHeader.COMMENTAIRE.getIndex(), stPfsAcsIad_p.getCommentaire());
      record.set(StPfsAcsIadHeader.CLIENT_OPERATEUR.getIndex(), stPfsAcsIad_p.getClientOperateur());
      record.set(StPfsAcsIadHeader.NO_COMPTE.getIndex(), stPfsAcsIad_p.getNoCompte());

      if (stPfsAcsIad_p.getDonneesIdentificationSTPfsAcsIad() != null)
      {
        record.set(StPfsAcsIadHeader.NO_EQUIPEMENT.getIndex(), stPfsAcsIad_p.getDonneesIdentificationSTPfsAcsIad().getNoEquipement());
      }

      if (stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad() != null)
      {
        record.set(StPfsAcsIadHeader.NUMERO_SERIE.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getNumeroSerie());
        record.set(StPfsAcsIadHeader.NOM_FABRICANT.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getNomFabricant());
        record.set(StPfsAcsIadHeader.MODELE_EQUIPEMENT.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getModele());
        record.set(StPfsAcsIadHeader.CODE_EAN.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getCodeEAN());
        record.set(StPfsAcsIadHeader.ADR_MAC_MODEM.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getAdresseMacModem());
        record.set(StPfsAcsIadHeader.ADR_MAC_MTA.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getAdresseMacMta());
        record.set(StPfsAcsIadHeader.ADR_MAC_GATEWAY.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getAdresseMacGateway());
        if (stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getConfigurationIms() != null)
        {
          record.set(StPfsAcsIadHeader.DOMAINE_IMS.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getConfigurationIms().getDomaineIms());
          record.set(StPfsAcsIadHeader.NOM_FQDN.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getConfigurationIms().getNomFQDN());
          record.set(StPfsAcsIadHeader.IMPI_PORT_VOIX1.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getConfigurationIms().getImpiPortVoix1());
          record.set(StPfsAcsIadHeader.MOT_DE_PASSE_PORT_VOIX1.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getConfigurationIms().getMotDePassePortVoix1());
          record.set(StPfsAcsIadHeader.TEL_URI_PORT_VOIX1.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getConfigurationIms().getTelUriPortVoix1());
          record.set(StPfsAcsIadHeader.IMPI_PORT_VOIX2.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getConfigurationIms().getImpiPortVoix2());
          record.set(StPfsAcsIadHeader.MOT_DE_PASSE_PORT_VOIX2.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getConfigurationIms().getMotDePassePortVoix2());
          record.set(StPfsAcsIadHeader.TEL_URI_PORT_VOIX2.getIndex(), stPfsAcsIad_p.getDonneesProvisionneesSTPfsAcsIad().getConfigurationIms().getTelUriPortVoix2());
        }
      }

      record.set(StPfsAcsIadHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsAcsIad_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
      record.set(StPfsAcsIadHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsAcsIad_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
      return record;
    }

    return Collections.emptyList();
  }
}
