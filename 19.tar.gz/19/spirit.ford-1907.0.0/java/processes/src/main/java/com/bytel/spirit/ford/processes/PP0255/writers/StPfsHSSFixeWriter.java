/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static java.util.Objects.nonNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.hssfixe.StPfsHSSFixe;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.processes.Messages;

/**
 *
 * @author anakashi
 * @version ($Revision$ $Date$)
 */
public class StPfsHSSFixeWriter extends STWriter
{

  /**
   *
   * @author anakashi
   * @version ($Revision$ $Date$)
   */
  public enum StPfsHSSFixeHeader
  {
    /**
     *
     */
    ID_ST(0),

    /**
     *
     */
    STATUT(1),

    /**
     *
     */
    COMMENTAIRE(2),

    /**
     *
     */
    CLIENT_OPERATEUR(3),

    /**
     *
     */
    NO_COMPTE(4),

    /**
     *
     */
    ID_COMPTE_IMS(5),

    /**
     *
     */
    NO_TELEPHONE(6),

    /**
     *
     */
    TYPE_USAGE(7),

    /**
    *
    */
    IMPI_FIXE(8),

    /**
    *
    */
    MOT_DE_PASSE_IMS(9),

    /**
    *
    */
    SIP_URI(10),

    /**
     *
     */
    TEL_URI(11),

    /**
     *
     */
    NOM_PRENOM_COURT(12),

    /**
    *
    */
    CODE_INSEE(13);

    /**
     * The header size
     */
    static final int ST_PFS_HSS_FIXE_HEADER_SIZE = 14;

    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    StPfsHSSFixeHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public StPfsHSSFixeWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    super(filePath_p, fileName_p, linesToFlush_p);
    createFile(filePath_p + fileName_p, StPfsHSSFixeHeader.class);
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique objectToWrite_p)
  {
    if (shouldExecuteDump(objectToWrite_p))
    {
      executeDumpAction(tracabilite_p, objectToWrite_p);
    }
  }

  @Override
  protected void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("StPfsHSSFixeWriter.start"))); //$NON-NLS-1$

    StPfsGenerique stPfsGenerique = StPfsGenerique.class.cast(serviceTechnique_p);
    StPfsHSSFixe stPfsHSSFixe = deserializeRawFields(tracabilite_p, stPfsGenerique);//because of raw json fields from SAAB
    List<String> record = this.getRecord(stPfsHSSFixe);

    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }

    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("StPfsHSSFixeWriter.end"))); //$NON-NLS-1$
  }

  @Override
  protected boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p)
  {
    if (serviceTechnique_p != null)
    {
      if (TypeST.PFS.name().equals(serviceTechnique_p.getTypeServiceTechnique()))
      {
        return TypePFS.HSS_FIXE.name().equals(StPfsGenerique.class.cast(serviceTechnique_p).getTypePfs());
      }
    }
    return false;
  }

  /**
   * Convert an instance of StPfsGenerique object (having json raw fields) to an instance of StPfsHSSFixe.
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @param stPfsGenerique_p
   *          Instance of StPfsGenerique
   * @return An instance of StPfsHSSFixe if deserialization succeeds, null otherwise.
   */
  private StPfsHSSFixe deserializeRawFields(Tracabilite tracabilite_p, StPfsGenerique stPfsGenerique_p)
  {
    StPfsHSSFixe stPfsHSSFixe = null;
    try
    {
      stPfsHSSFixe = stPfsGenerique_p != null ? StPfsHSSFixe.buildFromStPfsGenerique(stPfsGenerique_p) : null;
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
    }
    return stPfsHSSFixe;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param stPfsHSSFixe_p
   *          The ServiceTechnique
   *
   * @return List of values
   */
  private List<String> getRecord(StPfsHSSFixe stPfsHSSFixe_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[StPfsHSSFixeHeader.ST_PFS_HSS_FIXE_HEADER_SIZE]));

    if (nonNull(stPfsHSSFixe_p))
    {
      record.set(StPfsHSSFixeHeader.ID_ST.getIndex(), stPfsHSSFixe_p.getIdSt());
      record.set(StPfsHSSFixeHeader.STATUT.getIndex(), stPfsHSSFixe_p.getStatut());
      record.set(StPfsHSSFixeHeader.COMMENTAIRE.getIndex(), stPfsHSSFixe_p.getCommentaire());
      record.set(StPfsHSSFixeHeader.CLIENT_OPERATEUR.getIndex(), stPfsHSSFixe_p.getClientOperateur());
      record.set(StPfsHSSFixeHeader.NO_COMPTE.getIndex(), stPfsHSSFixe_p.getNoCompte());

      if (stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe() != null)
      {
        record.set(StPfsHSSFixeHeader.ID_COMPTE_IMS.getIndex(), stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getIdCompteIms());
        record.set(StPfsHSSFixeHeader.NO_TELEPHONE.getIndex(), stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getNoTelephone());
        record.set(StPfsHSSFixeHeader.TYPE_USAGE.getIndex(), stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getTypeUsage());
        record.set(StPfsHSSFixeHeader.IMPI_FIXE.getIndex(), stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getImpiFixe());
        record.set(StPfsHSSFixeHeader.MOT_DE_PASSE_IMS.getIndex(), stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getMotDePasseIms());
        record.set(StPfsHSSFixeHeader.SIP_URI.getIndex(), stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getSipUri());
        record.set(StPfsHSSFixeHeader.TEL_URI.getIndex(), stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getTelUri());
        record.set(StPfsHSSFixeHeader.NOM_PRENOM_COURT.getIndex(), stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getNomPrenomCourt());
        record.set(StPfsHSSFixeHeader.CODE_INSEE.getIndex(), stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe().getCodeInsee());
      }
      return record;
    }

    return Collections.emptyList();
  }

}
