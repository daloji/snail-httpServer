/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author jbrites
 * @version ($Revision$ $Date$)
 */
public class StLACWriter extends STWriter
{
  /**
   * Class containing the StLienAllocationCommercial entete to write in CSV File.
   *
   * @author jbrites
   * @version ($Revision$ $Date$)
   */
  public enum StLACHeader
  {
    /**
     *
     */
    ID_ST(0),

    /**
     *
     */
    STATUT(1),

    /**
     *
     */
    COMMENTAIRE(2),

    /**
     *
     */
    CLIENT_OPERATEUR(3),

    /**
     *
     */
    NO_COMPTE(4),

    /**
     *
     */
    TYPE_RESSOURCE(5),

    /**
     *
     */
    ID_RESSOURCE(6),

    /**
     *
     */
    TYPE_OC(7),

    /**
     *
     */
    OC_CLIENT_OPERATEUR(8),

    /**
     *
     */
    OC_NO_COMPTE(9),

    /**
     *
     */
    OC_ID_PA(10),

    /**
     *
     */
    OC_NO_SA(11),

    /**
     *
     */
    OC_NO_EQUIPEMENT(12),

    /**
     *
     */
    DATE_CREATION(13),

    /**
     *
     */
    DATE_MODIFICATION(14);

    /**
     * The header size
     */
    static final int ST_LAC_HEADER_SIZE = 15;

    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    StLACHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public StLACWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    super(filePath_p, fileName_p, linesToFlush_p);
    createFile(filePath_p + fileName_p, StLACHeader.class);
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    if (shouldExecuteDump(serviceTechnique_p))
    {
      executeDumpAction(tracabilite_p, serviceTechnique_p);
    }
  }

  @Override
  protected void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    List<String> record = this.getRecord(StLienAllocationCommercial.class.cast(serviceTechnique_p));
    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  protected boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p)
  {
    if (serviceTechnique_p != null)
    {
      return TypeST.LAC.name().equals(serviceTechnique_p.getTypeServiceTechnique());
    }
    return false;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param stLienAllocationCommercial_p
   *          The ServiceTechnique
   *
   * @return List of values
   */
  private List<String> getRecord(StLienAllocationCommercial stLienAllocationCommercial_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[StLACHeader.ST_LAC_HEADER_SIZE]));

    record.set(StLACHeader.ID_ST.getIndex(), stLienAllocationCommercial_p.getIdSt());
    record.set(StLACHeader.STATUT.getIndex(), stLienAllocationCommercial_p.getStatut());
    record.set(StLACHeader.COMMENTAIRE.getIndex(), stLienAllocationCommercial_p.getCommentaire());
    record.set(StLACHeader.CLIENT_OPERATEUR.getIndex(), stLienAllocationCommercial_p.getClientOperateur());
    record.set(StLACHeader.NO_COMPTE.getIndex(), stLienAllocationCommercial_p.getNoCompte());
    record.set(StLACHeader.TYPE_RESSOURCE.getIndex(), stLienAllocationCommercial_p.getTypeRessource());
    record.set(StLACHeader.ID_RESSOURCE.getIndex(), stLienAllocationCommercial_p.getIdRessource());
    record.set(StLACHeader.TYPE_OC.getIndex(), stLienAllocationCommercial_p.getTypeObjetCommercial());
    record.set(StLACHeader.OC_CLIENT_OPERATEUR.getIndex(), stLienAllocationCommercial_p.getOcClientOperateur());
    record.set(StLACHeader.OC_NO_COMPTE.getIndex(), stLienAllocationCommercial_p.getOcNoCompte());
    record.set(StLACHeader.OC_ID_PA.getIndex(), stLienAllocationCommercial_p.getOcIdentifiantFonctionnelPA());
    record.set(StLACHeader.OC_NO_SA.getIndex(), stLienAllocationCommercial_p.getOcNoServiceAccessible());
    record.set(StLACHeader.OC_NO_EQUIPEMENT.getIndex(), stLienAllocationCommercial_p.getOcNoEquipement());
    record.set(StLACHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(stLienAllocationCommercial_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
    record.set(StLACHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(stLienAllocationCommercial_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
    return record;

  }

}
