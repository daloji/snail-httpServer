/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0378.writers;

import static java.util.Objects.nonNull;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.QuoteMode;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.hssfixe.DonneesProvisionneesStPfsHSSFixe;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.hssfixe.StPfsHSSFixe;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.shared.misc.processes.writers.IGenericWriter;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class CompteHssParFqdnWriter implements IGenericWriter<ServiceTechnique>
{
  /**
   * Class containing the CompteHssParFqdn Entete to write in CSV file
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  public enum CompteHssParFqdnHeader
  {
    /**
     *
     */
    SUBSRIBERID(0),
    /**
     *
     */
    IMPI(1),
    /**
     *
     */
    IMPU_1(2),
    /**
     *
     */
    IMPU_2(3),
    /**
     *
     */
    PASSWORD(4),
    /**
     *
     */
    DISPLAY_NAME(5),
    /**
     *
     */
    REF_ACCESS_LOCATION(6);

    /**
     * The index of column in header
     */
    private int _index;

    /**
     * @param index_p
     *          the index
     */
    CompteHssParFqdnHeader(int index_p)
    {
      _index = index_p;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;

  /**
   * Number of maximum lines to write without performing a flush on the CSV file.
   */
  private int _linesToFlush;

  /**
   * The path of CSV file.
   */
  private String _filePath;

  /**
   * The name of CSV file.
   */
  private String _fileName;

  /**
   * Number of lines dumped in the CSV file.
   */
  private int _currentDumpedLines = 0;

  /**
   * retour
   */
  private Retour _retour;

  /**
   * Constructor
   *
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name of the file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public CompteHssParFqdnWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    _filePath = filePath_p;
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    _retour = RetourFactory.createOkRetour();

    //createFile(filePath_p + fileName_p, CompteHssParFqdnHeader.class);
    CSVFormat csvFormat = CSVFormat.newFormat(CSV_SEPARATOR).withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(CompteHssParFqdnHeader.class).withQuote('"').withQuoteMode(QuoteMode.ALL);
    _csvPrinter = new CSVPrinter(Files.newBufferedWriter(Paths.get(filePath_p + fileName_p)), csvFormat);
  }

  @Override
  public void close() throws IOException
  {
    _csvPrinter.flush();
    _csvPrinter.close();
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique objectToWrite_p)
  {
    if (shouldExecuteDump(tracabilite_p, objectToWrite_p))
    {
      executeDumpAction(tracabilite_p, objectToWrite_p);
    }
  }

  @Override
  public String getFileName()
  {
    return _fileName;
  }

  @Override
  public String getFilePath()
  {
    return _filePath;
  }

  /**
   * This method will return the dump execution result
   *
   * @return {@link Retour}
   */
  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  @Override
  public void setCSVPrinter(CSVPrinter csvPrinter_p)
  {
    this._csvPrinter = csvPrinter_p;
  }

  /**
   * Convert an instance of StPfsGenerique object (having json raw fields) to an instance of StPfsHSSFixe.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param stPfs_p
   *          Instance of StPfsGenerique
   *
   * @return An instance of StPfsHSSFixe if deserialization succeeds, null otherwise.
   */
  private StPfsHSSFixe deserializeRawFields(Tracabilite tracabilite_p, StPfsGenerique stPfs_p)
  {
    StPfsHSSFixe stPfsHSSFixe = null;
    try
    {
      stPfsHSSFixe = nonNull(stPfs_p) ? StPfsHSSFixe.buildFromStPfsGenerique(stPfs_p) : null;
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
    }
    return stPfsHSSFixe;
  }

  /**
   * Dump the object in serviceTechnique parameter
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param serviceTechnique_p
   *          ServiceTechnique object
   */
  private void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    StPfsHSSFixe stPfsHSSFixe = deserializeRawFields(tracabilite_p, StPfsGenerique.class.cast(serviceTechnique_p));
    List<String> record = this.getRecord(tracabilite_p, stPfsHSSFixe);
    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param stPfsHSSFixe_p
   *          stPfsHSSFixe_p
   *
   * @return List of values
   */
  private List<String> getRecord(Tracabilite tracabilite_p, StPfsHSSFixe stPfsHSSFixe_p)
  {
    if (nonNull(stPfsHSSFixe_p))
    {
      DonneesProvisionneesStPfsHSSFixe donneesProvisionnees = stPfsHSSFixe_p.getDonneesProvisionneesStPfsHSSFixe();
      List<String> record = new ArrayList<>(Arrays.asList(new String[CompteHssParFqdnHeader.values().length]));
      record.set(CompteHssParFqdnHeader.SUBSRIBERID.getIndex(), Optional.ofNullable(donneesProvisionnees.getIdCompteIms()).orElse(StringConstants.EMPTY_STRING));
      record.set(CompteHssParFqdnHeader.IMPI.getIndex(), Optional.ofNullable(donneesProvisionnees.getImpiFixe()).orElse(StringConstants.EMPTY_STRING));
      record.set(CompteHssParFqdnHeader.IMPU_1.getIndex(), Optional.ofNullable(donneesProvisionnees.getSipUri()).map(s -> "sip:+33" + s + "@fai.bouygtel.net").orElse(StringConstants.EMPTY_STRING)); //$NON-NLS-1$ //$NON-NLS-2$
      record.set(CompteHssParFqdnHeader.IMPU_2.getIndex(), Optional.ofNullable(donneesProvisionnees.getTelUri()).map(s -> "tel:+33" + s).orElse(StringConstants.EMPTY_STRING)); //$NON-NLS-1$
      String pw = null;
      try
      {
        pw = PasswordDecrypter.decrypt(donneesProvisionnees.getMotDePasseIms());
      }
      catch (RavelException exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      }
      record.set(CompteHssParFqdnHeader.PASSWORD.getIndex(), Optional.ofNullable(pw).orElse(StringConstants.EMPTY_STRING));
      record.set(CompteHssParFqdnHeader.DISPLAY_NAME.getIndex(), Optional.ofNullable(donneesProvisionnees.getNomPrenomCourt()).orElse(StringConstants.EMPTY_STRING));
      record.set(CompteHssParFqdnHeader.REF_ACCESS_LOCATION.getIndex(), Optional.ofNullable(donneesProvisionnees.getCodeInsee()).map(s -> "xDSL;operator-specific-GI=63" + s + "00").orElse(StringConstants.EMPTY_STRING)); //$NON-NLS-1$ //$NON-NLS-2$

      return record;
    }

    return Collections.emptyList();
  }

  /**
   * Check if the ServiceTechnique object in the parameter has the correct type and data, in order to know if the writer
   * should execute the dump operation
   *
   * @param tracabilite_p
   *          tracabilite
   * @param serviceTechnique_p
   *          The serviceTechnique object
   * @return true if dump operation is to be performed
   */
  private boolean shouldExecuteDump(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    if (nonNull(serviceTechnique_p) && TypeST.PFS.name().equals(serviceTechnique_p.getTypeServiceTechnique()))
    {
      StPfsGenerique stPfs = StPfsGenerique.class.cast(serviceTechnique_p);
      if (TypePFS.HSS_FIXE.name().equals(stPfs.getTypePfs()) && nonNull(stPfs.getDonneesProvisionnees()))
      {
        StPfsHSSFixe stPfsHSSFixe = deserializeRawFields(tracabilite_p, stPfs);
        return !Statut.INACTIF.name().equals(stPfsHSSFixe.getStatut()) && "VOIX".equals(stPfsHSSFixe.getDonneesProvisionneesStPfsHSSFixe().getTypeUsage()); //$NON-NLS-1$
      }
    }
    return false;
  }

  /**
   * Write in the CSV file the list of records. Each record corresponds to a line.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param record_p
   *          The list of records.
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> record_p)
  {
    try
    {
      _csvPrinter.printRecord(record_p);
      //check if a flush is needed
      if ((++_currentDumpedLines % this._linesToFlush) == 0)
      {
        _csvPrinter.flush();
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }
}
