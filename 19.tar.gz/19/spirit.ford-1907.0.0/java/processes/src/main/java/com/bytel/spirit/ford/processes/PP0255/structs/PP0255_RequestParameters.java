/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.structs;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PP0255_RequestParameters
{
  /**
   * Execution mode
   */
  private String _modeExecution;

  /**
   * Type of service technique
   */
  private String _typeServiceTechnique;

  /**
   * @return value of modeExecution
   */
  public String getModeExecution()
  {
    return _modeExecution;
  }

  /**
   * @return the typeServiceTechnique
   */
  public String getTypeServiceTechnique()
  {
    return _typeServiceTechnique;
  }

  /**
   * @param modeExecution_p
   *          The modeExecution to set.
   */
  public void setModeExecution(String modeExecution_p)
  {
    _modeExecution = modeExecution_p;
  }

  /**
   * @param typeServiceTechnique_p
   *          the typeServiceTechnique to set
   */
  public void setTypeServiceTechnique(String typeServiceTechnique_p)
  {
    _typeServiceTechnique = typeServiceTechnique_p;
  }

}
