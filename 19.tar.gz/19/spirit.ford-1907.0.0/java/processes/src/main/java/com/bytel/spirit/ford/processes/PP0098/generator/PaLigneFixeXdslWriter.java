/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PaLigneFixeXdslWriter implements INSFWriter
{
  /**
   * Enum containing the Header specification for a PALFXDSL CSV file type.
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public enum PALFXDSLHeader
  {

    /**
     *
     */
    CLIENT_OPERATEUR(0),

    /**
     *
     */
    NO_COMPTE(1),

    /**
     *
     */
    ID_PA(2),

    /**
     *
     */
    STATUT(3),

    /**
     *
     */
    DATE_CHGT_STATUT(4),

    /**
     *
     */
    ID_RACCO(5),

    /**
     *
     */
    IS_PA_CIBLE(6),

    /**
     *
     */
    IS_PA_PRINCIPAL(7),

    /**
     *
     */
    NDI(8),

    /**
     *
     */
    CODE_NRA(9),

    /**
     *
     */
    ID_RES_RESEAU(10),

    /**
     *
     */
    ID_LIGNE(11),

    /**
     *
     */
    ID_ACTION(12),

    /**
     *
     */
    TYPE_ACTION_ADSL(13),

    /**
     *
     */
    ADSL_ETAT_FT(14),

    /**
     *
     */
    QUALITES_TV_POSSIBLE(15),

    /**
     *
     */
    TECHNO_RACCO(16),

    /**
     *
     */
    ID_PROFIL_TECH(17),

    /**
     *
     */
    ID_OPE_COLLECTE(18),

    /**
     *
     */
    TYPE_DEGROUPAGE(19),

    /**
     *
     */
    ADR_NUMERO(20),

    /**
     *
     */
    ADR_IND_REPETITION(21),

    /**
     *
     */
    ADR_NOM_VOIE(22),

    /**
     *
     */
    ADR_CODE_POSTAL(23),

    /**
     *
     */
    ADR_VILLE(24),

    /**
     *
     */
    ADR_CODE_INSEE(25),

    /**
     *
     */
    ADR_CODE_RIVOLI(26),

    /**
     *
     */
    ADR_PORTE(27),

    /**
     *
     */
    ADR_LOGO(28),

    /**
     *
     */
    ADR_BATIMENT(29),

    /**
     *
     */
    ADR_ESCALIER(30),

    /**
     *
     */
    ADR_ETAGE(31),

    /**
     *
     */
    ADR_PRE_PROPRIETAIRE(32),

    /**
     *
     */
    INST_ID_MANDAT(33),

    /**
     *
     */
    INST_TYPE_MES(34),

    /**
     *
     */
    INST_DATE_CLIENT(35),

    /**
     *
     */
    INST_CRENEAU_CLIENT(36),

    /**
     *
     */
    INST_ID_RDV(37),

    /**
     *
     */
    INST_COMMENTAIRE(38),

    /**
     *
     */
    DATE_CREATION(39),

    /**
     *
     */
    DATE_MODIFICATION(40);
    /**
     * Header size of PALFXDSL CSV file type.
     */
    private static final int PALFXDSL_HEADER_SIZE = 43;
    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index_p
     *          The index
     */
    PALFXDSLHeader(int index_p)
    {
      _index = index_p;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * LIGNE_FIXE PA type
   */
  private static final String PA_TYPE_LIGNE_FIXE = "LIGNE_FIXE"; //$NON-NLS-1$

  /**
   * TECNOLOGIE XDSL
   */
  private static final String ACCES_TECHNIQUE_XDSL = "XDSL"; //$NON-NLS-1$

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;
  /**
   * Number of maximum lines to write without performing a flush on the CSV file.
   */
  private int _linesToFlush;

  /**
   * The name of CSV PFI file.
   */
  private String _fileName;

  /**
   * Number of lines dumped in the CSV file.
   */
  private int _currentDumpedLines = 0;

  /**
   * retour
   */
  private Retour _retour;

  /**
   * @param fileName_p
   *          Name of the CSV file to create
   * @param linesToFlush_p
   *          Number of written lines needed to perform a flush operation
   * @throws IOException
   *           IOException
   *
   */
  public PaLigneFixeXdslWriter(String fileName_p, int linesToFlush_p) throws IOException
  {
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    initCsvPrinter();

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> records = this.getRecords(pfi_p, dateDemande_p);

    for (List<String> record : records)
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param pfi_p
   *          The PFI
   *
   * @return List of records
   */
  private List<List<String>> getRecords(PFI pfi_p, LocalDate dateDemande_p)
  {

    List<List<String>> records = new ArrayList<>();

    List<PA> lPALigneFixe = pfi_p.getPa().stream().filter(pa -> pa.getTypePA().equals(PA_TYPE_LIGNE_FIXE))//filter PA of type LIGNE_FIXE
        .filter(pa -> pa.getPaTypeLigneFixe() != null)//only want non null PATypeLigneFixed
        .collect(Collectors.toList());

    for (PA pa : lPALigneFixe)
    {
      PaTypeLigneFixe paLigneFixe = pa.getPaTypeLigneFixe();
      if (isPALigneFixeXDSL(paLigneFixe) //
          && "BSS_GP".equals(pfi_p.getClientOperateur()) //$NON-NLS-1$
          && (dateDemande_p.isEqual(pa.getDateCreation().toLocalDate()) //
              || dateDemande_p.isEqual(pa.getDateModification().toLocalDate())))
      {
        List<String> record = new ArrayList<>(Arrays.asList(new String[PALFXDSLHeader.PALFXDSL_HEADER_SIZE]));

        record.set(PALFXDSLHeader.CLIENT_OPERATEUR.getIndex(), pfi_p.getClientOperateur());
        record.set(PALFXDSLHeader.NO_COMPTE.getIndex(), pfi_p.getNoCompte());
        record.set(PALFXDSLHeader.ID_PA.getIndex(), pa.getIdentifiantFonctionnelPA());
        record.set(PALFXDSLHeader.STATUT.getIndex(), CSVWriterUtils.getCsvValue(pa.getStatut()));
        record.set(PALFXDSLHeader.DATE_CHGT_STATUT.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getDatePriseEnCompteChangementStatut(), DateTimeFormatPattern.yyyy_dash_MM_dash_dd_space_HH_colon_mm_colon_ss_dot_SSS));
        record.set(PALFXDSLHeader.ID_RACCO.getIndex(), paLigneFixe.getIdRaccordement());
        record.set(PALFXDSLHeader.IS_PA_CIBLE.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getInfoBrutBssGp().isIndicateurPACible()));
        record.set(PALFXDSLHeader.IS_PA_PRINCIPAL.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getInfoBrutBssGp().isIndicateurPAPrincipal()));
        record.set(PALFXDSLHeader.NDI.getIndex(), paLigneFixe.getInfoBrutBssGp().getIdPrise());
        record.set(PALFXDSLHeader.CODE_NRA.getIndex(), paLigneFixe.getInfoBrutBssGp().getCodeNRA());
        record.set(PALFXDSLHeader.ID_RES_RESEAU.getIndex(), paLigneFixe.getInfoBrutBssGp().getIdRessourceReseauXDSL());
        record.set(PALFXDSLHeader.ID_LIGNE.getIndex(), paLigneFixe.getInfoBrutBssGp().getIdLigne());
        record.set(PALFXDSLHeader.ID_ACTION.getIndex(), paLigneFixe.getInfoBrutBssGp().getIdAction());
        record.set(PALFXDSLHeader.TYPE_ACTION_ADSL.getIndex(), paLigneFixe.getInfoBrutBssGp().getTypeActionADSL());
        record.set(PALFXDSLHeader.ADSL_ETAT_FT.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdslEtatFT());
        record.set(PALFXDSLHeader.QUALITES_TV_POSSIBLE.getIndex(), paLigneFixe.getInfoBrutBssGp().getQualitesTVPossibles());
        record.set(PALFXDSLHeader.TECHNO_RACCO.getIndex(), paLigneFixe.getInfoBrutBssGp().getAccesTechnique().getTechnologieAcces());
        record.set(PALFXDSLHeader.ID_PROFIL_TECH.getIndex(), paLigneFixe.getInfoBrutBssGp().getAccesTechnique().getIdProfilTechnique());
        record.set(PALFXDSLHeader.ID_OPE_COLLECTE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAccesTechnique().getIdOperateurCollecte());
        record.set(PALFXDSLHeader.TYPE_DEGROUPAGE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAccesTechnique().getTypeDegroupage());

        if (paLigneFixe.getInfoBrutBssGp().getAdresseInstallation() != null)
        {
          record.set(PALFXDSLHeader.ADR_NUMERO.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getNumero());
          record.set(PALFXDSLHeader.ADR_IND_REPETITION.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getIndiceRepetition());
          record.set(PALFXDSLHeader.ADR_NOM_VOIE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getNomVoie());
          record.set(PALFXDSLHeader.ADR_CODE_POSTAL.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getCodePostal());
          record.set(PALFXDSLHeader.ADR_VILLE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getVille());
          record.set(PALFXDSLHeader.ADR_CODE_INSEE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getCodeInsee());
          record.set(PALFXDSLHeader.ADR_CODE_RIVOLI.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getCodeRivoli());
          record.set(PALFXDSLHeader.ADR_PORTE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getPorte());
          record.set(PALFXDSLHeader.ADR_LOGO.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getLogo());
          record.set(PALFXDSLHeader.ADR_ESCALIER.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getEscalier());
          record.set(PALFXDSLHeader.ADR_ETAGE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getEtage());
          record.set(PALFXDSLHeader.ADR_PRE_PROPRIETAIRE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getPrecedentProprietaire());

        }

        if (paLigneFixe.getContexteInstallation() != null)
        {
          record.set(PALFXDSLHeader.INST_ID_MANDAT.getIndex(), paLigneFixe.getContexteInstallation().getIdMandat());
          record.set(PALFXDSLHeader.INST_TYPE_MES.getIndex(), paLigneFixe.getContexteInstallation().getTypeMes());
          record.set(PALFXDSLHeader.INST_DATE_CLIENT.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getContexteInstallation().getDateClient(), DateTimeFormatPattern.yyyy_dash_MM_dash_dd));
          record.set(PALFXDSLHeader.INST_CRENEAU_CLIENT.getIndex(), paLigneFixe.getContexteInstallation().getCreneauClient());
          record.set(PALFXDSLHeader.INST_ID_RDV.getIndex(), paLigneFixe.getContexteInstallation().getIdRdv());
          if (paLigneFixe.getContexteInstallation().getCommentaire() != null)
          {
            record.set(PALFXDSLHeader.INST_COMMENTAIRE.getIndex(), paLigneFixe.getContexteInstallation().getCommentaire().replaceAll("[\r\n]+", " ")); //$NON-NLS-1$//$NON-NLS-2$
          }
          else
          {
            record.set(PALFXDSLHeader.INST_COMMENTAIRE.getIndex(), null);
          }

        }
        record.set(PALFXDSLHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(pa.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
        record.set(PALFXDSLHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(pa.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
        records.add(record);
      }
    }
    return records;
  }

  /**
   * Constructs and configures a new instance of CSVFormat
   *
   * @throws IOException
   *           IOException
   *
   */
  private void initCsvPrinter() throws IOException
  {

    BufferedWriter bf = Files.newBufferedWriter(Paths.get(_fileName)); //bf is closed in method close by CSVPrinter
    CSVFormat csvFormat = CSVFormat.newFormat(CSV_SEPARATOR).withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(PALFXDSLHeader.class);
    _csvPrinter = new CSVPrinter(bf, csvFormat);

  }

  /**
   * Check if a PaTypeLigneFixe is of type XDSL
   *
   * @param paLigneFixe_p
   *          The PaTypeLigneFixe parameter
   * @return true if PaTypeLigneFixe is of type XDSL
   */
  private boolean isPALigneFixeXDSL(PaTypeLigneFixe paLigneFixe_p)
  {
    if (paLigneFixe_p != null)
    {
      if ((paLigneFixe_p.getInfoBrutBssGp() != null) && (paLigneFixe_p.getInfoBrutBssGp().getAccesTechnique() != null))
      {
        if (ACCES_TECHNIQUE_XDSL.equals(paLigneFixe_p.getInfoBrutBssGp().getAccesTechnique().getTechnologieAcces()))
        {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Write in the CSV file the list of records. Each record corresponds to a line.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param record_p
   *          The list of records.
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> record_p)
  {
    try
    {
      _csvPrinter.printRecord(record_p);
      //check if a flush is needed
      if ((++_currentDumpedLines % this._linesToFlush) == 0)
      {
        _csvPrinter.flush();
      }
    }
    catch (IOException e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, e.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, e.getMessage())); //$NON-NLS-1$
    }

  }
}
