/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0378.structs;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PP0378_RequestParameters
{
  /**
   * Execution mode
   */
  private String _modeExecution;

  /**
   * List of NOM_FQDN
   */
  private String _listeNomFqdn;

  /**
   * @return the listeNomFqdn
   */
  public String getListeNomFqdn()
  {
    return _listeNomFqdn;
  }

  /**
   * @return value of modeExecution
   */
  public String getModeExecution()
  {
    return _modeExecution;
  }

  /**
   * @param listeNomFqdn_p
   *          the listeNomFqdn to set
   */
  public void setListeNomFqdn(String listeNomFqdn_p)
  {
    _listeNomFqdn = listeNomFqdn_p;
  }

  /**
   * @param modeExecution_p
   *          The modeExecution to set.
   */
  public void setModeExecution(String modeExecution_p)
  {
    _modeExecution = modeExecution_p;
  }
}
