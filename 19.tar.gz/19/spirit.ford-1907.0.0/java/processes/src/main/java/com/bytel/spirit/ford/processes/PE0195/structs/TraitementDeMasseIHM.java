/*******************************************************************************
* $Id: TraitementDeMasseIHM.java 14226 2018-12-06 15:29:04Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PE0195.structs;

import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.saab.rex.TraitementDeMasse;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author lmerces
 * @version ($Revision: 14226 $ $Date: 2018-12-06 16:29:04 +0100 (jeu. 06 déc. 2018) $)
 */
public class TraitementDeMasseIHM extends TraitementDeMasse
{
  /**
   *
   */
  private static final long serialVersionUID = 4981019384543274133L;
  /**
   * rel attribute
   */
  @SerializedName("links")
  @Expose
  private List<Link> _links;

  /**
   * @param idTraitementDeMasse_p
   *          id traitement de masse
   * @param clientOperateur_p
   *          client operateur
   * @param typeTraitementDeMasse_p
   *          type traitament de masse
   * @param statut_p
   *          statut
   */
  public TraitementDeMasseIHM(String idTraitementDeMasse_p, String clientOperateur_p, String typeTraitementDeMasse_p, String statut_p)
  {
    super(idTraitementDeMasse_p, clientOperateur_p, typeTraitementDeMasse_p, statut_p);
  }

  /**
   * Constructor
   *
   * @param traitementDeMasse_p
   *          traitement de masse
   */
  public TraitementDeMasseIHM(TraitementDeMasse traitementDeMasse_p)
  {
    super(traitementDeMasse_p.getIdTraitementDeMasse(), traitementDeMasse_p.getClientOperateur(), traitementDeMasse_p.getTypeTraitementDeMasse(), traitementDeMasse_p.getStatut());
    this.setDateCreation(traitementDeMasse_p.getDateCreation());
    this.setDateModification(traitementDeMasse_p.getDateModification());
    this.setNbARealiser(traitementDeMasse_p.getNbARealiser());
    this.setNbDeclenches(traitementDeMasse_p.getNbDeclenches());
    this.setNbTermines(traitementDeMasse_p.getNbTermines());
    this.setNomFichierIn(traitementDeMasse_p.getNomFichierIn());
    this.setNomFichierOut(traitementDeMasse_p.getNomFichierOut());
    this.setReconciliationCommercialeEnMasse(traitementDeMasse_p.getReconciliationCommercialeEnMasse());
  }

  /**
   * @return the links
   */
  public List<Link> getLinks()
  {
    return new ArrayList<Link>(_links);
  }

  /**
   * @param links_p
   *          the links to set
   */
  public void setLinks(List<Link> links_p)
  {
    _links = new ArrayList<>(links_p);
  }
}
