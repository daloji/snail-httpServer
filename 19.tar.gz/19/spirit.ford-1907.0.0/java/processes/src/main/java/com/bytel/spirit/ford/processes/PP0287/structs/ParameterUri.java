/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0287.structs;

/**
 * The enum of the uri parameters of PP0287.
 *
 * @author asoares
 * @version ($Revision$ $Date$)
 */
public enum ParameterUri
{
  /**
   * Action
   */
  ACTION,

  /**
   * Periodicite
   */
  PERIODICITE;
}
