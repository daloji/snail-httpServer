/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0378;

import static com.google.common.base.Strings.isNullOrEmpty;
import static java.util.Objects.nonNull;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.cxf.helpers.FileUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier.BL3400_SupprimerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder;
import com.bytel.spirit.common.ford.config.ConfigurationFluxExtraction;
import com.bytel.spirit.common.ford.config.GenericProcessConfig;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0378.structs.PP0378_RequestParameters;
import com.bytel.spirit.ford.processes.PP0378.writers.CompteHssParFqdnWriter;
import com.bytel.spirit.ford.shared.misc.processes.FordProcessSkeleton;
import com.bytel.spirit.ford.shared.misc.processes.writers.IGenericWriter;
import com.bytel.spirit.ford.shared.types.GenericProcessConfigValidator;
import com.bytel.spirit.saab.connectors.air.AIRDatabaseProxy;
import com.bytel.spirit.saab.connectors.air.IIndexRecherchePfiByCleRechercheCallback;
import com.bytel.spirit.saab.connectors.air.IndexRecherchePfiByCleRecherche;
import com.bytel.spirit.saab.connectors.rst.IServiceTechniqueCallback;
import com.bytel.spirit.saab.connectors.rst.RSTDatabaseProxy;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PP0378_ExtractionMigrationAbonnesVIMS extends FordProcessSkeleton<IGenericWriter<ServiceTechnique>, ServiceTechnique> implements IServiceTechniqueCallback, IIndexRecherchePfiByCleRechercheCallback
{
  /**
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  public static final class PP0378_ExtractionMigrationAbonnesVIMSContext extends Context
  {
    /**
     * SerialUID
     */
    private static final long serialVersionUID = 1788320281302297877L;

    /**
     * The flux id
     */
    private String _idFluxExtraction;

    /**
     * The current process state.
     */
    private State _state = State.PP0378_BL001;

    /**
     * The process retour.
     */
    private Retour _processRetour;

    /**
     * Process configuration.
     */
    private transient GenericProcessConfig _configurationPP0378;

    /**
     * ListeNomFqdn
     */
    private String _listeNomFqdn;

    /**
     * ModeExecution
     */
    private String _modeExecution;

    /**
     * Constains the ThreadPoolExecutor.
     */
    private ThreadPoolExecutor _threadPoolExecutor;

    /**
     * Contains the future result of the submitted task for the ThreadPoolExecutor
     */
    private List<Future<Retour>> _threadPoolExecutorResult = Collections.synchronizedList(new ArrayList<>());

    /**
     * Constains the compteMailWriter list.
     */
    private List<IGenericWriter<ServiceTechnique>> _writers = new ArrayList<>(1);

    /**
     * @return the configurationPP0378
     */
    public GenericProcessConfig getConfigurationPP0378()
    {
      return _configurationPP0378;
    }

    /**
     * @return the idFluxExtraction
     */
    public String getIdFluxExtraction()
    {
      return _idFluxExtraction;
    }

    /**
     * @return the listeNomFqdn
     */
    public String getListeNomFqdn()
    {
      return _listeNomFqdn;
    }

    /**
     * @return the modeExecution
     */
    public String getModeExecution()
    {
      return _modeExecution;
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return value of threadPoolExecutor
     */
    public ThreadPoolExecutor getThreadPoolExecutor()
    {
      return _threadPoolExecutor;
    }

    /**
     * @return the writers
     */
    public List<IGenericWriter<ServiceTechnique>> getWriters()
    {
      return new ArrayList<>(_writers);
    }

    /**
     * @param configurationPP0378_p
     *          the configurationPP0378 to set
     */
    public void setConfigurationPP0378(GenericProcessConfig configurationPP0378_p)
    {
      _configurationPP0378 = configurationPP0378_p;
    }

    /**
     * @param idFluxExtraction_p
     *          the idFluxExtraction to set
     */
    public void setIdFluxExtraction(String idFluxExtraction_p)
    {
      _idFluxExtraction = idFluxExtraction_p;
    }

    /**
     * @param listeNomFqdn_p
     *          the listeNomFqdn to set
     */
    public void setListeNomFqdn(String listeNomFqdn_p)
    {
      _listeNomFqdn = listeNomFqdn_p;
    }

    /**
     * @param modeExecution_p
     *          the modeExecution to set
     */
    public void setModeExecution(String modeExecution_p)
    {
      _modeExecution = modeExecution_p;
    }

    /**
     * @param processRetour_p
     *          the processRetour to set
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param threadPoolExecutor_p
     *          The threadPoolExecutor to set.
     */
    public void setThreadPoolExecutor(ThreadPoolExecutor threadPoolExecutor_p)
    {
      _threadPoolExecutor = threadPoolExecutor_p;
    }

    /**
     * @param threadPoolExecutorResult_p
     *          The threadPoolExecutorResult to set.
     */
    public void setThreadPoolExecutorResult(List<Future<Retour>> threadPoolExecutorResult_p)
    {
      _threadPoolExecutorResult = new ArrayList<>(threadPoolExecutorResult_p);
    }

    /**
     * @param writers_p
     *          the writers to set
     */
    public void setWriters(List<IGenericWriter<ServiceTechnique>> writers_p)
    {
      _writers = new ArrayList<>(writers_p);
    }
  }

  /**
   * PP0378 states.
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The next step to execute is: BL001
     */
    PP0378_BL001(MandatoryProcessState.PRC_START),
    /**
     * The next step to execute is: BL100
     */
    PP0378_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL901
     */
    PP0378_BL901(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL902
     */
    PP0378_BL902(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: CALLBACK
     */
    PP0378_CALLBACK(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL910
     */
    PP0378_BL910(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL903
     */
    PP0378_BL903(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL200
     */
    PP0378_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL904
     */
    PP0378_BL904(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PP0378_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }
  }

  /**
   * SerialUID
   */
  private static final long serialVersionUID = 1663960989796339639L;

  /**
   * Url parameter name for listeNomFqdn
   */
  private static final String URL_PARAM_LISTE_NOM_FQDN = "listeNomFqdn"; //$NON-NLS-1$

  /**
   * The MIGRATION_VIMS flux id
   */
  private static final String SPIRIT_MIGRATION_VIMS = "SPIRIT-MIGRATION_VIMS"; //$NON-NLS-1$

  /**
   * The message to present when the ServiceTechnique param is required
   */
  protected static final String MESSAGE_PARAM_LISTE_NOM_FQDN_REQUIRED = Messages.getString("PP0378.ListeNomFqdnisNull"); //$NON-NLS-1$

  /**
   * The process context
   */
  private PP0378_ExtractionMigrationAbonnesVIMSContext _processContext;

  @Override
  public Retour consume(Tracabilite tracabilite_p, IndexRecherchePfiByCleRecherche indexRecherchePfiByCleRecherche_p) throws RavelException
  {
    //Call RST
    return RSTDatabaseProxy.getInstance().getAllActiveStPfsHssFixeByPFI(tracabilite_p, indexRecherchePfiByCleRecherche_p.getClientOperateur(), indexRecherchePfiByCleRecherche_p.getNoCompte(), this).getResult();
  }

  @Override
  public Retour consume(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p) throws RavelException
  {
    // Call BL910
    _processContext.setState(State.PP0378_BL910);
    Retour retourBL910 = BL910_PushIdInExecutor(tracabilite_p, _processContext.getConfigurationPP0378(), serviceTechnique_p, _processContext.getWriters(), _processContext.getThreadPoolExecutor(), _processContext._threadPoolExecutorResult);
    _processContext.setProcessRetour(retourBL910);

    return retourBL910;
  }

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    if (nonNull(retour_p))
    {
      return MarshallTools.marshall(retour_p);
    }
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PP0378_ExtractionMigrationAbonnesVIMSContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, MESSAGE_UNEXPECTED_CONTINUE);
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel
  }

  @Override
  protected Pair<Retour, IGenericWriter<ServiceTechnique>> getWriter(Tracabilite tracabilite_p, String extractionName_p, String filePath_p, String fileName_p, int nbLinesToFlush_p)
  {
    try
    {
      return new Pair<>(RetourFactory.createOkRetour(), new CompteHssParFqdnWriter(filePath_p, fileName_p, nbLinesToFlush_p));
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, fileName_p, e.getMessage())));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, fileName_p, e.getMessage())), null);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      //Call BL001
      _processContext.setState(State.PP0378_BL001);
      Pair<Retour, PP0378_RequestParameters> retourBL001 = PP0378_BL001_VerifierDonnees(request_p);
      _processContext.setProcessRetour(retourBL001._first);

      if (isRetourOK(_processContext.getProcessRetour()))
      {
        _processContext.setModeExecution(retourBL001._second.getModeExecution());
        _processContext.setListeNomFqdn(retourBL001._second.getListeNomFqdn());

        if (PRODUIRE_EXTRACTIONS.equals(_processContext.getModeExecution()))
        {
          //Call BL100
          _processContext.setState(State.PP0378_BL100);
          Retour bl100 = PP0378_BL100_ProduireFichierExtraction(tracabilite_p, _processContext.getListeNomFqdn());
          _processContext.setProcessRetour(bl100);
          if (!isRetourOK(_processContext.getProcessRetour()))
          {
            // if extraction errors, we should erase the previously created files
            deleteAllFilesInWorkPath(tracabilite_p, _processContext.getConfigurationPP0378().getCheminRepTravail(), _processContext.getModeExecution(), _processContext.getConfigurationPP0378().getExtensionFichierTemporaire());
          }
        }
        else
        {
          //Call BL200
          _processContext.setState(State.PP0378_BL200);
          Retour bl200 = PP0378_BL200_TransfererFichier(tracabilite_p);
          _processContext.setProcessRetour(bl200);
        }
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, e.getMessage()));
    }
    finally
    {
      endSynchronousProcess(request_p, _processContext.getProcessRetour());
    }

    // Set Process Retour
    this.setRetour(_processContext.getProcessRetour());
    _processContext.setState(State.PP0378_END);
  }

  /**
   * Extract URL parameters of PP0378
   *
   * @param request_p
   *          the request object
   * @return PP0378_RequestParameters
   */
  private Pair<Retour, PP0378_RequestParameters> getPP0378ParamsFromRequest(Request request_p)
  {
    PP0378_RequestParameters requestParameters = new PP0378_RequestParameters();

    // get url parameters
    List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();

    for (Parameter parametre : urlParametersType)
    {
      if (parametre.getName().equalsIgnoreCase(PARAM_MODE_EXECUTION))
      {
        requestParameters.setModeExecution(parametre.getValue());
      }

      if (parametre.getName().equalsIgnoreCase(URL_PARAM_LISTE_NOM_FQDN))
      {
        requestParameters.setListeNomFqdn(parametre.getValue());
      }
    }

    if (StringTools.isNullOrEmpty(requestParameters.getModeExecution()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_MODE_EXECUTION)), null);
    }
    if (!Arrays.asList(PRODUIRE_EXTRACTIONS, TRANSFERER_FICHIERS).contains(requestParameters.getModeExecution()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_MODE_EXECUTION_PAS_CONNU), null);
    }
    //typeServiceTechnique is required if modeExecution is ProduireExtractions
    if (PRODUIRE_EXTRACTIONS.equals(requestParameters.getModeExecution()) && StringTools.isNullOrEmpty(requestParameters.getListeNomFqdn()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_PARAM_LISTE_NOM_FQDN_REQUIRED), null);
    }

    return new Pair<>(RetourFactory.createOkRetour(), requestParameters);
  }

  /**
   * Verify the input
   *
   * @param request_p
   *          the process request
   *
   * @return Retour
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Pair<Retour, PP0378_RequestParameters> PP0378_BL001_VerifierDonnees(Request request_p) throws RavelException
  {
    //Get url parameters
    Pair<Retour, PP0378_RequestParameters> paramsFromRequest = getPP0378ParamsFromRequest(request_p);
    if (RetourFactory.isRetourNOK(paramsFromRequest._first))
    {
      return new Pair<>(paramsFromRequest._first, null);
    }

    //Load config
    String configPP0378Param = getConfigParameter(PARAM_CONFIG_PATH);
    if (StringTools.isNotNullOrEmpty(configPP0378Param))
    {
      try
      {
        Path configPP0378Path = Paths.get(configPP0378Param);
        String configPP0378File = new String(Files.readAllBytes(configPP0378Path));
        _processContext.setConfigurationPP0378(MarshallTools.unmarshall(GenericProcessConfig.class, configPP0378File));
      }
      catch (Exception e)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_FILE_ERROR, e.getMessage())), null);
      }
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, PARAM_CONFIG_PATH)), null);
    }

    // Check config parameters
    String chaineNomParam = GenericProcessConfigValidator.checkInexistantParams(_processContext.getConfigurationPP0378());
    if (chaineNomParam.length() > 0)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, chaineNomParam)), null);
    }

    // Check flux ids
    String chaineNomFlux = GenericProcessConfigValidator.checkFluxId(_processContext.getConfigurationPP0378(), SPIRIT_MIGRATION_VIMS);
    if (chaineNomFlux.length() > 0)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_UNAUTHORIZED_FLUX_ID, chaineNomFlux)), null);
    }

    ConfigurationFluxExtraction cfgExtraction = _processContext.getConfigurationPP0378().getConfigurationFluxExtraction().get(0);
    if (StringTools.isNullOrEmpty(cfgExtraction.getIdFluxExtraction()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_ID_FLUX_EXTRACTION)), null);
    }
    if (StringTools.isNullOrEmpty(cfgExtraction.getPattern()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_PATTERN)), null);
    }
    if (isNullOrEmpty(cfgExtraction.getChaineConnexion()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_CHAINE_CONNEXION)), null);
    }
    _processContext.setIdFluxExtraction(cfgExtraction.getIdFluxExtraction());

    return new Pair<>(RetourFactory.createOkRetour(), paramsFromRequest._second);
  }

  /**
   * ProduireFichierExtraction.
   *
   * @param listeNomFqdn_p
   *          listeNomFqdn
   * @return Retour
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Retour PP0378_BL100_ProduireFichierExtraction(Tracabilite tracabilite_p, String listeNomFqdn_p) throws RavelException
  {
    try
    {
      // Call BL901
      _processContext.setState(State.PP0378_BL901);
      Pair<Retour, List<IGenericWriter<ServiceTechnique>>> retourBL901 = BL901_InitWriters(tracabilite_p, _processContext.getConfigurationPP0378(), Collections.singletonList(_processContext.getIdFluxExtraction()), PRODUIRE_EXTRACTIONS);
      _processContext.setProcessRetour(retourBL901._first);

      if (RetourFactory.isRetourNOK(retourBL901._first))
      {
        return retourBL901._first;
      }

      // Store writers on context
      _processContext.setWriters(retourBL901._second);

      // Call BL902
      _processContext.setState(State.PP0378_BL902);
      Pair<Retour, ThreadPoolExecutor> retourBL902 = BL902_InitExecutor(tracabilite_p, _processContext.getConfigurationPP0378());
      _processContext.setProcessRetour(retourBL902._first);
      _processContext.setThreadPoolExecutor(retourBL902._second);

      if (RetourFactory.isRetourNOK(retourBL902._first))
      {
        return retourBL902._first;
      }

      // Call AIRDatabaseConnector and, for each result, call RSTDatabaseConnector
      _processContext.setState(State.PP0378_CALLBACK);
      Retour retourAIR = RetourFactory.createOkRetour();
      for (String fqdn : listeNomFqdn_p.split(";")) //$NON-NLS-1$
      {
        retourAIR = AIRDatabaseProxy.getInstance().getAllIndexRecherchePfiByCleRecherche(tracabilite_p, "NOM_FQDN", fqdn, this).getResult(); //$NON-NLS-1$
        _processContext.setProcessRetour(retourAIR);
      }

      // Call BL903
      _processContext.setState(State.PP0378_BL903);
      Retour retourBL903 = BL903_WaitExecutor(tracabilite_p, _processContext.getConfigurationPP0378(), retourBL902._second, _processContext._threadPoolExecutorResult);
      _processContext.setProcessRetour(retourBL903);

      // Check Returns
      if (RetourFactory.isRetourNOK(retourAIR))
      {
        if (IMegSpiritConsts.TIMEOUT.equals(retourAIR.getDiagnostic()))
        {
          return retourAIR;
        }
      }
      else if (RetourFactory.isRetourKO(retourBL903))
      {
        return retourBL903;
      }
    }
    catch (RavelException e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_LECTURE_IMPOSSIBLE);
    }
    finally
    {
      // Call BL904
      _processContext.setState(State.PP0378_BL904);
      BL904_CloseWriters(tracabilite_p, _processContext.getWriters(), _processContext.getConfigurationPP0378().getExtensionFichierTemporaire());
    }
    // Return OK
    return RetourFactory.createOkRetour();
  }

  /**
   * TransfererFichier
   *
   * @return Retour
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Retour PP0378_BL200_TransfererFichier(Tracabilite tracabilite_p) throws RavelException
  {
    GenericProcessConfig configurationPP0378 = _processContext.getConfigurationPP0378();

    String cheminRepTravail = configurationPP0378.getCheminRepTravail();

    for (ConfigurationFluxExtraction cfgExtraction : configurationPP0378.getConfigurationFluxExtraction())
    {
      File directory = new File(cheminRepTravail);
      if (directory.list().length >= 1)
      {
        List<File> files = FileUtils.getFiles(directory, cfgExtraction.getPattern());

        //Process file list
        for (File file : files)
        {
          try
          {
            if (file.getName().endsWith(configurationPP0378.getExtensionFichierTemporaire()))
            {
              LocalDateTime modifiedDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(file.lastModified()), ZoneId.systemDefault());
              LocalDateTime retentionDate = DateTimeManager.getInstance().now().minusSeconds(configurationPP0378.getDureeRetentionTmp());

              // Check date
              if (modifiedDate.isBefore(retentionDate))
              {
                // Call BL3400_SupprimerFichier
                BL3400_SupprimerFichier bl3400 = new BL3400_SupprimerFichierBuilder() //
                    .tracabilite(tracabilite_p) //
                    .fileName(file.getName()) //
                    .repertoire(cheminRepTravail) //
                    .build();
                bl3400.execute(this);
              }
            }
            else
            {
              // Call BL4300_EnvoyerFichier
              BL4300_EnvoyerFichier envoyerFichier = new BL4300_EnvoyerFichierBuilder() //
                  .tracabilite(tracabilite_p) //
                  .chaineConnexion(addFileToURI(cfgExtraction.getChaineConnexion(), file.getName())) //
                  .nomFichier(file.getName()) //
                  .repertoire(cheminRepTravail) //
                  .build();
              envoyerFichier.execute(this);
              Retour bl4300Retour = envoyerFichier.getRetour();

              if (RetourFactory.isRetourNOK(bl4300Retour))
              {
                if (IMegConsts.CAT1.equals(bl4300Retour.getCategorie()))
                {
                  // Call BL1200_DeplacerFichier
                  BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichierBuilder() //
                      .tracabilite(tracabilite_p) //
                      .nomFichier(file.getName()) //
                      .repertoireSrc(configurationPP0378.getCheminRepTravail()) //
                      .repertoireDes(configurationPP0378.getCheminRepArchiveErreur()) //
                      .build();
                  deplacerFichier.execute(this);
                }
                else
                {
                  // Renvoyer Erreur et Sortir du traitement
                  return bl4300Retour;
                }
              }
              else
              {
                // Call BL1200_DeplacerFichier
                BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder() //
                    .tracabilite(tracabilite_p) //
                    .nomFichier(file.getName()) //
                    .repertoireSrc(configurationPP0378.getCheminRepTravail()) //
                    .repertoireDes(configurationPP0378.getCheminRepArchiveSucces()) //
                    .build();
                deplacerFichier.execute(this);
              }
            }
          }
          catch (Exception exception)
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
            return RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage());
          }
        }
      }
    }
    return RetourFactory.createOkRetour();
  }
}
