/*******************************************************************************
* $Id: AirPfiWriter.java 19207 2019-03-28 13:17:54Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.structs;

import static java.util.Objects.nonNull;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0098.generator.INSFWriter;

/**
 *
 * @author pcarreir
 * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
 */
public class AirPfiWriter implements INSFWriter
{
  /**
   * Class containing the PFI entete to write in CSV File.
   *
   * @author jgregori
   * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
   */
  public enum PFIHeader
  {
    /**
     *
     */
    TYPE_CLE(0),

    /**
     *
     */
    VALEUR_CLE(1),

    /**
     *
     */
    CLIENT_OPERATEUR(2),

    /**
     *
     */
    NO_COMPTE(3);

    /**
     * The header size
     */
    static final int PFI_HEADER_SIZE = 4;
    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    PFIHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }

  }

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;

  /**
   * Number of maximum lines to write without performing a flush on the CSV file.
   */
  private int _linesToFlush;
  /**
   * The name of CSV PFI file.
   */
  private String _fileName;

  /**
   * Number of lines dumped in the CSV file.
   */
  private int _currentDumpedLines = 0;

  /**
   * retour
   */
  private Retour _retour;

  /**
   * @param fileName_p
   *          The path to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public AirPfiWriter(String fileName_p, int linesToFlush_p) throws IOException
  {
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    initCsvPrinter();

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PFIWriter.start"))); //$NON-NLS-1$

    List<String> record = this.getRecord(pfi_p, dateDemande_p);
    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }

    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PFIWriter.end"))); //$NON-NLS-1$
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param pfi_p
   *          The PFI
   * @param dateDemande_p
   *          The request date
   *
   * @return List of values
   */
  private List<String> getRecord(PFI pfi_p, LocalDate dateDemande_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[PFIHeader.PFI_HEADER_SIZE]));
    if (nonNull(pfi_p) //
        && "BSS_GP".equals(pfi_p.getClientOperateur()) //$NON-NLS-1$
        && (dateDemande_p.isEqual(pfi_p.getDateCreation().toLocalDate()) //
            || dateDemande_p.isEqual(pfi_p.getDateModification().toLocalDate())))
    {
      record.set(PFIHeader.CLIENT_OPERATEUR.getIndex(), pfi_p.getClientOperateur());
      record.set(PFIHeader.NO_COMPTE.getIndex(), pfi_p.getNoCompte());
      //      record.set(PFIHeader.STATUT.getIndex(), CSVWriterUtils.getCsvValue(pfi_p.getStatut()));
      //      record.set(PFIHeader.LIGNE_MARCHE.getIndex(), pfi_p.getLigneMarche());

      if (pfi_p.getTitulaire() != null)
      {
        //        record.set(PFIHeader.TITULAIRE_TYPE.getIndex(), CSVWriterUtils.getCsvValue(pfi_p.getTitulaire().getTypeTitulaire()));
        //        record.set(PFIHeader.NO_PERSONNE.getIndex(), pfi_p.getTitulaire().getNoPersonne());

        if (pfi_p.getTitulaire().getIndividu() != null)
        {
          //          record.set(PFIHeader.NOM.getIndex(), pfi_p.getTitulaire().getIndividu().getNom());
          //          record.set(PFIHeader.PRENOM.getIndex(), pfi_p.getTitulaire().getIndividu().getPrenom());
        }
        if (pfi_p.getTitulaire().getEntreprise() != null)
        {
          //          record.set(PFIHeader.NO_SIREN.getIndex(), pfi_p.getTitulaire().getEntreprise().getNoSiren());
          //          record.set(PFIHeader.RAISON_SOCIAL.getIndex(), pfi_p.getTitulaire().getEntreprise().getRaisonSociale());
        }
      }
      //      record.set(PFIHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(pfi_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
      //      record.set(PFIHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(pfi_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
      return record;
    }
    return Collections.emptyList();
  }

  /**
   * Constructs and configures a new instance of CSVFormat
   *
   * @throws IOException
   *           IOException
   *
   */
  private void initCsvPrinter() throws IOException
  {

    BufferedWriter bf = Files.newBufferedWriter(Paths.get(_fileName)); //bf is closed in method close by CSVPrinter
    CSVFormat csvFormat = CSVFormat.newFormat(CSV_SEPARATOR).withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(PFIHeader.class);
    _csvPrinter = new CSVPrinter(bf, csvFormat);

  }

  /**
   * Write in the CSV file the list of records. Each record corresponds to a line.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param record_p
   *          The list of records.
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> record_p)
  {
    try
    {
      _csvPrinter.printRecord(record_p);
      //check if a flush is needed
      if ((++_currentDumpedLines % this._linesToFlush) == 0)
      {
        _csvPrinter.flush();
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }
}
