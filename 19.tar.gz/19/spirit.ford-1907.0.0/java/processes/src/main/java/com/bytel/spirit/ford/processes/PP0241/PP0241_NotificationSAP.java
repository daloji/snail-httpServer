/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0241;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.csv.CSVFileWriter;
import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier;
import com.bytel.spirit.common.activities.shared.BL1300_CreerFichier.BL1300_CreerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL900_ObtenirConfigurationEmissionFichier;
import com.bytel.spirit.common.activities.shared.BL900_ObtenirConfigurationEmissionFichier.BL900_ObtenirConfigurationEmissionFichierBuilder;
import com.bytel.spirit.common.activities.shared.structs.ConfigurationEmission;
import com.bytel.spirit.common.connectors.gdr.GDRProxy;
import com.bytel.spirit.common.connectors.gdr.structs.BYTPRD;
import com.bytel.spirit.common.connectors.gdr.structs.CMDSIM;
import com.bytel.spirit.common.connectors.gdr.structs.SUIVISMDP;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0241.structs.CommandeESim;
import com.google.gson.Gson;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class PP0241_NotificationSAP extends SpiritRestApiProcessSkeleton
{

  /**
   *
   * @author jramos
   * @version ($Revision$ $Date$)
   */
  public static class PP0241_NotificationSAPContext extends Context

  {
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 3598954964508785069L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    State _state = State.START;

    /**
     * List de CMDSIM
     */
    List<CMDSIM> _listCMDSIM = new ArrayList<CMDSIM>();

    /**
     * List de CommandeESim
     */
    List<CommandeESim> _listCommandeESim = new ArrayList<CommandeESim>();

    /**
     * The configuration file
     */
    String _fichierDeConfiguration;

    /**
     * Map (IDTCMD, QTD)
     */
    Map<Long, Long> _mapIdtCmdQtd;

  }

  /**
   *
   * @author jramos
   * @version ($Revision$ $Date$)
   */
  private enum State
  {
    /**
     * The next step to execute is: PM001_MiseADispositionSIM_StartProcess.
     */
    START(MandatoryProcessState.PRC_START),
    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP),

    /**
     * BL100
     */
    PP0241_BL100(MandatoryProcessState.PRC_START),

    /**
     * BL1300
     */
    PP0241_BL1300(MandatoryProcessState.PRC_START),

    /**
     * BL1400
     */
    PP0241_BL1400(MandatoryProcessState.PRC_START),

    /**
     * BL002
     */
    PP0241_BL002(MandatoryProcessState.PRC_START);
    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * Default constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    private State(MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * Item Header of CSV File
   */
  static final String QUANTITE = "Quantite"; //$NON-NLS-1$

  /**
   * Item Header of CSV File
   */
  static final String CODE_ARTICLE_SAP = "CodeArticleSap"; //$NON-NLS-1$

  /**
   * Item Header of CSV File
   */
  static final String ID_CMD_SAP = "IdCmdSap"; //$NON-NLS-1$

  /**
   *
   */
  static final long serialVersionUID = 1L;

  /**
   * NAME OF FILE
   */
  static final String NOM_FICHIER = "RECEPTION_SPIRIT_{0}.csv"; //$NON-NLS-1$

  /**
   * FICHIER_DE_CONFIGURATION
   */
  static final String FICHIER_DE_CONFIGURATION = "fichierConfiguration"; //$NON-NLS-1$

  /**
   * NOTIFICATION_SAP
   */
  static final String NOTIFICATION_SAP = "NOTIFICATION_SAP"; //$NON-NLS-1$

  /**
   * Type de NotificationSAP Partiel
   */

  static final String PARTIEL = "partiel"; //$NON-NLS-1$

  /**
   * Type de NotificationSAP Complet
   */
  static final String COMPLET = "complet"; //$NON-NLS-1$

  /**
   * The process' context.
   */
  private PP0241_NotificationSAPContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return MarshallTools.marshall(retour_p);
  }

  @Override
  public String getInternalState()
  {
    return _processContext._state.toString();
  }

  /**
   * @return the processContext
   */
  public PP0241_NotificationSAPContext getProcessContext()
  {
    return _processContext;
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ZERO;
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext._state._technicalState;
  }

  @Override
  public void initializeContext()
  {
    // Initialization of the context cannot be done in the constructor
    // because
    // processes are allocated only at startup and cloned when a new process
    // is expected.
    _processContext = new PP0241_NotificationSAPContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext._state._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext._state._replayableState;
  }

  @LogContinueProcess
  @Override
  protected void continueGetProcess(Tracabilite tracabilite_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, Messages.getString("PP0241_NotificationSAP.UNEXPECTED_CONTINUEPROCESS_RECEIVED")); //$NON-NLS-1$
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // TODO Auto-generated method stub

  }

  /**
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @throws RavelException
   *           Ravel
   */
  protected void handlePostRequest(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {

    Pair<List<CommandeESim>, Retour> retourBl100;

    Retour retour = getProcessConfigParameters(tracabilite_p);

    if (isRetourOK(retour))
    {
      retourBl100 = PP0241_BL100_DeterminerIccid(tracabilite_p);
      retour = retourBl100._second;

      // BL100 Return list of IccidEligible
      if (isRetourOK(retourBl100._second) && !retourBl100._first.isEmpty())
      {
        // Create file
        retour = traitementFichier(tracabilite_p);
      }
    }

    PP0241_BL002_FormaterReponse(request_p, retour);
  }

  @Override
  protected void startMetroLog()
  {
    // TODO Auto-generated method stub
  }

  @LogStartProcess
  @Override
  protected void startPostProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, "STARTPROCESS")); //$NON-NLS-1$

    try
    {
      handlePostRequest(request_p, tracabilite_p);
    }
    finally
    {
      _processContext._state = State.ENDED;
    }
  }

  /**
   * Get configuration parameters
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   *
   * @return {@link Retour}
   */
  @LogProcessBL
  private Retour getProcessConfigParameters(Tracabilite tracabilite_p)
  {
    Retour retour = RetourFactory.createOkRetour();

    String fichierDeConfiguration = getConfigParameter(FICHIER_DE_CONFIGURATION);

    if (StringTools.isNotNullOrEmpty(fichierDeConfiguration))
    {
      _processContext._fichierDeConfiguration = getConfigParameter(FICHIER_DE_CONFIGURATION);
    }
    else
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0241_NotificationSAP.ENTREE_INCORRECTE"), FICHIER_DE_CONFIGURATION)); //$NON-NLS-1$

      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(Messages.getString("PP0241_NotificationSAP.ENTREE_INCORRECTE"), FICHIER_DE_CONFIGURATION))); //$NON-NLS-1$
    }

    return retour;
  }

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @return Retour
   * @throws RavelException
   *           Exception
   */
  private Retour miseajourCMDSIM(Tracabilite tracabilite_p) throws RavelException
  {

    SpiritLogEvent system = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PP0241_NotificationSAP.MESSAGE_MISEAJOUR_CMDSIM")); //$NON-NLS-1$
    RavelLogger.log(system);

    Retour retour = RetourFactory.createOkRetour();
    ConnectorResponse<Nothing, Retour> retourps023;
    Long quantite;

    for (CMDSIM itemidentifiantCommande : _processContext._listCMDSIM)
    {

      quantite = _processContext._mapIdtCmdQtd.get(itemidentifiantCommande.getIdtCMD());
      if (quantite != null)
      {

        if (itemidentifiantCommande.getQteCMD() > quantite)
        {
          retourps023 = GDRProxy.getInstance().ps023UpdateEnvoiCmdSim(tracabilite_p, itemidentifiantCommande.getIdtCMD().toString(), PARTIEL);
          retour = retourps023._second;
        }
        if (quantite.equals(itemidentifiantCommande.getQteCMD()))
        {
          retourps023 = GDRProxy.getInstance().ps023UpdateEnvoiCmdSim(tracabilite_p, itemidentifiantCommande.getIdtCMD().toString(), COMPLET);
          retour = retourps023._second;
        }
      }
    }
    return retour;

  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          request
   * @param retour
   *          retour
   *
   */
  @LogProcessBL
  private void PP0241_BL002_FormaterReponse(Request request_p, Retour retour)
  {
    _processContext._state = State.PP0241_BL002;

    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response response = null;
      ravelResponse.setDataType(MediaType.APPLICATION_JSON);

      if (StringConstants.OK.equals(retour.getResultat()))
      {
        response = new Response(ErrorCode.OK_00204, ravelResponse);

      }
      else
      {
        if (IMegConsts.DONNEE_INVALIDE.equals(retour.getDiagnostic()))
        {
          response = new Response(ErrorCode.KO_00400, ravelResponse);
        }
        if (IMegConsts.CAT1.equals(retour.getCategorie()))
        {
          response = new Response(ErrorCode.KO_00500, ravelResponse);
        }

        ravelResponse.setResult(new Gson().toJson(retour));
      }
      request_p.setResponse(response);
    }
  }

  /**
   * Create list of CommandeESim from consulting the database
   *
   * @param tracabilite_p
   *          tracabilite_p
   * @return Pair List CommandeEsim Retour
   */
  private Pair<List<CommandeESim>, Retour> PP0241_BL100_DeterminerIccid(Tracabilite tracabilite_p)
  {
    _processContext._state = State.PP0241_BL100;

    Pair<List<CommandeESim>, Retour> retourBl100 = new Pair<>(null, RetourFactory.createOkRetour());
    CommandeESim commandeTemp;
    List<CommandeESim> listCommandeESim = new ArrayList<>();

    ConnectorResponse<List<CMDSIM>, Retour> listidentifiantCommande;
    ConnectorResponse<List<BYTPRD>, Retour> listBYTPRD;
    ConnectorResponse<List<SUIVISMDP>, Retour> listSuiviSMDP;

    Map<Long, Long> idtcmdQtdMap = new HashMap<>();

    try
    {
      // CALL GDRPROXY.ps021
      listidentifiantCommande = GDRProxy.getInstance().ps021GetCommandesNonNotifies(tracabilite_p);

      // Save the list of CMDSIM for using in Update of table CMDSIM
      _processContext._listCMDSIM = listidentifiantCommande._first;
      long quantite;

      for (CMDSIM itemidentifiantCommande : listidentifiantCommande._first)
      {
        quantite = 0;

        // CALL GDRPROXY.ps025
        listSuiviSMDP = GDRProxy.getInstance().ps025GetSUIVISMDP(tracabilite_p, itemidentifiantCommande.getIdtCMD().toString());

        // IF LIST SUIVISMDP IS NOT EMPTY
        if (!listSuiviSMDP._first.isEmpty())
        {

          for (SUIVISMDP itemSUIVISMSP : listSuiviSMDP._first)
          {
            quantite += itemSUIVISMSP.getQuantite();
            // CALL GDRPROXY.ps024
            listBYTPRD = GDRProxy.getInstance().ps024GetBytprd(tracabilite_p, itemidentifiantCommande.getGnc().toString());

            for (BYTPRD itemBYTPRD : listBYTPRD._first)
            {
              commandeTemp = new CommandeESim();
              commandeTemp.setIdCmdSap(itemidentifiantCommande.getNumCMDSAP());
              commandeTemp.setQuantite(itemSUIVISMSP.getQuantite());
              commandeTemp.setCodeArticleSap(itemBYTPRD.getCodARTSAP());
              listCommandeESim.add(commandeTemp);
            }
          }
          idtcmdQtdMap.put(itemidentifiantCommande.getIdtCMD(), quantite);
        }
      }
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception.getMessage()));
      retourBl100._second = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.MISE_A_JOUR_INDISPONIBLE, Messages.getString("PP0241_NotificationSAP.CONSULTATION_INVALIDE")); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PP0241_NotificationSAP.CONSULTATION_INVALIDE"))); //$NON-NLS-1$
      retourBl100._first = listCommandeESim;
      return retourBl100;
    }
    _processContext._mapIdtCmdQtd = idtcmdQtdMap;
    _processContext._listCommandeESim = listCommandeESim;
    retourBl100._first = listCommandeESim;
    return retourBl100;
  }

  /**
   * Save the list of CommandeSim in the created file
   *
   * @param tracabilite_p
   *          tracabilite_p
   * @param file_p
   *          file
   * @return Retour
   * @throws RavelException
   *           Exception
   */
  private Retour saveObjectsdansFichier(Tracabilite tracabilite_p, String file_p) throws RavelException
  {

    SpiritLogEvent system = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PP0241_NotificationSAP.MESSAGE_SAVEOBJECT_FICHIER")); //$NON-NLS-1$
    RavelLogger.log(system);

    CSVLine body;

    Retour retour = RetourFactory.createOkRetour();

    Path path = Paths.get(file_p);

    CSVFileWriter writer;
    try
    {
      writer = new CSVFileWriter(path.toFile());

      StringBuilder headers = new StringBuilder();
      headers.append(ID_CMD_SAP).append(StringConstants.SEMICOLON_SEPARATOR).append(CODE_ARTICLE_SAP).append(StringConstants.SEMICOLON_SEPARATOR).append(QUANTITE).append(StringConstants.WINDOWS_NEW_LINE);

      CSVLine header = new CSVLine(headers.toString());
      writer.append(header);
      StringBuilder values;

      for (CommandeESim item : _processContext._listCommandeESim)
      {
        values = new StringBuilder();
        if (StringTools.isNotNullOrEmpty(item.getIdCmdSap()))
        {
          values.append(item.getIdCmdSap());
        }
        values.append(StringConstants.SEMICOLON_SEPARATOR);

        if (StringTools.isNotNullOrEmpty(item.getCodeArticleSap()))
        {
          values.append(item.getCodeArticleSap());
        }
        values.append(StringConstants.SEMICOLON_SEPARATOR);
        values.append(item.getQuantite()).append(StringConstants.WINDOWS_NEW_LINE);

        body = new CSVLine(values.toString());
        writer.append(body);
      }
      writer.flush();
      writer.close();
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception.getMessage()));

      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, file_p);
    }
    return retour;
  }

  /**
   * Creation of file and save the list of listCommmandeESim in file if the list is not empty
   *
   * @param tracabilite_p
   *          tracabilite
   * @return Retour
   * @throws RavelException
   *           Exception
   */
  private Retour traitementFichier(Tracabilite tracabilite_p) throws RavelException
  {
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PP0241_NotificationSAP.MESSAGE_TRAITEMENT_FICHIER"))); //$NON-NLS-1$

    // Create File
    String date = DateTimeFormatPattern.yyyyMMddHHmmss.format(DateTimeManager.getInstance().now());
    String filename = MessageFormat.format(NOM_FICHIER, date);

    //GET Configuration
    BL900_ObtenirConfigurationEmissionFichier bl900 = new BL900_ObtenirConfigurationEmissionFichierBuilder().tracabilite(tracabilite_p).codeFlux(NOTIFICATION_SAP).configurationFile(_processContext._fichierDeConfiguration).typeFichier(NOTIFICATION_SAP).build();
    ConfigurationEmission configurationEmission = bl900.execute(this);
    Retour retour = bl900.getRetour();

    // If Get Configuration OK
    if (RetourFactory.isRetourOK(bl900.getRetour()))
    {

      BL1300_CreerFichier bl1300 = new BL1300_CreerFichierBuilder().tracabilite(tracabilite_p).nomFichier(filename).repertoire(configurationEmission.getRepertoireTemp()).build();
      bl1300.execute(this);
      retour = bl1300.getRetour();
      // If creation file Ok

      if (RetourFactory.isRetourOK(bl1300.getRetour()))
      {
        // Save the list of Object in file
        saveObjectsdansFichier(tracabilite_p, configurationEmission.getRepertoireTemp().concat("/").concat(filename)); //$NON-NLS-1$
        // Update the state of ENVOINOTIFICATIONSAP in table CMDSIM
        miseajourCMDSIM(tracabilite_p);

        // Send the output file
        BL4300_EnvoyerFichier bl4300 = new BL4300_EnvoyerFichierBuilder().tracabilite(tracabilite_p).chaineConnexion(configurationEmission.getChaineConnexion()).repertoire(configurationEmission.getRepertoireTemp()).nomFichier(filename).build();
        bl4300.execute(this);
        retour = bl4300.getRetour();

        //Resgister in Database the file sended if send file was sucesseded
        if (RetourFactory.isRetourOK(retour))
        {
          // deplacement fichier ok
          BL1200_DeplacerFichier bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(filename).repertoireSrc(configurationEmission.getRepertoireTemp()).repertoireDes(configurationEmission.getRepertoireTraite()).build();
          bl1200.execute(this);
          retour = bl1200.getRetour();

          // connexion GDR
          for (CMDSIM itemidentifiantCommande : _processContext._listCMDSIM)
          {
            ConnectorResponse<Nothing, Retour> retourps026 = GDRProxy.getInstance().ps026EnregistrerEnvoiFichier(tracabilite_p, itemidentifiantCommande.getIdtCMD().toString(), filename);
            if (!RetourFactory.isRetourOK(retourps026._second))
            {
              String message = new StringBuilder().append("IDTCMD:").append(itemidentifiantCommande.getIdtCMD()).append("NOMFICHEIR:").append(filename).toString(); //$NON-NLS-1$ //$NON-NLS-2$
              RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, message));
            }
          }
        }
        else
        {
          // deplacement fichier echec
          BL1200_DeplacerFichier bl1200 = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(filename).repertoireSrc(configurationEmission.getRepertoireTemp()).repertoireDes(configurationEmission.getRepertoireEchec()).build();
          bl1200.execute(this);
        }
      }
    }
    return retour;
  }
}
