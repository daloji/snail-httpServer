/*******************************************************************************
* $Id: StPfsClfWriter.java 18813 2019-03-21 09:58:12Z lchanyip $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static java.util.Objects.nonNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.clf.StPfsClf;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author pcarreir
 * @version ($Revision: 18813 $ $Date: 2019-03-21 10:58:12 +0100 (jeu. 21 mars 2019) $)
 */
public class StPfsClfWriter extends STWriter
{
  /**
   * Class containing the StLienAllocationCommercial entete to write in CSV File.
   *
   * @author pcarreir
   * @version ($Revision: 18813 $ $Date: 2019-03-21 10:58:12 +0100 (jeu. 21 mars 2019) $)
   */
  public enum StPfsClfHeader
  {
    /**
     *
     */
    ID_ST(0),

    /**
     *
     */
    STATUT(1),

    /**
     *
     */
    COMMENTAIRE(2),

    /**
     *
     */
    CLIENT_OPERATEUR(3),

    /**
     *
     */
    NO_COMPTE(4),

    /**
     *
     */
    ID_PA(5),

    /**
     *
     */
    IMPI_FIXE(6),

    /**
     *
     */
    CODE_INSEE(7),

    /**
     *
     */
    DATE_CREATION(8),

    /**
     *
     */
    DATE_MODIFICATION(9);

    /**
     * The header size
     */
    static final int ST_PFS_CLF_HEADER_SIZE = 10;

    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    StPfsClfHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public StPfsClfWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    super(filePath_p, fileName_p, linesToFlush_p);
    createFile(filePath_p + fileName_p, StPfsClfHeader.class);
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique objectToWrite_p)
  {
    if (shouldExecuteDump(objectToWrite_p))
    {
      executeDumpAction(tracabilite_p, objectToWrite_p);
    }
  }

  @Override
  protected void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    StPfsGenerique stPfsGenerique = StPfsGenerique.class.cast(serviceTechnique_p);
    StPfsClf stPfsClf = deserializeRawFields(tracabilite_p, stPfsGenerique);//because of raw json fields from SAAB
    List<String> record = this.getRecord(stPfsClf);

    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }
  }

  @Override
  protected boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p)
  {
    if (serviceTechnique_p != null)
    {
      if (TypeST.PFS.name().equals(serviceTechnique_p.getTypeServiceTechnique()))
      {
        return TypePFS.CLF.name().equals(StPfsGenerique.class.cast(serviceTechnique_p).getTypePfs());
      }
    }
    return false;
  }

  /**
   * Convert an instance of StPfsGenerique object (having json raw fields) to an instance of StPfsClf.
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @param stPfsGenerique_p
   *          Instance of StPfsGenerique
   * @return An instance of StPfsClf if deserialization succeeds, null otherwise.
   */
  private StPfsClf deserializeRawFields(Tracabilite tracabilite_p, StPfsGenerique stPfsGenerique_p)
  {
    StPfsClf stPfsClf = null;
    try
    {
      stPfsClf = stPfsGenerique_p != null ? StPfsClf.buildFromStPfsGenerique(stPfsGenerique_p) : null;
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
    }
    return stPfsClf;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param stPfsClf_p
   *          The ServiceTechnique
   *
   * @return List of values
   */
  private List<String> getRecord(StPfsClf stPfsClf_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[StPfsClfHeader.ST_PFS_CLF_HEADER_SIZE]));

    if (nonNull(stPfsClf_p))
    {
      record.set(StPfsClfHeader.ID_ST.getIndex(), stPfsClf_p.getIdSt());
      record.set(StPfsClfHeader.STATUT.getIndex(), stPfsClf_p.getStatut());
      record.set(StPfsClfHeader.COMMENTAIRE.getIndex(), stPfsClf_p.getCommentaire());
      record.set(StPfsClfHeader.CLIENT_OPERATEUR.getIndex(), stPfsClf_p.getClientOperateur());
      record.set(StPfsClfHeader.NO_COMPTE.getIndex(), stPfsClf_p.getNoCompte());

      if (stPfsClf_p.getDonneesIdentificationStPfsClf() != null)
      {
        record.set(StPfsClfHeader.ID_PA.getIndex(), stPfsClf_p.getDonneesIdentificationStPfsClf().getIdentifiantFonctionnelPa());
      }

      if (stPfsClf_p.getDonneesProvisionneesStPfsClf() != null)
      {
        record.set(StPfsClfHeader.IMPI_FIXE.getIndex(), stPfsClf_p.getDonneesProvisionneesStPfsClf().getImpiFixe());
        record.set(StPfsClfHeader.CODE_INSEE.getIndex(), stPfsClf_p.getDonneesProvisionneesStPfsClf().getCodeInsee());
      }

      record.set(StPfsClfHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsClf_p.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
      record.set(StPfsClfHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(stPfsClf_p.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
      return record;
    }

    return Collections.emptyList();
  }
}
