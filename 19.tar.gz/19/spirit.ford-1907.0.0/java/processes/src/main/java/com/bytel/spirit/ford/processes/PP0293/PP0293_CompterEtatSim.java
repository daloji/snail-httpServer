package com.bytel.spirit.ford.processes.PP0293;

/*******************************************************************************
* $Id: PP0293_CompterEtatSim.java 18548 2019-03-13 15:36:54Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.MediaType;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.connectors.gdr.GDRProxy;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.Messages;
import com.google.gson.Gson;

/**
 *
 * @author rrosa
 * @version ($Revision: 18548 $ $Date: 2019-03-13 16:36:54 +0100 (mer. 13 mars 2019) $)
 */
public class PP0293_CompterEtatSim extends SpiritRestApiProcessSkeleton
{

  /**
   *
   * @author rrosa
   * @version ($Revision: 18548 $ $Date: 2019-03-13 16:36:54 +0100 (mer. 13 mars 2019) $)
   */
  public static class PP0293_CompterEtatSimContext extends Context
  {
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 3598952252508127069L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    State _state = State.START;

    /**
     * List of peConsumer
     */
    List<Integer> _listPeConsumer = null;

    /**
     * List of peM2M
     */
    List<Integer> _listPeM2M = null;

  }

  /**
   *
   * @author rrosa
   * @version ($Revision: 18548 $ $Date: 2019-03-13 16:36:54 +0100 (mer. 13 mars 2019) $)
   */
  private enum State
  {
    /**
     * The next step to execute is: BL001_CtrlDonneesEntree.
     */
    START(MandatoryProcessState.PRC_START),
    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP),

    /**
     * BL100
     */
    PP0293_BL001(MandatoryProcessState.PRC_START),

    /**
     * BL002
     */
    PP0293_BL002(MandatoryProcessState.PRC_START);
    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * Default constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    private State(MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = -2572461166876099280L;

  /**
   * Configuration parameter PE_Consumer.
   */
  public static final String PE_CONSUMER = "PE_Consumer"; //$NON-NLS-1$

  /**
   * Configuration parameter PE_M2M.
   */
  public static final String PE_M2M = "PE_M2M"; //$NON-NLS-1$

  /**
   * Regex parameter used to load process parameter
   */
  public static final String REGEX = ","; //$NON-NLS-1$

  /**
   * The process context.
   */
  private PP0293_CompterEtatSimContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return MarshallTools.marshall(retour_p);
  }

  @Override
  public String getInternalState()
  {
    return _processContext._state.toString();
  }

  /**
   * @return the processContext
   */
  public PP0293_CompterEtatSimContext getProcessContext()
  {
    return _processContext;
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ZERO;
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext._state._technicalState;
  }

  @Override
  public void initializeContext()
  {
    // Initialization of the context cannot be done in the constructor
    // because
    // processes are allocated only at startup and cloned when a new process
    // is expected.
    _processContext = new PP0293_CompterEtatSimContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext._state._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext._state._replayableState;
  }

  @LogContinueProcess
  @Override
  protected void continueGetProcess(Tracabilite tracabilite_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, Messages.getString("PP0241NotificationSAP.UNEXPECTED_CONTINUEPROCESS_RECEIVED")); //$NON-NLS-1$
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // TODO Auto-generated method stub

  }

  /**
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @throws RavelException
   *           Ravel
   */
  protected void handlePostRequest(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = PP0293_BL001_CtrlDonneesEntree(tracabilite_p);

    if (isRetourOK(retour))
    {
      ConnectorResponse<Nothing, Retour> resp = GDRProxy.getInstance().compterEtatESim(tracabilite_p, _processContext._listPeConsumer, _processContext._listPeM2M);
      retour = resp._second;
    }

    PP0293_BL002_FormaterReponse(request_p, retour);
  }

  @Override
  protected void startMetroLog()
  {
    // TODO Auto-generated method stub

  }

  @LogStartProcess
  @Override
  protected void startPostProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, "STARTPROCESS")); //$NON-NLS-1$

    try
    {
      handlePostRequest(request_p, tracabilite_p);
    }
    finally
    {
      _processContext._state = State.ENDED;
    }
  }

  /**
   * Check cardinality of the data in entry.
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   *
   * @return {@link Retour}
   */
  @LogProcessBL
  private Retour PP0293_BL001_CtrlDonneesEntree(Tracabilite tracabilite_p)
  {
    _processContext._listPeConsumer = new ArrayList<>();
    _processContext._listPeM2M = new ArrayList<>();

    Retour retour = RetourFactory.createOkRetour();

    String stringListPeConsumer = getConfigParameter(PE_CONSUMER);
    String stringListPeM2M = getConfigParameter(PE_M2M);

    if (StringTools.isNotNullOrEmpty(stringListPeConsumer))
    {
      Integer peConsumer = null;
      String[] list = stringListPeConsumer.split(REGEX);
      for (String stringPeConsumer : Arrays.asList(list))
      {
        try
        {
          peConsumer = Integer.valueOf(stringPeConsumer);
          _processContext._listPeConsumer.add(peConsumer);
        }
        catch (NumberFormatException e)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e.getMessage()));
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, Messages.getString("PP0293_compterEtatSim.CONFNOTDEFINED")); //$NON-NLS-1$
          return retour;
        }
      }
    }

    if (StringTools.isNotNullOrEmpty(stringListPeM2M))
    {
      Integer peM2M = null;
      String[] list = stringListPeM2M.split(REGEX);
      for (String stringPeM2M : Arrays.asList(list))
      {
        try
        {
          peM2M = Integer.valueOf(stringPeM2M);
          _processContext._listPeM2M.add(peM2M);
        }
        catch (NumberFormatException e)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e.getMessage()));
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, Messages.getString("PP0293_compterEtatSim.CONFNOTDEFINED")); //$NON-NLS-1$
          return retour;
        }
      }
    }

    if (_processContext._listPeConsumer.isEmpty() && _processContext._listPeM2M.isEmpty())
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, Messages.getString("PP0293_compterEtatSim.CONFNOTDEFINED")); //$NON-NLS-1$
    }

    return retour;
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          request
   * @param retour
   *          retour
   *
   */
  @LogProcessBL
  private void PP0293_BL002_FormaterReponse(Request request_p, Retour retour)
  {
    _processContext._state = State.PP0293_BL002;

    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response response = null;
      ravelResponse.setDataType(MediaType.APPLICATION_JSON);

      if (StringConstants.OK.equals(retour.getResultat()))
      {
        response = new Response(ErrorCode.OK_00204, ravelResponse);
      }
      else
      {
        if (IMegConsts.DONNEE_INVALIDE.equals(retour.getDiagnostic()))
        {
          response = new Response(ErrorCode.KO_00400, ravelResponse);
        }
        if (IMegConsts.CAT1.equals(retour.getCategorie()))
        {
          response = new Response(ErrorCode.KO_00500, ravelResponse);
        }
      }

      ravelResponse.setResult(new Gson().toJson(retour));
      request_p.setResponse(response);
    }
  }
}
