/*******************************************************************************
* $Id: Consts.java 3183 2017-12-28 17:59:20Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.structs;

/**
 *
 * @author pcarreir
 * @version ($Revision: 3183 $ $Date: 2017-12-28 18:59:20 +0100 (jeu. 28 déc. 2017) $)
 */
public final class Consts
{

  /**
   * The BSS_GP constant
   */
  public static final String BSS_GP = "BSS_GP"; //$NON-NLS-1$

  /**
   * The TV constant
   */
  public static final String TV = "TV"; //$NON-NLS-1$

  /**
   * The BRANCHEMENT_OPTIQUE constant
   */
  public static final String BRANCHEMENT_OPTIQUE = "BRANCHEMENT_OPTIQUE"; //$NON-NLS-1$

  /**
   * The MODEM constant
   */
  public static final String MODEM = "MODEM"; //$NON-NLS-1$

  /**
   *
   */
  private Consts()
  {
  }
}
