/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.structs;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class FichierAIntegrer implements Serializable
{

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = 6607572628538705340L;

  /**
   * typeFichier
   */
  @SerializedName("typeFichier")
  @Expose
  private String _typeFichier;

  /**
   * fichierNom
   */
  @SerializedName("fichierNom")
  @Expose
  private String _fichierNom;

  /**
   * File generation date
   */
  @SerializedName("date")
  @Expose
  private LocalDateTime _date;

  /**
   * File index
   */
  @SerializedName("index")
  @Expose
  private Integer _index;

  /**
   * Number of lines in file
   */
  @SerializedName("nbLignes")
  @Expose
  private Integer _nbLignes;

  /**
   * Number of lines KO in file
   */
  @SerializedName("nbLignesKO")
  @Expose
  private Integer _nbLignesKO;

  /**
   * Line delta compared to the active version
   */
  @SerializedName("deltaDeLigne")
  @Expose
  private Integer _deltaDeLigne;

  /**
   * Nb Ligne referentiel
   */
  private transient Integer _nbLigneRef;

  /**
   *
   */
  public FichierAIntegrer()
  {
    super();
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    FichierAIntegrer other = (FichierAIntegrer) obj;
    if (_date == null)
    {
      if (other._date != null)
      {
        return false;
      }
    }
    else if (!_date.equals(other._date))
    {
      return false;
    }
    if (_deltaDeLigne == null)
    {
      if (other._deltaDeLigne != null)
      {
        return false;
      }
    }
    else if (!_deltaDeLigne.equals(other._deltaDeLigne))
    {
      return false;
    }
    if (_fichierNom == null)
    {
      if (other._fichierNom != null)
      {
        return false;
      }
    }
    else if (!_fichierNom.equals(other._fichierNom))
    {
      return false;
    }
    if (_index == null)
    {
      if (other._index != null)
      {
        return false;
      }
    }
    else if (!_index.equals(other._index))
    {
      return false;
    }
    if (_nbLignes == null)
    {
      if (other._nbLignes != null)
      {
        return false;
      }
    }
    else if (!_nbLignes.equals(other._nbLignes))
    {
      return false;
    }
    if (_nbLignesKO == null)
    {
      if (other._nbLignesKO != null)
      {
        return false;
      }
    }
    else if (!_nbLignesKO.equals(other._nbLignesKO))
    {
      return false;
    }
    if (_typeFichier == null)
    {
      if (other._typeFichier != null)
      {
        return false;
      }
    }
    else if (!_typeFichier.equals(other._typeFichier))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the date
   */
  public LocalDateTime getDate()
  {
    return _date;
  }

  /**
   * @return the deltaDeLigne
   */
  public Integer getDeltaDeLigne()
  {
    return _deltaDeLigne;
  }

  /**
   * @return the fichierNom
   */
  public String getFichierNom()
  {
    return _fichierNom;
  }

  /**
   * @return the index
   */
  public Integer getIndex()
  {
    return _index;
  }

  /**
   * @return the nbLigneRef
   */
  public Integer getNbLigneRef()
  {
    return _nbLigneRef;
  }

  /**
   * @return the nbLignes
   */
  public Integer getNbLignes()
  {
    return _nbLignes;
  }

  /**
   * @return the nbLignesKO
   */
  public Integer getNbLignesKO()
  {
    return _nbLignesKO;
  }

  /**
   * @return the typeFichier
   */
  public String getTypeFichier()
  {
    return _typeFichier;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_date == null) ? 0 : _date.hashCode());
    result = (prime * result) + ((_deltaDeLigne == null) ? 0 : _deltaDeLigne.hashCode());
    result = (prime * result) + ((_fichierNom == null) ? 0 : _fichierNom.hashCode());
    result = (prime * result) + ((_index == null) ? 0 : _index.hashCode());
    result = (prime * result) + ((_nbLignes == null) ? 0 : _nbLignes.hashCode());
    result = (prime * result) + ((_nbLignesKO == null) ? 0 : _nbLignesKO.hashCode());
    result = (prime * result) + ((_typeFichier == null) ? 0 : _typeFichier.hashCode());
    return result;
  }

  /**
   * @param date_p
   *          the date to set
   */
  public void setDate(LocalDateTime date_p)
  {
    _date = date_p;
  }

  /**
   * @param deltaDeLigne_p
   *          the deltaDeLigne to set
   */
  public void setDeltaDeLigne(Integer deltaDeLigne_p)
  {
    _deltaDeLigne = deltaDeLigne_p;
  }

  /**
   * @param fichierNom_p
   *          the fichierNom to set
   */
  public void setFichierNom(String fichierNom_p)
  {
    _fichierNom = fichierNom_p;
  }

  /**
   * @param index_p
   *          the index to set
   */
  public void setIndex(Integer index_p)
  {
    _index = index_p;
  }

  /**
   * @param nbLigneRef_p
   *          the nbLigneRef to set
   */
  public void setNbLigneRef(Integer nbLigneRef_p)
  {
    _nbLigneRef = nbLigneRef_p;
  }

  /**
   * @param nbLignes_p
   *          the nbLignes to set
   */
  public void setNbLignes(Integer nbLignes_p)
  {
    _nbLignes = nbLignes_p;
  }

  /**
   * @param nbLignesKO_p
   *          the nbLignesKO to set
   */
  public void setNbLignesKO(Integer nbLignesKO_p)
  {
    _nbLignesKO = nbLignesKO_p;
  }

  /**
   * @param typeFichier_p
   *          the typeFichier to set
   */
  public void setTypeFichier(String typeFichier_p)
  {
    _typeFichier = typeFichier_p;
  }

}
