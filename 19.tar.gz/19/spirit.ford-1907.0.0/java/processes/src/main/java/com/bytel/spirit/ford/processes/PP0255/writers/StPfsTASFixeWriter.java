/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255.writers;

import static java.util.Objects.nonNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.tasfixe.StPfsTASFixe;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StPfsGenerique;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.ford.processes.Messages;

/**
 *
 * @author anakashi
 * @version ($Revision$ $Date$)
 */
public class StPfsTASFixeWriter extends STWriter
{

  /**
   *
   * @author anakashi
   * @version ($Revision$ $Date$)
   */
  public enum StPfsTASFixeHeader
  {
    /**
     *
     */
    ID_ST(0),

    /**
     *
     */
    STATUT(1),

    /**
     *
     */
    COMMENTAIRE(2),

    /**
     *
     */
    CLIENT_OPERATEUR(3),

    /**
     *
     */
    NO_COMPTE(4),

    /**
     *
     */
    NO_TELEPHONE(5),

    /**
     *
     */
    TYPE_USAGE(6),

    /**
    *
    */
    NOM(7),

    /**
    *
    */
    PRENOM(8),

    /**
    *
    */
    NOM_PRENOM_COURT(9),

    /**
     *
     */
    NIVEAU_RESTRICTION(10),

    /**
     *
     */
    NOTIFICATION_SUSPENSION(11),

    /**
    *
    */
    OPTION_APPELS_SURTAXES(12);

    /**
     * The header size
     */
    static final int ST_PFS_TAS_FIXE_HEADER_SIZE = 13;

    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index
     *          The index
     */
    StPfsTASFixeHeader(int index)
    {
      _index = index;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * @param filePath_p
   *          The path to the PFI CSV file
   * @param fileName_p
   *          The name to the PFI CSV file
   * @param linesToFlush_p
   *          Number of lines to flush
   * @throws IOException
   *           IOException
   */
  public StPfsTASFixeWriter(String filePath_p, String fileName_p, int linesToFlush_p) throws IOException
  {
    super(filePath_p, fileName_p, linesToFlush_p);
    createFile(filePath_p + fileName_p, StPfsTASFixeHeader.class);
  }

  @Override
  public void dump(Tracabilite tracabilite_p, ServiceTechnique objectToWrite_p)
  {
    if (shouldExecuteDump(objectToWrite_p))
    {
      executeDumpAction(tracabilite_p, objectToWrite_p);
    }
  }

  @Override
  protected void executeDumpAction(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p)
  {
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("StPfsTASFixeWriter.start"))); //$NON-NLS-1$

    StPfsGenerique stPfsGenerique = StPfsGenerique.class.cast(serviceTechnique_p);
    StPfsTASFixe stPfsTASFixe = deserializeRawFields(tracabilite_p, stPfsGenerique);//because of raw json fields from SAAB
    List<String> record = this.getRecord(stPfsTASFixe);

    if (!CollectionUtils.isEmpty(record))
    {
      write(tracabilite_p, record);
    }

    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("StPfsTASFixeWriter.end"))); //$NON-NLS-1$
  }

  @Override
  protected boolean shouldExecuteDump(ServiceTechnique serviceTechnique_p)
  {
    if (serviceTechnique_p != null)
    {
      if (TypeST.PFS.name().equals(serviceTechnique_p.getTypeServiceTechnique()))
      {
        return TypePFS.TAS_FIXE.name().equals(StPfsGenerique.class.cast(serviceTechnique_p).getTypePfs());
      }
    }
    return false;
  }

  /**
   * Convert an instance of StPfsGenerique object (having json raw fields) to an instance of StPfsTASFixe.
   *
   * @param tracabilite_p
   *          Tracabilite
   *
   * @param stPfsGenerique_p
   *          Instance of StPfsGenerique
   * @return An instance of StPfsTASFixe if deserialization succeeds, null otherwise.
   */
  private StPfsTASFixe deserializeRawFields(Tracabilite tracabilite_p, StPfsGenerique stPfsGenerique_p)
  {
    StPfsTASFixe stPfsTASFixe = null;
    try
    {
      stPfsTASFixe = stPfsGenerique_p != null ? StPfsTASFixe.buildFromStPfsGenerique(stPfsGenerique_p) : null;
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
    }
    return stPfsTASFixe;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param stPfsTASFixe_p
   *          The ServiceTechnique
   *
   * @return List of values
   */
  private List<String> getRecord(StPfsTASFixe stPfsTASFixe_p)
  {
    List<String> record = new ArrayList<>(Arrays.asList(new String[StPfsTASFixeHeader.ST_PFS_TAS_FIXE_HEADER_SIZE]));

    if (nonNull(stPfsTASFixe_p))
    {
      record.set(StPfsTASFixeHeader.ID_ST.getIndex(), stPfsTASFixe_p.getIdSt());
      record.set(StPfsTASFixeHeader.STATUT.getIndex(), stPfsTASFixe_p.getStatut());
      record.set(StPfsTASFixeHeader.COMMENTAIRE.getIndex(), stPfsTASFixe_p.getCommentaire());
      record.set(StPfsTASFixeHeader.CLIENT_OPERATEUR.getIndex(), stPfsTASFixe_p.getClientOperateur());
      record.set(StPfsTASFixeHeader.NO_COMPTE.getIndex(), stPfsTASFixe_p.getNoCompte());

      if (stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe() != null)
      {
        record.set(StPfsTASFixeHeader.NO_TELEPHONE.getIndex(), stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getNoTelephone());
        record.set(StPfsTASFixeHeader.TYPE_USAGE.getIndex(), stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getTypeUsage());
        record.set(StPfsTASFixeHeader.NOM.getIndex(), stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getNom());
        record.set(StPfsTASFixeHeader.PRENOM.getIndex(), stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getPrenom());
        record.set(StPfsTASFixeHeader.NOM_PRENOM_COURT.getIndex(), stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getNomPrenomCourt());
        record.set(StPfsTASFixeHeader.NIVEAU_RESTRICTION.getIndex(), stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getNiveauRestriction());
        record.set(StPfsTASFixeHeader.NOTIFICATION_SUSPENSION.getIndex(), stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getNotificationSuspension());
        record.set(StPfsTASFixeHeader.OPTION_APPELS_SURTAXES.getIndex(), stPfsTASFixe_p.getDonneesProvisionneesStPfsTASFixe().getOptionAppelSurTaxes());
      }
      return record;
    }

    return Collections.emptyList();
  }

}
