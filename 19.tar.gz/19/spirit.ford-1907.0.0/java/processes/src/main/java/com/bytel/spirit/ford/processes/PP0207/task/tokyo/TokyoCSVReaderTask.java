/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.task.tokyo;

import java.io.File;
import java.nio.charset.Charset;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.ford.processes.PP0207.task.AbstractCSVReaderTask;
import com.bytel.spirit.ford.processes.PP0207.task.IBlocImportData;
import com.bytel.spirit.ford.processes.PP0207.task.ImportContext;
import com.bytel.spirit.saab.connectors.res.geod.type.TypeReferentiel;

/**
 *
 * CSV Reader for Tokyo couverture multi-threaded import. <br />
 * See {@link AbstractCSVReaderTask} for more information.
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class TokyoCSVReaderTask extends AbstractCSVReaderTask
{

  /**
   * @param csvFile_p
   *          the CSV file
   * @param sep_p
   *          CSV separator
   * @param charset_p
   *          CSV charset
   * @param blocSize_p
   *          bloc size
   * @param typeReferentiel_p
   *          type referentiel
   * @param context_p
   *          context
   */
  public TokyoCSVReaderTask(File csvFile_p, char sep_p, Charset charset_p, Integer blocSize_p, TypeReferentiel typeReferentiel_p, ImportContext context_p)
  {
    super(csvFile_p, sep_p, charset_p, blocSize_p, typeReferentiel_p, context_p);
  }

  @Override
  protected IBlocImportData<?> initTransitionData()
  {
    return new TokyoBlocImportData();
  }

  @Override
  protected Retour validateSTI(CSVLine line_p)
  {
    // Checks the correct separator is present
    if (_sep != line_p.getSeparator())
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.LIGNE_INCORRECTE, "Propriétés non séparées par le bon séparateur"); //$NON-NLS-1$
    }

    // Return validation result
    if (!(line_p.size() == 2))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.LIGNE_INCORRECTE, "Nombre de propriétés présentées incorrectes"); //$NON-NLS-1$
    }

    Boolean validArgs = (line_p.getString(0).length() <= 15) && (line_p.getString(0).matches(REGEX_ID_ADRESSE_BYTEL)) && (line_p.getString(1).length() <= 10) && (line_p.getString(1).matches(REGEX_HOME_ZONE));

    return validArgs ? RetourFactory.createOkRetour() : RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.LIGNE_INCORRECTE, "Taille des propriétés incohérente"); //$NON-NLS-1$
  }

}
