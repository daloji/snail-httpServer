/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import java.text.MessageFormat;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.ford.processes.Messages;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public final class NSFWriterFactory
{

  /**
   * Retour of NSFWriterFactory
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public static final class NSFWriterFactoryRetour
  {
    /**
     * Retour of the factory
     */
    Retour _retour;
    /**
     * Object Writer
     */
    INSFWriter _writer;

    /**
     * Create Factory retour
     *
     * @param retour_p
     *          The retour
     * @param nsfWriter_p
     *          The INSFWriter object
     */
    public NSFWriterFactoryRetour(Retour retour_p, INSFWriter nsfWriter_p)
    {
      _retour = retour_p;
      _writer = nsfWriter_p;
    }

    /**
     * @return INSFWriter
     */
    public INSFWriter getNSFWriter()
    {
      return _writer;
    }

    /**
     * @return Retour
     */
    public Retour getRetour()
    {
      return _retour;
    }

  }

  /**
   * CSV file extension
   */
  public static final String CSV_FILE_EXTENSION = ".csv"; //$NON-NLS-1$

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @param extractionName_p
   *          The extraction name that determines the INSFWriter type to create
   * @param workPath_p
   *          The folder to store CSV file
   * @param environment_p
   *          The environment Ex: PROD, ITG, ...
   * @param nbLinesToFlush_p
   *          Number of CSV lines in buffer to flush into the CSV file
   * @param dateTime_p
   *          String representing a date in the format yyyyMMdd_HHmmss. Is the date that is part of the file name
   * @return NSFWriterFactoryRetour object which contains the Retour OK if the Writer is well created or KO otherwise.
   *         If the Writer is well created it will be accessible by method getNSFWriter(), otherwise null is returned.
   *
   */
  public static NSFWriterFactoryRetour getNSFWriter(Tracabilite tracabilite_p, String extractionName_p, String workPath_p, String environment_p, int nbLinesToFlush_p, String dateTime_p)
  {
    String extractionFileName = getFileExtractionName(extractionName_p, environment_p, dateTime_p);
    String fullPathfilename = workPath_p + extractionFileName;

    INSFWriter writer = null;
    Retour retour = RetourFactory.createOkRetour();

    try
    {
      switch (extractionName_p)
      {
        case "SPIRIT-PFI": //$NON-NLS-1$
          writer = new PfiWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-PALFXDSL": //$NON-NLS-1$
          writer = new PaLigneFixeXdslWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-PALFFTTH": //$NON-NLS-1$
          writer = new PaLigneFixeFtthWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-PALFFTTLA": //$NON-NLS-1$
          writer = new PaLigneFixeFttlaWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-PAVOIP": //$NON-NLS-1$
          writer = new PaVoipWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-PAFAX": //$NON-NLS-1$
          writer = new PaFaxWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-PACA": //$NON-NLS-1$
          writer = new PaCompteAccesWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-PATV": //$NON-NLS-1$
          writer = new PaTvWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-LIENSAPALF": //$NON-NLS-1$
          writer = new LienSaPaLigneFixeWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-LIENSAPAVOIP": //$NON-NLS-1$
          writer = new LienSaPaVoipWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-LIENSAPAFAX": //$NON-NLS-1$
          writer = new LienSaPaFaxWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-LIENSAPATV": //$NON-NLS-1$
          writer = new LienSaPaTvWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-LIENSAPACA": //$NON-NLS-1$
          writer = new LienSaPaCompteAccesWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-LIENEQTPAMODEM": //$NON-NLS-1$
          writer = new LienEqtPaModemWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-LIENEQTPADECODEURTV": //$NON-NLS-1$
          writer = new LienEqtPaDecodeurTvWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-LIENEQTPAONT": //$NON-NLS-1$
          writer = new LienEqtPaOntWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-LIENEQTPACARTETHD": //$NON-NLS-1$
          writer = new LienEqtPaCarteThdWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        case "SPIRIT-LIENEQTPAMODEMDECODEURTV": //$NON-NLS-1$
          writer = new LienEqtPaModemDecodeurTvWriter(fullPathfilename, nbLinesToFlush_p);
          break;
        default:
          return new NSFWriterFactoryRetour(RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0098.NSFWriterFactory.invalidExtractionName"), extractionName_p)), null); //$NON-NLS-1$
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), extractionFileName, e.getMessage()))); //$NON-NLS-1$
      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), extractionFileName, e.getMessage())); //$NON-NLS-1$
    }
    return new NSFWriterFactoryRetour(retour, writer);
  }

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @param extractionName_p
   *          The extraction name that determines the INSFWriter type to create
   * @param workPath_p
   *          The folder to store CSV file
   * @param environment_p
   *          The environment Ex: PROD, ITG, ...
   * @param nbLinesToFlush_p
   *          Number of CSV lines in buffer to flush into the CSV file
   * @param dateTime_p
   *          String representing a date in the format yyyyMMdd_HHmmss. Is the date that is part of the file name
   * @param pfiCounter_p
   *          Count the number of times the PFI was written.
   * @return NSFWriterFactoryRetour object which contains the Retour OK if the Writer is well created or KO otherwise.
   *         If the Writer is well created it will be accessible by method getNSFWriter(), otherwise null is returned.
   *
   */
  public static NSFWriterFactoryRetour getNSFWriter(Tracabilite tracabilite_p, String extractionName_p, String workPath_p, String environment_p, int nbLinesToFlush_p, String dateTime_p, Map<String, AtomicInteger> pfiCounter_p)
  {
    String filename = getFullPathFileExtractionName(extractionName_p, workPath_p, environment_p, dateTime_p);
    INSFWriter writer = null;
    Retour retour = RetourFactory.createOkRetour();
    try
    {
      writer = new NbPhotoSurPfiWriter(filename, nbLinesToFlush_p, pfiCounter_p);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), filename, e.getMessage()))); //$NON-NLS-1$
      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), filename, e.getMessage())); //$NON-NLS-1$
    }
    return new NSFWriterFactoryRetour(retour, writer);

  }

  /**
   * Build the file extraction name. The format of the name returned is
   * <FichierExtraction>_<ENVI>_<YYYYMMDD>_<HHMMSS>.csv
   *
   * @param extractionName_p
   *          The extraction name
   * @param environement_p
   *          The environment
   * @param dateTime
   *          The date and time
   * @return The filename in the format specified.
   */
  private static String getFileExtractionName(String extractionName_p, String environement_p, String dateTime)
  {

    StringBuilder sb = new StringBuilder();
    sb.append(extractionName_p) //
        .append('_')//
        .append(environement_p)//
        .append('_')//
        .append(dateTime).append(CSV_FILE_EXTENSION);
    return sb.toString();
  }

  /**
   * Build the full path file extraction name. The format of the name returned is
   * <FichierExtraction>_<ENVI>_<YYYYMMDD>_<HHMMSS>.csv
   *
   * @param extractionName_p
   *          The extraction name
   * @param workPath_p
   *          The path to work folder. Includes file separator at the end.
   * @param environement_p
   *          The environment
   * @param dateTime
   *          The date and time
   * @return The filename in the format specified.
   */
  private static String getFullPathFileExtractionName(String extractionName_p, String workPath_p, String environement_p, String dateTime)
  {
    return workPath_p + getFileExtractionName(extractionName_p, environement_p, dateTime);
  }

  /**
   *
   */
  private NSFWriterFactory()
  {

  }

}
