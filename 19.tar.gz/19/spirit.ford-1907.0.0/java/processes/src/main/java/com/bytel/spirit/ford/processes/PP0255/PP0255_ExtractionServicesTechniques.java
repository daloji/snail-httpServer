/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0255;

import static com.google.common.base.Strings.isNullOrEmpty;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.cxf.helpers.FileUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier.BL3400_SupprimerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder;
import com.bytel.spirit.common.ford.config.ConfigurationFluxExtraction;
import com.bytel.spirit.common.ford.config.GenericProcessConfig;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0255.structs.PP0255_RequestParameters;
import com.bytel.spirit.ford.processes.PP0255.writers.StLACWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsAcsIadWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsClfWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsEnumWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsFqdnWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsHSSFixeWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsMailWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsOltWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsPnfWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsSamWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsTASFixeWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsVmsCvmWriter;
import com.bytel.spirit.ford.processes.PP0255.writers.StPfsVmsStwWriter;
import com.bytel.spirit.ford.shared.misc.processes.FordProcessSkeleton;
import com.bytel.spirit.ford.shared.misc.processes.writers.IGenericWriter;
import com.bytel.spirit.ford.shared.types.GenericProcessConfigValidator;
import com.bytel.spirit.saab.connectors.rst.IServiceTechniqueCallback;
import com.bytel.spirit.saab.connectors.rst.RSTDatabaseProxy;

/**
 *
 * @author jbrites
 * @version ($Revision$ $Date$)
 */
public class PP0255_ExtractionServicesTechniques extends FordProcessSkeleton<IGenericWriter<ServiceTechnique>, ServiceTechnique> implements IServiceTechniqueCallback
{

  /**
   * Holds context data for PP0255_ExtractionServicesTechniques
   *
   * @author jbrites
   * @version ($Revision$ $Date$)
   */
  public static final class PP0255_ExtractionServicesTechniquesContext extends Context
  {
    /**
     *
     */
    private static final long serialVersionUID = 4502516496227138808L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PP0255_START;

    /**
     * Contains the process retour.
     */
    private Retour _processRetour;

    /**
     * Contains the process configuration
     */
    private transient GenericProcessConfig _configurationPP0255;

    /**
     * Contains the execution mode.
     */
    private String _modeExecution;

    /**
     * Contains the id of the extraction flux.
     */
    private String _typeServiceTechnique;

    /**
     * Constains the ThreadPoolExecutor.
     */
    private ThreadPoolExecutor _threadPoolExecutor;

    /**
     * Contains the future result of the submitted task for the ThreadPoolExecutor
     */
    List<Future<Retour>> _threadPoolExecutorResult = Collections.synchronizedList(new ArrayList<>());

    /**
     * Constains the writer.
     */
    private List<IGenericWriter<ServiceTechnique>> _writers;

    /**
     * @return the configurationPP0255
     */
    public GenericProcessConfig getConfigurationPP0255()
    {
      return _configurationPP0255;
    }

    /**
     * @return the modeExecution
     */
    public String getModeExecution()
    {
      return _modeExecution;
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the threadPoolExecutor
     */
    public ThreadPoolExecutor getThreadPoolExecutor()
    {
      return _threadPoolExecutor;
    }

    /**
     * @return the typeServiceTechnique
     */
    public String getTypeServiceTechnique()
    {
      return _typeServiceTechnique;
    }

    /**
     * @return the nfsWriters
     */
    public List<IGenericWriter<ServiceTechnique>> getWriters()
    {
      return new ArrayList<>(_writers);
    }

    /**
     * @param configurationPP0255_p
     *          the configurationPP0255 to set
     */
    public void setConfigurationPP0255(GenericProcessConfig configurationPP0255_p)
    {
      _configurationPP0255 = configurationPP0255_p;
    }

    /**
     * @param modeExecution_p
     *          the modeExecution to set
     */
    public void setModeExecution(String modeExecution_p)
    {
      _modeExecution = modeExecution_p;
    }

    /**
     * @param processRetour_p
     *          the processRetour to set
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param threadPoolExecutor_p
     *          the threadPoolExecutor to set
     */
    public void setThreadPoolExecutor(ThreadPoolExecutor threadPoolExecutor_p)
    {
      _threadPoolExecutor = threadPoolExecutor_p;
    }

    /**
     * @param typeServiceTechnique_p
     *          the typeServiceTechnique to set
     */
    public void setTypeServiceTechnique(String typeServiceTechnique_p)
    {
      _typeServiceTechnique = typeServiceTechnique_p;
    }

    /**
     * @param writers_p
     *          the nfsWriters to set
     */
    public void setWriters(List<IGenericWriter<ServiceTechnique>> writers_p)
    {
      _writers = new ArrayList<>(writers_p);
    }
  }

  /**
   * PP0255 states
   *
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PP0255_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call BL001
     */
    PP0255_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL100
     */
    PP0255_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL101
     */
    PP0255_BL101(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL102
     */
    PP0255_BL102(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL901
     */
    PP0255_BL901(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL902
     */
    PP0255_BL902(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL903
     */
    PP0255_BL903(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL904
     */
    PP0255_BL904(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL910
     */
    PP0255_BL910(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL920
     */
    PP0255_BL920(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PP0255_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PP0255_CALLBACK(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PP0255_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * ID Flux ExtractionAutorisees possibles
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  protected enum IdFluxExtraction
  {
    /**
     * ST-LAC
     */
    ST_LAC("SPIRIT-ST-LAC", "ST-LAC"), //$NON-NLS-1$ //$NON-NLS-2$

    /**
     * ST-PFS-MAIL
     */
    ST_PFS_MAIL("SPIRIT-ST-PFS-MAIL", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$

    /**
     * ST-PFS-OLT
     */
    ST_PFS_OLT("SPIRIT-ST-PFS-OLT", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$

    /**
     * ST-PFS-SAM
     */
    ST_PFS_SAM("SPIRIT-ST-PFS-SAM", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$

    /**
     * ST-PFS-CLF
     */
    ST_PFS_CLF("SPIRIT-ST-PFS-CLF", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$

    /**
     * ST-PFS-PNF
     */
    ST_PFS_PNF("SPIRIT-ST-PFS-PNF", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$

    /**
     * ST-PFS-VMS-STW
     */
    ST_PFS_VMS_STW("SPIRIT-ST-PFS-VMS-STW", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$

    /**
     * ST-PFS-ACS-IAD
     */
    ST_PFS_ACS_IAD("SPIRIT-ST-PFS-ACS_IAD", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$

    /**
     * ST-PFS-FQDN
     */
    ST_PFS_FQDN("SPIRIT-ST-PFS-FQDN", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$

    /**
     * ST_PFS_ENUM
     */
    ST_PFS_ENUM("SPIRIT-ST-PFS-ENUM", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$

    /**
     * ST-PFS-VMS-CVM
     */
    ST_PFS_VMS_CVM("SPIRIT-ST-PFS-VMS-CVM", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$,

    /**
     * ST-PFS-VMS-CVM
     */
    ST_PFS_HSS_FIXE("SPIRIT-ST-PFS-HSS_FIXE", TYPE_SERVICE_TECHNIQUE_ST_PFS), //$NON-NLS-1$

    /**
     * ST-PFS-VMS-CVM
     */
    ST_PFS_TAS_FIXE("SPIRIT-ST-PFS-TAS_FIXE", TYPE_SERVICE_TECHNIQUE_ST_PFS); //$NON-NLS-1$

    //Add new types of ST here, if the extraction is required

    /**
     * Get the value of the Id Flux in the config corresponding to the typeServiceTechnique parameter
     *
     * @param typeServiceTechnique_p
     *          The typeof ServiceTechnique
     * @return The value of Id Flux, Null if corresponding does not exists
     */
    public static List<String> getAllIdFluxfromTypeServiceTechnique(String typeServiceTechnique_p)
    {
      List<String> listIdFluxMatch = new ArrayList<>();
      for (IdFluxExtraction idFlux : IdFluxExtraction.values())
      {
        if (idFlux.getTypeServiceTechnique().equals(typeServiceTechnique_p))
        {
          listIdFluxMatch.add(idFlux.getIdFluxExtractionAutoriseConf());
        }
      }
      return listIdFluxMatch;
    }

    /**
     * Validate if the idFlux parameter is valid. To evaluete, check that the value is one of the values present in this
     * enum.
     *
     * @param idFlux_p
     *          The Id Flux to validate
     * @return True if valid, false otherwise
     */
    public static boolean isValidIdFluxAutorisee(String idFlux_p)
    {
      for (IdFluxExtraction idFlux : IdFluxExtraction.values())
      {
        if (idFlux.getIdFluxExtractionAutoriseConf().equals(idFlux_p))
        {
          return true;
        }
      }
      return false;
    }

    /**
     * Validate if the serviceTechnique parameter is valid. To evaluate, check that the value is one of the values
     * present in this enum.
     *
     * @param typeServiceTechnique_p
     *          The serviceTechnique to validate
     * @return True if valid, false otherwise
     */
    public static boolean isValidServiceTechnique(String typeServiceTechnique_p)
    {
      for (IdFluxExtraction idFlux : IdFluxExtraction.values())
      {
        if (idFlux.getTypeServiceTechnique().equals(typeServiceTechnique_p))
        {
          return true;
        }
      }
      return false;
    }

    /**
     * Name of idFluxExtractionAutorise possible in the configuration file
     */
    private String _idFluxExtractionAutoriseConf;

    /**
     * Value of the parameter typeServiceTechnique required to extract the correspondent flux
     */
    private String _typeServiceTechnique;

    /**
     *
     * @param idFluxExtractionAutoriseConf_p
     *          idFlux autorisee
     * @param typeServiceTechnique_p
     *          type of ServiceTechnique
     */
    private IdFluxExtraction(String idFluxExtractionAutoriseConf_p, String typeServiceTechnique_p)
    {
      _idFluxExtractionAutoriseConf = idFluxExtractionAutoriseConf_p;
      _typeServiceTechnique = typeServiceTechnique_p;

    }

    /**
     * @return the idFluxExtractionAutoriseConf
     */
    public String getIdFluxExtractionAutoriseConf()
    {
      return _idFluxExtractionAutoriseConf;
    }

    /**
     * @return the typeServiceTechnique
     */
    public String getTypeServiceTechnique()
    {
      return _typeServiceTechnique;
    }

  }

  /**
   * ST-PFS
   */
  public static final String TYPE_SERVICE_TECHNIQUE_ST_PFS = "ST-PFS"; //$NON-NLS-1$
  /**
   * ST-LAC
   */
  public static final String TYPE_SERVICE_TECHNIQUE_ST_LAC = "ST-LAC"; //$NON-NLS-1$

  /**
   * The message for ErrorRenamingFile.
   */
  protected static final String MESSAGE_UNAUTHORIZED_SERVICE_TECHNIQUE = Messages.getString("PP0255.UnauthorizedServiceTechnique"); //$NON-NLS-1$
  /**
   * The message to present when the ServiceTechnique param is required
   */
  protected static final String MESSAGE_PARAM_SERVICE_TECHNIQUE_REQUIRED = Messages.getString("PP0255.ServiceTechniqueisNull"); //$NON-NLS-1$
  /**
   *
   */
  private static final long serialVersionUID = -924558410356343196L;

  /**
   * The message for MESSAGE_AUCUNE_ST log.
   */
  private static final String MESSAGE_AUCUNE_ST = Messages.getString("PP0255.AucuneST"); //$NON-NLS-1$

  /**
   * The SPIRIT-ST-LAC constant.
   */
  private static final String SPIRIT_ST_LAC = "SPIRIT-ST-LAC"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-MAIL constant.
   */
  private static final String SPIRIT_ST_PFS_MAIL = "SPIRIT-ST-PFS-MAIL"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-OLT constant.
   */
  private static final String SPIRIT_ST_PFS_OLT = "SPIRIT-ST-PFS-OLT"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-SAM constant.
   */
  private static final String SPIRIT_ST_PFS_SAM = "SPIRIT-ST-PFS-SAM"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-CLF constant.
   */
  private static final String SPIRIT_ST_PFS_CLF = "SPIRIT-ST-PFS-CLF"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-PNF constant.
   */
  private static final String SPIRIT_ST_PFS_PNF = "SPIRIT-ST-PFS-PNF"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-PNF constant.
   */
  private static final String SPIRIT_ST_PFS_ENUM = "SPIRIT-ST-PFS-ENUM"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-VMS-STW constant.
   */
  private static final String SPIRIT_ST_PFS_VMS_STW = "SPIRIT-ST-PFS-VMS-STW"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-VMS-CVM constant.
   */
  private static final String SPIRIT_ST_PFS_VMS_CVM = "SPIRIT-ST-PFS-VMS-CVM"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-ACS_IAD constant.
   */
  private static final String SPIRIT_ST_PFS_ACS_IAD = "SPIRIT-ST-PFS-ACS_IAD"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-FQDN constant.
   */
  private static final String SPIRIT_ST_PFS_FQDN = "SPIRIT-ST-PFS-FQDN"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-HSS_FIXE constant.
   */
  private static final String SPIRIT_ST_PFS_HSS_FIXE = "SPIRIT-ST-PFS-HSS_FIXE"; //$NON-NLS-1$

  /**
   * The SPIRIT-ST-PFS-TAS_FIXE constant.
   */
  private static final String SPIRIT_ST_PFS_TAS_FIXE = "SPIRIT-ST-PFS-TAS_FIXE"; //$NON-NLS-1$

  /**
   * Url parameter name for typeServiceTechnique
   */
  private static final String URL_PARAM_TYPE_SERVICE_TECHNIQUE = "typeServiceTechnique"; //$NON-NLS-1$

  /**
   * The process context.
   */
  private PP0255_ExtractionServicesTechniquesContext _processContext;

  @Override
  public Retour consume(Tracabilite tracabilite_p, ServiceTechnique serviceTechnique_p) throws RavelException
  {
    //Cette méthode est appélée par un seul thread dans le connecteur Cassandra (c'est le même thread que celui qui exécute
    //ce processus).
    //Plus cette méthode est appelée, plus la liste _processContext._threadPoolExecutorResult grossit.
    //Pour donner un ordre d'idée, un fichier d'extract de ST PFS MAIL de 600 Mo contient 4 millions de lignes.
    //Il n'est donc pas raisonnable de stocker 4 millions de Future dans la liste  _processContext._threadPoolExecutorResult.
    //Une solution simple à ce problème: si la liste _processContext._threadPoolExecutorResult atteind la taille de la blocking queue (waitingFileSize = 100),
    //alors  on attend le resultat de ces 100 taches. Une fois les 100 taches terminées, on vide la liste _processContext._threadPoolExecutorResult
    //avant de rappeler le BL910_PushIdInExecutor.
    //Ainsi, la taille de liste _processContext._threadPoolExecutorResult sera toujours limitée en mémoire et puis on evite le risque de pousser dans une file pleine.
    //Quoi qu'il en soit:
    // - Si les writers sont rapides, la fonction d'attente BL903_WaitForTasksCompletion sera rapide également.
    // - Si les writers sont  lents, la fonction BL903_WaitForTasksCompletion attendra plus longtemps la fin des tâches.
    if (_processContext._threadPoolExecutorResult.size() == _processContext.getConfigurationPP0255().getWaitingFileSize())
    {
      Retour retour = BL903_WaitForTasksCompletion(tracabilite_p, _processContext.getConfigurationPP0255(), _processContext._threadPoolExecutorResult);
      if (!RetourFactory.isRetourOK(retour))
      {
        _processContext.setProcessRetour(retour);
        return retour;
      }

      _processContext._threadPoolExecutorResult.clear();
    }

    // Call BL110
    _processContext.setState(State.PP0255_BL910);
    Retour retourBL910 = BL910_PushIdInExecutor(tracabilite_p, _processContext.getConfigurationPP0255(), serviceTechnique_p, _processContext.getWriters(), _processContext.getThreadPoolExecutor(), _processContext._threadPoolExecutorResult);
    _processContext.setProcessRetour(retourBL910);

    return retourBL910;
  }

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    if (retour_p != null)
    {
      return MarshallTools.marshall(retour_p);
    }
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PP0255_ExtractionServicesTechniquesContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void continueProcess(Request arg0_p, Tracabilite arg1_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, MESSAGE_UNEXPECTED_CONTINUE);
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel
  }

  /**
   * Extract URL parameters of PP0255
   *
   * @param request_p
   *          The request object
   * @return PP0255_RequestParameters
   */
  protected Pair<Retour, PP0255_RequestParameters> getPP0255ParamsFromRequest(Request request_p)
  {
    PP0255_RequestParameters requestParameters = new PP0255_RequestParameters();

    // get url parameters
    List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();

    for (Parameter parametre : urlParametersType)
    {
      if (parametre.getName().equalsIgnoreCase(PARAM_MODE_EXECUTION))
      {
        requestParameters.setModeExecution(parametre.getValue());
      }

      if (parametre.getName().equalsIgnoreCase(URL_PARAM_TYPE_SERVICE_TECHNIQUE))
      {
        requestParameters.setTypeServiceTechnique(parametre.getValue());
      }
    }

    if (StringTools.isNullOrEmpty(requestParameters.getModeExecution()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_MODE_EXECUTION)), null);
    }
    if (!Arrays.asList(PRODUIRE_EXTRACTIONS, TRANSFERER_FICHIERS).contains(requestParameters.getModeExecution()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_MODE_EXECUTION_PAS_CONNU), null);
    }
    //typeServiceTechnique is required if modeExecution is ProduireExtractions
    if (PRODUIRE_EXTRACTIONS.equals(requestParameters.getModeExecution()) && StringTools.isNullOrEmpty(requestParameters.getTypeServiceTechnique()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_PARAM_SERVICE_TECHNIQUE_REQUIRED), null);
    }
    // Check TypeServiceTechnique
    if (PRODUIRE_EXTRACTIONS.equals(requestParameters.getModeExecution()) && !IdFluxExtraction.isValidServiceTechnique(requestParameters.getTypeServiceTechnique()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_UNAUTHORIZED_SERVICE_TECHNIQUE, requestParameters.getTypeServiceTechnique())), null);
    }

    return new Pair<>(RetourFactory.createOkRetour(), requestParameters);
  }

  @Override
  protected Pair<Retour, IGenericWriter<ServiceTechnique>> getWriter(Tracabilite tracabilite_p, String extractionName_p, String filePath_p, String fileName_p, int nbLinesToFlush_p)
  {
    try
    {
      switch (extractionName_p)
      {
        case SPIRIT_ST_LAC:
          return new Pair<>(RetourFactory.createOkRetour(), new StLACWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_MAIL:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsMailWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_OLT:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsOltWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_SAM:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsSamWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_CLF:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsClfWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_PNF:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsPnfWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_VMS_STW:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsVmsStwWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_ACS_IAD:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsAcsIadWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_FQDN:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsFqdnWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_ENUM:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsEnumWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_VMS_CVM:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsVmsCvmWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_HSS_FIXE:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsHSSFixeWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        case SPIRIT_ST_PFS_TAS_FIXE:
          return new Pair<>(RetourFactory.createOkRetour(), new StPfsTASFixeWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        default:
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_INVALID_EXTRACTION_NAME, extractionName_p)), null);
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, fileName_p, e.getMessage())));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, fileName_p, e.getMessage())), null);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      // Call BL001
      _processContext.setState(State.PP0255_BL001);
      Pair<Retour, PP0255_RequestParameters> bl001Return = PP0255_BL001_VerifierDonnees(tracabilite_p, request_p);
      _processContext.setProcessRetour(bl001Return._first);

      if (RetourFactory.isRetourOK(bl001Return._first))
      {
        _processContext.setModeExecution(bl001Return._second.getModeExecution());
        _processContext.setTypeServiceTechnique(bl001Return._second.getTypeServiceTechnique());

        if (PRODUIRE_EXTRACTIONS.equals(_processContext.getModeExecution()))
        {
          // Call BL100
          _processContext.setState(State.PP0255_BL100);
          Retour retourBL100 = PP0255_BL100_ProduireFichierExtraction(tracabilite_p, _processContext.getTypeServiceTechnique());
          _processContext.setProcessRetour(retourBL100);

          if (RetourFactory.isRetourKO(retourBL100))
          {
            // if extraction errors, we should erase the previously created files
            deleteAllFilesInWorkPath(tracabilite_p, _processContext.getConfigurationPP0255().getCheminRepTravail(), _processContext.getModeExecution(), _processContext.getConfigurationPP0255().getExtensionFichierTemporaire());
          }
        }
        else
        {
          // Call BL200
          _processContext.setState(State.PP0255_BL200);
          Retour retourBL200 = PP0255_BL200_TransfererFichierExtraction(tracabilite_p);
          _processContext.setProcessRetour(retourBL200);
        }
      }
    }
    catch (Exception ex)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, ex.getMessage()));
    }
    finally
    {
      endSynchronousProcess(request_p, _processContext.getProcessRetour());
    }

    // set Retour
    this.setRetour(_processContext.getProcessRetour());
    _processContext.setState(State.PP0255_END);
  }

  /**
   * Call RST database connector
   *
   * @param tracabilite_p
   *          Tracabilite
   * @return Retour OK if database connector invoked with success, KO otherwise
   * @throws RavelException
   *           Thrown by Database connector
   */
  private Retour callRSTDatabase(Tracabilite tracabilite_p) throws RavelException
  {

    //Call RST to get ST LAC
    switch (_processContext.getTypeServiceTechnique())
    {
      case TYPE_SERVICE_TECHNIQUE_ST_LAC:
        return getAllActiveStLAC(tracabilite_p);
      case TYPE_SERVICE_TECHNIQUE_ST_PFS:
        return getAllActiveStPFS(tracabilite_p);
      default:
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_UNAUTHORIZED_SERVICE_TECHNIQUE, _processContext.getTypeServiceTechnique()));

    }

  }

  /**
   * Call RSTDatabase connector to get all ServiceTechnique of type LAC
   *
   * @param tracabilite_p
   *          Tracabilite
   * @return Retour OK if database connector invoked with success, KO otherwise
   * @throws RavelException
   *           Thrown by Database connector
   */
  private Retour getAllActiveStLAC(Tracabilite tracabilite_p) throws RavelException
  {
    // Call RST Callback
    _processContext.setState(State.PP0255_CALLBACK);
    ConnectorResponse<Retour, Nothing> rstRetour = RSTDatabaseProxy.getInstance().getAllActiveStLienAllocationCommercial(tracabilite_p, this);
    _processContext.setProcessRetour(rstRetour._first);
    return rstRetour._first;
  }

  /**
   * Call RSTDatabase connector to get all ServiceTechnique of type PFS
   *
   * @param tracabilite_p
   *          Tracabilite
   * @return Retour OK if database connector invoked with success, KO otherwise
   * @throws RavelException
   *           Thrown by Database connector
   */
  private Retour getAllActiveStPFS(Tracabilite tracabilite_p) throws RavelException
  {
    // Call RST Callback
    _processContext.setState(State.PP0255_CALLBACK);
    ConnectorResponse<Retour, Nothing> rstRetour = RSTDatabaseProxy.getInstance().getAllActiveStPfs(tracabilite_p, this);
    _processContext.setProcessRetour(rstRetour._first);
    return rstRetour._first;
  }

  /**
   * Porte la vérification que l’ensemble des paramètres obligatoires de la configuration du processus sont définies.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param request_p
   *          request
   * @return PP0255_BL001_VerifierDonneesReturn
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Pair<Retour, PP0255_RequestParameters> PP0255_BL001_VerifierDonnees(@SuppressWarnings("unused") Tracabilite tracabilite_p, Request request_p) throws RavelException
  {
    // Get url parameters
    Pair<Retour, PP0255_RequestParameters> paramsFromRequest = getPP0255ParamsFromRequest(request_p);

    if (RetourFactory.isRetourNOK(paramsFromRequest._first))
    {
      return new Pair<>(paramsFromRequest._first, null);
    }

    // Load config
    String configPP0255Param = getConfigParameter(PARAM_CONFIG_PATH);

    if (!StringTools.isNullOrEmpty(configPP0255Param))
    {
      try
      {
        Path configPP0255Path = Paths.get(configPP0255Param);
        String configPP0255File = new String(Files.readAllBytes(configPP0255Path));
        _processContext.setConfigurationPP0255(MarshallTools.unmarshall(GenericProcessConfig.class, configPP0255File));
      }
      catch (Exception exception)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_FILE_ERROR, exception.getMessage())), null);
      }
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, PARAM_CONFIG_PATH)), null);
    }

    // Check config parameters
    String chaineNomParam = GenericProcessConfigValidator.checkInexistantParams(_processContext.getConfigurationPP0255());

    if (chaineNomParam.length() > 0)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, chaineNomParam)), null);
    }
    String[] idFluxAutorisees = _processContext.getConfigurationPP0255().getIdFluxExtractionAutorises().split(";"); //$NON-NLS-1$

    for (String idFlux : idFluxAutorisees)
    {
      String idFluxAutorise = idFlux.trim();
      if (!IdFluxExtraction.isValidIdFluxAutorisee(idFluxAutorise))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_ID_FLUX_EXTRACTION_INVALIDES, idFluxAutorise)), null);
      }
    }

    //Check if any of the ConfigurationFluxExtraction parameters are missing
    for (ConfigurationFluxExtraction cgfExtraction : _processContext.getConfigurationPP0255().getConfigurationFluxExtraction())
    {
      if (StringTools.isNullOrEmpty(cgfExtraction.getIdFluxExtraction()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_ID_FLUX_EXTRACTION)), null);
      }
      if (StringTools.isNullOrEmpty(cgfExtraction.getPattern()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_PATTERN)), null);
      }
      if (isNullOrEmpty(cgfExtraction.getChaineConnexion()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, PARAM_CHAINE_CONNEXION)), null);
      }
    }

    return new Pair<>(RetourFactory.createOkRetour(), paramsFromRequest._second);
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param typeServiceTechnique_p
   *          typeServiceTechnique_p
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP0255_BL100_ProduireFichierExtraction(Tracabilite tracabilite_p, String typeServiceTechnique_p) throws RavelException
  {
    try
    {
      // Call BL901
      _processContext.setState(State.PP0255_BL901);
      Pair<Retour, List<IGenericWriter<ServiceTechnique>>> retourInitNFSWriters = BL901_InitWriters(tracabilite_p, _processContext.getConfigurationPP0255(), IdFluxExtraction.getAllIdFluxfromTypeServiceTechnique(typeServiceTechnique_p), _processContext.getModeExecution());
      if (RetourFactory.isRetourKO(retourInitNFSWriters._first))
      {
        return retourInitNFSWriters._first;
      }

      // Store writers on context
      _processContext.setWriters(retourInitNFSWriters._second);

      // Call BL902
      _processContext.setState(State.PP0255_BL902);
      Pair<Retour, ThreadPoolExecutor> retourBL902 = BL902_InitExecutor(tracabilite_p, _processContext.getConfigurationPP0255());
      _processContext.setThreadPoolExecutor(retourBL902._second);

      if (RetourFactory.isRetourKO(retourBL902._first))
      {
        return retourBL902._first;
      }

      //Invoke dynamically the RSTDatabaseConnector depending on the typeServiceTechnique in the process context
      Retour retourRST = callRSTDatabase(tracabilite_p);

      // Call BL903
      _processContext.setState(State.PP0255_BL903);
      Retour retourBL903 = BL903_WaitExecutor(tracabilite_p, _processContext.getConfigurationPP0255(), retourBL902._second, _processContext._threadPoolExecutorResult);

      // Check Returns
      if (RetourFactory.isRetourKO(retourRST))
      {
        if (IMegSpiritConsts.TIMEOUT.equals(retourRST.getDiagnostic()))
        {
          return retourRST;
        }
        else if (IMegConsts.DONNEE_INCONNUE.equals(retourRST.getDiagnostic()))
        {
          // Log
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(MESSAGE_AUCUNE_ST, _processContext.getModeExecution(), tracabilite_p.getIdCorrelationByTel())));
          return RetourFactory.createOkRetour();
        }
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_LECTURE_IMPOSSIBLE);
      }
      else if (RetourFactory.isRetourKO(retourBL903))
      {
        return retourBL903;
      }
    }
    catch (RavelException re)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, re));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_LECTURE_IMPOSSIBLE);
    }
    finally
    {
      // Call BL904
      _processContext.setState(State.PP0255_BL904);
      BL904_CloseWriters(tracabilite_p, _processContext.getWriters(), _processContext.getConfigurationPP0255().getExtensionFichierTemporaire());
    }
    // Return OK
    return RetourFactory.createOkRetour();
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP0255_BL200_TransfererFichierExtraction(Tracabilite tracabilite_p) throws RavelException
  {
    // Get configuration
    GenericProcessConfig configurationPP0255 = _processContext.getConfigurationPP0255();

    String cheminRepTravail = configurationPP0255.getCheminRepTravail();

    for (ConfigurationFluxExtraction cgfExtraction : configurationPP0255.getConfigurationFluxExtraction())
    {
      File directory = new File(cheminRepTravail);
      if (directory.list().length >= 1)
      {
        List<File> files = FileUtils.getFiles(directory, cgfExtraction.getPattern());

        // Process file list
        for (File file : files)
        {
          try
          {
            if (file.getName().endsWith(configurationPP0255.getExtensionFichierTemporaire()))
            {
              LocalDateTime modifiedDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(file.lastModified()), ZoneId.systemDefault());
              LocalDateTime retentionDate = DateTimeManager.getInstance().now().minusSeconds(configurationPP0255.getDureeRetentionTmp());

              // Check date
              if (modifiedDate.isBefore(retentionDate))
              {
                // Call BL3400_SupprimerFichier
                BL3400_SupprimerFichier bl3400 = new BL3400_SupprimerFichierBuilder() //
                    .tracabilite(tracabilite_p) //
                    .fileName(file.getName()) //
                    .repertoire(cheminRepTravail) //
                    .build();
                bl3400.execute(this);
              }
            }
            else
            {
              // Call BL4300_EnvoyerFichier
              BL4300_EnvoyerFichier envoyerFichier = new BL4300_EnvoyerFichierBuilder() //
                  .tracabilite(tracabilite_p) //
                  .chaineConnexion(addFileToURI(cgfExtraction.getChaineConnexion(), file.getName())) //
                  .nomFichier(file.getName()) //
                  .repertoire(cheminRepTravail) //
                  .build();
              envoyerFichier.execute(this);
              Retour bl4300Retour = envoyerFichier.getRetour();

              if (RetourFactory.isRetourNOK(bl4300Retour))
              {
                if (IMegConsts.CAT1.equals(bl4300Retour.getCategorie()))
                {
                  // Call BL1200_DeplacerFichier
                  BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichierBuilder() //
                      .tracabilite(tracabilite_p) //
                      .nomFichier(file.getName()) //
                      .repertoireSrc(configurationPP0255.getCheminRepTravail()) //
                      .repertoireDes(configurationPP0255.getCheminRepArchiveErreur()) //
                      .build();
                  deplacerFichier.execute(this);
                }
                else
                {
                  // Renvoyer Erreur et Sortir du traitement
                  return bl4300Retour;
                }
              }
              else
              {
                // Call BL1200_DeplacerFichier
                BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder() //
                    .tracabilite(tracabilite_p) //
                    .nomFichier(file.getName()) //
                    .repertoireSrc(configurationPP0255.getCheminRepTravail()) //
                    .repertoireDes(configurationPP0255.getCheminRepArchiveSucces()) //
                    .build();
                deplacerFichier.execute(this);
              }
            }
          }
          catch (Exception exception)
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
            return RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage());
          }
        }
      }
    }
    return RetourFactory.createOkRetour();
  }
}
