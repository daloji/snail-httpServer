/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static java.util.Objects.nonNull;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.AccesTechnique;
import com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssGp;
import com.bytel.spirit.common.shared.saab.rpg.LienSAPA;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.SA;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class LienSaPaLigneFixeWriter implements INSFWriter
{

  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  public enum Header
  {
    /**
     * CLIENT_OPERATEUR
     */
    CLIENT_OPERATEUR(0),
    /**
     * NO_COMPTE
     */
    NO_COMPTE(1),
    /**
     * NO_SA
     */
    NO_SA(2),
    /**
     * ID_PA
     */
    ID_PA(3),
    /**
     * STATUT
     */
    STATUT(4),
    /**
     * NO_SC
     */
    NO_SC(5),
    /**
     * NOM_SC
     */
    NOM_SC(6),
    /**
     * TYPE_PA
     */
    TYPE_PA(7),
    /**
     * ID_RACCO
     */
    ID_RACCO(8),
    /**
     * ID_RES_RESEAU
     */
    ID_RES_RESEAU(9),
    /**
     * ID_OSS
     */
    ID_OSS(10),
    /**
     * ID_LIGNE
     */
    ID_LIGNE(11),
    /**
     * TECHNO_RACCO
     */
    TECHNO_RACCO(12),
    /**
     * ID_PROFIL_TECH
     */
    ID_PROFIL_TECH(13),
    /**
     * ID_OPE_COLLECTE
     */
    ID_OPE_COLLECTE(14),
    /**
     * ADR_CODE_INSEE
     */
    ADR_CODE_INSEE(15),
    /**
     * DATE_CREATION
     */
    DATE_CREATION(16),
    /**
     * DATE_MODIFICATION
     */
    DATE_MODIFICATION(17);

    /**
     * The position in CSV
     */
    private int _position;

    /**
     * Default constructor
     *
     * @param position
     *          The position
     */
    Header(int position)
    {
      _position = position;
    }

    /**
     * @return the position
     */
    public int getPosition()
    {
      return _position;
    }
  }

  /**
   * LIGNE_FIXE
   */
  public final static String LIGNE_FIXE = "LIGNE_FIXE"; //$NON-NLS-1$

  /**
   * Writer retour
   */
  private Retour _retour;

  /**
   * The writer
   */
  private BufferedWriter _writer;

  /**
   * The csv printer
   */
  private CSVPrinter _csvPrinter;

  /**
   * Current line in buffer
   */
  private Integer _lineCount;

  /**
   * Number of lines permited on buffer to call flush
   */
  private Integer _linesToFlush;

  /**
   * File Name
   */
  private String _fileName;

  /**
   * @param fileName_p
   *          The filename
   * @param linesToFlush_p
   *          The number of lines to call flush
   * @throws IOException
   *           IOException
   */
  public LienSaPaLigneFixeWriter(String fileName_p, Integer linesToFlush_p) throws IOException
  {
    _retour = RetourFactory.createOkRetour();
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    _lineCount = 0;
    _writer = Files.newBufferedWriter(Paths.get(fileName_p));
    _csvPrinter = new CSVPrinter(_writer, CSVFormat.newFormat(';').withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(Header.class));

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
    _writer.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> lines = this.getRecords(pfi_p, dateDemande_p);
    for (List<String> line : lines)
    {
      write(tracabilite_p, line);
    }
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param pfi_p
   *          The PFI
   * @return lines
   */
  public List<List<String>> getRecords(PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> records = new ArrayList<>();
    if (nonNull(pfi_p.getPa()))
    {
      List<PA> paList = pfi_p.getPa().stream().filter(pa -> LIGNE_FIXE.equals(pa.getTypePA())).collect(Collectors.toList());
      if (nonNull(paList))
      {
        for (PA pa : paList)
        {
          //Find LienSAPA
          List<LienSAPA> lienSaPaList = pfi_p.getLienSAPA().stream().filter(lSaPa -> pa.getIdentifiantFonctionnelPA().equals(lSaPa.getIdentifiantFonctionnelPA())).collect(Collectors.toList());
          if (nonNull(lienSaPaList))
          {
            for (LienSAPA lienSaPa : lienSaPaList)
            {
              List<SA> saList = pfi_p.getSa().stream().filter(sa -> sa.getNoServiceAccessible().equals(lienSaPa.getNoServiceAccessible())).collect(Collectors.toList());
              if (nonNull(saList))
              {
                for (SA sa : saList)
                {
                  if (nonNull(lienSaPa) //
                      && "BSS_GP".equals(pfi_p.getClientOperateur()) //$NON-NLS-1$
                      && dateDemande_p.isEqual(lienSaPa.getDateModification().toLocalDate()))
                  {
                    List<String> csvLine = new ArrayList<>(Arrays.asList(new String[Header.values().length]));
                    csvLine.set(Header.CLIENT_OPERATEUR.getPosition(), pfi_p.getClientOperateur());
                    csvLine.set(Header.NO_COMPTE.getPosition(), pfi_p.getNoCompte());
                    csvLine.set(Header.NO_SA.getPosition(), lienSaPa.getNoServiceAccessible());
                    csvLine.set(Header.ID_PA.getPosition(), lienSaPa.getIdentifiantFonctionnelPA());
                    csvLine.set(Header.STATUT.getPosition(), CSVWriterUtils.getCsvValue(lienSaPa.getStatut()));
                    csvLine.set(Header.NO_SC.getPosition(), sa.getNoServiceCommercial());
                    csvLine.set(Header.NOM_SC.getPosition(), sa.getNomServiceCommercial());
                    csvLine.set(Header.TYPE_PA.getPosition(), pa.getTypePA());
                    if (nonNull(pa.getPaTypeLigneFixe()))
                    {
                      csvLine.set(Header.ID_RACCO.getPosition(), pa.getPaTypeLigneFixe().getIdRaccordement());
                      InfoBrutBssGp infoBBss = pa.getPaTypeLigneFixe().getInfoBrutBssGp();
                      if (nonNull(infoBBss))
                      {
                        csvLine.set(Header.ID_RES_RESEAU.getPosition(), infoBBss.getIdRessourceReseauXDSL());
                        csvLine.set(Header.ID_OSS.getPosition(), infoBBss.getIdRessourceReseauFTTX());
                        csvLine.set(Header.ID_LIGNE.getPosition(), infoBBss.getIdLigne());
                        AccesTechnique accesTec = infoBBss.getAccesTechnique();
                        if (nonNull(accesTec))
                        {
                          csvLine.set(Header.TECHNO_RACCO.getPosition(), accesTec.getTechnologieAcces());
                          csvLine.set(Header.ID_PROFIL_TECH.getPosition(), accesTec.getIdProfilTechnique());
                          csvLine.set(Header.ID_OPE_COLLECTE.getPosition(), accesTec.getIdOperateurCollecte());
                        }
                        if (nonNull(infoBBss.getAdresseInstallation()))
                        {
                          csvLine.set(Header.ADR_CODE_INSEE.getPosition(), infoBBss.getAdresseInstallation().getCodeInsee());
                        }
                      }
                    }
                    csvLine.set(Header.DATE_CREATION.getPosition(), CSVWriterUtils.getCsvValue(lienSaPa.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
                    csvLine.set(Header.DATE_MODIFICATION.getPosition(), CSVWriterUtils.getCsvValue(lienSaPa.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
                    records.add(csvLine);
                  }
                }
              }
            }
          }
        }
      }
    }
    return records;
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Add lines to buffer or write them on file if buffer size is greater then max permited
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param line_p
   *          lines to be inserted in the file
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> line_p)
  {
    try
    {
      _csvPrinter.printRecord(line_p);
      _lineCount++;
      if (_lineCount >= _linesToFlush)
      {
        _csvPrinter.flush();
        _lineCount = 0;
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }
}
