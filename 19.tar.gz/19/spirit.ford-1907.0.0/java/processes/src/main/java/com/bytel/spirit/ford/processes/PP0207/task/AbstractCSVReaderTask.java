/*******************************************************************************
* $Id: AbstractCSVReaderTask.java 22848 2019-06-18 09:32:58Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.task;

import java.io.File;
import java.nio.charset.Charset;
import java.text.MessageFormat;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.csv.CSVFileReader;
import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.services.process.task.IRavelTask;
import com.bytel.ravel.services.process.task.ITransitionData;
import com.bytel.ravel.services.process.task.internal.RavelCancelException;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.saab.connectors.res.geod.type.TypeReferentiel;

/**
 * Common abstract task implementation for CSV reading task. <br />
 * One task will read entirely one CSV line by line. Every line will be validated (by concrete implementation) and added
 * to a bloc for further processing. Number of total lines and KO lines is modi
 *
 * @author jstrub
 * @version ($Revision: 22848 $ $Date: 2019-06-18 11:32:58 +0200 (mar. 18 juin 2019) $)
 */
public abstract class AbstractCSVReaderTask implements IRavelTask
{
  /** REGEX_ID_ADRESSE_BYTEL */
  protected static final String REGEX_ID_ADRESSE_BYTEL = "([0-9][0-9AB][0-9]{3}[0-9A-Z]{5}[0-9]{5})"; //$NON-NLS-1$
  /** REGEX_CODE_INSEE */
  protected static final String REGEX_CODE_INSEE = "([0-9][0-9AB][0-9]{3})"; //$NON-NLS-1$
  /** REGEX_CODE_RIVOLI */
  protected static final String REGEX_CODE_RIVOLI = "([0-9A-Z]{4})"; //$NON-NLS-1$
  /** REGEX_CODE_POSTAL */
  protected static final String REGEX_CODE_POSTAL = "([0-9][0-9AB][0-9]{3})"; //$NON-NLS-1$
  /** REGEX_HOME_ZONE */
  protected static final String REGEX_HOME_ZONE = "(HZ[0-9]-T[0-9]{5})"; //$NON-NLS-1$

  /** Description. */
  private final String _description;
  /** File. */
  private final File _file;
  /** File. */
  private final Charset _charset;
  /** CSV separator. */
  protected final char _sep;
  /** Bloc size of CSV line to pass further down. */
  protected final Integer _blocSize;
  /** Import context. */
  protected final ImportContext _context;

  /** CSV file reader */
  protected CSVFileReader _csvFileReader = null;
  /** Current state of this task : executing while there is line. */
  protected State _state;

  /**
   * @param csvFile_p
   *          the CSV file
   * @param sep_p
   *          CSV separator
   * @param charset_p
   *          CSV charset
   * @param blocSize_p
   *          bloc size
   * @param typeReferentiel_p
   *          type referentiel
   * @param context_p
   *          context
   */
  public AbstractCSVReaderTask(File csvFile_p, char sep_p, Charset charset_p, Integer blocSize_p, TypeReferentiel typeReferentiel_p, ImportContext context_p)
  {
    // Initialize fields
    _file = csvFile_p;
    _sep = sep_p;
    _charset = charset_p;
    _blocSize = blocSize_p;
    _context = context_p;

    // Build a description
    _description = "CSVReader-" + typeReferentiel_p.name() + "-" + csvFile_p.getName(); //$NON-NLS-1$ //$NON-NLS-2$

    // Task start executing
    _state = State.EXECUTING;
  }

  @Override
  public String description()
  {
    return _description;
  }

  @Override
  public ITransitionData execute() throws RavelException
  {
    try
    {
      // Lazy initialize the CSV file reader
      if (_csvFileReader == null)
      {
        _csvFileReader = new CSVFileReader(_file, _sep, _charset);
      }

      // Build the bloc
      Retour retour = RetourFactory.createOkRetour();
      IBlocImportData<?> transitionData = initTransitionData();
      while ((transitionData.size() < _blocSize) && hasNext())
      {
        // Read line
        CSVLine line = _csvFileReader.next();

        // Validate STI and increment total counter
        retour = validateSTI(line);
        _context.incremementLine();

        // Add line if it is STI compatible or increment KO counter
        if (RetourFactory.isRetourOK(retour))
        {
          transitionData.addLine(line);
        }
        else
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, _context.getTracabilite(), MessageFormat.format(Messages.getString("AbstractCSVReaderTask.LineKO"), line.toString(), retour.getLibelle()))); //$NON-NLS-1$
          _context.incremementLineKO();
        }
      }

      // If end of file has been reached, end this task
      if (!hasNext())
      {
        _state = State.ENDED;
        _csvFileReader.close();
      }

      // Don't return data on empty bloc
      if (transitionData.isEmpty())
      {
        return null;
      }

      return transitionData;
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, _context.getTracabilite(), exception));
      // On any error, cancel execution
      throw new RavelCancelException(ExceptionType.INTERNAL_ERROR, ErrorCode.KO_00000, exception.getMessage(), exception.getCause());
    }
  }

  @Override
  public State state()
  {
    return _state;
  }

  /**
   * @return a new bloc
   */
  protected abstract IBlocImportData<?> initTransitionData();

  /**
   * Validate line with the STI.
   *
   * @param line_p
   *          the line to validate
   * @return validation result
   */
  protected abstract Retour validateSTI(CSVLine line_p);

  /**
   * Validates next line to be read, doesn't throw an exception
   *
   * @return the result
   */
  private Boolean hasNext()
  {
    Boolean hasNext = false;
    Boolean hasException = false;
    do
    {
      try
      {
        hasNext = _csvFileReader.hasNext();
        hasException = false;
      }
      catch (IllegalArgumentException e)
      {
        //Line value empty or null
        hasException = true;
      }
    }
    while (hasException);

    return hasNext;
  }

}