/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import static java.util.Objects.nonNull;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.AccesTechnique;
import com.bytel.spirit.common.shared.saab.rpg.EquipementDeclare;
import com.bytel.spirit.common.shared.saab.rpg.InfoBrutBssGp;
import com.bytel.spirit.common.shared.saab.rpg.LienEquipementPA;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class LienEqtPaDecodeurTvWriter implements INSFWriter
{
  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  public enum Header
  {
    /**
     * CLIENT_OPERATEUR
     */
    CLIENT_OPERATEUR(0),
    /**
     * NO_COMPTE
     */
    NO_COMPTE(1),
    /**
     * NO_EQUIPEMENT
     */
    NO_EQUIPEMENT(2),
    /**
     * ID_PA
     */
    ID_PA(3),
    /**
     * STATUT
     */
    STATUT(4),
    /**
     * SERIAL_NUMBER
     */
    SERIAL_NUMBER(5),
    /**
     * TYPE
     */
    TYPE(6),
    /**
     * MODELE
     */
    MODELE(7),
    /**
     * ADR_MAC_TV
     */
    ADR_MAC_TV(8),
    /**
     * CODE_EAN
     */
    CODE_EAN(9),
    /**
     * NOM_FABRICANT
     */
    NOM_FABRICANT(10),
    /**
     * TECHNO_RACCO
     */
    TECHNO_RACCO(11),
    /**
     * ADR_CODE_INSEE
     */
    ADR_CODE_INSEE(12),
    /**
     * DATE_CREATION
     */
    DATE_CREATION(13),
    /**
     * DATE_MODIFICATION
     */
    DATE_MODIFICATION(14);

    /**
     * The position in CSV
     */
    private int _position;

    /**
     * Default constructor
     *
     * @param position
     *          The position
     */
    Header(int position)
    {
      _position = position;
    }

    /**
     * @return the position
     */
    public int getPosition()
    {
      return _position;
    }
  }

  /**
   * DECODEUR_TV
   */
  public final static String DECODEUR_TV = "DECODEUR_TV"; //$NON-NLS-1$

  /**
   * LIGNE_FIXE
   */
  public final static String LIGNE_FIXE = "LIGNE_FIXE"; //$NON-NLS-1$

  /**
   * The writer
   */
  private BufferedWriter _writer;

  /**
   * The csv printer
   */
  private CSVPrinter _csvPrinter;

  /**
   * Current line in buffer
   */
  private Integer _lineCount;

  /**
   * Number of lines permited on buffer to call flush
   */
  private Integer _linesToFlush;

  /**
   * Writer retour
   */
  private Retour _retour;

  /**
   * File Name
   */
  private String _fileName;

  /**
   * @param fileName_p
   *          The filename The number of lines to call flush
   * @param linesToFlush_p
   *          The number of lines to call flush
   * @throws IOException
   *           IOException
   *
   */
  public LienEqtPaDecodeurTvWriter(String fileName_p, Integer linesToFlush_p) throws IOException
  {
    _retour = RetourFactory.createOkRetour();
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    _lineCount = 0;

    _writer = Files.newBufferedWriter(Paths.get(fileName_p));
    _csvPrinter = new CSVPrinter(_writer, CSVFormat.newFormat(';').withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(Header.class));

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
    _writer.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> lines = this.getRecords(pfi_p, dateDemande_p);
    for (List<String> line : lines)
    {
      write(tracabilite_p, line);
    }
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param pfi_p
   *          The PFI
   * @return lines
   */
  private List<List<String>> getRecords(PFI pfi_p, LocalDate dateDemande_p)
  {
    List<List<String>> lines = new ArrayList<>();
    if (nonNull(pfi_p.getEquipementDeclare()))
    {
      List<EquipementDeclare> eqDeclareList = pfi_p.getEquipementDeclare().stream().filter(eq -> DECODEUR_TV.equals(eq.getTypeEquipement())).collect(Collectors.toList());
      if (nonNull(eqDeclareList))
      {
        for (EquipementDeclare eqDeclare : eqDeclareList)
        {
          List<LienEquipementPA> lienEquipementPAList = pfi_p.getLienEquipementPA().stream().filter(lEqPa -> eqDeclare.getNoEquipement().equals(lEqPa.getNoEquipement())).collect(Collectors.toList());
          if (nonNull(lienEquipementPAList))
          {
            for (LienEquipementPA lienEqPa : lienEquipementPAList)
            {
              if (nonNull(lienEqPa) //
                  && "BSS_GP".equals(pfi_p.getClientOperateur()) //$NON-NLS-1$
                  && dateDemande_p.isEqual(lienEqPa.getDateModification().toLocalDate()))
              {
                List<String> csvLine = new ArrayList<>(Arrays.asList(new String[Header.values().length]));
                csvLine.set(Header.CLIENT_OPERATEUR.getPosition(), pfi_p.getClientOperateur());
                csvLine.set(Header.NO_COMPTE.getPosition(), pfi_p.getNoCompte());
                csvLine.set(Header.NO_EQUIPEMENT.getPosition(), lienEqPa.getNoEquipement());
                csvLine.set(Header.ID_PA.getPosition(), lienEqPa.getIdFonctionnelPa());
                csvLine.set(Header.STATUT.getPosition(), CSVWriterUtils.getCsvValue(lienEqPa.getStatut()));
                csvLine.set(Header.SERIAL_NUMBER.getPosition(), eqDeclare.getNoIdentifiant());
                csvLine.set(Header.TYPE.getPosition(), eqDeclare.getTypeEquipement());
                csvLine.set(Header.MODELE.getPosition(), eqDeclare.getModele());
                csvLine.set(Header.ADR_MAC_TV.getPosition(), eqDeclare.getMacAddressTv());
                csvLine.set(Header.CODE_EAN.getPosition(), eqDeclare.getCodeEan());
                csvLine.set(Header.NOM_FABRICANT.getPosition(), eqDeclare.getNomFabricant());

                PA pa = pfi_p.getPa().stream().filter(p -> LIGNE_FIXE.equals(p.getTypePA()) && p.getIdentifiantFonctionnelPA().equals(lienEqPa.getIdFonctionnelPa())).findFirst().orElse(null);
                if (nonNull(pa) && nonNull(pa.getPaTypeLigneFixe()))
                {
                  InfoBrutBssGp infoBBss = pa.getPaTypeLigneFixe().getInfoBrutBssGp();
                  if (nonNull(infoBBss))
                  {
                    AccesTechnique accesTec = infoBBss.getAccesTechnique();
                    if (nonNull(accesTec))
                    {
                      csvLine.set(Header.TECHNO_RACCO.getPosition(), accesTec.getTechnologieAcces());
                    }
                    if (nonNull(infoBBss.getAdresseInstallation()))
                    {
                      csvLine.set(Header.ADR_CODE_INSEE.getPosition(), infoBBss.getAdresseInstallation().getCodeInsee());
                    }
                  }
                }
                csvLine.set(Header.DATE_CREATION.getPosition(), CSVWriterUtils.getCsvValue(lienEqPa.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
                csvLine.set(Header.DATE_MODIFICATION.getPosition(), CSVWriterUtils.getCsvValue(lienEqPa.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
                lines.add(csvLine);
              }
            }
          }
        }
      }
    }
    return lines;
  }

  /**
   * Add lines to buffer or write them on file if buffer size is greater then max permited
   *
   * @param tracabilite_p
   *          the Tracabilite
   * @param line_p
   *          lines to be inserted in the file
   */
  private synchronized void write(Tracabilite tracabilite_p, List<String> line_p)
  {
    try
    {
      _csvPrinter.printRecord(line_p);
      _lineCount++;
      if (_lineCount >= _linesToFlush)
      {
        _csvPrinter.flush();
        _lineCount = 0;
      }
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }

}
