/*******************************************************************************
* $Id: Action.java 15669 2019-01-11 10:46:05Z asoares $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0287.structs;

/**
 * The enum of the uri parameter action.
 *
 * @author asoares
 * @version ($Revision: 15669 $ $Date: 2019-01-11 11:46:05 +0100 (ven. 11 janv. 2019) $)
 */
public enum Action
{
  /**
   * Create files
   */
  EXTRACTION("extraction"), //$NON-NLS-1$

  /**
   * Send files
   */
  ENVOIE("envoie"); //$NON-NLS-1$

  /**
   * Compares the input value against the values of the {@link Action}.
   *
   * @param value_p
   *          the value to compare
   * @return {@link Action}
   */
  public static Action fromValue(String value_p)
  {
    for (Action action : Action.values())
    {
      if (action._value.equalsIgnoreCase(value_p))
      {
        return action;
      }
    }
    return null;
  }

  /**
   * The value
   */
  private final String _value;

  /**
   * The constructor.
   *
   * @param value_p
   *          the value
   */
  private Action(String value_p)
  {
    _value = value_p;
  }

  /**
   * @return value
   */
  public String value()
  {
    return _value;
  }
}
