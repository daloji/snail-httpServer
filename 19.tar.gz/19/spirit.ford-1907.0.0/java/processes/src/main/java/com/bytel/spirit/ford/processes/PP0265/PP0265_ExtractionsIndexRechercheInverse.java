package com.bytel.spirit.ford.processes.PP0265;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.cxf.helpers.FileUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier;
import com.bytel.spirit.common.activities.shared.BL4300_EnvoyerFichier;
import com.bytel.spirit.common.ford.config.ConfigurationFluxExtraction;
import com.bytel.spirit.common.ford.config.GenericProcessConfig;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0265.writers.IndexRecherchePfiWriter;
import com.bytel.spirit.ford.shared.misc.processes.FordProcessSkeleton;
import com.bytel.spirit.ford.shared.misc.processes.writers.IGenericWriter;
import com.bytel.spirit.ford.shared.types.GenericProcessConfigValidator;
import com.bytel.spirit.ford.shared.types.GenericRequestParameters;
import com.bytel.spirit.saab.connectors.air.AIRDatabaseProxy;
import com.bytel.spirit.saab.connectors.air.IIndexRecherchePfiCallback;

/**
 *
 * @author pcarreir
 * @version ($Revision: 22820 $ $Date: 2019-06-17 10:36:59 +0200 (lun. 17 juin 2019) $)
 */
public class PP0265_ExtractionsIndexRechercheInverse extends FordProcessSkeleton<IGenericWriter<IndexRecherchePfi>, IndexRecherchePfi> implements IIndexRecherchePfiCallback
{
  /**
   *
   * @author pcarreir
   * @version ($Revision: 22820 $ $Date: 2019-06-17 10:36:59 +0200 (lun. 17 juin 2019) $)
   */
  public static final class PP0265_ExtractionsIndexRechercheInverseContext extends Context
  {
    /**
     * The serial version UID
     */
    private static final long serialVersionUID = -1425386512974494053L;

    /**
     * The current process state
     */
    private State _state = State.PP0265_BL001;

    /**
     * Contains the process retour.
     */
    private Retour _processRetour;

    /**
     * Contains the process configuration
     */
    private transient GenericProcessConfig _configurationPP0265;

    /**
     * Contains the execution mode.
     */
    private String _modeExecution;

    /**
     * The flux id
     */
    private String _idFluxExtraction;

    /**
     * Constains the ThreadPoolExecutor.
     */
    private ThreadPoolExecutor _threadPoolExecutor;

    /**
     * Contains the future result of the submitted task for the ThreadPoolExecutor
     */
    List<Future<Retour>> _threadPoolExecutorResult = Collections.synchronizedList(new ArrayList<>());

    /**
     * Contains the writers.
     */
    private List<IGenericWriter<IndexRecherchePfi>> _writers = new ArrayList<>();

    /**
     * @return the configurationPP0255
     */
    public GenericProcessConfig getConfigurationPP0265()
    {
      return _configurationPP0265;
    }

    /**
     * @return the idFluxExtraction
     */
    public String getIdFluxExtraction()
    {
      return _idFluxExtraction;
    }

    /**
     * @return the modeExecution
     */
    public String getModeExecution()
    {
      return _modeExecution;
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the threadPoolExecutor
     */
    public ThreadPoolExecutor getThreadPoolExecutor()
    {
      return _threadPoolExecutor;
    }

    /**
     * @return the nsfWriters
     */
    public List<IGenericWriter<IndexRecherchePfi>> getWriters()
    {
      return new ArrayList<>(_writers);
    }

    /**
     * @param configurationPP0265_p
     *          the configurationPP0265 to set
     */
    public void setConfigurationPP0265(GenericProcessConfig configurationPP0265_p)
    {
      _configurationPP0265 = configurationPP0265_p;
    }

    /**
     * @param idFluxExtraction_p
     *          the idFluxExtraction to set
     */
    public void setIdFluxExtraction(String idFluxExtraction_p)
    {
      _idFluxExtraction = idFluxExtraction_p;
    }

    /**
     * @param modeExecution_p
     *          the modeExecution to set
     */
    public void setModeExecution(String modeExecution_p)
    {
      _modeExecution = modeExecution_p;
    }

    /**
     * @param processRetour_p
     *          the processRetour to set
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param threadPoolExecutor_p
     *          the threadPoolExecutor to set
     */
    public void setThreadPoolExecutor(ThreadPoolExecutor threadPoolExecutor_p)
    {
      _threadPoolExecutor = threadPoolExecutor_p;
    }

    /**
     * @param nsfWriters_p
     *          the nsfWriters to set
     */
    public void setWriters(List<IGenericWriter<IndexRecherchePfi>> nsfWriters_p)
    {
      _writers = new ArrayList<>(nsfWriters_p);
    }
  }

  /**
   * PP0265 states
   *
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PP0265_BL001(MandatoryProcessState.PRC_START),
    /**
     * The next step to execute is: BL100
     */
    PP0265_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL101
     */
    PP0265_BL101(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL200
     */
    PP0265_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL902
     */
    PP0265_BL901(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL902
     */
    PP0265_BL902(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL903
     */
    PP0265_BL903(MandatoryProcessState.PRC_RUNNING),
    /**
     * The next step to execute is: BL904
     */
    PP0265_BL904(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL910
     */
    PP0265_BL910(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL920
     */
    PP0265_BL920(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PP0265_CALLBACK(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PP0265_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = -2449444866274281651L;

  /**
   * The message for MESSAGE_AUCUNE_INDEX_RECHERCHE_PFI log.
   */
  private static final String MESSAGE_AUCUNE_INDEX_RECHERCHE_PFI = Messages.getString("PP0265.AucuneIndexRecherchePfi"); //$NON-NLS-1$

  /**
   * The SPIRIT-AIR-PFI flux id
   */
  private static final String SPIRIT_AIR_PFI = "SPIRIT-AIR-PFI"; //$NON-NLS-1$

  /**
   * The process context.
   */
  private PP0265_ExtractionsIndexRechercheInverseContext _processContext;

  @Override
  public Retour consume(Tracabilite tracabilite_p, IndexRecherchePfi indexRecherchePfi_p) throws RavelException
  {
    //Cette méthode est appélée par un seul thread dans le connecteur Cassandra (c'est le même thread que celui qui exécute
    //ce processus).
    //Plus cette méthode est appelée, plus la liste _processContext._threadPoolExecutorResult grossit.
    //Pour donner un ordre d'idée, un fichier d'extract de ST PFS MAIL de 600 Mo contient 4 millions de lignes.
    //Il n'est donc pas raisonnable de stocker 4 millions de Future dans la liste  _processContext._threadPoolExecutorResult.
    //Une solution simple à ce problème: si la liste _processContext._threadPoolExecutorResult atteind la taille de la blocking queue (waitingFileSize = 100),
    //alors  on attend le resultat de ces 100 taches. Une fois les 100 taches terminées, on vide la liste _processContext._threadPoolExecutorResult
    //avant de rappeler le BL910_PushIdInExecutor.
    //Ainsi, la taille de liste _processContext._threadPoolExecutorResult sera toujours limitée en mémoire et puis on evite le risque de pousser dans une file pleine.
    //Quoi qu'il en soit:
    // - Si les writers sont rapides, la fonction d'attente BL903_WaitForTasksCompletion sera rapide également.
    // - Si les writers sont  lents, la fonction BL903_WaitForTasksCompletion attendra plus longtemps la fin des tâches.
    if (_processContext._threadPoolExecutorResult.size() == _processContext.getConfigurationPP0265().getWaitingFileSize())
    {
      Retour retour = BL903_WaitForTasksCompletion(tracabilite_p, _processContext.getConfigurationPP0265(), _processContext._threadPoolExecutorResult);
      if (!RetourFactory.isRetourOK(retour))
      {
        _processContext.setProcessRetour(retour);
        return retour;
      }

      _processContext._threadPoolExecutorResult.clear();
    }

    // Call BL110
    _processContext.setState(State.PP0265_BL910);
    Retour retourBL910 = BL910_PushIdInExecutor(tracabilite_p, _processContext.getConfigurationPP0265(), indexRecherchePfi_p, _processContext.getWriters(), _processContext.getThreadPoolExecutor(), _processContext._threadPoolExecutorResult);
    _processContext.setProcessRetour(retourBL910);

    return retourBL910;
  }

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    if (retour_p != null)
    {
      return MarshallTools.marshall(retour_p);
    }
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PP0265_ExtractionsIndexRechercheInverseContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request arg0, Tracabilite arg1) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, MESSAGE_UNEXPECTED_CONTINUE);
  }

  @Override
  protected void exitKOMetroLog(String arg0)
  {
    // Not required for now in Ravel
  }

  @Override
  protected Pair<Retour, IGenericWriter<IndexRecherchePfi>> getWriter(Tracabilite tracabilite_p, String extractionName_p, String filePath_p, String fileName_p, int nbLinesToFlush_p)
  {
    try
    {
      switch (extractionName_p)
      {
        case SPIRIT_AIR_PFI:
          return new Pair<>(RetourFactory.createOkRetour(), new IndexRecherchePfiWriter(filePath_p, fileName_p, nbLinesToFlush_p));
        default:
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("Common.NSFWriterFactory.invalidExtractionName"), extractionName_p)), null); //$NON-NLS-1$
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, fileName_p, e.getMessage())));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(MESSAGE_ERROR_WRITING_FILE, fileName_p, e.getMessage())), null);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      // Call BL001
      _processContext.setState(State.PP0265_BL001);
      Pair<Retour, GenericRequestParameters> bl001Return = PP0265_BL001_VerifierDonnees(tracabilite_p, request_p);
      _processContext.setProcessRetour(bl001Return._first);

      if (RetourFactory.isRetourOK(bl001Return._first))
      {
        _processContext.setModeExecution(bl001Return._second.getModeExecution());
        _processContext.setIdFluxExtraction(bl001Return._second.getIdFluxExtraction());

        if (PRODUIRE_EXTRACTIONS.equals(_processContext.getModeExecution()))
        {
          // Call BL100
          _processContext.setState(State.PP0265_BL100);
          Retour retourBL100 = PP0265_BL100_ProduireFichierExtraction(tracabilite_p, _processContext.getIdFluxExtraction());
          _processContext.setProcessRetour(retourBL100);

          if (RetourFactory.isRetourKO(retourBL100))
          {
            // if extraction errors, we should erase the previously created files
            deleteAllFilesInWorkPath(tracabilite_p, _processContext.getConfigurationPP0265().getCheminRepTravail(), _processContext.getModeExecution(), _processContext.getConfigurationPP0265().getExtensionFichierTemporaire());
          }
        }
        else
        {
          // Call BL200
          _processContext.setState(State.PP0265_BL200);
          Retour retourBL200 = PP0265_BL200_TransfererFichierExtraction(tracabilite_p, _processContext.getIdFluxExtraction());
          _processContext.setProcessRetour(retourBL200);
        }
      }
    }
    catch (Exception ex)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, ex.getMessage()));
    }
    finally
    {
      endSynchronousProcess(request_p, _processContext.getProcessRetour());
    }

    // Set Process Retour
    this.setRetour(_processContext.getProcessRetour());
    _processContext.setState(State.PP0265_END);
  }

  /**
   * Porte la vérification que l’ensemble des paramètres obligatoires de la configuration du processus sont définies.
   *
   * @param tracabilite_p
   *          The tracability
   * @param request_p
   *          The process request
   *
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Pair<Retour, GenericRequestParameters> PP0265_BL001_VerifierDonnees(Tracabilite tracabilite_p, Request request_p) throws RavelException
  {
    // Get url parameters
    Pair<Retour, GenericRequestParameters> paramsFromRequest = getParamsFromRequest(request_p);

    if (RetourFactory.isRetourNOK(paramsFromRequest._first))
    {
      return new Pair<>(paramsFromRequest._first, null);
    }

    // Load config
    String configPP0265Param = getConfigParameter(PARAM_CONFIG_PATH);

    if (!StringTools.isNullOrEmpty(configPP0265Param))
    {
      try
      {
        Path configPP0255Path = Paths.get(configPP0265Param);
        String configPP0255File = new String(Files.readAllBytes(configPP0255Path));
        _processContext.setConfigurationPP0265(MarshallTools.unmarshall(GenericProcessConfig.class, configPP0255File));
      }
      catch (Exception exception)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_FILE_ERROR, exception.getMessage())), null);
      }
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, PARAM_CONFIG_PATH)), null);
    }

    // Check config parameters
    String chaineNomParam = GenericProcessConfigValidator.checkInexistantParams(_processContext.getConfigurationPP0265());
    if (chaineNomParam.length() > 0)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_PARAMETRES_CONFIGURATION_MANQUANTES, chaineNomParam)), null);
    }

    // Check flux ids
    String chaineNomFlux = GenericProcessConfigValidator.checkFluxId(_processContext.getConfigurationPP0265(), SPIRIT_AIR_PFI);
    if (chaineNomFlux.length() > 0)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_UNAUTHORIZED_FLUX_ID, chaineNomFlux)), null);
    }

    // Validate flux id
    boolean idFluxExtractionValid = GenericProcessConfigValidator.isIdFluxExtractionValid(paramsFromRequest._second.getIdFluxExtraction(), SPIRIT_AIR_PFI);
    if (!idFluxExtractionValid)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_UNAUTHORIZED_FLUX_ID, paramsFromRequest._second.getIdFluxExtraction())), null);
    }

    return new Pair<>(RetourFactory.createOkRetour(), paramsFromRequest._second);
  }

  /**
   * Cette activité permet de produire l'ensemble le fichier d'extractions.
   *
   * @param tracabilite_p
   *          The tracability
   * @param idFluxExtractions_p
   *          The flux id
   *
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP0265_BL100_ProduireFichierExtraction(Tracabilite tracabilite_p, String idFluxExtractions_p) throws RavelException
  {
    switch (idFluxExtractions_p)
    {
      case SPIRIT_AIR_PFI:
        _processContext.setState(State.PP0265_BL101);
        Retour retourBL101 = PP0265_BL101_ProduireFichierIndexRecherchePfi(tracabilite_p);
        _processContext.setProcessRetour(retourBL101);

        return retourBL101;
      default:
        break;
    }

    return _processContext.getProcessRetour();
  }

  /**
   * L'extraction SPIRIT-AIR-PFI est construite à partir des index de recherche Pfi inversé.
   *
   * @param tracabilite_p
   *          The tracability
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP0265_BL101_ProduireFichierIndexRecherchePfi(Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      // Call BL901
      _processContext.setState(State.PP0265_BL901);
      Pair<Retour, List<IGenericWriter<IndexRecherchePfi>>> retourBL901 = BL901_InitWriters(tracabilite_p, _processContext.getConfigurationPP0265(), Collections.singletonList(_processContext.getIdFluxExtraction()), _processContext.getModeExecution());
      _processContext.setProcessRetour(retourBL901._first);

      if (RetourFactory.isRetourKO(retourBL901._first))
      {
        return retourBL901._first;
      }

      // Store writers on context
      _processContext.setWriters(retourBL901._second);

      // Set state
      _processContext.setState(State.PP0265_BL902);
      Pair<Retour, ThreadPoolExecutor> retourBL902 = BL902_InitExecutor(tracabilite_p, _processContext.getConfigurationPP0265());
      _processContext.setThreadPoolExecutor(retourBL902._second);

      if (RetourFactory.isRetourKO(retourBL902._first))
      {
        return retourBL902._first;
      }

      // Call AIR Callback
      _processContext.setState(State.PP0265_CALLBACK);
      ConnectorResponse<Retour, Nothing> allIndexRecherchePfiRetour = AIRDatabaseProxy.getInstance().getAllIndexRecherchePfi(tracabilite_p, this);
      _processContext.setProcessRetour(allIndexRecherchePfiRetour._first);
      Retour retourAIR = allIndexRecherchePfiRetour._first;

      // Call BL903
      _processContext.setState(State.PP0265_BL903);
      Retour retourBL903 = BL903_WaitExecutor(tracabilite_p, _processContext.getConfigurationPP0265(), retourBL902._second, _processContext._threadPoolExecutorResult);
      _processContext.setProcessRetour(retourBL903);

      // Check Returns
      if (RetourFactory.isRetourKO(retourAIR))
      {
        if (IMegSpiritConsts.TIMEOUT.equals(retourAIR.getDiagnostic()))
        {
          return retourAIR;
        }
        else if (IMegConsts.DONNEE_INCONNUE.equals(retourAIR.getDiagnostic()))
        {
          // Log
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(MESSAGE_AUCUNE_INDEX_RECHERCHE_PFI, _processContext.getModeExecution(), tracabilite_p.getIdCorrelationByTel())));
          return RetourFactory.createOkRetour();
        }
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_LECTURE_IMPOSSIBLE);
      }
      else if (RetourFactory.isRetourKO(retourBL903))
      {
        return retourBL903;
      }
    }
    catch (RavelException e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_LECTURE_IMPOSSIBLE);
    }
    finally
    {
      // Call BL904
      _processContext.setState(State.PP0265_BL904);
      BL904_CloseWriters(tracabilite_p, _processContext.getWriters(), _processContext.getConfigurationPP0265().getExtensionFichierTemporaire());
    }

    // Return OK
    return RetourFactory.createOkRetour();
  }

  /**
   * Cette activité permet de : <br>
   * - Transférer/déposer le(s) fichier(s) d'extractions dans le répertoire de travail vers un répertoire se trouvant
   * sur un serveur distant tel que spécifié en configuration<br>
   * - Supprimer les fichiers temporaires <br>
   * Les fichiers transférés sont déplacés dans le répertoire des fichiers traités en succès.
   *
   * @param tracabilite_p
   *          The tracability
   * @param idFluxExtractions_p
   *          The flux id
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP0265_BL200_TransfererFichierExtraction(Tracabilite tracabilite_p, String idFluxExtractions_p) throws RavelException
  {
    // Get configuration
    GenericProcessConfig configurationPP0265 = _processContext.getConfigurationPP0265();
    Pair<Retour, ConfigurationFluxExtraction> fluxExtraction = getConfigurationFluxExtraction(configurationPP0265, idFluxExtractions_p);

    if (RetourFactory.isRetourNOK(fluxExtraction._first))
    {
      return fluxExtraction._first;
    }

    // Get file list
    ConfigurationFluxExtraction matchingConfigFlux = fluxExtraction._second;

    String cheminRepTravail = configurationPP0265.getCheminRepTravail();

    File directory = new File(cheminRepTravail);
    if (directory.list().length >= 1)
    {
      List<File> files = FileUtils.getFiles(new File(cheminRepTravail), matchingConfigFlux.getPattern());
      for (File file : files)
      {
        try
        {
          if (file.getName().endsWith(configurationPP0265.getExtensionFichierTemporaire()))
          {
            // (systime - retentionTime)
            LocalDateTime expiredDate = DateTimeManager.getInstance().now().minusSeconds(configurationPP0265.getDureeRetentionTmp());

            // Date de Modification
            LocalDateTime modifiedDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(file.lastModified()), ZoneId.systemDefault());

            // Si Date de Modification du fichier sur le filer < sysdate - oConfigurationPP0255.dureeRetentionTmp
            if (modifiedDate.isBefore(expiredDate))
            {
              // Call BL3400
              BL3400_SupprimerFichier bl3400 = new BL3400_SupprimerFichier.BL3400_SupprimerFichierBuilder()//
                  .fileName(file.getName()) //
                  .repertoire(cheminRepTravail) //
                  .tracabilite(tracabilite_p) //
                  .build();
              bl3400.execute(this);
            }
          }
          else
          {
            // Call BL4300_EnvoyerFichier
            BL4300_EnvoyerFichier envoyerFichier = new BL4300_EnvoyerFichier.BL4300_EnvoyerFichierBuilder() //
                .tracabilite(tracabilite_p) //
                .chaineConnexion(addFileToURI(matchingConfigFlux.getChaineConnexion(), file.getName())) //
                .nomFichier(file.getName()) //
                .repertoire(cheminRepTravail) //
                .build();
            envoyerFichier.execute(this);
            Retour bl4300Retour = envoyerFichier.getRetour();

            if (RetourFactory.isRetourNOK(bl4300Retour))
            {
              if (IMegConsts.CAT1.equals(bl4300Retour.getCategorie()))
              {
                // Call BL1200_DeplacerFichier
                BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder() //
                    .tracabilite(tracabilite_p) //
                    .nomFichier(file.getName()) //
                    .repertoireSrc(configurationPP0265.getCheminRepTravail()) //
                    .repertoireDes(configurationPP0265.getCheminRepArchiveErreur()) //
                    .build();
                deplacerFichier.execute(this);
              }
              else
              {
                // Renvoyer Erreur et Sortir du traitement
                return bl4300Retour;
              }
            }
            else
            {
              // Call BL1200_DeplacerFichier
              BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder() //
                  .tracabilite(tracabilite_p) //
                  .nomFichier(file.getName()) //
                  .repertoireSrc(configurationPP0265.getCheminRepTravail()) //
                  .repertoireDes(configurationPP0265.getCheminRepArchiveSucces()) //
                  .build();
              deplacerFichier.execute(this);
            }
          }
        }
        catch (Exception exception)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
          return RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage());
        }
      }
    }
    return RetourFactory.createOkRetour();
  }
}
