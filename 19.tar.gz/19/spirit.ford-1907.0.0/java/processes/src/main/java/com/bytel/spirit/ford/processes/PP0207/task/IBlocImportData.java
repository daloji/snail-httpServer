/*******************************************************************************
* $Id: IBlocImportData.java 13227 2018-11-15 13:48:27Z jstrub $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.task;

import java.util.List;

import com.bytel.ravel.common.csv.CSVLine;
import com.bytel.ravel.services.process.task.ITransitionData;

/**
 * Type of data shared between tasks : contains the line of a bloc.
 *
 * @author jstrub
 * @version ($Revision: 13227 $ $Date: 2018-11-15 14:48:27 +0100 (jeu. 15 nov. 2018) $)
 * @param <T>
 *          type of bloc's lines
 */
public interface IBlocImportData<T> extends ITransitionData
{

  /**
   * Add a line to the bloc.
   *
   * @param line_p
   *          the line to add
   */
  void addLine(CSVLine line_p);

  /**
   *
   * @return the bloc
   */
  List<T> getBloc();

  /**
   * @return true if current bloc is empty, false otherwise
   */
  boolean isEmpty();

  /**
   * @return the size of bloc
   */
  int size();

}
