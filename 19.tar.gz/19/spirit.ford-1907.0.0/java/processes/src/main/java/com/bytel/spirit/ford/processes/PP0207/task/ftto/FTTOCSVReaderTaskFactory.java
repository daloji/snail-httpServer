/*******************************************************************************
* $Id: FTTOCSVReaderTaskFactory.java 17245 2019-02-15 14:36:03Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0207.task.ftto;

import java.io.File;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.List;

import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.services.process.task.ITransitionData;
import com.bytel.spirit.ford.processes.PP0207.task.AbstractCSVReaderTaskFactory;
import com.bytel.spirit.ford.processes.PP0207.task.ImportContext;
import com.bytel.spirit.saab.connectors.res.geod.type.TypeReferentiel;

/**
 * CSV Reader factory for FTTO couverture multi-threaded import. <br />
 * See {@link AbstractCSVReaderTaskFactory} for more information.
 *
 * @author jstrub
 * @version ($Revision: 17245 $ $Date: 2019-02-15 15:36:03 +0100 (ven. 15 févr. 2019) $)
 */
public class FTTOCSVReaderTaskFactory extends AbstractCSVReaderTaskFactory<FTTOCSVReaderTask>
{

  /**
   * Task factory for only one file.
   *
   * @param csvFile_p
   *          CSV file
   * @param sep_p
   *          CSV separator
   * @param charset_p
   *          CSV charset
   * @param blocSize_p
   *          bloc size
   * @param typeReferentiel_p
   *          type referentiel
   * @param context_p
   *          context
   */
  public FTTOCSVReaderTaskFactory(File csvFile_p, char sep_p, Charset charset_p, Integer blocSize_p, TypeReferentiel typeReferentiel_p, ImportContext context_p)
  {
    super(Arrays.asList(csvFile_p), sep_p, charset_p, blocSize_p, typeReferentiel_p, context_p);
  }

  /**
   * Task factory for a list of file.
   *
   * @param csvFiles_p
   *          List of CSV file
   * @param sep_p
   *          CSV separator
   * @param charset_p
   *          CSV charset
   * @param blocSize_p
   *          bloc size
   * @param typeReferentiel_p
   *          type referentiel
   * @param context_p
   *          context
   */
  public FTTOCSVReaderTaskFactory(List<File> csvFiles_p, char sep_p, Charset charset_p, Integer blocSize_p, TypeReferentiel typeReferentiel_p, ImportContext context_p)
  {
    super(csvFiles_p, sep_p, charset_p, blocSize_p, typeReferentiel_p, context_p);
  }

  @Override
  public FTTOCSVReaderTask newTask(ITransitionData arg0_p) throws RavelException
  {
    File nextFile = _csvFiles.poll();
    if (nextFile != null)
    {
      return new FTTOCSVReaderTask(nextFile, _sep, _charset, _blocSize, _typeReferentiel, _context);
    }

    // No new task is needed
    return null;
  }

}
