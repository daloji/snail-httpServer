/*******************************************************************************
* $Id: ParametreSim.java 16692 2019-02-05 13:40:36Z sdiop $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0258.structs;

import java.io.Serializable;

/**
 *
 * @author sdiop
 * @version ($Revision: 16692 $ $Date: 2019-02-05 14:40:36 +0100 (mar. 05 févr. 2019) $)
 */
public class ParametreSim implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * imsi de la carte sim
   */
  private String _imsi;

  /**
   * iccid de la carte sim
   */
  private String _iccid;

  /**
   * iccid swappé
   */
  private String _iccidSwappe;

  /**
   * @return the iccid
   */
  public String getIccid()
  {
    return _iccid;
  }

  /**
   * @return the iccidSwappe
   */
  public String getIccidSwappe()
  {
    return _iccidSwappe;
  }

  /**
   * @return the imsi
   */
  public String getImsi()
  {
    return _imsi;
  }

  /**
   * @param iccid_p
   *          the iccid to set
   */
  public void setIccid(String iccid_p)
  {
    _iccid = iccid_p;
  }

  /**
   * @param iccidSwappe_p
   *          the iccidSwappe to set
   */
  public void setIccidSwappe(String iccidSwappe_p)
  {
    _iccidSwappe = iccidSwappe_p;
  }

  /**
   * @param imsi_p
   *          the imsi to set
   */
  public void setImsi(String imsi_p)
  {
    _imsi = imsi_p;
  }

}
