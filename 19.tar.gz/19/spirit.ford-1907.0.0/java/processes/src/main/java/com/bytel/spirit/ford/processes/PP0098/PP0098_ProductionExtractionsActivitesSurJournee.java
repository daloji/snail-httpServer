/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098;

import static java.util.Objects.isNull;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.cxf.common.util.CollectionUtils;
import org.apache.cxf.helpers.FileUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier;
import com.bytel.spirit.common.activities.shared.BL1200_DeplacerFichier.BL1200_DeplacerFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL1400_EmettreFichier;
import com.bytel.spirit.common.activities.shared.BL1400_EmettreFichier.BL1400_EmettreFichierBuilder;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier.BL3400_SupprimerFichierBuilder;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.processes.PP0098.generator.INSFWriter;
import com.bytel.spirit.ford.processes.PP0098.generator.NSFWriterFactory;
import com.bytel.spirit.ford.processes.PP0098.generator.NSFWriterFactory.NSFWriterFactoryRetour;
import com.bytel.spirit.ford.processes.PP0098.structs.ConfigExtractionActiviteSurJournee;
import com.bytel.spirit.ford.processes.PP0098.structs.PP0098_BL102_Retour;
import com.bytel.spirit.ford.shared.misc.processes.workers.WaitBlockingQueue;
import com.bytel.spirit.saab.connectors.rpg.IChangedIdPfiCallback;
import com.bytel.spirit.saab.connectors.rpg.RPGDatabaseProxy;
import com.bytel.spirit.saab.connectors.rpg.type.RefChangedIdPfi;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public final class PP0098_ProductionExtractionsActivitesSurJournee extends SpiritProcessSkeleton implements IChangedIdPfiCallback
{
  /**
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public static final class PP0098_ProductionExtractionsActivitesSurJourneeContext extends Context
  {

    /**
     * The generated UUID
     */
    private static final long serialVersionUID = 3078771395986700030L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PP0098_BL001;

    /**
     * Contains the process configuration
     */
    private ConfigExtractionActiviteSurJournee _configExtractionActiviteSurJournee;

    /**
     * Contains the current dateTime.
     */
    private String _dateTime;

    /**
     * Yesterday Date.
     */
    private LocalDate _yesterday;

    /**
     * Contains the execution mode.
     */
    private String _modeExecution;

    /**
     * Constains the PFI already writed.
     */
    private Map<String, AtomicInteger> _pfiCounter;

    /**
     * multiThread Flag
     */
    private boolean _multiThreadFlag;

    /**
     * Constains the ThreadPoolExecutor.
     */
    private ThreadPoolExecutor _threadPoolExecutor;

    /**
     * Contains the future result of the submitted task for the ThreadPoolExecutor
     */
    List<Future<?>> _threadPoolExecutorResult = Collections.synchronizedList(new ArrayList<>());

    /**
     * Constains the NSF writers.
     */
    private List<INSFWriter> _nsfWriters;

    /**
     * addThreadPoolExecutorResult
     *
     * @param element_p
     *          element
     */
    public void addThreadPoolExecutorResult(Future<?> element_p)
    {
      _threadPoolExecutorResult.add(element_p);
    }

    /**
     * @return value of configExtractionActiviteSurJournee
     */
    public ConfigExtractionActiviteSurJournee getConfigExtractionActiviteSurJournee()
    {
      return _configExtractionActiviteSurJournee;
    }

    /**
     * @return value of dateTime
     */
    public String getDateTime()
    {
      return _dateTime;
    }

    /**
     * @return value of modeExecution
     */
    public String getModeExecution()
    {
      return _modeExecution;
    }

    /**
     * @return value of nsfWriters
     */
    public List<INSFWriter> getNsfWriters()
    {
      return new ArrayList<>(_nsfWriters);
    }

    /**
     * @return value of pfiCounter
     */
    public Map<String, AtomicInteger> getPfiCounter()
    {
      return _pfiCounter;
    }

    /**
     * @return the state
     */
    public final State getState()
    {
      return _state;
    }

    /**
     * @return value of threadPoolExecutor
     */
    public ThreadPoolExecutor getThreadPoolExecutor()
    {
      return _threadPoolExecutor;
    }

    /**
     * @return the yesterday
     */
    public LocalDate getYesterday()
    {
      return _yesterday;
    }

    /**
     * @return the multiThreadFlag
     */
    public boolean isMultiThreadFlag()
    {
      return _multiThreadFlag;
    }

    /**
     * @param configExtractionActiviteSurJournee_p
     *          The configExtractionActiviteSurJournee to set.
     */
    public void setConfigExtractionActiviteSurJournee(ConfigExtractionActiviteSurJournee configExtractionActiviteSurJournee_p)
    {
      _configExtractionActiviteSurJournee = configExtractionActiviteSurJournee_p;
    }

    /**
     * @param dateTime_p
     *          The dateTime to set.
     */
    public void setDateTime(String dateTime_p)
    {
      _dateTime = dateTime_p;
    }

    /**
     * @param modeExecution_p
     *          The modeExecution to set.
     */
    public void setModeExecution(String modeExecution_p)
    {
      _modeExecution = modeExecution_p;
    }

    /**
     * @param multiThreadFlag_p
     *          the multiThreadFlag to set
     */
    public void setMultiThreadFlag(boolean multiThreadFlag_p)
    {
      _multiThreadFlag = multiThreadFlag_p;
    }

    /**
     * @param nsfWriters_p
     *          The nsfWriters to set.
     */
    public void setNsfWriters(List<INSFWriter> nsfWriters_p)
    {
      _nsfWriters = new ArrayList<>(nsfWriters_p);
    }

    /**
     * @param pfiCounter_p
     *          The pfiCounter to set.
     */
    public void setPfiCounter(Map<String, AtomicInteger> pfiCounter_p)
    {
      _pfiCounter = pfiCounter_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public final void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param threadPoolExecutor_p
     *          The threadPoolExecutor to set.
     */
    public void setThreadPoolExecutor(ThreadPoolExecutor threadPoolExecutor_p)
    {
      _threadPoolExecutor = threadPoolExecutor_p;
    }

    /**
     * @param yesterday_p
     *          the yesterday to set
     */
    public void setYesterday(LocalDate yesterday_p)
    {
      _yesterday = yesterday_p;
    }

  }

  /**
   * PP0098 states
   *
   */
  public enum State
  {
    /**
     * First step to execute
     */
    PP0098_BL001(MandatoryProcessState.PRC_START),

    /**
     * The next step to execute is: BL100
     */
    PP0098_BL100(MandatoryProcessState.PRC_RUNNING),

    /**
     * The next step to execute is: BL101
     */
    PP0098_BL101(MandatoryProcessState.PRC_RUNNING),

    /**
     * The next step to execute is: BL102
     */
    PP0098_BL102(MandatoryProcessState.PRC_RUNNING),

    /**
     * The next step to execute is: BL103
     */
    PP0098_BL103(MandatoryProcessState.PRC_RUNNING),

    /**
     * The next step to execute is: BL104
     */
    PP0098_BL104(MandatoryProcessState.PRC_RUNNING),

    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * Tableau listant les activités autorisées
   */
  private enum FichiersAutorises
  {
    /**
     * PFI
     */
    PFI("SPIRIT-PFI"), //$NON-NLS-1$
    /**
     * PALFXDSL
     */
    PALFXDSL("SPIRIT-PALFXDSL"), //$NON-NLS-1$
    /**
     * PALFFTTH
     */
    PALFFTTH("SPIRIT-PALFFTTH"), //$NON-NLS-1$
    /**
     * PALFFTTLA
     */
    PALFFTTLA("SPIRIT-PALFFTTLA"), //$NON-NLS-1$
    /**
     * PAVOIP
     */
    PAVOIP("SPIRIT-PAVOIP"), //$NON-NLS-1$
    /**
     * PAFAX
     */
    PAFAX("SPIRIT-PAFAX"), //$NON-NLS-1$
    /**
     * PACA
     */
    PACA("SPIRIT-PACA"), //$NON-NLS-1$
    /**
     * PATV
     */
    PATV("SPIRIT-PATV"), //$NON-NLS-1$
    /**
     * LIENSAPALF
     */
    LIENSAPALF("SPIRIT-LIENSAPALF"), //$NON-NLS-1$
    /**
     * LIENSAPAVOIP
     */
    LIENSAPAVOIP("SPIRIT-LIENSAPAVOIP"), //$NON-NLS-1$
    /**
     * LIENSAPAFAX
     */
    LIENSAPAFAX("SPIRIT-LIENSAPAFAX"), //$NON-NLS-1$
    /**
     * LIENSAPATV
     */
    LIENSAPATV("SPIRIT-LIENSAPATV"), //$NON-NLS-1$
    /**
     * LIENSAPACA
     */
    LIENSAPACA("SPIRIT-LIENSAPACA"), //$NON-NLS-1$
    /**
     * LIENEQTPAMODEM
     */
    LIENEQTPAMODEM("SPIRIT-LIENEQTPAMODEM"), //$NON-NLS-1$
    /**
     * LIENEQTPADECODEURTV
     */
    LIENEQTPADECODEURTV("SPIRIT-LIENEQTPADECODEURTV"), //$NON-NLS-1$
    /**
     * LIENEQTPAONT
     */
    LIENEQTPAONT("SPIRIT-LIENEQTPAONT"), //$NON-NLS-1$
    /**
     * LIENEQTPACARTETHD
     */
    LIENEQTPACARTETHD("SPIRIT-LIENEQTPACARTETHD"), //$NON-NLS-1$
    /**
     * LIENEQTPAMODEMDECODEURTV
     */
    LIENEQTPAMODEMDECODEURTV("SPIRIT-LIENEQTPAMODEMDECODEURTV"), //$NON-NLS-1$
    /**
     * NBPHOTO
     */
    NBPHOTO("SPIRIT-NBPHOTOSURPFI"); //$NON-NLS-1$
    /**
     *
     */
    private final String _name;

    /**
     * @param name_p
     *          name
     */
    private FichiersAutorises(final String name_p)
    {
      this._name = name_p;
    }

    /**
     * @return name
     *
     */
    public String getName()
    {
      return _name;
    }
  }

  /**
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  class PFIWorker implements Runnable
  {
    /**
     * The tracability.
     */
    private Tracabilite _tracabilite;

    /**
     * The object from the RPG call.
     */
    private RefChangedIdPfi _refChangedIdPfi;

    /**
     * The writers.
     */
    private List<INSFWriter> _writers;

    /**
     *
     * @param tracabilite_p
     *          tracabilite
     * @param refChangedIdPfi_p
     *          refChangedIdPfi
     * @param writers_p
     *          writers_p
     */
    public PFIWorker(Tracabilite tracabilite_p, RefChangedIdPfi refChangedIdPfi_p, List<INSFWriter> writers_p)
    {
      _tracabilite = tracabilite_p;
      _refChangedIdPfi = refChangedIdPfi_p;
      _writers = new ArrayList<>(writers_p);
    }

    @Override
    public void run()
    {
      // Call BL120
      PP0098_BL120_DumpPFI(_tracabilite, _refChangedIdPfi, _writers);
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = 7294311004932276610L;

  /**
   * The TransfererFichiers constant.
   */
  private static final String TRANSFERER_FICHIERS = "TransfererFichiers"; //$NON-NLS-1$

  /**
   * The ProduireExtractions constant.
   */
  private static final String PRODUIRE_EXTRACTIONS = "ProduireExtractions"; //$NON-NLS-1$

  /**
   * The message for BL110 TIMEOUT log.
   */
  private static final String MESSAGE_BL110_TIMEOUT = Messages.getString("PP0098.BL110.Timeout"); //$NON-NLS-1$

  /**
   * Technical exception message
   */
  private static final String TECHNICAL_EXCEPTION_MESSAGE = Messages.getString("PP0098.TechnicalExceptionMessage"); //$NON-NLS-1$

  /**
   * The message for MESSAGE_UNEXPECTED_CONTINUE log.
   */
  private static final String MESSAGE_UNEXPECTED_CONTINUE = Messages.getString(MessageFormat.format("PP0098.UnexpectedContinueProcessReceived", PP0098_ProductionExtractionsActivitesSurJournee.class.getSimpleName())); //$NON-NLS-1$

  /**
   * The message for MESSAGE_LECTURE_IMPOSSIBLE log.
   */
  private static final String MESSAGE_LECTURE_IMPOSSIBLE = Messages.getString("PP0098.BL100.LectureImpossible"); //$NON-NLS-1$

  /**
   * The message for MESSAGE_AUCUNE_PFI log.
   */
  private static final String MESSAGE_AUCUNE_PFI = Messages.getString("PP0098.BL100.AucunePFI"); //$NON-NLS-1$

  /**
   * The message for MESSAGE_DEPLACER_FICHIER log.
   */
  private static final String MESSAGE_DEPLACER_FICHIER = Messages.getString("PP0098.BL101.LOG.DeplacerFichier"); //$NON-NLS-1$
  /**
   * The message for Supprimer fichier log
   */
  private static final String MESSAGE_FICHIER_SUPPRIME = Messages.getString("PP0098.BL100.FichierSupprime"); //$NON-NLS-1$

  /**
   * The message for MESSAGE_GET_PFI log.
   */
  private static final String MESSAGE_GET_PFI = Messages.getString("PP0098.BL120.LOG.GetPFI"); //$NON-NLS-1$

  /**
   * The message for AUCUNE_EXTRACTION log.
   */
  private static final String MESSAGE_AUCUNE_EXTRACTION = Messages.getString("PP0098.BL101.NoExtractionInConfig"); //$NON-NLS-1$

  /**
   * The message for BL103 TIMEOUT ERROR log.
   */
  private static final String MESSAGE_BL103_TIMEOUT_ERROR = Messages.getString("PP0098.BL103.TimeoutError"); //$NON-NLS-1$

  /**
   * The message for SERVICE_TIERS_INDISPONIBLE log.
   */
  private static final String SERVICE_TIERS_INDISPONIBLE = Messages.getString("PP0098.BL200.ServiceTiersIndisponible"); //$NON-NLS-1$

  /**
   * The message for DEPLACEMENT_FICHIER_INVALIDE log.
   */
  private static final String DEPLACEMENT_FICHIER_INVALIDE = Messages.getString("PP0098.BL200.DeplacementFichierInvalide"); //$NON-NLS-1$

  /**
   * Nombre de PFI traites en parallele
   */
  private static final String POOL_SIZE = "poolSize"; //$NON-NLS-1$

  /**
   * Taille de la file d attente
   */
  private static final String WAITING_FILE_SIZE = "waitingFileSize"; //$NON-NLS-1$

  /**
   * Temps d attente de finalisation des traitements
   */
  private static final String ENDING_TIMEOUT = "endingTimeout"; //$NON-NLS-1$

  /**
   * Temps maximal d attente pour ajouter un PFI dans la file d attnte
   */
  private static final String PUSH_TIMEOUT = "pushTimeout"; //$NON-NLS-1$

  /**
   * Chemin d acces au repertoire de travail du processus
   */
  private static final String CHEMIN_REP_TRAVAIL = "cheminRepTravail"; //$NON-NLS-1$

  /**
   * Chemin d acces au repertoire d archivage des fichiers traites en succes pour le processus
   */
  private static final String CHEMIN_REP_ARCHIVE_SUCCES = "cheminRepArchiveSucces"; //$NON-NLS-1$

  /**
   * Chemin d acces au repertoire d archivage des fichiers traites en erreur pour le processus
   */
  private static final String CHEMIN_REP_ARCHIVE_ERREUR = "cheminRepArchiveErreur"; //$NON-NLS-1$

  /**
   * Designe l environnement PROD, REC, ITG, PREP sur lequel le processus est execute
   */
  private static final String ENVIRONNEMENT = "environnement"; //$NON-NLS-1$

  /**
   * Repertoire du serveur distant GAS ou seront deposes les fichiers d extractions
   */
  private static final String CHEMIN_REP_DEPOT_DISTANT = "cheminRepDepotDistant"; //$NON-NLS-1$

  /**
   * Tableau listant les fichiers d extraction a produire
   */
  private static final String LISTE_EXTRACTION_ACTIVITE_A_PRODUIRE = "listeExtractionActiviteAProduire"; //$NON-NLS-1$

  /**
   * Numero des lignes pour appeller le flush
   */
  private static final String LINES_TO_FLUSH = "linesToFlush"; //$NON-NLS-1$

  /**
   * FPT Connector Id
   */
  private static final String CHAINE_CONNEXION = "chaineConnexion"; //$NON-NLS-1$

  /**
   * ActivateMultiThread parameter name
   */
  private static final String MULTI_THREAD_FLAG_PARAM = "activateMultiThread"; //$NON-NLS-1$

  /**
   * Mode execution parameter name
   */
  private static final String MODE_EXECUTION_PARAM = "modeExecution"; //$NON-NLS-1$

  /**
   * Name of the activity PP0098_BL100_ProduireListeFichierExtractionSurJournee
   */
  private static final String PP0098_BL100_PRODUIRELISTEFICHIEREXTRACTIONSURJOURNEE = "PP0098_BL100_ProduireListeFichierExtractionSurJournee"; //$NON-NLS-1$

  /**
   * Name of the activity PP0098_BL200_TransfererListeFichierExtractionJournee
   */
  private static final String PP0098_BL200_TRANSFERERLISTEFICHIEREXTRACTIONJOURNEE = "PP0098_BL200_TransfererListeFichierExtractionJournee"; //$NON-NLS-1$

  /**
   * The process context.
   */
  private PP0098_ProductionExtractionsActivitesSurJourneeContext _processContext;

  @Override
  public Retour consume(Tracabilite tracabilite_p, RefChangedIdPfi refChangedIdPfi_p) throws RavelException
  {
    //Cette méthode est appélée par un seul thread dans le connecteur Cassandra (c'est le même thread que celui qui exécute
    //ce processus).
    //Plus cette méthode est appelée, plus la liste _processContext._threadPoolExecutorResult grossit.
    //Pour donner un ordre d'idée, un fichier d'extract de ST PFS MAIL de 600 Mo contient 4 millions de lignes.
    //Il n'est donc pas raisonnable de stocker 4 millions de Future dans la liste  _processContext._threadPoolExecutorResult.
    //Une solution simple à ce problème: si la liste _processContext._threadPoolExecutorResult atteind la taille de la blocking queue (waitingFileSize = 100),
    //alors  on attend le resultat de ces 100 taches. Une fois les 100 taches terminées, on vide la liste _processContext._threadPoolExecutorResult
    //avant de rappeler le BL910_PushIdInExecutor.
    //Ainsi, la taille de liste _processContext._threadPoolExecutorResult sera toujours limitée en mémoire et puis on evite le risque de pousser dans une file pleine.
    //Quoi qu'il en soit:
    // - Si les writers sont rapides, la fonction d'attente BL903_WaitForTasksCompletion sera rapide également.
    // - Si les writers sont  lents, la fonction BL903_WaitForTasksCompletion attendra plus longtemps la fin des tâches.
    if (_processContext._threadPoolExecutorResult.size() == _processContext.getConfigExtractionActiviteSurJournee().getWaitingFileSize())
    {
      Retour retour = PP0098_BL103_WaitForTasksCompletion(tracabilite_p);
      if (!RetourFactory.isRetourOK(retour))
      {
        return retour;
      }

      _processContext._threadPoolExecutorResult.clear();
    }

    // Call BL110
    return PP0098_BL110_PushIdInExecutor(tracabilite_p, refChangedIdPfi_p, _processContext.getNsfWriters(), _processContext.getThreadPoolExecutor());
  }

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    if (retour_p != null)
    {
      return MarshallTools.marshall(retour_p);
    }
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PP0098_ProductionExtractionsActivitesSurJourneeContext();
    _processContext._pfiCounter = new ConcurrentHashMap<>();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    throw new RavelException(ExceptionType.UNEXPECTED, ErrorCode.PRCESS_00001, MESSAGE_UNEXPECTED_CONTINUE);
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel

  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel

  }

  @LogStartProcess
  @Override
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retourPP0098 = null;
    try
    {
      // Load config
      loadConfiguration(tracabilite_p);

      // Get url parameters
      String modeExecution = getModeExecutionFromRequest(request_p);
      _processContext.setModeExecution(modeExecution);

      // get Yesterday date
      _processContext.setYesterday(LocalDate.now().minusDays(1));

      // Call BL001
      retourPP0098 = PP0098_BL001_VerifierDonnees(tracabilite_p, modeExecution, request_p);
      if (RetourFactory.isRetourOK(retourPP0098))
      {
        if (PRODUIRE_EXTRACTIONS.equals(modeExecution))
        {
          retourPP0098 = PP0098_BL100_ProduireListeFichierExtractionSurJournee(tracabilite_p);

          if (RetourFactory.isRetourKO(retourPP0098))
          { //if extraction errors, we should erase the previously created files
            deleteAllFilesInWorkPath(tracabilite_p);
          }
        }
        else
        {
          retourPP0098 = PP0098_BL200_TransfererListeFichierExtractionJournee(tracabilite_p);
        }
      }
    }
    catch (Exception ex)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
      retourPP0098 = RetourFactory.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, ex.getMessage());
    }
    finally
    {
      endSynchronousProcess(request_p, retourPP0098);
    }

    // Log Retour
    this.setRetour(retourPP0098);
    _processContext.setState(State.ENDED);
  }

  /**
   * Checks if there is any mandatory parameter missing in the ConfigExtractionActiviteSurJournee.
   *
   * @param cfigExtractActSurJournee_p
   *          the configExtractionActiviteSurJournee
   * @return String with the name of the parameters that are missing
   */
  private String checkInexistanceParam(ConfigExtractionActiviteSurJournee cfigExtractActSurJournee_p)
  {
    StringJoiner chaineNomParam = new StringJoiner(";"); //$NON-NLS-1$

    if (isNull(cfigExtractActSurJournee_p.getPoolSize()))
    {
      chaineNomParam.add(POOL_SIZE);
    }

    if (isNull(cfigExtractActSurJournee_p.getWaitingFileSize()))
    {
      chaineNomParam.add(WAITING_FILE_SIZE);
    }

    if (isNull(cfigExtractActSurJournee_p.getEndingTimeout()))
    {
      chaineNomParam.add(ENDING_TIMEOUT);
    }

    if (isNull(cfigExtractActSurJournee_p.getPushTimeout()))
    {
      chaineNomParam.add(PUSH_TIMEOUT);
    }

    if (isNull(cfigExtractActSurJournee_p.getLinesToFlush()))
    {
      chaineNomParam.add(LINES_TO_FLUSH);
    }

    if (StringTools.isNullOrEmpty(cfigExtractActSurJournee_p.getChaineConnexion()))
    {
      chaineNomParam.add(CHAINE_CONNEXION);
    }

    if (StringTools.isNullOrEmpty(cfigExtractActSurJournee_p.getCheminRepTravail()))
    {
      chaineNomParam.add(CHEMIN_REP_TRAVAIL);
    }

    if (StringTools.isNullOrEmpty(cfigExtractActSurJournee_p.getCheminRepArchiveSucces()))
    {
      chaineNomParam.add(CHEMIN_REP_ARCHIVE_SUCCES);
    }

    if (StringTools.isNullOrEmpty(cfigExtractActSurJournee_p.getCheminRepArchiveErreur()))
    {
      chaineNomParam.add(CHEMIN_REP_ARCHIVE_ERREUR);
    }

    if (StringTools.isNullOrEmpty(cfigExtractActSurJournee_p.getEnvironnement()))
    {
      chaineNomParam.add(ENVIRONNEMENT);
    }

    if (CollectionUtils.isEmpty(cfigExtractActSurJournee_p.getListeExtractionActiviteAProduire()))
    {
      chaineNomParam.add(LISTE_EXTRACTION_ACTIVITE_A_PRODUIRE);
    }

    return chaineNomParam.toString();
  }

  /**
   * Deletes all files in the work directory
   *
   * @param tracabilite_p
   *          The tracabilite
   */
  private void deleteAllFilesInWorkPath(Tracabilite tracabilite_p)
  {
    String workPath = _processContext.getConfigExtractionActiviteSurJournee().getCheminRepTravail();
    List<File> files = FileUtils.getFiles(new File(workPath), ".+\\.csv$"); //$NON-NLS-1$

    // Process file list
    for (File f : files)
    {
      BL3400_SupprimerFichier bl3400 = new BL3400_SupprimerFichierBuilder()//
          .tracabilite(tracabilite_p)// set tracabilite
          .repertoire(workPath)// set file location Path
          .fileName(f.getName())// set file name
          .build();
      try
      {
        bl3400.execute(this);

        if (RetourFactory.isRetourOK(bl3400.getRetour()))
        {
          String logMessage = MessageFormat.format(MESSAGE_FICHIER_SUPPRIME, _processContext.getModeExecution(), tracabilite_p.getIdCorrelationSpirit(), f.getName());
          RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, logMessage));
        }
      }
      catch (RavelException exception)
      {
        // Log
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      }
    }
  }

  /**
   * Method to end synchronous process
   *
   * @param request_p
   *          Request parameter
   * @param retour_p
   *          Retour parameter
   *
   * @throws RavelException
   *           RavelException
   */
  private void endSynchronousProcess(Request request_p, Retour retour_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      String result = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(retour_p);
      ravelResponse.setResult(result);

      Response response = new Response(isRetourOK(retour_p) ? ErrorCode.OK_00200 : ErrorCode.KO_00404, ravelResponse);
      request_p.setResponse(response);
    }
  }

  /**
   * Get a Integer value from the configuration
   *
   * @param key
   *          The key from which to get the value
   * @return The configuration value
   */
  private Integer getIntegerConfigParameter(String key)
  {
    String value = getConfigParameter(key);
    return StringTools.isNotNullOrEmpty(value) ? Integer.valueOf(value) : null;
  }

  /**
   * Gets the URL parameters into the ProcessContext
   *
   * @param request_p
   *          request
   * @return Value of the modeExecution
   *
   */
  private String getModeExecutionFromRequest(Request request_p)
  {

    // get url parameters
    List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();

    for (Parameter parametre : urlParametersType)
    {
      if (parametre.getName().equalsIgnoreCase(MODE_EXECUTION_PARAM))
      {
        return parametre.getValue();
      }
    }
    return null; //parameter is not set
  }

  /**
   * Load process configuration into ConfigExtractionActiviteSurJournee Object
   *
   * @param tracabilite_p
   *          tracabilite
   */
  private void loadConfiguration(Tracabilite tracabilite_p)
  {
    if (_processContext.getConfigExtractionActiviteSurJournee() == null)
    {
      _processContext.setConfigExtractionActiviteSurJournee(new ConfigExtractionActiviteSurJournee());
    }
    _processContext.getConfigExtractionActiviteSurJournee().setPoolSize(getIntegerConfigParameter(POOL_SIZE));
    _processContext.getConfigExtractionActiviteSurJournee().setWaitingFileSize(getIntegerConfigParameter(WAITING_FILE_SIZE));
    _processContext.getConfigExtractionActiviteSurJournee().setEndingTimeout(getIntegerConfigParameter(ENDING_TIMEOUT));
    _processContext.getConfigExtractionActiviteSurJournee().setPushTimeout(getIntegerConfigParameter(PUSH_TIMEOUT));
    _processContext.getConfigExtractionActiviteSurJournee().setLinesToFlush(getIntegerConfigParameter(LINES_TO_FLUSH));
    _processContext.getConfigExtractionActiviteSurJournee().setChaineConnexion(getConfigParameter(CHAINE_CONNEXION));
    _processContext.getConfigExtractionActiviteSurJournee().setCheminRepTravail(getConfigParameter(CHEMIN_REP_TRAVAIL));
    _processContext.getConfigExtractionActiviteSurJournee().setCheminRepArchiveSucces(getConfigParameter(CHEMIN_REP_ARCHIVE_SUCCES));
    _processContext.getConfigExtractionActiviteSurJournee().setCheminRepArchiveErreur(getConfigParameter(CHEMIN_REP_ARCHIVE_ERREUR));
    _processContext.getConfigExtractionActiviteSurJournee().setEnvironnement(getConfigParameter(ENVIRONNEMENT));
    _processContext.getConfigExtractionActiviteSurJournee().setCheminRepDepotDistant(getConfigParameter(CHEMIN_REP_DEPOT_DISTANT));
    String listeExtractionActiviteAProduire = getConfigParameter(LISTE_EXTRACTION_ACTIVITE_A_PRODUIRE);
    if (StringTools.isNotNullOrEmpty(listeExtractionActiviteAProduire))
    {
      ArrayList<String> extractionActiviteAProduireList = new ArrayList<>();
      Stream.of(listeExtractionActiviteAProduire.split(";")).forEach(s -> extractionActiviteAProduireList.add(s.trim())); //$NON-NLS-1$

      _processContext.getConfigExtractionActiviteSurJournee().setListeExtractionActiviteAProduire(extractionActiviteAProduireList);
    }

    String multiThreadParam = getConfigParameter(MULTI_THREAD_FLAG_PARAM);
    if ((multiThreadParam == null) || "true".equalsIgnoreCase(multiThreadParam)) //$NON-NLS-1$
    {
      _processContext.setMultiThreadFlag(true);
    }
    else
    {
      _processContext.setMultiThreadFlag(false);
    }

    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "Configuration Values: " + _processContext.getConfigExtractionActiviteSurJournee().toString())); //$NON-NLS-1$

  }

  /**
   * Porte la vérification que l’ensemble des paramètres obligatoires de la configuration du processus sont définies.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param modeExecution_p
   *          the modeExecution
   * @param request_p
   *          request
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PP0098_BL001_VerifierDonnees(Tracabilite tracabilite_p, String modeExecution_p, Request request_p) throws RavelException
  {
    if (!PRODUIRE_EXTRACTIONS.equals(modeExecution_p) && !TRANSFERER_FICHIERS.equals(modeExecution_p))
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, Messages.getString("PP0098.BL001.ModeExecutionPasConnu")); //$NON-NLS-1$
    }

    ConfigExtractionActiviteSurJournee cfigExtractActSurJournee = _processContext.getConfigExtractionActiviteSurJournee();
    String chaineNomParam = checkInexistanceParam(cfigExtractActSurJournee);

    if (chaineNomParam.length() > 0)
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0098.BL001.ParametresConfigurationManquants"), chaineNomParam)); //$NON-NLS-1$
    }

    Path pathCheminRepTravail = Paths.get(cfigExtractActSurJournee.getCheminRepTravail());

    if (!Files.isDirectory(pathCheminRepTravail))
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0098.BL001.RepertoirePasExiste"), cfigExtractActSurJournee.getCheminRepTravail())); //$NON-NLS-1$
    }

    //Verification des droits d'ecriture sur le repertoire.
    //Test non pertinent sous Windows (setWritable non supporté après Java 6)
    //TU impossible car isWritable renvoie toujours true si root

    if (!Files.isWritable(pathCheminRepTravail))
    {
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.BL001.DirNotWritable"), pathCheminRepTravail)); //$NON-NLS-1$
    }

    if (PRODUIRE_EXTRACTIONS.equals(modeExecution_p) && cfigExtractActSurJournee.getListeExtractionActiviteAProduire().isEmpty())
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, Messages.getString("PP0098.BL001.AucuneExtractionConfiguree")); //$NON-NLS-1$
    }

    for (String file : cfigExtractActSurJournee.getListeExtractionActiviteAProduire())
    {
      boolean isPresentInActiviteAutorise = false;
      for (int i = 0; i < FichiersAutorises.values().length; i++)
      {
        if (FichiersAutorises.values()[i].getName().equals(file))
        {
          isPresentInActiviteAutorise = true;
          break;
        }
      }
      if (!isPresentInActiviteAutorise)
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0098.BL001.FichierImpossible"), file)); //$NON-NLS-1$
      }
    }

    Path pathCheminRepArchiveSucces = Paths.get(cfigExtractActSurJournee.getCheminRepArchiveSucces());
    Path pathCheminRepArchiveErreur = Paths.get(cfigExtractActSurJournee.getCheminRepArchiveErreur());

    if (TRANSFERER_FICHIERS.equals(modeExecution_p))
    {
      if (!Files.isDirectory(pathCheminRepArchiveSucces))
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0098.BL001.RepertoirePasExiste"), cfigExtractActSurJournee.getCheminRepArchiveSucces())); //$NON-NLS-1$
      }

      if (!Files.isDirectory(pathCheminRepArchiveErreur))
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(Messages.getString("PP0098.BL001.RepertoirePasExiste"), cfigExtractActSurJournee.getCheminRepArchiveErreur())); //$NON-NLS-1$
      }
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * This activity allows the production of extraction files that represent a SPIRIT system
   *
   * @param tracabilite_p
   *          tracabilite
   * @return retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PP0098_BL100_ProduireListeFichierExtractionSurJournee(Tracabilite tracabilite_p) throws RavelException
  {
    // Set state
    _processContext.setState(State.PP0098_BL100);

    // Init BL retours
    Retour retourBL101;
    Retour retourRPG;
    Retour retourBL103;
    try
    {
      // Call BL101
      Pair<Retour, List<INSFWriter>> retourInitNSFWriters = PP0098_BL101_InitNSFWriters(tracabilite_p);
      retourBL101 = retourInitNSFWriters._first;

      // Store writers on context
      _processContext.setNsfWriters(retourInitNSFWriters._second);

      if (RetourFactory.isRetourKO(retourBL101))
      {
        retourBL101.setActivite(PP0098_BL100_PRODUIRELISTEFICHIEREXTRACTIONSURJOURNEE);
        return retourBL101;
      }

      // Call BL102
      PP0098_BL102_Retour retourBL102 = PP0098_BL102_InitExecutor(tracabilite_p);
      Retour ret = retourBL102.getRetour();
      if (RetourFactory.isRetourKO(ret))
      {
        ret.setActivite(PP0098_BL100_PRODUIRELISTEFICHIEREXTRACTIONSURJOURNEE);
        return ret;
      }

      // Call RPG
      ConnectorResponse<Retour, Nothing> retourIdPfiChangedOverGivenPeriod = RPGDatabaseProxy.getInstance().getIdPfiChangedOverGivenDate(tracabilite_p, _processContext.getYesterday(), this);
      retourRPG = retourIdPfiChangedOverGivenPeriod._first;

      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "RPG response:" + retourRPG.toString())); //$NON-NLS-1$

      // Call BL103
      retourBL103 = PP0098_BL103_WaitExecutor(tracabilite_p, retourBL102.getPfiIdPoolExecutor());

      // Check Returns
      if (RetourFactory.isRetourKO(retourRPG))
      {
        retourRPG.setActivite(PP0098_BL100_PRODUIRELISTEFICHIEREXTRACTIONSURJOURNEE);
        if (IMegSpiritConsts.TIMEOUT.equals(retourRPG.getDiagnostic()))
        {
          return retourRPG;
        }
        else if (IMegConsts.DONNEE_INCONNUE.equals(retourRPG.getDiagnostic()))
        {
          // Log
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, MessageFormat.format(MESSAGE_AUCUNE_PFI, _processContext.getModeExecution(), tracabilite_p.getIdCorrelationByTel(), DateTimeFormatPattern.yyyyMMdd.format(_processContext.getYesterday()))));
          return RetourFactory.createOkRetour();
        }
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_LECTURE_IMPOSSIBLE);
      }
      else if (RetourFactory.isRetourKO(retourBL103))
      {
        retourBL103.setActivite(PP0098_BL100_PRODUIRELISTEFICHIEREXTRACTIONSURJOURNEE);
        return retourBL103;
      }
    }
    catch (RavelException re)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, re));
      return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.LECTURE_INDISPONIBLE, MESSAGE_LECTURE_IMPOSSIBLE);
    }
    finally
    {
      // Call BL104
      PP0098_BL104_CloseNSFWriters(tracabilite_p, _processContext.getNsfWriters());
    }
    // Return OK
    return RetourFactory.createOkRetour();
  }

  /**
   * This activity initialiazes the NSFWriter objects for the files in the configuration.
   *
   * @param tracabilite_p
   *          tracabilite
   * @return List of writers
   */
  @LogProcessBL
  private Pair<Retour, List<INSFWriter>> PP0098_BL101_InitNSFWriters(Tracabilite tracabilite_p)
  {
    // Set state
    _processContext.setState(State.PP0098_BL101);

    // Get file list
    String cheminRepTravail = _processContext.getConfigExtractionActiviteSurJournee().getCheminRepTravail();
    String archiveErreur = _processContext.getConfigExtractionActiviteSurJournee().getCheminRepArchiveErreur();
    List<File> files = FileUtils.getFiles(new File(cheminRepTravail), ".+\\.csv$"); //$NON-NLS-1$

    // Process file list
    files.forEach(file -> {
      // Call BL1200_DeplacerFichier
      BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(file.getName()).repertoireSrc(cheminRepTravail).repertoireDes(archiveErreur).build();
      try
      {
        deplacerFichier.execute(this);
      }
      catch (RavelException e_p)
      {
        // Log
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e_p));
      }

      // Log operation
      String logMessage = MessageFormat.format(MESSAGE_DEPLACER_FICHIER, _processContext.getModeExecution(), tracabilite_p.getIdCorrelationSpirit(), file.getName(), archiveErreur);
      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, logMessage));
    });

    if (CollectionUtils.isEmpty(_processContext.getConfigExtractionActiviteSurJournee().getListeExtractionActiviteAProduire()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.AUCUNE_EXTRACTION, MESSAGE_AUCUNE_EXTRACTION), Collections.emptyList());
    }

    // Current time
    _processContext.setDateTime(DateTimeFormatPattern.yyyyMMdd_underscore_HHmmss.format(LocalDateTime.now()));

    List<INSFWriter> writers = new ArrayList<>();
    List<String> lExtractionType = _processContext.getConfigExtractionActiviteSurJournee().getListeExtractionActiviteAProduire().stream()//
        .filter(s -> !s.equals("SPIRIT-NBPHOTOSURPFI")) //we dont want to init SPIRIT-NBPHOTOSURPFI  writer //$NON-NLS-1$
        .collect(Collectors.toList());

    for (String extractionType : lExtractionType)
    {
      // Get factory writer parameters
      String environnement = _processContext.getConfigExtractionActiviteSurJournee().getEnvironnement();
      Integer linesToFlush = _processContext.getConfigExtractionActiviteSurJournee().getLinesToFlush();

      // Add writer to list
      NSFWriterFactoryRetour nsfWriterFactoryRetour = NSFWriterFactory.getNSFWriter(tracabilite_p, extractionType, cheminRepTravail, environnement, linesToFlush, _processContext.getDateTime());
      if (RetourFactory.isRetourOK(nsfWriterFactoryRetour.getRetour()))
      {
        writers.add(nsfWriterFactoryRetour.getNSFWriter());
      }
      else if (IMegSpiritConsts.CREATION_FICHIER_INVALIDE.equals(nsfWriterFactoryRetour.getRetour().getDiagnostic()))
      { //could not create a file, so terminate treatment
        return new Pair<>(nsfWriterFactoryRetour.getRetour(), writers); //return writes list to call close writers later
      }
    }

    return new Pair<>(RetourFactory.createOkRetour(), writers);
  }

  /**
   * This activity initializes the execution pool and the semaphore.
   *
   * @param tracabilite_p
   *          tracabilite
   * @return The thread pool and semaphore.
   */
  @LogProcessBL
  private PP0098_BL102_Retour PP0098_BL102_InitExecutor(Tracabilite tracabilite_p)
  {
    // Set state
    _processContext.setState(State.PP0098_BL102);
    ThreadPoolExecutor threadPoolExecutor = null;

    if (_processContext.isMultiThreadFlag())
    {
      WaitBlockingQueue waitBlockingQueue = new WaitBlockingQueue(_processContext.getConfigExtractionActiviteSurJournee().getWaitingFileSize(), _processContext.getConfigExtractionActiviteSurJournee().getPushTimeout(), TimeUnit.MILLISECONDS);

      threadPoolExecutor = new ThreadPoolExecutor(_processContext.getConfigExtractionActiviteSurJournee().getPoolSize(), _processContext.getConfigExtractionActiviteSurJournee().getPoolSize(), 0 /* keep alive time */, TimeUnit.MILLISECONDS, waitBlockingQueue);

      _processContext.setThreadPoolExecutor(threadPoolExecutor);
    }

    return new PP0098_BL102_Retour(RetourFactory.createOkRetour(), threadPoolExecutor);
  }

  /**
   * This activity waits for the process end.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param pfiIdPoolExecutor_p
   *          pfiIdPoolExecutor
   * @return retour
   */
  @LogProcessBL
  private Retour PP0098_BL103_WaitExecutor(Tracabilite tracabilite_p, ThreadPoolExecutor pfiIdPoolExecutor_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    // Set state
    _processContext.setState(State.PP0098_BL103);

    if (_processContext.isMultiThreadFlag())
    {
      try
      {
        retour = PP0098_BL103_WaitForTasksCompletion(tracabilite_p);
      }
      finally
      {
        try
        {
          Integer endingTimeout = _processContext.getConfigExtractionActiviteSurJournee().getEndingTimeout();
          // Shutdown pool
          pfiIdPoolExecutor_p.shutdown();
          // Wait a while for existing tasks to terminate
          if (!pfiIdPoolExecutor_p.awaitTermination(endingTimeout, TimeUnit.MILLISECONDS))
          {
            pfiIdPoolExecutor_p.shutdownNow(); // Cancel currently executing tasks
            // Wait a while for tasks to respond to being cancelled
            if (!pfiIdPoolExecutor_p.awaitTermination(endingTimeout, TimeUnit.MILLISECONDS))
            {
              RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format("Pool did not terminate in {0} ms", endingTimeout))); //$NON-NLS-1$
            }
          }
        }
        catch (InterruptedException e_p)
        {
          // (Re-)Cancel if current thread also interrupted
          pfiIdPoolExecutor_p.shutdownNow();
          // Preserve interrupt status
          Thread.currentThread().interrupt();
        }
        catch (Exception e_p)
        {
          String exceptionMessage = (e_p.getCause() != null) && StringTools.isNotNullOrEmpty(e_p.getCause().getMessage()) ? e_p.getCause().getMessage() : e_p.getMessage();
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format("Unexpected error during pool shutdown: {0}", exceptionMessage))); //$NON-NLS-1$
        }
      }
    }
    return retour;
  }

  /**
   * Waits for tasks completion
   *
   * @param tracabilite_p
   *          tracabilite
   * @return a Retour OK if all tasks completed successfully
   */
  @LogProcessBL
  private Retour PP0098_BL103_WaitForTasksCompletion(Tracabilite tracabilite_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    if (_processContext.isMultiThreadFlag())
    {
      Integer endingTimeout = _processContext.getConfigExtractionActiviteSurJournee().getEndingTimeout();

      try
      {
        // gather all the future result
        for (Future<?> future : _processContext._threadPoolExecutorResult)
        {
          if (future != null)
          {
            future.get(endingTimeout, TimeUnit.MILLISECONDS);
          }
        }
      }
      catch (ExecutionException e_p)
      {
        String exceptionMessage = (e_p.getCause() != null) && StringTools.isNotNullOrEmpty(e_p.getCause().getMessage()) ? e_p.getCause().getMessage() : e_p.getMessage();
        String message = MessageFormat.format(TECHNICAL_EXCEPTION_MESSAGE, "ExecutionException", "PP0098_BL103_WaitExecutor", exceptionMessage, ExceptionTools.getExceptionLineAndFile(e_p.getCause() == null ? e_p : e_p.getCause())); //$NON-NLS-1$ //$NON-NLS-2$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, message);
      }
      catch (TimeoutException e_p)
      {
        String exceptionMessage = (e_p.getCause() != null) && StringTools.isNotNullOrEmpty(e_p.getCause().getMessage()) ? e_p.getCause().getMessage() : e_p.getMessage();
        String message = MessageFormat.format(TECHNICAL_EXCEPTION_MESSAGE, "TimeoutException", "PP0098_BL103_WaitExecutor", exceptionMessage, ExceptionTools.getExceptionLineAndFile(e_p.getCause() == null ? e_p : e_p.getCause())); //$NON-NLS-1$ //$NON-NLS-2$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.TIMEOUT, MESSAGE_BL103_TIMEOUT_ERROR);
      }
      catch (InterruptedException e_p)
      {
        String message = "Current thread interrupted while waiting for the computation to complete."; //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, message);
      }
      catch (Exception e_p)
      {
        String exceptionMessage = (e_p.getCause() != null) && StringTools.isNotNullOrEmpty(e_p.getCause().getMessage()) ? e_p.getCause().getMessage() : e_p.getMessage();
        String message = MessageFormat.format(TECHNICAL_EXCEPTION_MESSAGE, "Unexpected exception", "PP0098_BL103_WaitExecutor", exceptionMessage, ExceptionTools.getExceptionLineAndFile(e_p.getCause() == null ? e_p : e_p.getCause())); //$NON-NLS-1$ //$NON-NLS-2$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, message));
        retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, message);
      }
    }
    return retour;
  }

  /**
   * This activity closes the open files.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param writers_p
   *          writers
   */
  @LogProcessBL
  private void PP0098_BL104_CloseNSFWriters(Tracabilite tracabilite_p, List<INSFWriter> writers_p)
  {
    // Set state
    _processContext.setState(State.PP0098_BL104);

    writers_p.forEach(writer -> {
      try
      {
        writer.close();
      }
      catch (Exception e_p)
      {
        // Log
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e_p));
      }
    });

    // Get writer parameters
    String cheminRepTravail = _processContext.getConfigExtractionActiviteSurJournee().getCheminRepTravail();
    String environnement = _processContext.getConfigExtractionActiviteSurJournee().getEnvironnement();
    Integer linesToFlush = _processContext.getConfigExtractionActiviteSurJournee().getLinesToFlush();
    NSFWriterFactoryRetour factoryRetour = NSFWriterFactory.getNSFWriter(tracabilite_p, "SPIRIT-NBPHOTOSURPFI", cheminRepTravail, environnement, linesToFlush, _processContext.getDateTime(), _processContext.getPfiCounter()); //$NON-NLS-1$

    if (RetourFactory.isRetourOK(factoryRetour.getRetour()))
    {
      INSFWriter nbPhotoSurPFIWriter = null;
      try
      {
        nbPhotoSurPFIWriter = factoryRetour.getNSFWriter(); // get NbPhotoSurPfiWriter
        nbPhotoSurPFIWriter.dumpPFI(tracabilite_p, null, null); // Call dumpPFI
      }
      finally
      {
        try
        {
          if (nbPhotoSurPFIWriter != null)
          {
            nbPhotoSurPFIWriter.close();
          }
        }
        catch (Exception e_p)
        {
          // Log
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e_p));
        }
      }
    }
  }

  /**
   * This activity feeds the executor with the PFI to treat.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param refChangedIdPfi_p
   *          The object from the RPG call.
   * @param writers_p
   *          The list of writes.
   * @param threadPoolExecutor_p
   *          The thread pool executor.
   * @return retour
   */
  @LogProcessBL
  private Retour PP0098_BL110_PushIdInExecutor(Tracabilite tracabilite_p, RefChangedIdPfi refChangedIdPfi_p, List<INSFWriter> writers_p, ThreadPoolExecutor threadPoolExecutor_p)
  {
    // Increment pfi counter
    String key = refChangedIdPfi_p.getClientOperateur() + ";" + refChangedIdPfi_p.getNoCompte(); //$NON-NLS-1$
    if (_processContext.getPfiCounter().containsKey(key))
    {
      _processContext.getPfiCounter().get(key).incrementAndGet();

      // Log
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PP0098.BL110.LOG.End"))); //$NON-NLS-1$

      return RetourFactory.createOkRetour();
    }
    _processContext.getPfiCounter().putIfAbsent(key, new AtomicInteger(1));

    if (_processContext.isMultiThreadFlag())
    {
      // Add worker to execution pool
      PFIWorker pfiWorker = new PFIWorker(tracabilite_p, refChangedIdPfi_p, writers_p);

      Future<?> future;
      try
      {
        future = threadPoolExecutor_p.submit(pfiWorker);
      }
      catch (RejectedExecutionException e)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_BL110_TIMEOUT, refChangedIdPfi_p.getClientOperateur(), refChangedIdPfi_p.getNoCompte())));
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.TIMEOUT, MessageFormat.format(MESSAGE_BL110_TIMEOUT, refChangedIdPfi_p.getClientOperateur(), refChangedIdPfi_p.getNoCompte()));
      }

      // Set future result for error check
      _processContext.addThreadPoolExecutorResult(future);

    }
    else // no multithread
    {
      // Call BL120
      PP0098_BL120_DumpPFI(tracabilite_p, refChangedIdPfi_p, writers_p);
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * This activity dispatches the PFI to the writers
   *
   * @param tracabilite_p
   *          tracabilite
   * @param refChangedIdPfi_p
   *          The object from the RPG call.
   * @param writers_p
   *          The list of writes.
   */
  @LogProcessBL
  private void PP0098_BL120_DumpPFI(Tracabilite tracabilite_p, RefChangedIdPfi refChangedIdPfi_p, List<INSFWriter> writers_p)
  {
    try
    {
      // Call RPG
      ConnectorResponse<Retour, PFI> retourPfi = RPGDatabaseProxy.getInstance().getPfi(tracabilite_p, refChangedIdPfi_p.getClientOperateur(), refChangedIdPfi_p.getNoCompte());

      // Check return
      if (RetourFactory.isRetourKO(retourPfi._first))
      {
        String logMessage = MessageFormat.format(MESSAGE_GET_PFI, _processContext.getModeExecution(), tracabilite_p.getIdCorrelationSpirit(), refChangedIdPfi_p.getClientOperateur(), refChangedIdPfi_p.getNoCompte());
        RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, logMessage));
        return;
      }

      // Process writers
      for (INSFWriter writer : writers_p)
      {
        writer.dumpPFI(tracabilite_p, retourPfi._second, _processContext.getYesterday());
      }
    }
    catch (RavelException e_p)
    {
      // Log
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e_p));
    }
  }

  /**
   * This activity produces all extraction files that represent the activity of the SPIRIT system over a period of time
   *
   * @param tracabilite_p
   *          tracabilite parameter
   * @return return Retour
   * @throws RavelException
   *           Ravel exception
   */
  @LogProcessBL
  private Retour PP0098_BL200_TransfererListeFichierExtractionJournee(Tracabilite tracabilite_p) throws RavelException
  {
    // Get configuration
    ConfigExtractionActiviteSurJournee configExtractionActiviteSurJournee = _processContext.getConfigExtractionActiviteSurJournee();

    // Log
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "CheminRepDepotDistant: " + configExtractionActiviteSurJournee.getCheminRepDepotDistant())); //$NON-NLS-1$

    if (configExtractionActiviteSurJournee.getCheminRepDepotDistant() != null)
    {
      String cheminRepTravail = configExtractionActiviteSurJournee.getCheminRepTravail();
      String archiveErreur = configExtractionActiviteSurJournee.getCheminRepArchiveErreur();
      String chaineConnexion = configExtractionActiviteSurJournee.getChaineConnexion();

      File directory = new File(cheminRepTravail);
      if (directory.list().length >= 1)
      {

        List<File> files = FileUtils.getFiles(directory, ".+\\.csv$"); //$NON-NLS-1$
        if (files.size() > 0)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "Found " + files.size() + " files in work directory.")); //$NON-NLS-1$ //$NON-NLS-2$);
        }
        // Process file list
        for (File file : files)
        {
          // Call BL1400_EmettreFichier
          BL1400_EmettreFichier emettreFichier = new BL1400_EmettreFichierBuilder().tracabilite(tracabilite_p).chaineConnexion(chaineConnexion).nomFichier(file.getName()).repertoireSrc(cheminRepTravail).repertoireArchiveSucces(configExtractionActiviteSurJournee.getCheminRepArchiveSucces()).cheminRepDepotDistant(configExtractionActiviteSurJournee.getCheminRepDepotDistant()).build();

          try
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "Moving file  " + file.getName())); //$NON-NLS-1$
            emettreFichier.execute(this);
            Retour retour = emettreFichier.getRetour();

            if (IMegConsts.CAT2.equals(retour.getCategorie()) && SERVICE_TIERS_INDISPONIBLE.equals(retour.getDiagnostic()))
            {
              retour.setActivite(PP0098_BL200_TRANSFERERLISTEFICHIEREXTRACTIONJOURNEE);
              return retour;
            }
            else if (IMegConsts.CAT1.equals(retour.getCategorie()) && DEPLACEMENT_FICHIER_INVALIDE.equals(retour.getDiagnostic()))
            {
              // Call BL1200_DeplacerFichier
              BL1200_DeplacerFichier deplacerFichier = new BL1200_DeplacerFichierBuilder().tracabilite(tracabilite_p).nomFichier(file.getName()).repertoireSrc(cheminRepTravail).repertoireDes(archiveErreur).build();
              deplacerFichier.execute(this);
            }
          }
          catch (RavelException exception)
          {
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
            return RetourFactory.createNOK(IMegConsts.CAT10, exception.getErrorCode().toString(), exception.getMessage());
          }
        }
        return RetourFactory.createOkRetour();
      }

      RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, "PP0098:" + _processContext.getModeExecution() + ":" + IHttpHeadersConsts.X_REQUEST_ID.toUpperCase() + ": Aucun Fichier trouvé dans le répertoire " + cheminRepTravail)); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      return RetourFactory.createOkRetour();

    }
    return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "Les paramètres de connexion au serveur distant sont inconnus"); //$NON-NLS-1$
  }
}
