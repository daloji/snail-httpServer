package com.bytel.spirit.ford.processes.PP0207.task;

import java.io.File;
import java.nio.charset.Charset;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import com.bytel.ravel.services.process.task.IRavelTaskFactory;
import com.bytel.spirit.saab.connectors.res.geod.type.TypeReferentiel;

/**
 * Common abstract task factory implementation for CSV reading tasks. <br />
 * This factory is built will a list of files (or an unique file) and will create one task by file.
 *
 * @author jstrub
 * @version ($Revision: 17245 $ $Date: 2019-02-15 15:36:03 +0100 (ven. 15 févr. 2019) $)
 * @param <T>
 *          Type of concrete CSV reader task
 */
public abstract class AbstractCSVReaderTaskFactory<T extends AbstractCSVReaderTask> implements IRavelTaskFactory<T>
{

  /** Queue of files to import. */
  protected final Queue<File> _csvFiles;
  /** CSV Separator. */
  protected final char _sep;
  /** CSV charset. */
  protected final Charset _charset;
  /** Bloc size. */
  protected final Integer _blocSize;
  /** Type referentiel. */
  protected final TypeReferentiel _typeReferentiel;
  /** Import context. */
  protected final ImportContext _context;
  /** Description. */
  private final String _description;

  /**
   * Builds a CSV Reader task factory for a list of files.
   *
   * @param csvFiles_p
   *          List of CSV file
   * @param sep_p
   *          CSV separator
   * @param charset_p
   *          CSV charset
   * @param blocSize_p
   *          bloc size
   * @param typeReferentiel_p
   *          type referentiel
   * @param context_p
   *          context
   */
  public AbstractCSVReaderTaskFactory(List<File> csvFiles_p, char sep_p, Charset charset_p, Integer blocSize_p, TypeReferentiel typeReferentiel_p, ImportContext context_p)
  {
    // Initialize fields
    _csvFiles = new LinkedList<>(csvFiles_p);
    _sep = sep_p;
    _charset = charset_p;
    _blocSize = blocSize_p;
    _typeReferentiel = typeReferentiel_p;
    _context = context_p;

    // Compute a description
    _description = "CSV-Reader-" + typeReferentiel_p.name(); //$NON-NLS-1$
  }

  @Override
  public String description()
  {
    return _description;
  }

}
