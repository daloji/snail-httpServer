/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.structs;

import java.util.concurrent.ThreadPoolExecutor;

import com.bytel.ravel.common.business.generated.Retour;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PP0098_BL102_Retour
{
  /**
   * THe retour of the BL102.
   */
  private Retour _retour;

  /**
   * Extraction execution pool.
   */
  private ThreadPoolExecutor _pfiIdPoolExecutor;

  /**
   * Constructor
   * 
   * @param pfiIdPoolExecutor_p
   * @param semaphore_p
   */
  public PP0098_BL102_Retour(Retour retour_p, ThreadPoolExecutor pfiIdPoolExecutor_p)
  {
    _retour = retour_p;
    _pfiIdPoolExecutor = pfiIdPoolExecutor_p;
  }

  /**
   * @return value of pfiIdPoolExecutor
   */
  public ThreadPoolExecutor getPfiIdPoolExecutor()
  {
    return _pfiIdPoolExecutor;
  }

  /**
   * @return value of _retour
   */
  public Retour getRetour()
  {
    return _retour;
  }
}
