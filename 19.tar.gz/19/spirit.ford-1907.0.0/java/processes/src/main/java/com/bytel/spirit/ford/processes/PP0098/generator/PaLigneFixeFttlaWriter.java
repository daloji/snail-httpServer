package com.bytel.spirit.ford.processes.PP0098.generator;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe;
import com.bytel.spirit.ford.processes.Messages;
import com.bytel.spirit.ford.shared.misc.processes.writers.CSVWriterUtils;

/**
 *
 * @author vloureir
 * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
 */
public class PaLigneFixeFttlaWriter implements INSFWriter
{
  /**
   * Enum containing the Header specification for a PALFFTTLA CSV file type.
   *
   * @author vloureir
   * @version ($Revision: 19207 $ $Date: 2019-03-28 14:17:54 +0100 (jeu. 28 mars 2019) $)
   */
  public enum PALFFTTLAHeader
  {

    /**
     * CLIENT_OPERATEUR
     */
    CLIENT_OPERATEUR(0),

    /**
     * NO_COMPTE
     */
    NO_COMPTE(1),

    /**
     * ID_PA
     */
    ID_PA(2),

    /**
     * STATUT
     */
    STATUT(3),
    /**
     * ID_RACCO
     */
    ID_RACCO(4),

    /**
     * IS_PA_CIBLE
     */
    IS_PA_CIBLE(5),

    /**
     * IS_PA_PRINCIPAL
     */
    IS_PA_PRINCIPAL(6),

    /**
     * ID_PRISE
     */
    ID_PRISE(7),

    /**
     * ID_OSS
     */
    ID_OSS(8),

    /**
     * IS_PRO
     */
    IS_PRO(9),

    /**
     * ID_CLIENT_EXTERNE
     */
    ID_CLIENT_EXTERNE(10),

    /**
     * TECHNO_RACCO
     */
    TECHNO_RACCO(11),

    /**
     * ID_PROFIL_TECH
     */
    ID_PROFIL_TECH(12),

    /**
     * ADR_NUMERO
     */
    ADR_NUMERO(13),

    /**
     * ADR_IND_REPETITION
     */
    ADR_IND_REPETITION(14),

    /**
     * ADR_NOM_VOIE
     */
    ADR_NOM_VOIE(15),

    /**
     * ADR_CODE_POSTAL
     */
    ADR_CODE_POSTAL(16),

    /**
     * ADR_VILLE
     */
    ADR_VILLE(17),

    /**
     * ADR_CODE_INSEE
     */
    ADR_CODE_INSEE(18),

    /**
     * ADR_CODE_RIVOLI
     */
    ADR_CODE_RIVOLI(19),

    /**
     * ADR_PORTE
     */
    ADR_PORTE(20),

    /**
     * ADR_LOGO
     */
    ADR_LOGO(21),

    /**
     * ADR_BATIMENT
     */
    ADR_BATIMENT(22),

    /**
     * ADR_ESCALIER
     */
    ADR_ESCALIER(23),

    /**
     * ADR_ETAGE
     */
    ADR_ETAGE(24),

    /**
     * INST_TYPE_MES
     */
    INST_TYPE_MES(25),

    /**
     * INST_DATE_CLIENT
     */
    INST_DATE_CLIENT(26),

    /**
     * INST_CRENEAU_CLIENT
     */
    INST_CRENEAU_CLIENT(27),

    /**
     * INST_ID_RDV
     */
    INST_ID_RDV(28),

    /**
     * INST_PRESTATAIRE
     */
    INST_PRESTATAIRE(29),

    /**
     * INST_COMMENTAIRE
     */
    INST_COMMENTAIRE(30),

    /**
     * DATE_CREATION
     */
    DATE_CREATION(31),

    /**
     * DATE_MODIFICATION
     */
    DATE_MODIFICATION(32);

    /**
     * Header size of PALFFTTLA CSV file type.
     */
    private static final int PALFFTTLA_HEADER_SIZE = 35;
    /**
     * The index of column in the Header
     */
    private int _index;

    /**
     * @param index_p
     *          The index
     */
    PALFFTTLAHeader(int index_p)
    {
      _index = index_p;
    }

    /**
     * Return the index position in the header
     *
     * @return The index.
     */
    public int getIndex()
    {
      return _index;
    }
  }

  /**
   * LIGNE_FIXE PA type
   */
  private static final String PA_TYPE_LIGNE_FIXE = "LIGNE_FIXE"; //$NON-NLS-1$

  /**
   * FTTLA
   */
  private static final String FTTLA = "FTTLA"; //$NON-NLS-1$

  /**
   * Writer retour
   */
  private Retour _retour;

  /**
   * The CSVPrinter
   */
  private CSVPrinter _csvPrinter;
  /**
   * Number of maximum lines to write without performing a flush on the CSV file.
   */
  private int _linesToFlush;

  /**
   * The name of CSV PFI file.
   */
  private String _fileName;
  /**
   * Number of lines dumped in the CSV file.
   */
  private int _currentDumpedLines = 0;

  /**
   * Default Constructor
   *
   * @param fileName_p
   *          The filePath
   * @param linesToFlush_p
   *          The number of lines to call flush
   * @throws IOException
   *           IOException
   */
  public PaLigneFixeFttlaWriter(String fileName_p, int linesToFlush_p) throws IOException
  {
    _fileName = fileName_p;
    _linesToFlush = linesToFlush_p;
    initCsvPrinter();

  }

  @Override
  public void close() throws Exception
  {
    _csvPrinter.flush();
    _csvPrinter.close();
  }

  @Override
  public void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p)
  {
    try
    {
      List<List<String>> records = this.getRecords(pfi_p, dateDemande_p);
      write(records);
    }
    catch (IOException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage()))); //$NON-NLS-1$
      _retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.CREATION_FICHIER_INVALIDE, MessageFormat.format(Messages.getString("PP0098.ErrorWritingFile"), _fileName, exception.getMessage())); //$NON-NLS-1$
    }
  }

  @Override
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * Builds a list of lists. Each inner list corresponds to a line in the CSV file.
   *
   * @param pfi_p
   *          The PFI
   *
   * @return The String list representing a line
   */
  private List<List<String>> getRecords(PFI pfi_p, LocalDate dateDemande_p)
  {

    List<List<String>> records = new ArrayList<>();

    List<PA> lPALigneFixe = pfi_p.getPa().stream().filter(pa -> pa.getTypePA().equals(PA_TYPE_LIGNE_FIXE))//filter PA of type LIGNE_FIXE
        .filter(pa -> pa.getPaTypeLigneFixe() != null)//only want non null PATypeLigneFixed
        .collect(Collectors.toList());

    for (PA pa : lPALigneFixe)
    {
      PaTypeLigneFixe paLigneFixe = pa.getPaTypeLigneFixe();
      if (isPALigneFixeFTTLA(paLigneFixe) //
          && "BSS_GP".equals(pfi_p.getClientOperateur()) //$NON-NLS-1$
          && (dateDemande_p.isEqual(pa.getDateCreation().toLocalDate()) //
              || dateDemande_p.isEqual(pa.getDateModification().toLocalDate())))
      {
        List<String> record = new ArrayList<>(Arrays.asList(new String[PALFFTTLAHeader.PALFFTTLA_HEADER_SIZE]));

        record.set(PALFFTTLAHeader.CLIENT_OPERATEUR.getIndex(), pfi_p.getClientOperateur());
        record.set(PALFFTTLAHeader.NO_COMPTE.getIndex(), pfi_p.getNoCompte());
        record.set(PALFFTTLAHeader.ID_PA.getIndex(), pa.getIdentifiantFonctionnelPA());
        record.set(PALFFTTLAHeader.STATUT.getIndex(), CSVWriterUtils.getCsvValue(pa.getStatut()));
        record.set(PALFFTTLAHeader.ID_RACCO.getIndex(), paLigneFixe.getIdRaccordement());
        record.set(PALFFTTLAHeader.IS_PA_CIBLE.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getInfoBrutBssGp().isIndicateurPACible()));
        record.set(PALFFTTLAHeader.IS_PA_PRINCIPAL.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getInfoBrutBssGp().isIndicateurPAPrincipal()));
        record.set(PALFFTTLAHeader.ID_PRISE.getIndex(), paLigneFixe.getInfoBrutBssGp().getIdPrise());
        record.set(PALFFTTLAHeader.ID_OSS.getIndex(), paLigneFixe.getInfoBrutBssGp().getIdRessourceReseauFTTX());
        record.set(PALFFTTLAHeader.IS_PRO.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getInfoBrutBssGp().getIndicateurAccesPRO()));
        record.set(PALFFTTLAHeader.ID_CLIENT_EXTERNE.getIndex(), paLigneFixe.getInfoBrutBssGp().getIdClientExterne());
        record.set(PALFFTTLAHeader.TECHNO_RACCO.getIndex(), paLigneFixe.getInfoBrutBssGp().getAccesTechnique().getTechnologieAcces());
        record.set(PALFFTTLAHeader.ID_PROFIL_TECH.getIndex(), paLigneFixe.getInfoBrutBssGp().getAccesTechnique().getIdProfilTechnique());

        if (paLigneFixe.getInfoBrutBssGp().getAdresseInstallation() != null)
        {
          record.set(PALFFTTLAHeader.ADR_NUMERO.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getNumero());
          record.set(PALFFTTLAHeader.ADR_IND_REPETITION.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getIndiceRepetition());
          record.set(PALFFTTLAHeader.ADR_NOM_VOIE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getNomVoie());
          record.set(PALFFTTLAHeader.ADR_CODE_POSTAL.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getCodePostal());
          record.set(PALFFTTLAHeader.ADR_VILLE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getVille());
          record.set(PALFFTTLAHeader.ADR_CODE_INSEE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getCodeInsee());
          record.set(PALFFTTLAHeader.ADR_CODE_RIVOLI.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getCodeRivoli());
          record.set(PALFFTTLAHeader.ADR_PORTE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getPorte());
          record.set(PALFFTTLAHeader.ADR_LOGO.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getLogo());
          record.set(PALFFTTLAHeader.ADR_BATIMENT.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getBatiment());
          record.set(PALFFTTLAHeader.ADR_ESCALIER.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getEscalier());
          record.set(PALFFTTLAHeader.ADR_ETAGE.getIndex(), paLigneFixe.getInfoBrutBssGp().getAdresseInstallation().getEtage());
        }

        if (paLigneFixe.getContexteInstallation() != null)
        {
          record.set(PALFFTTLAHeader.INST_TYPE_MES.getIndex(), paLigneFixe.getContexteInstallation().getTypeMes());
          record.set(PALFFTTLAHeader.INST_DATE_CLIENT.getIndex(), CSVWriterUtils.getCsvValue(paLigneFixe.getContexteInstallation().getDateClient(), DateTimeFormatPattern.yyyy_dash_MM_dash_dd));
          record.set(PALFFTTLAHeader.INST_CRENEAU_CLIENT.getIndex(), paLigneFixe.getContexteInstallation().getCreneauClient());
          record.set(PALFFTTLAHeader.INST_ID_RDV.getIndex(), paLigneFixe.getContexteInstallation().getIdRdv());
          record.set(PALFFTTLAHeader.INST_PRESTATAIRE.getIndex(), paLigneFixe.getContexteInstallation().getPrestataire());
          if (paLigneFixe.getContexteInstallation().getCommentaire() != null)
          {
            record.set(PALFFTTLAHeader.INST_COMMENTAIRE.getIndex(), paLigneFixe.getContexteInstallation().getCommentaire().replaceAll("[\r\n]+", " ")); //$NON-NLS-1$//$NON-NLS-2$
          }
          else
          {
            record.set(PALFFTTLAHeader.INST_COMMENTAIRE.getIndex(), null);
          }

        }
        record.set(PALFFTTLAHeader.DATE_CREATION.getIndex(), CSVWriterUtils.getCsvValue(pa.getDateCreation(), DateTimeFormatPattern.yyyyMMddHHmmss));
        record.set(PALFFTTLAHeader.DATE_MODIFICATION.getIndex(), CSVWriterUtils.getCsvValue(pa.getDateModification(), DateTimeFormatPattern.yyyyMMddHHmmss));
        records.add(record);
      }
    }
    return records;
  }

  /**
   * Constructs and configures a new instance of CSVFormat
   *
   * @throws IOException
   *           IOException
   */
  private void initCsvPrinter() throws IOException
  {

    BufferedWriter bf = Files.newBufferedWriter(Paths.get(_fileName)); //bf is closed in method close by CSVPrinter
    CSVFormat csvFormat = CSVFormat.newFormat(CSV_SEPARATOR).withRecordSeparator(StringConstants.LINE_SEPARATOR).withHeader(PALFFTTLAHeader.class);
    _csvPrinter = new CSVPrinter(bf, csvFormat);

  }

  /**
   * Check if a PaTypeLigneFixe is of type FTTLA
   *
   * @param paLigneFixe_p
   *          The PaTypeLigneFixe parameter
   * @return true if PaTypeLigneFixe is of type FTTLA
   */
  private boolean isPALigneFixeFTTLA(PaTypeLigneFixe paLigneFixe_p)
  {
    if (paLigneFixe_p != null)
    {
      if ((paLigneFixe_p.getInfoBrutBssGp() != null) && (paLigneFixe_p.getInfoBrutBssGp().getAccesTechnique() != null))
      {
        if (FTTLA.equals(paLigneFixe_p.getInfoBrutBssGp().getAccesTechnique().getTechnologieAcces()))
        {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Write in the CSV file the list of records. Each record corresponds to a line.
   *
   * @param records_p
   *          The list of records.
   * @throws IOException
   *           Throws IOException.
   */
  private synchronized void write(List<List<String>> records_p) throws IOException
  {
    for (List<String> record : records_p)
    {
      _csvPrinter.printRecord(record);
      //check if a flush is needed
      if ((++_currentDumpedLines % this._linesToFlush) == 0)
      {
        _csvPrinter.flush();
      }
    }
  }
}
