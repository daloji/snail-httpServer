/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.ford.processes.PP0098.generator;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import java.time.LocalDate;

/**
 * Interface implemented by PFI file generators.
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public interface INSFWriter extends AutoCloseable
{

  /**
   * CSV values separator
   */
  public static final char CSV_SEPARATOR = ';';

  /**
   * Generates files for the specified PFI
   *
   * @param pfi_p
   *          The PFI
   * @param tracabilite_p
   *          Tracabilite
   */
  void dumpPFI(Tracabilite tracabilite_p, PFI pfi_p, LocalDate dateDemande_p);

  /**
   * return of writer
   *
   * @return
   */
  Retour getRetour();

}
