#!/bin/bash

#Specialist name. Must be lowercase !
# specialist=saab ==> Injected in environment

dir=$(dirname $(readlink -f "$0"))
jarDir=$(realpath ${dir}/../jar)
confDir=$(realpath ${dir}/../conf)
command=${1}

# Force running directory to use same config as local test (cf. relative paths)
cd /spirit/$specialist

# Wait for RING (required on startup for RavelDatabaseConnector)
timeout 120 bash -c 'until echo 2> /dev/null > /dev/tcp/ring-tester/9042; do sleep 1; done'
if [ $? -eq 124 ]; then
    echo 'waited 120 seconds but RING may not have started correctly'
fi


# Override supervision directory for test purpose
${JAVA_HOME}/bin/java ${JAVA_OPTS} -classpath "${jarDir}/*" \
	 -DconfigSpiritFrontendDir=${confDir} -DsupervisionSpiritFrontendDir=/spirit/${specialist}/logs/ \
	 -DconfigSpiritBackendDir=${confDir} -DsupervisionSpiritBackendDir=/spirit/${specialist}/logs/ \
	 com.bytel.ravel.embedded.jetty.JettyServer ${confDir}/${specialist}Jetty.xml ${command} 2>&1 
