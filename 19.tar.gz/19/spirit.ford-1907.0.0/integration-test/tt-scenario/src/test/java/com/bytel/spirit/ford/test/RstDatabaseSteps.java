package com.bytel.spirit.ford.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.bytel.ravel.config.RavelCassandraConfig;
import com.bytel.ravel.step.helper.AbstractSteps;
import com.datastax.driver.core.Session;

public class RstDatabaseSteps extends AbstractSteps
{
  /** BASE_PATH */
  private static final String BASE_PATH = "RST-cql";

  /** Cassandra session */
  @Autowired
  @Qualifier(RavelCassandraConfig.RAVEL_CASSANDRA_SESSION)
  private Session _session;

  /**
   * Default constructor
   */
  public RstDatabaseSteps()
  {
    super(BASE_PATH);
  }

}
