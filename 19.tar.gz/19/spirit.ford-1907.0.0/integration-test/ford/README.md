Manual test in IDE (eg. Eclipse)
================================
Create folder (if necessary) from the root of this project : 
* ./tt-files/sftp ==> folder mounted inside the SFTP container
* ./tt-files/data ==> folder data for the specialist (should be the root of specialist's configuration for business files).

Start a docker container from the root of this project with the command :
> docker run -p 22:22 -v ./tt-files/sftp/:/home/ford/data/ bt1svm33:5000/atmoz/sftp:alpine-3.6 ford:fordpass:::data

Start Ford from Eclipse (from the class FordTester, Run As > Java Application)