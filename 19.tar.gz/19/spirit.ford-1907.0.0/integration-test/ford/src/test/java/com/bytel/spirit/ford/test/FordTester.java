package com.bytel.spirit.ford.test;

import com.bytel.ravel.embedded.jetty.JettyServer;

/**
 * Class with a main method to launch a local Saab.
 *
 * @author jstrub
 */
public final class FordTester
{
  /**
   * Main method.
   *
   * @param args
   *          main args
   * @throws Exception
   *           on error
   */
  @SuppressWarnings("nls")
  public static void main(String[] args) throws Exception
  {
    // Resources directory
    String confDir = "conf/";

    // System properties used by Spirit
    System.setProperty("configSpiritBackendDir", confDir);
    System.setProperty("supervisionSpiritBackendDir", "logs/");

    // Start the backend !
    JettyServer.main(new String[] { confDir + "fordJetty.xml", "start" });
  }

  /** Private constructor. */
  private FordTester()
  {
    // Nothing to do
  }
}
