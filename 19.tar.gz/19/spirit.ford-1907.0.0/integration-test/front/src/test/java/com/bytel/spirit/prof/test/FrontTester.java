package com.bytel.spirit.prof.test;

import com.bytel.ravel.embedded.jetty.JettyServer;

/**
 * Class with a main method to launch a local Front.
 *
 * @author jstrub
 */
public final class FrontTester
{
  /**
   * Main method.
   *
   * @param args
   *          main args
   * @throws Exception
   *           on error
   */
  @SuppressWarnings("nls")
  public static void main(String[] args) throws Exception
  {
    // Resources directory
    String confDir = "conf/";

    // System properties used by Spirit
    System.setProperty("configSpiritFrontendDir", confDir);
    System.setProperty("supervisionSpiritFrontendDir", "logs/");

    // Start the backend !
    JettyServer.main(new String[] { confDir + "frontJetty.xml", "start" });
  }

  /** Private constructor. */
  private FrontTester()
  {
    // Nothing to do
  }
}
