#!/bin/bash

if [ -z $4 ]; then
	echo "usage: $0 REGISTRY_CENTOS_URL SPECIALIST VERSION CENTOS73_VERSION"
	exit 1
fi

export REGISTRY_CENTOS_URL=$1
export SPECIALIST=$2
export VERSION=$3
export CENTOS73_VERSION=$4
export BUILD_DATE=$(date +%Y-%m-%dT%H:%M:%S.%3N%:z)
export SVN_URL=$(svn info --xml | grep '<url>' | cut -d '>' -f 2 | cut -d '<' -f 1)
export SVN_REVISION=$(svn info --xml | grep revision | tail -n 1 | cut -d '"' -f 2)

envsubst < Dockerfile > build/Dockerfile

find -name "*.sh" -exec chmod +x {} \;