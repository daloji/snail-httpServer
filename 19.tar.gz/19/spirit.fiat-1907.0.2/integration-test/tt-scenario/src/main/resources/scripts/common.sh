#!/bin/bash

#Specialist name. Must be lowercase !
# specialist=fiat ==> Injected in environment

dir=$(dirname $(readlink -f "$0"))
jarDir=$(realpath ${dir}/../jar)
confDir=$(realpath ${dir}/../conf)
command=${1}

# Force running directory to use same config as local test (cf. relative paths)
cd /spirit/$specialist

# Override supervision directory for test purpose
${JAVA_HOME}/bin/java ${JAVA_OPTS} -classpath "${jarDir}/*" \
	 -DconfigSpiritFrontendDir=${confDir} -DsupervisionSpiritFrontendDir=/spirit/${specialist}/logs/ \
	 -DconfigSpiritBackendDir=${confDir} -DsupervisionSpiritBackendDir=/spirit/${specialist}/logs/ \
	 com.bytel.ravel.embedded.jetty.JettyServer ${confDir}/${specialist}Jetty.xml ${command} 2>&1 
