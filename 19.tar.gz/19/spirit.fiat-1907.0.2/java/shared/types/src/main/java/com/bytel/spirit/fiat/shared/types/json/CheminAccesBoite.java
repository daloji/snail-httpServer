/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.shared.types.json;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class CheminAccesBoite implements Serializable
{
  /**
   * Generate Unique Serial Identifier
   */
  private static final long serialVersionUID = -8434357960000401117L;

  /**
   * Racine du chemin d’accès a la boite mail
   */
  @SerializedName("racine")
  private String _racine;

  /**
   * Filer du chemin d’accès a la boite mail
   */
  @SerializedName("filer")
  private String _filer;

  /**
   * Répertoire du chemin d’accès a la boite mail
   */
  @SerializedName("repertoire")
  private String _repertoire;

  /**
   * Constructor
   *
   * @param racine_p
   *          Racine du chemin d’accès a la boite mail
   * @param filer_p
   *          Filer du chemin d’accès a la boite mail
   * @param repertoire_p
   *          Répertoire du chemin d’accès a la boite mail
   */
  public CheminAccesBoite(final String racine_p, final String filer_p, final String repertoire_p)
  {
    super();

    _racine = racine_p;
    _filer = filer_p;
    _repertoire = repertoire_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    CheminAccesBoite other = (CheminAccesBoite) obj;
    if (_filer == null)
    {
      if (other._filer != null)
      {
        return false;
      }
    }
    else if (!_filer.equals(other._filer))
    {
      return false;
    }
    if (_racine == null)
    {
      if (other._racine != null)
      {
        return false;
      }
    }
    else if (!_racine.equals(other._racine))
    {
      return false;
    }
    if (_repertoire == null)
    {
      if (other._repertoire != null)
      {
        return false;
      }
    }
    else if (!_repertoire.equals(other._repertoire))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the filer
   */
  public final String getFiler()
  {
    return _filer;
  }

  /**
   * @return the racine
   */
  public final String getRacine()
  {
    return _racine;
  }

  /**
   * @return the repertoire
   */
  public final String getRepertoire()
  {
    return _repertoire;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_filer == null) ? 0 : _filer.hashCode());
    result = (prime * result) + ((_racine == null) ? 0 : _racine.hashCode());
    result = (prime * result) + ((_repertoire == null) ? 0 : _repertoire.hashCode());
    return result;
  }

  /**
   * @param filer_p
   *          the filer to set
   */
  public final void setFiler(final String filer_p)
  {
    _filer = filer_p;
  }

  /**
   * @param racine_p
   *          the racine to set
   */
  public final void setRacine(final String racine_p)
  {
    _racine = racine_p;
  }

  /**
   * @param repertoire_p
   *          the repertoire to set
   */
  public final void setRepertoire(final String repertoire_p)
  {
    _repertoire = repertoire_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("CheminAccesBoite [_racine="); //$NON-NLS-1$
    builder.append(_racine);
    builder.append(", _filer="); //$NON-NLS-1$
    builder.append(_filer);
    builder.append(", _repertoire="); //$NON-NLS-1$
    builder.append(_repertoire);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
