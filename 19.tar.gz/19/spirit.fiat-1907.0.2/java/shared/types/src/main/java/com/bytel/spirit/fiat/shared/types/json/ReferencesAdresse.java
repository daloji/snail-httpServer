/*******************************************************************************
* $Id: ReferencesAdresse.java 11885 2018-10-19 09:08:09Z jgregori $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.shared.types.json;

import java.io.Serializable;

import javax.validation.Valid;

import com.bytel.spirit.fiat.shared.types.json.validation.ReferencesAdresseConstraint;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 11885 $ $Date: 2018-10-19 11:08:09 +0200 (ven., 19 oct. 2018) $)
 */
@ReferencesAdresseConstraint
public class ReferencesAdresse implements Serializable
{
  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 2443941295373606652L;

  /**
   * hexacle
   */
  @SerializedName("hexacle")
  @Expose
  private String _hexacle;

  /**
   * rivoli
   */
  @SerializedName("rivoli")
  @Expose
  @Valid
  private QuadrupletRivoli _rivoli;

  /**
   * hexacleVoie
   */
  @SerializedName("hexacleVoie")
  @Expose
  @Valid
  private HexacleVoie _hexacleVoie;

  /**
   * referenceGeographique
   */
  @SerializedName("referenceGeographique")
  @Expose
  @Valid
  private CoordonneesGeo _referenceGeo;

  /**
   * identifiantImmeuble
   */
  @SerializedName("identifiantImmeuble")
  @Expose
  private String _identifiantImeuble;

  /**
   * adresseLibre
   */
  @SerializedName("adresseLibre")
  @Expose
  private String _adresseLibre;

  /**
   * @return the adresseLibre
   */
  public String getAdresseLibre()
  {
    return _adresseLibre;
  }

  /**
   * @return the hexacle
   */
  public String getHexacle()
  {
    return _hexacle;
  }

  /**
   * @return the hexacleVoie
   */
  public HexacleVoie getHexacleVoie()
  {
    return _hexacleVoie;
  }

  /**
   * @return the identifiantImeuble
   */
  public String getIdentifiantImeuble()
  {
    return _identifiantImeuble;
  }

  /**
   * @return the referenceGeo
   */
  public CoordonneesGeo getReferenceGeo()
  {
    return _referenceGeo;
  }

  /**
   * @return the rivoli
   */
  public QuadrupletRivoli getRivoli()
  {
    return _rivoli;
  }

  /**
   * @param adresseLibre_p
   *          the adresseLibre to set
   */
  public void setAdresseLibre(String adresseLibre_p)
  {
    _adresseLibre = adresseLibre_p;
  }

  /**
   * @param hexacle_p
   *          the hexacle to set
   */
  public void setHexacle(String hexacle_p)
  {
    _hexacle = hexacle_p;
  }

  /**
   * @param hexacleVoie_p
   *          the hexacleVoie to set
   */
  public void setHexacleVoie(HexacleVoie hexacleVoie_p)
  {
    _hexacleVoie = hexacleVoie_p;
  }

  /**
   * @param identifiantImeuble_p
   *          the identifiantImeuble to set
   */
  public void setIdentifiantImeuble(String identifiantImeuble_p)
  {
    _identifiantImeuble = identifiantImeuble_p;
  }

  /**
   * @param referenceGeo_p
   *          the referenceGeo to set
   */
  public void setReferenceGeo(CoordonneesGeo referenceGeo_p)
  {
    _referenceGeo = referenceGeo_p;
  }

  /**
   * @param rivoli_p
   *          the rivoli to set
   */
  public void setRivoli(QuadrupletRivoli rivoli_p)
  {
    _rivoli = rivoli_p;
  }

}
