/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.shared.types.json;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
public class PBO implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 2815176847043925392L;

  /** Reference PM. */
  @SerializedName("referencePM")
  @Expose
  private String _referencePM;

  /** Reference PBO. */
  @SerializedName("referencePBO")
  @Expose
  private String _referencePBO;

  /** Adresse PBO. */
  @SerializedName("adressePBO")
  @Expose
  private Adresse _adressePBO;

  /** Structure PBO. */
  @SerializedName("structurePBO")
  @Expose
  private ComplementAdresse _structurePBO;

  /** Nombre fibres disponibles. */
  @SerializedName("nombreFibresDisponibles")
  @Expose
  private Integer _nombreFibresDisponibles;

  /** Nature PBO. */
  @SerializedName("naturePBO")
  @Expose
  private String _naturePBO;

  /**
   *
   */
  public PBO()
  {
    // nothing to do
  }

  /**
   * @param pbo_p
   *          pbo to convert
   *
   */
  public PBO(com.bytel.spirit.common.connector.oi.emutation.structs.PBO pbo_p)
  {
    this.setAdressePBO(pbo_p.getAdressePBO());
    if (pbo_p.getStructurePBO() != null)
    {
      this.setStructurePBO(pbo_p.getStructurePBO());
    }
    _referencePM = pbo_p.getReferencePM();
    _referencePBO = pbo_p.getReferencePBO();
    _nombreFibresDisponibles = pbo_p.getNombreFibresDisponibles();
    _naturePBO = pbo_p.getNaturePBO();
  }

  /**
   * @param referencePM_p
   *          the referencePM
   * @param referencePBO_p
   *          the referencePBO
   * @param adressePBO_p
   *          the adressePBO
   * @param structurePBO_p
   *          the structurePBO
   * @param nombreFibresDisponibles_p
   *          the nombreFibresDisponibles
   * @param naturePBO_p
   *          the naturePBO
   */
  public PBO(String referencePM_p, String referencePBO_p, Adresse adressePBO_p, ComplementAdresse structurePBO_p, Integer nombreFibresDisponibles_p, String naturePBO_p)
  {
    _referencePM = referencePM_p;
    _referencePBO = referencePBO_p;
    _adressePBO = adressePBO_p;
    _structurePBO = structurePBO_p;
    _nombreFibresDisponibles = nombreFibresDisponibles_p;
    _naturePBO = naturePBO_p;
  }

  /**
   * @return the adressePBO
   */
  public Adresse getAdressePBO()
  {
    return _adressePBO;
  }

  /**
   * @return the naturePBO
   */
  public String getNaturePBO()
  {
    return _naturePBO;
  }

  /**
   * @return the nombreFibresDisponibles
   */
  public Integer getNombreFibresDisponibles()
  {
    return _nombreFibresDisponibles;
  }

  /**
   * @return the referencePBO
   */
  public String getReferencePBO()
  {
    return _referencePBO;
  }

  /**
   * @return the referencePM
   */
  public String getReferencePM()
  {
    return _referencePM;
  }

  /**
   * @return the structurePBO
   */
  public ComplementAdresse getStructurePBO()
  {
    return _structurePBO;
  }

  /**
   * @param adressePBO_p
   *          the adressePBO to set
   */
  public void setAdressePBO(Adresse adressePBO_p)
  {
    _adressePBO = adressePBO_p;
  }

  /**
   * @param adressePBO_p
   *          the adressePBO to set
   */
  public void setAdressePBO(com.bytel.spirit.common.connector.oi.emutation.structs.Adresse adressePBO_p)
  {
    Adresse adresse = null;
    if (adressePBO_p.getReferencesAdresse() != null)
    {
      adresse = new Adresse();
      ReferencesAdresse referencesAdresse = new ReferencesAdresse();
      referencesAdresse.setAdresseLibre(adressePBO_p.getReferencesAdresse().getAdresseLibre());
      adresse.setReferencesAdresse(referencesAdresse);
    }
    _adressePBO = adresse;
  }

  /**
   * @param naturePBO_p
   *          the naturePBO to set
   */
  public void setNaturePBO(String naturePBO_p)
  {
    _naturePBO = naturePBO_p;
  }

  /**
   * @param nombreFibresDisponibles_p
   *          the nombreFibresDisponibles to set
   */
  public void setNombreFibresDisponibles(Integer nombreFibresDisponibles_p)
  {
    _nombreFibresDisponibles = nombreFibresDisponibles_p;
  }

  /**
   * @param referencePBO_p
   *          the referencePBO to set
   */
  public void setReferencePBO(String referencePBO_p)
  {
    _referencePBO = referencePBO_p;
  }

  /**
   * @param referencePM_p
   *          the referencePM to set
   */
  public void setReferencePM(String referencePM_p)
  {
    _referencePM = referencePM_p;
  }

  /**
   * @param structurePBO_p
   *          the structurePBO to set
   */
  public void setStructurePBO(com.bytel.spirit.common.connector.oi.emutation.structs.ComplementAdresse structurePBO_p)
  {
    ComplementAdresse complementAdresse = new ComplementAdresse();
    complementAdresse.setBatiment(structurePBO_p.getBatiment());
    complementAdresse.setEscalier(structurePBO_p.getEscalier());
    complementAdresse.setEtage(structurePBO_p.getEtage());
    _structurePBO = complementAdresse;
  }

  /**
   * @param structurePBO_p
   *          the structurePBO to set
   */
  public void setStructurePBO(ComplementAdresse structurePBO_p)
  {
    _structurePBO = structurePBO_p;
  }

  @Override
  public String toString()
  {
    return "PBO [_referencePM=" + _referencePM + ", _referencePBO=" + _referencePBO + ", _adressePBO=" + _adressePBO + ", _structurePBO=" + _structurePBO + ", _nombreFibresDisponibles=" + _nombreFibresDisponibles + ", _naturePBO=" + _naturePBO + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
  }

}
