/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.shared.types.json.response;

import java.io.Serializable;
import java.time.LocalDate;

import javax.validation.Valid;

import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.shared.types.json.CheminAccesBoite;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class ReponseFonctionnellePI0150C implements Serializable
{
  /**
   * Generate Unique Serial Identifier
   */
  private static final long serialVersionUID = 1997377164161192037L;

  /**
   * Adresse Mail
   */
  @SerializedName("loginMail")
  @Expose
  private String _loginMail;

  /**
   * IdCompteMailPrincipal
   */
  @SerializedName("idCompteMail")
  @Expose
  private String _idCompteMail;

  /**
   * Type Service MAIL
   */
  @SerializedName("typeServiceMail")
  @Expose
  private String _typeServiceMail;

  /**
   * Taille de la pièce jointe en Mo
   */
  @SerializedName("taillePieceJointe")
  @Expose
  private Long _taillePieceJointe;

  /**
   * Taille Boite Mail en Go
   */
  @SerializedName("volumeBoite")
  @Expose
  private Long _volumeBoite;
  /**
   * Niveau de restriction.
   */
  @SerializedName("niveauRestriction")
  @Expose
  private String _niveauRestriction;

  /**
   * Etat d’activation du service antivirus
   */
  @SerializedName("antivirus")
  @Expose
  private Boolean _antivirus;

  /**
   * Etat d’activation du service antispam
   */
  @SerializedName("antispam")
  @Expose
  private Boolean _antispam;

  /**
   * idCompteMailPrincipal
   */
  @SerializedName("idCompteMailPrincipal")
  @Expose
  private String _idCompteMailPrincipal;

  /**
   * Chemin d'accès de la boite mail
   */
  @SerializedName("cheminAccesBoite")
  @Expose
  @Valid
  private CheminAccesBoite _cheminAccesBoite;

  /**
   * Date de création du compte sur la PFS
   */
  @SerializedName("dateCreationCompte")
  @Expose
  private LocalDate _dateCreationCompte;

  /**
   * Date de modification du compte sur la PFS
   */
  @SerializedName("dateModificationCompte")
  @Expose
  private LocalDate _dateModificationCompte;

  /**
   * Eléments de traçabilité associée au retour
   */
  private transient Tracabilite _tracabilitePI;

  /**
   * @param loginMail_p
   *          Adresse Mail
   * @param idCompteMail_p
   *          Id compte mail
   * @param typeServiceMail_p
   *          Type Service MAIL
   * @param taillePieceJointe_p
   *          Taille de la pièce jointe en Mo
   * @param volumeBoite_p
   *          Taille Boite Mail en Go
   * @param niveauRestriction_p
   *          Niveau de restriction.
   * @param antivirus_p
   *          Etat d’activation du service antivirus
   * @param antispam_p
   *          Etat d’activation du service antispam
   * @param idCompteMailPrincipal_p
   *          idCompteMailPrincipal
   * @param cheminAccesBoite_p
   *          Chemin d'accès de la boite mail
   * @param dateCreationCompte_p
   *          Date de création du compte sur la PFS
   * @param dateModificationCompte_p
   *          Date de modification du compte sur la PFS
   */
  public ReponseFonctionnellePI0150C(String loginMail_p, String idCompteMail_p, String typeServiceMail_p, Long taillePieceJointe_p, Long volumeBoite_p, String niveauRestriction_p, Boolean antivirus_p, Boolean antispam_p, String idCompteMailPrincipal_p, @Valid CheminAccesBoite cheminAccesBoite_p, LocalDate dateCreationCompte_p, LocalDate dateModificationCompte_p)
  {
    super();
    _loginMail = loginMail_p;
    _idCompteMail = idCompteMail_p;
    _typeServiceMail = typeServiceMail_p;
    _taillePieceJointe = taillePieceJointe_p;
    _volumeBoite = volumeBoite_p;
    _niveauRestriction = niveauRestriction_p;
    _antivirus = antivirus_p;
    _antispam = antispam_p;
    _idCompteMailPrincipal = idCompteMailPrincipal_p;
    _cheminAccesBoite = cheminAccesBoite_p;
    _dateCreationCompte = dateCreationCompte_p;
    _dateModificationCompte = dateModificationCompte_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    ReponseFonctionnellePI0150C other = (ReponseFonctionnellePI0150C) obj;
    if (_antispam == null)
    {
      if (other._antispam != null)
      {
        return false;
      }
    }
    else if (!_antispam.equals(other._antispam))
    {
      return false;
    }
    if (_antivirus == null)
    {
      if (other._antivirus != null)
      {
        return false;
      }
    }
    else if (!_antivirus.equals(other._antivirus))
    {
      return false;
    }
    if (_cheminAccesBoite == null)
    {
      if (other._cheminAccesBoite != null)
      {
        return false;
      }
    }
    else if (!_cheminAccesBoite.equals(other._cheminAccesBoite))
    {
      return false;
    }
    if (_dateCreationCompte == null)
    {
      if (other._dateCreationCompte != null)
      {
        return false;
      }
    }
    else if (!_dateCreationCompte.equals(other._dateCreationCompte))
    {
      return false;
    }
    if (_dateModificationCompte == null)
    {
      if (other._dateModificationCompte != null)
      {
        return false;
      }
    }
    else if (!_dateModificationCompte.equals(other._dateModificationCompte))
    {
      return false;
    }
    if (_idCompteMail == null)
    {
      if (other._idCompteMail != null)
      {
        return false;
      }
    }
    else if (!_idCompteMail.equals(other._idCompteMail))
    {
      return false;
    }
    if (_idCompteMailPrincipal == null)
    {
      if (other._idCompteMailPrincipal != null)
      {
        return false;
      }
    }
    else if (!_idCompteMailPrincipal.equals(other._idCompteMailPrincipal))
    {
      return false;
    }
    if (_loginMail == null)
    {
      if (other._loginMail != null)
      {
        return false;
      }
    }
    else if (!_loginMail.equals(other._loginMail))
    {
      return false;
    }
    if (_niveauRestriction == null)
    {
      if (other._niveauRestriction != null)
      {
        return false;
      }
    }
    else if (!_niveauRestriction.equals(other._niveauRestriction))
    {
      return false;
    }
    if (_taillePieceJointe == null)
    {
      if (other._taillePieceJointe != null)
      {
        return false;
      }
    }
    else if (!_taillePieceJointe.equals(other._taillePieceJointe))
    {
      return false;
    }
    if (_typeServiceMail == null)
    {
      if (other._typeServiceMail != null)
      {
        return false;
      }
    }
    else if (!_typeServiceMail.equals(other._typeServiceMail))
    {
      return false;
    }
    if (_volumeBoite == null)
    {
      if (other._volumeBoite != null)
      {
        return false;
      }
    }
    else if (!_volumeBoite.equals(other._volumeBoite))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the antispam
   */
  public final Boolean getAntispam()
  {
    return _antispam;
  }

  /**
   * @return the antivirus
   */
  public final Boolean getAntivirus()
  {
    return _antivirus;
  }

  /**
   * @return the cheminAccesBoite
   */
  public final CheminAccesBoite getCheminAccesBoite()
  {
    return _cheminAccesBoite;
  }

  /**
   * @return the dateCreationCompte
   */
  public final LocalDate getDateCreationCompte()
  {
    return _dateCreationCompte;
  }

  /**
   * @return the dateModificationCompte
   */
  public final LocalDate getDateModificationCompte()
  {
    return _dateModificationCompte;
  }

  /**
   * @return the idCompteMail
   */
  public String getIdCompteMail()
  {
    return _idCompteMail;
  }

  /**
   * @return the idCompteMailPrincipal
   */
  public String getIdCompteMailPrincipal()
  {
    return _idCompteMailPrincipal;
  }

  /**
   * @return the loginMail
   */
  public final String getLoginMail()
  {
    return _loginMail;
  }

  /**
   * @return the niveauRestriction
   */
  public final String getNiveauRestriction()
  {
    return _niveauRestriction;
  }

  /**
   * @return the taillePieceJointe
   */
  public final Long getTaillePieceJointe()
  {
    return _taillePieceJointe;
  }

  /**
   * @return the tracabilitePI
   */
  public final Tracabilite getTracabilitePI()
  {
    return _tracabilitePI;
  }

  /**
   * @return the typeServiceMail
   */
  public final String getTypeServiceMail()
  {
    return _typeServiceMail;
  }

  /**
   * @return the volumeBoite
   */
  public final Long getVolumeBoite()
  {
    return _volumeBoite;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_antispam == null) ? 0 : _antispam.hashCode());
    result = (prime * result) + ((_antivirus == null) ? 0 : _antivirus.hashCode());
    result = (prime * result) + ((_cheminAccesBoite == null) ? 0 : _cheminAccesBoite.hashCode());
    result = (prime * result) + ((_dateCreationCompte == null) ? 0 : _dateCreationCompte.hashCode());
    result = (prime * result) + ((_dateModificationCompte == null) ? 0 : _dateModificationCompte.hashCode());
    result = (prime * result) + ((_idCompteMail == null) ? 0 : _idCompteMail.hashCode());
    result = (prime * result) + ((_idCompteMailPrincipal == null) ? 0 : _idCompteMailPrincipal.hashCode());
    result = (prime * result) + ((_loginMail == null) ? 0 : _loginMail.hashCode());
    result = (prime * result) + ((_niveauRestriction == null) ? 0 : _niveauRestriction.hashCode());
    result = (prime * result) + ((_taillePieceJointe == null) ? 0 : _taillePieceJointe.hashCode());
    result = (prime * result) + ((_typeServiceMail == null) ? 0 : _typeServiceMail.hashCode());
    result = (prime * result) + ((_volumeBoite == null) ? 0 : _volumeBoite.hashCode());
    return result;
  }

  /**
   * @param antispam_p
   *          the antispam to set
   */
  public final void setAntispam(final Boolean antispam_p)
  {
    _antispam = antispam_p;
  }

  /**
   * @param antivirus_p
   *          the antivirus to set
   */
  public final void setAntivirus(final Boolean antivirus_p)
  {
    _antivirus = antivirus_p;
  }

  /**
   * @param cheminAccesBoite_p
   *          the cheminAccesBoite to set
   */
  public final void setCheminAccesBoite(final CheminAccesBoite cheminAccesBoite_p)
  {
    _cheminAccesBoite = cheminAccesBoite_p;
  }

  /**
   * @param dateCreationCompte_p
   *          the dateCreationCompte to set
   */
  public final void setDateCreationCompte(final LocalDate dateCreationCompte_p)
  {
    _dateCreationCompte = dateCreationCompte_p;
  }

  /**
   * @param dateModificationCompte_p
   *          the dateModificationCompte to set
   */
  public final void setDateModificationCompte(final LocalDate dateModificationCompte_p)
  {
    _dateModificationCompte = dateModificationCompte_p;
  }

  /**
   * @param idCompteMail_p
   *          the idCompteMail to set
   */
  public void setIdCompteMail(String idCompteMail_p)
  {
    _idCompteMail = idCompteMail_p;
  }

  /**
   * @param idCompteMailPrincipal_p
   *          the idCompteMailPrincipal to set
   */
  public void setIdCompteMailPrincipal(String idCompteMailPrincipal_p)
  {
    _idCompteMailPrincipal = idCompteMailPrincipal_p;
  }

  /**
   * @param loginMail_p
   *          the loginMail to set
   */
  public final void setLoginMail(final String loginMail_p)
  {
    _loginMail = loginMail_p;
  }

  /**
   * @param niveauRestriction_p
   *          the niveauRestriction to set
   */
  public final void setNiveauRestriction(final String niveauRestriction_p)
  {
    _niveauRestriction = niveauRestriction_p;
  }

  /**
   * @param taillePieceJointe_p
   *          the taillePieceJointe to set
   */
  public final void setTaillePieceJointe(final Long taillePieceJointe_p)
  {
    _taillePieceJointe = taillePieceJointe_p;
  }

  /**
   * @param tracabilitePI_p
   *          the tracabilitePI to set
   */
  public final void setTracabilitePI(final Tracabilite tracabilitePI_p)
  {
    _tracabilitePI = tracabilitePI_p;
  }

  /**
   * @param typeServiceMail_p
   *          the typeServiceMail to set
   */
  public final void setTypeServiceMail(final String typeServiceMail_p)
  {
    _typeServiceMail = typeServiceMail_p;
  }

  /**
   * @param volumeBoite_p
   *          the volumeBoite to set
   */
  public final void setVolumeBoite(final Long volumeBoite_p)
  {
    _volumeBoite = volumeBoite_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("ReponseFonctionnellePI0150C [_loginMail="); //$NON-NLS-1$
    builder.append(_loginMail);
    builder.append(", _typeServiceMail="); //$NON-NLS-1$
    builder.append(_typeServiceMail);
    builder.append(", _taillePieceJointe="); //$NON-NLS-1$
    builder.append(_taillePieceJointe);
    builder.append(", _volumeBoite="); //$NON-NLS-1$
    builder.append(_volumeBoite);
    builder.append(", _niveauRestriction="); //$NON-NLS-1$
    builder.append(_niveauRestriction);
    builder.append(", _antivirus="); //$NON-NLS-1$
    builder.append(_antivirus);
    builder.append(", _antispam="); //$NON-NLS-1$
    builder.append(_antispam);
    builder.append(", _cheminAccesBoite="); //$NON-NLS-1$
    builder.append(_cheminAccesBoite);
    builder.append(", _dateCreationCompte="); //$NON-NLS-1$
    builder.append(_dateCreationCompte);
    builder.append(", _dateModificationCompte="); //$NON-NLS-1$
    builder.append(_dateModificationCompte);
    builder.append(", _tracabilitePI="); //$NON-NLS-1$
    builder.append(_tracabilitePI);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
