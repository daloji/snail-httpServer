/*******************************************************************************
* $Id: Adresse.java 11885 2018-10-19 09:08:09Z jgregori $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.shared.types.json;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 11885 $ $Date: 2018-10-19 11:08:09 +0200 (ven., 19 oct. 2018) $)
 */
public class Adresse implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 6913693451311618522L;

  /**
   * referencesAdresse
   */
  @SerializedName("referencesAdresse")
  @Expose
  private ReferencesAdresse _referencesAdresse;

  /**
   * codePostal
   */
  @SerializedName("codePostal")
  @Expose
  private String _codePostal;

  /**
   * commune
   */
  @SerializedName("commune")
  @Expose
  private String _commune;

  /**
   * typeVoie
   */
  @SerializedName("typeVoie")
  @Expose
  private String _typeVoie;

  /**
   * libelleVoie
   */
  @SerializedName("libelleVoie")
  @Expose
  private String _libelleVoie;

  /**
   * numeroVoie
   */
  @SerializedName("numeroVoie")
  @Expose
  private String _numeroVoie;

  /**
   * complementNumero
   */
  @SerializedName("complementNumero")
  @Expose
  private String _complementNumero;

  /**
   * @return the codePostal
   */
  public String getCodePostal()
  {
    return _codePostal;
  }

  /**
   * @return the commune
   */
  public String getCommune()
  {
    return _commune;
  }

  /**
   * @return the complementNumero
   */
  public String getComplementNumero()
  {
    return _complementNumero;
  }

  /**
   * @return the libelleVoie
   */
  public String getLibelleVoie()
  {
    return _libelleVoie;
  }

  /**
   * @return the numeroVoie
   */
  public String getNumeroVoie()
  {
    return _numeroVoie;
  }

  /**
   * @return the referencesAdresse
   */
  public ReferencesAdresse getReferencesAdresse()
  {
    return _referencesAdresse;
  }

  /**
   * @return the typeVoie
   */
  public String getTypeVoie()
  {
    return _typeVoie;
  }

  /**
   * @param codePostal_p
   *          the codePostal to set
   */
  public void setCodePostal(String codePostal_p)
  {
    _codePostal = codePostal_p;
  }

  /**
   * @param commune_p
   *          the commune to set
   */
  public void setCommune(String commune_p)
  {
    _commune = commune_p;
  }

  /**
   * @param complementNumero_p
   *          the complementNumero to set
   */
  public void setComplementNumero(String complementNumero_p)
  {
    _complementNumero = complementNumero_p;
  }

  /**
   * @param libelleVoie_p
   *          the libelleVoie to set
   */
  public void setLibelleVoie(String libelleVoie_p)
  {
    _libelleVoie = libelleVoie_p;
  }

  /**
   * @param numeroVoie_p
   *          the numeroVoie to set
   */
  public void setNumeroVoie(String numeroVoie_p)
  {
    _numeroVoie = numeroVoie_p;
  }

  /**
   * @param referencesAdresse_p
   *          the referencesAdresse to set
   */
  public void setReferencesAdresse(ReferencesAdresse referencesAdresse_p)
  {
    _referencesAdresse = referencesAdresse_p;
  }

  /**
   * @param typeVoie_p
   *          the typeVoie to set
   */
  public void setTypeVoie(String typeVoie_p)
  {
    _typeVoie = typeVoie_p;
  }

}
