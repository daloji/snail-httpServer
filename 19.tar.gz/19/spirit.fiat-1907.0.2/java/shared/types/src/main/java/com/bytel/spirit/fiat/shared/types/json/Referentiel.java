package com.bytel.spirit.fiat.shared.types.json;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.google.gson.annotations.SerializedName;

/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public final class Referentiel implements Serializable
{

  /**
   *
   * EtatProvisioning
   */
  public enum EtatProvisioning
  {
    /**
     * REALISE
     */
    REALISE,
    /**
     * ECHEC
     */
    ECHEC,
    /**
     * EN_COURS
     */
    EN_COURS;
  }

  /**
   * NiveauRestriction
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public enum NiveauRestriction
  {
    /**
     * NON_RESTREINT
     */
    NON_RESTREINT,

    /**
     * RESTREINT
     */
    RESTREINT;

  }

  /**
   *
   * TypeService
   */
  public enum TypeService
  {
    /**
     * MAIL
     */
    MAIL;
  }

  /**
   * TypeServiceMail
   *
   */
  public enum TypeServiceMail
  {

    PRINCIPAL,

    /**
     * SECONDAIRE
     */
    SECONDAIRE;
  }

  /**
   *
   */
  private static final long serialVersionUID = 3599390325446246278L;

  /**
   * IdSTPFS id
   */
  private transient String _idStPfs;

  /**
   *
   */
  @SerializedName("typeService")
  private String _typeService;

  /**
   * Prefixe de L'ádresse mail de la ressource de type email
   */
  @SerializedName("loginMail")
  private String _loginMail;

  /**
   * Liste de Ressources
   */
  @SerializedName("ressources")
  private List<Ressource> _ressources;

  /**
   * Liste de ServiceTecniques
   */
  private transient List<ServiceTechnique> _servicetechniques;

  /**
   * Statut du Provisioning
   */
  @SerializedName("etatProvisioning")
  private String _etatProvisioning;

  /**
   * Type Service Mail
   */
  @SerializedName("typeServiceMail")
  private String _typeServiceMail;

  /**
   * Taille de la piece jointe en Mo
   */
  @SerializedName("taillePieceJointe")
  private Long _taillePieceJointe;

  /**
   * Taille Mail en Go
   */
  @SerializedName("volumeBoite")
  private Long _volumeBoite;

  /**
   * Niveau de restriction
   */
  @SerializedName("niveauRestricion")
  private String _niveauRestriction;

  /**
   *
   */
  @SerializedName("noCompte")
  private String _noCompte;

  /**
   *
   */
  @SerializedName("clienteOperateur")
  private String _clientOperateur;

  /**
   * Liste de desynchrinsation detectees
   */
  @SerializedName("audits")
  private List<Audit> _audits;

  /**
   * List de erreurs detectes
   */
  @SerializedName("erreurs")
  private List<Erreur> _erreurs;

  /**
   * Default constructor
   */
  public Referentiel()
  {
    super();
  }

  /**
   * @param typeService_p
   *          typeService
   * @param loginMail_p
   *          loginMail
   * @param etatProvisioning_p
   *          etat de provisioning
   */
  public Referentiel(String typeService_p, String loginMail_p, String etatProvisioning_p)
  {
    super();
    _typeService = typeService_p;
    _loginMail = loginMail_p;
    _etatProvisioning = etatProvisioning_p;
  }

  /**
   * Add an Audit object to the audit list
   *
   * @param audit_p
   *          The audit objet to add
   */
  public void addAudit(Audit audit_p)
  {
    if (_audits == null)
    {
      _audits = new ArrayList<>();
    }
    _audits.add(audit_p);
  }

  /**
   * Add an Erreur object to the list erreurs
   *
   * @param erreur_p
   *          The erreur objet to add.
   */
  public void addErreur(Erreur erreur_p)
  {
    if (_erreurs == null)
    {
      _erreurs = new ArrayList<>();
    }
    _erreurs.add(erreur_p);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    Referentiel other = (Referentiel) obj;
    if (_audits == null)
    {
      if (other._audits != null)
      {
        return false;
      }
    }
    else if (!_audits.equals(other._audits))
    {
      return false;
    }
    if (_clientOperateur == null)
    {
      if (other._clientOperateur != null)
      {
        return false;
      }
    }
    else if (!_clientOperateur.equals(other._clientOperateur))
    {
      return false;
    }
    if (_erreurs == null)
    {
      if (other._erreurs != null)
      {
        return false;
      }
    }
    else if (!_erreurs.equals(other._erreurs))
    {
      return false;
    }
    if (_etatProvisioning == null)
    {
      if (other._etatProvisioning != null)
      {
        return false;
      }
    }
    else if (!_etatProvisioning.equals(other._etatProvisioning))
    {
      return false;
    }
    if (_idStPfs == null)
    {
      if (other._idStPfs != null)
      {
        return false;
      }
    }
    else if (!_idStPfs.equals(other._idStPfs))
    {
      return false;
    }
    if (_loginMail == null)
    {
      if (other._loginMail != null)
      {
        return false;
      }
    }
    else if (!_loginMail.equals(other._loginMail))
    {
      return false;
    }
    if (_niveauRestriction == null)
    {
      if (other._niveauRestriction != null)
      {
        return false;
      }
    }
    else if (!_niveauRestriction.equals(other._niveauRestriction))
    {
      return false;
    }
    if (_noCompte == null)
    {
      if (other._noCompte != null)
      {
        return false;
      }
    }
    else if (!_noCompte.equals(other._noCompte))
    {
      return false;
    }
    if (_ressources == null)
    {
      if (other._ressources != null)
      {
        return false;
      }
    }
    else if (!_ressources.equals(other._ressources))
    {
      return false;
    }
    if (_servicetechniques == null)
    {
      if (other._servicetechniques != null)
      {
        return false;
      }
    }
    else if (!_servicetechniques.equals(other._servicetechniques))
    {
      return false;
    }
    if (_taillePieceJointe == null)
    {
      if (other._taillePieceJointe != null)
      {
        return false;
      }
    }
    else if (!_taillePieceJointe.equals(other._taillePieceJointe))
    {
      return false;
    }
    if (_typeService == null)
    {
      if (other._typeService != null)
      {
        return false;
      }
    }
    else if (!_typeService.equals(other._typeService))
    {
      return false;
    }
    if (_typeServiceMail == null)
    {
      if (other._typeServiceMail != null)
      {
        return false;
      }
    }
    else if (!_typeServiceMail.equals(other._typeServiceMail))
    {
      return false;
    }
    if (_volumeBoite == null)
    {
      if (other._volumeBoite != null)
      {
        return false;
      }
    }
    else if (!_volumeBoite.equals(other._volumeBoite))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the audits
   */
  public List<Audit> getAudits()
  {
    return _audits != null ? new ArrayList<>(_audits) : null;

  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the erreurs
   */
  public List<Erreur> getErreurs()
  {
    return _erreurs != null ? new ArrayList<>(_erreurs) : null;

  }

  /**
   * @return the etatProvisioning
   */
  public String getEtatProvisioning()
  {
    return _etatProvisioning;
  }

  /**
   * @return the idStPfs
   */
  public String getIdStPfs()
  {
    return _idStPfs;
  }

  /**
   * @return the loginMail
   */
  public String getLoginMail()
  {
    return _loginMail;
  }

  /**
   * @return the niveauRestriction
   */
  public String getNiveauRestriction()
  {
    return _niveauRestriction;
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the ressources
   */
  public List<Ressource> getRessources()
  {
    return _ressources != null ? new ArrayList<>(_ressources) : null;
  }

  /**
   * @return the servicetechniques
   */
  public List<ServiceTechnique> getServicetechniques()
  {
    return _servicetechniques != null ? new ArrayList<>(_servicetechniques) : null;

  }

  /**
   * @return the taillePieceJointe
   */
  public Long getTaillePieceJointe()
  {
    return _taillePieceJointe;
  }

  /**
   * @return the typeService
   */
  public String getTypeService()
  {
    return _typeService;
  }

  /**
   * @return the typeServiceMail
   */
  public String getTypeServiceMail()
  {
    return _typeServiceMail;
  }

  /**
   * @return the volumeBoite
   */
  public Long getVolumeBoite()
  {
    return _volumeBoite;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_audits == null) ? 0 : _audits.hashCode());
    result = (prime * result) + ((_clientOperateur == null) ? 0 : _clientOperateur.hashCode());
    result = (prime * result) + ((_erreurs == null) ? 0 : _erreurs.hashCode());
    result = (prime * result) + ((_etatProvisioning == null) ? 0 : _etatProvisioning.hashCode());
    result = (prime * result) + ((_idStPfs == null) ? 0 : _idStPfs.hashCode());
    result = (prime * result) + ((_loginMail == null) ? 0 : _loginMail.hashCode());
    result = (prime * result) + ((_niveauRestriction == null) ? 0 : _niveauRestriction.hashCode());
    result = (prime * result) + ((_noCompte == null) ? 0 : _noCompte.hashCode());
    result = (prime * result) + ((_ressources == null) ? 0 : _ressources.hashCode());
    result = (prime * result) + ((_servicetechniques == null) ? 0 : _servicetechniques.hashCode());
    result = (prime * result) + ((_taillePieceJointe == null) ? 0 : _taillePieceJointe.hashCode());
    result = (prime * result) + ((_typeService == null) ? 0 : _typeService.hashCode());
    result = (prime * result) + ((_typeServiceMail == null) ? 0 : _typeServiceMail.hashCode());
    result = (prime * result) + ((_volumeBoite == null) ? 0 : _volumeBoite.hashCode());
    return result;
  }

  /**
   * @param audits_p
   *          the audits to set
   */
  public void setAudits(List<Audit> audits_p)
  {
    _audits = audits_p != null ? new ArrayList<>(_audits) : null;

  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param erreurs_p
   *          the erreurs to set
   */
  public void setErreurs(List<Erreur> erreurs_p)
  {
    _erreurs = erreurs_p != null ? new ArrayList<>(_erreurs) : null;
  }

  /**
   * @param etatProvisioning_p
   *          the etatProvisioning to set
   */
  public void setEtatProvisioning(String etatProvisioning_p)
  {
    _etatProvisioning = etatProvisioning_p;
  }

  /**
   * @param idStPfs_p
   *          the idStPfs to set
   */
  public void setIdStPfs(String idStPfs_p)
  {
    _idStPfs = idStPfs_p;
  }

  /**
   * @param loginMail_p
   *          the loginMail to set
   */
  public void setLoginMail(String loginMail_p)
  {
    _loginMail = loginMail_p;
  }

  /**
   * @param niveauRestriction_p
   *          the niveauRestriction to set
   */
  public void setNiveauRestriction(String niveauRestriction_p)
  {
    _niveauRestriction = niveauRestriction_p;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param ressources_p
   *          the ressources to set
   */
  public void setRessources(List<Ressource> ressources_p)
  {
    _ressources = ressources_p != null ? new ArrayList<>(ressources_p) : null;

  }

  /**
   * @param servicetechniques_p
   *          the servicetechniques to set
   */
  public void setServicetechniques(List<ServiceTechnique> servicetechniques_p)
  {
    _servicetechniques = servicetechniques_p != null ? new ArrayList<>(servicetechniques_p) : null;
  }

  /**
   * @param taillePieceJointe_p
   *          the taillePieceJointe to set
   */
  public void setTaillePieceJointe(Long taillePieceJointe_p)
  {
    _taillePieceJointe = taillePieceJointe_p;
  }

  /**
   * @param typeService_p
   *          the typeService to set
   */
  public void setTypeService(String typeService_p)
  {
    _typeService = typeService_p;
  }

  /**
   * @param typeServiceMail_p
   *          the typeServiceMail to set
   */
  public void setTypeServiceMail(String typeServiceMail_p)
  {
    _typeServiceMail = typeServiceMail_p;
  }

  /**
   * @param volumeBoite_p
   *          the volumeBoite to set
   */
  public void setVolumeBoite(Long volumeBoite_p)
  {
    _volumeBoite = volumeBoite_p;
  }

  @Override
  public String toString()
  {
    return "Referentiel [_typeService=" + _typeService + ", _loginMail=" + _loginMail + ", _ressources=" + _ressources + ", _etatProvisioning=" + _etatProvisioning + ", _typeServiceMail=" + _typeServiceMail + ", _taillePieceJointe=" + _taillePieceJointe + ", _volumeBoite=" + _volumeBoite + ", _niveauRestriction=" + _niveauRestriction + ", _noCompte=" + _noCompte + ", _clientOperateur=" + _clientOperateur + ", _audits=" + _audits + ", _erreurs=" + _erreurs + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$ //$NON-NLS-11$ //$NON-NLS-12$ //$NON-NLS-13$
  }
}
