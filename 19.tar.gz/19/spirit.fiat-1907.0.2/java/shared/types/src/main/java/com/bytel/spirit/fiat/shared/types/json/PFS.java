/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.shared.types.json;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public final class PFS implements Serializable
{
  /**
   * NiveauRestriction
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public enum NiveauRestriction
  {
    /**
     * NON_RESTREINT
     */
    NON_RESTREINT,

    /**
     * RESTREINT
     */
    RESTREINT;
  }

  /**
   * TypePfs
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public enum TypePfs
  {
    /**
     * ROMA
     */
    ROMA;
  }

  /**
   * TypeServiceMail
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public enum TypeServiceMail
  {
    /**
     * PRINCIPAL
     */
    PRINCIPAL,

    /**
     * SECONDAIRE
     */
    SECONDAIRE;
  }

  /**
   *
   */
  private static final long serialVersionUID = 662520624120151102L;

  /**
   * Type de la Plateforme de Service
   */
  @SerializedName("typePfs")
  private String _typePfs;

  /**
   *
   */
  @SerializedName("loginMail")
  private String _loginMail;

  /**
   * Type de service de Mail
   */
  @SerializedName("typeServiceMail")
  private String _typeServiceMail;

  /**
   * Taille de la piece jointe en MO
   */
  @SerializedName("taillePieceJointe")
  private Long _taillePieceJointe;

  /**
   * Taille Boite Mail en GO
   */
  @SerializedName("volumeBoite")
  private Long _volumeBoite;

  /**
   * Niveau de Restriction
   */
  @SerializedName("niveauRestriction")
  private String _niveauRestriction;

  /**
   * Etat d´áctivation de service de antivirus
   */
  @SerializedName("antivirus")
  private Boolean _antivirus;

  /**
   * Etat d'activation de service de antispam
   */
  @SerializedName("antispam")
  private Boolean _antispam;

  /**
   * Date de creation du compte sur la PFS
   */
  @SerializedName("dateCreationCompte")
  private LocalDate _dateCreationCompte;

  /**
   * Date de modification du compte sur la PFS
   */
  @SerializedName("dateModificationCompte")
  private LocalDate _dateModificationCompte;

  /**
   * Liste des deynchronisation detectees
   */
  @SerializedName("audits")
  private List<Audit> _audits;

  /**
   * Identifiant de l'action de corrective a appliquer
   */
  @SerializedName("idActionCorrective")
  private String _idActionCorrective;

  /**
   * Liste des erreurs detectees
   */
  @SerializedName("erreurs")
  private List<Erreur> _erreurs;

  /**
   * ID CompteMail
   */
  private transient String _idCompteMail;

  /**
   * idCompteMailPrincipal
   */
  private transient String _idCompteMailPrincipal;

  /**
   *
   */
  public PFS()
  {
    super();
  }

  /**
   * @param typePfs_p
   *          typeFPs
   * @param loginMail_p
   *          loginMail
   */
  public PFS(String typePfs_p, String loginMail_p)
  {
    super();

    _typePfs = typePfs_p;
    _loginMail = loginMail_p;
  }

  /**
   * Add an Audit object to the audit list
   *
   * @param audit_p
   *          The audit objet to add
   */
  public void addAudit(Audit audit_p)
  {
    if (_audits == null)
    {
      _audits = new ArrayList<>();
    }
    _audits.add(audit_p);
  }

  /**
   * Add an Erreur object to the list erreurs
   *
   * @param erreur_p
   *          The erreur objet to add.
   */
  public void addErreur(Erreur erreur_p)
  {
    if (_erreurs == null)
    {
      _erreurs = new ArrayList<>();
    }
    _erreurs.add(erreur_p);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PFS other = (PFS) obj;
    if (_antispam == null)
    {
      if (other._antispam != null)
      {
        return false;
      }
    }
    else if (!_antispam.equals(other._antispam))
    {
      return false;
    }
    if (_antivirus == null)
    {
      if (other._antivirus != null)
      {
        return false;
      }
    }
    else if (!_antivirus.equals(other._antivirus))
    {
      return false;
    }
    if (_audits == null)
    {
      if (other._audits != null)
      {
        return false;
      }
    }
    else if (!_audits.equals(other._audits))
    {
      return false;
    }
    if (_dateCreationCompte == null)
    {
      if (other._dateCreationCompte != null)
      {
        return false;
      }
    }
    else if (!_dateCreationCompte.equals(other._dateCreationCompte))
    {
      return false;
    }
    if (_dateModificationCompte == null)
    {
      if (other._dateModificationCompte != null)
      {
        return false;
      }
    }
    else if (!_dateModificationCompte.equals(other._dateModificationCompte))
    {
      return false;
    }
    if (_erreurs == null)
    {
      if (other._erreurs != null)
      {
        return false;
      }
    }
    else if (!_erreurs.equals(other._erreurs))
    {
      return false;
    }
    if (_idActionCorrective == null)
    {
      if (other._idActionCorrective != null)
      {
        return false;
      }
    }
    else if (!_idActionCorrective.equals(other._idActionCorrective))
    {
      return false;
    }
    if (_idCompteMail == null)
    {
      if (other._idCompteMail != null)
      {
        return false;
      }
    }
    else if (!_idCompteMail.equals(other._idCompteMail))
    {
      return false;
    }
    if (_idCompteMailPrincipal == null)
    {
      if (other._idCompteMailPrincipal != null)
      {
        return false;
      }
    }
    else if (!_idCompteMailPrincipal.equals(other._idCompteMailPrincipal))
    {
      return false;
    }
    if (_loginMail == null)
    {
      if (other._loginMail != null)
      {
        return false;
      }
    }
    else if (!_loginMail.equals(other._loginMail))
    {
      return false;
    }
    if (_niveauRestriction == null)
    {
      if (other._niveauRestriction != null)
      {
        return false;
      }
    }
    else if (!_niveauRestriction.equals(other._niveauRestriction))
    {
      return false;
    }
    if (_taillePieceJointe == null)
    {
      if (other._taillePieceJointe != null)
      {
        return false;
      }
    }
    else if (!_taillePieceJointe.equals(other._taillePieceJointe))
    {
      return false;
    }
    if (_typePfs == null)
    {
      if (other._typePfs != null)
      {
        return false;
      }
    }
    else if (!_typePfs.equals(other._typePfs))
    {
      return false;
    }
    if (_typeServiceMail == null)
    {
      if (other._typeServiceMail != null)
      {
        return false;
      }
    }
    else if (!_typeServiceMail.equals(other._typeServiceMail))
    {
      return false;
    }
    if (_volumeBoite == null)
    {
      if (other._volumeBoite != null)
      {
        return false;
      }
    }
    else if (!_volumeBoite.equals(other._volumeBoite))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the antispam
   */
  public Boolean getAntispam()
  {
    return _antispam;
  }

  /**
   * @return the antivirus
   */
  public Boolean getAntivirus()
  {
    return _antivirus;
  }

  /**
   * @return the audits
   */
  public List<Audit> getAudits()
  {
    return _audits != null ? new ArrayList<>(_audits) : null;
  }

  /**
   * @return the dateCreationCompte
   */
  public LocalDate getDateCreationCompte()
  {
    return _dateCreationCompte;
  }

  /**
   * @return the dateModificationCompte
   */
  public LocalDate getDateModificationCompte()
  {
    return _dateModificationCompte;
  }

  /**
   * @return the erreurs
   */
  public List<Erreur> getErreurs()
  {
    return _erreurs != null ? new ArrayList<>(_erreurs) : null;
  }

  /**
   * @return the idActionCorrective
   */
  public String getIdActionCorrective()
  {
    return _idActionCorrective;
  }

  /**
   * @return the idCompteMail
   */
  public String getIdCompteMail()
  {
    return _idCompteMail;
  }

  /**
   * @return the idCompteMailPrincipal
   */
  public String getIdCompteMailPrincipal()
  {
    return _idCompteMailPrincipal;
  }

  /**
   * @return the loginMail
   */
  public String getLoginMail()
  {
    return _loginMail;
  }

  /**
   * @return the niveauRestriction
   */
  public String getNiveauRestriction()
  {
    return _niveauRestriction;
  }

  /**
   * @return the taillePieceJointe
   */
  public Long getTaillePieceJointe()
  {
    return _taillePieceJointe;
  }

  /**
   * @return the typePfs
   */
  public String getTypePfs()
  {
    return _typePfs;
  }

  /**
   * @return the typeServiceMail
   */
  public String getTypeServiceMail()
  {
    return _typeServiceMail;
  }

  /**
   * @return the volumeBoite
   */
  public Long getVolumeBoite()
  {
    return _volumeBoite;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_antispam == null) ? 0 : _antispam.hashCode());
    result = (prime * result) + ((_antivirus == null) ? 0 : _antivirus.hashCode());
    result = (prime * result) + ((_audits == null) ? 0 : _audits.hashCode());
    result = (prime * result) + ((_dateCreationCompte == null) ? 0 : _dateCreationCompte.hashCode());
    result = (prime * result) + ((_dateModificationCompte == null) ? 0 : _dateModificationCompte.hashCode());
    result = (prime * result) + ((_erreurs == null) ? 0 : _erreurs.hashCode());
    result = (prime * result) + ((_idActionCorrective == null) ? 0 : _idActionCorrective.hashCode());
    result = (prime * result) + ((_idCompteMail == null) ? 0 : _idCompteMail.hashCode());
    result = (prime * result) + ((_idCompteMailPrincipal == null) ? 0 : _idCompteMailPrincipal.hashCode());
    result = (prime * result) + ((_loginMail == null) ? 0 : _loginMail.hashCode());
    result = (prime * result) + ((_niveauRestriction == null) ? 0 : _niveauRestriction.hashCode());
    result = (prime * result) + ((_taillePieceJointe == null) ? 0 : _taillePieceJointe.hashCode());
    result = (prime * result) + ((_typePfs == null) ? 0 : _typePfs.hashCode());
    result = (prime * result) + ((_typeServiceMail == null) ? 0 : _typeServiceMail.hashCode());
    result = (prime * result) + ((_volumeBoite == null) ? 0 : _volumeBoite.hashCode());
    return result;
  }

  /**
   * @param antispam_p
   *          the antispam to set
   */
  public void setAntispam(Boolean antispam_p)
  {
    _antispam = antispam_p;
  }

  /**
   * @param antivirus_p
   *          the antivirus to set
   */
  public void setAntivirus(Boolean antivirus_p)
  {
    _antivirus = antivirus_p;
  }

  /**
   * @param audits_p
   *          the audits to set
   */
  public void setAudits(List<Audit> audits_p)
  {
    _audits = audits_p != null ? new ArrayList<>(audits_p) : null;
  }

  /**
   * @param dateCreationCompte_p
   *          the dateCreationCompte to set
   */
  public void setDateCreationCompte(LocalDate dateCreationCompte_p)
  {
    _dateCreationCompte = dateCreationCompte_p;
  }

  /**
   * @param dateModificationCompte_p
   *          the dateModificationCompte to set
   */
  public void setDateModificationCompte(LocalDate dateModificationCompte_p)
  {
    _dateModificationCompte = dateModificationCompte_p;
  }

  /**
   * @param erreurs_p
   *          the erreurs to set
   */
  public void setErreurs(List<Erreur> erreurs_p)
  {
    _erreurs = erreurs_p != null ? new ArrayList<>(erreurs_p) : null;
  }

  /**
   * @param idActionCorrective_p
   *          the idActionCorrective to set
   */
  public void setIdActionCorrective(String idActionCorrective_p)
  {
    _idActionCorrective = idActionCorrective_p;
  }

  /**
   * @param idCompteMail_p
   *          the idCompteMail to set
   */
  public void setIdCompteMail(String idCompteMail_p)
  {
    _idCompteMail = idCompteMail_p;
  }

  /**
   * @param idCompteMailPrincipal_p
   *          the idCompteMailPrincipal to set
   */
  public void setIdCompteMailPrincipal(String idCompteMailPrincipal_p)
  {
    _idCompteMailPrincipal = idCompteMailPrincipal_p;
  }

  /**
   * @param loginMail_p
   *          the loginMail to set
   */
  public void setLoginMail(String loginMail_p)
  {
    _loginMail = loginMail_p;
  }

  /**
   * @param niveauRestriction_p
   *          the niveauRestriction to set
   */
  public void setNiveauRestriction(String niveauRestriction_p)
  {
    _niveauRestriction = niveauRestriction_p;
  }

  /**
   * @param taillePieceJointe_p
   *          the taillePieceJointe to set
   */
  public void setTaillePieceJointe(Long taillePieceJointe_p)
  {
    _taillePieceJointe = taillePieceJointe_p;
  }

  /**
   * @param typePfs_p
   *          the typePfs to set
   */
  public void setTypePfs(String typePfs_p)
  {
    _typePfs = typePfs_p;
  }

  /**
   * @param typeServiceMail_p
   *          the typeServiceMail to set
   */
  public void setTypeServiceMail(String typeServiceMail_p)
  {
    _typeServiceMail = typeServiceMail_p;
  }

  /**
   * @param volumeBoite_p
   *          the volumeBoite to set
   */
  public void setVolumeBoite(Long volumeBoite_p)
  {
    _volumeBoite = volumeBoite_p;
  }

  @Override
  public String toString()
  {
    return "PFS [_typePfs=" + _typePfs + ", _loginMail=" + _loginMail + ", _typeServiceMail=" + _typeServiceMail + ", _taillePieceJointe=" + _taillePieceJointe + ", _volumeBoite=" + _volumeBoite + ", _niveauRestriction=" + _niveauRestriction + ", _antivirus=" + _antivirus + ", _antispam=" + _antispam + ", _dateCreationCompte=" + _dateCreationCompte + ", _dateModificationCompte=" + _dateModificationCompte + ", _audits=" + _audits + ", _idActionCorrective=" + _idActionCorrective + ", _erreurs=" + _erreurs + ", _idCompteMail=" + _idCompteMail + ", _idCompteMailPrincipal=" + _idCompteMailPrincipal + "]";
  }

}
