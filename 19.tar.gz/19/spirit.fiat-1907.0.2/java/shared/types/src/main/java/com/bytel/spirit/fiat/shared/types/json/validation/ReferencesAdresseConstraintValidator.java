/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.shared.types.json.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.bytel.ravel.common.utils.StringTools;
import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.bytel.spirit.fiat.shared.types.json.ReferencesAdresse;

/**
 *
 * @author mfreire
 * @version ($Revision$ $Date$)
 */
public final class ReferencesAdresseConstraintValidator implements ConstraintValidator<ReferencesAdresseConstraint, ReferencesAdresse>
{

  @Override
  public boolean isValid(ReferencesAdresse value_p, ConstraintValidatorContext context_p)
  {
    if (StringTools.areAllNullOrEmpty(value_p.getHexacle(), value_p.getIdentifiantImeuble(), value_p.getAdresseLibre()))
    {
      if ((value_p.getRivoli() == null) && (value_p.getHexacleVoie() == null) && (value_p.getReferenceGeo() == null))
      {
        context_p.disableDefaultConstraintViolation();
        context_p.buildConstraintViolationWithTemplate(IMessageFormatKeys.CONDITIONAL_FIELD).addPropertyNode("< au moins une reference necessaire >").addConstraintViolation();
        return false;
      }

    }

    return true;
  }

}
