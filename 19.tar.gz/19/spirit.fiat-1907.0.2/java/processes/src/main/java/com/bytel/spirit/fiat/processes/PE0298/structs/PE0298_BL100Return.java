/**
 *
 */
package com.bytel.spirit.fiat.processes.PE0298.structs;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;

/**
 * @author kbettenc
 *
 */
public class PE0298_BL100Return extends AbstractBLReturn
{
  /**
   *
   */
  private static final long serialVersionUID = 6329162960234562624L;

  /**
   * Identifiant de la demande
   */
  private String _noCompte;

  /**
   * Identifiant de la demande
   */
  private String _noContrat;

  /**
   * Identifiant de la demande
   */
  private String _clientOperateur;

  /**
   * Default constructor
   */
  public PE0298_BL100Return(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @param noCompte_p
   * @param noContrat_p
   * @param clientOperateur_p
   */
  public PE0298_BL100Return(Retour retour_p, String noCompte_p, String noContrat_p, String clientOperateur_p)
  {
    super(retour_p);
    _noCompte = noCompte_p;
    _noContrat = noContrat_p;
    _clientOperateur = clientOperateur_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0298_BL100Return other = (PE0298_BL100Return) obj;
    if (_clientOperateur == null)
    {
      if (other._clientOperateur != null)
      {
        return false;
      }
    }
    else if (!_clientOperateur.equals(other._clientOperateur))
    {
      return false;
    }
    if (_noCompte == null)
    {
      if (other._noCompte != null)
      {
        return false;
      }
    }
    else if (!_noCompte.equals(other._noCompte))
    {
      return false;
    }
    if (_noContrat == null)
    {
      if (other._noContrat != null)
      {
        return false;
      }
    }
    else if (!_noContrat.equals(other._noContrat))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the noContrat
   */
  public String getNoContrat()
  {
    return _noContrat;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_clientOperateur == null) ? 0 : _clientOperateur.hashCode());
    result = (prime * result) + ((_noCompte == null) ? 0 : _noCompte.hashCode());
    result = (prime * result) + ((_noContrat == null) ? 0 : _noContrat.hashCode());
    return result;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param noContrat_p
   *          the noContrat to set
   */
  public void setNoContrat(String noContrat_p)
  {
    _noContrat = noContrat_p;
  }
}
