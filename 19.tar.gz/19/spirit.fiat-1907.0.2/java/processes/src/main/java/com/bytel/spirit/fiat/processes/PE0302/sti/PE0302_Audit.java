/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.squareup.moshi.Json;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0302_Audit implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -1566810398298508869L;

  /**
   * diagnostic
   */
  @Json(name = "diagnostic")
  private String _diagnostic;
  /**
   * libelle
   */
  @Json(name = "libelle")
  private String _libelle;
  /**
   * parameters
   */
  @Json(name = "parameters")
  private List<String> _parameters;

  /**
   * @return the diagnostic
   */
  public String getDiagnostic()
  {
    return _diagnostic;
  }

  /**
   * @return the libelle
   */
  public String getLibelle()
  {
    return _libelle;
  }

  /**
   * @return the parameters
   */
  public List<String> getParameters()
  {
    return _parameters != null ? new ArrayList<>(_parameters) : new ArrayList<>();

  }

  /**
   * @param diagnostic_p
   *          the diagnostic to set
   */
  public void setDiagnostic(String diagnostic_p)
  {
    _diagnostic = diagnostic_p;
  }

  /**
   * @param libelle_p
   *          the libelle to set
   */
  public void setLibelle(String libelle_p)
  {
    _libelle = libelle_p;
  }

  /**
   * @param parameters_p
   *          the parameters to set
   */
  public void setParameters(List<String> parameters_p)
  {
    _parameters = new ArrayList<>(parameters_p);
  }

}
