/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0221;

import static java.util.Objects.isNull;
import static java.util.Objects.nonNull;

import java.text.MessageFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.BL5280_RecupererTypeAccesNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5280_RecupererTypeAccesNoTelephone.BL5280_RecupererTypeAccesNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL5270_Return;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0221.structs.PE0221_BL001Return;
import com.bytel.spirit.fiat.processes.PE0221.structs.PE0221_BL002Return;
import com.bytel.spirit.fiat.processes.PE0221.structs.PE0221_GetResponse;
import com.bytel.spirit.fiat.processes.PE0221.structs.PE0221_ReponseFonctionnelle;
import com.bytel.spirit.fiat.processes.PE0221.structs.types.Appel;
import com.bytel.spirit.fiat.processes.PE0221.structs.types.AppelPfs;
import com.bytel.spirit.fiat.processes.structs.XLink;
import com.google.gson.Gson;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PE0221_JournalAppels extends SpiritRestApiProcessSkeleton
{
  /**
   * Holds context data for PE0221_JournalAppels
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public static final class PE0221_JournalAppelsContext extends Context
  {
    /**
     * The serial UID
     */
    private static final long serialVersionUID = -4056932692971584215L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0221_START;

    /**
     * The retour of the process
     */
    private Retour _processRetour;

    /**
     * The noTelephone from the request
     */
    private String _noTelephone;

    /**
     * The noJours from the request
     */
    private Integer _noJours;

    /**
     * The limite from the request
     */
    private Integer _limite;

    /**
     *
     */
    private PE0221_GetResponse _pe0221GetResponse;

    /**
     * @return the limite
     */
    public Integer getLimite()
    {
      return _limite;
    }

    /**
     * @return the noJours
     */
    public Integer getNoJours()
    {
      return _noJours;
    }

    /**
     * @return value of noTelephone
     */
    public String getNoTelephone()
    {
      return _noTelephone;
    }

    /**
     * @return the pe0221GetResponse
     */
    public PE0221_GetResponse getPe0221GetResponse()
    {
      return _pe0221GetResponse;
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return value of state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param limite_p
     *          the limite to set
     */
    public void setLimite(Integer limite_p)
    {
      _limite = limite_p;
    }

    /**
     * @param noJours_p
     *          the noJours to set
     */
    public void setNoJours(Integer noJours_p)
    {
      _noJours = noJours_p;
    }

    /**
     * @param noTelephone_p
     *          The noTelephone to set.
     */
    public void setNoTelephone(String noTelephone_p)
    {
      _noTelephone = noTelephone_p;
    }

    /**
     * @param pe0221GetResponse_p
     *          the pe0221GetResponse to set
     */
    public void setPe0221GetResponse(PE0221_GetResponse pe0221GetResponse_p)
    {
      _pe0221GetResponse = pe0221GetResponse_p;
    }

    /**
     * @param processRetour_p
     *          the processRetour to set
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param state_p
     *          The state to set.
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }
  }

  /**
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0221_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call BL001
     */
    PE0221_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL100
     */
    PE0221_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL002
     */
    PE0221_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call SI002
     */
    PE0221_SI002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PE0221_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   *
   */
  private static final String IDC = "idc"; //$NON-NLS-1$

  /**
   * The serial UID
   */
  private static final long serialVersionUID = 4622319449524057461L;

  /**
   * OPERATION_LIGNES_TEL
   */
  protected static final String OPERATION_LIGNES_TEL = "/lignes-tel/"; //$NON-NLS-1$

  /**
   * OPERATION_JOURNAUX_APPELS
   */
  protected static final String OPERATION_JOURNAUX_APPELS = "/journaux-appels"; //$NON-NLS-1$

  /**
   *
   */
  private static final String TYPOLOGIE_APPEL_SORTANT = "SORTANT"; //$NON-NLS-1$

  /**
   *
   */
  private static final String TYPOLOGIE_APPEL_ENTRANT = "ENTRANT"; //$NON-NLS-1$

  /**
   *
   */
  private static final String TYPOLOGIE_APPEL_EN_ABSENCE = "EN_ABSENCE"; //$NON-NLS-1$

  /**
   * The constant for BL001.ParameterNullOrEmpty message
   */
  private static final String MESSAGE_PARAMETER_NULL_OR_EMPTY = Messages.getString("PE0221.BL001.ParameterNullOrEmpty"); //$NON-NLS-1$

  /**
   * The constant for BL100.TelephoneInvalide message
   */
  private static final String MESSAGE_INVALID_PHONE_NUMBER = Messages.getString("PE0221.BL100.TelephoneInvalide"); //$NON-NLS-1$

  /**
   * The constant for BL100.TelephoneInvalide message
   */
  private static final String MESSAGE_UNKNOWN_PHONE_NUMBER = Messages.getString("PE0221.BL100.TelephoneInconnu"); //$NON-NLS-1$

  /**
   * The constant for BL100.TelephoneInvalide message
   */
  private static final String MESSAGE_SERVICE_INDISPO = Messages.getString("PE0221.BL100.ServiceIndisponible"); //$NON-NLS-1$

  /**
   * KPSA_PROCESS_CONSULTER_APPELS_PFS
   */
  private static final String KPSA_PROCESS_CONSULTER_APPELS_PFS = "consulterAppelsPfs"; //$NON-NLS-1$

  /**
   * KPSA_PARAM_NO_TELEPHONE
   */
  private static final String KPSA_PARAM_NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   * KPSA_PARAM_DATE_DEBUT_RECHERCHE
   */
  private static final String KPSA_PARAM_DATE_DEBUT_RECHERCHE = "dateDebutRecherche"; //$NON-NLS-1$

  /**
   * PARAM_NO_TELEPHONE constant
   */
  private static final String PARAM_NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   * PARAM_NO_JOURS constant
   */
  private static final String PARAM_NO_JOURS = "noJours"; //$NON-NLS-1$

  /**
   * LIMITE constant
   */
  private static final String PARAM_LIMITE = "limite"; //$NON-NLS-1$

  /**
   * Process context instance
   */
  protected PE0221_JournalAppelsContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0221_JournalAppelsContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String s_p)
  {
    // Not required for now in Ravel
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param request_p
   *          Object technique «virtuel» regroupant l'ensemble des informations fournies en entrées du service REST
   *          (PATH + paramètres de l'URL, headers http, body http)
   * @return Pair of types Retour, PE0221_BL001_Return
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  protected Pair<Retour, PE0221_BL001Return> PE0221_BL001_VerifierDonneesConsultation(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    // Get QueryParam for noTelephone
    for (Parameter parameter : request_p.getUrlParameters().getUrlParameters())
    {
      if (PARAM_NO_TELEPHONE.equals(parameter.getName()))
      {
        _processContext.setNoTelephone(parameter.getValue());
      }
    }

    final Retour retour = checkRequestParameters(request_p);
    if (RetourFactory.isRetourNOK(retour))
    {
      return new Pair<>(retour, null);
    }

    final PE0221_BL001Return bl001Return = new PE0221_BL001Return(LocalDateTime.now().minusDays(_processContext.getNoJours()));
    bl001Return.setNoTelephone(_processContext.getNoTelephone());
    bl001Return.setLimit(_processContext.getLimite());

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_OAUTH2_IDCONTRATS.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        String[] listeContract = header.getValue().trim().split(StringConstants.SEMICOLON_SEPARATOR);
        for (String contract : listeContract)
        {
          String[] contractElement = contract.split(","); //$NON-NLS-1$
          for (int i = 0; i < contractElement.length; i++)
          {
            String[] idContract = contractElement[i].split("="); //$NON-NLS-1$
            if (IDC.equals(idContract[0]))
            {
              bl001Return.addContratOauth(idContract[1]);
            }
          }
        }
      }
    }

    // Set mode appel
    bl001Return.setModeAppel(request_p.getMetadata(IMetadata.METADATA_CANAL));

    //Enrichissement objet oTracabilite
    final Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, request_p.getIdClient());
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, _processContext.getNoTelephone());

    BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
    bl1700.execute(this);

    // Retour OK
    return new Pair<>(RetourFactory.createOkRetour(), bl001Return);
  }

  /**
   * Format response to the client
   *
   * @param retour_p
   *          Result of bl001.
   * @param tracabilite_p
   *          Tracabilite
   * @param pe0221GetResponse_p
   *          Resultat du traitement fonctionnele retourné par le PI KPSA
   * @return Pair of types Retour, PE0221_BL002_Return
   */
  @LogProcessBL
  protected Pair<Retour, PE0221_BL002Return> PE0221_BL002_FormaterReponseConsultation(Tracabilite tracabilite_p, Retour retour_p, PE0221_GetResponse pe0221GetResponse_p)
  {
    PE0221_BL002Return bl002Return = new PE0221_BL002Return();
    ReponseErreur responseError = new ReponseErreur();

    if (RetourFactory.isRetourNOK(retour_p))
    {
      responseError.setError(retour_p.getDiagnostic());
      responseError.setErrorDescription(retour_p.getLibelle());
      bl002Return.setReponseErreur(responseError);
      return new Pair<>(retour_p, bl002Return);
    }

    bl002Return.setPe0221RetourGET(pe0221GetResponse_p);
    return new Pair<>(retour_p, bl002Return);
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      // Call BL001
      _processContext.setState(State.PE0221_BL001);
      Pair<Retour, PE0221_BL001Return> retourBL001 = PE0221_BL001_VerifierDonneesConsultation(tracabilite_p, request_p);
      _processContext.setProcessRetour(retourBL001._first);

      if (isRetourOK(retourBL001._first))
      {
        // Call BL100
        _processContext.setState(State.PE0221_BL100);
        Pair<Retour, PE0221_GetResponse> retourBL100 = PE0221_BL100_ConsulterJournauxAppels(tracabilite_p, retourBL001._second);
        _processContext.setProcessRetour(retourBL100._first);
        _processContext.setPe0221GetResponse(retourBL100._second);
      }

      // Call BL002
      _processContext.setState(State.PE0221_BL002);
      Pair<Retour, PE0221_BL002Return> bl002 = PE0221_BL002_FormaterReponseConsultation(tracabilite_p, _processContext.getProcessRetour(), _processContext.getPe0221GetResponse());
      _processContext.setProcessRetour(bl002._first);

      // Set process response
      syncResponse(request_p, bl002._second.getReponseErreur(), bl002._second.getPe0221RetourGET());
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));

      ReponseErreur responseError = new ReponseErreur();
      responseError.setError(IMegSpiritConsts.TRAITEMENT_ARRETE);
      responseError.setErrorDescription(exception.getMessage());

      // Set process response
      syncResponse(request_p, responseError, null);
    }
    finally
    {
      // Set process retour
      this.setRetour(_processContext.getProcessRetour());
      // Set end state
      _processContext.setState(State.PE0221_END);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param reponserreur_p
   *          the reponserreur
   * @param pe0221_p
   *          variable pe0221
   */
  protected void syncResponse(Request request_p, ReponseErreur reponserreur_p, PE0221_GetResponse pe0221_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

      if (reponserreur_p != null)
      {
        ErrorCode errorCode;
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(reponserreur_p));
        switch (reponserreur_p.getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;

          case IMegSpiritConsts.ID_PA_INCONNU:
          case IMegSpiritConsts.NO_COMPTE_INCONNU:
          case IMegSpiritConsts.NO_TELEPHONE_EST_INCONNU:
          case IMegSpiritConsts.NO_TELEPHONE_INCONNU:
          case IMegSpiritConsts.SERVICE_NON_PROVISIONNE:
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;

          case IMegSpiritConsts.PFS_INDISPO:
            errorCode = ErrorCode.KO_00503;
            break;

          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }

        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0221_p));
        request_p.setResponse(new Response(ErrorCode.OK_00200, ravelResponse));
      }
    }
  }

  /**
   * Check the request parameters
   *
   * @param request_p
   *          request
   * @return {@link Retour}
   */
  private Retour checkRequestParameters(final Request request_p)
  {
    // Get URL parameters
    List<Parameter> urlParameters = request_p.getUrlParameters().getUrlParameters();

    for (Parameter parameter : urlParameters)
    {
      if (parameter.getName().equals(PARAM_NO_JOURS))
      {
        try
        {
          _processContext.setNoJours(Integer.parseInt(parameter.getValue()));
        }
        catch (Exception exception)
        {
          // Do nothing
        }
      }
      else if (parameter.getName().equals(PARAM_LIMITE))
      {
        try
        {
          _processContext.setLimite(Integer.parseInt(parameter.getValue()));
        }
        catch (Exception exception)
        {
          // Do nothing
        }
      }
    }

    if (StringTools.isNullOrEmpty(_processContext.getNoTelephone()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_PARAMETER_NULL_OR_EMPTY, PARAM_NO_TELEPHONE));
    }

    if (isNull(_processContext.getNoJours()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_PARAMETER_NULL_OR_EMPTY, PARAM_NO_JOURS));
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * @param listeAppels
   * @param typologieAppel
   */
  private int getNombreAppelsByTypologieAcces(List<Appel> listeAppels, String typologieAppel)
  {
    int nombreAppels = 0;
    for (Appel appel : listeAppels)
    {
      if (typologieAppel.equals(appel.getTypologieAppel()))
      {
        nombreAppels++;
      }
    }

    return nombreAppels;
  }

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @param bl001Return_p
   *          PE0221_BL001Return
   * @return Pair of types Retour, String
   * @throws RavelException
   */
  @LogProcessBL
  private Pair<Retour, PE0221_GetResponse> PE0221_BL100_ConsulterJournauxAppels(Tracabilite tracabilite_p, PE0221_BL001Return bl001Return_p) throws RavelException
  {
    //Récupérer le type de l’accés du NoTelephone
    final BL5280_RecupererTypeAccesNoTelephone bl5280 = new BL5280_RecupererTypeAccesNoTelephoneBuilder() //
        .tracabilite(tracabilite_p) //
        .noTelephone(bl001Return_p.getNoTelephone()) //
        .build();
    final String typeAcces = bl5280.execute(this);
    if (isRetourOK(bl5280.getRetour()))
    {
      if (!"FIXE".equals(typeAcces)) //$NON-NLS-1$
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PHONE_NUMBER, bl001Return_p.getNoTelephone())), null);
      }
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PHONE_NUMBER, bl001Return_p.getNoTelephone())), null);
    }

    //Identifier le Pfi a partir du Numero Telephone
    final BL5270_RecupererPfiParNoTelephone bl5270 = new BL5270_RecupererPfiParNoTelephoneBuilder().tracabilite(tracabilite_p).noTelephone(bl001Return_p.getNoTelephone()).build();
    final BL5270_Return bl5270Return = bl5270.execute(this);
    Retour retour = bl5270.getRetour();
    if (!isRetourOK(retour))
    {
      if (IMegConsts.CAT4.equals(retour.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(retour.getDiagnostic()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_INCONNU, MessageFormat.format(MESSAGE_UNKNOWN_PHONE_NUMBER, bl001Return_p.getNoTelephone())), null);
      }

      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPO), null);
    }

    // Contrôle des autorisations sur le numéro contrat
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001Return_p.getModeAppel()))
    {
      if (CollectionUtils.isEmpty(bl001Return_p.getListeContratOauth()) //
          || StringTools.isNullOrEmpty(bl5270Return.getNoContrat()) //
          || bl001Return_p.getListeContratOauth().stream().noneMatch(c -> c.equals(bl5270Return.getNoContrat())))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "acces refuse"), null); //$NON-NLS-1$
      }
    }

    //Declencher l’appel vers KPSA DIAG
    ListeParametre listParams = new ListeParametre();
    listParams.add(KPSA_PARAM_NO_TELEPHONE, bl001Return_p.getNoTelephone());

    // get dateDebutRecherche in format YYYY-MM-DDTHH:MI:SS.sTZD
    String dateDebutRecherche = null;
    if (bl001Return_p.getDateDebutRecherche() != null)
    {
      dateDebutRecherche = DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ.format(bl001Return_p.getDateDebutRecherche());
    }
    listParams.add(KPSA_PARAM_DATE_DEBUT_RECHERCHE, dateDebutRecherche);

    _processContext.setState(State.PE0221_SI002);
    PROV_SI002_ExecuterProcessus prov_SI002 = new PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder() //
        .tracabilite(tracabilite_p) //
        .processus(KPSA_PROCESS_CONSULTER_APPELS_PFS) //
        .priorite(10) //
        .listeParametres(listParams) //
        .build();
    ResponseConnector responseConnector = prov_SI002.execute(this);
    if (!isRetourOK(prov_SI002.getRetour()))
    {
      if (IMegConsts.CAT1.equals(prov_SI002.getRetour().getCategorie()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPO), null);
      }
      else if (IMegConsts.CAT2.equals(prov_SI002.getRetour().getCategorie()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPO), null);
      }
      else
      {
        return new Pair<>(prov_SI002.getRetour(), null);
      }
    }

    Gson gsonInstance = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_ddTHH_colon_mm_colon_ssZ);
    final PE0221_ReponseFonctionnelle functionalResponse = responseConnector.getFunctionalResponse(PE0221_ReponseFonctionnelle.class, gsonInstance);

    if (functionalResponse == null)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Messages.getString("PE0221.BL100.ErrorInFunctionalResponse")), null);
    }

    final PE0221_GetResponse pe0221Response = new PE0221_GetResponse();
    final List<AppelPfs> listeAppelPfs = functionalResponse.getItems();

    final List<Appel> listeAppels = new ArrayList<>();
    for (AppelPfs appelPfs : listeAppelPfs)
    {
      final Appel appel = new Appel();
      appel.setNumeroAppelant(appelPfs.getNumeroAppelant());
      appel.setNumeroAppele(appelPfs.getNumeroAppele());
      appel.setAboutissement(appelPfs.getAboutissement());
      appel.setNumeroTransfert(appelPfs.getNumeroTransfert());
      appel.setTypologieAppel(appelPfs.getTypologieAppel());
      appel.setDate(appelPfs.getDateDebut());
      appel.setDureeAppel(Duration.between(appelPfs.getDateDebut(), appelPfs.getDateFin()).toString());

      listeAppels.add(appel);
    }

    pe0221Response.setNombreAppelsEnAbsence(getNombreAppelsByTypologieAcces(listeAppels, TYPOLOGIE_APPEL_EN_ABSENCE));
    pe0221Response.setNombreAppelsRecu(getNombreAppelsByTypologieAcces(listeAppels, TYPOLOGIE_APPEL_ENTRANT));
    pe0221Response.setNombreAppelsEmis(getNombreAppelsByTypologieAcces(listeAppels, TYPOLOGIE_APPEL_SORTANT));

    if (nonNull(bl001Return_p.getLimit()) && (bl001Return_p.getLimit() != 0))
    {
      // Ordering appels by date
      listeAppels.sort(Comparator.comparing(Appel::getDate));
      Collections.reverse(listeAppels);

      final List<Appel> appelsAConserver = new ArrayList<>();
      for (int i = 0; i < Math.min(bl001Return_p.getLimit().intValue(), listeAppels.size()); i++)
      {
        appelsAConserver.add(listeAppels.get(i));
      }

      pe0221Response.setAppels(appelsAConserver);
    }
    else
    {
      pe0221Response.setAppels(listeAppels);
    }

    // Build SelfXlink
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001Return_p.getModeAppel()))
    {
      final XLink link = new XLink();
      link.setHref(OPERATION_LIGNES_TEL + bl001Return_p.getNoTelephone() + OPERATION_JOURNAUX_APPELS);
      pe0221Response.putLink(XLink.SELF, link);
    }

    return new Pair<>(RetourFactory.createOkRetour(), pe0221Response);
  }
}