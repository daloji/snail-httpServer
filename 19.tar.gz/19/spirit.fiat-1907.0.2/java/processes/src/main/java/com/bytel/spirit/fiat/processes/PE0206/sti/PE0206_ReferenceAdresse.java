/*******************************************************************************
* $Id: PE0206_ReferenceAdresse.java 14954 2018-12-20 11:10:00Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206.sti;

import java.io.Serializable;

import javax.validation.Valid;

import com.bytel.spirit.fiat.processes.PE0206.sti.validation.PE0206_ReferencesAdresseConstraint;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 14954 $ $Date: 2018-12-20 12:10:00 +0100 (jeu., 20 déc. 2018) $)
 */
@PE0206_ReferencesAdresseConstraint
public class PE0206_ReferenceAdresse implements Serializable
{
  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 2443941295373606652L;

  /**
   * hexacle
   */
  @SerializedName("hexacle")
  @Expose
  private String _hexacle;

  /**
   * rivoli
   */
  @SerializedName("rivoli")
  @Expose
  @Valid
  private PE0206_QuadrupletRivoli _rivoli;

  /**
   * hexacleVoie
   */
  @SerializedName("hexacleVoie")
  @Expose
  @Valid
  private PE0206_HexacleVoie _hexacleVoie;

  /**
   * referenceGeographique
   */
  @SerializedName("referenceGeographique")
  @Expose
  @Valid
  private PE0206_CoordonneesGeo _referenceGeo;

  /**
   * identifiantImmeuble
   */
  @SerializedName("identifiantImmeuble")
  @Expose
  private String _identifiantImeuble;

  /**
   * adresseLibre
   */
  @SerializedName("adresseLibre")
  @Expose
  private String _adresseLibre;

  /**
   * @return the adresseLibre
   */
  public String getAdresseLibre()
  {
    return _adresseLibre;
  }

  /**
   * @return the hexacle
   */
  public String getHexacle()
  {
    return _hexacle;
  }

  /**
   * @return the hexacleVoie
   */
  public PE0206_HexacleVoie getHexacleVoie()
  {
    return _hexacleVoie;
  }

  /**
   * @return the identifiantImeuble
   */
  public String getIdentifiantImeuble()
  {
    return _identifiantImeuble;
  }

  /**
   * @return the referenceGeo
   */
  public PE0206_CoordonneesGeo getReferenceGeo()
  {
    return _referenceGeo;
  }

  /**
   * @return the rivoli
   */
  public PE0206_QuadrupletRivoli getRivoli()
  {
    return _rivoli;
  }

  /**
   * @param adresseLibre_p
   *          the adresseLibre to set
   */
  public void setAdresseLibre(String adresseLibre_p)
  {
    _adresseLibre = adresseLibre_p;
  }

  /**
   * @param hexacle_p
   *          the hexacle to set
   */
  public void setHexacle(String hexacle_p)
  {
    _hexacle = hexacle_p;
  }

  /**
   * @param hexacleVoie_p
   *          the hexacleVoie to set
   */
  public void setHexacleVoie(PE0206_HexacleVoie hexacleVoie_p)
  {
    _hexacleVoie = hexacleVoie_p;
  }

  /**
   * @param identifiantImeuble_p
   *          the identifiantImeuble to set
   */
  public void setIdentifiantImeuble(String identifiantImeuble_p)
  {
    _identifiantImeuble = identifiantImeuble_p;
  }

  /**
   * @param referenceGeo_p
   *          the referenceGeo to set
   */
  public void setReferenceGeo(PE0206_CoordonneesGeo referenceGeo_p)
  {
    _referenceGeo = referenceGeo_p;
  }

  /**
   * @param rivoli_p
   *          the rivoli to set
   */
  public void setRivoli(PE0206_QuadrupletRivoli rivoli_p)
  {
    _rivoli = rivoli_p;
  }

}
