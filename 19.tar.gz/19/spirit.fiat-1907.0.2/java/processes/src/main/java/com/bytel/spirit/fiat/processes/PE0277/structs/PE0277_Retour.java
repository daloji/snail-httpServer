/*******************************************************************************
* $Id: PEP0147_Retour.java 6688 2018-06-04 12:19:03Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0277.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.fiat.shared.types.json.PBO;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Class used to return a Json response in PE0277
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
public class PE0277_Retour implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 2923623497557379756L;

  /**
   * resultsCount
   */
  @SerializedName("resultsCount")
  @Expose
  private int _resultsCount = 0;

  /**
   * items
   */
  @SerializedName("items")
  @Expose
  private List<PBO> _items;

  /**
   * @return the items
   */
  public List<PBO> getItems()
  {
    if (_items != null)
    {
      return new ArrayList<>(_items);
    }
    return null;
  }

  /**
   * @return the resultsCount
   */
  public Integer getResultsCount()
  {
    if (_items != null)
    {
      _resultsCount = _items.size();
    }

    return _resultsCount;
  }

  /**
   * @param items_p
   *          the listePbo to set
   */
  public void setItems(List<PBO> items_p)
  {
    if (items_p != null)
    {
      _items = new ArrayList<>(items_p);
      _resultsCount = _items.size();
    }

  }

  /**
   * @param items_p
   *          the list of items to get the size
   */
  public void setResultsCount(List<PBO> items_p)
  {
    _resultsCount = items_p.size();
  }

}
