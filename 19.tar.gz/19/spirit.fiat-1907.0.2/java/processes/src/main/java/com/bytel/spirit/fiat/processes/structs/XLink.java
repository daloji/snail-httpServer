/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.squareup.moshi.Json;

/**
 * @author fbarnabe
 * @version ($Revision$ $Date$)
 */
public class XLink implements Serializable
{
  /**
   * Serial UID
   */
  private static final long serialVersionUID = 8226999394705990012L;

  /**
   * SELF
   */
  public final static String SELF = "self"; //$NON-NLS-1$

  /**
   * href
   */
  @SerializedName("href")
  @Expose
  @Json(name = "href")
  private String _href;

  /**
   * Default constructor
   */
  public XLink()
  {
    // Default constructor
  }

  /**
   * Argument constructor
   *
   * @param href_p
   *          href
   */
  public XLink(String href_p)
  {
    _href = href_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    XLink other = (XLink) obj;
    if (_href == null)
    {
      if (other._href != null)
      {
        return false;
      }
    }
    else if (!_href.equals(other._href))
    {
      return false;
    }
    return true;
  }

  /**
   * @return value of _href
   */
  public String getHref()
  {
    return _href;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_href == null) ? 0 : _href.hashCode());
    return result;
  }

  /**
   * @param href_p
   *          The _href to set.
   */
  public void setHref(String href_p)
  {
    _href = href_p;
  }

  @Override
  public String toString()
  {
    return "XLink [_href=" + _href + "]";
  }
}
