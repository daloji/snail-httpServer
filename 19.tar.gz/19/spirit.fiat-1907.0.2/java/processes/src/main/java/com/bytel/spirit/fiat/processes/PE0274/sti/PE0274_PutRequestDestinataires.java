/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.functional.types.json.Destinataire;
import com.squareup.moshi.Json;

/**
 * MessageriesADistance Payload
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0274_PutRequestDestinataires implements Serializable
{
  /**
   * The id for serialization
   */
  private static final long serialVersionUID = 7354073310004193791L;

  /**
   * destinataires
   */
  @Json(name = "destinataires")
  private List<Destinataire> _destinataires;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0274_PutRequestDestinataires other = (PE0274_PutRequestDestinataires) obj;
    if (_destinataires == null)
    {
      if (other._destinataires != null)
      {
        return false;
      }
    }
    else if (!_destinataires.equals(other._destinataires))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the destinataires
   */
  public List<Destinataire> getDestinataires()
  {
    return _destinataires != null ? new ArrayList<>(_destinataires) : new ArrayList<>();
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_destinataires == null) ? 0 : _destinataires.hashCode());
    return result;
  }

  /**
   * @param destinataires_p
   *          the destinataires to set
   */
  public void setDestinataires(List<Destinataire> destinataires_p)
  {
    _destinataires = new ArrayList<>(destinataires_p);
  }
}
