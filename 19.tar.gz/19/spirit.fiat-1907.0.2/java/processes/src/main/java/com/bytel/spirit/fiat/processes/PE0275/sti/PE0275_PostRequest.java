/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : 814_837_RessourceMessage
 *  Package : com.bytel.spirit.fiat.processes.PE0275.structs
 *  Classe  : PE0275_PutRequest
 *  Auteur  : sdiop
 *
 */

package com.bytel.spirit.fiat.processes.PE0275.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.squareup.moshi.Json;

/**
 * @author fmonteir
 * @version ($Revision$ $Date$)
 */
public class PE0275_PostRequest implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 5711162770439733802L;

  /**
  *
  */
  public enum TypeMessagerie
  {
    VOIX, FAX;
  }

  /**
   *
   */
  @Json(name = "expediteur")
  private String _expediteur;

  /**
   *
   */
  @Json(name = "nomExpediteur")
  private String _nomExpediteur;

  @Json(name = "typeMessagerie")
  private String _typeMessagerie;

  @Json(name = "idMessagerie")
  private String _idMessagerie;

  @Json(name = "destinataires")
  private List<String> _destinataires;

  @Json(name = "nbPages")
  private Integer _nbPages;

  @Json(name = "emailNotification")
  private String _emailNotification;

  @Json(name = "emailCopieFax")
  private String _emailCopieFax;

  @Json(name = "suivi")
  private PE0275_SuiviPost _suivi;

  /**
   * @return value of _expediteur
   */
  public String getExpediteur()
  {
    return _expediteur;
  }

  /**
   * @param expediteur_p
   *          The _expediteur to set.
   */
  public void setExpediteur(String expediteur_p)
  {
    _expediteur = expediteur_p;
  }

  /**
   * @return value of _nomExpediteur
   */
  public String getNomExpediteur()
  {
    return _nomExpediteur;
  }

  /**
   * @param nomExpediteur_p
   *          The _nomExpediteur to set.
   */
  public void setNomExpediteur(String nomExpediteur_p)
  {
    _nomExpediteur = nomExpediteur_p;
  }

  /**
   * @return value of _typeMessagerie
   */
  public String getTypeMessagerie()
  {
    return _typeMessagerie;
  }

  /**
   * @param typeMessagerie_p
   *          The _typeMessagerie to set.
   */
  public void setTypeMessagerie(String typeMessagerie_p)
  {
    _typeMessagerie = typeMessagerie_p;
  }

  /**
   * @return value of _idMessagerie
   */
  public String getIdMessagerie()
  {
    return _idMessagerie;
  }

  /**
   * @param idMessagerie_p
   *          The _idMessagerie to set.
   */
  public void setIdMessagerie(String idMessagerie_p)
  {
    _idMessagerie = idMessagerie_p;
  }

  /**
   * @return value of _destinataires
   */
  public List<String> getDestinataires()
  {
    return _destinataires != null ? new ArrayList<>(_destinataires) : new ArrayList<>();
  }

  /**
   * @param destinataires_p
   *          The _destinataires to set.
   */
  public void setDestinataires(List<String> destinataires_p)
  {
    _destinataires = destinataires_p != null ? new ArrayList<>(destinataires_p) : new ArrayList<>();
  }

  /**
   * @return value of _nbPages
   */
  public Integer getNbPages()
  {
    return _nbPages;
  }

  /**
   * @param nbPages_p
   *          The _nbPages to set.
   */
  public void setNbPages(Integer nbPages_p)
  {
    _nbPages = nbPages_p;
  }

  /**
   * @return value of _emailNotification
   */
  public String getEmailNotification()
  {
    return _emailNotification;
  }

  /**
   * @param emailNotification_p
   *          The _emailNotification to set.
   */
  public void setEmailNotification(String emailNotification_p)
  {
    _emailNotification = emailNotification_p;
  }

  /**
   * @return value of _emailCopieFax
   */
  public String getEmailCopieFax()
  {
    return _emailCopieFax;
  }

  /**
   * @param emailCopieFax_p
   *          The _emailCopieFax to set.
   */
  public void setEmailCopieFax(String emailCopieFax_p)
  {
    _emailCopieFax = emailCopieFax_p;
  }

  /**
   * @return value of _suivi
   */
  public PE0275_SuiviPost getSuivi()
  {
    return _suivi;
  }

  /**
   * @param suivi_p
   *          The _suivi to set.
   */
  public void setSuivi(PE0275_SuiviPost suivi_p)
  {
    _suivi = suivi_p;
  }

  /**
   * default constructor
   * 
   * @param expediteur_p
   *          The _expediteur to set.
   * @param nomExpediteur_p
   *          The _nomExpediteur to set.
   * @param typeMessagerie_p
   *          The _typeMessagerie to set.
   * @param idMessagerie_p
   *          The _idMessagerie to set.
   * @param destinataires_p
   *          The _destinataires to set.
   * @param nbPages_p
   *          The _nbPages to set.
   * @param emailNotification_p
   *          The _emailNotification to set.
   * @param emailCopieFax_p
   *          The _emailCopieFax to set.
   * @param suivi_p
   *          The suivi to set
   */
  public PE0275_PostRequest(String expediteur_p, String nomExpediteur_p, String typeMessagerie_p, String idMessagerie_p, List<String> destinataires_p, Integer nbPages_p, String emailNotification_p, String emailCopieFax_p, PE0275_SuiviPost suivi_p)
  {
    _expediteur = expediteur_p;
    _nomExpediteur = nomExpediteur_p;
    _typeMessagerie = typeMessagerie_p;
    _idMessagerie = idMessagerie_p;
    _destinataires = new ArrayList<>(destinataires_p);
    _nbPages = nbPages_p;
    _emailNotification = emailNotification_p;
    _emailCopieFax = emailCopieFax_p;
    _suivi = suivi_p;
  }
}
