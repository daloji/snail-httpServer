/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223;

import static com.bytel.ravel.common.utils.RetourFactory.isRetourNOK;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.log.event.SystemLogEvent;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.BL5280_RecupererTypeAccesNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5280_RecupererTypeAccesNoTelephone.BL5280_RecupererTypeAccesNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL5270_Return;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.shared.functional.types.json.OptionAppelPfs;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0223.structs.PE0223_ResponseFonctionnelle;
import com.bytel.spirit.fiat.processes.PE0223.structs.get.PE0223_BL001GetReturn;
import com.bytel.spirit.fiat.processes.PE0223.structs.get.PE0223_BL002GetReturn;
import com.bytel.spirit.fiat.processes.PE0223.structs.get.PE0223_GetResponse;
import com.bytel.spirit.fiat.processes.PE0223.structs.put.IOptionAppelConsts;
import com.bytel.spirit.fiat.processes.PE0223.structs.put.PE0223_BL001PutReturn;
import com.bytel.spirit.fiat.processes.PE0223.structs.put.PE0223_PutRequest;
import com.bytel.spirit.fiat.processes.PE0223.structs.types.OptionAppel;
import com.bytel.spirit.fiat.processes.structs.XAction;
import com.bytel.spirit.fiat.processes.structs.XLink;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PE0223_OptionsAppels extends SpiritRestApiProcessSkeleton
{
  /**
   * Holds context data for PE0223_OptionsAppels
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public static final class PE0223_OptionsAppelsContext extends Context
  {
    /**
     * The serial UID
     */
    private static final long serialVersionUID = 9127139357989647720L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0223_START;

    /**
     * The retour of the process
     */
    private Retour _processRetour;

    /**
     * The identifiantFonctionnelPa from the request
     */
    private String _identifiantFonctionnelPa;

    /**
     * The idRequest
     */
    private String _idRequest;

    /**
     * The identifiantFonctionnelPa from the request
     */
    private String _clientOperateur;

    /**
     * The noCompte from the request
     */
    private String _noCompte;

    /**
     * The action for the request;
     */
    private String _action;

    /**
     * The type for the request;
     */
    private String _type;

    /**
     * The noTelephone from the request
     */
    private String _noTelephone;

    /**
     * The modeAppel
     */
    private String _modeAppel;

    /**
     * The Liste NoContrat B2R from the request
     */
    private List<String> _listeContratOauth = new ArrayList<>();

    /**
     * The ressources
     */
    private String _ressources;

    /**
     * @param contratOuath_p
     *          the contratOuath to add
     */
    public void addContratOauth(String contratOuath_p)
    {
      _listeContratOauth.add(contratOuath_p);
    }

    @Override
    public boolean equals(Object obj)
    {
      if (this == obj)
      {
        return true;
      }
      if (obj == null)
      {
        return false;
      }
      if (getClass() != obj.getClass())
      {
        return false;
      }
      PE0223_OptionsAppelsContext other = (PE0223_OptionsAppelsContext) obj;
      if (_action == null)
      {
        if (other._action != null)
        {
          return false;
        }
      }
      else if (!_action.equals(other._action))
      {
        return false;
      }
      if (_clientOperateur == null)
      {
        if (other._clientOperateur != null)
        {
          return false;
        }
      }
      else if (!_clientOperateur.equals(other._clientOperateur))
      {
        return false;
      }
      if (_idRequest == null)
      {
        if (other._idRequest != null)
        {
          return false;
        }
      }
      else if (!_idRequest.equals(other._idRequest))
      {
        return false;
      }
      if (_identifiantFonctionnelPa == null)
      {
        if (other._identifiantFonctionnelPa != null)
        {
          return false;
        }
      }
      else if (!_identifiantFonctionnelPa.equals(other._identifiantFonctionnelPa))
      {
        return false;
      }
      if (_listeContratOauth == null)
      {
        if (other._listeContratOauth != null)
        {
          return false;
        }
      }
      else if (!_listeContratOauth.equals(other._listeContratOauth))
      {
        return false;
      }
      if (_modeAppel == null)
      {
        if (other._modeAppel != null)
        {
          return false;
        }
      }
      else if (!_modeAppel.equals(other._modeAppel))
      {
        return false;
      }
      if (_noCompte == null)
      {
        if (other._noCompte != null)
        {
          return false;
        }
      }
      else if (!_noCompte.equals(other._noCompte))
      {
        return false;
      }
      if (_noTelephone == null)
      {
        if (other._noTelephone != null)
        {
          return false;
        }
      }
      else if (!_noTelephone.equals(other._noTelephone))
      {
        return false;
      }
      if (_processRetour == null)
      {
        if (other._processRetour != null)
        {
          return false;
        }
      }
      else if (!_processRetour.equals(other._processRetour))
      {
        return false;
      }
      if (_ressources == null)
      {
        if (other._ressources != null)
        {
          return false;
        }
      }
      else if (!_ressources.equals(other._ressources))
      {
        return false;
      }
      if (_state != other._state)
      {
        return false;
      }
      if (_type == null)
      {
        if (other._type != null)
        {
          return false;
        }
      }
      else if (!_type.equals(other._type))
      {
        return false;
      }
      return true;
    }

    /**
     * @return the action
     */

    public String getAction()
    {
      return _action;
    }

    /**
     * @return the clientOperateur
     */
    public String getClientOperateur()
    {
      return _clientOperateur;
    }

    /**
     * @return value of identifiantFonctionnelPa
     */
    public String getIdentifiantFonctionnelPa()
    {
      return _identifiantFonctionnelPa;
    }

    /**
     * @return the idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the listeContratOauth
     */
    public List<String> getListeContratOauth()
    {
      return new ArrayList<>(_listeContratOauth);
    }

    /**
     * @return the modeAppel
     */
    public String getModeAppel()
    {
      return _modeAppel;
    }

    /**
     * @return value of noCompte
     */
    public String getNoCompte()
    {
      return _noCompte;
    }

    /**
     * @return value of noTelephone
     */
    public String getNoTelephone()
    {
      return _noTelephone;
    }

    /**
     * @return value of processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the ressources
     */
    public String getRessources()
    {
      return _ressources;
    }

    /**
     * @return value of state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the type
     */
    public String getType()
    {
      return _type;
    }

    @Override
    public int hashCode()
    {
      final int prime = 31;
      int result = 1;
      result = (prime * result) + ((_action == null) ? 0 : _action.hashCode());
      result = (prime * result) + ((_clientOperateur == null) ? 0 : _clientOperateur.hashCode());
      result = (prime * result) + ((_idRequest == null) ? 0 : _idRequest.hashCode());
      result = (prime * result) + ((_identifiantFonctionnelPa == null) ? 0 : _identifiantFonctionnelPa.hashCode());
      result = (prime * result) + ((_listeContratOauth == null) ? 0 : _listeContratOauth.hashCode());
      result = (prime * result) + ((_modeAppel == null) ? 0 : _modeAppel.hashCode());
      result = (prime * result) + ((_noCompte == null) ? 0 : _noCompte.hashCode());
      result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
      result = (prime * result) + ((_processRetour == null) ? 0 : _processRetour.hashCode());
      result = (prime * result) + ((_ressources == null) ? 0 : _ressources.hashCode());
      result = (prime * result) + ((_state == null) ? 0 : _state.hashCode());
      result = (prime * result) + ((_type == null) ? 0 : _type.hashCode());
      return result;
    }

    /**
     * @param action_p
     *          the action to set
     */
    public void setAction(String action_p)
    {
      _action = action_p;
    }

    /**
     * @param clientOperateur_p
     *          the clientOperateur to set
     */
    public void setClientOperateur(String clientOperateur_p)
    {
      _clientOperateur = clientOperateur_p;
    }

    /**
     * @param identifiantFonctionnelPa_p
     *          The identifiantFonctionnelPa to set.
     */
    public void setIdentifiantFonctionnelPa(String identifiantFonctionnelPa_p)
    {
      _identifiantFonctionnelPa = identifiantFonctionnelPa_p;
    }

    /**
     * @param idRequest_p
     *          the idRequest to set
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param modeAppel_p
     *          the modeAppel to set
     */
    public void setModeAppel(String modeAppel_p)
    {
      _modeAppel = modeAppel_p;
    }

    /**
     * @param noCompte_p
     *          The noCompte to set.
     */
    public void setNoCompte(String noCompte_p)
    {
      _noCompte = noCompte_p;
    }

    /**
     * @param noTelephone_p
     *          The noTelephone to set.
     */
    public void setNoTelephone(String noTelephone_p)
    {
      _noTelephone = noTelephone_p;
    }

    /**
     * @param processRetour_p
     *          The processRetour to set.
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param ressources_p
     *          The ressources to set
     */
    public void setRessources(String ressources_p)
    {
      _ressources = ressources_p;
    }

    /**
     * @param state_p
     *          The state to set.
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param type_p
     *          the type to set
     */
    public void setType(String type_p)
    {
      _type = type_p;
    }
  }

  /**
   *
   * @author jpais
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0223_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call BL001
     */
    PE0223_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL100
     */
    PE0223_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL002
     */
    PE0223_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call SI002
     */
    PE0223_SI002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PE0223_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * The serial UID
   */
  private static final long serialVersionUID = -8502197543367858332L;

  /**
   * The constant for BL001.HeaderNullOrEmpty message
   */
  private static final String MESSAGE_INVALID_HEADER = Messages.getString("PE0223.BL001.HeaderNullOrEmpty"); //$NON-NLS-1$

  /**
   * The constant for BL001.idOptionInconnu message
   */
  private static final String MESSAGE_ID_OPTION_INCONNU = Messages.getString("PE0223.BL001.idOptionInconnu"); //$NON-NLS-1$

  /**
   * The constant for BL100.missingParameter message
   */
  private static final String MESSAGE_MISSING_PARAMETER = Messages.getString("PE0223.BL001.missingParameter"); //$NON-NLS-1$

  /**
   * The constant for BL100.emptyBody message
   */
  private static final String MESSAGE_EMPTY_BODY = Messages.getString("PE0223.BL100.emptyBody"); //$NON-NLS-1$

  /**
   * The constant for BL100.invalidParameter message
   */
  private static final String MESSAGE_INVALID_PARAMETER = Messages.getString("PE0223.BL100.invalidParameter"); //$NON-NLS-1$

  /**
   * The constant for BL100.noTelephoneInconnu message
   */
  private static final String MESSAGE_NO_TELEPHONE_INCONNU = Messages.getString("PE0223.BL100.noTelephoneInconnu"); //$NON-NLS-1$

  /**
   * The constant for BL100.serviceIndisponible message
   */
  private static final String MESSAGE_SERVICE_INDISPONIBLE = Messages.getString("PE0223.BL100.serviceIndisponible"); //$NON-NLS-1$

  /**
   * The constant for BL100.noTelephoneInvalide message
   */
  private static final String MESSAGE_NO_TELEPHONE_INVALIDE = Messages.getString("PE0223.BL100.noTelephoneInvalide"); //$NON-NLS-1$

  /**
   * PARAM_ACTION constant
   */
  private static final String PARAM_ACTION = "action"; //$NON-NLS-1$

  /**
   * PARAM_TYPE constant
   */
  private static final String PARAM_TYPE = "typeOptionAppel"; //$NON-NLS-1$

  /**
   * PARAM_NO_TELEPHONE constant
   */
  private static final String PARAM_NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   * PARAM_OPERATION constant
   */
  private static final String PARAM_OPERATION = "typeOperation"; //$NON-NLS-1$

  /**
   * PARAM_STATUT constant
   */
  private static final String PARAM_STATUT = "statut"; //$NON-NLS-1$

  /**
   * KPSA_PROCESS_CONSULTER_APPELS_PFS
   */
  private static final String KPSA_PROCESS_CONSULTER_OPTIONS_APPELS_PFS = "consulterOptionsAppelsPfs"; //$NON-NLS-1$

  /**
   * KPSA_PROCESS_CONSULTER_APPELS_PFS
   */
  private static final String KPSA_PROCESS_DESACTIVER_RENVOIS_APPEL = "desactiverRenvoisAppel"; //$NON-NLS-1$

  /**
   * KPSA_PROCESS_CONSULTER_APPELS_PFS
   */
  private static final String KPSA_PROCESS_MODIFIER_OPTION_APPEL = "modifierOptionAppel"; //$NON-NLS-1$

  /**
   * KPSA_PARAM_NO_TELEPHONE
   */
  private static final String KPSA_PARAM_NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   * The STATUT constant
   */
  private static final String KPSA_PARAM_STATUT = "statut"; //$NON-NLS-1$

  /**
   * The TYPE constant
   */
  private static final String KPSA_PARAM_TYPE_OPTON_APPEL = "typeOptionAppel"; //$NON-NLS-1$

  /**
   * The MODE_RENVOI constant
   */
  private static final String KPSA_PARAM_MODE_RENVOI = "modeRenvoi"; //$NON-NLS-1$

  /**
   * The NUMERO_RENVOI constant
   */
  private static final String KPSA_PARAM_NUMERO_RENVOI = "numeroRenvoi"; //$NON-NLS-1$

  /**
   * The NOMBRE_SONNERIES constant
   */
  private static final String KPSA_PARAM_NOMBRE_SONNERIES = "nombreSonneries"; //$NON-NLS-1$

  /**
   * modifierOptionAppel action
   */
  private static final String MODIFIER_OPTION_APPEL = "modifierOptionAppel"; //$NON-NLS-1$

  /**
   * desactiverRenvoisAppels action
   */
  private static final String DESACTIVER_RENVOIS_APPELS = "desactiverRenvoisAppels"; //$NON-NLS-1$

  /**
   * The type FIXE constant
   */
  private static final String TYPE_FIXE = "FIXE"; //$NON-NLS-1$

  /**
   * OPERATION_OPTIONS_APPELS
   */
  private static final String OPERATION_OPTIONS_APPELS = "/options-appels"; //$NON-NLS-1$

  /**
   * OPERATION_LIGNES_TEL
   */
  private static final String OPERATION_LIGNES_TEL = "/lignes-tel/"; //$NON-NLS-1$

  /**
  *
  */
  private static final String IDC = "idc"; //$NON-NLS-1$

  /**
   * Process context instance
   */
  protected PE0223_OptionsAppelsContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0223_OptionsAppelsContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String s_p)
  {
    // Not required for now in Ravel
  }

  /**
   * PE0223_BL001_VerifierDonneesConsultation
   *
   * @param tracabilite_p
   *          tracabilite
   * @param request_p
   *          request
   * @return Retour retour
   * @throws RavelException
   *           excetpion
   */
  @LogProcessBL
  protected Pair<Retour, PE0223_BL001GetReturn> PE0223_BL001_VerifierDonneesConsultation(Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    Retour retour = checkRequestHeaders(request_p);
    if (!isRetourOK(retour))
    {
      return new Pair<>(retour, null);
    }

    // Get QueryParam for noTelephone
    for (Parameter parameter : request_p.getUrlParameters().getUrlParameters())
    {
      if (PARAM_NO_TELEPHONE.equals(parameter.getName()))
      {
        _processContext.setNoTelephone(parameter.getValue());
      }
    }

    getUrlParametersIntoProcessContext(request_p);

    if (StringTools.isNullOrEmpty(_processContext.getNoTelephone()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, PARAM_NO_TELEPHONE)), null);
    }

    // Build BL001 response
    PE0223_BL001GetReturn bl001GetRetour = new PE0223_BL001GetReturn();
    bl001GetRetour.setNoTelephone(_processContext.getNoTelephone());
    bl001GetRetour.setModeAppel(_processContext.getModeAppel());
    bl001GetRetour.setListeContratOauth(_processContext.getListeContratOauth());

    //Enrichissement objet oTracabilite
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, _processContext.getIdRequest());
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, _processContext.getNoTelephone());
    BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
    bl1700.execute(this);

    return new Pair<>(RetourFactory.createOkRetour(), bl001GetRetour);
  }

  /**
   *
   * @param tracabilite_p
   *          The tracability
   * @param request_p
   *          The request
   * @return {@link PE0223_BL001PutReturn}
   * @throws RavelException
   *           Exception thrown if something fails
   */
  @LogProcessBL
  protected Pair<Retour, PE0223_BL001PutReturn> PE0223_BL001_VerifierDonneesModification(Tracabilite tracabilite_p, Request request_p) throws RavelException
  {
    Retour retourHeaders = checkRequestHeaders(request_p);
    if (!isRetourOK(retourHeaders))
    {
      return new Pair<>(retourHeaders, null);
    }

    PE0223_BL001PutReturn retourBL001 = new PE0223_BL001PutReturn();
    retourBL001.setModeAppel(_processContext.getModeAppel());
    retourBL001.setListeContratOauth(_processContext.getListeContratOauth());

    // Get the Url parameters
    getUrlParametersIntoProcessContext(request_p);

    // Get the body parameters
    PE0223_PutRequest putRequest = GsonTools.getIso8601Sec().fromJson(request_p.getPayload(), PE0223_PutRequest.class);

    // Check the body request
    if (putRequest == null)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_EMPTY_BODY), null);
    }

    // Case idOptionAppel
    if (StringTools.isNotNullOrEmpty(request_p.getUrlDynamicParameters()))
    {
      retourBL001.setIdOptionAppel(request_p.getUrlDynamicParameters());

      // Decrypt the idOption
      String idOptionDecrypted;
      try
      {
        idOptionDecrypted = PasswordDecrypter.decryptForURL(retourBL001.getIdOptionAppel());
      }
      catch (RavelException exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, "Error decrypting idOption", exception)); //$NON-NLS-1$
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_OPTION_APPEL_INCONNU, MessageFormat.format(MESSAGE_ID_OPTION_INCONNU, retourBL001.getIdOptionAppel())), null);
      }

      // Get the parameters type and noTelephone
      String[] parametresOptionalAppel = idOptionDecrypted.split("#"); //$NON-NLS-1$
      if (parametresOptionalAppel.length >= 3)
      {
        retourBL001.setNoContrat(parametresOptionalAppel[0]);
        retourBL001.setNoTelephone(parametresOptionalAppel[1]);
        retourBL001.setTypeOptionAppel(parametresOptionalAppel[2]);
      }
      else
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_OPTION_APPEL_INCONNU, MessageFormat.format(MESSAGE_ID_OPTION_INCONNU, retourBL001.getIdOptionAppel())), null);
      }
    } // Case NumTelephone and Action
    else
    {
      if (StringTools.isNullOrEmpty(_processContext.getNoTelephone()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, PARAM_NO_TELEPHONE, _processContext.getNoTelephone())), null);
      }
      retourBL001.setNoTelephone(_processContext.getNoTelephone());
      if (StringTools.isNullOrEmpty(_processContext.getAction()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, PARAM_OPERATION, _processContext.getAction())), null);
      }
    }

    // Parameters URL
    if (StringTools.isNullOrEmpty(retourBL001.getIdOptionAppel()))
    {
      if (DESACTIVER_RENVOIS_APPELS.equals(_processContext.getAction()))
      {
        retourBL001.setTypeOperation(DESACTIVER_RENVOIS_APPELS);
        if (!IOptionAppelConsts.STATUT_INACTIF.equals(putRequest.getStatut()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, PARAM_STATUT, putRequest.getStatut())), null);
        }
      }
      else
      {
        retourBL001.setTypeOperation(MODIFIER_OPTION_APPEL);
        // If the action is modifierOptionAppel and we don't have IdOptionAppel then the type must exist and be valid
        if (!isTypeOk(_processContext.getType()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, "type", _processContext.getType())), null); //$NON-NLS-1$
        }

        retourBL001.setTypeOptionAppel(_processContext.getType());
      }
    }
    else // Dynamic URL
    {
      retourBL001.setTypeOperation(MODIFIER_OPTION_APPEL);
    }

    // Check if the body status, modeRenvoi, nombreSonneries and numeroRenvoi are valid
    if (StringTools.isNullOrEmpty(putRequest.getStatut()))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, PARAM_STATUT, putRequest.getStatut())), null);
    }

    switch (putRequest.getStatut())
    {
      case IOptionAppelConsts.STATUT_ACTIF:
        Retour retour = statutActifSwitchCase(putRequest, retourBL001);
        if (isRetourNOK(retour))
        {
          return new Pair<>(retour, null);
        }

        retourBL001.setStatutOptionAppel(putRequest.getStatut());
        break;

      case IOptionAppelConsts.STATUT_INACTIF:
      case IOptionAppelConsts.STATUT_SUSPENDU:

        if (putRequest.getModeRenvoi() != null)
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, KPSA_PARAM_MODE_RENVOI, putRequest.getStatut())), null);
        }

        if (putRequest.getNumeroRenvoi() != null)
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, KPSA_PARAM_NUMERO_RENVOI, putRequest.getStatut())), null);
        }

        retourBL001.setStatutOptionAppel(putRequest.getStatut());
        break;

      default:
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, PARAM_STATUT, putRequest.getStatut())), null);
    }

    //Enrichissement objet oTracabilite
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, _processContext.getIdRequest());
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, _processContext.getNoTelephone());
    BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
    bl1700.execute(this);

    return new Pair<>(RetourFactory.createOkRetour(), retourBL001);
  }

  /**
   * PE0223_BL002_FormaterReponseConsultation
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retourIn_p
   *          retourBL001
   * @param reponse_p
   *          reponse
   * @return Pair<ReponseErreur, PE0223_Retour>
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  protected Pair<Retour, PE0223_BL002GetReturn> PE0223_BL002_FormaterReponseConsultation(Tracabilite tracabilite_p, Retour retourIn_p, PE0223_GetResponse reponse_p) throws RavelException
  {
    if (isRetourOK(retourIn_p))
    {
      return new Pair<>(retourIn_p, new PE0223_BL002GetReturn(null, reponse_p));
    }

    ReponseErreur responseErreeur = new ReponseErreur();
    responseErreeur.setError(retourIn_p.getDiagnostic());
    responseErreeur.setErrorDescription(retourIn_p.getLibelle());
    return new Pair<>(retourIn_p, new PE0223_BL002GetReturn(responseErreeur, null));
  }

  /**
   * @param tracabilite_p
   *          The tracabilite
   * @param retour_p
   *          The retourBL001
   * @return Pair<Retour, ReponseErreur>
   */
  @LogProcessBL
  protected Pair<Retour, ReponseErreur> PE0223_BL002_FormaterReponseModification(Tracabilite tracabilite_p, Retour retour_p)
  {
    if (isRetourNOK(retour_p))
    {
      ReponseErreur reponseErreur = new ReponseErreur();
      reponseErreur.setError(retour_p.getDiagnostic());
      reponseErreur.setErrorDescription(retour_p.getLibelle());
      return new Pair<>(retour_p, reponseErreur);
    }

    return new Pair<>(retour_p, null);
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      // Set process variables
      PE0223_GetResponse pe0223GetResponse = null;

      // Call BL001
      _processContext.setState(State.PE0223_BL001);
      Pair<Retour, PE0223_BL001GetReturn> retourBL001 = PE0223_BL001_VerifierDonneesConsultation(tracabilite_p, request_p);
      _processContext.setProcessRetour(retourBL001._first);

      if (isRetourOK(retourBL001._first))
      {
        // Call BL100
        _processContext.setState(State.PE0223_BL100);
        Pair<Retour, PE0223_GetResponse> retourBl100 = PE0223_BL100_ListerOptionsAppel(tracabilite_p, retourBL001._second);
        pe0223GetResponse = retourBl100._second;
        Retour retourBL100 = retourBl100._first;
        _processContext.setProcessRetour(retourBL100);
      }

      // Call BL002
      _processContext.setState(State.PE0223_BL002);
      Pair<Retour, PE0223_BL002GetReturn> bl002Retour = PE0223_BL002_FormaterReponseConsultation(tracabilite_p, _processContext.getProcessRetour(), pe0223GetResponse);

      // Set process retour
      this.setRetour(_processContext.getProcessRetour());

      // Set process response
      syncGetResponse(request_p, bl002Retour._second);
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));

      ReponseErreur responseError = new ReponseErreur();
      responseError.setError(IMegSpiritConsts.TRAITEMENT_ARRETE);
      responseError.setErrorDescription(exception.getMessage());

      // Set process response
      syncGetResponse(request_p, new PE0223_BL002GetReturn(responseError, null));
    }
    finally
    {
      // Set process retour
      this.setRetour(_processContext.getProcessRetour());
      // Set end state
      _processContext.setState(State.PE0223_END);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startPutProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      // Call BL001
      _processContext.setState(State.PE0223_BL001);
      Pair<Retour, PE0223_BL001PutReturn> bl001Retour = PE0223_BL001_VerifierDonneesModification(tracabilite_p, request_p);
      Retour retourBL001 = bl001Retour._first;
      _processContext.setProcessRetour(retourBL001);

      if (RetourFactory.isRetourOK(retourBL001))
      {
        PE0223_BL001PutReturn pe0223BL001Retour = bl001Retour._second;

        // CAll BL100
        _processContext.setState(State.PE0223_BL100);
        Retour retourBL100 = PE0223_BL100_ModifierOptionAppel(tracabilite_p, pe0223BL001Retour);
        _processContext.setProcessRetour(retourBL100);
      }

      // Call BL002
      _processContext.setState(State.PE0223_BL002);
      Pair<Retour, ReponseErreur> bl002Retour = PE0223_BL002_FormaterReponseModification(tracabilite_p, _processContext.getProcessRetour());

      // Set process response
      syncPutResponse(request_p, tracabilite_p, bl002Retour._second);

    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));

      ReponseErreur responseError = new ReponseErreur();
      responseError.setError(IMegSpiritConsts.TRAITEMENT_ARRETE);
      responseError.setErrorDescription(exception.getMessage());

      // Set process response
      syncPutResponse(request_p, tracabilite_p, responseError);
    }
    finally
    {
      // Set process retour
      this.setRetour(_processContext.getProcessRetour());
      // Set end state
      _processContext.setState(State.PE0223_END);
    }

  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param pe0223BL002GetReturn_p
   *          variable pe0223
   */
  protected void syncGetResponse(Request request_p, PE0223_BL002GetReturn pe0223BL002GetReturn_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

      if (pe0223BL002GetReturn_p.getReponseErreur() != null)
      {
        ErrorCode errorCode;
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0223BL002GetReturn_p.getReponseErreur()));
        switch (pe0223BL002GetReturn_p.getReponseErreur().getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ID_PA_INCONNU:
          case IMegSpiritConsts.NO_COMPTE_INCONNU:
          case IMegSpiritConsts.NO_TELEPHONE_EST_INCONNU:
          case IMegSpiritConsts.NO_TELEPHONE_INCONNU:
          case IMegSpiritConsts.SERVICE_NON_PROVISIONNE:
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;

          case IMegSpiritConsts.PFS_INDISPO:
            errorCode = ErrorCode.KO_00503;
            break;

          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0223BL002GetReturn_p.getPe0223getRetour()));
        request_p.setResponse(new Response(ErrorCode.OK_00200, ravelResponse));
      }
    }
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param tracabilite_p
   *          Tracabilite
   * @param reponserreur_p
   *          the reponserreur
   */
  protected void syncPutResponse(Request request_p, Tracabilite tracabilite_p, ReponseErreur reponserreur_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp = null;

      if (reponserreur_p != null)
      {
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponserreur_p));
        ErrorCode errorCode = ErrorCode.KO_00403; //Unknown error

        if (IMegSpiritConsts.NON_RESPECT_STI.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00400;
        }

        rsp = new Response(errorCode, ravelResponse);
      }
      else
      {
        //Add empty Json in case OK
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        rsp = new Response(ErrorCode.OK_00204, ravelResponse);
      }

      request_p.setResponse(rsp);
    }
  }

  /**
   * Validates that each key in headersMap_p has a value in the request_p parameter, and if yes set the corresponding
   * value.
   *
   * @param request_p
   *          The request The original request containing all headers
   *
   * @return Retour OK if all the headers in the headersMap_p are set, NOK otherwise
   */
  private Retour checkRequestHeaders(final Request request_p)
  {
    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        _processContext.setIdRequest(header.getValue());
      }

      if (IHttpHeadersConsts.X_OAUTH2_IDCONTRATS.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        String[] listeContract = header.getValue().trim().split(StringConstants.SEMICOLON_SEPARATOR);
        for (String contract : listeContract)
        {
          String[] contractElement = contract.split(","); //$NON-NLS-1$
          for (int i = 0; i < contractElement.length; i++)
          {
            String[] idContract = contractElement[i].split("="); //$NON-NLS-1$
            if (IDC.equals(idContract[0]))
            {
              _processContext.addContratOauth(idContract[1]);
            }
          }
        }
      }
    }

    // Set mode appel
    _processContext.setModeAppel(request_p.getMetadata(IMetadata.METADATA_CANAL));
    if (StringTools.isNullOrEmpty(_processContext.getIdRequest()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_REQUEST_ID));
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Gets the URL parameters into the ProcessContext
   *
   * @param request_p
   *          request
   */
  private void getUrlParametersIntoProcessContext(Request request_p)
  {
    // get url parameters
    final List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();
    for (Parameter parameter : urlParametersType)
    {
      switch (parameter.getName())
      {
        case PARAM_NO_TELEPHONE:
          _processContext.setNoTelephone(parameter.getValue());
          break;

        case PARAM_ACTION:
          _processContext.setAction(parameter.getValue());
          break;

        case PARAM_TYPE:
          _processContext.setType(parameter.getValue());
          break;

        default:
          break;
      }
    }
  }

  /**
   * This method checks if the type is valid
   *
   * @param type_p
   *          The type
   * @return boolean
   */
  private boolean isTypeOk(String type_p)
  {
    if (StringTools.isNullOrEmpty(type_p))
    {
      return false;
    }

    switch (type_p)
    {
      case IOptionAppelConsts.TYPE_RENVOI_INCONDITIONNEL:
      case IOptionAppelConsts.TYPE_RENVOI_LIGNE_INDISPONIBLE:
      case IOptionAppelConsts.TYPE_RENVOI_LIGNE_OCCUPEE:
      case IOptionAppelConsts.TYPE_RENVOI_NON_REPONSE:
        return true;

      default:
        return false;
    }
  }

  /**
   * PE0223_BL100_PreparerConsultOptionsAppels
   *
   * @param tracabilite_p
   *          tracabilite
   * @param bl001GetRetour_p
   *          PE0223_BL001GetRetour
   * @return Pair<Retour, PE0223_BL100Reponse>
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Retour, PE0223_GetResponse> PE0223_BL100_ListerOptionsAppel(Tracabilite tracabilite_p, PE0223_BL001GetReturn bl001GetRetour_p) throws RavelException
  {
    //Récupérer le type de l’accés du NoTelephone cf A4
    BL5280_RecupererTypeAccesNoTelephone bl5280 = new BL5280_RecupererTypeAccesNoTelephoneBuilder() ///
        .tracabilite(tracabilite_p) //
        .noTelephone(bl001GetRetour_p.getNoTelephone()) //
        .build();
    String typeAcces = bl5280.execute(this);
    Retour retourBL5280 = bl5280.getRetour();

    if (isRetourOK(retourBL5280))
    {
      if (!TYPE_FIXE.equals(typeAcces))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_NO_TELEPHONE_INVALIDE, bl001GetRetour_p.getNoTelephone())), null);
      }
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_NO_TELEPHONE_INVALIDE, bl001GetRetour_p.getNoTelephone())), null);
    }

    // Call activity BL5270_RecupererPfiParNoTelephone
    BL5270_RecupererPfiParNoTelephone bl5270 = new BL5270_RecupererPfiParNoTelephoneBuilder() //
        .tracabilite(tracabilite_p) //
        .noTelephone(bl001GetRetour_p.getNoTelephone()) //
        .build();
    final BL5270_Return bl5270_Return = bl5270.execute(this);
    final Retour retourBL5270 = bl5270.getRetour();

    if (!isRetourOK(retourBL5270))
    {
      if ((IMegConsts.CAT4.equals(retourBL5270.getCategorie())) && (IMegConsts.DONNEE_INCONNUE.equals(retourBL5270.getDiagnostic())))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_INCONNU, MessageFormat.format(MESSAGE_NO_TELEPHONE_INCONNU, bl001GetRetour_p.getNoTelephone())), null);
      }

      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE), null);
    }

    //Authorization control of contract number
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001GetRetour_p.getModeAppel()))
    {
      if (CollectionUtils.isEmpty(bl001GetRetour_p.getListeContratOauth()) //
          || StringTools.isNullOrEmpty(bl5270_Return.getNoContrat()) //
          || bl001GetRetour_p.getListeContratOauth().stream().noneMatch(c -> c.equals(bl5270_Return.getNoContrat())))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "Acces refuse"), null); //$NON-NLS-1$
      }
    }

    // Call KPSA
    ListeParametre listParams = new ListeParametre();
    listParams.add(KPSA_PARAM_NO_TELEPHONE, bl001GetRetour_p.getNoTelephone());

    final PROV_SI002_ExecuterProcessus si002 = new PROV_SI002_ExecuterProcessusBuilder() //
        .tracabilite(tracabilite_p) //
        .processus(KPSA_PROCESS_CONSULTER_OPTIONS_APPELS_PFS) //
        .listeParametres(listParams) //
        .priorite(10) //
        .build();
    ResponseConnector si002Retour = si002.execute(this);
    Retour retourSI002 = si002.getRetour();
    _processContext.setProcessRetour(retourSI002);

    if (!isRetourOK(retourSI002))
    {
      switch (retourSI002.getCategorie())
      {
        case IMegConsts.CAT1:
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE), null);

        case IMegConsts.CAT2:
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPONIBLE), null);

        default:
          return new Pair<>(retourSI002, null);
      }
    }

    // Build response
    final PE0223_ResponseFonctionnelle functionalResponse = si002Retour.getFunctionalResponse(PE0223_ResponseFonctionnelle.class);
    final List<OptionAppel> optionAppelList;
    final PE0223_GetResponse reponse = new PE0223_GetResponse();
    if (functionalResponse.getResultsCount() > 0)
    {
      optionAppelList = new ArrayList<>();
      for (OptionAppelPfs option : functionalResponse.getItems())
      {
        final String id = bl5270_Return.getNoContrat() + "#" + bl001GetRetour_p.getNoTelephone() + "#" + option.getType(); //$NON-NLS-1$ //$NON-NLS-2$
        final String encryptedId = PasswordEncrypter.encryptForURL(id);

        final OptionAppel optionAppel = new OptionAppel();
        optionAppel.setIdOptionAppel(encryptedId);
        optionAppel.setNoTelephone(bl001GetRetour_p.getNoTelephone());
        optionAppel.setStatut(option.getStatut());
        optionAppel.setType(option.getType());
        optionAppel.setModeRenvoi(option.getModeRenvoi());
        optionAppel.setNombreSonneries(option.getNombreSonneries());
        optionAppel.setNumeroRenvoi(option.getNumeroRenvoi());

        if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001GetRetour_p.getModeAppel()))
        {
          // Build ModifierOptionAppel
          final XAction modifierOptionsAppel = new XAction();
          modifierOptionsAppel.setAction(OPERATION_OPTIONS_APPELS + "/" + encryptedId); //$NON-NLS-1$
          modifierOptionsAppel.setType(MediaType.APPLICATION_JSON);
          modifierOptionsAppel.setMethod(HttpConstants.PUT_METHOD);
          optionAppel.putAction(MODIFIER_OPTION_APPEL, modifierOptionsAppel);
        }

        optionAppelList.add(optionAppel);
      }
      reponse.setResultsCount(functionalResponse.getResultsCount());
      reponse.setItems(optionAppelList);

      // Build SelfXlink
      if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001GetRetour_p.getModeAppel()))
      {
        final XLink link = new XLink();
        link.setHref(OPERATION_LIGNES_TEL + bl001GetRetour_p.getNoTelephone() + OPERATION_OPTIONS_APPELS);
        reponse.putLink(XLink.SELF, link);
      }
    }

    return new Pair<>(RetourFactory.createOkRetour(), reponse);
  }

  /**
   * @param tracabilite_p
   *          The tracability
   * @param bl001PutReturn_p
   *          The PE0223_BL001PutRetourd
   * @return Pair<Retour, String>
   * @throws RavelException
   *           Exception thrown if something goes wrong
   */
  @LogProcessBL
  private Retour PE0223_BL100_ModifierOptionAppel(Tracabilite tracabilite_p, PE0223_BL001PutReturn bl001PutReturn_p) throws RavelException
  {
    if (StringTools.isNullOrEmpty(bl001PutReturn_p.getIdOptionAppel()))
    {
      //Identifier le Pfi a partir du Numero Telephone
      BL5270_RecupererPfiParNoTelephone bl5270 = new BL5270_RecupererPfiParNoTelephoneBuilder().tracabilite(tracabilite_p).noTelephone(bl001PutReturn_p.getNoTelephone()).build();
      BL5270_Return bl5270ReturnObjet = bl5270.execute(this);
      Retour bl5270Retour = bl5270.getRetour();

      if (!RetourFactory.isRetourOK(bl5270Retour))
      {
        if (IMegConsts.CAT4.equals(bl5270Retour.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(bl5270Retour.getDiagnostic()))
        {
          return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_EST_INCONNU, MessageFormat.format(MESSAGE_NO_TELEPHONE_INCONNU, bl001PutReturn_p.getNoTelephone()));
        }

        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE);
      }

      bl001PutReturn_p.setNoContrat(bl5270ReturnObjet.getNoContrat());
    }

    // Contrôle des autorisations sur le numéro contrat
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001PutReturn_p.getModeAppel()))
    {
      if (CollectionUtils.isEmpty(bl001PutReturn_p.getListeContratOauth()) //
          || StringTools.isNullOrEmpty(bl001PutReturn_p.getNoContrat()) //
          || bl001PutReturn_p.getListeContratOauth().stream().noneMatch(c -> c.equals(bl001PutReturn_p.getNoContrat())))
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "acces refuse"); //$NON-NLS-1$
      }
    }

    // Build KPSA Request
    String processus;
    ListeParametre listParams = new ListeParametre();
    if (DESACTIVER_RENVOIS_APPELS.equals(bl001PutReturn_p.getTypeOperation()))
    {
      listParams.add(KPSA_PARAM_NO_TELEPHONE, bl001PutReturn_p.getNoTelephone());
      listParams.add(KPSA_PARAM_STATUT, bl001PutReturn_p.getStatutOptionAppel());
      processus = KPSA_PROCESS_DESACTIVER_RENVOIS_APPEL;
    }
    else
    {
      processus = KPSA_PROCESS_MODIFIER_OPTION_APPEL;
      listParams.add(KPSA_PARAM_NO_TELEPHONE, bl001PutReturn_p.getNoTelephone());
      listParams.add(KPSA_PARAM_STATUT, bl001PutReturn_p.getStatutOptionAppel());
      listParams.add(KPSA_PARAM_TYPE_OPTON_APPEL, bl001PutReturn_p.getTypeOptionAppel());
      listParams.add(KPSA_PARAM_MODE_RENVOI, bl001PutReturn_p.getModeRenvoi());
      listParams.add(KPSA_PARAM_NUMERO_RENVOI, bl001PutReturn_p.getNumeroRenvoi());
      if ((bl001PutReturn_p.getNombreSonneries() != null) && (Integer.parseInt(bl001PutReturn_p.getNombreSonneries()) > 0))
      {
        listParams.add(KPSA_PARAM_NOMBRE_SONNERIES, bl001PutReturn_p.getNombreSonneries());
      }
    }

    // Call PROV_SI002
    PROV_SI002_ExecuterProcessus si002 = new PROV_SI002_ExecuterProcessusBuilder().tracabilite(tracabilite_p) //
        .cles(Collections.emptyList()) //
        .priorite(10) //
        .processus(processus) //
        .listeParametres(listParams) //
        .build();
    si002.execute(this);
    Retour retourSI002 = si002.getRetour();

    if (isRetourNOK(si002.getRetour()))
    {
      if (IMegConsts.CAT1.equals(si002.getRetour().getCategorie()))
      {
        return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE);
      }
      else if (IMegConsts.CAT2.equals(si002.getRetour().getCategorie()))
      {
        return RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPONIBLE);
      }
      else
      {
        return si002.getRetour();
      }
    }

    return retourSI002;
  }

  /**
   * @param pe0223Input_p
   * @param retour_p
   *          The information to check
   * @return Retour
   */
  private Retour statutActifSwitchCase(PE0223_PutRequest pe0223Input_p, PE0223_BL001PutReturn retour_p)
  {
    if (!(IOptionAppelConsts.TYPE_APPEL_INCOGNITO.equals(retour_p.getTypeOptionAppel()) || IOptionAppelConsts.TYPE_APPEL_DOUBLE_APPEL.equals(retour_p.getTypeOptionAppel())))
    {
      // If the status is active and the type is not APPEL_INCOGNITO or DOUBLE_APPEL the modeRenvoi must exist and be either MODE_RENVOI_NUMERO or MODE_RENVOI_VMS
      if (StringTools.isNullOrEmpty(pe0223Input_p.getModeRenvoi()) //
          || !(IOptionAppelConsts.MODE_RENVOI_NUMERO.equals(pe0223Input_p.getModeRenvoi()) //
              || IOptionAppelConsts.MODE_RENVOI_VMS.equals(pe0223Input_p.getModeRenvoi())))
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, KPSA_PARAM_MODE_RENVOI, pe0223Input_p.getModeRenvoi()));
      }

      retour_p.setModeRenvoi(pe0223Input_p.getModeRenvoi());

      if (IOptionAppelConsts.MODE_RENVOI_NUMERO.equals(pe0223Input_p.getModeRenvoi()))
      {
        // The numeroRenvoi must exist
        if (StringTools.isNullOrEmpty(pe0223Input_p.getNumeroRenvoi()))
        {
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, KPSA_PARAM_NUMERO_RENVOI, pe0223Input_p.getNumeroRenvoi()));
        }

        retour_p.setNumeroRenvoi(pe0223Input_p.getNumeroRenvoi());
      }
    }

    if (IOptionAppelConsts.TYPE_RENVOI_NON_REPONSE.equals(retour_p.getTypeOptionAppel()))
    {
      // If the status is active and the type is not RENVOI_NON_RESPONSE the nombreSonneries must exist
      if (StringTools.isNullOrEmpty(pe0223Input_p.getNombreSonneries()))
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PARAMETER, KPSA_PARAM_NOMBRE_SONNERIES, pe0223Input_p.getNombreSonneries()));
      }

      retour_p.setNombreSonneries(pe0223Input_p.getNombreSonneries());
    }

    return RetourFactory.createOkRetour();
  }
}
