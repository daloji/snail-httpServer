/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0276.structs;

import com.bytel.spirit.fiat.processes.structs.XItem;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.squareup.moshi.Json;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class AnnoncesAccueil extends XItem
{
  /**
   * Serial ID
   */
  private static final long serialVersionUID = 1910208886580712724L;

  /**
   * @return the serialversionuid
   */
  public static long getSerialversionuid()
  {
    return serialVersionUID;
  }

  /**
   * idAnnonce
   */
  @Json(name = "idAnnonce")
  private String _idAnnonce;

  /**
   * idMessagerie
   */
  @Json(name = "idMessagerie")
  private String _idMessagerie;

  /**
   * typeAnnonce
   */
  @Json(name = "typeAnnonce")
  private String _typeAnnonce;

  /**
   * statutAnnonce
   */
  @Json(name = "statutAnnonce")
  private String _statutAnnonce;

  @Override
  public boolean equals(Object obj)
  {
    if (obj == null)
    {
      return false;
    }
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    AnnoncesAccueil other = (AnnoncesAccueil) obj;
    if (_idAnnonce == null)
    {
      if (other._idAnnonce != null)
      {
        return false;
      }
    }
    else if (!_idAnnonce.equals(other._idAnnonce))
    {
      return false;
    }
    if (_idMessagerie == null)
    {
      if (other._idMessagerie != null)
      {
        return false;
      }
    }
    else if (!_idMessagerie.equals(other._idMessagerie))
    {
      return false;
    }
    if (_statutAnnonce == null)
    {
      if (other._statutAnnonce != null)
      {
        return false;
      }
    }
    else if (!_statutAnnonce.equals(other._statutAnnonce))
    {
      return false;
    }
    if (_typeAnnonce == null)
    {
      if (other._typeAnnonce != null)
      {
        return false;
      }
    }
    else if (!_typeAnnonce.equals(other._typeAnnonce))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the idAnnonce
   */
  public String getIdAnnonce()
  {
    return _idAnnonce;
  }

  /**
   * @return the idMessagerie
   */
  public String getIdMessagerie()
  {
    return _idMessagerie;
  }

  /**
   * @return the statutAnnonce
   */
  public String getStatutAnnonce()
  {
    return _statutAnnonce;
  }

  /**
   * @return the typeAnnonce
   */
  public String getTypeAnnonce()
  {
    return _typeAnnonce;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_idAnnonce == null) ? 0 : _idAnnonce.hashCode());
    result = (prime * result) + ((_idMessagerie == null) ? 0 : _idMessagerie.hashCode());
    result = (prime * result) + ((_statutAnnonce == null) ? 0 : _statutAnnonce.hashCode());
    result = (prime * result) + ((_typeAnnonce == null) ? 0 : _typeAnnonce.hashCode());
    return result;
  }

  /**
   * @param idAnnonce_p
   *          the idAnnonce to set
   */
  public void setIdAnnonce(String idAnnonce_p)
  {
    _idAnnonce = idAnnonce_p;
  }

  /**
   * @param idMessagerie_p
   *          the idMessagerie to set
   */
  public void setIdMessagerie(String idMessagerie_p)
  {
    _idMessagerie = idMessagerie_p;
  }

  /**
   * @param statutAnnonce_p
   *          the statutAnnonce to set
   */
  public void setStatutAnnonce(String statutAnnonce_p)
  {
    _statutAnnonce = statutAnnonce_p;
  }

  /**
   * @param typeAnnonce_p
   *          the typeAnnonce to set
   */
  public void setTypeAnnonce(String typeAnnonce_p)
  {
    _typeAnnonce = typeAnnonce_p;
  }

  @Override
  public String toString()
  {
    return "AnnoncesAccueil [_idAnnonce=" + _idAnnonce + ", _idMessagerie=" + _idMessagerie + ", _typeAnnonce=" + _typeAnnonce + ", _statutAnnonce=" + _statutAnnonce + "]";
  }

}
