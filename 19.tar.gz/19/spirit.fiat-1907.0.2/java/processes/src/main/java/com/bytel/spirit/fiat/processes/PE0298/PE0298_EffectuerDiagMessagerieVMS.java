/*******************************************************************************
* $Id: PE0298_EffectuerDiagMessagerieVMS.java 22610 2019-06-12 09:19:43Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0298;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI026_LireRessourceNoTelephone;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI026_LireRessourceNoTelephone.OSSFAI_SI026_LireRessourceNoTelephoneBuilder;
import com.bytel.spirit.common.activities.ossfai.structs.si026.OSSFAI_SI026_Return;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL5270_Return;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.MessageriePfs;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechnique;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechniqueVmsCvm;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechniqueVmsStw;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.TypeAction;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmscvm.StPfsVmsCvm;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.StPfsVmsStw;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.utils.st.StLacFilter;
import com.bytel.spirit.common.shared.utils.st.StPfsVmsCvmFilter;
import com.bytel.spirit.common.shared.utils.st.StPfsVmsStwFilter;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Audit;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Audit.Diagnostic;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Erreur;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Erreur.TypeError;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_PFS;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Referentiel;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Referentiel.EtatProvisionning;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Referentiel.TypeService;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Ressource;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Ressource.EtatAllocation;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Ressource.TypeRessource;
import com.bytel.spirit.fiat.processes.PE0298.structs.PE0298_BL001Return;
import com.bytel.spirit.fiat.processes.PE0298.structs.PE0298_BL002Return;
import com.bytel.spirit.fiat.processes.PE0298.structs.PE0298_BL200Return;
import com.bytel.spirit.fiat.processes.PE0298.structs.PE0298_BL400Return;
import com.bytel.spirit.fiat.processes.PE0298.structs.PE0298_Reponse;

/**
 *
 * @author kbettenc
 * @version ($Revision: 22610 $ $Date: 2019-06-12 11:19:43 +0200 (mer. 12 juin 2019) $)
 */
public class PE0298_EffectuerDiagMessagerieVMS extends SpiritRestApiProcessSkeleton
{

  /**
   * Holds context data for PE0298_EffectuerDiagMessagerieVMS
   *
   * @author kbettenc
   * @version ($Revision: 22610 $ $Date: 2019-06-12 11:19:43 +0200 (mer. 12 juin 2019) $)
   */
  public static final class PE0298_EffectuerDiagMessagerieVMSContext extends Context
  {

    /**
     *
     */
    private static final long serialVersionUID = -7778279029455495756L;

    /**
     * The request id
     */
    private String _idRequest;
    /**
     * The retour of the process
     */
    private Retour _processRetour;
    /**
     * The noTelephone from the request
     */
    private String _noTelephone;
    /**
     * The sourceDonnee from the request
     */
    private List<String> _sourceDonnee;

    /**
     * The audit from the request
     */
    private Boolean _audit;
    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0298_START;

    private PE0298_Reponse _pe0298Reponse;

    /**
     * @return the audit
     */
    public Boolean getAudit()
    {
      return _audit;
    }

    /**
     * @return the idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the noTelephone
     */
    public String getNoTelephone()
    {
      return _noTelephone;
    }

    /**
     * @return the pe0298Reponse
     */
    public PE0298_Reponse getPe0298Reponse()
    {
      return _pe0298Reponse;
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the sourceDonnee
     */
    public List<String> getSourceDonnee()
    {
      return _sourceDonnee != null ? new ArrayList<>(_sourceDonnee) : new ArrayList<>();
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param audit_p
     *          the audit to set
     */
    public void setAudit(Boolean audit_p)
    {
      _audit = audit_p;
    }

    /**
     * @param idRequest_p
     *          the idRequest to set
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param noTelephone_p
     *          the noTelephone to set
     */
    public void setNoTelephone(String noTelephone_p)
    {
      _noTelephone = noTelephone_p;
    }

    /**
     * @param pe0298Reponse_p
     *          the pe0298Reponse to set
     */
    public void setPe0298Reponse(PE0298_Reponse pe0298Reponse_p)
    {
      _pe0298Reponse = pe0298Reponse_p;
    }

    /**
     * @param processRetour_p
     *          the processRetour to set
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param sourceDonnee_p
     *          the sourceDonnee to set
     */
    public void setSourceDonnee(List<String> sourceDonnee_p)
    {
      _sourceDonnee = sourceDonnee_p != null ? new ArrayList<>(sourceDonnee_p) : new ArrayList<>();
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }
  }

  /**
   *
   * @author jpais
   * @version ($Revision: 22610 $ $Date: 2019-06-12 11:19:43 +0200 (mer. 12 juin 2019) $)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0298_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call BL001
     */
    PE0298_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL100
     */
    PE0298_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PE0298_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL300
     */
    PE0298_BL300(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL400
     */
    PE0298_BL400(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL002
     */
    PE0298_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call SI002
     */
    PE0298_SI002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PE0298_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   *
   */
  private static final String CONSULTER_MESSAGERIE_VMS_PFS = "consulterMessagerieVmsPfs";

  /**
   *
   */
  private static final String NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PFS = "PFS";//$NON-NLS-1$

  /**
   *
   */
  private static final String REFERENTIEL = "REFERENTIEL";//$NON-NLS-1$

  /**
   *
   */
  private static final String AUDIT = "audit";//$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_SOURCE_DONNEE = "sourceDonnee";//$NON-NLS-1$

  /**
   *
   */
  private static final long serialVersionUID = 984688447440816671L;

  /**
   * PARAM_NO_TELEPHONE constant
   */
  private static final String PARAM_NO_TELEPHONE = NO_TELEPHONE;

  /**
   * The constant for BL001.ParameterNullOrEmpty message
   */
  private static final String MESSAGE_PARAMETER_NULL_OR_EMPTY = Messages.getString("PE0298.BL001.ParameterNullOrEmpty"); //$NON-NLS-1$

  /**
   * The constant for BL001.DataSourceNotValidate message
   */
  private static final String MESSAGE_DATASOURCE_NOT_VALIDATED = Messages.getString("PE0298.BL001.DataSourceNotValidate"); //$NON-NLS-1$
  /**
   * Constant for action corrective creation error
   */
  private static final String ERROR_CREATION_ACTION_CORRECTIVE = Messages.getString("PE0298.BL400.ErrorDescrition"); //$NON-NLS-1$

  /**
   * Process context instance
   */
  protected PE0298_EffectuerDiagMessagerieVMSContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour arg0_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0298_EffectuerDiagMessagerieVMSContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    try
    {
      List<PE0298_PFS> listePfs = null;
      List<PE0298_Referentiel> listeReferentiels = null;
      String idActionCorrective = null;

      _processContext.setState(State.PE0298_BL001);
      PE0298_BL001Return bl001 = PE0298_BL001_VerifierDonnees(tracabilite_p, request_p);
      _processContext.setProcessRetour(bl001.getRetour());
      _processContext.setIdRequest(bl001.getIdRequest());
      _processContext.setNoTelephone(bl001.getNoTelephone());

      if (isRetourOK(bl001.getRetour()))
      {
        _processContext.setState(State.PE0298_BL200);
        PE0298_BL200Return bl200 = PE0298_BL200_ConstruireVueReferentiel(tracabilite_p, bl001);
        listeReferentiels = bl200.getListeReferentiel();
        _processContext.setProcessRetour(bl200.getRetour());

        if (isRetourOK(bl200.getRetour()))
        {
          _processContext.setState(State.PE0298_BL300);
          Pair<Retour, List<PE0298_PFS>> bl300 = PE0298_BL300_ConstruireVuePfs(tracabilite_p, bl001.getNoTelephone(), bl001.getListeSourceDonnee());
          listePfs = bl300._second;
          _processContext.setProcessRetour(bl300._first);

          _processContext.setState(State.PE0298_BL400);
          PE0298_BL400Return bl400 = PE0298_BL400_ComparerVues(tracabilite_p, bl001, listeReferentiels, listePfs);
          _processContext.setProcessRetour(bl400.getRetour());
          idActionCorrective = bl400.getIdActionCorrective();
        }
      }

      _processContext.setState(State.PE0298_BL002);
      PE0298_BL002Return bl002 = PE0298_BL002_FormaterReponse(tracabilite_p, _processContext.getProcessRetour(), listePfs, listeReferentiels, idActionCorrective);
      _processContext.setProcessRetour(bl002.getRetour());

      // Set process responseFile
      syncResponse(request_p, tracabilite_p, bl002.getReponseErreur(), bl002.getPe0298Reponse());
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, exception.getMessage()));

      ReponseErreur responseError = new ReponseErreur();
      responseError.setError(IMegSpiritConsts.TRAITEMENT_ARRETE);
      responseError.setErrorDescription(exception.getMessage());

      // Set process response
      syncResponse(request_p, tracabilite_p, responseError, null);
    }
    finally
    {
      // Set process retour
      this.setRetour(_processContext.getProcessRetour());
      // Set end state
      _processContext.setState(State.PE0298_END);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param reponserreur_p
   *          the reponserreur
   * @param pe0298Reponse_p
   *          variable pe0221
   */
  protected void syncResponse(Request request_p, Tracabilite tracabilite_p, ReponseErreur reponserreur_p, PE0298_Reponse pe0298Reponse_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);

      if (reponserreur_p != null)
      {
        ErrorCode errorCode;
        try
        {
          ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponserreur_p, ReponseErreur.class));
        }
        catch (Exception ex)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
        }
        switch (reponserreur_p.getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ACCES_REFUSE:
            errorCode = ErrorCode.KO_00403;
            break;
          case IMegSpiritConsts.NO_TELEPHONE_INCONNU:
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;
          //          case IMegSpiritConsts.TYPE_CONTENU_NON_SUPPORTE:
          //            errorCode = ErrorCode.KO_00415;
          //            break;
          case IMegSpiritConsts.PFS_INDISPO:
          case IMegSpiritConsts.MIGRATION_EN_COURS:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        try
        {
          ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pe0298Reponse_p, PE0298_Reponse.class));
        }
        catch (Exception ex)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
        }
        request_p.setResponse(new Response(ErrorCode.OK_00200, ravelResponse));
      }
    }
  }

  /**
   * Check if a diagnostic is in an Audit list
   *
   * @param listeAudits_p
   * @param diagnostic_p
   * @return
   */
  private boolean auditContainsDiagnostic(List<PE0298_Audit> listeAudits_p, Diagnostic diagnostic_p)
  {
    for (PE0298_Audit audit : listeAudits_p)
    {
      if (diagnostic_p.toString().equals(audit.getDiagnostic()))
      {
        return true;
      }
    }
    return false;
  }

  /**
   * Check the request parameters
   *
   * @param request_p
   *          request
   * @return {@link Retour}
   */
  private Retour checkRequestParameters(final Request request_p)
  {
    // Get URL parameters
    List<Parameter> urlParameters = request_p.getUrlParameters().getUrlParameters();
    _processContext.setAudit(Boolean.FALSE);

    for (Parameter parameter : urlParameters)
    {
      if (parameter.getName().equals(PARAM_NO_TELEPHONE))
      {
        _processContext.setNoTelephone(parameter.getValue());
      }
      else if (parameter.getName().equals(PARAM_SOURCE_DONNEE))
      {
        List<String> listeSourceDonnee = new ArrayList<>();
        String[] parameterSourceDonnee = parameter.getValue().split(",");//$NON-NLS-1$
        for (int i = 0; i < parameterSourceDonnee.length; i++)
        {
          listeSourceDonnee.add(parameterSourceDonnee[i]);
        }

        _processContext.setSourceDonnee(listeSourceDonnee);
      }
      else if (parameter.getName().equals(AUDIT))
      {
        _processContext.setAudit(Boolean.valueOf(parameter.getValue()));
      }
    }

    if (StringTools.isNullOrEmpty(_processContext.getNoTelephone()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_PARAMETER_NULL_OR_EMPTY, PARAM_NO_TELEPHONE));
    }
    if ((_processContext.getSourceDonnee() == null) || _processContext.getSourceDonnee().isEmpty())
    {
      _processContext.setSourceDonnee(Arrays.asList(REFERENTIEL));
    }
    if (!(_processContext.getSourceDonnee().contains(REFERENTIEL) && _processContext.getSourceDonnee().contains(PFS)))
    {
      _processContext.setAudit(Boolean.FALSE);
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Creates ActionServiceTechnique based on given ServiceTechnique
   *
   * @param serviceTechnique_p
   * @return ActionServiceTechnique
   */
  private ActionServiceTechnique createActionServiceTechnique(ServiceTechnique serviceTechnique_p)
  {
    ActionServiceTechnique actionServiceTechnique = null;

    if (serviceTechnique_p instanceof StPfsVmsStw)
    {
      StPfsVmsStw stPfsVmsStw = (StPfsVmsStw) serviceTechnique_p;

      ActionServiceTechniqueVmsStw actionServiceTechniqueStw = new ActionServiceTechniqueVmsStw(TypeAction.MODIFICATION.name(), stPfsVmsStw.getStatut(), stPfsVmsStw.getDateModification());
      actionServiceTechniqueStw.setIdSt(stPfsVmsStw.getIdSt());
      actionServiceTechniqueStw.setCommentaire(stPfsVmsStw.getCommentaire());

      if (!Statut.INACTIF.toString().equals(stPfsVmsStw.getStatut()))
      {
        actionServiceTechniqueStw.setTypePfs(stPfsVmsStw.getTypePfs());
        actionServiceTechniqueStw.setDonneesProvisionneesStPfsVmsStw(stPfsVmsStw.getDonneesProvisionneesSTPfsVmsStw());
      }
      actionServiceTechnique = actionServiceTechniqueStw;
    }

    else if (serviceTechnique_p instanceof StPfsVmsCvm)
    {
      StPfsVmsCvm stPfsVmsCvm = (StPfsVmsCvm) serviceTechnique_p;

      ActionServiceTechniqueVmsCvm actionServiceTechniqueCvm = new ActionServiceTechniqueVmsCvm(TypeAction.MODIFICATION.name(), stPfsVmsCvm.getStatut(), stPfsVmsCvm.getDateModification());
      actionServiceTechniqueCvm.setIdSt(stPfsVmsCvm.getIdSt());
      actionServiceTechniqueCvm.setCommentaire(stPfsVmsCvm.getCommentaire());

      if (!Statut.INACTIF.toString().equals(stPfsVmsCvm.getStatut()))
      {
        actionServiceTechniqueCvm.setTypePfs(stPfsVmsCvm.getTypePfs());
        actionServiceTechniqueCvm.setDonneesProvisionneesStPfsVmsCvm(stPfsVmsCvm.getDonneesProvisionneesSTPfsVmsCvm());
      }
      actionServiceTechnique = actionServiceTechniqueCvm;
    }

    return actionServiceTechnique;
  }

  private PE0298_Referentiel getReferentielByNoTelephone(List<PE0298_Referentiel> listeReferentiels_p, String noTelephone_p)
  {
    for (PE0298_Referentiel referentiel : listeReferentiels_p)
    {
      if (noTelephone_p.equals(referentiel.getNoTelephone()))
      {
        return referentiel;
      }
    }

    return null;
  }

  /**
   * Validate Data Source (REFERENTIEL ,PFS)
   *
   * @param sourceDonnee_p
   *          list Source
   * @return Retour
   */
  private Retour isvalidSource(List<String> sourceDonnee_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    for (String source : sourceDonnee_p)
    {
      switch (source)
      {
        case REFERENTIEL:
        case PFS:
          break;
        default:
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_DATASOURCE_NOT_VALIDATED, source));

      }
    }

    return retour;
  }

  /**
   * @param tracabilite_p
   * @param request_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private PE0298_BL001Return PE0298_BL001_VerifierDonnees(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    Retour retour = checkRequestParameters(request_p);
    if (RetourFactory.isRetourNOK(retour))
    {
      return new PE0298_BL001Return(retour);
    }

    PE0298_BL001Return bl001Return = new PE0298_BL001Return(retour);
    bl001Return.setNoTelephone(_processContext.getNoTelephone());
    bl001Return.setListeSourceDonnee(_processContext.getSourceDonnee());
    bl001Return.setAudit(_processContext.getAudit());

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        bl001Return.setIdRequest(header.getValue());
      }
    }

    retour = isvalidSource(_processContext.getSourceDonnee());
    if (RetourFactory.isRetourNOK(retour))
    {
      return new PE0298_BL001Return(retour);
    }
    if (_processContext.getSourceDonnee().contains(REFERENTIEL))
    {
      BL5270_RecupererPfiParNoTelephone bl5270 = new BL5270_RecupererPfiParNoTelephoneBuilder().tracabilite(tracabilite_p).noTelephone(bl001Return.getNoTelephone()).build();
      BL5270_Return bl5270_Return = bl5270.execute(this);

      if (isRetourOK(bl5270.getRetour()))
      {
        bl001Return.setClientOperateur(bl5270_Return.getClientOperateur());
        bl001Return.setNoCompte(bl5270_Return.getNoCompte());
      }
      else
      {
        retour = bl5270.getRetour();
        if (IMegConsts.CAT4.equals(bl5270.getRetour().getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(bl5270.getRetour().getDiagnostic()))
        {
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_INCONNU, MessageFormat.format(Messages.getString("PE0298.BL001.NumeroTelephoneInconnu"), bl001Return.getNoTelephone())); //$NON-NLS-1$
        }

        bl001Return.setRetour(retour);
      }
    }

    return bl001Return;
  }

  /**
   * @param tracabilite_p
   * @param retourIn_p
   * @param listePfs_p
   * @param listeReferentiels_p
   * @param idActionCorrective_p
   * @return
   */
  @LogProcessBL
  private PE0298_BL002Return PE0298_BL002_FormaterReponse(Tracabilite tracabilite_p, Retour retourIn_p, List<PE0298_PFS> listePfs_p, List<PE0298_Referentiel> listeReferentiels_p, String idActionCorrective_p)
  {
    PE0298_BL002Return processRetour = new PE0298_BL002Return();

    if (!RetourFactory.isRetourOK(retourIn_p))
    {
      ReponseErreur reponseErreur = new ReponseErreur();
      reponseErreur.setError(retourIn_p.getDiagnostic());
      reponseErreur.setErrorDescription(retourIn_p.getLibelle());
      processRetour.setReponseErreur(reponseErreur);
    }
    else
    {
      PE0298_Reponse pe0298Reponse = new PE0298_Reponse();
      pe0298Reponse.setIdActionCorrective(idActionCorrective_p);
      pe0298Reponse.setReferentiel(listeReferentiels_p);
      pe0298Reponse.setPfs(listePfs_p);

      processRetour.setPe0298Reponse(pe0298Reponse);
    }
    processRetour.setRetour(retourIn_p);
    return processRetour;
  }

  /**
   * @param tracabilite_p
   * @param bl001Retour_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private PE0298_BL200Return PE0298_BL200_ConstruireVueReferentiel(Tracabilite tracabilite_p, PE0298_BL001Return bl001Retour_p) throws RavelException
  {
    PE0298_BL200Return bl200Return = new PE0298_BL200Return(RetourFactory.createOkRetour());

    List<PE0298_Referentiel> listeReferentiel = null;

    if (_processContext.getSourceDonnee().contains(REFERENTIEL))
    {
      listeReferentiel = new ArrayList<>();
      //Récupérer la liste des ST du Pfi en utilisant le verbe lireTousParPfi
      ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = RSTProxy.getInstance().serviceTechniqueLireTousParPfi(tracabilite_p, bl001Retour_p.getClientOperateur(), bl001Retour_p.getNoCompte(), null, null);
      if (RetourFactory.isRetourNOK((rstResponse._first)))
      {
        if (!(IMegConsts.CAT4.equals(rstResponse._first.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(rstResponse._first.getDiagnostic())))
        {
          return new PE0298_BL200Return(rstResponse._first);
        }
      }

      List<ServiceTechnique> listeST = rstResponse._second;

      StLienAllocationCommercial stLac = null;
      StPfsVmsStw stPfsVmsStw = null;
      StPfsVmsCvm stPfsVmsCvm = null;
      ServiceTechnique serviceTechniqueBL201 = null;

      if ((listeST != null) && !listeST.isEmpty())
      {
        stLac = new StLacFilter() //
            .whereStatutIsNot(Statut.INACTIF) //
            .whereTypeRessourceIsEqual(com.bytel.spirit.common.shared.saab.res.TypeRessource.NUMERO_TELEPHONE) //
            .whereIdRessourceIsEqual(bl001Retour_p.getNoTelephone()) //
            .getFirst(listeST);

        stPfsVmsStw = new StPfsVmsStwFilter() //
            .whereStatutIsNot(Statut.INACTIF) //
            .whereTelephoneIsEqual(bl001Retour_p.getNoTelephone()) //
            .getFirst(listeST);

        stPfsVmsCvm = new StPfsVmsCvmFilter() //
            .whereStatutIsNot(Statut.INACTIF) //
            .whereTelephoneIsEqual(bl001Retour_p.getNoTelephone()) //
            .getFirst(listeST);
      }

      //Si ST Messagerie VMS StreamWIDE et ST Messagerie VMS Convergys trouvés, alors une migration est en cours --> ont interrompt le traitement
      if ((stPfsVmsStw != null) && (stPfsVmsCvm != null))
      {
        return new PE0298_BL200Return(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.MIGRATION_EN_COURS, Messages.getString("PE0298.MigrationEnCours"))); //$NON-NLS-1$
      }

      serviceTechniqueBL201 = stPfsVmsStw != null ? stPfsVmsStw : stPfsVmsCvm;

      Pair<Retour, PE0298_Referentiel> retourBL201 = PE0298_BL201_CreerObjetReferentiel(tracabilite_p, bl001Retour_p.getNoTelephone(), serviceTechniqueBL201, stLac);

      listeReferentiel.add(retourBL201._second);
    }

    bl200Return.setListeReferentiel(listeReferentiel);
    return bl200Return;
  }

  /**
   * @param tracabilite_p
   * @param noTelephone_p
   * @param serviceTechnique_p
   *          StPfsVmsStw or StPfsVmsCvm
   * @param stLac_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private Pair<Retour, PE0298_Referentiel> PE0298_BL201_CreerObjetReferentiel(Tracabilite tracabilite_p, String noTelephone_p, ServiceTechnique serviceTechnique_p, StLienAllocationCommercial stLac_p) throws RavelException
  {
    PE0298_Referentiel referentiel = new PE0298_Referentiel();
    referentiel.setTypeService(TypeService.MESSAGERIE.toString());
    referentiel.setNoTelephone(noTelephone_p);

    OSSFAI_SI026_LireRessourceNoTelephone ossfaiSI026 = new OSSFAI_SI026_LireRessourceNoTelephoneBuilder().tracabilite(tracabilite_p).noTelephone(noTelephone_p).build();
    OSSFAI_SI026_Return ossfaiSI026Return = ossfaiSI026.execute(this);

    if (RetourFactory.isRetourNOK((ossfaiSI026.getRetour())))
    {
      PE0298_Erreur erreur = new PE0298_Erreur();
      erreur.setError(IMegSpiritConsts.ERREUR_INTERNE);
      erreur.setErrorDescription(Messages.getString("PE0298.BL001.ProblemeQOD") + ossfaiSI026.getRetour().getDiagnostic()); //$NON-NLS-1$
      referentiel.addErreur(erreur);
    }
    else
    {
      PE0298_Ressource ressource = new PE0298_Ressource();
      ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
      ressource.setEtatRessource(ossfaiSI026Return.getStatut());

      if (stLac_p != null)
      {
        if (Statut.ACTIF.toString().equals(stLac_p.getStatut()))
        {
          ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
        }
        else if (Statut.ECHEC.toString().equals(stLac_p.getStatut()))
        {
          ressource.setEtatAllocation(EtatAllocation.ECHEC.toString());
        }
        else
        {
          ressource.setEtatAllocation(EtatAllocation.EN_COURS.toString());
        }
      }
      else
      {
        ressource.setEtatAllocation(EtatAllocation.EN_COURS.toString());
      }
      referentiel.addRessource(ressource);
    }

    if (serviceTechnique_p != null)
    {
      if (Statut.ACTIF.toString().equals(serviceTechnique_p.getStatut()))
      {
        referentiel.setEtatProvisioning(EtatProvisionning.REALISE.toString());
      }
      else if (Statut.ECHEC.toString().equals(serviceTechnique_p.getStatut()))
      {
        referentiel.setEtatProvisioning(EtatProvisionning.ECHEC.toString());
      }
      else
      {
        referentiel.setEtatProvisioning(EtatProvisionning.EN_COURS.toString());
      }
    }
    else
    {
      referentiel.setEtatProvisioning(EtatProvisionning.EN_COURS.toString());
    }

    if ((serviceTechnique_p != null) && (serviceTechnique_p instanceof StPfsVmsStw))
    {
      StPfsVmsStw stPfsVmsStw = (StPfsVmsStw) serviceTechnique_p;
      if (stPfsVmsStw.getDonneesProvisionneesSTPfsVmsStw() != null)
      {
        referentiel.addST(stPfsVmsStw);
        referentiel.setTypeMessagerie(stPfsVmsStw.getDonneesProvisionneesSTPfsVmsStw().getTypeUsage());
      }
    }

    if ((serviceTechnique_p != null) && (serviceTechnique_p instanceof StPfsVmsCvm))
    {
      StPfsVmsCvm stPfsVmsCvm = (StPfsVmsCvm) serviceTechnique_p;
      if (stPfsVmsCvm.getDonneesProvisionneesSTPfsVmsCvm() != null)
      {
        referentiel.addST(stPfsVmsCvm);
        referentiel.setTypeMessagerie(stPfsVmsCvm.getDonneesProvisionneesSTPfsVmsCvm().getTypeUsage());
      }
    }

    return new Pair<>(RetourFactory.createOkRetour(), referentiel);
  }

  /**
   * @param tracabilite_p
   * @param noTelephone_p
   * @param listeSourceDonnees_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private Pair<Retour, List<PE0298_PFS>> PE0298_BL300_ConstruireVuePfs(Tracabilite tracabilite_p, String noTelephone_p, List<String> listeSourceDonnees_p) throws RavelException
  {
    List<PE0298_PFS> listePfs = null;

    if (listeSourceDonnees_p.contains(PFS))
    {
      //Declencher l’appel vers KPSA DIAG
      ListeParametre listeParametres = new ListeParametre();
      listeParametres.add(NO_TELEPHONE, noTelephone_p);

      PROV_SI002_ExecuterProcessus prov_SI002 = new PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder() //
          .tracabilite(tracabilite_p) //
          .processus(CONSULTER_MESSAGERIE_VMS_PFS) //
          .priorite(10) //
          .listeParametres(listeParametres) //
          .build();
      ResponseConnector responseConnector = prov_SI002.execute(this);
      Retour retourProvSI002 = prov_SI002.getRetour();

      MessageriePfs messageriePfs = new MessageriePfs(); //unused in BL301 if provSI002 KO
      if (isRetourOK(retourProvSI002))
      {
        ReponseFonctionnelle<MessageriePfs> functionalResponse = responseConnector.getReponseFonctionnelle(MessageriePfs.class);

        if ((functionalResponse.getItems() != null) && !functionalResponse.getItems().isEmpty())
        {
          messageriePfs = functionalResponse.getItems().get(0);
        }
      }

      Pair<Retour, PE0298_PFS> bl301 = PE0298_BL301_CreerObjetPfs(tracabilite_p, noTelephone_p, messageriePfs, retourProvSI002);
      PE0298_PFS pfs = bl301._second;
      listePfs = new ArrayList<>();
      listePfs.add(pfs);
    }
    return new Pair<>(RetourFactory.createOkRetour(), listePfs);

  }

  /**
   * @param tracabilite_p
   * @param noTelephone_p
   * @param messageriePfs_p
   * @param retour_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private Pair<Retour, PE0298_PFS> PE0298_BL301_CreerObjetPfs(Tracabilite tracabilite_p, String noTelephone_p, MessageriePfs messageriePfs_p, Retour retour_p) throws RavelException
  {
    PE0298_PFS pfs = new PE0298_PFS();
    pfs.setNoTelephone(noTelephone_p);

    if (RetourFactory.isRetourNOK(retour_p))
    {

      if (IMegConsts.CAT4.equals(retour_p.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(retour_p.getDiagnostic()))
      {
        PE0298_Audit audit = new PE0298_Audit();
        audit.setDiagnostic(Diagnostic.SERVICE_NON_PROVISIONNE.toString());
        audit.setLibelle(Messages.getString("PE0298.BL301.ServiceNonProvisionne")); //$NON-NLS-1$
        pfs.addAudit(audit);
      }
      else
      {
        String errorDescription;
        String error;

        if (IMegConsts.CAT2.equals(retour_p.getCategorie()) && IMegConsts.SERVICE_TIERS_INDISPONIBLE.equals(retour_p.getDiagnostic()))
        {
          error = IMegSpiritConsts.PFS_INDISPONIBLE;
          errorDescription = MessageFormat.format(Messages.getString("PE0298.BL301.PfsIndispo"), pfs.getTypePfs()); //$NON-NLS-1$
        }
        else if (IMegConsts.CAT1.equals(retour_p.getCategorie()))
        {
          error = IMegSpiritConsts.ERREUR_INTERNE;
          errorDescription = Messages.getString("PE0298.BL301.ErreurInterne"); //$NON-NLS-1$
        }
        else
        {
          error = retour_p.getDiagnostic();
          errorDescription = retour_p.getLibelle();
        }

        pfs.addErreur(new PE0298_Erreur(error, errorDescription));
      }

      return new Pair<>(RetourFactory.createOkRetour(), pfs);
    }

    pfs.setTypePfs(messageriePfs_p.getTypePfs());
    pfs.setTypeMessagerie(messageriePfs_p.getTypeMessagerie());
    pfs.setStatutMessagerie(messageriePfs_p.getStatutMessagerie());

    return new Pair<>(RetourFactory.createOkRetour(), pfs);
  }

  /**
   * @param tracabilite_p
   * @param referentiel_p
   * @param pfs_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private PE0298_BL400Return PE0298_BL400_ComparerVues(Tracabilite tracabilite_p, PE0298_BL001Return bl001Return_p, List<PE0298_Referentiel> referentiel_p, List<PE0298_PFS> pfs_p) throws RavelException
  {
    List<ActionServiceTechnique> listeActionServiceTechnique = new ArrayList<>();
    List<PE0298_Referentiel> listeReferentiel = referentiel_p != null ? new ArrayList<>(referentiel_p) : null;
    List<PE0298_PFS> listePFS = pfs_p != null ? new ArrayList<>(pfs_p) : null;

    String idExterne = null;
    String idActionCorrective = null;

    if ((listeReferentiel != null) && (listePFS != null) && bl001Return_p.getAudit())
    {
      for (PE0298_PFS pfs : listePFS)
      {
        ServiceTechnique serviceTechnique = null;
        StPfsVmsStw stPfsVmsStw = null;
        StPfsVmsCvm stPfsVmsCvm = null;

        if (pfs.getErreurs().isEmpty())
        {
          Boolean creerActionCorrective = Boolean.FALSE;

          PE0298_Referentiel referentiel = getReferentielByNoTelephone(listeReferentiel, pfs.getNoTelephone());
          if (referentiel != null)
          {
            stPfsVmsStw = new StPfsVmsStwFilter() //
                .whereStatutIs(Statut.ACTIF) //
                .getFirst(referentiel.getListeST());

            stPfsVmsCvm = new StPfsVmsCvmFilter() //
                .whereStatutIs(Statut.ACTIF) //
                .getFirst(referentiel.getListeST());

            if ((stPfsVmsStw != null) && (stPfsVmsCvm != null))
            {
              return new PE0298_BL400Return(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.MIGRATION_EN_COURS, Messages.getString("PE0298.MigrationEnCours"))); //$NON-NLS-1$
            }

            if ((stPfsVmsStw == null) && (stPfsVmsCvm == null))
            {
              continue;
            }

            serviceTechnique = stPfsVmsStw != null ? stPfsVmsStw : stPfsVmsCvm;

            Pair<ServiceTechnique, Boolean> traitementAudit = traiterAudit(serviceTechnique, pfs);
            serviceTechnique = traitementAudit._first;
            creerActionCorrective = traitementAudit._second;
          }

          if (creerActionCorrective)
          {
            listeActionServiceTechnique.add(createActionServiceTechnique(serviceTechnique));
          }
        }
      }

      if (!listeActionServiceTechnique.isEmpty())
      {
        idExterne = _processContext.getIdRequest() + _processContext.getNoTelephone();

        ActionCorrective actionCorrective = new ActionCorrective(bl001Return_p.getClientOperateur(), bl001Return_p.getNoCompte());
        actionCorrective.setActionsServicesTechniques(listeActionServiceTechnique);

        BL5100_CreerActionCorrective bl5100 = new BL5100_CreerActionCorrective.BL5100_CreerActionCorrectiveBuilder() // create BL5100_CreerActionCorrective
            .idExterne(idExterne).actionCorrective(actionCorrective).tracabilite(tracabilite_p) //set Tracabilite
            .build();

        idActionCorrective = bl5100.execute(this);
        Retour bl5100Retour = bl5100.getRetour();

        if (RetourFactory.isRetourNOK(bl5100Retour))
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, bl5100Retour.getDiagnostic() + ": " + bl5100Retour.getLibelle())); //$NON-NLS-1$

          //Ajouter l’erreur ECHEC_ACTION_CORRECTIVE a la liste d’objets PFS desycnhonisés
          for (PE0298_PFS pfs : listePFS)
          {
            if (!pfs.getAudits().isEmpty())
            {
              pfs.addErreur(new PE0298_Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), MessageFormat.format(ERROR_CREATION_ACTION_CORRECTIVE, bl5100Retour.getDiagnostic())));
            }
          }
        }
      }
    }

    return new PE0298_BL400Return(RetourFactory.createOkRetour(), referentiel_p, pfs_p, idActionCorrective);
  }

  /**
   * Audit treatment in PE0298_PFS and evaluates the need for a corrective action
   *
   * @param serviceTechnique_p
   * @param pfs_p
   * @return Pair<ServiceTechnique, Boolean> Pair with serviceTechnique and boolean creerActionCorrective
   */
  private Pair<ServiceTechnique, Boolean> traiterAudit(ServiceTechnique serviceTechnique_p, PE0298_PFS pfs_p)
  {
    if ((pfs_p.getAudits() != null) && auditContainsDiagnostic(pfs_p.getAudits(), Diagnostic.SERVICE_NON_PROVISIONNE))
    {
      serviceTechnique_p.setStatut(Statut.INACTIF.toString());
      return new Pair<>(serviceTechnique_p, Boolean.TRUE);
    }

    StPfsVmsStw stPfsVmsStw = serviceTechnique_p instanceof StPfsVmsStw ? (StPfsVmsStw) serviceTechnique_p : null;
    StPfsVmsCvm stPfsVmsCvm = serviceTechnique_p instanceof StPfsVmsCvm ? (StPfsVmsCvm) serviceTechnique_p : null;

    PE0298_Audit pe0298Audit = new PE0298_Audit(Diagnostic.DESYNCHRO_PFS.toString(), Messages.getString("PE0298.BL400.LibelleDesynchroPfs")); //$NON-NLS-1$
    pe0298Audit.addParameter("typeMessagerie"); //$NON-NLS-1$

    if ((stPfsVmsStw != null) && (stPfsVmsStw.getDonneesProvisionneesSTPfsVmsStw() != null) && (!pfs_p.getTypeMessagerie().equals(stPfsVmsStw.getDonneesProvisionneesSTPfsVmsStw().getTypeUsage())))
    {
      pfs_p.addAudit(pe0298Audit);
      return new Pair<>(stPfsVmsStw, Boolean.TRUE);
    }

    if ((stPfsVmsCvm != null) && (stPfsVmsCvm.getDonneesProvisionneesSTPfsVmsCvm() != null) && (!pfs_p.getTypeMessagerie().equals(stPfsVmsCvm.getDonneesProvisionneesSTPfsVmsCvm().getTypeUsage())))
    {
      pfs_p.addAudit(pe0298Audit);
      return new Pair<>(stPfsVmsCvm, Boolean.TRUE);
    }

    return new Pair<>(serviceTechnique_p, Boolean.FALSE);
  }
}