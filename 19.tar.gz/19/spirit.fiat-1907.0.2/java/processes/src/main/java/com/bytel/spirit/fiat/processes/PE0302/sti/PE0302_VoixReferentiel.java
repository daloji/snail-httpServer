/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.squareup.moshi.Json;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0302_VoixReferentiel implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 6753027399600847393L;

  /**
   * typeReseau
   */
  @Json(name = "typeReseau")
  private String _typeReseau;

  /**
   * statut
   */
  @Json(name = "statut")
  private String _statut;

  /**
   * niveauRestriction
   */
  @Json(name = "niveauRestriction")
  private String _niveauRestriction;

  /**
   * impi
   */
  @Json(name = "impi")
  private List<String> _impi;

  /**
   * impu
   */
  @Json(name = "impu")
  private List<String> _impu;

  /**
   * codeINSEE
   */
  @Json(name = "codeINSEE")
  private String _codeINSEE;

  /**
   * nom
   */
  @Json(name = "nom")
  private String _nom;

  /**
   * preNom
   */
  @Json(name = "prenom")
  private String _prenom;

  /**
   * nomUtilisateurCourt
   */
  @Json(name = "nomPrenomCourt")
  private String _nomPrenomCourt;

  /**
   * optionAppelSurTaxes
   */
  @Json(name = "optionAppelSurTaxes")
  private String _optionAppelSurTaxes;

  /**
   * @return the codeINSEE
   */
  public String getCodeINSEE()
  {
    return _codeINSEE;
  }

  /**
   * @return the impi
   */
  public List<String> getImpi()
  {
    return _impi != null ? new ArrayList<>(_impi) : new ArrayList<>();
  }

  /**
   * @return the impu
   */
  public List<String> getImpu()
  {
    return _impu != null ? new ArrayList<>(_impu) : new ArrayList<>();
  }

  /**
   * @return the niveauRestriction
   */
  public String getNiveauRestriction()
  {
    return _niveauRestriction;
  }

  /**
   * @return the nom
   */
  public String getNom()
  {
    return _nom;
  }

  /**
   * @return the nomPrenomCourt
   */
  public String getNomPrenomCourt()
  {
    return _nomPrenomCourt;
  }

  /**
   * @return the optionAppelSurTaxes
   */
  public String getOptionAppelSurTaxes()
  {
    return _optionAppelSurTaxes;
  }

  /**
   * @return the prenom
   */
  public String getPrenom()
  {
    return _prenom;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the typeReseau
   */
  public String getTypeReseau()
  {
    return _typeReseau;
  }

  /**
   * @param codeINSEE_p
   *          the codeINSEE to set
   */
  public void setCodeINSEE(String codeINSEE_p)
  {
    _codeINSEE = codeINSEE_p;
  }

  /**
   * @param impi_p
   *          the impi to set
   */
  public void setImpi(List<String> impi_p)
  {
    _impi = new ArrayList<>(impi_p);
  }

  /**
   * @param impu_p
   *          the impu to set
   */
  public void setImpu(List<String> impu_p)
  {
    _impu = new ArrayList<>(impu_p);
  }

  /**
   * @param niveauRestriction_p
   *          the niveauRestriction to set
   */
  public void setNiveauRestriction(String niveauRestriction_p)
  {
    _niveauRestriction = niveauRestriction_p;
  }

  /**
   * @param nom_p
   *          the nom to set
   */
  public void setNom(String nom_p)
  {
    _nom = nom_p;
  }

  /**
   * @param nomPrenomCourt_p
   *          the nomPrenomCourt to set
   */
  public void setNomPrenomCourt(String nomPrenomCourt_p)
  {
    _nomPrenomCourt = nomPrenomCourt_p;
  }

  /**
   * @param optionAppelSurTaxes_p
   *          the optionAppelSurTaxes to set
   */
  public void setOptionAppelSurTaxes(String optionAppelSurTaxes_p)
  {
    _optionAppelSurTaxes = optionAppelSurTaxes_p;
  }

  /**
   * @param prenom_p
   *          the prenom to set
   */
  public void setPrenom(String prenom_p)
  {
    _prenom = prenom_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param typeReseau_p
   *          the typeReseau to set
   */
  public void setTypeReseau(String typeReseau_p)
  {
    _typeReseau = typeReseau_p;
  }

}
