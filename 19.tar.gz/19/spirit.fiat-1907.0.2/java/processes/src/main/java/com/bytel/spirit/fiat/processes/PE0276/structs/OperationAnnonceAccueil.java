/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0276.structs;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public enum OperationAnnonceAccueil
{
  LISTER_ANNONCE("listerAnnonce"), //
  TELECHARGER_ANNONCE("telechargerAnnonce"), //
  MODIFIER_CONTENU_ANNONCE("modifierContenuAnnonce"), //
  MODIFIER_STATUT_ANNONCE("modifierStatutAnnonce"), //
  MODIFIER_ANNONCE("modifierAnnonce");

  /**
   * Value
   */
  private final String _value;

  /**
   * Default constructor
   * 
   * @param value
   */
  OperationAnnonceAccueil(String value)
  {
    this._value = value;
  }

  /**
   * Get value
   * 
   * @return
   */
  public String getValue()
  {
    return this._value;
  }

}
