/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.structs;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.squareup.moshi.Json;

/**
 *
 * @author fbarnabe
 * @version ($Revision$ $Date$)
 * @param <T>
 *          Type
 */
public class GetResponse<T> extends XItem
{

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = -8290377457419004056L;

  /**
   * results count
   */
  @SerializedName("resultsCount")
  @Expose
  @Json(name = "resultsCount")
  private Integer _resultsCount;

  /**
   * items
   */
  @SerializedName("items")
  @Expose
  @Json(name = "items")
  private List<T> _items;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    GetResponse other = (GetResponse) obj;
    if (_items == null)
    {
      if (other._items != null)
      {
        return false;
      }
    }
    else if (!_items.equals(other._items))
    {
      return false;
    }
    if (_resultsCount == null)
    {
      if (other._resultsCount != null)
      {
        return false;
      }
    }
    else if (!_resultsCount.equals(other._resultsCount))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the items
   */
  public List<T> getItems()
  {
    return _items != null ? new ArrayList<>(_items) : new ArrayList<>();
  }

  /**
   * @return the resultsCount
   */
  public Integer getResultsCount()
  {
    return _resultsCount;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_items == null) ? 0 : _items.hashCode());
    result = (prime * result) + ((_resultsCount == null) ? 0 : _resultsCount.hashCode());
    return result;
  }

  /**
   * @param items_p
   *          the items to set
   */
  public void setItems(List<T> items_p)
  {
    _items = new ArrayList<T>(items_p);
  }

  /**
   * @param resultsCount_p
   *          the resultsCount to set
   */
  public void setResultsCount(Integer resultsCount_p)
  {
    _resultsCount = resultsCount_p;
  }

  @Override
  public String toString()
  {
    return "GetResponse [_resultsCount=" + _resultsCount + ", _items=" + _items + "]";
  }

}
