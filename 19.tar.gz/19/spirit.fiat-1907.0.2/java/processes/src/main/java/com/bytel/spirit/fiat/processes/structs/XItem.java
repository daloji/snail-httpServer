/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.structs;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.squareup.moshi.Json;

/**
 *
 * @author fbarnabe
 * @version ($Revision$ $Date$)
 */
public class XItem implements Serializable
{

  /**
   * The serial version UID
   */
  private static final long serialVersionUID = 1806207757957590180L;

  /**
   * _actions
   */
  @SerializedName("_actions")
  @Expose
  @Json(name = "_actions")
  private Map<String, XAction> _actions;

  /**
   * _links
   */
  @SerializedName("_links")
  @Expose
  @Json(name = "_links")
  private Map<String, XLink> _links;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    XItem other = (XItem) obj;
    if (_actions == null)
    {
      if (other._actions != null)
      {
        return false;
      }
    }
    else if (!_actions.equals(other._actions))
    {
      return false;
    }
    if (_links == null)
    {
      if (other._links != null)
      {
        return false;
      }
    }
    else if (!_links.equals(other._links))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the actions
   */
  public Map<String, XAction> getActions()
  {
    return _actions;
  }

  /**
   * @return the links
   */
  public Map<String, XLink> getLinks()
  {
    return _links;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_actions == null) ? 0 : _actions.hashCode());
    result = (prime * result) + ((_links == null) ? 0 : _links.hashCode());
    return result;
  }

  /**
   * @param key_p
   *          key
   * @param action_p
   *          link
   */
  public void putAction(String key_p, XAction action_p)
  {
    if (_actions == null)
    {
      _actions = new HashMap<>();
    }
    _actions.put(key_p, action_p);
  }

  /**
   * @param key_p
   *          key
   * @param link_p
   *          link
   */
  public void putLink(String key_p, XLink link_p)
  {
    if (_links == null)
    {
      _links = new HashMap<>();
    }
    _links.put(key_p, link_p);
  }

  /**
   * @param actions_p
   *          the actions to set
   */
  public void setActions(Map<String, XAction> actions_p)
  {
    _actions = actions_p;
  }

  /**
   * @param links_p
   *          the links to set
   */
  public void setLinks(Map<String, XLink> links_p)
  {
    _links = links_p;
  }

  @Override
  public String toString()
  {
    return "XItem [_actions=" + _actions + ", _links=" + _links + "]";
  }

}
