/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.common.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_Erreur;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_PFS;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_Referentiel;
import com.squareup.moshi.Json;

/**
 *
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0302_Retour implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -9082618969389586914L;

  /**
   * responseErrreur
   */
  private transient PE0302_Erreur _reponseErreur;

  /**
   *
   */
  @Json(name = "pfs")
  private List<PE0302_PFS> _pfs;

  /**
   *
   */
  @Json(name = "referentiels")
  private List<PE0302_Referentiel> _referentiels;

  /**
   *
   */
  @Json(name = "idActionCorrective")
  private String _idActionCorrective;

  /**
   * retour
   */
  private transient Retour _retour;

  /**
   * @return the idActionCorrective
   */
  public String getIdActionCorrective()
  {
    return _idActionCorrective;
  }

  /**
   * @return the pfs
   */
  public List<PE0302_PFS> getPfs()
  {
    return _pfs != null ? new ArrayList<>(_pfs) : new ArrayList<>();
  }

  /**
   * @return the referentiels
   */
  public List<PE0302_Referentiel> getReferentiels()
  {
    return _referentiels != null ? new ArrayList<>(_referentiels) : new ArrayList<>();
  }

  /**
   * @return the reponseErreur
   */
  public PE0302_Erreur getReponseErreur()
  {
    return _reponseErreur;
  }

  /**
   * @return the retour
   */
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * @param idActionCorrective_p
   *          the idActionCorrective to set
   */
  public void setIdActionCorrective(String idActionCorrective_p)
  {
    _idActionCorrective = idActionCorrective_p;
  }

  /**
   * @param pfs_p
   *          the pfs to set
   */
  public void setPfs(List<PE0302_PFS> pfs_p)
  {
    _pfs = CollectionUtils.isEmpty(pfs_p) ? null : new ArrayList<>(pfs_p);
  }

  /**
   * @param referentiels_p
   *          the referentiels to set
   */
  public void setReferentiels(List<PE0302_Referentiel> referentiels_p)
  {
    _referentiels = CollectionUtils.isEmpty(referentiels_p) ? null : new ArrayList<>(referentiels_p);
  }

  /**
   * @param reponseErreur_p
   *          the reponseErreur to set
   */
  public void setReponseErreur(PE0302_Erreur reponseErreur_p)
  {
    _reponseErreur = reponseErreur_p;
  }

  /**
   * @param retour_p
   *          the retour to set
   */
  public void setRetour(Retour retour_p)
  {
    _retour = retour_p;
  }
}
