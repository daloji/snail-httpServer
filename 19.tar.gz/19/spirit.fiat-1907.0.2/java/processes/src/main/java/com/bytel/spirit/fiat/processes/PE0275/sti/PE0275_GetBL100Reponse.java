/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0275.sti;

import com.bytel.spirit.fiat.processes.structs.GetResponse;

/**
 *
 * @author vloureir
 * @version ($Revision$ $Date$)
 */
public class PE0275_GetBL100Reponse extends GetResponse<PE0275_MessagesPFS>
{

  /**
   *
   */
  private static final long serialVersionUID = -1602047350098009328L;

}
