/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : 814_837_RessourceMessage
 *  Package : com.bytel.spirit.fiat.processes.PE0275.structs
 *  Classe  : PE0275_Suivi
 *  Auteur  : sdiop
 *
 */

package com.bytel.spirit.fiat.processes.PE0275.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.squareup.moshi.Json;

/**
 * @author sdiop
 * @version ($Revision$ $Date$)
 */
public class PE0275_SuiviPost implements Serializable
{
    /**
     * Serial UID
     */
    private static final long serialVersionUID = 8006002634074652870L;

    /**
     * statutLecture
     */
    @Json(name = "statutLecture")
    private String _statutLecture;

    /**
     * statutArchivage
     */
    @Json(name = "statutArchivage")
    private String _statutArchivage;

    /**
     * Default constructor
     */
    public PE0275_SuiviPost()
    {
        super();
    }

    /**
     * Argument constructor
     *
     * @param statutLecture_p
     *          statutLecture
     * @param statutArchivage_p
     *          statutArchivage
     */
    public PE0275_SuiviPost(String statutLecture_p, String statutArchivage_p)
    {
        _statutLecture = statutLecture_p;
        _statutArchivage = statutArchivage_p;
    }

    /**
     * @return statutLecture
     */
    public String getStatutLecture()
    {
        return _statutLecture;
    }

    /**
     * @param statutLecture_p statutLecture
     */
    public void setStatutLecture(String statutLecture_p)
    {
        _statutLecture = statutLecture_p;
    }

    /**
     * @return value of statutArchivage
     */
    public String getStatutArchivage()
    {
        return _statutArchivage;
    }

    /**
     * @param statutArchivage_p
     *     The statutArchivage to set.
     */
    public void setStatutArchivage(String statutArchivage_p)
    {
        _statutArchivage = statutArchivage_p;
    }
}


