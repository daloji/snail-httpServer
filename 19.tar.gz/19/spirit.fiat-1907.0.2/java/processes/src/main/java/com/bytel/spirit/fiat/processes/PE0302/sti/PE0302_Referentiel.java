/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.squareup.moshi.Json;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0302_Referentiel implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -2188022431549175423L;
  /**
   * typeService
   */
  @Json(name = "typeService")
  private String _typeService;
  /**
   * noTelephone
   */
  @Json(name = "noTelephone")
  private String _noTelephone;
  /**
   * ressources
   */
  @Json(name = "ressources")
  private List<PE0302_Ressource> _ressources;
  /**
   * typeUsages
   */
  @Json(name = "typeUsages")
  private List<String> _typeUsages;
  /**
   * etatProvisioning
   */
  @Json(name = "etatProvisioning")
  private String _etatProvisioning;
  /**
   * audits
   */
  @Json(name = "audits")
  private List<PE0302_Audit> _audits;
  /**
   * erreurs
   */
  @Json(name = "erreurs")
  private List<PE0302_Erreur> _erreurs;
  /**
   * voix
   */
  @Json(name = "voix")
  private PE0302_VoixReferentiel _voix;

  /**
   *
   */
  @Json(name = "fax")
  private PE0302_Fax _fax;

  /**
   * System technique
   */
  private transient List<ServiceTechnique> _st;

  /**
   * noCompte
   */
  private transient String _noCompte;

  /**
   * clientOp
   */
  private transient String _clientOperateur;

  /**
   * @return the audits
   */
  public List<PE0302_Audit> getAudits()
  {
    return _audits != null ? new ArrayList<>(_audits) : new ArrayList<>();
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the erreurs
   */
  public List<PE0302_Erreur> getErreurs()
  {
    return _erreurs != null ? new ArrayList<>(_erreurs) : new ArrayList<>();
  }

  /**
   * @return the etatProvisioning
   */
  public String getEtatProvisioning()
  {
    return _etatProvisioning;
  }

  /**
   * @return the fax
   */
  public PE0302_Fax getFax()
  {
    return _fax;
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the ressources
   */
  public List<PE0302_Ressource> getRessources()
  {
    return _ressources != null ? new ArrayList<>(_ressources) : new ArrayList<>();

  }

  /**
   * @return the st
   */
  public List<ServiceTechnique> getSt()
  {
    return _st != null ? new ArrayList<>(_st) : new ArrayList<>();

  }

  /**
   * @return the typeService
   */
  public String getTypeService()
  {
    return _typeService;
  }

  /**
   * @return the typeUsages
   */
  public List<String> getTypeUsages()
  {
    return _typeUsages != null ? new ArrayList<>(_typeUsages) : new ArrayList<>();
  }

  /**
   * @return the voix
   */
  public PE0302_VoixReferentiel getVoix()
  {
    return _voix;
  }

  /**
   * @param audits_p
   *          the audits to set
   */
  public void setAudits(List<PE0302_Audit> audits_p)
  {
    _audits = new ArrayList<>(audits_p);
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param erreurs_p
   *          the erreurs to set
   */
  public void setErreurs(List<PE0302_Erreur> erreurs_p)
  {
    _erreurs = new ArrayList<>(erreurs_p);
  }

  /**
   * @param etatProvisioning_p
   *          the etatProvisioning to set
   */
  public void setEtatProvisioning(String etatProvisioning_p)
  {
    _etatProvisioning = etatProvisioning_p;
  }

  /**
   * @param fax_p
   *          the fax to set
   */
  public void setFax(PE0302_Fax fax_p)
  {
    _fax = fax_p;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param ressources_p
   *          the ressources to set
   */
  public void setRessources(List<PE0302_Ressource> ressources_p)
  {
    _ressources = new ArrayList<>(ressources_p);

  }

  /**
   * @param st_p
   *          the st to set
   */
  public void setSt(List<ServiceTechnique> st_p)
  {
    _st = new ArrayList<>(st_p);

  }

  /**
   * @param typeService_p
   *          the typeService to set
   */
  public void setTypeService(String typeService_p)
  {
    _typeService = typeService_p;
  }

  /**
   * @param typeUsages_p
   *          the typeUsages to set
   */
  public void setTypeUsages(List<String> typeUsages_p)
  {
    _typeUsages = new ArrayList<>(typeUsages_p);
  }

  /**
   * @param voix_p
   *          the voix to set
   */
  public void setVoix(PE0302_VoixReferentiel voix_p)
  {
    _voix = voix_p;
  }

}
