/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0276;

import static com.bytel.spirit.fiat.processes.PE0276.structs.OperationAnnonceAccueil.LISTER_ANNONCE;
import static com.bytel.spirit.fiat.processes.PE0276.structs.OperationAnnonceAccueil.MODIFIER_ANNONCE;
import static com.bytel.spirit.fiat.processes.PE0276.structs.OperationAnnonceAccueil.MODIFIER_CONTENU_ANNONCE;
import static com.bytel.spirit.fiat.processes.PE0276.structs.OperationAnnonceAccueil.MODIFIER_STATUT_ANNONCE;
import static com.bytel.spirit.fiat.processes.PE0276.structs.OperationAnnonceAccueil.TELECHARGER_ANNONCE;
import static java.util.Objects.nonNull;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;
import org.springframework.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI015_TelechargerAnnonceAccueil;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI015_TelechargerAnnonceAccueil.VMSCVM_SI015_TelechargerAnnonceAccueilBuilder;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI034_PersonnaliserAnnonceAccueil;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI034_PersonnaliserAnnonceAccueil.VMSCVM_SI034_PersonnaliserAnnonceAccueilBuilder;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI029_ModifierContenuMediaAnnonceAccueil;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI029_ModifierContenuMediaAnnonceAccueil.VMSSTW_SI029_ModifierContenuMediaAnnonceAccueilBuilder;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI031_TelechargerAnnonceAccueil;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI031_TelechargerAnnonceAccueil.VMSSTW_SI031_TelechargerAnnonceAccueilBuilder;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.fiat.config.AnnonceAccueilConfig;
import com.bytel.spirit.common.shared.functional.types.Annonce;
import com.bytel.spirit.common.shared.functional.types.json.AnnonceAccueilPfs;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.types.BinaryContentWrapper;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0276.structs.AnnoncesAccueil;
import com.bytel.spirit.fiat.processes.PE0276.structs.OperationAnnonceAccueil;
import com.bytel.spirit.fiat.processes.PE0276.structs.PE0276_BL001GetRetour;
import com.bytel.spirit.fiat.processes.PE0276.structs.PE0276_BL001PutRetour;
import com.bytel.spirit.fiat.processes.PE0276.structs.PE0276_BL002GetReturn;
import com.bytel.spirit.fiat.processes.PE0276.structs.PE0276_BL100Reponse;
import com.bytel.spirit.fiat.processes.PE0276.structs.PE0276_PutRequest;
import com.bytel.spirit.fiat.processes.structs.XAction;
import com.bytel.spirit.fiat.processes.structs.XLink;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PE0276_AnnoncesAccueils extends SpiritRestApiProcessSkeleton
{

  /**
   *
   *
   * @author pescudei
   * @version ($Revision$ $Date$)
   */
  public static final class PE0276_AnnoncesAccueilsContext extends Context
  {

    /**
     * The serial UID
     */
    private static final long serialVersionUID = 1222979846631230064L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0276_START;

    /**
     * Contains the process configuration
     */
    private transient AnnonceAccueilConfig _configurationPE0276;

    /**
     * The retour of the process
     */
    private Retour _processRetour;

    /**
     * Mailbox ID
     */
    private String _idMessagerie;

    /**
     * modeAppel
     */
    private String _modeAppel;

    /**
     * The Liste contract auth;
     */
    private List<String> _listeContratOauth;

    /**
     * Message format
     */
    private String _format;

    /**
     * idRequest
     */
    private String _idRequest;

    /**
     * @param contratOuath_p
     *          the contratOuath to add
     */
    public void addContratOauth(String contratOuath_p)
    {
      if (_listeContratOauth == null)
      {
        _listeContratOauth = new ArrayList<>();
      }
      _listeContratOauth.add(contratOuath_p);
    }

    /**
     * @return value of _configurationPE0276
     */
    public AnnonceAccueilConfig getConfigurationPE0276()
    {
      return _configurationPE0276;
    }

    /**
     * @return the format
     */
    public String getFormat()
    {
      return _format;
    }

    /**
     * @return the idMessagerie
     */
    public String getIdMessagerie()
    {
      return _idMessagerie;
    }

    /**
     * @return the idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the listeContratOauth
     */
    public List<String> getListeContratOauth()
    {
      return _listeContratOauth != null ? new ArrayList<>(_listeContratOauth) : new ArrayList<>();
    }

    /**
     * @return the modeAppel
     */
    public String getModeAppel()
    {
      return _modeAppel;
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param configurationPE0276_p
     *          The _configurationPE0276 to set.
     */
    public void setConfigurationPE0276(AnnonceAccueilConfig configurationPE0276_p)
    {
      _configurationPE0276 = configurationPE0276_p;
    }

    /**
     * @param format_p
     *          the format to set
     */
    public void setFormat(String format_p)
    {
      _format = format_p;
    }

    /**
     * @param idMessagerie_p
     *          the idMessagerie to set
     */
    public void setIdMessagerie(String idMessagerie_p)
    {
      _idMessagerie = idMessagerie_p;
    }

    /**
     * @param idRequest_p
     *          the idRequest to set
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param listeContratOauth_p
     *          the listeContratOauth to set
     */
    public void setListeContratOauth(List<String> listeContratOauth_p)
    {
      _listeContratOauth = new ArrayList<>(listeContratOauth_p);
    }

    /**
     * @param modeAppel_p
     *          the modeAppel to set
     */
    public void setModeAppel(String modeAppel_p)
    {
      _modeAppel = modeAppel_p;
    }

    /**
     * @param processRetour_p
     *          the processRetour to set
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }
  }

  /**
   *
   * @author pescudei
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0276_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call GET_BL001
     */
    PE0276_GET_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT_BL001
     */
    PE0276_PUT_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call GET BL100
     */
    PE0276_GET_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL100
     */
    PE0276_PUT_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PE0276_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call GET BL002
     */
    PE0276_GET_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL002
     */
    PE0276_PUT_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PE0276_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }

    /**
     * @return the technicalState
     */
    public MandatoryProcessState getTechnicalState()
    {
      return _technicalState;
    }

    /**
     * @return the asynchronousState
     */
    public boolean isAsynchronousState()
    {
      return _asynchronousState;
    }

    /**
     * @return the replayableState
     */
    public boolean isReplayableState()
    {
      return _replayableState;
    }

    /**
     * @param asynchronousState_p
     *          the asynchronousState to set
     */
    public void setAsynchronousState(boolean asynchronousState_p)
    {
      _asynchronousState = asynchronousState_p;
    }

    /**
     * @param replayableState_p
     *          the replayableState to set
     */
    public void setReplayableState(boolean replayableState_p)
    {
      _replayableState = replayableState_p;
    }

    /**
     * @param technicalState_p
     *          the technicalState to set
     */
    public void setTechnicalState(MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
    }

  }

  /**
   * The serial UID
   */
  private static final long serialVersionUID = 8803261048750203871L;

  /**
   * The constant for FileError message
   */
  protected static final String MESSAGE_FILE_ERROR = Messages.getString("PE0276.FileError"); //$NON-NLS-1$

  /**
   * The constant for NoParam message
   */
  protected static final String MESSAGE_NO_PARAM = Messages.getString("PE0276.NoParam"); //$NON-NLS-1$

  /**
   * The constant for BL001.HeaderNullOrEmpty message
   */
  private static final String MESSAGE_INVALID_HEADER = Messages.getString("PE0276.BL001.HeaderNullOrEmpty"); //$NON-NLS-1$

  /**
   * The constant for BL100.IdMessagrieInconnu message
   */
  private static final String MESSAGE_ID_MESSAGERIE_INCONNU = Messages.getString("PE0276.BL100.IdMessagrieInconnu"); //$NON-NLS-1$

  /**
   * The constant for BL200.IdAnnonceInconnu message
   */
  private static final String MESSAGE_ID_ANNNONCE_INCONNU = Messages.getString("PE0276.BL200.IdAnnonceInconnu"); //$NON-NLS-1$

  /**
   * The constant for BL100.OperationNotAutorized message
   */
  private static final String MESSAGE_OPERATION_NOT_AUTORIZED = Messages.getString("PE0276.BL100.OperationNotAutorized"); //$NON-NLS-1$

  /**
   * The constant for BL200.OperationNotAutorized message
   */
  private static final String MESSAGE_OPERATION_NOT_AUTORIZED_BL200 = Messages.getString("PE0276.BL200.OperationNotAutorized"); //$NON-NLS-1$

  /**
   * The constant for BL100.serviceIndisponible message
   */
  private static final String MESSAGE_SERVICE_INDISPONIBLE = Messages.getString("PE0276.BL100.ServiceIndisponible"); //$NON-NLS-1$

  /**
   * The constant for BL100.missingParameter message
   */
  private static final String MESSAGE_MISSING_PARAMETER = Messages.getString("PE0276.BL001.MissingParameter"); //$NON-NLS-1$

  /**
   * PARAM_ID_MESSAGERIE constant
   */
  private static final String PARAM_ID_MESSAGERIE = "idMessagerie"; //$NON-NLS-1$

  /**
   * PARAM_ID_ANNONCE constant
   */
  private static final String PARAM_ID_ANNONCE = "idAnnonce"; //$NON-NLS-1$

  /**
   * Configuration path Param
   */
  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * OPERATION_ANNONCES_ACCUEIL
   */
  protected static final String OPERATION_ANNONCES_ACCUEIL = "PE0276_AnnoncesAccueilsLister"; //$NON-NLS-1$

  /**
   * URL_ANNONCE_ACCUEIL for BL100 return
   */
  protected static final String URL_ANNONCE_ACCUEIL = "/annonces-accueil/"; //$NON-NLS-1$

  /**
   * Constant string type annonce PERSONNALISEE
   */
  private static final String TYPE_ANNONCE_PERSONNALISEE = "PERSONNALISEE"; //$NON-NLS-1$

  /**
   * Constant string type annonce DEFAUT
   */
  private static final String TYPE_ANNONCE_DEFAUT = "DEFAUT"; //$NON-NLS-1$

  /**
   * Constant string STW
   */
  private static final String STW = "STW"; //$NON-NLS-1$

  /**
   * Constant string CVG
   */
  private static final String CVG = "CVG"; //$NON-NLS-1$

  /**
   * separator of X-Oauth2-Contracts in header
   */
  private static final String SEPARATOR = ","; //$NON-NLS-1$

  /**
   * KPSA processus name consulterAnnonceAccueilPfs
   */
  private static final String KPSA_CONSULTER_ANNONCE_ACCUEIL_PFS = "consulterAnnonceAccueilPfs"; //$NON-NLS-1$

  /**
   * KPSA processus name ModifierStatutAnnonceAccueilPfs
   */
  private static final String KPSA_MODIFIER_STATUT_ANNONCE_ACCUEIL_PFS = "modifierStatutAnnonceAccueilPfs"; //$NON-NLS-1$

  /**
   * idMessageriePfs constant
   */
  private static final String KPSA_PARAM_ID_MESSAGERIE_PFS = "idMessageriePfs"; //$NON-NLS-1$

  /**
   * typePfs constant
   */
  private static final String KPSA_PARAM_TYPE_PFS = "typePfs"; //$NON-NLS-1$

  /**
   * typeAnnonce constant
   */
  private static final String KPSA_PARAM_TYPE_ANNONCE = "typeAnnonce"; //$NON-NLS-1$

  /**
   * statutAnnonce constant
   */
  private static final String KPSA_PARAM_STATUT_ANNONCE = "statutAnnonce"; //$NON-NLS-1$

  /**
   * Process context instance
   */
  protected PE0276_AnnoncesAccueilsContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0276_AnnoncesAccueilsContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String s_p)
  {
    // Not required for now in Ravel
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param request_p
   *          Object technique «virtuel» regroupant l'ensemble des informations fournies en entrées du service REST
   *          (PATH + paramètres de l'URL, headers http, body http)
   * @return Pair of types Retour, PE0276_BL001GetRetour
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  protected Pair<Retour, PE0276_BL001GetRetour> PE0276_BL001_VerifierDonneesConsultation(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    try
    {
      // Load process config file
      Retour retourLoadConfig = loadConfigFile();
      if (RetourFactory.isRetourNOK(retourLoadConfig))
      {
        return new Pair<>(retourLoadConfig, null);
      }

      // Get the header parameters
      Retour retourHeaders = checkRequestHeaders(tracabilite_p, request_p);
      if (!isRetourOK(retourHeaders))
      {
        return new Pair<>(retourHeaders, null);
      }

      PE0276_BL001GetRetour retourBL001 = new PE0276_BL001GetRetour();
      retourBL001.setModeAppel(_processContext.getModeAppel());
      retourBL001.setListeContratOauth(_processContext.getListeContratOauth());

      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.ID_EXTERNE, _processContext.getIdRequest());
      if (OPERATION_ANNONCES_ACCUEIL.equals(request_p.getOperation()))
      {
        retourBL001.setTypeOperation(LISTER_ANNONCE);
        if (StringTools.isNullOrEmpty(request_p.getUrlDynamicParameters()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, PARAM_ID_MESSAGERIE)), null);
        }
        retourBL001.setIdMessagerie(request_p.getUrlDynamicParameters());
        refFonc.put(IRefFoncConstants.ID_MESSAGERIE, retourBL001.getIdMessagerie());
      }
      else
      {
        retourBL001.setTypeOperation(TELECHARGER_ANNONCE);
        if (StringTools.isNullOrEmpty(request_p.getUrlDynamicParameters()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, PARAM_ID_ANNONCE)), null);
        }
        retourBL001.setIdAnnonce(request_p.getUrlDynamicParameters());
        refFonc.put(IRefFoncConstants.ID_ANNONCE, retourBL001.getIdAnnonce());
      }

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
      bl1700.execute(this);

      // Retour OK
      return new Pair<>(RetourFactory.createOkRetour(), retourBL001);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()), null);
    }
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param request_p
   *          Object technique «virtuel» regroupant l'ensemble des informations fournies en entrées du service REST
   *          (PATH + paramètres de l'URL, headers http, body http)
   * @return Pair of types Retour, PE0276_BL001PutRetour
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  protected Pair<Retour, PE0276_BL001PutRetour> PE0276_BL001_VerifierDonneesModification(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    try
    {
      // Load process config file
      Retour retourLoadConfig = loadConfigFile();
      if (RetourFactory.isRetourNOK(retourLoadConfig))
      {
        return new Pair<>(retourLoadConfig, null);
      }

      // Get the header parameters
      Retour retourHeaders = checkRequestHeaders(tracabilite_p, request_p);
      if (!isRetourOK(retourHeaders))
      {
        return new Pair<>(retourHeaders, null);
      }

      PE0276_BL001PutRetour bl001PutRetour = new PE0276_BL001PutRetour();
      bl001PutRetour.setIdAnnonce(request_p.getUrlDynamicParameters());
      bl001PutRetour.setModeAppel(_processContext.getModeAppel());
      bl001PutRetour.setListeContratOauth(_processContext.getListeContratOauth());

      // Get idAnnonce from url
      if (StringTools.isNullOrEmpty(request_p.getUrlDynamicParameters()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, PARAM_ID_ANNONCE)), null);
      }
      bl001PutRetour.setIdAnnonce(request_p.getUrlDynamicParameters());

      // Get body parameters
      if (nonNull(request_p.getMultipartBody()))
      {
        // Get data part
        String dataPart = request_p.getMultipartBody().readStringPart("data");
        PE0276_PutRequest statutAnnonce = RavelJsonTools.getInstance().fromJson(dataPart, PE0276_PutRequest.class);
        bl001PutRetour.setStatutAnnonce(statutAnnonce == null ? null : statutAnnonce.getStatutAnnonce());

        // Get audio part
        InputStream audioPart = request_p.getMultipartBody().streamPart("audio");
        bl001PutRetour.setContenuMedia(audioPart == null ? null : IOUtils.toByteArray(audioPart));
      }
      else
      {
        // Get content type
        String contentType = request_p.getContentType();

        // Evaluate content type
        if (HttpConstants.CONTENT_TYPE_JSON.equals(contentType))
        {
          PE0276_PutRequest statutAnnonce = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0276_PutRequest.class);
          bl001PutRetour.setStatutAnnonce(statutAnnonce == null ? null : statutAnnonce.getStatutAnnonce());
        }
        else if (HttpConstants.CONTENT_TYPE_WAV.equalsIgnoreCase(contentType) //
            || HttpConstants.CONTENT_TYPE_X_WAV.equalsIgnoreCase(contentType) //
            || HttpConstants.CONTENT_TYPE_WAVE.equalsIgnoreCase(contentType))
        {
          InputStream audioPart = request_p.streamPayload();
          bl001PutRetour.setContenuMedia(audioPart == null ? null : IOUtils.toByteArray(audioPart));
        }
      }

      // Check content
      if ((bl001PutRetour.getContenuMedia() != null) && (bl001PutRetour.getContenuMedia().length > 0))
      {
        if (StringTools.isNullOrEmpty(bl001PutRetour.getStatutAnnonce()))
        {
          bl001PutRetour.setTypeOperation(MODIFIER_CONTENU_ANNONCE);
        }
        else
        {
          bl001PutRetour.setTypeOperation(MODIFIER_ANNONCE);
        }
      }
      else
      {
        bl001PutRetour.setTypeOperation(MODIFIER_STATUT_ANNONCE);
      }

      // Enrich tracability
      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.ID_EXTERNE, _processContext.getIdRequest());
      refFonc.put(IRefFoncConstants.ID_ANNONCE, bl001PutRetour.getIdAnnonce());

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
      bl1700.execute(this);

      // Retour OK
      return new Pair<>(RetourFactory.createOkRetour(), bl001PutRetour);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()), null);
    }
  }

  /**
   * PE0223_BL002_FormaterReponseConsultation
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retourIn_p
   *          retourBL001
   * @param typeOperation_p
   *          typeOperation
   * @param reponse_p
   *          reponse
   * @param contenuMedia_p
   *          contenuMedia
   * @return Pair<ReponseErreur, PE0223_Retour>
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  protected Pair<Retour, PE0276_BL002GetReturn> PE0276_BL002_FormaterReponseConsultation(Tracabilite tracabilite_p, Retour retourIn_p, OperationAnnonceAccueil typeOperation_p, PE0276_BL100Reponse reponse_p, byte[] contenuMedia_p) throws RavelException
  {

    if (!isRetourOK(retourIn_p))
    {
      ReponseErreur responseErreeur = new ReponseErreur();
      responseErreeur.setError(retourIn_p.getDiagnostic());
      responseErreeur.setErrorDescription(retourIn_p.getLibelle());
      return new Pair<>(retourIn_p, new PE0276_BL002GetReturn(responseErreeur, null, null));
    }
    if (LISTER_ANNONCE == typeOperation_p)
    {
      return new Pair<>(retourIn_p, new PE0276_BL002GetReturn(null, reponse_p, null));
    }
    return new Pair<>(retourIn_p, new PE0276_BL002GetReturn(null, null, contenuMedia_p));
  }

  /**
   * PE0276_BL002_FormaterReponseModification
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retourIn_p
   *          Retour
   * @return Retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  protected Pair<Retour, ReponseErreur> PE0276_BL002_FormaterReponseModification(Tracabilite tracabilite_p, Retour retourIn_p) throws RavelException
  {
    if (RetourFactory.isRetourNOK(retourIn_p))
    {
      ReponseErreur reponseErreur = new ReponseErreur();
      reponseErreur.setError(retourIn_p.getDiagnostic());
      reponseErreur.setErrorDescription(retourIn_p.getLibelle());
      return new Pair<>(retourIn_p, reponseErreur);
    }
    return new Pair<>(retourIn_p, null);
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    // Set process variables
    PE0276_BL100Reponse reponseConnector = null;
    byte[] contenuMedia = null;
    OperationAnnonceAccueil typeOperation = null;

    // Call BL001
    _processContext.setState(State.PE0276_GET_BL001);
    Pair<Retour, PE0276_BL001GetRetour> retourBL001 = PE0276_BL001_VerifierDonneesConsultation(tracabilite_p, request_p);
    _processContext.setProcessRetour(retourBL001._first);

    if (isRetourOK(retourBL001._first))
    {
      typeOperation = retourBL001._second.getTypeOperation();
      switch (typeOperation)
      {
        case LISTER_ANNONCE:
          // Call BL100
          _processContext.setState(State.PE0276_GET_BL100);
          Pair<Retour, PE0276_BL100Reponse> retourBl100 = PE0276_BL100_ListerAnnonce(tracabilite_p, retourBL001._second);
          reponseConnector = retourBl100._second;
          Retour retourBL100 = retourBl100._first;
          _processContext.setProcessRetour(retourBL100);
          break;

        case TELECHARGER_ANNONCE:
          //Call BL200
          _processContext.setState(State.PE0276_BL200);
          Pair<Retour, byte[]> retourBl200 = PE0276_BL200_TelechargerAnnonce(tracabilite_p, retourBL001._second);
          contenuMedia = retourBl200._second;
          Retour retourBL200 = retourBl200._first;
          _processContext.setProcessRetour(retourBL200);
          break;
      }
    }

    // Call BL002
    _processContext.setState(State.PE0276_GET_BL002);
    Pair<Retour, PE0276_BL002GetReturn> bl002Retour = PE0276_BL002_FormaterReponseConsultation(tracabilite_p, _processContext.getProcessRetour(), typeOperation, reponseConnector, contenuMedia);
    // Set process retour
    this.setRetour(_processContext.getProcessRetour());

    // Set process response
    syncGetResponse(request_p, bl002Retour._second);

    // Set end state
    _processContext.setState(State.PE0276_END);
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startPutProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    // Call BL001
    _processContext.setState(State.PE0276_PUT_BL001);
    Pair<Retour, PE0276_BL001PutRetour> retourBL001 = PE0276_BL001_VerifierDonneesModification(tracabilite_p, request_p);
    _processContext.setProcessRetour(retourBL001._first);

    if (RetourFactory.isRetourOK(retourBL001._first))
    {
      // Call BL001
      _processContext.setState(State.PE0276_PUT_BL100);
      Retour retourB100 = PE0276_BL100_ModifierAnnonce(tracabilite_p, retourBL001._second);
      _processContext.setProcessRetour(retourB100);
    }

    // Call BL002
    _processContext.setState(State.PE0276_PUT_BL002);
    Pair<Retour, ReponseErreur> retourBL002 = PE0276_BL002_FormaterReponseModification(tracabilite_p, _processContext.getProcessRetour());
    _processContext.setProcessRetour(retourBL002._first);

    // Set reponse
    syncPutResponse(request_p, retourBL002._second);

    // Set process retour
    this.setRetour(_processContext.getProcessRetour());

    // Set end state
    _processContext.setState(State.PE0276_END);
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param pe0276BL002GetReturn_p
   *          variable pe0276
   */
  protected void syncGetResponse(Request request_p, PE0276_BL002GetReturn pe0276BL002GetReturn_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

      if (pe0276BL002GetReturn_p.getReponseErreur() != null)
      {
        ErrorCode errorCode;
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pe0276BL002GetReturn_p.getReponseErreur(), ReponseErreur.class));
        switch (pe0276BL002GetReturn_p.getReponseErreur().getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ACCES_REFUSE:
            errorCode = ErrorCode.KO_00403;
            break;
          case IMegSpiritConsts.ID_MESSAGERIE_INCONNU:
          case IMegSpiritConsts.ID_ANNONCE_INCONNU:
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;
          //          case IMegSpiritConsts.TYPE_CONTENU_NON_SUPPORTE:
          //            errorCode = ErrorCode.KO_00415;
          //            break;
          case IMegSpiritConsts.PFS_INDISPO:
            //         case IMegSpiritConsts.MIGRATION_EN_COURS:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        if (pe0276BL002GetReturn_p.getPe0276BL100Retour() != null)
        {
          ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
          ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pe0276BL002GetReturn_p.getPe0276BL100Retour(), PE0276_BL100Reponse.class));
        }
        else
        {
          ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_WAV);
          ravelResponse.setBinaryResult(new ByteArrayInputStream(pe0276BL002GetReturn_p.getContenuMedia()));
        }
        request_p.setResponse(new Response(ErrorCode.OK_00200, ravelResponse));
      }
    }
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param reponseErreur_p
   *          variable pe0276
   */
  protected void syncPutResponse(Request request_p, ReponseErreur reponseErreur_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

      if (reponseErreur_p != null)
      {
        ErrorCode errorCode;
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur_p, ReponseErreur.class));
        switch (reponseErreur_p.getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ACCES_REFUSE:
            errorCode = ErrorCode.KO_00403;
            break;
          case IMegSpiritConsts.ID_ANNONCE_INCONNU:
          case IMegSpiritConsts.ACCES_MESSAGERIE_RESTREINT:
          case IMegSpiritConsts.KO_PFS:
            //case IMegSpiritConsts.TYPE_CONTENU_NON_SUPPORTE:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.PFS_INDISPO:
            //case IMegSpiritConsts.MIGRATION_EN_COURS:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        // Set content type
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        request_p.setResponse(new Response(ErrorCode.OK_00204, ravelResponse));
      }
    }
  }

  /**
   * Validates that each key in headersMap_p has a value in the request_p parameter, and if yes set the corresponding
   * value.
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param request_p
   *          The request The original request containing all headers
   *
   * @return Retour OK if all the headers in the headersMap_p are set, NOK otherwise
   */
  private Retour checkRequestHeaders(Tracabilite tracabilite_p, final Request request_p)
  {
    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        _processContext.setIdRequest(header.getValue());
      }

      if (IHttpHeadersConsts.X_OAUTH2_IDCONTRATS.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        String[] listeContract = header.getValue().trim().split(StringConstants.SEMICOLON_SEPARATOR);
        for (String contract : listeContract)
        {
          String[] contractElement = contract.split(SEPARATOR);
          String[] idContract = contractElement[0].split("="); //$NON-NLS-1$
          _processContext.addContratOauth(idContract[1]);
        }
      }
    }

    // Set mode appel
    _processContext.setModeAppel(request_p.getMetadata(IMetadata.METADATA_CANAL));

    if (StringTools.isNullOrEmpty(_processContext.getIdRequest()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_REQUEST_ID)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_REQUEST_ID));
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Load process configuration file into process context
   *
   * @return
   */
  private Retour loadConfigFile()
  {
    // Load config
    String configPE0276Param = getConfigParameter(PARAM_CONFIG_PATH);

    if (!StringTools.isNullOrEmpty(configPE0276Param))
    {
      try
      {
        Path configPE0276Path = Paths.get(configPE0276Param);
        String configPE0276File = new String(Files.readAllBytes(configPE0276Path));
        _processContext.setConfigurationPE0276(MarshallTools.unmarshall(AnnonceAccueilConfig.class, configPE0276File));

        return RetourFactory.createOkRetour();
      }
      catch (Exception exception)
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_FILE_ERROR, exception.getMessage()));
      }
    }
    return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, PARAM_CONFIG_PATH));
  }

  /**
   * PE0276_BL100_ListerAnnonce
   *
   * @param tracabilite_p
   *          tracabilite
   * @param bl001Retour_p
   *          nPE0276_BL001GetRetour
   * @return Retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Retour, PE0276_BL100Reponse> PE0276_BL100_ListerAnnonce(Tracabilite tracabilite_p, PE0276_BL001GetRetour bl001Retour_p) throws RavelException
  {
    String idMessagerieDecrypted, noContrat, idMessageriePfs, typeMessagerie, typePfs;

    // Decrypt the idMesssagerie
    try
    {
      idMessagerieDecrypted = PasswordDecrypter.decryptForURL(bl001Retour_p.getIdMessagerie());
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, "Error decrypting idOption", exception)); //$NON-NLS-1$
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGERIE_INCONNU, bl001Retour_p.getIdMessagerie())), null);
    }
    // Get the parameters type and noTelephone
    String[] parametresMessageriel = idMessagerieDecrypted.split("#"); //$NON-NLS-1$
    if (parametresMessageriel.length == 4)
    {
      noContrat = parametresMessageriel[0];
      idMessageriePfs = parametresMessageriel[1];
      typeMessagerie = parametresMessageriel[2];
      typePfs = parametresMessageriel[3];
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGERIE_INCONNU, bl001Retour_p.getIdMessagerie())), null);
    }

    //Check Operation is authorized for this type of Messagerie
    if (!_processContext.getConfigurationPE0276().getListeTypeMessagerieAutorisee().contains(typeMessagerie))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED, bl001Retour_p.getIdMessagerie())), null);
    }

    //Authorization control of contract number
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001Retour_p.getModeAppel()))
    {
      if (CollectionUtils.isEmpty(bl001Retour_p.getListeContratOauth()) //
          || StringTools.isNullOrEmpty(noContrat) //
          || bl001Retour_p.getListeContratOauth().stream().noneMatch(c -> c.equals(noContrat)))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "Acces refuse"), null); //$NON-NLS-1$
      }
    }

    //Call KPSA

    ListeParametre listparametre = new ListeParametre();
    listparametre.add(KPSA_PARAM_ID_MESSAGERIE_PFS, idMessageriePfs);
    listparametre.add(KPSA_PARAM_TYPE_PFS, typePfs);

    // Call PROV_SI002
    PROV_SI002_ExecuterProcessus si002 = new PROV_SI002_ExecuterProcessusBuilder().tracabilite(tracabilite_p) //
        .cles(Collections.emptyList()) //
        .priorite(10) //
        .processus(KPSA_CONSULTER_ANNONCE_ACCUEIL_PFS) //
        .listeParametres(listparametre).build();
    ResponseConnector si002Retour = si002.execute(this);
    Retour retour = si002.getRetour();

    if (!isRetourOK(retour))
    {
      switch (retour.getCategorie())
      {
        case IMegConsts.CAT1:
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE), null);
        case IMegConsts.CAT2:
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPONIBLE), null);
        default:
          return new Pair<>(retour, null);
      }
    }

    ReponseFonctionnelle<AnnonceAccueilPfs> responseFonctionnelle = si002Retour.getReponseFonctionnelle(AnnonceAccueilPfs.class);
    List<AnnoncesAccueil> annoncesAccueilList = new ArrayList<>();
    PE0276_BL100Reponse reponse = new PE0276_BL100Reponse();
    if ((responseFonctionnelle != null) && (responseFonctionnelle.getResultsCount() > 0))
    {
      for (AnnonceAccueilPfs annonceAccueilPfs : responseFonctionnelle.getItems())
      {
        AnnoncesAccueil annoncesAccueilObject = new AnnoncesAccueil();
        annoncesAccueilObject.setIdMessagerie(bl001Retour_p.getIdMessagerie());
        String idAnnonce = noContrat + "#" + typePfs + "#" + idMessageriePfs + "#" + annonceAccueilPfs.getTypeAnnonce(); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        String encryptedIdAnnonce = PasswordEncrypter.encryptForURL(idAnnonce);
        annoncesAccueilObject.setIdAnnonce(encryptedIdAnnonce);
        annoncesAccueilObject.setStatutAnnonce(annonceAccueilPfs.getStatutAnnonce());
        annoncesAccueilObject.setTypeAnnonce(annonceAccueilPfs.getTypeAnnonce());

        if (IMetadata.CANAL_B2R.equalsIgnoreCase(_processContext.getModeAppel()))
        {
          // Build ModifierAnnonceAccueil
          annoncesAccueilObject.putAction("modifierAnnonceAccueil", new XAction(URL_ANNONCE_ACCUEIL + encryptedIdAnnonce, MediaType.MULTIPART_FORM_DATA, HttpConstants.PUT_METHOD)); //$NON-NLS-1$

          // Build TelechargerAnnonceAccueil
          annoncesAccueilObject.putLink("telechargerAnnonceAccueil", new XLink(URL_ANNONCE_ACCUEIL + encryptedIdAnnonce + "/contenu")); //$NON-NLS-1$
        }
        annoncesAccueilList.add(annoncesAccueilObject);

      }
      reponse.setResultsCount(responseFonctionnelle.getResultsCount());
      reponse.setItems(annoncesAccueilList);

      // Build SelfXlink
      if (IMetadata.CANAL_B2R.equalsIgnoreCase(_processContext.getModeAppel()))
      {
        XLink self = new XLink();
        self.setHref(URL_ANNONCE_ACCUEIL + bl001Retour_p.getIdMessagerie() + "/annonces-accueil?format=metadata"); //$NON-NLS-1$
        reponse.putLink(XLink.SELF, self);
      }

    }
    return new Pair<>(retour, reponse);
  }

  /**
   * PE0276_BL100_ModifierAnnonce
   *
   * @param tracabilite_p
   *          tracabilite
   * @param bl001PutRetour_p
   *          PE0276_BL001PutRetour
   * @return Retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PE0276_BL100_ModifierAnnonce(Tracabilite tracabilite_p, PE0276_BL001PutRetour bl001PutRetour_p) throws RavelException
  {
    String idAnnonceDecrypted, noContrat, idMessageriePfs, typeAnnonce, typePfs;

    // Decrypt the idMesssagerie
    try
    {
      idAnnonceDecrypted = PasswordDecrypter.decryptForURL(bl001PutRetour_p.getIdAnnonce());
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, "Error decrypting idOption", exception)); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_ANNONCE_INCONNU, MessageFormat.format(MESSAGE_ID_ANNNONCE_INCONNU, bl001PutRetour_p.getIdAnnonce()));
    }
    // Get the parameters type and noTelephone
    String[] parametresAnnonce = idAnnonceDecrypted.split("#"); //$NON-NLS-1$
    if (parametresAnnonce.length == 4)
    {
      noContrat = parametresAnnonce[0];
      typePfs = parametresAnnonce[1];
      idMessageriePfs = parametresAnnonce[2];
      typeAnnonce = parametresAnnonce[3];
    }
    else
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_ANNNONCE_INCONNU, bl001PutRetour_p.getIdAnnonce()));
    }

    //Contrôler que l’opération demande est autorisée pour le type d’annonce
    if (TYPE_ANNONCE_PERSONNALISEE.equals(typeAnnonce))
    {
      if (!_processContext.getConfigurationPE0276().getListeOperationPersonnaliseeAutorisee().contains(bl001PutRetour_p.getTypeOperation().getValue()))
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_BL200, bl001PutRetour_p.getIdAnnonce(), typeAnnonce));
      }
    }
    else
    {
      if (!_processContext.getConfigurationPE0276().getListeOperationDefautAutorisee().contains(bl001PutRetour_p.getTypeOperation().getValue()))
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_BL200, bl001PutRetour_p.getIdAnnonce(), typeAnnonce));
      }
    }

    //Authorization control of contract number
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001PutRetour_p.getModeAppel()))
    {
      if (CollectionUtils.isEmpty(bl001PutRetour_p.getListeContratOauth()) //
          || StringTools.isNullOrEmpty(noContrat) //
          || bl001PutRetour_p.getListeContratOauth().stream().noneMatch(c -> c.equals(noContrat)))
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "Acces refuse"); //$NON-NLS-1$
      }
    }

    if (STW.equals(typePfs))
    {
      if ((MODIFIER_CONTENU_ANNONCE == bl001PutRetour_p.getTypeOperation()) //
          || (MODIFIER_ANNONCE == bl001PutRetour_p.getTypeOperation()))
      {
        // Call VMSSTW_SI029_ModifierContenuMediaAnnonceAccueil
        VMSSTW_SI029_ModifierContenuMediaAnnonceAccueil si029 = new VMSSTW_SI029_ModifierContenuMediaAnnonceAccueilBuilder() //
            .tracabilite(tracabilite_p) //
            .idMessageriePfs(idMessageriePfs) //
            .typeAnnonceAccueil(typeAnnonce) //
            .contenuMedia(bl001PutRetour_p.getContenuMedia()) //
            .build();
        si029.execute(this);
        Retour retour = si029.getRetour();
        if (!isRetourOK(retour))
        {
          return retour;
        }
      }

      if ((MODIFIER_ANNONCE == bl001PutRetour_p.getTypeOperation()) //
          || (MODIFIER_STATUT_ANNONCE == bl001PutRetour_p.getTypeOperation()))
      {
        //Call KPSA
        ListeParametre listparametre = new ListeParametre();
        listparametre.add(KPSA_PARAM_ID_MESSAGERIE_PFS, idMessageriePfs);
        listparametre.add(KPSA_PARAM_TYPE_PFS, typePfs);
        listparametre.add(KPSA_PARAM_TYPE_ANNONCE, typeAnnonce);
        listparametre.add(KPSA_PARAM_STATUT_ANNONCE, bl001PutRetour_p.getStatutAnnonce());

        PROV_SI002_ExecuterProcessus si002 = new PROV_SI002_ExecuterProcessusBuilder().tracabilite(tracabilite_p).cles(Collections.emptyList()) //
            .priorite(10) //
            .processus(KPSA_MODIFIER_STATUT_ANNONCE_ACCUEIL_PFS) //
            .listeParametres(listparametre).build();
        si002.execute(this);
        Retour retourProv = si002.getRetour();

        if (!isRetourOK(retourProv))
        {
          switch (retourProv.getCategorie())
          {
            case IMegConsts.CAT1:
              return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE);
            case IMegConsts.CAT2:
              return RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPONIBLE);
            default:
              return retourProv;
          }
        }
      }
    } // VMS CVG
    else
    {
      // Call VMSCVM_SI034_PersonnaliserAnnonceAccueil
      Annonce annonce = new Annonce(typeAnnonce, bl001PutRetour_p.getStatutAnnonce());
      annonce.setContenuMedia(new BinaryContentWrapper(bl001PutRetour_p.getContenuMedia()));
      VMSCVM_SI034_PersonnaliserAnnonceAccueil si034 = new VMSCVM_SI034_PersonnaliserAnnonceAccueilBuilder() //
          .tracabilite(tracabilite_p) //
          .idMessageriePfs(idMessageriePfs) //
          .annonce(annonce) //
          .build();
      si034.execute(this);
      Retour retour = si034.getRetour();
      if (!isRetourOK(retour))
      {
        return retour;
      }
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @param bl001_p
   *          tracabilite
   * @return Retour
   */
  @LogProcessBL
  private Pair<Retour, byte[]> PE0276_BL200_TelechargerAnnonce(Tracabilite tracabilite_p, PE0276_BL001GetRetour bl001_p) throws RavelException
  {
    String idAnnonceDecrypted, noContrat, idMessageriePfs, typeAnnonce, typePfs;

    // Decrypt the idMesssagerie
    try
    {
      idAnnonceDecrypted = PasswordDecrypter.decryptForURL(bl001_p.getIdAnnonce());
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, "Error decrypting idOption", exception)); //$NON-NLS-1$
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_ANNONCE_INCONNU, MessageFormat.format(MESSAGE_ID_ANNNONCE_INCONNU, bl001_p.getIdAnnonce())), null);
    }
    // Get the parameters type and noTelephone
    String[] parametresMessageriel = idAnnonceDecrypted.split("#"); //$NON-NLS-1$
    if (parametresMessageriel.length == 4)
    {
      noContrat = parametresMessageriel[0];
      typePfs = parametresMessageriel[1];
      idMessageriePfs = parametresMessageriel[2];
      typeAnnonce = parametresMessageriel[3];
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_ANNONCE_INCONNU, MessageFormat.format(MESSAGE_ID_ANNNONCE_INCONNU, bl001_p.getIdAnnonce())), null);
    }

    //Contrôler que l’opération demande est autorisée pour le type d’annonce
    switch (typeAnnonce)
    {
      case TYPE_ANNONCE_DEFAUT:
        if (!_processContext.getConfigurationPE0276().getListeOperationDefautAutorisee().contains(bl001_p.getTypeOperation().getValue()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_BL200, bl001_p.getIdAnnonce(), typeAnnonce)), null);
        }
        break;
      case TYPE_ANNONCE_PERSONNALISEE:
        if (!_processContext.getConfigurationPE0276().getListeOperationPersonnaliseeAutorisee().contains(bl001_p.getTypeOperation().getValue()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_BL200, bl001_p.getIdAnnonce(), typeAnnonce)), null);
        }
        break;
      default:
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_BL200, bl001_p.getIdAnnonce(), typeAnnonce)), null);
    }

    //Authorization control of contract number
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001_p.getModeAppel()))
    {
      if (CollectionUtils.isEmpty(bl001_p.getListeContratOauth()) //
          || StringTools.isNullOrEmpty(noContrat) //
          || bl001_p.getListeContratOauth().stream().noneMatch(c -> c.equals(noContrat)))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "Acces refuse"), null); //$NON-NLS-1$
      }
    }

    byte[] contenuMediaRetour = null;
    Retour retour = null;

    if (STW.equals(typePfs))
    {
      // Call VMSSTW_SI031_telechargerAnnonceAccueil
      VMSSTW_SI031_TelechargerAnnonceAccueil si031 = new VMSSTW_SI031_TelechargerAnnonceAccueilBuilder() //
          .tracabilite(tracabilite_p) //
          .idMessageriePfs(idMessageriePfs) //
          .typeAnnonce(TYPE_ANNONCE_PERSONNALISEE) //
          .build();
      contenuMediaRetour = si031.execute(this);
      retour = si031.getRetour();
    }
    else if (CVG.equals(typePfs))
    {
      // Call VMSSTW_SI031_telechargerAnnonceAccueil
      VMSCVM_SI015_TelechargerAnnonceAccueil si015 = new VMSCVM_SI015_TelechargerAnnonceAccueilBuilder() //
          .tracabilite(tracabilite_p) //
          .idMessageriePfs(idMessageriePfs) //
          .typeAnnonce(TYPE_ANNONCE_PERSONNALISEE) //
          .build();
      contenuMediaRetour = si015.execute(this);
      retour = si015.getRetour();
    }

    return new Pair<>(retour, contenuMediaRetour);
  }
}
