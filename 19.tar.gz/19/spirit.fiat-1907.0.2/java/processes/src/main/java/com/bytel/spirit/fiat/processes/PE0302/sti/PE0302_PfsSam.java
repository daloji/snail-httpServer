/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302.sti;

import java.util.ArrayList;
import java.util.List;

import com.squareup.moshi.Json;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0302_PfsSam extends PE0302_PFS
{

  /**
   *
   */
  private static final long serialVersionUID = 3222425186816081829L;

  /**
   * typeUsages
   */
  @Json(name = "typeUsages")
  private List<String> _typeUsages;

  /**
   * voix
   */
  @Json(name = "voix")
  private PE0302_VoixPFS _voix;

  /**
   * fax
   */
  @Json(name = "fax")
  private PE0302_FaxPFS _fax;

  /**
   * @param noTelephone_p
   */
  public PE0302_PfsSam(String noTelephone_p)
  {
    super(typePfs.SAM.name(), noTelephone_p);

  }

  /**
   * @return the fax
   */
  public PE0302_FaxPFS getFax()
  {
    return _fax;
  }

  /**
   * @return the typeUsages
   */
  public List<String> getTypeUsages()
  {
    return _typeUsages != null ? new ArrayList<>(_typeUsages) : new ArrayList<>();
  }

  /**
   * @return the voix
   */
  public PE0302_VoixPFS getVoix()
  {
    return _voix;
  }

  /**
   * @param fax_p
   *          the fax to set
   */
  public void setFax(PE0302_FaxPFS fax_p)
  {
    _fax = fax_p;
  }

  /**
   * @param typeUsages_p
   *          the typeUsages to set
   */
  public void setTypeUsages(List<String> typeUsages_p)
  {
    _typeUsages = new ArrayList<>(typeUsages_p);
  }

  /**
   * @param voix_p
   *          the voix to set
   */
  public void setVoix(PE0302_VoixPFS voix_p)
  {
    _voix = voix_p;
  }

}
