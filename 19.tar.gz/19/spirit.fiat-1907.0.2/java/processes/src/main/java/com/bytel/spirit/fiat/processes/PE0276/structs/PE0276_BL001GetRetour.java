/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0276.structs;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PE0276_BL001GetRetour
{
  /**
   * ID of the mailbox
   */
  private String _idMessagerie;

  /**
   * ID Announce
   */
  private String _idAnnonce;

  /**
   * Type operation
   */
  private OperationAnnonceAccueil _typeOperation;

  /**
   * mode appel
   */
  private String _modeAppel;

  /**
   * List contracts auth
   */
  private List<String> _listeContratOauth;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0276_BL001GetRetour other = (PE0276_BL001GetRetour) obj;
    if (_idAnnonce == null)
    {
      if (other._idAnnonce != null)
      {
        return false;
      }
    }
    else if (!_idAnnonce.equals(other._idAnnonce))
    {
      return false;
    }
    if (_idMessagerie == null)
    {
      if (other._idMessagerie != null)
      {
        return false;
      }
    }
    else if (!_idMessagerie.equals(other._idMessagerie))
    {
      return false;
    }
    if (_listeContratOauth == null)
    {
      if (other._listeContratOauth != null)
      {
        return false;
      }
    }
    else if (!_listeContratOauth.equals(other._listeContratOauth))
    {
      return false;
    }
    if (_modeAppel == null)
    {
      if (other._modeAppel != null)
      {
        return false;
      }
    }
    else if (!_modeAppel.equals(other._modeAppel))
    {
      return false;
    }
    if (_typeOperation == null)
    {
      if (other._typeOperation != null)
      {
        return false;
      }
    }
    else if (!_typeOperation.equals(other._typeOperation))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the idAnnonce
   */
  public String getIdAnnonce()
  {
    return _idAnnonce;
  }

  /**
   * @return the idMessagerie
   */
  public String getIdMessagerie()
  {
    return _idMessagerie;
  }

  /**
   * @return the listeContratOauth
   */
  public List<String> getListeContratOauth()
  {
    return _listeContratOauth != null ? new ArrayList<>(_listeContratOauth) : new ArrayList<>();
  }

  /**
   * @return the modeAppel
   */
  public String getModeAppel()
  {
    return _modeAppel;
  }

  /**
   * @return the typeOperation
   */
  public OperationAnnonceAccueil getTypeOperation()
  {
    return _typeOperation;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_idAnnonce == null) ? 0 : _idAnnonce.hashCode());
    result = (prime * result) + ((_idMessagerie == null) ? 0 : _idMessagerie.hashCode());
    result = (prime * result) + ((_listeContratOauth == null) ? 0 : _listeContratOauth.hashCode());
    result = (prime * result) + ((_modeAppel == null) ? 0 : _modeAppel.hashCode());
    result = (prime * result) + ((_typeOperation == null) ? 0 : _typeOperation.hashCode());
    return result;
  }

  /**
   * @param idAnnonce_p
   *          the idAnnonce to set
   */
  public void setIdAnnonce(String idAnnonce_p)
  {
    _idAnnonce = idAnnonce_p;
  }

  /**
   * @param idMessagerie_p
   *          the idMessagerie to set
   */
  public void setIdMessagerie(String idMessagerie_p)
  {
    _idMessagerie = idMessagerie_p;
  }

  /**
   * @param listeContratOauth_p
   *          the listeContratOauth to set
   */
  public void setListeContratOauth(List<String> listeContratOauth_p)
  {
    _listeContratOauth = new ArrayList<>(listeContratOauth_p);
  }

  /**
   * @param modeAppel_p
   *          the modeAppel to set
   */
  public void setModeAppel(String modeAppel_p)
  {
    _modeAppel = modeAppel_p;
  }

  /**
   * @param typeOperation_p
   *          the typeOperation to set
   */
  public void setTypeOperation(OperationAnnonceAccueil typeOperation_p)
  {
    _typeOperation = typeOperation_p;
  }

  @Override
  public String toString()
  {
    return "PE0276_BL001GetRetour [_idMessagerie=" + _idMessagerie + ", _idAnnonce=" + _idAnnonce + ", _typeOperation=" + _typeOperation + ", _modeAppel=" + _modeAppel + ", _listeContratOauth=" + _listeContratOauth + "]";
  }

}
