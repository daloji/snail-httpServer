/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0277;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.oi.OI_SI003_PBO;
import com.bytel.spirit.common.activities.oi.OI_SI003_PBO.OI_SI003_PBOBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.PBOs;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0277.structs.PE0277_BL001_VerifierDonneesPboReturn;
import com.bytel.spirit.fiat.processes.PE0277.structs.PE0277_Retour;
import com.bytel.spirit.fiat.shared.types.json.PBO;

/**
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
public class PE0277_RessourcePBO extends SpiritRestApiProcessSkeleton
{

  /**
   *
   * @author rrosa
   * @version ($Revision$ $Date$)
   */
  public interface IRequestParameters
  {
    /**
    *
    */
    public static final String OI = "OI"; //$NON-NLS-1$
    /**
    *
    */
    public static final String REF_PRESTATION_PRISE = "refPrestationPrise"; //$NON-NLS-1$

  }

  /**
   * Process context
   *
   * @author rrosa
   * @version ($Revision$ $Date$)
   */
  public static final class PE0277_RessourcesEmutationContext extends Context
  {
    /**
     * The generated UID
     */
    private static final long serialVersionUID = 4076872994425840958L;

    /***
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0277_BL001;

    /**
     * The source from header
     */
    private String _xSource;

    /**
     * The process from header
     */
    private String _xProcess;

    /**
     * The requestId from header
     */
    private String _xRequestId;

    /**
     *
     */
    private String _oi;

    /**
     *
     */
    private String _refPrestationPrise;

    /**
     * @return the oi
     */
    public String getOi()
    {
      return _oi;
    }

    /**
     * @return the refPrestationPrise
     */
    public String getRefPrestationPrise()
    {
      return _refPrestationPrise;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the xProcess
     */
    public String getxProcess()
    {
      return _xProcess;
    }

    /**
     * @return the xRequestId
     */
    public String getxRequestId()
    {
      return _xRequestId;
    }

    /**
     * @return the xSource
     */
    public String getxSource()
    {
      return _xSource;
    }

    /**
     * @param oi_p
     *          the oi to set
     */
    public void setOi(String oi_p)
    {
      _oi = oi_p;
    }

    /**
     * @param refPrestationPrise_p
     *          the refPrestationPrise to set
     */
    public void setRefPrestationPrise(String refPrestationPrise_p)
    {
      _refPrestationPrise = refPrestationPrise_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param xProcess_p
     *          the xProcess to set
     */
    public void setxProcess(String xProcess_p)
    {
      _xProcess = xProcess_p;
    }

    /**
     * @param xRequestId_p
     *          the xRequestId to set
     */
    public void setxRequestId(String xRequestId_p)
    {
      _xRequestId = xRequestId_p;
    }

    /**
     * @param xSource_p
     *          the xSource to set
     */
    public void setxSource(String xSource_p)
    {
      _xSource = xSource_p;
    }

  }

  /**
   * The Enum containing all process states
   *
   * @author rrosa
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * Verifier_Donnes
     */
    PE0277_BL001(MandatoryProcessState.PRC_START, false, false),
    /**
     * Formater_Reponse
     */
    PE0277_BL002(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * OI_SI003_PBO
     */
    PE0277_OS_SI003_PBO(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = -1895410773971080468L;

  /**
   * Constant for invalid headers message
   */
  private static final String INVALID_HEADERS_MESSAGE = Messages.getString("PE0277.BL001.HeaderNullOrEmpty"); //$NON-NLS-1$

  /**
  *
  */
  private static final String INVALID_PARAMETERS_MESSAGE = Messages.getString("PE0277.BL001.ParametersNullOrEmpty"); //$NON-NLS-1$

  /**
  *
  */
  private static final String REF_PRESTATION_PRISE_INCONNUE = Messages.getString("PE0277.RefPrestationPriseInconnue"); //$NON-NLS-1$

  /**
   * The process context.
   */
  private PE0277_RessourcesEmutationContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return ""; //$NON-NLS-1$
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0277_RessourcesEmutationContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel

  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = null;
    PBOs listePbo = null;
    try
    {
      PE0277_BL001_VerifierDonneesPboReturn bl001Return = PE0277_BL001_VerifierDonnesPbo(tracabilite_p, request_p);
      retour = bl001Return.getRetour();
      if (isRetourOK(retour))
      {
        OI_SI003_PBO si003PboResult = new OI_SI003_PBOBuilder().tracabilite(tracabilite_p).codeOi(bl001Return.getOi()).refPrestationprise(bl001Return.getRefPrestationPrise()).build();
        listePbo = si003PboResult.execute(this);
        retour = si003PboResult.getRetour();
      }
    }
    catch (Exception ex)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex.getMessage());
    }
    finally
    {
      //Call BL002
      _processContext.setState(State.PE0277_BL002);
      Pair<ReponseErreur, PE0277_Retour> pe0277Retour = PE0277_BL002_FormaterReponsePbo(retour, listePbo);
      this.setRetour(retour);
      _processContext.setState(State.ENDED);
      syncResponse(tracabilite_p, request_p, pe0277Retour._first, pe0277Retour._second);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel

  }

  /**
   * Gets the URL parameters into the ProcessContext
   *
   * @param tracabilite_p
   *          tracabilite
   * @param parametersMap_p
   *          parameters
   *
   * @param request_p
   *          request
   * @return Object STI
   */
  private Retour checkIRequestParameters(Tracabilite tracabilite_p, final Map<String, String> parametersMap_p, final Request request_p)
  {
    //fill the values of the required parameters, from the request object
    fillParametersMapFromRequest(parametersMap_p, request_p);

    Iterator<String> parametersIterator = parametersMap_p.keySet().iterator();
    //check if the values of the required parameters are set, if not return with NOK immediately
    while (parametersIterator.hasNext())
    {
      String parameterName = parametersIterator.next();
      if (StringTools.isNullOrEmpty(parametersMap_p.get(parameterName)))
      {
        String libelleErreur = MessageFormat.format(INVALID_PARAMETERS_MESSAGE, parameterName);
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
      }
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Validates that each key in headersMap_p has a value in the request_p parameter, and if yes set the corresponding
   * value.
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param headersMap_p
   *          Map containing the header names as keys.
   * @param request_p
   *          The request The original request containing all headers
   *
   * @return Retour OK if all the headers in the headersMap_p are set, NOK otherwise
   */
  private Retour checkRequestHeaders(Tracabilite tracabilite_p, Map<String, String> headersMap_p, final Request request_p)
  {

    //fill the values of the required headers, from the request object
    fillHeaderMapFromRequest(headersMap_p, request_p);

    Iterator<String> headersIterator = headersMap_p.keySet().iterator();
    //check if the values of the required headers are set, if not return with NOK immediately
    while (headersIterator.hasNext())
    {
      String headerName = headersIterator.next();
      if (StringTools.isNullOrEmpty(headersMap_p.get(headerName)))
      {
        String libelleErreur = MessageFormat.format(INVALID_HEADERS_MESSAGE, headerName);
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
      }
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Fill the values in the headersMap_p parameters, using the headers in the request_p paramter.
   *
   * @param headersMap_p
   *          The map containing the headers to fill
   * @param request_p
   *          The request objetct containing all the headers
   */
  private void fillHeaderMapFromRequest(final Map<String, String> headersMap_p, final Request request_p)
  {
    if ((headersMap_p != null) && !headersMap_p.keySet().isEmpty())
    {
      for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
      {
        if (headersMap_p.containsKey(header.getName()))
        {
          headersMap_p.put(header.getName(), header.getValue()); //fill value for the specified header
        }
      }
    }
  }

  /**
   * @param parametersMap_p
   *          parameters
   * @param request_p
   *          request
   */
  private void fillParametersMapFromRequest(Map<String, String> parametersMap_p, Request request_p)
  {
    if ((parametersMap_p != null) && !parametersMap_p.keySet().isEmpty())
    {
      List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();
      for (Parameter parametre : urlParametersType)
      {
        if (parametersMap_p.containsKey(parametre.getName()))
        {
          parametersMap_p.put(parametre.getName(), parametre.getValue()); //fill value for the specified parameter
        }
      }
    }
  }

  /**
   * Validates Json object received in the request parameter.
   *
   * @param request_p
   *          The request
   * @param tracabilite_p
   *          Tracabilite
   * @return PE0277_BL001_VerifierDonneesPboReturn
   * @throws RavelException
   *           In case of error
   */
  @LogProcessBL
  private PE0277_BL001_VerifierDonneesPboReturn PE0277_BL001_VerifierDonnesPbo(Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    PE0277_BL001_VerifierDonneesPboReturn bl001Return = new PE0277_BL001_VerifierDonneesPboReturn(retour);

    //create a map to store all required headers names to validate, ignoring case of the header name
    Map<String, String> headersMap = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    headersMap.put(IHttpHeadersConsts.X_SOURCE, null);
    headersMap.put(IHttpHeadersConsts.X_PROCESS, null);
    headersMap.put(IHttpHeadersConsts.X_REQUEST_ID, null);

    retour = checkRequestHeaders(tracabilite_p, headersMap, request_p);
    if (isRetourOK(retour))
    {
      Map<String, String> parametersMap = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
      parametersMap.put(IRequestParameters.OI, null);
      parametersMap.put(IRequestParameters.REF_PRESTATION_PRISE, null);

      retour = checkIRequestParameters(tracabilite_p, parametersMap, request_p);
      if (isRetourOK(retour))
      {
        bl001Return.setOi(parametersMap.get(IRequestParameters.OI));
        bl001Return.setRefPrestationPrise(parametersMap.get(IRequestParameters.REF_PRESTATION_PRISE));
        _processContext.setOi(bl001Return.getOi());
        _processContext.setRefPrestationPrise(bl001Return.getRefPrestationPrise());
      }
    }
    bl001Return.setRetour(retour);
    return bl001Return;
  }

  /**
   * Format response to the client
   *
   * @param inRetour_p
   *          Result of bl001.
   * @param listePbo_p
   *          the listePbo
   *
   * @return {@link ReponseErreur}
   */
  @LogProcessBL
  private Pair<ReponseErreur, PE0277_Retour> PE0277_BL002_FormaterReponsePbo(Retour inRetour_p, PBOs listePbo_p)
  {
    ReponseErreur responseErreur = null;
    PE0277_Retour pe0277Retour = new PE0277_Retour();

    List<PBO> listePbo;

    if (isRetourOK(inRetour_p))
    {
      if ((listePbo_p != null) && (listePbo_p.getPbos() != null) && !listePbo_p.getPbos().isEmpty())
      {
        listePbo = new ArrayList<>();
        for (com.bytel.spirit.common.connector.oi.emutation.structs.PBO pbo : listePbo_p.getPbos())
        {
          listePbo.add(new PBO(pbo));
        }
        pe0277Retour.setItems(listePbo);
      }
    }
    else
    {
      responseErreur = new ReponseErreur();
      responseErreur.setError(inRetour_p.getDiagnostic());
      responseErreur.setErrorDescription(inRetour_p.getLibelle());
    }

    return new Pair<>(responseErreur, pe0277Retour);
  }

  /**
   * Send sync response for requester.
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param request_p
   *          The request object
   * @param reponserreur_p
   *          the reponserreur
   * @param pe0277_retour_p
   *          the pe0277_retour
   */
  private void syncResponse(Tracabilite tracabilite_p, Request request_p, ReponseErreur reponserreur_p, PE0277_Retour pe0277_retour_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp = null;

      if (reponserreur_p != null)
      {
        ReponseErreur reponserreur = reponserreur_p;
        ErrorCode errorCode = ErrorCode.KO_00500; //Unknown error

        if (IMegSpiritConsts.NON_RESPECT_STI.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00400;
        }
        else if (IMegSpiritConsts.PRESTATION_PRISE_INCONNUE.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00404;
          String libelleErreur = MessageFormat.format(REF_PRESTATION_PRISE_INCONNUE, _processContext.getRefPrestationPrise());
          reponserreur.setErrorDescription(libelleErreur);
        }
        else if (IMegSpiritConsts.ECHEC_PARTENAIRE.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00404;
        }
        else if (IMegConsts.SERVICE_TIERS_INDISPONIBLE.equals(reponserreur_p.getError()) || IMegSpiritConsts.FLUX_BIENTOT_DISPONIBLE.equals(reponserreur_p.getError()) || IMegSpiritConsts.FLUX_INDISPONIBLE.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00503;
        }

        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(GsonTools.getIso8601Ms().toJson(reponserreur));

        rsp = new Response(errorCode, ravelResponse);
      }
      else
      {
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0277_retour_p));
        rsp = new Response(ErrorCode.OK_00200, ravelResponse);
      }

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PE0277 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);

    }
  }
}
