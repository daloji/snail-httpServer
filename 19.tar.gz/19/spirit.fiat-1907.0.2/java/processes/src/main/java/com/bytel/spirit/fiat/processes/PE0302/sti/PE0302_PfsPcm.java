/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302.sti;

import com.squareup.moshi.Json;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0302_PfsPcm extends PE0302_PFS
{

  /**
   *
   */
  private static final long serialVersionUID = 9129044162252026220L;

  /**
   * nom
   */
  @Json(name = "nom")
  private String _nom;

  /**
   * prenom
   */
  @Json(name = "prenom")
  private String _prenom;

  /**
   * The ligneEnCommunication
   */
  @Json(name = "ligneEnCommunication")
  private String _ligneEnCommunication;

  /**
   * @param noTelephone_p
   */
  public PE0302_PfsPcm(String noTelephone_p)
  {
    super(typePfs.PCM.name(), noTelephone_p);
  }

  /**
   * @return the ligneEnCommunication
   */
  public String getLigneEnCommunication()
  {
    return _ligneEnCommunication;
  }

  /**
   * @return the nom
   */
  public String getNom()
  {
    return _nom;
  }

  /**
   * @return the prenom
   */
  public String getPrenom()
  {
    return _prenom;
  }

  /**
   * @param ligneEnCommunication_p
   *          the ligneEnCommunication to set
   */
  public void setLigneEnCommunication(String ligneEnCommunication_p)
  {
    _ligneEnCommunication = ligneEnCommunication_p;
  }

  /**
   * @param nom_p
   *          the nom to set
   */
  public void setNom(String nom_p)
  {
    _nom = nom_p;
  }

  /**
   * @param prenom_p
   *          the prenom to set
   */
  public void setPrenom(String prenom_p)
  {
    _prenom = prenom_p;
  }

}
