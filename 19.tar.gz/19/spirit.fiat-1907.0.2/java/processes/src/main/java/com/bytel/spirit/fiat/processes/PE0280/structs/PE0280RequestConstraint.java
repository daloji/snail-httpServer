/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0280.structs;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
@Documented
@Target({ TYPE })
@Retention(RUNTIME)
@Constraint(validatedBy = { PE0280RequestConstraintValidator.class })
public @interface PE0280RequestConstraint
{
  /**
   * Allows the specification of validation groups, to which this constraint belongs.
   *
   * @return Validation groups
   */
  Class<?>[] groups() default {};

  /**
   * The message to return when the instance of "Raccordement" fails the validation.
   *
   * @return Error message
   */
  String message() default IValidationConst.ATTRIBUT_COND_MANQUANT;

  /**
   * Assign custom payload objects to a constraint.
   *
   * @return Custom payload
   */
  Class<? extends Payload>[] payload() default {};

}
