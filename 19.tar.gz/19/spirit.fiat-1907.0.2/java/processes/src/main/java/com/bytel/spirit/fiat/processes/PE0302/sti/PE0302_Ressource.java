/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0302_Ressource implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -6666581516917649360L;

  /**
   * typeRessource
   */
  @Json(name = "typeRessource")
  private String _type;
  /**
   * etatRessource
   */
  @Json(name = "etatRessource")
  private String _etatRessource;
  /**
   * etatAllocation
   */
  @Json(name = "etatAllocation")
  private String _etatAllocation;

  /**
   * @return the etatAllocation
   */
  public String getEtatAllocation()
  {
    return _etatAllocation;
  }

  /**
   * @return the etatRessource
   */
  public String getEtatRessource()
  {
    return _etatRessource;
  }

  /**
   * @return the type
   */
  public String getType()
  {
    return _type;
  }

  /**
   * @param etatAllocation_p
   *          the etatAllocation to set
   */
  public void setEtatAllocation(String etatAllocation_p)
  {
    _etatAllocation = etatAllocation_p;
  }

  /**
   * @param etatRessource_p
   *          the etatRessource to set
   */
  public void setEtatRessource(String etatRessource_p)
  {
    _etatRessource = etatRessource_p;
  }

  /**
   * @param type_p
   *          the type to set
   */
  public void setType(String type_p)
  {
    _type = type_p;
  }

}
