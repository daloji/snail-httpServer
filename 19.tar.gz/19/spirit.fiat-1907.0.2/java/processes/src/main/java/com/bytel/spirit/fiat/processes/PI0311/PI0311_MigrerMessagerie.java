/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PI0311;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.connector.tools.MSISDNTools;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL3400_SupprimerFichier;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI034_PersonnaliserAnnonceAccueil;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI034_PersonnaliserAnnonceAccueil.VMSCVM_SI034_PersonnaliserAnnonceAccueilBuilder;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI101_ImporterMessage;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI101_ImporterMessage.VMSCVM_SI101_ImporterMessageBuilder;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI101_ExporterMessages;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI101_ExporterMessages.VMSSTW_SI101_ExporterMessagesBuilder;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI102_ExporterAnnonces;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI102_ExporterAnnonces.VMSSTW_SI102_ExporterAnnoncesBuilder;
import com.bytel.spirit.common.connectors.streamwide.StreamWideProxy;
import com.bytel.spirit.common.shared.functional.types.Annonce;
import com.bytel.spirit.common.shared.functional.types.Message;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Nothing;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.types.BinaryContentWrapper;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PI0311.structs.PI0311_BL001Return;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PI0311_MigrerMessagerie extends SpiritRestApiProcessSkeleton
{
  /**
   *
   * @author mbaptist
   * @version ($Revision$ $Date$)
   */
  public static final class PI0311_MigrerMessagerieContext extends Context
  {
    /**
     *
     */
    private static final long serialVersionUID = -8032271440200659761L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PI0311_START;

    /**
     * IdRequest
     */
    private String _idRequest;

    /**
     * IdVmsStw
     */
    private String _idVmsStw;

    /**
     * Numero Telephone
     */
    private String _noTelephone;

    /**
     * @return the idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the _idVmsStw
     */
    public String getIdVmsStw()
    {
      return _idVmsStw;
    }

    /**
     * @return the _noTelephone
     */
    public String getNoTelephone()
    {
      return _noTelephone;
    }

    /**
     * @return the _state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param idRequest_p
     *          the idRequest to set
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param idVmsStw_p
     *          the _idVmsStw to set
     */
    public void setIdVmsStw(String idVmsStw_p)
    {
      this._idVmsStw = idVmsStw_p;
    }

    /**
     * @param noTelephone_p
     *          the _noTelephone to set
     */
    public void setNoTelephone(String noTelephone_p)
    {
      this._noTelephone = noTelephone_p;
    }

    /**
     * @param state_p
     *          the _state to set
     */
    public void setState(State state_p)
    {
      this._state = state_p;
    }
  }

  /**
   *
   * @author mbaptist
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PI0311_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call BL001
     */
    PI0311_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call VMSSTW_SI101
     */
    VMSSTW_SI101(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL100
     */
    PI0311_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call VMSCVM_SI101
     */
    VMSCVM_SI101(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call VMSSTW_SI102
     */
    VMSSTW_SI102(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PI0311_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call VMSCVM_SI034
     */
    VMSCVM_SI034(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL002
     */
    PI0311_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PI0311_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   *
   * @author mbaptist
   * @version ($Revision$ $Date$)
   */
  protected enum MetadataParameters
  {
    /**
     * idVmsStw
     */
    ID_VMS_STW,
    /**
     * noTelephone
     */
    NO_TELEPHONE;

  }

  /**
   *
   */
  private static final long serialVersionUID = 7582159597355847055L;

  /**
   * Constant for parameter name idVmsStw
   */
  private static final String ID_VMS_STW_PARAM_NAME = "idVmsStw"; //$NON-NLS-1$
  /**
   * Constant for parameter name noTelephone
   */
  private static final String NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   * Temp folder to store message/annonce files.
   */
  private static final String TEMP_FOLFER = "/tmp/"; //$NON-NLS-1$
  /**
   * The process context.
   */
  private PI0311_MigrerMessagerieContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour arg0_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();

  }

  /**
   * @param retour_p
   * @return
   */
  public com.bytel.ravel.types.Retour getRetourJSON(Retour retour_p)
  {
    com.bytel.ravel.types.Retour jsonRetour = new com.bytel.ravel.types.Retour();
    jsonRetour.setResultat(retour_p.getResultat());
    jsonRetour.setCategorie(retour_p.getCategorie());
    jsonRetour.setDiagnostic(retour_p.getDiagnostic());
    jsonRetour.setLibelle(retour_p.getLibelle());

    return jsonRetour;
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PI0311_MigrerMessagerieContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    // Not required for now in Ravel
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel

  }

  /**
   * Handle all POST treatment
   */
  @Override
  @LogStartProcess
  protected void startPostProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    PI0311_BL001Return bl001Return = new PI0311_BL001Return(RetourFactory.createOkRetour());

    try
    {
      _processContext.setState(State.PI0311_BL001);
      bl001Return = PI0311_BL001_VerifierDonnees(tracabilite_p, request_p);
      retour = bl001Return.getRetour();

      if (isRetourOK(retour))
      {

        /**
         * Export all messages associated with noTelephone from the VMS StreamWide plateform
         */
        _processContext.setState(State.VMSSTW_SI101);
        VMSSTW_SI101_ExporterMessages vmsStwSi101 = new VMSSTW_SI101_ExporterMessagesBuilder()//
            .tracabilite(tracabilite_p)//
            .tempFolder(TEMP_FOLFER)//
            .idVmsStw(_processContext.getIdVmsStw())//
            .noTelephone(_processContext.getNoTelephone())//
            .build();
        List<Message> messages = vmsStwSi101.execute(this);
        retour = vmsStwSi101.getRetour();

        if (isRetourOK(retour))
        {
          /**
           * Implements PI0311_BL100_BoucleImportMessages
           *
           * Import all the messages exported from StreamWide into the VMS Convergys platform If no messages to import
           * continues OK
           */
          for (Message message : messages)
          {
            _processContext.setState(State.PI0311_BL100); // PI0311_BL100 implemented in the for cycle
            _processContext.setState(State.VMSCVM_SI101);
            try
            {
              if (message.getFileName() == null)
              {
                retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Messages.getString("PI0311.NomFichierVide")); //$NON-NLS-1$
                return;
              }
              //load the contenuMedia from the corresponding file
              message.setContenuMedia(importMediaContentFromFile(message.getFileName()));

              VMSCVM_SI101_ImporterMessage vmsCvmSi101 = new VMSCVM_SI101_ImporterMessageBuilder()//
                  .tracabilite(tracabilite_p)//
                  .idMessageriePfs(_processContext.getNoTelephone())//
                  .message(message)//
                  .build();
              vmsCvmSi101.execute(this);
              retour = vmsCvmSi101.getRetour();
              if (!isRetourOK(retour))
              {
                return;
              }
            }
            catch (Exception exception)
            {
              throw exception;
            }
            finally
            {
              //clean temp file created to store the media content
              cleanStreamWideTempFile(tracabilite_p, message.getFileName());
            }

          }

          /**
           * Export all annonces associated with noTelephone from the VMS StreamWide platform
           */
          _processContext.setState(State.VMSSTW_SI102);
          VMSSTW_SI102_ExporterAnnonces vmsStwSi102 = new VMSSTW_SI102_ExporterAnnoncesBuilder()//
              .tracabilite(tracabilite_p)//
              .tempFolder(TEMP_FOLFER)//
              .idVmsStw(_processContext.getIdVmsStw())//
              .noTelephone(_processContext.getNoTelephone())//
              .build();
          List<Annonce> annonces = vmsStwSi102.execute(this);
          retour = vmsStwSi102.getRetour();
          if (isRetourOK(retour))
          {
            /**
             * Implements PI0311_BL200_BoucleImportAnnonces
             *
             * Import all the annonces exported from StreamWide into the VMS Convergys platform If no annonces to import
             * continues OK
             */
            for (Annonce annonce : annonces)
            {
              _processContext.setState(State.PI0311_BL200);//PI0311_BL200 implemented in the for cycle
              _processContext.setState(State.VMSCVM_SI034);
              try
              {
                if (annonce.getFileName() == null)
                {
                  retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, Messages.getString("PI0311.NomFichierVide")); //$NON-NLS-1$
                  return;
                }
                //load the contenuMedia from the corresponding file
                annonce.setContenuMedia(importMediaContentFromFile(annonce.getFileName()));

                VMSCVM_SI034_PersonnaliserAnnonceAccueil vmsCvmSi034 = new VMSCVM_SI034_PersonnaliserAnnonceAccueilBuilder()//
                    .tracabilite(tracabilite_p)//
                    .idMessageriePfs(_processContext.getNoTelephone()) //
                    .annonce(annonce)//
                    .build();
                vmsCvmSi034.execute(this);
                retour = vmsCvmSi034.getRetour();
                if (!isRetourOK(retour))
                {
                  return;
                }
              }
              catch (Exception exception)
              {
                throw exception;
              }
              finally
              {
                //clean temp file created to store the media content
                cleanStreamWideTempFile(tracabilite_p, annonce.getFileName());
              }
            }
          }
        }
      }
    }
    catch (final Exception e)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
    }
    finally
    {
      _processContext.setState(State.PI0311_BL002);
      Retour processRetour = PI0311_BL002_FormaterReponse(tracabilite_p, retour);
      setRetour(processRetour);
      syncResponse(tracabilite_p, request_p, processRetour);
      _processContext.setState(State.PI0311_END);
    }
  }

  /**
   * Extract metadata ID_VMS_STW and NO_TELEPHONE from the request
   *
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @return Retour Check if Url Parameters are Ok
   * @throws RavelException
   */
  private Retour checkAndExtractMetadataParameters(final Request request_p, final Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();

    String idVmsStw = request_p.getMetadata(MetadataParameters.ID_VMS_STW.name());
    String noTelephone = request_p.getMetadata(MetadataParameters.NO_TELEPHONE.name());

    // Check combinations of parameters required

    if (StringTools.isNotNullOrEmpty(noTelephone))
    {
      if (!MSISDNTools.isValidE164MSISDN(noTelephone)) // check format E.164 (starts with + followed by 15 digits)
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PI0311.BL001.NoTelephoneInvalide"), noTelephone)); //$NON-NLS-1$
        return retour;
      }
      _processContext.setNoTelephone(noTelephone);
    }
    else
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PI0311.BL001.MissingParameter"), NO_TELEPHONE)); //$NON-NLS-1$
      return retour;
    }

    if (StringTools.isNotNullOrEmpty(idVmsStw))
    {
      ConnectorResponse<Boolean, Nothing> isIdVmsStwInConfigTable = StreamWideProxy.getInstance().isIdVmsStwInConfigTable(tracabilite_p, idVmsStw);
      if (!isIdVmsStwInConfigTable._first)
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PI0311.BL001.IdVmsStwConfigAbsent"), idVmsStw)); //$NON-NLS-1$
        return retour;
      }
      _processContext.setIdVmsStw(idVmsStw);
    }
    else
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PI0311.BL001.MissingParameter"), ID_VMS_STW_PARAM_NAME)); //$NON-NLS-1$
      return retour;
    }

    return retour;

  }

  /**
   * Delete a temporary StreamWide file.
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param filePath_p
   *          The file path to delete
   * @throws RavelException
   */
  private void cleanStreamWideTempFile(Tracabilite tracabilite_p, String filePath_p) throws RavelException
  {
    BL3400_SupprimerFichier bl3400 = new BL3400_SupprimerFichier.BL3400_SupprimerFichierBuilder()//
        .tracabilite(tracabilite_p)//
        .repertoire(TEMP_FOLFER)//
        .fileName(filePath_p).build();
    bl3400.execute(this);

  }

  /**
   * Import the media content from the temporary file
   *
   * @param fileName_p
   *          The fileName containing the media object
   * @return
   * @throws IOException
   *           Thrown if IO error
   */
  private BinaryContentWrapper importMediaContentFromFile(String fileName_p) throws IOException
  {
    byte[] contenuMedia = Files.readAllBytes(Paths.get(TEMP_FOLFER + fileName_p)); //read the byte[] from the temporary file
    return new BinaryContentWrapper(contenuMedia);
  }

  /**
   * Check that STI is respected.
   *
   * @param tracabilite_p
   * @param request_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private PI0311_BL001Return PI0311_BL001_VerifierDonnees(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {

    final PI0311_BL001Return bl001return = new PI0311_BL001Return(RetourFactory.createOkRetour());

    Retour metadataParametersRetour = checkAndExtractMetadataParameters(request_p, tracabilite_p);

    //return if parameters are not conform as on STI
    if (!RetourFactory.isRetourOK(metadataParametersRetour))
    {
      bl001return.setRetour(metadataParametersRetour);
      return bl001return;
    }

    bl001return.setNoTelephone(_processContext.getNoTelephone());
    bl001return.setIdVmsStw(_processContext.getIdVmsStw());

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_VMS_STW, _processContext.getIdVmsStw());
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, _processContext.getNoTelephone());
    BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
    bl1700.execute(this);

    return bl001return;

  }

  /**
   * PI0311_BL002_FormaterReponse
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retourIn_p
   *          Retour
   * @return Retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PI0311_BL002_FormaterReponse(Tracabilite tracabilite_p, Retour retourIn_p) throws RavelException
  {
    Retour retourOut = null;
    if (RetourFactory.isRetourNOK(retourIn_p))
    {
      if (IMegConsts.CAT4.equals(retourIn_p.getCategorie()))
      {
        if (IMegSpiritConsts.KO_PFS.equals(retourIn_p.getDiagnostic()))
        {
          retourOut = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, retourIn_p.getLibelle());
        }
        else if (IMegSpiritConsts.NO_TELEPHONE_INCONNU.equals(retourIn_p.getDiagnostic()) || IMegSpiritConsts.ID_MESSAGERIE_INCONNU.equals(retourIn_p.getDiagnostic()))
        {
          retourOut = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.BOITE_INCONNUE, retourIn_p.getLibelle());
        }
      }
      else if ((IMegConsts.CAT1.equals(retourIn_p.getCategorie()) && IMegSpiritConsts.KO_PFS.equals(retourIn_p.getDiagnostic())) || (IMegConsts.CAT2.equals(retourIn_p.getCategorie()) && IMegSpiritConsts.PFS_INDISPO.equals(retourIn_p.getDiagnostic())))
      {
        retourOut = RetourFactory.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, retourIn_p.getLibelle());
      }
      else
      {
        retourOut = retourIn_p;
      }

    }
    else
    {
      retourOut = retourIn_p;
    }

    return retourOut;
  }

  /**
   * send a sync response for requester.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param request_p
   *          The request object
   * @param pi0311Retour_p
   *          The Return
   */
  private void syncResponse(Tracabilite tracabilite_p, Request request_p, Retour pi0311Retour_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp;
      ErrorCode errorCode;
      String jsonResponse;

      if (pi0311Retour_p.getDiagnostic() != null)
      {
        switch (pi0311Retour_p.getDiagnostic())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.BOITE_INCONNUE:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegConsts.SERVICE_TIERS_INDISPONIBLE:
          case IMegSpiritConsts.PROCESSUS_INDISPONIBLE:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        rsp = new Response(errorCode, ravelResponse);
      }
      else
      {
        rsp = new Response(ErrorCode.OK_00201, ravelResponse);
      }
      try
      {
        jsonResponse = RavelJsonTools.getInstance().toJson(getRetourJSON(pi0311Retour_p), com.bytel.ravel.types.Retour.class);

      }
      catch (RavelException exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
        jsonResponse = null;
      }
      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      ravelResponse.setResult(jsonResponse);

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PI0311 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);
    }
  }

}
