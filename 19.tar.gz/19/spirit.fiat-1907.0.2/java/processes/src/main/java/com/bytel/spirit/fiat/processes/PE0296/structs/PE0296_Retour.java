/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0296.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.squareup.moshi.Json;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class PE0296_Retour implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -2467725247182548626L;

  /**
   * @return the serialversionuid
   */
  public static long getSerialversionuid()
  {
    return serialVersionUID;
  }

  /**
   *
   */
  @Json(name = "error")
  String _error;

  /**
   *
   */
  @Json(name = "error_description")
  String _error_description;

  /**
   * List of Referentiels
   */
  @Json(name = "Referentiels")
  List<PE0296_Referentiel> _listReferentiel;

  /**
   *
   */
  public PE0296_Retour()
  {
    super();
  }

  /**
   * @param error_p
   *          error
   * @param error_description_p
   *          error_description
   * @param listReferentiel_p
   *          listReferentiel
   */
  public PE0296_Retour(String error_p, String error_description_p, List<PE0296_Referentiel> listReferentiel_p)
  {
    super();
    _error = error_p;
    _error_description = error_description_p;
    _listReferentiel = listReferentiel_p;
  }

  /**
   * @return the error
   */
  public String getError()
  {
    return _error;
  }

  /**
   * @return the error_description
   */
  public String getErrordescription()
  {
    return _error_description;
  }

  /**
   * @return the listReferentiel
   */
  public List<PE0296_Referentiel> getListReferentiel()
  {
    return _listReferentiel != null ? new ArrayList<>(_listReferentiel) : new ArrayList<>();
  }

  /**
   * @param error_p
   *          the error to set
   */
  public void setError(String error_p)
  {
    _error = error_p;
  }

  /**
   * @param error_description_p
   *          the error_description to set
   */
  public void setErrordescription(String error_description_p)
  {
    _error_description = error_description_p;
  }

  /**
   * @param listReferentiel_p
   *          the listReferentiel to set
   */
  public void setListReferentiel(List<PE0296_Referentiel> listReferentiel_p)
  {
    _listReferentiel = listReferentiel_p != null ? new ArrayList<>(listReferentiel_p) : new ArrayList<>();
  }

}
