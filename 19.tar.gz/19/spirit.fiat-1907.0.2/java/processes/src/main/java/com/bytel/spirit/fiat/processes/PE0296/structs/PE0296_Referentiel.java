/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0296.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.squareup.moshi.Json;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class PE0296_Referentiel implements Serializable
{

  /**
   *
   * EtatProvisioning
   */
  public enum EtatProvisioning
  {
    /**
     * REALISE
     */
    REALISE,
    /**
     * ECHEC
     */
    ECHEC,
    /**
     * EN_COURS
     */
    EN_COURS;
  }

  /**
   *
   * TypeService
   */
  public enum TypeService
  {
    /**
     * RACCORDEMENT
     */
    RACCORDEMENT;
  }

  /**
  *
  */
  private static final long serialVersionUID = 1L;

  /**
  *
  */
  @Json(name = "clientOperateur")
  private String _clientOperateur;

  /**
  *
  */
  @Json(name = "noCompte")
  private String _noCompte;

  /**
  *
  */
  @Json(name = "idRaccordement")
  private String _idRaccordement;

  /**
  *
  */
  @Json(name = "typeService")
  private String _typeService;

  /**
  *
  */
  @Json(name = "techno")
  private String _techno;

  /**
   * Liste de Ressources
   */
  @Json(name = "ressources")
  private List<PE0296_Ressource> _ressources;

  /**
  *
  */
  @Json(name = "vlan")
  private String _vlan;

  /**
   * Statut du Provisioning
   */
  @Json(name = "etatProvisioning")
  private String _etatProvisioning;

  /**
   * List de erreurs detectes
   */
  @Json(name = "erreurs")
  private List<PE0296_Erreur> _erreurs;

  /**
   *
   */
  public PE0296_Referentiel()
  {
    super();
  }

  /**
   * @param idRaccordement_p
   *          idRaccordement
   * @param typeService_p
   *          typeService
   * @param etatProvisioning_p
   *          etatProvisioning
   */
  public PE0296_Referentiel(String idRaccordement_p, String typeService_p, String etatProvisioning_p)
  {
    super();
    _idRaccordement = idRaccordement_p;
    _typeService = typeService_p;
    _etatProvisioning = etatProvisioning_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0296_Referentiel other = (PE0296_Referentiel) obj;
    if (_clientOperateur == null)
    {
      if (other._clientOperateur != null)
      {
        return false;
      }
    }
    else if (!_clientOperateur.equals(other._clientOperateur))
    {
      return false;
    }
    if (_erreurs == null)
    {
      if (other._erreurs != null)
      {
        return false;
      }
    }
    else if (!_erreurs.equals(other._erreurs))
    {
      return false;
    }
    if (_etatProvisioning == null)
    {
      if (other._etatProvisioning != null)
      {
        return false;
      }
    }
    else if (!_etatProvisioning.equals(other._etatProvisioning))
    {
      return false;
    }
    if (_idRaccordement == null)
    {
      if (other._idRaccordement != null)
      {
        return false;
      }
    }
    else if (!_idRaccordement.equals(other._idRaccordement))
    {
      return false;
    }
    if (_noCompte == null)
    {
      if (other._noCompte != null)
      {
        return false;
      }
    }
    else if (!_noCompte.equals(other._noCompte))
    {
      return false;
    }
    if (_ressources == null)
    {
      if (other._ressources != null)
      {
        return false;
      }
    }
    else if (!_ressources.equals(other._ressources))
    {
      return false;
    }
    if (_techno == null)
    {
      if (other._techno != null)
      {
        return false;
      }
    }
    else if (!_techno.equals(other._techno))
    {
      return false;
    }
    if (_typeService == null)
    {
      if (other._typeService != null)
      {
        return false;
      }
    }
    else if (!_typeService.equals(other._typeService))
    {
      return false;
    }
    if (_vlan == null)
    {
      if (other._vlan != null)
      {
        return false;
      }
    }
    else if (!_vlan.equals(other._vlan))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the erreurs
   */
  public List<PE0296_Erreur> getErreurs()
  {
    return _erreurs != null ? new ArrayList<>(_erreurs) : new ArrayList<>();
  }

  /**
   * @return the etatProvisioning
   */
  public String getEtatProvisioning()
  {
    return _etatProvisioning;
  }

  /**
   * @return the idRaccordement
   */
  public String getIdRaccordement()
  {
    return _idRaccordement;
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the ressources
   */
  public List<PE0296_Ressource> getRessources()
  {
    return _ressources != null ? new ArrayList<>(_ressources) : new ArrayList<>();

  }

  /**
   * @return the techno
   */
  public String getTechno()
  {
    return _techno;
  }

  /**
   * @return the typeService
   */
  public String getTypeService()
  {
    return _typeService;
  }

  /**
   * @return the vlan
   */
  public String getVlan()
  {
    return _vlan;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_clientOperateur == null) ? 0 : _clientOperateur.hashCode());
    result = (prime * result) + ((_erreurs == null) ? 0 : _erreurs.hashCode());
    result = (prime * result) + ((_etatProvisioning == null) ? 0 : _etatProvisioning.hashCode());
    result = (prime * result) + ((_idRaccordement == null) ? 0 : _idRaccordement.hashCode());
    result = (prime * result) + ((_noCompte == null) ? 0 : _noCompte.hashCode());
    result = (prime * result) + ((_ressources == null) ? 0 : _ressources.hashCode());
    result = (prime * result) + ((_techno == null) ? 0 : _techno.hashCode());
    result = (prime * result) + ((_typeService == null) ? 0 : _typeService.hashCode());
    result = (prime * result) + ((_vlan == null) ? 0 : _vlan.hashCode());
    return result;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param erreurs_p
   *          the erreurs to set
   */
  public void setErreurs(List<PE0296_Erreur> erreurs_p)
  {
    _erreurs = erreurs_p != null ? new ArrayList<>(erreurs_p) : new ArrayList<>();
  }

  /**
   * @param etatProvisioning_p
   *          the etatProvisioning to set
   */
  public void setEtatProvisioning(String etatProvisioning_p)
  {
    _etatProvisioning = etatProvisioning_p;
  }

  /**
   * @param idRaccordement_p
   *          the idRaccordement to set
   */
  public void setIdRaccordement(String idRaccordement_p)
  {
    _idRaccordement = idRaccordement_p;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param ressources_p
   *          the ressources to set
   */
  public void setRessources(List<PE0296_Ressource> ressources_p)
  {
    _ressources = ressources_p != null ? new ArrayList<>(ressources_p) : new ArrayList<>();

  }

  /**
   * @param techno_p
   *          the techno to set
   */
  public void setTechno(String techno_p)
  {
    _techno = techno_p;
  }

  /**
   * @param typeService_p
   *          the typeService to set
   */
  public void setTypeService(String typeService_p)
  {
    _typeService = typeService_p;
  }

  /**
   * @param vlan_p
   *          the vlan to set
   */
  public void setVlan(String vlan_p)
  {
    _vlan = vlan_p;
  }

}
