/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274.structs;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public enum OperationMessageries
{
  /**
   * LIRE_INTERDICTION_DEPOT_MESSAGE
   */
  LIRE_INTERDICTION_DEPOT_MESSAGE("lireInterdictionDepotMessage"), //$NON-NLS-1$
  /**
   * LIRE_NOTIFICATION_EMAIL
   */
  LIRE_NOTIFICATION_EMAIL("lireNotificationEmail"), //$NON-NLS-1$
  /**
   * LIRE_MESSAGERIE_A_DISTANCE
   */
  LIRE_MESSAGERIE_A_DISTANCE("lireMessagerieADistance"), //$NON-NLS-1$
  /**
   * LISTER_MESSAGERIE
   */
  LISTER_MESSAGERIE("listerMessagerie"), //$NON-NLS-1$
  /**
   * LISTER_NOTIFICATIONS_SMS
   */
  LISTER_NOTIFICATIONS_SMS("listerNotificationsSMS"), //$NON-NLS-1$
  /**
   * MODIFIER_STATUT_MESSAGERIE
   */
  MODIFIER_STATUT_MESSAGERIE("modifierStatutMessagerie"), //$NON-NLS-1$
  /**
   * MODIFIER_NOTIFICATIONS_EMAIL
   */
  MODIFIER_NOTIFICATIONS_EMAIL("modifierNotificationsEmail"), //$NON-NLS-1$
  /**
   * MODIFIER_INTERDICTIONS_DEPOT_MESSAGES
   */
  MODIFIER_INTERDICTIONS_DEPOT_MESSAGES("modifierInterdictionsDepotMessages"), //$NON-NLS-1$
  /**
   * MODIFIER_MESSAGERIES_A_DISTANCE
   */
  MODIFIER_MESSAGERIES_A_DISTANCE("modifierMessageriesADistance"), //$NON-NLS-1$
  /**
   * GESTION_VVM
   */
  GESTION_VVM("gestionVVM"), //$NON-NLS-1$
  /**
   * MODIFIER_NOTIFICATIONS_SMS
   */
  MODIFIER_NOTIFICATIONS_SMS("modifierNotificationsSMS"), //$NON-NLS-1$
  /**
   * MODIFIER_CODE_PIN
   */
  MODIFIER_CODE_PIN("modifierCodePin"); //$NON-NLS-1$

  /**
   * Value
   */
  private final String _value;

  /**
   * Default constructor
   *
   * @param value_p
   *          value
   */
  private OperationMessageries(String value_p)
  {
    this._value = value_p;
  }

  /**
   * Get value
   *
   * @return String
   */
  public String getValue()
  {
    return this._value;
  }

}