/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 * ModifierCodePin Payload
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0274_PutRequestCodePin implements Serializable
{
  /**
   * The id for serialization
   */
  private static final long serialVersionUID = -7498329481686167427L;

  /**
   * codePin
   */
  @Json(name = "codePin")
  private String _codePin;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0274_PutRequestCodePin other = (PE0274_PutRequestCodePin) obj;
    if (_codePin == null)
    {
      if (other._codePin != null)
      {
        return false;
      }
    }
    else if (!_codePin.equals(other._codePin))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the codePin
   */
  public String getCodePin()
  {
    return _codePin;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_codePin == null) ? 0 : _codePin.hashCode());
    return result;
  }

  /**
   * @param codePin_p
   *          the codePin to set
   */
  public void setCodePin(String codePin_p)
  {
    _codePin = codePin_p;
  }
}
