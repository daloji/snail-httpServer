/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0279.structs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0279_BL001_VerifierDonneesFibresReturn extends AbstractBLReturn
{
  /**
   *
   */
  private static final long serialVersionUID = -6319132452349832134L;

  /**
   * The OI
   */
  private String _oi;

  /**
   * The ListeEtat
   */
  private List<String> _listeEtat;

  /**
   * The ReferencePM
   */
  private String _referencePM;

  /**
   * The refPrestationPrise
   */
  private String _refPrestationPrise;

  /**
   * The ReferencePBO
   */
  private String _referencePBO;

  /**
   * Constructor.
   *
   * @param retour_p
   *          retour
   */
  public PE0279_BL001_VerifierDonneesFibresReturn(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @return the listeEtat
   */
  public List<String> getListeEtat()
  {
    return _listeEtat != null ? Collections.unmodifiableList(_listeEtat) : new ArrayList<>();
  }

  /**
   * @return the oi
   */
  public String getOi()
  {
    return _oi;
  }

  /**
   * @return the referencePBO
   */
  public String getReferencePBO()
  {
    return _referencePBO;
  }

  /**
   * @return the referencePM
   */
  public String getReferencePM()
  {
    return _referencePM;
  }

  /**
   * @return the refPrestationPrise
   */
  public String getRefPrestationPrise()
  {
    return _refPrestationPrise;
  }

  /**
   * @param listeEtat_p
   *          the listeEtat to set
   */
  public void setListeEtat(List<String> listeEtat_p)
  {
    _listeEtat = listeEtat_p != null ? new ArrayList<>(listeEtat_p) : new ArrayList<>();
  }

  /**
   * @param oi_p
   *          the oi to set
   */
  public void setOi(String oi_p)
  {
    _oi = oi_p;
  }

  /**
   * @param referencePBO_p
   *          the referencePBO to set
   */
  public void setReferencePBO(String referencePBO_p)
  {
    _referencePBO = referencePBO_p;
  }

  /**
   * @param referencePM_p
   *          the referencePM to set
   */
  public void setReferencePM(String referencePM_p)
  {
    _referencePM = referencePM_p;
  }

  /**
   * @param refPrestationPrise_p
   *          the refPrestationPrise to set
   */
  public void setRefPrestationPrise(String refPrestationPrise_p)
  {
    _refPrestationPrise = refPrestationPrise_p;
  }

  @Override
  public String toString()
  {
    return "PE0279_BL001_VerifierDonneesFibresReturn [_oi=" + _oi + ", _listeEtat=" + _listeEtat + ", _referencePM=" + _referencePM + ", _refPrestationPrise=" + _refPrestationPrise + ", _referencePBO=" + _referencePBO + "]";
  }

}
