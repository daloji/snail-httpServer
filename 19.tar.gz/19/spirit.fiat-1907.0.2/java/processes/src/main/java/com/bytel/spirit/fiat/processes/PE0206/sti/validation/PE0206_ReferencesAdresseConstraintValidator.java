package com.bytel.spirit.fiat.processes.PE0206.sti.validation;

/*******************************************************************************
* $Id: PE0206_ReferencesAdresseConstraintValidator.java 14954 2018-12-20 11:10:00Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.bytel.ravel.common.utils.StringTools;
import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_ReferenceAdresse;

/**
 *
 * @author mfreire
 * @version ($Revision: 14954 $ $Date: 2018-12-20 12:10:00 +0100 (jeu., 20 déc. 2018) $)
 */
public final class PE0206_ReferencesAdresseConstraintValidator implements ConstraintValidator<PE0206_ReferencesAdresseConstraint, PE0206_ReferenceAdresse>
{

  @Override
  public boolean isValid(PE0206_ReferenceAdresse value_p, ConstraintValidatorContext context_p)
  {
    if (StringTools.areAllNullOrEmpty(value_p.getHexacle(), value_p.getIdentifiantImeuble(), value_p.getAdresseLibre()))
    {
      if ((value_p.getRivoli() == null) && (value_p.getHexacleVoie() == null) && (value_p.getReferenceGeo() == null))
      {
        context_p.disableDefaultConstraintViolation();
        context_p.buildConstraintViolationWithTemplate(IMessageFormatKeys.CONDITIONAL_FIELD).addPropertyNode("< au moins une reference necessaire >").addConstraintViolation();
        return false;
      }

    }

    return true;
  }

}
