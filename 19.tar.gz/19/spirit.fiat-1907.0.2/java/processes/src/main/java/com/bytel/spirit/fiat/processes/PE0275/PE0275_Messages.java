/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0275;

import static com.bytel.spirit.fiat.processes.PE0275.structs.OperationMessage.LISTER_MESSAGE;
import static com.bytel.spirit.fiat.processes.PE0275.structs.OperationMessage.TELECHARGER_MESSAGE;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.data.exchange.generated.RavelResponse;
import com.bytel.ravel.common.data.exchange.generated.RavelResponse.ResponseHeader;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.RavelMultipartBody;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI024_DeposerMessage;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI025_TelechargeMessage;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI025_TelechargeMessage.VMSCVM_SI025_TelechargeMessageBuilder;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI042_EnvoyerFax;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI028_TelechargeMessage;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI028_TelechargeMessage.VMSSTW_SI028_TelechargeMessageBuilder;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.fiat.config.MessagesConfig;
import com.bytel.spirit.common.shared.functional.types.json.MessagePfsFax;
import com.bytel.spirit.common.shared.functional.types.json.MessagePfsVoix;
import com.bytel.spirit.common.shared.functional.types.json.MessagesPfs;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_GetBL100Reponse;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_MessagesPFS;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_PostRequest;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_PutRequest;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_Suivi;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_SuiviPost;
import com.bytel.spirit.fiat.processes.PE0275.structs.OperationMessage;
import com.bytel.spirit.fiat.processes.PE0275.structs.PE0275_BL001DeleteRetour;
import com.bytel.spirit.fiat.processes.PE0275.structs.PE0275_BL001GetRetour;
import com.bytel.spirit.fiat.processes.PE0275.structs.PE0275_BL001PostRetour;
import com.bytel.spirit.fiat.processes.PE0275.structs.PE0275_BL001PutRetour;
import com.bytel.spirit.fiat.processes.PE0275.structs.PE0275_BL002GetReturn;
import com.bytel.spirit.fiat.processes.structs.XAction;
import com.bytel.spirit.fiat.processes.structs.XLink;

/**
 *
 * @author vloureir
 * @version ($Revision$ $Date$)
 */
public class PE0275_Messages extends SpiritRestApiProcessSkeleton
{

  /**
   *
   * @author vloureir
   * @version ($Revision$ $Date$)
   */
  public static final class PE0275_MessagesContext extends Context
  {

    /**
     * The serial UID
     */
    private static final long serialVersionUID = 8388598975713583554L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0275_START;

    /**
     * Contains the process configuration
     */
    private transient MessagesConfig _configurationPE0275;

    /**
     * The retour of the process
     */
    private Retour _processRetour;

    /**
     * Mailbox ID
     */
    private String _idMessagerie;

    /**
     * modeAppel
     */
    private String _modeAppel;

    /**
     * The Liste contract auth;
     */
    private List<String> _listeContratOauth;

    /**
     * idRequest
     */
    private String _idRequest;

    /**
     *
     */
    private String _frontAdress;

    /**
     * @param contratOuath_p
     *          the contratOuath to add
     */
    public void addContratOauth(String contratOuath_p)
    {
      if (_listeContratOauth == null)
      {
        _listeContratOauth = new ArrayList<>();
      }
      _listeContratOauth.add(contratOuath_p);
    }

    /**
     * @return value of _configurationPE0275
     */
    public MessagesConfig getConfigurationPE0275()
    {
      return _configurationPE0275;
    }

    /**
     * @return the frontAdress
     */
    public String getFrontAdress()
    {
      return _frontAdress;
    }

    /**
     * @return the idMessagerie
     */
    public String getIdMessagerie()
    {
      return _idMessagerie;
    }

    /**
     * @return the idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the listeContratOauth
     */
    public List<String> getListeContratOauth()
    {
      return _listeContratOauth != null ? new ArrayList<>(_listeContratOauth) : new ArrayList<>();
    }

    /**
     * @return the modeAppel
     */
    public String getModeAppel()
    {
      return _modeAppel;
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param configurationPE0275_p
     *          The _configurationPE0275 to set.
     */
    public void setConfigurationPE0275(MessagesConfig configurationPE0275_p)
    {
      _configurationPE0275 = configurationPE0275_p;
    }

    /**
     * @param frontAdress_p
     *          the frontAdress to set
     */
    public void setFrontAdress(String frontAdress_p)
    {
      _frontAdress = frontAdress_p;
    }

    /**
     * @param idMessagerie_p
     *          the idMessagerie to set
     */
    public void setIdMessagerie(String idMessagerie_p)
    {
      _idMessagerie = idMessagerie_p;
    }

    /**
     * @param idRequest_p
     *          the idRequest to set
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param listeContratOauth_p
     *          the listeContratOauth to set
     */
    public void setListeContratOauth(List<String> listeContratOauth_p)
    {
      _listeContratOauth = new ArrayList<>(listeContratOauth_p);
    }

    /**
     * @param modeAppel_p
     *          the modeAppel to set
     */
    public void setModeAppel(String modeAppel_p)
    {
      _modeAppel = modeAppel_p;
    }

    /**
     * @param processRetour_p
     *          the processRetour to set
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }
  }

  /**
   *
   * @author pescudei
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0275_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call GET_BL001
     */
    PE0275_GET_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT_BL001
     */
    PE0275_PUT_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call POST_BL001
     */
    PE0275_POST_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call DELETE_BL001
     */
    PE0275_DELETE_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call GET BL100
     */
    PE0275_GET_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL100
     */
    PE0275_PUT_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call POST BL200
     */
    PE0275_POST_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call DELETE BL100
     */
    PE0275_DELETE_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PE0275_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call GET BL002
     */
    PE0275_GET_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call POST BL002
     */
    PE0275_POST_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL002
     */
    PE0275_PUT_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call DELETE BL002
     */
    PE0275_DELETE_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PE0275_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }

    /**
     * @return the technicalState
     */
    public MandatoryProcessState getTechnicalState()
    {
      return _technicalState;
    }

    /**
     * @return the asynchronousState
     */
    public boolean isAsynchronousState()
    {
      return _asynchronousState;
    }

    /**
     * @return the replayableState
     */
    public boolean isReplayableState()
    {
      return _replayableState;
    }

    /**
     * @param asynchronousState_p
     *          the asynchronousState to set
     */
    public void setAsynchronousState(boolean asynchronousState_p)
    {
      _asynchronousState = asynchronousState_p;
    }

    /**
     * @param replayableState_p
     *          the replayableState to set
     */
    public void setReplayableState(boolean replayableState_p)
    {
      _replayableState = replayableState_p;
    }

    /**
     * @param technicalState_p
     *          the technicalState to set
     */
    public void setTechnicalState(MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
    }
  }

  protected enum UrlParameters
  {
    /**
     * loginMail
     */
    ID_MESSAGES("idMessages"); //$NON-NLS-1$
    /**
     *
     */
    private String _paramName;

    /**
     * @param name_p
     *          name
     */
    private UrlParameters(String name_p)
    {
      setParamName(name_p);
    }

    /**
     * @return the paramName
     */
    public String getParamName()
    {
      return _paramName;
    }

    /**
     * @param paramName_p
     *          the paramName to set
     */
    public void setParamName(String paramName_p)
    {
      _paramName = paramName_p;
    }
  }

  /**
   * The serial UID
   */
  private static final long serialVersionUID = 8803261048750203871L;

  /**
   * The constant for FileError message
   */
  protected static final String MESSAGE_FILE_ERROR = Messages.getString("PE0275.FileError"); //$NON-NLS-1$

  /**
   * The constant for NoParam message
   */
  protected static final String MESSAGE_NO_PARAM = Messages.getString("PE0275.NoParam"); //$NON-NLS-1$

  /**
   * The constant for BL001.HeaderNullOrEmpty message
   */
  private static final String MESSAGE_INVALID_HEADER = Messages.getString("PE0275.BL001.HeaderNullOrEmpty"); //$NON-NLS-1$

  /**
   * The constant for BL100.IdMessagerieInconnu message
   */
  private static final String MESSAGE_ID_MESSAGERIE_INCONNU = Messages.getString("PE0275.BL100.IdMessagerieInconnu"); //$NON-NLS-1$

  /**
   * The constant for BL200.IdMessageInconnu message
   */
  private static final String MESSAGE_ID_MESSAGE_INCONNU = Messages.getString("PE0275.BL200.IdMessageInconnu"); //$NON-NLS-1$

  /**
   * The constant for BL100.IdMessageInconnu message
   */
  private static final String MESSAGE_ID_MESSAGE_INCONNU_BL100 = Messages.getString("PE0275.BL100.IdMessageInconnu"); //$NON-NLS-1$

  /**
   * The constant for BL100.OperationNotAutorized message
   */
  private static final String MESSAGE_OPERATION_NOT_AUTORIZED = Messages.getString("PE0275.BL100.OperationNotAutorized"); //$NON-NLS-1$

  /**
   * The constant for BL100.OperationNotAutorized message
   */
  private static final String MESSAGE_OPERATION_NOT_AUTORIZED_DELETE = Messages.getString("PE0275.BL100.delete.OperationNotAutorized"); //$NON-NLS-1$

  /**
   * The constant for BL200.OperationNotAutorized message
   */
  private static final String MESSAGE_OPERATION_NOT_AUTORIZED_BL200 = Messages.getString("PE0275.BL200.OperationNotAutorized"); //$NON-NLS-1$

  /**
   * The constant for BL100.serviceIndisponible message
   */
  private static final String MESSAGE_SERVICE_INDISPONIBLE = Messages.getString("PE0275.BL100.ServiceIndisponible"); //$NON-NLS-1$

  /**
   * The constant for BL100.missingParameter message
   */
  private static final String MESSAGE_MISSING_PARAMETER = Messages.getString("PE0275.BL001.MissingParameter"); //$NON-NLS-1$

  /**
   * The constant for BL001.ParameterInvalide message
   */
  private static final String MESSAGE_PARAMETER_INVALIDE = Messages.getString("PE0275.BL001.ParameterInvalide"); //$NON-NLS-1$

  /**
   * The constant for BL100.accesRefuse message
   */
  private static final String MESSAGE_ACCES_REFUSE = Messages.getString("PE0275.BL100.AccesRefuse"); //$NON-NLS-1$

  /**
   * PARAM_ID_MESSAGERIE constant
   */
  private static final String PARAM_ID_MESSAGERIE = "idMessagerie"; //$NON-NLS-1$

  /**
   * PARAM_ID_ANNONCE constant
   */
  private static final String PARAM_MESSAGE = "idMessage"; //$NON-NLS-1$

  /**
   * PARAM_STATUT_LECTURE constant
   */
  private static final String PARAM_STATUT_LECTURE = "statutLecture"; //$NON-NLS-1$

  /**
   * Configuration path Param
   */
  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * configuration Adresse Front
   */
  protected static final String PARAM_FRONT_ADRESSE = "FRONT_ADRESSE"; //$NON-NLS-1$

  /**
   * OPERATION_ANNONCES_ACCUEIL
   */
  protected static final String OPERATION_MESSAGES = "PE0275_Messages"; //$NON-NLS-1$

  /**
   * URL_MESSAGES for BL100 return
   */
  protected static final String URL_MESSAGES = "/messages/"; //$NON-NLS-1$

  /**
   * URL_MESSAGES for BL100 return
   */
  protected static final String URL_MESSAGERIES = "/messageries/"; //$NON-NLS-1$

  /**
   * Constant string type annonce VOIX
   */
  private static final String TYPE_VOIX = "VOIX"; //$NON-NLS-1$

  /**
   * Constant string type annonce FAX
   */
  private static final String TYPE_FAX = "FAX"; //$NON-NLS-1$

  /**
   * separator of X-Oauth2-Contracts in header
   */
  private static final String SEPARATOR = ","; //$NON-NLS-1$

  /**
   * separator of id
   */
  private static final String ID_SEPARATOR = "#"; //$NON-NLS-1$

  /**
   * KPSA processus name ConsulterAnnonceAccueilPfs
   */
  private static final String KPSA_CONSULTER_MESSAGES_PFS = "consulterMessagesPfs"; //$NON-NLS-1$

  /**
   * Supprimer message constant
   */
  private static final String KPSA_SUPPRIMER_MESSAGE = "supprimerMessage"; //$NON-NLS-1$

  /**
   * idMessageriePfs constant
   */
  private static final String KPSA_PARAM_ID_MESSAGERIE_PFS = "idMessageriePfs"; //$NON-NLS-1$

  /**
   * typePfs constant
   */
  private static final String KPSA_PARAM_TYPE_PFS = "typePfs"; //$NON-NLS-1$

  /**
   * typePfs constant
   */
  private static final String KPSA_PARAM_ID_MESSAGE_PFS = "idMessagePfs"; //$NON-NLS-1$

  /**
   * statutLecture constant
   */
  private static final String KPSA_PARAM_STATUT_LECTURE = "statutLecture"; //$NON-NLS-1$

  /**
   * listeIdMessagePfs constant
   */
  private static final String LISTE_ID_MESSAGE_PFS = "listeIdMessagePfs"; //$NON-NLS-1$

  /**
   * STW
   */
  public static final String STW = "STW"; //$NON-NLS-1$

  /**
   * CVG
   */
  public static final String CVG = "CVG"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ID_MESSAGE = "idMessage";

  /**
   *
   */
  private static final String NON_LU = "NON_LU";

  /**
   *
   */
  private static final String NON_ARCHIVE = "NON_ARCHIVE";

  /**
   *
   */
  private static final String EMISSION = "EMISSION";

  /**
   *
   */
  private static final String EN_COURS = "EN_COURS";

  /**
   *
   */
  private static final String APPLICATION_PDF = "application/pdf";

  /**
   *
   */
  private static final String RECEPTION = "RECEPTION";

  /**
   *
   */
  private static final String RECU = "RECU";

  /**
   *
   */
  private static final String AUDIO_WAV = "audio/wav";

  /**
   *
   */
  private static final String FAX = "fax";

  /**
   *
   */
  private static final String DATA = "data";

  /**
   *
   */
  private static final String AUDIO = "audio";

  /**
   * Process context instance
   */
  protected PE0275_MessagesContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0275_MessagesContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String s_p)
  {
    // Not required for now in Ravel
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param request_p
   *          Object technique «virtuel» regroupant l'ensemble des informations fournies en entrées du service REST
   *          (PATH + paramètres de l'URL, headers http, body http)
   * @return Pair of types Retour, PE0275_BL001GetRetour
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  protected Pair<Retour, PE0275_BL001GetRetour> PE0275_BL001_VerifierDonneesConsultation(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    try
    {
      // Load process config file
      Retour retourLoadConfig = loadConfigFile();
      if (RetourFactory.isRetourNOK(retourLoadConfig))
      {
        return new Pair<>(retourLoadConfig, null);
      }

      // Get the header parameters
      Retour retourHeaders = checkRequestHeaders(tracabilite_p, request_p);
      if (!isRetourOK(retourHeaders))
      {
        return new Pair<>(retourHeaders, null);
      }

      PE0275_BL001GetRetour retourBL001 = new PE0275_BL001GetRetour();
      retourBL001.setModeAppel(_processContext.getModeAppel());
      retourBL001.setListeContratOauth(_processContext.getListeContratOauth());

      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.ID_EXTERNE, _processContext.getIdRequest());
      if (OPERATION_MESSAGES.equals(request_p.getOperation()))
      {
        retourBL001.setTypeOperation(LISTER_MESSAGE);
        if (StringTools.isNullOrEmpty(request_p.getUrlDynamicParameters()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, PARAM_ID_MESSAGERIE)), null);
        }
        retourBL001.setIdMessagerie(request_p.getUrlDynamicParameters());
        refFonc.put(IRefFoncConstants.ID_MESSAGERIE, retourBL001.getIdMessagerie());
      }
      else
      {
        retourBL001.setTypeOperation(TELECHARGER_MESSAGE);
        if (StringTools.isNullOrEmpty(request_p.getUrlDynamicParameters()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, PARAM_MESSAGE)), null);
        }
        retourBL001.setIdMessage(request_p.getUrlDynamicParameters());
        refFonc.put(IRefFoncConstants.ID_ANNONCE, retourBL001.getIdMessage());
      }

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
      bl1700.execute(this);

      // Retour OK
      return new Pair<>(RetourFactory.createOkRetour(), retourBL001);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()), null);
    }
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param request_p
   *          Object technique «virtuel» regroupant l'ensemble des informations fournies en entrées du service REST
   *          (PATH + paramètres de l'URL, headers http, body http)
   * @return Pair of types Retour, PE0275_BL001GetRetour
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  protected Pair<Retour, PE0275_BL001PostRetour> PE0275_BL001_VerifierDonneesCreation(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    try
    {
      // Load process config file
      Retour retourLoadConfig = loadConfigFile();
      if (RetourFactory.isRetourNOK(retourLoadConfig))
      {
        return new Pair<>(retourLoadConfig, null);
      }

      // Get the header parameters
      Retour retourHeaders = checkRequestHeaders(tracabilite_p, request_p);
      if (!isRetourOK(retourHeaders))
      {
        return new Pair<>(retourHeaders, null);
      }

      PE0275_BL001PostRetour postRetour = new PE0275_BL001PostRetour();
      RavelMultipartBody multipartBody = request_p.getMultipartBody();
      if (multipartBody == null)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "data")), null);
      }
      final String dataPart = multipartBody.readStringPart(DATA);
      if (StringUtils.isEmpty(dataPart))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "data")), null);
      }
      PE0275_PostRequest postRequest = RavelJsonTools//
          .getInstance()//
          .fromJson(dataPart, PE0275_PostRequest.class);

      if (StringUtils.isEmpty(postRequest.getExpediteur()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "expediteur")), null);
      }
      if (StringUtils.isEmpty(postRequest.getTypeMessagerie()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "typeMessagerie")), null);
      }
      if (StringUtils.isEmpty(postRequest.getIdMessagerie()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "idMessagerie")), null);
      }
      if (postRequest.getDestinataires().isEmpty())
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "destinatairs")), null);
      }
      for (String destinatair : postRequest.getDestinataires())
      {
        if (StringUtils.isEmpty(destinatair))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "destinatair")), null);
        }
      }
      if (postRequest.getSuivi() != null)
      {
        if (!NON_LU.equals(postRequest.getSuivi().getStatutLecture()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "statutLecture")), null);
        }
        if (!NON_ARCHIVE.equals(postRequest.getSuivi().getStatutArchivage()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "statutArchivage")), null);
        }
      }
      else
      {
        PE0275_SuiviPost suivi = new PE0275_SuiviPost(NON_LU, NON_ARCHIVE);
        postRequest.setSuivi(suivi);
      }

      final MessagesPfs messagesPfs;
      final InputStream streamContenu;
      if (PE0275_PostRequest.TypeMessagerie.FAX.name().equalsIgnoreCase(postRequest.getTypeMessagerie()))
      {
        MessagePfsFax messagesPfsFax = new MessagePfsFax();
        messagesPfsFax.setStatutTransfert(EMISSION);
        messagesPfsFax.setStatut(EN_COURS);
        messagesPfsFax.setTypeContenu(APPLICATION_PDF);
        messagesPfsFax.setNbPages(postRequest.getNbPages());
        if ((messagesPfsFax.getNbPages() == null) || (messagesPfsFax.getNbPages() < 1))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "statutArchivage")), null);
        }
        streamContenu = multipartBody.streamPart(FAX);
        messagesPfsFax.setDestinataires(postRequest.getDestinataires().toArray(new String[] {}));
        messagesPfs = messagesPfsFax;
        messagesPfsFax.setIdCorrelation(UUID.randomUUID().toString());
      }
      else
      {
        MessagePfsVoix messagePfsVoix = new MessagePfsVoix();
        messagePfsVoix.setStatutTransfert(RECEPTION);
        messagePfsVoix.setStatut(RECU);
        messagePfsVoix.setTypeMessage(AUDIO_WAV);
        streamContenu = multipartBody.streamPart(AUDIO);
        messagesPfs = messagePfsVoix;
      }

      if (streamContenu == null)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, "streamContenu")), null);
      }

      messagesPfs.setExpediteur(postRequest.getExpediteur());
      messagesPfs.setNomExpediteur(postRequest.getNomExpediteur());
      messagesPfs.setTypeMessage(postRequest.getTypeMessagerie());
      messagesPfs.setContenu(IOUtils.toByteArray(streamContenu));

      _processContext.setIdMessagerie(postRequest.getIdMessagerie());
      postRetour.setIdMessagerie(postRequest.getIdMessagerie());
      postRetour.setModeAppel(_processContext.getModeAppel());
      postRetour.setListeContratOauth(_processContext.getListeContratOauth());
      postRetour.setTypeOperation(OperationMessage.DEPOSER_MESSAGE);
      postRetour.setMessagesPfs(messagesPfs);

      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.ID_EXTERNE, _processContext.getIdRequest());
      refFonc.put(ID_MESSAGE, messagesPfs.getIdMessagePfs());

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder()//
          .refFonc(refFonc)//
          .tracabilite(tracabilite_p)//
          .build();
      bl1700.execute(this);

      return new Pair<>(RetourFactory.createOkRetour(), postRetour);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()), null);
    }
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param request_p
   *          Object technique «virtuel» regroupant l'ensemble des informations fournies en entrées du service REST
   *          (PATH + paramètres de l'URL, headers http, body http)
   * @return Pair of types Retour, PE0275_BL001PutRetour
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  protected Pair<Retour, PE0275_BL001PutRetour> PE0275_BL001_VerifierDonneesModification(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    try
    {
      // Load process config file
      Retour retourLoadConfig = loadConfigFile();
      if (RetourFactory.isRetourNOK(retourLoadConfig))
      {
        return new Pair<>(retourLoadConfig, null);
      }

      // Get the header parameters
      Retour retourHeaders = checkRequestHeaders(tracabilite_p, request_p);
      if (!isRetourOK(retourHeaders))
      {
        return new Pair<>(retourHeaders, null);
      }

      PE0275_BL001PutRetour bl001PutRetour = new PE0275_BL001PutRetour();

      // Get idMessage from url
      if (StringTools.isNullOrEmpty(request_p.getUrlDynamicParameters()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, PARAM_MESSAGE)), null);
      }
      bl001PutRetour.setIdMessage(request_p.getUrlDynamicParameters());
      bl001PutRetour.setModeAppel(_processContext.getModeAppel());
      bl001PutRetour.setListeContratOauth(_processContext.getListeContratOauth());
      bl001PutRetour.setTypeOperation(OperationMessage.MODIFIER_STATUT_MESSAGE);

      PE0275_PutRequest putRequest = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0275_PutRequest.class);

      if ((putRequest.getStatutLecture() == null) //
          || (!PE0275_PutRequest.StatutLecture.LU.name().equals(putRequest.getStatutLecture())//
              && !PE0275_PutRequest.StatutLecture.NON_LU.name().equals(putRequest.getStatutLecture())))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_PARAMETER_INVALIDE, PARAM_STATUT_LECTURE)), null);
      }

      bl001PutRetour.setStatutLecture(putRequest.getStatutLecture());

      // Retour OK
      return new Pair<>(RetourFactory.createOkRetour(), bl001PutRetour);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()), null);
    }
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param request_p
   *          Objet technique « virtuel » regroupant l’ensemble des informations fournies en entrées du service REST
   *          (PATH + paramètres de l’URI, headers http, body http)
   * @return Pair of types Retour, PE0275_BL001DeleteRetour
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  protected Pair<Retour, PE0275_BL001DeleteRetour> PE0275_BL001_VerifierDonneesSuppression(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    try
    {
      // Load process config file
      Retour retourLoadConfig = loadConfigFile();
      if (RetourFactory.isRetourNOK(retourLoadConfig))
      {
        return new Pair<>(retourLoadConfig, null);
      }

      // Get the header parameters
      Retour retourHeaders = checkRequestHeaders(tracabilite_p, request_p);
      if (!isRetourOK(retourHeaders))
      {
        return new Pair<>(retourHeaders, null);
      }

      // Ger url parameters
      String listIdMessages = extractUrlParameters(request_p, tracabilite_p).get(UrlParameters.ID_MESSAGES.toString());
      if (StringTools.isNullOrEmpty(listIdMessages))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, PARAM_MESSAGE)), null);
      }

      //Build BL retour
      PE0275_BL001DeleteRetour retourBL001 = new PE0275_BL001DeleteRetour();
      retourBL001.setListIdMessage(listIdMessages);
      retourBL001.setListeContratOauth(_processContext.getListeContratOauth());
      retourBL001.setModeAppel(_processContext.getModeAppel());
      retourBL001.setTypeOperation(OperationMessage.SUPPRIMER_MESSAGE);

      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.ID_EXTERNE, _processContext.getIdRequest());
      refFonc.put(LISTE_ID_MESSAGE_PFS, retourBL001.getListIdMessage());

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder().tracabilite(tracabilite_p).refFonc(refFonc).build();
      bl1700.execute(this);

      // Retour OK
      return new Pair<>(RetourFactory.createOkRetour(), retourBL001);

    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()), null);
    }

  }

  /**
   * PE0223_BL002_FormaterReponseConsultation
   *
   * @param retourIn_p
   *          retourBL001
   * @param typeOperation_p
   *          typeOperation
   * @param reponseIN_p
   *          reponse
   * @param contenuMedia_p
   *          contenuMedia
   * @return Pair<ReponseErreur, PE0223_Retour>
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  protected Pair<Retour, PE0275_BL002GetReturn> PE0275_BL002_FormaterReponseConsultation(Tracabilite tracabilite_p, Retour retourIn_p, OperationMessage typeOperation_p, PE0275_GetBL100Reponse reponseIN_p, byte[] contenuMedia_p) throws RavelException
  {

    if (!isRetourOK(retourIn_p))
    {
      ReponseErreur responseErreeur = new ReponseErreur();
      responseErreeur.setError(retourIn_p.getDiagnostic());
      responseErreeur.setErrorDescription(retourIn_p.getLibelle());
      return new Pair<>(retourIn_p, new PE0275_BL002GetReturn(responseErreeur, null, null));
    }
    if (LISTER_MESSAGE == typeOperation_p)
    {
      return new Pair<>(retourIn_p, new PE0275_BL002GetReturn(null, reponseIN_p, null));
    }
    return new Pair<>(retourIn_p, new PE0275_BL002GetReturn(null, null, contenuMedia_p));
  }

  /**
   * PE0275_BL002_FormaterReponseCreation
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retourIn_p
   *          Retour
   * @return Retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  protected Pair<Retour, ReponseErreur> PE0275_BL002_FormaterReponseCreation(Tracabilite tracabilite_p, Retour retourIn_p) throws RavelException
  {
    if (RetourFactory.isRetourNOK(retourIn_p))
    {
      ReponseErreur reponseErreur = new ReponseErreur();
      reponseErreur.setError(retourIn_p.getDiagnostic());
      reponseErreur.setErrorDescription(retourIn_p.getLibelle());
      return new Pair<>(retourIn_p, reponseErreur);
    }
    return new Pair<>(retourIn_p, null);
  }

  /**
   * PE0275_BL002_FormaterReponseModification
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retourIn_p
   *          Retour
   * @return Retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  protected Pair<Retour, ReponseErreur> PE0275_BL002_FormaterReponseModification(Tracabilite tracabilite_p, Retour retourIn_p) throws RavelException
  {
    if (RetourFactory.isRetourNOK(retourIn_p))
    {
      ReponseErreur reponseErreur = new ReponseErreur();
      reponseErreur.setError(retourIn_p.getDiagnostic());
      reponseErreur.setErrorDescription(retourIn_p.getLibelle());
      return new Pair<>(retourIn_p, reponseErreur);
    }
    return new Pair<>(retourIn_p, null);
  }

  /**
   * PE0275_BL002_FormaterReponseSuppression
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retourIn_p
   *          retourBL001
   * @return Pair<Retour, ReponseErreur>
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  protected Pair<Retour, ReponseErreur> PE0275_BL002_FormaterReponseSuppression(Tracabilite tracabilite_p, Retour retourIn_p) throws RavelException
  {

    if (!isRetourOK(retourIn_p))
    {
      ReponseErreur responseErreeur = new ReponseErreur();
      responseErreeur.setError(retourIn_p.getDiagnostic());
      responseErreeur.setErrorDescription(retourIn_p.getLibelle());
      return new Pair<>(retourIn_p, responseErreeur);
    }
    return new Pair<>(retourIn_p, null);
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param bl001PostRetour_p
   *          Object {@Code PE0275_BL001PostRetour}
   * @return Retour
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  protected Retour PE0275_BL200_CreerMessagePfs(final Tracabilite tracabilite_p, PE0275_BL001PostRetour bl001PostRetour_p) throws RavelException
  {
    String idMessagerieDecrypted;

    // Decrypt the idMesssagerie
    try
    {
      idMessagerieDecrypted = PasswordDecrypter.decryptForURL(bl001PostRetour_p.getIdMessagerie());
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, "Error decrypting idMesssagerie", exception)); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGERIE_INCONNU, bl001PostRetour_p.getIdMessagerie()));
    }

    String[] parametresMessagerie = idMessagerieDecrypted.split(ID_SEPARATOR);
    if (parametresMessagerie.length != 4)
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGERIE_INCONNU, bl001PostRetour_p.getIdMessagerie()));
    }

    //Extraire les parametres du message a partir de la chaine dechiffrée
    String noContrat = parametresMessagerie[0];
    String idMessageriePfs = parametresMessagerie[1];
    String typeMessagerie = parametresMessagerie[2];
    String typePfs = parametresMessagerie[3];

    if (STW.equals(typePfs))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0275.BL200.TypePfsNotAutorized"), typePfs));
    }

    //Contrôler que l’opération demande est autorisée pour le type de message
    if (!_processContext.getConfigurationPE0275().getListeTypeMessagerieAutorisee().contains(typeMessagerie))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_BL200, idMessageriePfs, typeMessagerie));
    }

    if ("B2R".equals(bl001PostRetour_p.getModeAppel())) //$NON-NLS-1$
    {
      if (CollectionUtils.isEmpty(bl001PostRetour_p.getListeContratOauth()) || StringTools.isNullOrEmpty(noContrat) || !bl001PostRetour_p.getListeContratOauth().contains(noContrat))
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MESSAGE_ACCES_REFUSE);
      }
    }

    //#voix case
    if (TYPE_VOIX.equals(bl001PostRetour_p.getMessagesPfs().getTypeMessage()))
    {
      VMSCVM_SI024_DeposerMessage deposerMessage = new VMSCVM_SI024_DeposerMessage.VMSCVM_SI024_DeposerMessageBuilder()//
          .messagePfs(bl001PostRetour_p.getMessagesPfs())//
          .idMessageriePfs(idMessageriePfs)//
          .tracabilite(tracabilite_p)//
          .build();

      deposerMessage.execute(this);
      return deposerMessage.getRetour();
    }

    //#fax case
    int nbEnvoisOk = 0;
    MessagePfsFax messagePfsFax = (MessagePfsFax) bl001PostRetour_p.getMessagesPfs();
    for (String destinataire : messagePfsFax.getDestinataires())
    {
      MessagePfsFax messagePfsTemp = SerializationUtils.clone(messagePfsFax);
      messagePfsTemp.setDestinataires(new String[] { destinataire });
      VMSCVM_SI042_EnvoyerFax envoyerFax = new VMSCVM_SI042_EnvoyerFax.VMSCVM_SI042_EnvoyerFaxBuilder()//
          .idMessagerie(idMessageriePfs)//
          .messagePfs(messagePfsTemp)//
          .tracabilite(tracabilite_p)//
          .build();
      envoyerFax.execute(this);
      final Retour retourEnvoyerFax = envoyerFax.getRetour();
      if (RetourFactory.isRetourNOK(retourEnvoyerFax))
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.KO_PFS, MessageFormat.format(Messages.getString("PE0275.BL200.ErrorSendFAX"), //
            nbEnvoisOk, messagePfsFax.getDestinataires().length//
        ));
      }
      nbEnvoisOk++;
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param bl001PutRetour_p
   *          Object {@Code PE0275_BL001PutRetour}
   * @return Retour
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  protected Retour PE0275_BL200_ModifierMessagePfs(final Tracabilite tracabilite_p, PE0275_BL001PutRetour bl001PutRetour_p) throws RavelException
  {
    String idMessageDecrypted;

    // Decrypt the idMesssage
    try
    {
      idMessageDecrypted = PasswordDecrypter.decryptForURL(bl001PutRetour_p.getIdMessage());
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, "Error decrypting idMesssage", exception)); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGE_INCONNU, bl001PutRetour_p.getIdMessage()));
    }
    //Extraire les parametres du message a partir de la chaine dechiffrée
    String[] parametresMessage = idMessageDecrypted.split(ID_SEPARATOR);
    String noContrat = parametresMessage[0];
    String typePfs = parametresMessage[1];
    String idMessageriePfs = parametresMessage[2];
    String typeMessage = parametresMessage[3];
    String idMessagePfs = parametresMessage[4];

    //Contrôler que l’opération demande est autorisée pour le type de message
    if (!_processContext.getConfigurationPE0275().getListeTypeMessagerieAutorisee().contains(typeMessage))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_BL200, bl001PutRetour_p.getIdMessage(), typeMessage));
    }

    if (!StringTools.isNullOrEmpty(bl001PutRetour_p.getModeAppel()) && bl001PutRetour_p.getModeAppel().equals("B2R")) //$NON-NLS-1$
    {
      if (CollectionUtils.isEmpty(bl001PutRetour_p.getListeContratOauth()) || StringTools.isNullOrEmpty(noContrat) || !bl001PutRetour_p.getListeContratOauth().contains(noContrat))
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MESSAGE_ACCES_REFUSE);
      }
    }

    String statutLecture = bl001PutRetour_p.getStatutLecture();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(KPSA_PARAM_ID_MESSAGERIE_PFS, idMessageriePfs);
    listeParametres.add(KPSA_PARAM_TYPE_PFS, typePfs);
    listeParametres.add(KPSA_PARAM_ID_MESSAGE_PFS, idMessagePfs);
    listeParametres.add(KPSA_PARAM_STATUT_LECTURE, statutLecture);

    //Declencher l’appel vers KPSA
    PROV_SI002_ExecuterProcessus prov_si002 = new PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder()//
        .tracabilite(tracabilite_p)//
        .priorite(10)//
        .processus("modifierStatutLectureMessage")//
        .listeParametres(listeParametres).build();
    prov_si002.execute(this);
    Retour retourProv = prov_si002.getRetour();

    if (!isRetourOK(retourProv))
    {
      switch (retourProv.getCategorie())
      {
        case IMegConsts.CAT1:
          return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE);
        case IMegConsts.CAT2:
          return RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPONIBLE);
        default:
          return retourProv;
      }
    }

    return RetourFactory.createOkRetour();
  }

  @Override
  @LogStartProcess
  protected void startDeleteProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    // Call BL001
    _processContext.setState(State.PE0275_DELETE_BL001);
    Pair<Retour, PE0275_BL001DeleteRetour> retourBL001 = PE0275_BL001_VerifierDonneesSuppression(tracabilite_p, request_p);
    _processContext.setProcessRetour(retourBL001._first);

    if (RetourFactory.isRetourOK(retourBL001._first))
    {
      // Call BL100
      _processContext.setState(State.PE0275_DELETE_BL100);
      Retour retourBL100 = PE0275_BL100_SupprimerListeMessagePfs(tracabilite_p, retourBL001._second);
      _processContext.setProcessRetour(retourBL100);
    }

    // Call BL002
    _processContext.setState(State.PE0275_DELETE_BL002);
    Pair<Retour, ReponseErreur> bl002Retour = PE0275_BL002_FormaterReponseSuppression(tracabilite_p, _processContext.getProcessRetour());
    _processContext.setProcessRetour(bl002Retour._first);

    // Set process retour
    this.setRetour(_processContext.getProcessRetour());

    // Set process response
    syncDeleteResponse(request_p, bl002Retour._second);

    // Set end state
    _processContext.setState(State.PE0275_END);
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    // Set process variables
    PE0275_GetBL100Reponse reponseConnector = null;
    byte[] contenuMedia = null;
    OperationMessage typeOperation = null;

    // Call BL001
    _processContext.setState(State.PE0275_GET_BL001);
    Pair<Retour, PE0275_BL001GetRetour> retourBL001 = PE0275_BL001_VerifierDonneesConsultation(tracabilite_p, request_p);
    _processContext.setProcessRetour(retourBL001._first);

    if (isRetourOK(retourBL001._first))
    {
      typeOperation = retourBL001._second.getTypeOperation();
      switch (typeOperation)
      {
        case LISTER_MESSAGE:
          // Call BL100
          _processContext.setState(State.PE0275_GET_BL100);
          Pair<Retour, PE0275_GetBL100Reponse> retourBl100 = PE0275_BL100_ListerMessagePfs(tracabilite_p, retourBL001._second);
          reponseConnector = retourBl100._second;
          Retour retourBL100 = retourBl100._first;
          _processContext.setProcessRetour(retourBL100);
          break;

        case TELECHARGER_MESSAGE:
          //Call BL200
          _processContext.setState(State.PE0275_BL200);
          Pair<Retour, byte[]> retourBl200 = PE0275_BL200_TelechargerMessagePfs(tracabilite_p, retourBL001._second);
          contenuMedia = retourBl200._second;
          Retour retourBL200 = retourBl200._first;
          _processContext.setProcessRetour(retourBL200);
          break;

        default:
          break;
      }
    }

    // Call BL002
    _processContext.setState(State.PE0275_GET_BL002);
    Pair<Retour, PE0275_BL002GetReturn> bl002Retour = PE0275_BL002_FormaterReponseConsultation(tracabilite_p, _processContext.getProcessRetour(), typeOperation, reponseConnector, contenuMedia);

    // Set process retour
    this.setRetour(_processContext.getProcessRetour());

    // Set process response
    syncGetResponse(request_p, bl002Retour._second);

    // Set end state
    _processContext.setState(State.PE0275_END);
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startPostProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    // Call BL001
    _processContext.setState(State.PE0275_POST_BL001);
    Pair<Retour, PE0275_BL001PostRetour> retourBL001 = PE0275_BL001_VerifierDonneesCreation(tracabilite_p, request_p);
    _processContext.setProcessRetour(retourBL001._first);

    if (RetourFactory.isRetourOK(retourBL001._first))
    {
      // Call BL200
      _processContext.setState(State.PE0275_POST_BL200);
      Retour retourB200 = PE0275_BL200_CreerMessagePfs(tracabilite_p, retourBL001._second);
      _processContext.setProcessRetour(retourB200);
    }

    // Call BL002
    _processContext.setState(State.PE0275_POST_BL002);
    Pair<Retour, ReponseErreur> retourBL002 = PE0275_BL002_FormaterReponseCreation(tracabilite_p, _processContext.getProcessRetour());
    _processContext.setProcessRetour(retourBL002._first);

    // Set reponse
    syncPostResponse(request_p, retourBL002._second);

    // Set process retour
    this.setRetour(_processContext.getProcessRetour());

    // Set end state
    _processContext.setState(State.PE0275_END);
  }

  @Override
  @LogStartProcess
  protected void startPutProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    // Call BL001
    _processContext.setState(State.PE0275_PUT_BL001);
    Pair<Retour, PE0275_BL001PutRetour> retourBL001 = PE0275_BL001_VerifierDonneesModification(tracabilite_p, request_p);
    _processContext.setProcessRetour(retourBL001._first);

    if (RetourFactory.isRetourOK(retourBL001._first))
    {
      // Call BL001
      _processContext.setState(State.PE0275_PUT_BL100);
      Retour retourB100 = PE0275_BL200_ModifierMessagePfs(tracabilite_p, retourBL001._second);
      _processContext.setProcessRetour(retourB100);
    }

    // Call BL002
    _processContext.setState(State.PE0275_PUT_BL002);
    Pair<Retour, ReponseErreur> retourBL002 = PE0275_BL002_FormaterReponseModification(tracabilite_p, _processContext.getProcessRetour());
    _processContext.setProcessRetour(retourBL002._first);

    // Set reponse
    syncPutResponse(request_p, retourBL002._second);

    // Set process retour
    this.setRetour(_processContext.getProcessRetour());

    // Set end state
    _processContext.setState(State.PE0275_END);
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param reponseErreur_p
   *          variable PE0275
   */
  protected void syncDeleteResponse(Request request_p, ReponseErreur reponseErreur_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

      if (reponseErreur_p != null)
      {
        ErrorCode errorCode;
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur_p, ReponseErreur.class));
        switch (reponseErreur_p.getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ACCES_REFUSE:
            errorCode = ErrorCode.KO_00403;
            break;
          case IMegSpiritConsts.ID_MESSAGE_INCONNU:
          case IMegSpiritConsts.ACCES_MESSAGERIE_RESTREINT:
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.PFS_INDISPO:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        // Set content type
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        // Set content type
        request_p.setResponse(new Response(ErrorCode.OK_00204, ravelResponse));
      }
    }
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param pe0275BL002GetReturn_p
   *          variable PE0275
   */
  protected void syncGetResponse(Request request_p, PE0275_BL002GetReturn pe0275BL002GetReturn_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

      if (pe0275BL002GetReturn_p.getReponseErreur() != null)
      {
        ErrorCode errorCode;
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pe0275BL002GetReturn_p.getReponseErreur(), ReponseErreur.class));
        switch (pe0275BL002GetReturn_p.getReponseErreur().getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ACCES_REFUSE:
            errorCode = ErrorCode.KO_00403;
            break;
          case IMegSpiritConsts.ID_MESSAGERIE_INCONNU:
          case IMegSpiritConsts.SERVICE_NON_PROVISIONNE:
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.PFS_INDISPO:
          case IMegSpiritConsts.MIGRATION_EN_COURS:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        if (pe0275BL002GetReturn_p.getPE0275BL100Retour() != null)
        {
          ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
          ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pe0275BL002GetReturn_p.getPE0275BL100Retour(), PE0275_GetBL100Reponse.class));
        }
        else
        {
          ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_WAV);
          ravelResponse.setBinaryResult(new ByteArrayInputStream(pe0275BL002GetReturn_p.getContenuMedia()));
        }
        request_p.setResponse(new Response(ErrorCode.OK_00200, ravelResponse));
      }
    }
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param reponseErreur_p
   *          variable PE0275
   */
  protected void syncPostResponse(Request request_p, ReponseErreur reponseErreur_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

      if (reponseErreur_p != null)
      {
        ErrorCode errorCode;
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur_p, ReponseErreur.class));
        switch (reponseErreur_p.getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ACCES_REFUSE:
            errorCode = ErrorCode.KO_00403;
            break;
          case IMegSpiritConsts.ID_MESSAGE_INCONNU:
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.PFS_INDISPO:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        // Set content type
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        RavelResponse.ResponseHeader header = new ResponseHeader();
        header.setName("Location"); //$NON-NLS-1$
        String uri = "http://" + _processContext.getFrontAdress() + "/messages/" + _processContext.getIdMessagerie(); //$NON-NLS-1$//$NON-NLS-2$
        header.setValue(uri);
        ravelResponse.getResponseHeader().add(header);
        request_p.setResponse(new Response(ErrorCode.OK_00201, ravelResponse));
      }
    }
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param reponseErreur_p
   *          variable PE0275
   */
  protected void syncPutResponse(Request request_p, ReponseErreur reponseErreur_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

      if (reponseErreur_p != null)
      {
        ErrorCode errorCode;
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur_p, ReponseErreur.class));
        switch (reponseErreur_p.getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ACCES_REFUSE:
            errorCode = ErrorCode.KO_00403;
            break;
          case IMegSpiritConsts.ID_MESSAGE_INCONNU:
          case IMegSpiritConsts.ACCES_MESSAGERIE_RESTREINT:
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.PFS_INDISPO:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        // Set content type
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        request_p.setResponse(new Response(ErrorCode.OK_00204, ravelResponse));
      }
    }
  }

  /**
   * Validates that each key in headersMap_p has a value in the request_p parameter, and if yes set the corresponding
   * value.
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param request_p
   *          The request The original request containing all headers
   *
   * @return Retour OK if all the headers in the headersMap_p are set, NOK otherwise
   */
  private Retour checkRequestHeaders(Tracabilite tracabilite_p, final Request request_p)
  {
    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        _processContext.setIdRequest(header.getValue());
      }

      if (IHttpHeadersConsts.X_OAUTH2_IDCONTRATS.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        String[] listeContract = header.getValue().trim().split(StringConstants.SEMICOLON_SEPARATOR);
        for (String contract : listeContract)
        {
          String[] contractElement = contract.split(SEPARATOR);
          String[] idContract = contractElement[0].split("="); //$NON-NLS-1$
          _processContext.addContratOauth(idContract[1]);
        }
      }
    }

    // Set mode appel
    _processContext.setModeAppel(request_p.getMetadata(IMetadata.METADATA_CANAL));

    if (StringTools.isNullOrEmpty(_processContext.getIdRequest()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_REQUEST_ID)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_REQUEST_ID));
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @return HashMap<String, String> with tue URLs present
   */
  private HashMap<String, String> extractUrlParameters(final Request request_p, final Tracabilite tracabilite_p)
  {
    HashMap<String, String> urlParameters = new HashMap<>();

    // Checks if Parameters exists and set in urlParameters
    for (Parameter parameter : request_p.getUrlParameters().getUrlParameters())
    {
      if (UrlParameters.ID_MESSAGES.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        urlParameters.put(UrlParameters.ID_MESSAGES.toString(), parameter.getValue());
      }
    }
    return urlParameters;
  }

  /**
   * Load process configuration file into process context
   *
   * @return Retour
   */
  private Retour loadConfigFile()
  {

    String configAdressFront = getConfigParameter(PARAM_FRONT_ADRESSE);
    if (StringTools.isNullOrEmpty(configAdressFront))
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, PARAM_FRONT_ADRESSE));
    }
    _processContext.setFrontAdress(configAdressFront);

    // Load config
    String configPE0275Param = getConfigParameter(PARAM_CONFIG_PATH);

    if (!StringTools.isNullOrEmpty(configPE0275Param))
    {
      try
      {
        Path configPE0275Path = Paths.get(configPE0275Param);
        String configPE0275File = new String(Files.readAllBytes(configPE0275Path));
        _processContext.setConfigurationPE0275(MarshallTools.unmarshall(MessagesConfig.class, configPE0275File));

        return RetourFactory.createOkRetour();
      }
      catch (Exception exception)
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_FILE_ERROR, exception.getMessage()));
      }
    }
    return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, PARAM_CONFIG_PATH));
  }

  /**
   * PE0275_BL100_ListerAnnonce
   *
   * @param tracabilite_p
   *          tracabilite
   * @param bl001Retour_p
   *          nPE0275_BL001GetRetour
   * @return Retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Retour, PE0275_GetBL100Reponse> PE0275_BL100_ListerMessagePfs(Tracabilite tracabilite_p, PE0275_BL001GetRetour bl001Retour_p) throws RavelException
  {
    String idMessagerieDecrypted;

    // Decrypt the idMesssagerie
    try
    {
      idMessagerieDecrypted = PasswordDecrypter.decryptForURL(bl001Retour_p.getIdMessagerie());
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, "Error decrypting idOption", exception)); //$NON-NLS-1$
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGERIE_INCONNU, bl001Retour_p.getIdMessagerie())), null);
    }
    // Get the parameters type and noTelephone
    String[] parametresMessageriel = idMessagerieDecrypted.split(ID_SEPARATOR);
    if (parametresMessageriel.length != 4)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGERIE_INCONNU, bl001Retour_p.getIdMessagerie())), null);
    }
    String noContrat = parametresMessageriel[0];
    String idMessageriePfs = parametresMessageriel[1];
    String typeMessagerie = parametresMessageriel[2];
    String typePfs = parametresMessageriel[3];

    //Check Operation is authorized for this type of Messagerie
    if (!_processContext.getConfigurationPE0275().getListeTypeMessagerieAutorisee().contains(typeMessagerie))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED, bl001Retour_p.getIdMessagerie())), null);
    }

    //Authorization control of contract number
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001Retour_p.getModeAppel()))
    {
      if (CollectionUtils.isEmpty(bl001Retour_p.getListeContratOauth()) //
          || StringTools.isNullOrEmpty(noContrat) //
          || bl001Retour_p.getListeContratOauth().stream().noneMatch(c -> c.equals(noContrat)))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MESSAGE_ACCES_REFUSE), null);
      }
    }

    //Call KPSA
    ListeParametre listParametres = new ListeParametre();
    listParametres.add(KPSA_PARAM_ID_MESSAGERIE_PFS, idMessageriePfs);
    listParametres.add(KPSA_PARAM_TYPE_PFS, typePfs);

    // Call PROV_SI002
    PROV_SI002_ExecuterProcessus si002 = new PROV_SI002_ExecuterProcessusBuilder().tracabilite(tracabilite_p) //
        .cles(Collections.emptyList()) //
        .priorite(10) //
        .processus(KPSA_CONSULTER_MESSAGES_PFS) //
        .listeParametres(listParametres) //
        .build();
    ResponseConnector si002Retour = si002.execute(this);
    Retour retour = si002.getRetour();

    if (!isRetourOK(retour))
    {
      switch (retour.getCategorie())
      {
        case IMegConsts.CAT1:
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE), null);
        case IMegConsts.CAT2:
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPONIBLE), null);
        default:
          return new Pair<>(retour, null);
      }
    }

    List<PE0275_MessagesPFS> listPE0275MessagesPFS = new ArrayList<>();
    PE0275_GetBL100Reponse reponse = new PE0275_GetBL100Reponse();
    String encryptedIdMessage = null;

    ReponseFonctionnelle<MessagesPfs> responseFonctionnelle = si002Retour.getReponseFonctionnelle(MessagesPfs.class);
    if ((responseFonctionnelle != null) && (responseFonctionnelle.getResultsCount() > 0))
    {
      // Get result count
      reponse.setResultsCount(responseFonctionnelle.getResultsCount());

      for (MessagesPfs messagesPfs : responseFonctionnelle.getItems())
      {
        if (TYPE_VOIX.equals(messagesPfs.getTypeMessage()))
        {
          MessagePfsVoix messagesPfsVoix = (MessagePfsVoix) messagesPfs;
          String idMessage = noContrat + ID_SEPARATOR + typePfs + ID_SEPARATOR + idMessageriePfs + ID_SEPARATOR + messagesPfsVoix.getTypeMessage() + ID_SEPARATOR + messagesPfsVoix.getIdMessagePfs();
          encryptedIdMessage = PasswordEncrypter.encryptForURL(idMessage);

          PE0275_MessagesPFS pe0275MessagesPFS = new PE0275_MessagesPFS();
          pe0275MessagesPFS.setIdMessagerie(bl001Retour_p.getIdMessagerie());
          pe0275MessagesPFS.setIdMessage(encryptedIdMessage);
          pe0275MessagesPFS.setExpediteur(messagesPfsVoix.getExpediteur());
          pe0275MessagesPFS.setTypeMessage(messagesPfsVoix.getTypeMessage());
          pe0275MessagesPFS.setDateDepot(messagesPfsVoix.getDateDepot());
          pe0275MessagesPFS.setStatut("RECU"); //$NON-NLS-1$

          pe0275MessagesPFS.setDuree(Duration.ofSeconds(messagesPfsVoix.getDuree()).toString());
          pe0275MessagesPFS.setSuivi(new PE0275_Suivi(messagesPfsVoix.getStatutLecture(), messagesPfsVoix.getDateLecture()));

          if (IMetadata.CANAL_B2R.equalsIgnoreCase(_processContext.getModeAppel()))
          {
            // Build Action modifierStatutMessage
            pe0275MessagesPFS.putAction("modifierStatutsMessage", new XAction(URL_MESSAGES + encryptedIdMessage + "/suivi", MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$

            // Build Link TelechargerMessagePfs
            pe0275MessagesPFS.putLink("telechargerMessage", new XLink(URL_MESSAGES + encryptedIdMessage + "/contenu")); //$NON-NLS-1$

            // Build Action supprimerMessage
            pe0275MessagesPFS.putAction("supprimerMessage", new XAction(URL_MESSAGES + encryptedIdMessage, MediaType.APPLICATION_JSON, HttpConstants.DEL_METHOD)); //$NON-NLS-1$
          }
          // Add PE0275_MessagesPFS
          listPE0275MessagesPFS.add(pe0275MessagesPFS);
        }
        else if (TYPE_FAX.equals(messagesPfs.getTypeMessage()))
        {
          MessagePfsFax messagesPfsFax = (MessagePfsFax) messagesPfs;
          String idMessage = noContrat + ID_SEPARATOR + typePfs + ID_SEPARATOR + idMessageriePfs + ID_SEPARATOR + messagesPfsFax.getTypeMessage() + ID_SEPARATOR + messagesPfsFax.getIdMessagePfs();
          encryptedIdMessage = PasswordEncrypter.encryptForURL(idMessage);

          PE0275_MessagesPFS pe0275MessagesPFS = new PE0275_MessagesPFS();
          pe0275MessagesPFS.setIdMessagerie(bl001Retour_p.getIdMessagerie());
          pe0275MessagesPFS.setIdMessage(encryptedIdMessage);
          pe0275MessagesPFS.setExpediteur(messagesPfsFax.getExpediteur());
          pe0275MessagesPFS.setTypeMessage(messagesPfsFax.getTypeMessage());
          pe0275MessagesPFS.setDateDepot(messagesPfsFax.getDateDepot());
          pe0275MessagesPFS.setStatut("RECU"); //$NON-NLS-1$

          pe0275MessagesPFS.setIdCorrelation(messagesPfsFax.getIdCorrelation());
          pe0275MessagesPFS.setNbPages(messagesPfsFax.getNbPages());
          pe0275MessagesPFS.setDateEnvoi(messagesPfsFax.getDateEnvoi());
          pe0275MessagesPFS.setDestinataire(messagesPfsFax.getDestinataires()[0]);
          pe0275MessagesPFS.setEmailNotification(messagesPfsFax.getEmailNotification());
          pe0275MessagesPFS.setEmailCopieFax(messagesPfsFax.getEmailCopieFax());

          if (IMetadata.CANAL_B2R.equalsIgnoreCase(_processContext.getModeAppel()))
          {
            // Build Link TelechargerMessagePfs
            pe0275MessagesPFS.putLink("telechargerMessage", new XLink(URL_MESSAGES + encryptedIdMessage + "/contenu")); //$NON-NLS-1$

            // Build Action SupprimerMessagePfs
            pe0275MessagesPFS.putAction("supprimerMessage", new XAction(URL_MESSAGES + encryptedIdMessage, MediaType.APPLICATION_JSON, HttpConstants.DEL_METHOD)); //$NON-NLS-1$
          }
          // Add PE0275_MessagesPFS
          listPE0275MessagesPFS.add(pe0275MessagesPFS);
        }
      }
      reponse.setItems(listPE0275MessagesPFS);

      if (IMetadata.CANAL_B2R.equalsIgnoreCase(_processContext.getModeAppel()))
      {
        //Build SupprimerListeMessagePfs
        reponse.putAction("supprimerListeMessages", new XAction("/messages?idMessages=", MediaType.APPLICATION_JSON, HttpConstants.DEL_METHOD)); //$NON-NLS-1$

        // Build SelfXlink
        reponse.putLink(XLink.SELF, new XLink(URL_MESSAGERIES + bl001Retour_p.getIdMessagerie() + "/messages?format=metadata")); //$NON-NLS-1$
      }
    }

    // SPIRIT-1008
    if (reponse.getResultsCount() == null)
    {
      reponse.setResultsCount(Integer.valueOf(0));
      reponse.setItems(new ArrayList<>());
    }

    return new Pair<>(retour, reponse);
  }

  /**
   * PE0275_BL100_supprimerListeMessagePfs
   *
   * @param tracabilite_p
   *          tracabilite
   * @param bl001DeleteRetour_p
   *          PE0275_BL001DeleteRetour
   * @return Retour
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PE0275_BL100_SupprimerListeMessagePfs(Tracabilite tracabilite_p, PE0275_BL001DeleteRetour bl001DeleteRetour_p) throws RavelException
  {
    String idMessageDecrypted;
    Retour retour = RetourFactory.createOkRetour();

    // get idsMessage
    String[] idsMessagesToSupprimer = bl001DeleteRetour_p.getListIdMessage().split(","); //$NON-NLS-1$

    for (String idMessage : idsMessagesToSupprimer)
    {
      // Decrypt the idMesssage
      try
      {
        idMessageDecrypted = PasswordDecrypter.decryptForURL(idMessage);
      }
      catch (RavelException exception)
      {
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_ID_MESSAGE_INCONNU_BL100, idMessage)));
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGE_INCONNU_BL100, idMessage));
      }
      // Get the parameters
      String[] parametresMessage = idMessageDecrypted.split(ID_SEPARATOR);
      if (parametresMessage.length != 5)
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGE_INCONNU_BL100, idMessage));
      }

      String noContrat = parametresMessage[0];
      String typePfs = parametresMessage[1];
      String idMessageriePfs = parametresMessage[2];
      String typeMessage = parametresMessage[3];
      String idMessagePfs = parametresMessage[4];

      // Authorization control of contract number
      if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001DeleteRetour_p.getModeAppel()))
      {
        if (CollectionUtils.isEmpty(bl001DeleteRetour_p.getListeContratOauth()) //
            || StringTools.isNullOrEmpty(noContrat) //
            || bl001DeleteRetour_p.getListeContratOauth().stream().noneMatch(c -> c.equals(noContrat)))
        {
          return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MESSAGE_ACCES_REFUSE);
        }
      }

      // Contrôler que l’opération demande est autorisée pour le type de message
      switch (typeMessage)
      {
        case TYPE_VOIX:
          if (!_processContext.getConfigurationPE0275().getListeTypeMessagerieAutorisee().contains(typeMessage))
          {
            return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_DELETE, idMessage, typeMessage));
          }
          break;

        default:
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_DELETE, idMessage, typeMessage));
      }

      // Call KPSA
      ListeParametre listeParametre = new ListeParametre();

      listeParametre.add(KPSA_PARAM_ID_MESSAGERIE_PFS, idMessageriePfs);
      listeParametre.add(KPSA_PARAM_TYPE_PFS, typePfs);
      listeParametre.add(KPSA_PARAM_ID_MESSAGE_PFS, idMessagePfs);

      // Call PROV_SI002
      PROV_SI002_ExecuterProcessus si002 = new PROV_SI002_ExecuterProcessusBuilder().tracabilite(tracabilite_p) //
          .cles(Collections.emptyList()) //
          .priorite(10) //
          .processus(KPSA_SUPPRIMER_MESSAGE) //
          .listeParametres(listeParametre) //
          .build();
      si002.execute(this);
      retour = si002.getRetour();

      if (!isRetourOK(retour))
      {
        switch (retour.getCategorie())
        {
          case IMegConsts.CAT1:
            return RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE);
          case IMegConsts.CAT2:
            return RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPONIBLE);
          default:
            return retour;
        }
      }
    }
    return retour;
  }

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @param bl001_p
   *          tracabilite
   * @return Retour retour
   * @throws RavelException
   *           Ravel Exception
   */
  @LogProcessBL
  private Pair<Retour, byte[]> PE0275_BL200_TelechargerMessagePfs(Tracabilite tracabilite_p, PE0275_BL001GetRetour bl001_p) throws RavelException
  {
    String idMessageDecrypted;

    // Decrypt the idMessage
    try
    {
      idMessageDecrypted = PasswordDecrypter.decryptForURL(bl001_p.getIdMessage());
    }
    catch (RavelException exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, "Error decrypting idOption", exception)); //$NON-NLS-1$
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGE_INCONNU, bl001_p.getIdMessage())), null);
    }
    // Get the parameters
    String[] parametresMessage = idMessageDecrypted.split(ID_SEPARATOR);
    if (parametresMessage.length != 5)
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_MESSAGE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGE_INCONNU, bl001_p.getIdMessage())), null);
    }

    String noContrat = parametresMessage[0];
    String typePfs = parametresMessage[1];
    String idMessageriePfs = parametresMessage[2];
    String typeMessage = parametresMessage[3];
    String idMessagePfs = parametresMessage[4];

    //Contrôler que l’opération demande est autorisée pour le type de message
    switch (typeMessage)
    {
      case TYPE_VOIX:
        if (!_processContext.getConfigurationPE0275().getListeTypeMessagerieAutorisee().contains(typeMessage))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_BL200, bl001_p.getIdMessage(), typeMessage)), null);
        }
        break;

      default:
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NOT_AUTORIZED_BL200, bl001_p.getIdMessage(), typeMessage)), null);
    }

    //Authorization control of contract number
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(bl001_p.getModeAppel()))
    {
      if (CollectionUtils.isEmpty(bl001_p.getListeContratOauth()) //
          || StringTools.isNullOrEmpty(noContrat) //
          || bl001_p.getListeContratOauth().stream().noneMatch(c -> c.equals(noContrat)))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MESSAGE_ACCES_REFUSE), null);
      }
    }

    Retour retour = null;
    byte[] siRetour = null;
    if (STW.equals(typePfs))
    {
      // Call VMSSTW_SI031_telechargerAnnonceAccueil
      VMSSTW_SI028_TelechargeMessage si028 = new VMSSTW_SI028_TelechargeMessageBuilder() //
          .tracabilite(tracabilite_p) //
          .idMessagePfs(idMessagePfs) //
          .typeMessage(typeMessage) //
          .build();
      siRetour = si028.execute(this);
      retour = si028.getRetour();
    }
    else if (CVG.equals(typePfs))
    {
      // Call VMSCVM_SI025_telechargeMessage
      VMSCVM_SI025_TelechargeMessage si025 = new VMSCVM_SI025_TelechargeMessageBuilder() //
          .tracabilite(tracabilite_p) //
          .idMessagePfs(idMessagePfs) //
          .idMessageriePfs(idMessageriePfs) //
          .build();
      siRetour = si025.execute(this);
      retour = si025.getRetour();
    }

    return new Pair<>(retour, siRetour);
  }
}
