/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.structs;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.squareup.moshi.Json;

/**
 * @author fbarnabe
 * @version ($Revision$ $Date$)
 */
public class XAction implements Serializable
{
  /**
   * Serial UID
   */
  private static final long serialVersionUID = 8113343874337080307L;

  /**
   * action
   */
  @SerializedName("action")
  @Expose
  @Json(name = "action")
  private String _action;

  /**
   * type
   */
  @SerializedName("type")
  @Expose
  @Json(name = "type")
  private String _type;

  /**
   * method
   */
  @SerializedName("method")
  @Expose
  @Json(name = "method")
  private String _method;

  /**
   * Default constructor
   */
  public XAction()
  {
    // Default constructor
  }

  /**
   * Argument constructor
   *
   * @param action_p
   *          action
   * @param type_p
   *          type
   * @param method_p
   *          method
   */
  public XAction(String action_p, String type_p, String method_p)
  {
    _action = action_p;
    _type = type_p;
    _method = method_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    XAction other = (XAction) obj;
    if (_action == null)
    {
      if (other._action != null)
      {
        return false;
      }
    }
    else if (!_action.equals(other._action))
    {
      return false;
    }
    if (_method == null)
    {
      if (other._method != null)
      {
        return false;
      }
    }
    else if (!_method.equals(other._method))
    {
      return false;
    }
    if (_type == null)
    {
      if (other._type != null)
      {
        return false;
      }
    }
    else if (!_type.equals(other._type))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the action
   */
  public String getAction()
  {
    return _action;
  }

  /**
   * @return the method
   */
  public String getMethod()
  {
    return _method;
  }

  /**
   * @return the type
   */
  public String getType()
  {
    return _type;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_action == null) ? 0 : _action.hashCode());
    result = (prime * result) + ((_method == null) ? 0 : _method.hashCode());
    result = (prime * result) + ((_type == null) ? 0 : _type.hashCode());
    return result;
  }

  /**
   * @param action_p
   *          the action to set
   */
  public void setAction(String action_p)
  {
    _action = action_p;
  }

  /**
   * @param method_p
   *          the method to set
   */
  public void setMethod(String method_p)
  {
    _method = method_p;
  }

  /**
   * @param type_p
   *          the type to set
   */
  public void setType(String type_p)
  {
    _type = type_p;
  }

  @Override
  public String toString()
  {
    return "XAction [_action=" + _action + ", _type=" + _type + ", _method=" + _method + "]";
  }
}
