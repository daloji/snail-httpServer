/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 * ModifierStatutMessagerie Payload
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0274_PutRequestStatutMessagerie implements Serializable
{
  /**
   * The id for serialization
   */
  private static final long serialVersionUID = -3710216437954301712L;

  /**
   * statutMessagerie
   */
  @Json(name = "statutMessagerie")
  private String _statutMessagerie;

  /**
   * statutRappel
   */
  @Json(name = "statutRappel")
  private String _statutRappel;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0274_PutRequestStatutMessagerie other = (PE0274_PutRequestStatutMessagerie) obj;
    if (_statutMessagerie == null)
    {
      if (other._statutMessagerie != null)
      {
        return false;
      }
    }
    else if (!_statutMessagerie.equals(other._statutMessagerie))
    {
      return false;
    }
    if (_statutRappel == null)
    {
      if (other._statutRappel != null)
      {
        return false;
      }
    }
    else if (!_statutRappel.equals(other._statutRappel))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the statutMessagerie
   */
  public String getStatutMessagerie()
  {
    return _statutMessagerie;
  }

  /**
   * @return the statutRappel
   */
  public String getStatutRappel()
  {
    return _statutRappel;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_statutMessagerie == null) ? 0 : _statutMessagerie.hashCode());
    result = (prime * result) + ((_statutRappel == null) ? 0 : _statutRappel.hashCode());
    return result;
  }

  /**
   * @param statutMessagerie_p
   *          the statutMessagerie to set
   */
  public void setStatutMessagerie(String statutMessagerie_p)
  {
    _statutMessagerie = statutMessagerie_p;
  }

  /**
   * @param statutRappel_p
   *          the statutRappel to set
   */
  public void setStatutRappel(String statutRappel_p)
  {
    _statutRappel = statutRappel_p;
  }
}
