/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0276.structs;

import java.util.ArrayList;
import java.util.List;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PE0276_BL001PutRetour
{
  /**
   * Identifiant de l’annonce produit par SPIRIT
   */
  private String _idAnnonce;

  /**
   * Contenu media de l’annonce de l’accueil
   */
  private byte[] _contenuMedia;

  /**
   * Statut de l’annonce
   */
  private String _statutAnnonce;

  /**
   * Mode d’appel utilisés pour solliciter le service
   */
  private String _modeAppel;

  /**
   * Liste NoContrat B2R
   */
  private List<String> _listeContratOauth;

  /**
   * Type Operation
   */
  private OperationAnnonceAccueil _typeOperation;

  /**
   * Default constructor
    */
  public PE0276_BL001PutRetour()
  {
    // Default constructor
  }

  /**
   * @return value of _idAnnonce
   */
  public String getIdAnnonce()
  {
    return _idAnnonce;
  }

  /**
   * @param idAnnonce_p
   *     The _idAnnonce to set.
   */
  public void setIdAnnonce(String idAnnonce_p)
  {
    _idAnnonce = idAnnonce_p;
  }

  /**
   * @return value of _contenuMedia
   */
  public byte[] getContenuMedia()
  {
    return _contenuMedia == null ? null : _contenuMedia.clone();
  }

  /**
   * @param contenuMedia_p
   *     The _contenuMedia to set.
   */
  public void setContenuMedia(byte[] contenuMedia_p)
  {
    _contenuMedia = contenuMedia_p == null ? null : contenuMedia_p.clone();
  }

  /**
   * @return value of _statutAnnonce
   */
  public String getStatutAnnonce()
  {
    return _statutAnnonce;
  }

  /**
   * @param statutAnnonce_p
   *     The _statutAnnonce to set.
   */
  public void setStatutAnnonce(String statutAnnonce_p)
  {
    _statutAnnonce = statutAnnonce_p;
  }

  /**
   * @return value of _modeAppel
   */
  public String getModeAppel()
  {
    return _modeAppel;
  }

  /**
   * @param modeAppel_p
   *     The _modeAppel to set.
   */
  public void setModeAppel(String modeAppel_p)
  {
    _modeAppel = modeAppel_p;
  }

  /**
   * @return value of _listeContratOauth
   */
  public List<String> getListeContratOauth()
  {
    return _listeContratOauth != null ? new ArrayList<>(_listeContratOauth) : new ArrayList<>();
  }

  /**
   * @param listeContratOauth_p
   *     The _listeContratOauth to set.
   */
  public void setListeContratOauth(List<String> listeContratOauth_p)
  {
    _listeContratOauth = new ArrayList<>(listeContratOauth_p);
  }

  /**
   * @return value of _typeOperation
   */
  public OperationAnnonceAccueil getTypeOperation()
  {
    return _typeOperation;
  }

  /**
   * @param typeOperation_p
   *     The _typeOperation to set.
   */
  public void setTypeOperation(OperationAnnonceAccueil typeOperation_p)
  {
    _typeOperation = typeOperation_p;
  }
}
