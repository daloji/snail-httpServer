/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;
import java.util.stream.Collectors;

import org.apache.cxf.common.util.CollectionUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.BooleanTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.AbstractBLReturn;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI026_LireRessourceNoTelephone;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI026_LireRessourceNoTelephone.OSSFAI_SI026_LireRessourceNoTelephoneBuilder;
import com.bytel.spirit.common.activities.ossfai.structs.si026.OSSFAI_SI026_Return;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL5270_Return;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.ServiceTechniquePfsPcm;
import com.bytel.spirit.common.shared.functional.types.json.ServiceTechniquePfsSam;
import com.bytel.spirit.common.shared.functional.types.json.TypeUsage;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechnique;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechniqueSam;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.TypeAction;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.clf.StPfsClf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pnf.StPfsPnf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.DonneesProvisionneesStPfsSam;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.StPfsSam;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.utils.st.StLacFilter;
import com.bytel.spirit.common.shared.utils.st.StPfsClfFilter;
import com.bytel.spirit.common.shared.utils.st.StPfsPnfFilter;
import com.bytel.spirit.common.shared.utils.st.StPfsSamFilter;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_Audit;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_Erreur;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_Fax;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_FaxPFS;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_PFS;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_PfsPcm;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_PfsSam;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_Referentiel;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_Ressource;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_VoixPFS;
import com.bytel.spirit.fiat.processes.PE0302.sti.PE0302_VoixReferentiel;
import com.bytel.spirit.fiat.processes.PE0302.structs.PE0302_Retour;
import com.bytel.spirit.fiat.shared.types.json.Audit.Diagnostic;
import com.bytel.spirit.fiat.shared.types.json.Erreur.TypeError;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0302_DiagnosticServiceTelephonie extends SpiritRestApiProcessSkeleton
{

  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  public static final class PE0302_BL001Return extends AbstractBLReturn
  {

    /**
     *
     */
    private static final long serialVersionUID = 3861421266837122368L;
    /**
     * Client Operateur
     */
    private String _clientOperateur;
    /**
     * NoCompte
     */
    private String _noCompte;
    /**
     * Numero Telephone
     */
    private String _noTelephone;
    /**
     * SourceDonnee
     */
    private EnumSet<SourceDonne> _sourceDonnee;

    /**
     * Audit
     */
    private Boolean _audit;

    /**
     * IdRequest
     */
    private String _idRequest;

    /**
     * @param retour_p
     *          retour
     */

    public PE0302_BL001Return(Retour retour_p)
    {
      super(retour_p);
    }

    /**
     * @return the audit
     */
    public Boolean getAudit()
    {
      return _audit;
    }

    /**
     * @return the clientOperateur
     */
    public String getClientOperateur()
    {
      return _clientOperateur;
    }

    /**
     * @return the idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the noCompte
     */
    public String getNoCompte()
    {
      return _noCompte;
    }

    /**
     * @return the noTelephone
     */
    public String getNoTelephone()
    {
      return _noTelephone;
    }

    /**
     * @return the sourceDonnee
     */
    public EnumSet<SourceDonne> getSourceDonnee()
    {
      return _sourceDonnee.clone();
    }

    /**
     * @param audit_p
     *          the audit to set
     */
    public void setAudit(Boolean audit_p)
    {
      _audit = audit_p;
    }

    /**
     * @param clientOperateur_p
     *          the clientOperateur to set
     */
    public void setClientOperateur(String clientOperateur_p)
    {
      _clientOperateur = clientOperateur_p;
    }

    /**
     * @param idRequest_p
     *          the idRequest to set
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param noCompte_p
     *          the noCompte to set
     */
    public void setNoCompte(String noCompte_p)
    {
      _noCompte = noCompte_p;
    }

    /**
     * @param noTelephone_p
     *          the noTelephone to set
     */
    public void setNoTelephone(String noTelephone_p)
    {
      _noTelephone = noTelephone_p;
    }

    /**
     * @param sourceDonnee_p
     *          the sourceDonnee to set
     */
    public void setSourceDonnee(EnumSet<SourceDonne> sourceDonnee_p)
    {
      _sourceDonnee = sourceDonnee_p.clone();
    }

  }

  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  public static final class PE0302_BL400Return extends AbstractBLReturn
  {

    /**
     *
     */
    private static final long serialVersionUID = 3074053145034955031L;

    /**
     *
     */
    private List<PE0302_Referentiel> _listReferentiel;

    /**
     *
     */
    private List<PE0302_PFS> _listPfs;

    /**
     *
     */
    private String _idActionCorrective;

    /**
     * @param retour_p
     */
    public PE0302_BL400Return(Retour retour_p)
    {
      super(retour_p);
    }

    /**
     * @return the idActionCorrective
     */
    public String getIdActionCorrective()
    {
      return _idActionCorrective;
    }

    /**
     * @return the listPfs
     */
    public List<PE0302_PFS> getListPfs()
    {
      return _listPfs != null ? new ArrayList<>(_listPfs) : new ArrayList<>();

    }

    /**
     * @return the listReferentiel
     */
    public List<PE0302_Referentiel> getListReferentiel()
    {
      return _listReferentiel != null ? new ArrayList<>(_listReferentiel) : new ArrayList<>();
    }

    /**
     * @param idActionCorrective_p
     *          the idActionCorrective to set
     */
    public void setIdActionCorrective(String idActionCorrective_p)
    {
      _idActionCorrective = idActionCorrective_p;
    }

    /**
     * @param listPfs_p
     *          the listPfs to set
     */
    public void setListPfs(List<PE0302_PFS> listPfs_p)
    {
      _listPfs = listPfs_p != null ? new ArrayList<>(listPfs_p) : new ArrayList<>();
    }

    /**
     * @param listReferentiel_p
     *          the listReferentiel to set
     */
    public void setListReferentiel(List<PE0302_Referentiel> listReferentiel_p)
    {
      _listReferentiel = listReferentiel_p != null ? new ArrayList<>(listReferentiel_p) : new ArrayList<>();
    }

  }

  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  public static final class PE0302_DiagnosticServiceTelephonieContext extends Context
  {
    /**
     *
     */
    private static final long serialVersionUID = 4146440397576616529L;
    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0302_START;

    /**
     * NoCompte
     */
    private String _noCompte;

    /**
     * ClientOperateur
     */
    private String _clientOperateur;
    /**
     * IdContrat
     */
    private String _idContrat;

    /**
     * Indique si la comparaison entre les deux vues Référentiel et PFS doit être réalisé si l'appelant ne le précise
     * pas dans la requête émise
     */
    private Boolean _auditViews;

    /**
     * Numero Telephone
     */
    private String _noTelephone;

    /**
     * Liste des noms des vues pour lesquels le service est ouvert
     */
    private EnumSet<SourceDonne> _sourceDonnes;

    /**
     * IdRequest
     */
    private String _idRequest;

    /**
     *
     */
    private StPfsSam _stPfsSam;

    /**
     * @return the auditViews
     */
    public Boolean getAuditViews()
    {
      return _auditViews;
    }

    /**
     * @return the clientOperateur
     */
    public String getClientOperateur()
    {
      return _clientOperateur;
    }

    /**
     * @return the idContract
     */
    public String getIdContract()
    {
      return _idContrat;
    }

    /**
     * @return the idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the noCompte
     */
    public String getNoCompte()
    {
      return _noCompte;
    }

    /**
     * @return the noTelephone
     */
    public String getNoTelephone()
    {
      return _noTelephone;
    }

    /**
     * @return the sourceDonnes
     */
    public EnumSet<SourceDonne> getSourceDonnes()
    {
      return _sourceDonnes.clone();
    }

    /**
     * @return value of state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the stPfsSam
     */
    public StPfsSam getStPfsSam()
    {
      return _stPfsSam;
    }

    /**
     * @param auditViews_p
     *          the auditViews to set
     */
    public final void setAuditViews(final Boolean auditViews_p)
    {
      _auditViews = auditViews_p;
    }

    /**
     * @param clientOperateur_p
     *          the clientOperateur to set
     */
    public void setClientOperateur(String clientOperateur_p)
    {
      _clientOperateur = clientOperateur_p;
    }

    /**
     * @param idContrat_p
     *          the idContrat to set
     */
    public void setIdContrat(String idContrat_p)
    {
      _idContrat = idContrat_p;
    }

    /**
     * @param idRequest_p
     *          the idRequest to set
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param noCompte_p
     *          the noCompte to set
     */
    public void setNoCompte(String noCompte_p)
    {
      _noCompte = noCompte_p;
    }

    /**
     * @param noTelephone_p
     */
    public void setNoTelephone(String noTelephone_p)
    {
      _noTelephone = noTelephone_p;

    }

    /**
     * @param sourceDonnes_p
     *          the sourceDonnes to set
     */
    public void setSourceDonnes(EnumSet<SourceDonne> sourceDonnes_p)
    {
      if (sourceDonnes_p != null)
      {
        _sourceDonnes = sourceDonnes_p.clone();
      }
      else
      {
        _sourceDonnes = EnumSet.noneOf(SourceDonne.class);
      }
    }

    /**
     * @param state_p
     *          The state to set.
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param stPfsSam_p
     */
    public void setStPfsSam(StPfsSam stPfsSam_p)
    {
      _stPfsSam = stPfsSam_p;

    }

  }

  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  public enum SourceDonne
  {
    /**
    *
    */
    REFERENTIEL,
    /**
    *
    */
    PFS
  }

  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0302_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call BL001
     */
    PE0302_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL002
     */
    PE0302_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL100
     */
    PE0302_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL200
     */
    PE0302_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL201
     */
    PE0302_BL201(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL300
     */
    PE0302_BL300(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL301
     */
    PE0302_BL301(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call SI002
     */
    PE0302_SI002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL302
     */
    PE0302_BL302(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL400
     */
    PE0302_BL400(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL5100
     */
    PE0302_BL5100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call BL5270
     */
    PE0302_BL5270(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PE0302_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  protected enum UrlParameters
  {
    /**
     * loginMail
     */
    NOTELEPHONE("noTelephone"), //$NON-NLS-1$
    /**
     * sourceDonnee
     */
    SOURCE_DONNE("sourceDonnee"), //$NON-NLS-1$
    /**
     * audit
     */
    AUDIT("audit"); //$NON-NLS-1$

    /**
    *
    */
    private String _paramName;

    /**
     * @param name_p
     *          name
     */
    private UrlParameters(String name_p)
    {
      setParamName(name_p);
    }

    /**
     * @return the paramName
     */
    public String getParamName()
    {
      return _paramName;
    }

    /**
     * @param paramName_p
     *          the paramName to set
     */
    public void setParamName(String paramName_p)
    {
      _paramName = paramName_p;
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = 7010714543376812138L;

  /**
   * separator of sourceDonne url parameter
   */
  private static final String SOURCE_DONNES_SEPARATOR = ","; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String AUDIT_VUES = "auditVues"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String SOURCE_DONNEE_DEFAULT_PARAM_NAME = "sourceDonneeParDefaut"; //$NON-NLS-1$

  /**
   * Priority to set in the call to KPSA DIAG in BL300
   */
  private static final int KPSA_DIAG_PRIORITE = 10;

  /**
   * Constant
   */
  private static final String ERROR_CREATION_ACTION_CORRECTIVE = Messages.getString("PE0302.BL400.ErrorDescrition"); //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String SAM = "SAM"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String NO_TELEPHONE = "NO_TELEPHONE"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String NUMERO_TELEPHONE = "NUMERO_TELEPHONE"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String FIXE = "FIXE"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String VOIX = "VOIX"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String FAX = "FAX"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String RESTREINT = "RESTREINT"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String ACTIF = "ACTIF"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String EN_COURS = "EN_COURS"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String REALISE = "REALISE"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String ECHEC = "ECHEC"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String TELEPHONIE = "TELEPHONIE"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String CONSULTER_SERVICE_TECHNIQUE_PFSSAM = "consulterServiceTechniquePfsSam"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String CONSULTER_SERVICE_TECHNIQUE_PFSPCM = "consulterServiceTechniquePfsPcm"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String SERVICE_NON_PROVISIONNE = "SERVICE_NON_PROVISIONNE"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String PFS_INDISPONIBLE = "PFS_INDISPONIBLE"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String ERREUR_INTERNE = "ERREUR_INTERNE"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String INACTIF = "INACTIF"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String NOM_PRENOM_COURT = "nomPrenomCourt"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String NIVEAU_RESTRICTION = "niveauRestriction"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String DESYNCHRO_PFS = "DESYNCHRO_PFS"; //$NON-NLS-1$

  /**
   * Message
   */
  private static final String DESYNCHRO_PFS_LIBELLE = Messages.getString("PE0302.BL400.Desynchronisation"); //$NON-NLS-1$

  /**
   * Message
   */
  private static final String PROBLEME_QOD_RESSOURCES = Messages.getString("PE0302.BL201.ProblemeQodRessources"); //$NON-NLS-1$

  /**
   * Constant
   */
  private static final Object NON_RESTREINT = "NON_RESTREINT"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String EN_COMMUNICATION = "EN_COMMUNICATION"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String LIBRE = "LIBRE"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String OPTION_APPEL_SUR_TAXES = "OptionAppelSurTaxes"; //$NON-NLS-1$

  /**
   * The process context.
   */
  private PE0302_DiagnosticServiceTelephonieContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour arg0_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();

  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0302_DiagnosticServiceTelephonieContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    // Not required for now in Ravel
  }

  /**
   *
   */

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    PE0302_BL001Return bl001Return = new PE0302_BL001Return(RetourFactory.createOkRetour());

    List<PE0302_PFS> listPfs = null;
    List<PE0302_Referentiel> listReferentiel = null;
    String idActionCorrective = null;
    try
    {
      getProcessConfigParameters(tracabilite_p);
      _processContext.setState(State.PE0302_BL001);
      bl001Return = PE0302_BL001_VerifierDonnees(tracabilite_p, request_p);
      retour = bl001Return.getRetour();

      if (isRetourOK(retour))
      {
        _processContext.setState(State.PE0302_BL200);
        Pair<Retour, List<PE0302_Referentiel>> bl200Return = PE0302_BL200_ConstruireVueReferentiel(tracabilite_p, bl001Return.getNoTelephone(), bl001Return.getClientOperateur(), bl001Return.getNoCompte(), bl001Return.getSourceDonnee());
        retour = bl200Return._first;
        listReferentiel = bl200Return._second;
        if (isRetourOK(retour))
        {
          _processContext.setState(State.PE0302_BL300);
          Pair<Retour, List<PE0302_PFS>> bl300Return = PE0302_BL300_ConstruireVuePfs(tracabilite_p, bl001Return.getNoTelephone(), bl001Return.getSourceDonnee(), listReferentiel);
          retour = bl300Return._first;
          listPfs = bl300Return._second;

          _processContext.setState(State.PE0302_BL400);
          PE0302_BL400Return bl400Return = PE0302_BL400_ComparerVues(tracabilite_p, bl001Return.getClientOperateur(), bl001Return.getNoCompte(), listReferentiel, listPfs, bl001Return.getSourceDonnee(), bl001Return.getAudit());
          retour = bl400Return.getRetour();
          listPfs = bl400Return.getListPfs();
          listReferentiel = bl400Return.getListReferentiel();
          idActionCorrective = bl400Return.getIdActionCorrective();

        }
      }
    }
    catch (final Exception e)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
    }
    finally
    {
      _processContext.setState(State.PE0302_BL002);
      PE0302_Retour processRetour = PE0302_BL002_FormaterReponse(tracabilite_p, retour, listPfs, listReferentiel, idActionCorrective);
      setRetour(retour);
      syncResponse(tracabilite_p, request_p, processRetour);
      _processContext.setState(State.PE0302_END);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel

  }

  /**
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @return Retour
   */
  private Retour checkAndExtractHeaders(final Request request_p, Tracabilite tracabilite_p)
  {

    Retour retour = RetourFactory.createOkRetour();

    // Verifying if Headers exists

    String process = null;
    String source = null;
    String requestId = null;
    String actionId = null;
    String messageId = null;

    // Verifying if Headers exists

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        source = header.getValue();
      }
      else if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()))
      {
        requestId = header.getValue();
      }
      else if (IHttpHeadersConsts.X_MESSAGE_ID.equalsIgnoreCase(header.getName()))
      {
        messageId = header.getValue();
      }
      else if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        process = header.getValue();
      }
      else if (IHttpHeadersConsts.X_ACTION_ID.equalsIgnoreCase(header.getName()))
      {
        actionId = header.getValue();
      }
    }

    // check if  one or more of headers are missing
    if (StringTools.containsOneNullOrEmpty(source, requestId, messageId, process, actionId))
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$
      if (StringTools.isNullOrEmpty(source))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), IHttpHeadersConsts.X_SOURCE)); //$NON-NLS-1$
      }
      if (StringTools.isNullOrEmpty(requestId))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), IHttpHeadersConsts.X_REQUEST_ID)); //$NON-NLS-1$
      }
      if (StringTools.isNullOrEmpty(messageId))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), IHttpHeadersConsts.X_MESSAGE_ID)); //$NON-NLS-1$
      }
      if (StringTools.isNullOrEmpty(process))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), IHttpHeadersConsts.X_PROCESS)); //$NON-NLS-1$
      }
      if (StringTools.isNullOrEmpty(actionId))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), IHttpHeadersConsts.X_ACTION_ID)); //$NON-NLS-1$
      }
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, joiner.toString());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, joiner.toString()));

    }
    else
    {
      _processContext.setIdRequest(requestId);
    }
    return retour;
  }

  /**
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @return Retour Check if Url Parameters are Ok
   */
  private Retour checkAndExtractUrlParameters(final Request request_p, final Tracabilite tracabilite_p)
  {
    Retour retour = RetourFactory.createOkRetour();

    String noTelephone = null;
    String sourceDonnee = null;
    String audit = null;

    // Checks if Parameters exists
    for (Parameter parameter : request_p.getUrlParameters().getUrlParameters())
    {
      if (UrlParameters.NOTELEPHONE.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        noTelephone = parameter.getValue();
      }
      else if (UrlParameters.SOURCE_DONNE.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        sourceDonnee = parameter.getValue();
      }
      else if (UrlParameters.AUDIT.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        audit = parameter.getValue();
      }
    }

    // Check combinations of parameters required

    if (StringTools.isNotNullOrEmpty(noTelephone))
    {
      if (!isValidNoTelephone(noTelephone))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0302.BL001.NoTelephoneInvalide"), noTelephone)); //$NON-NLS-1$
        return retour;
      }
      _processContext.setNoTelephone(noTelephone);
    }
    else
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0302.BL001.MissingParameter"), UrlParameters.NOTELEPHONE.getParamName())); //$NON-NLS-1$
      return retour;
    }

    EnumSet<SourceDonne> sourceDonnesSet = EnumSet.noneOf(SourceDonne.class);
    try
    {
      //validate parameter sourceDonne if present
      sourceDonnesSet = extractSourceDonneFromStringParam(sourceDonnee);
    }
    finally
    {
      if ((sourceDonnesSet.isEmpty() && StringTools.isNotNullOrEmpty(sourceDonnee))) //param sourceDonne contains invalid values
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0302.BL001.SourceDonneeInvalide"), sourceDonnee)); //$NON-NLS-1$
        return retour;
      }
      if (!sourceDonnesSet.isEmpty())
      {
        _processContext.setSourceDonnes(sourceDonnesSet);
      } //if sourceDonne not present in URL parameters the value will be the specified in the process configuration, REFERENTIEL by default
    }

    if (StringTools.isNotNullOrEmpty(audit))//TODO: validate the link between source (STI)
    {
      Boolean auditBool = getAuditValue(audit);
      if (auditBool != null)
      {
        _processContext.setAuditViews(Boolean.valueOf(audit));
      }
    }

    return retour;

  }

  /**
   * Add the possible values of parameter sourceDonne to a Set of type SourceDonne
   *
   * @param sourceDonne_p
   *          The sourceDonne parameter
   * @return The Set containing the sourceDonne values, null if the sourceDonne_p contains invalid values or empty set
   *         if sourceDonne_p is empty
   */
  private EnumSet<SourceDonne> extractSourceDonneFromStringParam(String sourceDonne_p)
  {
    EnumSet<SourceDonne> sourceDonnes = EnumSet.noneOf(SourceDonne.class);

    if (StringTools.isNotNullOrEmpty(sourceDonne_p))
    {
      String[] sourceDonneStr = sourceDonne_p.trim().split(SOURCE_DONNES_SEPARATOR);
      for (String sd : sourceDonneStr)
      {
        if (StringTools.isNotNullOrEmpty(sd))
        {
          SourceDonne sourceDonne;
          try
          {
            sourceDonne = SourceDonne.valueOf(sd.trim());
            sourceDonnes.add(sourceDonne);
          }
          catch (Exception ex)
          {
            throw new IllegalArgumentException(MessageFormat.format(Messages.getString("PE0302.BL001.SourceDonneeInvalide"), sourceDonne_p)); //$NON-NLS-1$
          }
        }

      }
    }
    return sourceDonnes;
  }

  /**
   * Find the diagnostic_p parameter in the list of PE0302_Audit audits_p.
   *
   * @param pe0302_Audit_p
   *          The PE0302_Audit list to find the diagnostic
   * @param diagnostic_p
   *          The diagnostic to find for
   * @return The PE0302_Audit object if found, null otherwise
   */
  private PE0302_Audit findAuditByDiagnostique(List<PE0302_Audit> pe0302_Audit_p, Diagnostic diagnostic_p)
  {
    if ((diagnostic_p != null) && !CollectionUtils.isEmpty(pe0302_Audit_p))
    {
      for (PE0302_Audit audit : pe0302_Audit_p)
      {
        if (diagnostic_p.name().equals(audit.getDiagnostic()))
        {
          return audit;
        }
      }
    }
    return null;
  }

  /**
   * Get boolean value of audit parameter.
   *
   * @param audit_p
   *          The String audit parameter
   * @return The boolean value of audit
   */
  private Boolean getAuditValue(String audit_p)
  {
    Boolean audit = null;
    if (StringTools.isNotNullOrEmpty(audit_p))
    {
      try
      {
        audit = BooleanTools.toBooleanIgnoreCase(audit_p);
      }
      catch (Exception ex)
      {
        //ignore
      }
    }
    return audit;
  }

  /**
   * Load process parameters into the process context
   *
   * @param tracabilite_p
   *          Tracabilite
   */
  private void getProcessConfigParameters(final Tracabilite tracabilite_p)
  {
    final String sourceDonneeConfig = getConfigParameter(SOURCE_DONNEE_DEFAULT_PARAM_NAME);

    EnumSet<SourceDonne> sourceDonne = EnumSet.noneOf(SourceDonne.class);
    try
    {
      sourceDonne = extractSourceDonneFromStringParam(sourceDonneeConfig);
    }
    catch (IllegalArgumentException e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, MessageFormat.format(Messages.getString("PE0302.BL001.InvalidParameterValue"), "sourceDonneeAutorise", "[REFRENTIEL, PFS]"))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
    finally
    {
      if (sourceDonne.isEmpty())
      {//Set sourceDonne by default ( [REFRENTIEL, PFS])

        sourceDonne = EnumSet.allOf(SourceDonne.class);
      }
      _processContext.setSourceDonnes(sourceDonne);
    }

    final String auditConfig = getConfigParameter(AUDIT_VUES);

    if (StringTools.isNotNullOrEmpty(auditConfig))
    {
      Boolean auditBool = getAuditValue(auditConfig);
      _processContext.setAuditViews(auditBool);
    }
    else
    {//set audit by default
      RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, MessageFormat.format(Messages.getString("PE0302.BL001.InvalidParameterValue"), "auditVues", "false"))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      _processContext.setAuditViews(false);
    }
  }

  /**
   * @param noTelephone_p
   * @return
   */
  private boolean isValidNoTelephone(String noTelephone_p)
  {
    // TODO: Create validation
    return StringTools.isNotNullOrEmpty(noTelephone_p);
  }

  /**
   * @param tracabilite_p
   * @param request_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private PE0302_BL001Return PE0302_BL001_VerifierDonnees(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {

    final PE0302_BL001Return bl001return = new PE0302_BL001Return(RetourFactory.createOkRetour());

    Retour urlHeadersRetour = checkAndExtractHeaders(request_p, tracabilite_p);

    //return if headears are not conform as on STI
    if (!RetourFactory.isRetourOK(urlHeadersRetour))
    {
      bl001return.setRetour(urlHeadersRetour);
      return bl001return;
    }

    Retour urlParametersRetour = checkAndExtractUrlParameters(request_p, tracabilite_p);

    //return if parameters are not conform as on STI
    if (!RetourFactory.isRetourOK(urlParametersRetour))
    {
      bl001return.setRetour(urlParametersRetour);
      return bl001return;
    }

    bl001return.setNoTelephone(_processContext.getNoTelephone());
    bl001return.setSourceDonnee(_processContext.getSourceDonnes());
    bl001return.setAudit(_processContext.getAuditViews());
    bl001return.setIdRequest(_processContext.getIdRequest());

    if (StringTools.isNotNullOrEmpty(bl001return.getNoTelephone()) && bl001return.getSourceDonnee().contains(SourceDonne.REFERENTIEL))
    {
      _processContext.setState(State.PE0302_BL5270);
      final BL5270_RecupererPfiParNoTelephone bl5270 = new BL5270_RecupererPfiParNoTelephoneBuilder().tracabilite(tracabilite_p).noTelephone(bl001return.getNoTelephone()).build();
      BL5270_Return bl5270Reponse = bl5270.execute(this);

      if (!isRetourOK(bl5270.getRetour()))
      {
        if (IMegConsts.CAT4.equals(bl5270.getRetour().getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(bl5270.getRetour().getDiagnostic()))
        {
          bl001return.setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_INCONNU, MessageFormat.format(Messages.getString("PE0302.BL001.TelephoneIconnu"), bl001return.getNoTelephone()))); //$NON-NLS-1$
        }
        else
        {
          bl001return.setRetour(bl5270.getRetour());
        }
      }
      else
      {
        bl001return.setNoCompte(bl5270Reponse.getNoCompte());
        bl001return.setClientOperateur(bl5270Reponse.getClientOperateur());
        _processContext.setIdContrat(bl5270Reponse.getNoContrat());
      }
    }
    _processContext.setNoCompte(bl001return.getNoCompte());
    _processContext.setClientOperateur(bl001return.getClientOperateur());

    return bl001return;

  }

  /**
   * @param tracabilite_p
   * @param retour_p
   * @param listPfs_p
   * @param listReferentiel_p
   * @param idActionCorrective_p
   * @return
   */
  @LogProcessBL
  private PE0302_Retour PE0302_BL002_FormaterReponse(Tracabilite tracabilite_p, Retour retour_p, List<PE0302_PFS> listPfs_p, List<PE0302_Referentiel> listReferentiel_p, String idActionCorrective_p)
  {
    PE0302_Retour processRetour = new PE0302_Retour();

    if (RetourFactory.isRetourKO(retour_p))
    {
      PE0302_Erreur reponseErreur = new PE0302_Erreur();
      reponseErreur.setError(retour_p.getDiagnostic());
      reponseErreur.setErrorDescription(retour_p.getLibelle());
      processRetour.setReponseErreur(reponseErreur);
    }
    else
    {
      processRetour.setReferentiels(listReferentiel_p);
      processRetour.setPfs(listPfs_p);
      processRetour.setIdActionCorrective(idActionCorrective_p);
    }
    processRetour.setRetour(retour_p);

    return processRetour;
  }

  /**
   * @param tracabilite_p
   * @param noTelephone_p
   * @param clientOperateur_p
   * @param noCompte_p
   * @param sourceDonnee_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private Pair<Retour, List<PE0302_Referentiel>> PE0302_BL200_ConstruireVueReferentiel(Tracabilite tracabilite_p, String noTelephone_p, String clientOperateur_p, String noCompte_p, EnumSet<SourceDonne> sourceDonnee_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    List<PE0302_Referentiel> listReferentiel = null;

    if (sourceDonnee_p.contains(SourceDonne.REFERENTIEL))
    {
      StLienAllocationCommercial stLacNoTelephone = null;
      StLienAllocationCommercial stLacImpiFixe = null;
      StPfsClf stPfsClf = null;
      StPfsSam stPfsSam = null;
      StPfsPnf stPfsPnf = null;
      listReferentiel = new ArrayList<>();
      ConnectorResponse<Retour, List<ServiceTechnique>> rstProxy = RSTProxy.getInstance().serviceTechniqueLireTousParPfi(tracabilite_p, clientOperateur_p, noCompte_p, null, null);
      if (!isRetourOK(rstProxy._first))
      {
        if (!IMegConsts.CAT4.equals(rstProxy._first.getCategorie()) || !IMegConsts.DONNEE_INCONNUE.equals(rstProxy._first.getDiagnostic()))
        {
          retour = rstProxy._first;
          return new Pair<Retour, List<PE0302_Referentiel>>(retour, listReferentiel);
        }
      }
      List<ServiceTechnique> listStPfi = rstProxy._second;
      if (!CollectionUtils.isEmpty(listStPfi))
      {
        List<ServiceTechnique> listStLacNoTelephone = new StLacFilter()//
            .whereStatutIsNot(Statut.INACTIF)//
            .whereTypeRessourceIsEqual(TypeRessource.NUMERO_TELEPHONE)//
            .whereIdRessourceIsEqual(noTelephone_p)//
            .filter(listStPfi);

        if (!CollectionUtils.isEmpty(listStLacNoTelephone))
        {
          stLacNoTelephone = (StLienAllocationCommercial) listStLacNoTelephone.get(0);

          if (stLacNoTelephone != null)
          {
            stLacImpiFixe = new StLacFilter()//
                .whereStatutIsNot(Statut.INACTIF)//
                .whereTypeRessourceIsEqual(TypeRessource.IMPI_FIXE)//
                .whereIdentifiantFonctionnelPaIsEqual(stLacNoTelephone.getOcIdentifiantFonctionnelPA())//
                .getFirst(listStPfi);

            stPfsClf = new StPfsClfFilter()//
                .whereStatutIsNot(Statut.INACTIF)//
                .whereIdentifiantFonctionnelPaIsEqual(stLacNoTelephone.getOcIdentifiantFonctionnelPA())//
                .getFirst(listStPfi);

            stPfsSam = new StPfsSamFilter()//
                .whereStatutIsNot(Statut.INACTIF)//
                .whereIdentifiantFonctionnelPaIsEqual(stLacNoTelephone.getOcIdentifiantFonctionnelPA())//
                .getFirst(listStPfi);
            _processContext.setStPfsSam(stPfsSam);

            stPfsPnf = new StPfsPnfFilter().whereStatutIsNot(Statut.INACTIF)//
                .whereIdentifiantFonctionnelPaIsEqual(stLacNoTelephone.getOcIdentifiantFonctionnelPA())//
                .getFirst(listStPfi);

          }
        }
      }
      _processContext.setState(State.PE0302_BL201);
      Pair<PE0302_Referentiel, Retour> bl201return = PE0302_BL201_CreerObjetReferentiel(tracabilite_p, noTelephone_p, stLacNoTelephone, stLacImpiFixe, stPfsSam, stPfsPnf, stPfsClf);
      listReferentiel.add(bl201return._first);
    }
    return new Pair<Retour, List<PE0302_Referentiel>>(retour, listReferentiel);
  }

  /**
   * @param tracabilite_p
   * @param noTelephone_p
   * @param stLacNoTelephone_p
   * @param stLacImpiFixe_p
   * @param stPfsSam_p
   * @param stPfsPnf_p
   * @param stPfsClf_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private Pair<PE0302_Referentiel, Retour> PE0302_BL201_CreerObjetReferentiel(Tracabilite tracabilite_p, String noTelephone_p, StLienAllocationCommercial stLacNoTelephone_p, StLienAllocationCommercial stLacImpiFixe_p, StPfsSam stPfsSam_p, StPfsPnf stPfsPnf_p, StPfsClf stPfsClf_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    PE0302_Referentiel referentiel = new PE0302_Referentiel();
    referentiel.setNoTelephone(noTelephone_p);
    referentiel.setTypeService(TELEPHONIE);

    OSSFAI_SI026_LireRessourceNoTelephone si026 = new OSSFAI_SI026_LireRessourceNoTelephoneBuilder().tracabilite(tracabilite_p).noTelephone(noTelephone_p).build();
    OSSFAI_SI026_Return response = si026.execute(this);

    if (!isRetourOK(si026.getRetour()))
    {
      PE0302_Erreur erreur = new PE0302_Erreur();
      erreur.setError(ERREUR_INTERNE);
      erreur.setErrorDescription(MessageFormat.format(PROBLEME_QOD_RESSOURCES, NO_TELEPHONE, si026.getRetour().getDiagnostic()));
      List<PE0302_Erreur> erreurs = new ArrayList<>();
      erreurs.add(erreur);
      referentiel.setErreurs(erreurs);
    }
    else
    {
      List<PE0302_Ressource> listRessources = referentiel.getRessources();
      PE0302_Ressource ressource = new PE0302_Ressource();
      ressource.setType(NUMERO_TELEPHONE);
      ressource.setEtatRessource(response.getStatut());

      if ((stLacNoTelephone_p != null))
      {
        if (Statut.ACTIF.toString().equals(stLacNoTelephone_p.getStatut()))
        {
          ressource.setEtatAllocation(REALISE);
        }
        else if (Statut.ECHEC.toString().equals(stLacNoTelephone_p.getStatut()))
        {
          ressource.setEtatAllocation(ECHEC);
        }
        else
        {
          ressource.setEtatAllocation(EN_COURS);
        }
      }
      else
      {
        ressource.setEtatAllocation(EN_COURS);
      }
      listRessources.add(ressource);
      referentiel.setRessources(listRessources);
    }

    //Mapping du parametre etatProvisioning
    if ((stLacNoTelephone_p == null) && (stLacImpiFixe_p == null) && (stPfsSam_p == null) && (stPfsPnf_p == null) && (stPfsClf_p == null))
    {
      referentiel.setEtatProvisioning(EN_COURS);
    }
    else if (((stLacNoTelephone_p != null) && Statut.ECHEC.toString().equals(stLacNoTelephone_p.getStatut())) || ((stLacImpiFixe_p != null) && Statut.ECHEC.toString().equals(stLacImpiFixe_p.getStatut())) || ((stPfsSam_p != null) && Statut.ECHEC.toString().equals(stPfsSam_p.getStatut())) || ((stPfsPnf_p != null) && Statut.ECHEC.toString().equals(stPfsPnf_p.getStatut())) || ((stPfsClf_p != null) && Statut.ECHEC.toString().equals(stPfsClf_p.getStatut())))
    {
      referentiel.setEtatProvisioning(ECHEC);

    }
    else if ((stLacNoTelephone_p != null) && (stLacImpiFixe_p != null) && (stPfsSam_p != null) && (stPfsPnf_p != null))
    {
      DonneesProvisionneesStPfsSam donnesProvisionneesSam = stPfsSam_p.getDonneesProvisionneesStPfsSam();
      if (Statut.ACTIF.toString().equals(stLacNoTelephone_p.getStatut()) //
          && Statut.ACTIF.toString().equals(stLacImpiFixe_p.getStatut()) //
          && Statut.ACTIF.toString().equals(stPfsSam_p.getStatut()) //
          && (donnesProvisionneesSam != null) && noTelephone_p.equals(stPfsSam_p.getDonneesProvisionneesStPfsSam().getNoTelephone()) //
          && Statut.ACTIF.toString().equals(stPfsPnf_p.getStatut()) //
          && (stPfsPnf_p.getDonneesProvisionnees() != null) && noTelephone_p.equals(stPfsPnf_p.getDonneesProvisionneesStPfsPnf().getNoTelephone()) //
          && ((VOIX.equals(donnesProvisionneesSam.getTypeUsage()) && (stPfsClf_p != null) && Statut.ACTIF.toString().equals(stPfsClf_p.getStatut())) //
              || (FAX.equals(donnesProvisionneesSam.getTypeUsage()) && (stPfsClf_p == null))) //
      )
      {
        referentiel.setEtatProvisioning(REALISE);
      }
      else
      {
        referentiel.setEtatProvisioning(EN_COURS);
      }
    }
    else
    {
      referentiel.setEtatProvisioning(EN_COURS);
    }

    if ((stPfsSam_p != null) && (stPfsSam_p.getDonneesProvisionneesStPfsSam() != null) && (stPfsSam_p.getDonneesProvisionneesStPfsSam().getTypeUsage() != null))
    {
      List<ServiceTechnique> listSts = referentiel.getSt();
      listSts.add(stPfsSam_p);
      referentiel.setSt(listSts);

      DonneesProvisionneesStPfsSam donnesProvisionnees = stPfsSam_p.getDonneesProvisionneesStPfsSam();

      List<String> typeUsages = referentiel.getTypeUsages();
      typeUsages.add(donnesProvisionnees.getTypeUsage());
      referentiel.setTypeUsages(typeUsages);

      if (VOIX.equals(donnesProvisionnees.getTypeUsage()))
      {
        PE0302_VoixReferentiel voix = new PE0302_VoixReferentiel();
        voix.setTypeReseau(FIXE);
        voix.setNiveauRestriction(donnesProvisionnees.getNiveauRestriction());
        List<String> impi = voix.getImpi();
        impi.add(donnesProvisionnees.getImpiFixe());
        voix.setImpi(impi);
        List<String> impu = voix.getImpu();
        impu.add(donnesProvisionnees.getSipUri());
        impu.add(donnesProvisionnees.getTelUri());
        voix.setImpu(impu);
        voix.setNomPrenomCourt(donnesProvisionnees.getNomPrenomCourt());
        voix.setNom(donnesProvisionnees.getNom());
        voix.setPrenom(donnesProvisionnees.getPrenom());
        voix.setOptionAppelSurTaxes(donnesProvisionnees.getOptionAppelSurTaxes());
        referentiel.setVoix(voix);

        if (NON_RESTREINT.equals(donnesProvisionnees.getNiveauRestriction()))
        {
          voix.setStatut(ACTIF);
        }
        else
        {
          voix.setStatut(RESTREINT);
        }
        if ((stPfsClf_p != null) && (stPfsClf_p.getDonneesProvisionnees() != null))
        {
          voix.setCodeINSEE(stPfsClf_p.getDonneesProvisionneesStPfsClf().getCodeInsee());
        }
      }
      else
      {
        PE0302_Fax fax = new PE0302_Fax();
        fax.setTypeReseau(FIXE);
        List<String> impi = fax.getImpi();
        impi.add(donnesProvisionnees.getImpiFixe());
        fax.setImpi(impi);
        List<String> impu = fax.getImpu();
        impu.add(donnesProvisionnees.getSipUri());
        impu.add(donnesProvisionnees.getTelUri());
        fax.setImpu(impu);
        referentiel.setFax(fax);
      }
      referentiel.setNoCompte(stPfsSam_p.getNoCompte());
      referentiel.setClientOperateur(stPfsSam_p.getClientOperateur());
    }

    return new Pair<PE0302_Referentiel, Retour>(referentiel, retour);
  }

  /**
   * @param tracabilite_p
   * @param noTelephone_p
   * @param sourceDonnee_p
   * @param listReferentiel_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private Pair<Retour, List<PE0302_PFS>> PE0302_BL300_ConstruireVuePfs(Tracabilite tracabilite_p, String noTelephone_p, EnumSet<SourceDonne> sourceDonnee_p, List<PE0302_Referentiel> listReferentiel_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    Retour retourBloquant = null;
    List<PE0302_PFS> listPfs = null;
    ResponseConnector response = null;
    PROV_SI002_ExecuterProcessus provSI002 = null;

    if (sourceDonnee_p.contains(SourceDonne.PFS))
    {
      listPfs = new ArrayList<>();
      provSI002 = new PROV_SI002_ExecuterProcessusBuilder().tracabilite(tracabilite_p)//set Tracabilite
          .priorite(KPSA_DIAG_PRIORITE)//set priority
          .processus(CONSULTER_SERVICE_TECHNIQUE_PFSSAM)//set Process name to call
          .noms(Arrays.asList("noTelephone")) //set names //$NON-NLS-1$
          .valeurs(Arrays.asList(noTelephone_p))//set values
          .build();
      response = provSI002.execute(this);
      ServiceTechniquePfsSam stPfsSam = null;

      retour = provSI002.getRetour();

      if (!isRetourOK(retour) && IMegConsts.CAT1.equals(retour.getCategorie()))
      {
        retourBloquant = retour;
      }

      if (isRetourOK(retour))
      {
        ReponseFonctionnelle<ServiceTechniquePfsSam> functionalResponse = response.getReponseFonctionnelle(ServiceTechniquePfsSam.class);
        if (functionalResponse != null)
        {
          List<ServiceTechniquePfsSam> listeStPfsSam = functionalResponse.getItems();
          if (!CollectionUtils.isEmpty(listeStPfsSam))
          {
            stPfsSam = listeStPfsSam.get(0);
          }
        }
      }
      _processContext.setState(State.PE0302_BL301);
      Pair<Retour, PE0302_PFS> bL301Retour = PE0302_BL301_CreerObjetPfsSam(tracabilite_p, noTelephone_p, retour, stPfsSam);
      listPfs.add(bL301Retour._second);
      retour = bL301Retour._first;

      if ((retourBloquant == null) && (listReferentiel_p != null) && !CollectionUtils.isEmpty(listReferentiel_p))
      {
        List<PE0302_Referentiel> referentielWithFax = (listReferentiel_p.stream().filter(x -> x.getFax() != null).collect(Collectors.toList()));
        if (CollectionUtils.isEmpty(referentielWithFax))
        {
          _processContext.setState(State.PE0302_SI002);
          provSI002 = new PROV_SI002_ExecuterProcessusBuilder().tracabilite(tracabilite_p)//set Tracabilite
              .priorite(KPSA_DIAG_PRIORITE)//set priority
              .processus(CONSULTER_SERVICE_TECHNIQUE_PFSPCM)//set Process name to call
              .noms(Arrays.asList("noTelephone")) //set names //$NON-NLS-1$
              .valeurs(Arrays.asList(noTelephone_p))//set values
              .build();
          response = provSI002.execute(this);
          retour = provSI002.getRetour();

          ServiceTechniquePfsPcm serviceTechniquePfsPcm = null;
          if (isRetourOK(retour))
          {
            ReponseFonctionnelle<ServiceTechniquePfsPcm> functionalResponse = response.getReponseFonctionnelle(ServiceTechniquePfsPcm.class);
            List<ServiceTechniquePfsPcm> listServiceTechniquePfsPcm = functionalResponse.getItems();
            if (!CollectionUtils.isEmpty(listServiceTechniquePfsPcm))
            {
              serviceTechniquePfsPcm = listServiceTechniquePfsPcm.get(0);
            }
          }
          _processContext.setState(State.PE0302_BL302);
          Pair<Retour, PE0302_PFS> bL302Retour = PE0302_BL302_CreerObjetPfsPcm(tracabilite_p, noTelephone_p, retour, serviceTechniquePfsPcm);
          listPfs.add(bL302Retour._second);
          retour = bL302Retour._first;
        }
      }
    }
    return new Pair<Retour, List<PE0302_PFS>>(retour, listPfs);

  }

  /**
   * @param tracabilite_p
   * @param noTelephone_p
   * @param retour_p
   * @param stPfsSam_p
   * @return
   */
  @LogProcessBL
  private Pair<Retour, PE0302_PFS> PE0302_BL301_CreerObjetPfsSam(Tracabilite tracabilite_p, String noTelephone_p, Retour retour_p, ServiceTechniquePfsSam stPfsSam_p)
  {
    PE0302_PfsSam pfsSam = new PE0302_PfsSam(noTelephone_p);

    if (!isRetourOK(retour_p))
    {
      return validateRetour(retour_p, pfsSam);
    }
    if (stPfsSam_p.getTypeUsage() != null)
    {
      List<String> typeUsages = pfsSam.getTypeUsages();
      typeUsages.add(stPfsSam_p.getTypeUsage().toString());
      pfsSam.setTypeUsages(typeUsages);
    }

    if (TypeUsage.VOIX.equals(stPfsSam_p.getTypeUsage()))
    {
      PE0302_VoixPFS voix = new PE0302_VoixPFS();
      voix.setEtatEnregistrement(stPfsSam_p.getEtatEnregistrement());
      voix.setNiveauRestriction(stPfsSam_p.getNiveauRestriction());
      if (Objects.nonNull(stPfsSam_p.getImpiFixe()))
      {
        List<String> impiFixes = new ArrayList<>();
        impiFixes.add(stPfsSam_p.getImpiFixe());
        voix.setImpi(impiFixes);
      }
      if (Objects.nonNull(stPfsSam_p.getSipUri()) || Objects.nonNull(stPfsSam_p.getTelUri()))
      {
        List<String> impus = new ArrayList<>();
        if (Objects.nonNull(stPfsSam_p.getSipUri()))
        {
          impus.add(stPfsSam_p.getSipUri());
        }
        if (Objects.nonNull(stPfsSam_p.getTelUri()))
        {
          impus.add(stPfsSam_p.getTelUri());
        }
        voix.setImpu(impus);
      }
      voix.setNomPrenomCourt(stPfsSam_p.getNomPrenomCourt());
      voix.setNom(stPfsSam_p.getNom());
      voix.setPrenom(stPfsSam_p.getPrenom());
      voix.setOptionAppelSurTaxes(stPfsSam_p.getOptionAppelSurTaxes());
      if (!StringTools.areAllNullOrEmpty(stPfsSam_p.getNiveauRestriction()))
      {
        if (NON_RESTREINT.equals(stPfsSam_p.getNiveauRestriction()))
        {
          voix.setStatut(ACTIF);
        }
        else
        {
          voix.setStatut(RESTREINT);
        }
      }
      pfsSam.setVoix(voix);
    }
    else
    {
      PE0302_FaxPFS fax = new PE0302_FaxPFS();
      List<String> impi = fax.getImpi();
      impi.add(stPfsSam_p.getImpiFixe());
      fax.setImpi(impi);
      List<String> impu = fax.getImpu();
      impu.add(stPfsSam_p.getSipUri());
      impu.add(stPfsSam_p.getTelUri());
      fax.setImpu(impu);
      pfsSam.setFax(fax);
    }
    return new Pair<Retour, PE0302_PFS>(RetourFactory.createOkRetour(), pfsSam);
  }

  /**
   * @param tracabilite_p
   * @param noTelephone_p
   * @param retour_p
   * @param serviceTechniquePfsPcm_p
   * @return
   */
  @LogProcessBL
  private Pair<Retour, PE0302_PFS> PE0302_BL302_CreerObjetPfsPcm(Tracabilite tracabilite_p, String noTelephone_p, Retour retour_p, ServiceTechniquePfsPcm serviceTechniquePfsPcm_p)
  {
    PE0302_PfsPcm pfsPcm = new PE0302_PfsPcm(noTelephone_p);
    if (!isRetourOK(retour_p))
    {
      return validateRetour(retour_p, pfsPcm);
    }
    pfsPcm.setNom(serviceTechniquePfsPcm_p.getNom());
    pfsPcm.setPrenom(serviceTechniquePfsPcm_p.getPrenom());
    if (serviceTechniquePfsPcm_p.isEstEnCommunication())
    {
      pfsPcm.setLigneEnCommunication(EN_COMMUNICATION);
    }
    else
    {
      pfsPcm.setLigneEnCommunication(LIBRE);
    }
    return new Pair<Retour, PE0302_PFS>(RetourFactory.createOkRetour(), pfsPcm);

  }

  /**
   * @param tracabilite_p
   * @param clientOperateur_p
   * @param noCompte_p
   * @param listReferentiel_p
   * @param listPfs_p
   * @param sourceDonnee_p
   * @param audit_p
   * @return
   * @throws RavelException
   */
  @LogProcessBL
  private PE0302_BL400Return PE0302_BL400_ComparerVues(Tracabilite tracabilite_p, String clientOperateur_p, String noCompte_p, List<PE0302_Referentiel> listReferentiel_p, List<PE0302_PFS> listPfs_p, EnumSet<SourceDonne> sourceDonnee_p, Boolean audit_p) throws RavelException
  {
    PE0302_BL400Return bl400Return = new PE0302_BL400Return(RetourFactory.createOkRetour());
    List<ActionServiceTechnique> listActionSt = new ArrayList<>();

    Boolean creerActionCorrective;
    String idActionCorrective = null;

    if ((listReferentiel_p != null) && (listPfs_p != null) && !CollectionUtils.isEmpty(listReferentiel_p) && !CollectionUtils.isEmpty(listPfs_p) && audit_p)
    {
      String idExterne = null;
      for (PE0302_PFS pfs : listPfs_p)
      {
        if (CollectionUtils.isEmpty(pfs.getErreurs()))
        {
          creerActionCorrective = false;
          List<PE0302_Referentiel> listReferentiel = listReferentiel_p.stream().filter(o -> o.getNoTelephone().equals(pfs.getNoTelephone())).collect(Collectors.toList());

          if (!CollectionUtils.isEmpty(listReferentiel))
          {
            List<ServiceTechnique> listSt = listReferentiel.get(0).getSt();
            if (!CollectionUtils.isEmpty(listSt))
            {
              List<String> listInchorences = new ArrayList<>();
              StPfsSam stSam = null;
              // Filter List de ServicesTechniques
              List<ServiceTechnique> listStSAM = new StPfsSamFilter().whereStatutIs(Statut.ACTIF).filter(listSt);
              if (!CollectionUtils.isEmpty(listStSAM))
              {
                stSam = (StPfsSam) listStSAM.get(0);
                if (findAuditByDiagnostique(pfs.getAudits(), Diagnostic.SERVICE_NON_PROVISIONNE) != null)
                {
                  stSam.setStatut(INACTIF);
                  creerActionCorrective = true;
                }
                else
                {
                  if (SAM.equals(pfs.getTypePfs()))
                  {
                    PE0302_VoixPFS voix = ((PE0302_PfsSam) pfs).getVoix();
                    if (voix != null)
                    {
                      if (StringTools.isNotNullOrEmpty(voix.getNomPrenomCourt()) && !(voix.getNomPrenomCourt().equals(stSam.getDonneesProvisionneesStPfsSam().getNomPrenomCourt())))
                      {
                        listInchorences.add(NOM_PRENOM_COURT);
                        stSam.getDonneesProvisionneesStPfsSam().setNomPrenomCourt(voix.getNomPrenomCourt());
                        creerActionCorrective = true;
                      }
                      if (StringTools.isNotNullOrEmpty(voix.getNiveauRestriction()) && !(voix.getNiveauRestriction().equals(stSam.getDonneesProvisionneesStPfsSam().getNiveauRestriction())))
                      {
                        listInchorences.add(NIVEAU_RESTRICTION);
                        stSam.getDonneesProvisionneesStPfsSam().setNiveauRestriction(voix.getNiveauRestriction());
                        creerActionCorrective = true;
                      }
                      if (StringTools.isNotNullOrEmpty(voix.getOptionAppelSurTaxes()) && !(voix.getOptionAppelSurTaxes().equals(stSam.getDonneesProvisionneesStPfsSam().getOptionAppelSurTaxes())))
                      {
                        listInchorences.add(OPTION_APPEL_SUR_TAXES);
                        stSam.getDonneesProvisionneesStPfsSam().setOptionAppelSurTaxes(voix.getOptionAppelSurTaxes());
                        creerActionCorrective = true;
                      }
                    }
                  }
                }
              }
              if (!CollectionUtils.isEmpty(listInchorences))
              {
                List<PE0302_Audit> listAudit = new ArrayList<>();
                PE0302_Audit audit = new PE0302_Audit();
                audit.setDiagnostic(DESYNCHRO_PFS);
                audit.setLibelle(DESYNCHRO_PFS_LIBELLE);
                audit.setParameters(listInchorences);
                listAudit.add(audit);
                pfs.setAudits(listAudit);
              }
              if (creerActionCorrective && (stSam != null))
              {
                idExterne = _processContext.getIdRequest() + pfs.getNoTelephone();
                ActionServiceTechniqueSam actionServiceTechnique = new ActionServiceTechniqueSam(TypeAction.MODIFICATION.name(), stSam.getTypeServiceTechnique(), stSam.getStatut(), stSam.getDateModification());
                actionServiceTechnique.setIdSt(stSam.getIdSt());
                if (!INACTIF.equals(stSam.getStatut()))
                {
                  actionServiceTechnique.setTypePfs(stSam.getTypePfs());
                  actionServiceTechnique.setDonneesProvisionneesStPfsSam(stSam.getDonneesProvisionneesStPfsSam());
                }
                else
                {
                  actionServiceTechnique.setTypePfs(null);
                  actionServiceTechnique.setDonneesProvisionneesStPfsSam(null);
                }
                listActionSt.add(actionServiceTechnique);
              }
            }
          }
        }
      }

      if (!CollectionUtils.isEmpty(listActionSt))
      {
        ActionCorrective actionCorrective = new ActionCorrective(clientOperateur_p, noCompte_p);
        actionCorrective.setActionsServicesTechniques(listActionSt);
        Retour bl5100Retour = null;
        _processContext.setState(State.PE0302_BL5100);
        BL5100_CreerActionCorrective bl5100 = new BL5100_CreerActionCorrective.BL5100_CreerActionCorrectiveBuilder() // create BL5100_CreerActionCorrective
            .idExterne(idExterne).actionCorrective(actionCorrective).tracabilite(tracabilite_p) //set Tracabilite
            .build();
        idActionCorrective = bl5100.execute(this);
        bl5100Retour = bl5100.getRetour();
        if (!isRetourOK(bl5100Retour))
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, bl5100Retour.getDiagnostic() + ": " + bl5100Retour.getLibelle())); //$NON-NLS-1$
          PE0302_Erreur erreur = new PE0302_Erreur();
          erreur.setError(TypeError.ECHEC_ACTION_CORRECTIVE.name());
          erreur.setErrorDescription(MessageFormat.format(ERROR_CREATION_ACTION_CORRECTIVE, bl5100Retour.getDiagnostic()));
          for (PE0302_PFS pfs : listPfs_p)
          {
            if (!CollectionUtils.isEmpty(pfs.getAudits()))
            {
              List<PE0302_Erreur> erreurs = new ArrayList<>();
              erreurs.add(erreur);
              pfs.setErreurs(erreurs);
            }
          }
        }
      }
    }

    bl400Return.setIdActionCorrective(idActionCorrective);
    bl400Return.setListPfs(listPfs_p);
    bl400Return.setListReferentiel(listReferentiel_p);

    return bl400Return;
  }

  /**
   * send a sync response for requester.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param request_p
   *          The request object
   * @param pe0302Retour_p
   *          The Return
   */
  private void syncResponse(Tracabilite tracabilite_p, Request request_p, PE0302_Retour pe0302Retour_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp;
      ErrorCode errorCode;
      String jsonResponse;

      if (pe0302Retour_p.getReponseErreur() != null)
      {
        try
        {
          jsonResponse = RavelJsonTools.getInstance().toJson(pe0302Retour_p.getReponseErreur(), PE0302_Erreur.class);
        }
        catch (RavelException exception)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
          jsonResponse = null;
        }
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(jsonResponse);

        switch (pe0302Retour_p.getReponseErreur().getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.NO_TELEPHONE_INCONNU:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.SERVICE_NON_PROVISIONNE:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.PFS_INDISPO:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        rsp = new Response(errorCode, ravelResponse);
      }

      else
      {
        try
        {
          jsonResponse = RavelJsonTools.getInstance().toJson(pe0302Retour_p, PE0302_Retour.class);
        }
        catch (Exception ex)
        {
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
          jsonResponse = null;
        }

        //Add Json response in case OK
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(jsonResponse);
        rsp = new Response(ErrorCode.OK_00200, ravelResponse);
      }

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PE0302 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);
    }
  }

  /**
   * @param retour_p
   * @param pfs_p
   * @return
   */
  private Pair<Retour, PE0302_PFS> validateRetour(Retour retour_p, PE0302_PFS pfs_p)
  {
    if (IMegConsts.CAT4.equals(retour_p.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(retour_p.getDiagnostic()))
    {
      PE0302_Audit audit = new PE0302_Audit();
      audit.setDiagnostic(SERVICE_NON_PROVISIONNE);
      audit.setLibelle(Messages.getString("PE0302.BL301.ServiceNonProvisonne")); //$NON-NLS-1$
      List<PE0302_Audit> audits = new ArrayList<>();
      audits.add(audit);
      pfs_p.setAudits(audits);
    }
    else if (IMegConsts.CAT2.equals(retour_p.getCategorie()) && IMegConsts.SERVICE_TIERS_INDISPONIBLE.equals(retour_p.getDiagnostic()))
    {
      PE0302_Erreur erreur = new PE0302_Erreur();
      erreur.setError(PFS_INDISPONIBLE);
      erreur.setErrorDescription(MessageFormat.format(Messages.getString("PE0302.BL301.PFSIndisponible"), pfs_p.getTypePfs())); //$NON-NLS-1$
      List<PE0302_Erreur> erreurs = new ArrayList<>();
      erreurs.add(erreur);
      pfs_p.setErreurs(erreurs);
    }
    else if (IMegConsts.CAT1.equals(retour_p.getCategorie()))
    {
      PE0302_Erreur erreur = new PE0302_Erreur();
      erreur.setError(ERREUR_INTERNE);
      erreur.setErrorDescription(Messages.getString("PE0302.BL301.ErreurInterne")); //$NON-NLS-1$
      List<PE0302_Erreur> erreurs = new ArrayList<>();
      erreurs.add(erreur);
      pfs_p.setErreurs(erreurs);
    }
    else
    {
      PE0302_Erreur erreur = new PE0302_Erreur();
      erreur.setError(retour_p.getDiagnostic());
      erreur.setErrorDescription(retour_p.getLibelle());
      List<PE0302_Erreur> erreurs = new ArrayList<>();
      erreurs.add(erreur);
      pfs_p.setErreurs(erreurs);
    }
    return new Pair<Retour, PE0302_PFS>(RetourFactory.createOkRetour(), pfs_p);

  }

}
