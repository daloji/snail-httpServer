/**
 *
 */
package com.bytel.spirit.fiat.processes.PE0221.structs.types;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * @author mbaptist
 *
 */
public class Appel implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -7639982713908447195L;

  /**
   * numero appelant
   */
  @SerializedName("numeroAppelant")
  @Expose
  private String _numeroAppelant;

  /**
   * numero appelé
   */
  @SerializedName("numeroAppele")
  @Expose
  private String _numeroAppele;

  /**
   * Data de l'appel
   */
  @SerializedName("date")
  @Expose
  private LocalDateTime _date;

  /**
   * Durée de l'appel
   */
  @SerializedName("dureeAppel")
  @Expose
  private String _dureeAppel;

  /**
   * Typologie de l'appel
   */
  @SerializedName("typologieAppel")
  @Expose
  private String _typologieAppel;

  /**
   * Statut d'aboutissement de l'appel
   */
  @SerializedName("aboutissement")
  @Expose
  private String _aboutissement;

  /**
   * Numéro auquel l'appel a été transféré
   */
  @SerializedName("numeroTransfert")
  @Expose
  private String _numeroTransfert;

  /**
   *
   */
  public Appel()
  {
    // Default constructor
  }

  /**
   * @param numeroAppelant_p
   *          Numéro appelant
   * @param numeroAppele_p
   *          Numéro appelé
   * @param date_p
   *          Date de l'appel
   * @param dureeAppel_p
   *          Durée de l'appel
   * @param typologieAppel_p
   *          Typologie de l'appel
   * @param aboutissement_p
   *          Statut d'aboutissement de l'appel
   * @param numeroTransfert_p
   *          Numéro auquel l'appel a été transféré
   */
  public Appel(String numeroAppelant_p, String numeroAppele_p, LocalDateTime date_p, String dureeAppel_p, String typologieAppel_p, String aboutissement_p, String numeroTransfert_p)
  {
    super();
    _numeroAppelant = numeroAppelant_p;
    _numeroAppele = numeroAppele_p;
    _date = date_p;
    _dureeAppel = dureeAppel_p;
    _typologieAppel = typologieAppel_p;
    _aboutissement = aboutissement_p;
    _numeroTransfert = numeroTransfert_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    Appel other = (Appel) obj;
    if (_aboutissement == null)
    {
      if (other._aboutissement != null)
      {
        return false;
      }
    }
    else if (!_aboutissement.equals(other._aboutissement))
    {
      return false;
    }
    if (_date == null)
    {
      if (other._date != null)
      {
        return false;
      }
    }
    else if (!_date.equals(other._date))
    {
      return false;
    }
    if (_dureeAppel == null)
    {
      if (other._dureeAppel != null)
      {
        return false;
      }
    }
    else if (!_dureeAppel.equals(other._dureeAppel))
    {
      return false;
    }
    if (_numeroAppelant == null)
    {
      if (other._numeroAppelant != null)
      {
        return false;
      }
    }
    else if (!_numeroAppelant.equals(other._numeroAppelant))
    {
      return false;
    }
    if (_numeroAppele == null)
    {
      if (other._numeroAppele != null)
      {
        return false;
      }
    }
    else if (!_numeroAppele.equals(other._numeroAppele))
    {
      return false;
    }
    if (_numeroTransfert == null)
    {
      if (other._numeroTransfert != null)
      {
        return false;
      }
    }
    else if (!_numeroTransfert.equals(other._numeroTransfert))
    {
      return false;
    }
    if (_typologieAppel == null)
    {
      if (other._typologieAppel != null)
      {
        return false;
      }
    }
    else if (!_typologieAppel.equals(other._typologieAppel))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the aboutissement
   */
  public String getAboutissement()
  {
    return _aboutissement;
  }

  /**
   * @return the date
   */
  public LocalDateTime getDate()
  {
    return _date;
  }

  /**
   * @return the dureeAppel
   */
  public String getDureeAppel()
  {
    return _dureeAppel;
  }

  /**
   * @return the numeroAppelant
   */
  public String getNumeroAppelant()
  {
    return _numeroAppelant;
  }

  /**
   * @return the numeroAppele
   */
  public String getNumeroAppele()
  {
    return _numeroAppele;
  }

  /**
   * @return the numeroTransfert
   */
  public String getNumeroTransfert()
  {
    return _numeroTransfert;
  }

  /**
   * @return the typologieAppel
   */
  public String getTypologieAppel()
  {
    return _typologieAppel;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_aboutissement == null) ? 0 : _aboutissement.hashCode());
    result = (prime * result) + ((_date == null) ? 0 : _date.hashCode());
    result = (prime * result) + ((_dureeAppel == null) ? 0 : _dureeAppel.hashCode());
    result = (prime * result) + ((_numeroAppelant == null) ? 0 : _numeroAppelant.hashCode());
    result = (prime * result) + ((_numeroAppele == null) ? 0 : _numeroAppele.hashCode());
    result = (prime * result) + ((_numeroTransfert == null) ? 0 : _numeroTransfert.hashCode());
    result = (prime * result) + ((_typologieAppel == null) ? 0 : _typologieAppel.hashCode());
    return result;
  }

  /**
   * @param aboutissement_p
   *          the aboutissement to set
   */
  public void setAboutissement(String aboutissement_p)
  {
    _aboutissement = aboutissement_p;
  }

  /**
   * @param date_p
   *          the date to set
   */
  public void setDate(LocalDateTime date_p)
  {
    _date = date_p;
  }

  /**
   * @param dureeAppel_p
   *          the dureeAppel to set
   */
  public void setDureeAppel(String dureeAppel_p)
  {
    _dureeAppel = dureeAppel_p;
  }

  /**
   * @param numeroAppelant_p
   *          the numeroAppelant to set
   */
  public void setNumeroAppelant(String numeroAppelant_p)
  {
    _numeroAppelant = numeroAppelant_p;
  }

  /**
   * @param numeroAppele_p
   *          the numeroAppele to set
   */
  public void setNumeroAppele(String numeroAppele_p)
  {
    _numeroAppele = numeroAppele_p;
  }

  /**
   * @param numeroTransfert_p
   *          the numeroTransfert to set
   */
  public void setNumeroTransfert(String numeroTransfert_p)
  {
    _numeroTransfert = numeroTransfert_p;
  }

  /**
   * @param typologieAppel_p
   *          the typologieAppel to set
   */
  public void setTypologieAppel(String typologieAppel_p)
  {
    _typologieAppel = typologieAppel_p;
  }

}
