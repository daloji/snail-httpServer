/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang.ArrayUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI018_RecupererInfosAccesFTTH;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI018_RecupererInfosAccesFTTH.OSSFAI_SI018_RecupererInfosAccesFTTHBuilder;
import com.bytel.spirit.common.activities.shared.BL5000_ObtenirConfigFluxPartenaire;
import com.bytel.spirit.common.activities.shared.BL5000_ObtenirConfigFluxPartenaire.BL5000_ObtenirConfigFluxPartenaireBuilder;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.ws.access.ftth.AccesRI;
import com.bytel.spirit.common.generated.ws.access.ftth.AccesRI.ListeRouteOptique;
import com.bytel.spirit.common.generated.ws.access.ftth.AdresseRI;
import com.bytel.spirit.common.generated.ws.access.ftth.EtatAccesRI;
import com.bytel.spirit.common.generated.ws.access.ftth.QuadrupletRivoliRI;
import com.bytel.spirit.common.generated.ws.access.ftth.ReferenceAdresseRI;
import com.bytel.spirit.common.generated.ws.access.ftth.RouteOptiqueRI;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_Adresse;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_ComplementAdresse;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_HexacleVoie;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_PositionPMType;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_QuadrupletRivoli;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_ReferenceAdresse;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_Retour;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_RouteOptique;
import com.bytel.spirit.fiat.shared.types.json.Fibre;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0206_InfosMutation extends SpiritRestApiProcessSkeleton
{

  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  public static class DemandeInfoMutation
  {
    /**
     * Name of the installer
     */
    private String _installateur;

    /**
     * Number of the intervention in installer referential
     */
    private String _numIntervention;

    /**
     * Type of intervention
     */
    private String _typeIntervention;

    /**
     * Identifier "Bytel" in installer side set in the installation time
     */
    private String _idExterneRdv;

    /**
     * @return the idExterneRdv
     */
    public String getIdExterneRdv()
    {
      return _idExterneRdv;
    }

    /**
     * @return the installateur
     */
    public String getInstallateur()
    {
      return _installateur;
    }

    /**
     * @return the numIntervention
     */
    public String getNumIntervention()
    {
      return _numIntervention;
    }

    /**
     * @return the typeIntervention
     */
    public String getTypeIntervention()
    {
      return _typeIntervention;
    }

    /**
     * @param idExterneRdv_p
     *          the idExterneRdv to set
     */
    public void setIdExterneRdv(String idExterneRdv_p)
    {
      _idExterneRdv = idExterneRdv_p;
    }

    /**
     * @param installateur_p
     *          the installateur to set
     */
    public void setInstallateur(String installateur_p)
    {
      _installateur = installateur_p;
    }

    /**
     * @param numIntervention_p
     *          the numIntervention to set
     */
    public void setNumIntervention(String numIntervention_p)
    {
      _numIntervention = numIntervention_p;
    }

    /**
     * @param typeIntervention_p
     *          the typeIntervention to set
     */
    public void setTypeIntervention(String typeIntervention_p)
    {
      _typeIntervention = typeIntervention_p;
    }

  }

  /**
   * PE0206_RessourcesEmutation context
   *
   * @author jiantila
   * @version ($Revision$ $Date$)
   */
  public static final class PE0206_RessourcesEmutationContext extends Context
  {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /***
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0206_BL001;

    /**
     *
     */
    private DemandeInfoMutation _demandeInfo;

    /**
     * @return the demandeInfo
     */
    public DemandeInfoMutation getDemandeInfo()
    {
      return _demandeInfo;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param demandeInfo_p
     *          the demandeInfo to set
     */
    public void setDemandeInfo(DemandeInfoMutation demandeInfo_p)
    {
      _demandeInfo = demandeInfo_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

  }

  /**
   *
   * @author jiantila
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * PE0206_BL001_VerifierDonneesInfoMutation
     */
    PE0206_BL001(MandatoryProcessState.PRC_START, false, false),
    /**
     * PE0206_BL100_FiltrerAcces
     */
    PE0206_BL100(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
     * PE0206_BL101_OIEligible
     */
    PE0206_BL101(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * PE0206_BL002_FormaterReponseInfoMutation
     */
    PE0206_BL002(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   *
   * @author jiantila
   * @version ($Revision$ $Date$)
   */
  public enum TypeInstallateur
  {

    /**
     *
     */
    PC30,
    /**
    *
    */
    LORI,
    /**
    *
    */
    SGTL;
  }

  /**
   *
   * @author jiantila
   * @version ($Revision$ $Date$)
   */
  private enum TypeIntervention
  {
    /**
     *
     */
    SAV,
    /**
    *
    */
    RACCO;
  }

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * INSTALLATEUR
   */
  public static final String INSTALLATEUR = "installateur"; //$NON-NLS-1$
  /**
   * NUMINTERVENTION
   */
  public static final String NUMINTERVENTION = "numIntervention"; //$NON-NLS-1$
  /**
   * TYPEINTERVENTION
   */
  public static final String TYPEINTERVENTION = "typeIntervention"; //$NON-NLS-1$
  /**
   * IDEXTERNERDV
   */
  public static final String IDEXTERNERDV = "idExterneRdv"; //$NON-NLS-1$

  /**
   * OI_MUTATION
   */
  private static final String OI_MUTATION = "OI_MUTATION"; //$NON-NLS-1$

  /**
   * RACCO
   */
  private static final String RACCO = "RACCO"; //$NON-NLS-1$

  /**
   * Constant for invalid headers message
   */
  private static final String INVALID_HEADERS_MESSAGE = Messages.getString("PE0206.BL001.HeaderNullOrEmpty"); //$NON-NLS-1$
  /**
   *
   */
  private static final String INVALID_PARAMETERS_MESSAGE = Messages.getString("PE0206.BL001.ParametersNullOrEmpty"); //$NON-NLS-1$
  /**
   *
   */
  private static final String EMPTY_VALID_ACCES_MESSAGE = Messages.getString("PE0206.BL100.EmptyAccesValide"); //$NON-NLS-1$
  /**
   *
   */
  private static final String EMPTY_ACCES_EN_COURS_MESSAGE = Messages.getString("PE0206.BL100.EmptyAccesEnCours"); //$NON-NLS-1$
  /**
   *
   */
  private static final String PLUS_DONNEE_MESSAGE = Messages.getString("PE0206.BL100.PlusUneDonnee"); //$NON-NLS-1$
  /**
   *
   */
  private static final String EMPTY_ACCES_CONSTRUIT_MESSAGE = Messages.getString("PE0206.BL100.EmptyAccesConstruit"); //$NON-NLS-1$
  /**
   *
   */
  private static final String INVALID_ACCES_CONSTRUIT_MESSAGE = Messages.getString("PE0206.BL100.PlusUneDonneeConstruit"); //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAMETERS_CONSTRAINT_MESSAGE = Messages.getString("PE0206.BL001.ParametersConstraintFailed"); //$NON-NLS-1$

  /**
   * process Context
   */
  private PE0206_RessourcesEmutationContext _processContext;

  /**
   *
   */
  public PE0206_InfosMutation()
  {
    // TODO Auto-generated constructor stub
  }

  @Override
  public String createDefaultFunctionalResponse(Retour arg0_p) throws RavelException
  {
    return ""; //$NON-NLS-1$
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    super.initializeContext();
    _processContext = new PE0206_RessourcesEmutationContext();

  }

  @Override
  public boolean isAsynchronous()
  {

    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // TODO Auto-generated method stub

  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {

    String dateDispo = null;
    AccesRI accesRi = null;
    Retour retour = RetourFactory.createOkRetour();
    try
    {
      _processContext.setState(State.PE0206_BL001);
      Pair<DemandeInfoMutation, Retour> bl001Result = PE0206_BL001_VerifierDonneesInfoMutation(tracabilite_p, request_p);

      DemandeInfoMutation demandeInfoMutation = bl001Result._first;
      retour = bl001Result._second;
      if (isRetourOK(retour))
      {
        OSSFAI_SI018_RecupererInfosAccesFTTH si018Result = new OSSFAI_SI018_RecupererInfosAccesFTTHBuilder().tracabilite(tracabilite_p)//set tracabilite
            .idServiceClient(demandeInfoMutation.getIdExterneRdv()).build();
        List<AccesRI> listAccesRi = si018Result.execute(this);
        retour = si018Result.getRetour();
        if (isRetourOK(retour))
        {
          _processContext.setState(State.PE0206_BL100);
          Pair<AccesRI, Retour> bl100Result = PE0206_BL100_FiltrerAcces(tracabilite_p, demandeInfoMutation, listAccesRi);
          accesRi = bl100Result._first;
          retour = bl100Result._second;
          if (isRetourOK(retour))
          {
            _processContext.setState(State.PE0206_BL101);
            Pair<String, Retour> bl101Result = PE0206_BL101_OIEligible(tracabilite_p, demandeInfoMutation, accesRi);
            dateDispo = bl101Result._first;
            retour = bl101Result._second;
          }
        }
      }
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, exception.getMessage());
    }
    finally
    {
      _processContext.setState(State.PE0206_BL002);
      Pair<ReponseErreur, PE0206_Retour> response_bl002 = PE0206_BL002_FormaterReponseInfoMutation(tracabilite_p, accesRi, dateDispo, retour);
      syncGetResponse(request_p, tracabilite_p, response_bl002._second, response_bl002._first);
      _processContext.setState(State.ENDED);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // TODO Auto-generated method stub

  }

  /**
   * Gets the URL parameters into the ProcessContext
   *
   * @param tracabilite_p
   *          tracabilite
   * @param parametersMap_p
   *          parameters
   *
   * @param request_p
   *          request
   * @return Object STI
   */
  private Retour checkIRequestParameters(Tracabilite tracabilite_p, final Map<String, String> parametersMap_p, final Request request_p)
  {
    //fill the values of the required parameters, from the request object
    fillParametersMapFromRequest(parametersMap_p, request_p);

    Iterator<String> parametersIterator = parametersMap_p.keySet().iterator();
    Retour retour = RetourFactory.createOkRetour();
    //check if the values of the required parameters are set, if not return with NOK immediately
    while (parametersIterator.hasNext())
    {
      String parameterName = parametersIterator.next();
      if (StringTools.isNullOrEmpty(parametersMap_p.get(parameterName)))
      {
        String libelleErreur = MessageFormat.format(INVALID_PARAMETERS_MESSAGE, parameterName);
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
      }
      else
      {

        //Check Constraint
        String value = parametersMap_p.get(parameterName);
        retour = validConstraint(parameterName, value);
      }
      if (!isRetourOK(retour))
      {
        return retour;
      }
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Validates that each key in headersMap_p has a value in the request_p parameter, and if yes set the corresponding
   * value.
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param headersMap_p
   *          Map containing the header names as keys.
   * @param request_p
   *          The request The original request containing all headers
   *
   * @return Retour OK if all the headers in the headersMap_p are set, NOK otherwise
   */
  private Retour checkRequestHeaders(Tracabilite tracabilite_p, Map<String, String> headersMap_p, final Request request_p)
  {

    //fill the values of the required headers, from the request object
    fillHeaderMapFromRequest(headersMap_p, request_p);

    Iterator<String> headersIterator = headersMap_p.keySet().iterator();
    //check if the values of the required headers are set, if not return with NOK immediately
    while (headersIterator.hasNext())
    {
      String headerName = headersIterator.next();
      if (StringTools.isNullOrEmpty(headersMap_p.get(headerName)))
      {
        String libelleErreur = MessageFormat.format(INVALID_HEADERS_MESSAGE, headerName);
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
      }
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Fill the values in the headersMap_p parameters, using the headers in the request_p paramter.
   *
   * @param headersMap_p
   *          The map containing the headers to fill
   * @param request_p
   *          The request objetct containing all the headers
   */
  private void fillHeaderMapFromRequest(final Map<String, String> headersMap_p, final Request request_p)
  {
    if ((headersMap_p != null) && !headersMap_p.keySet().isEmpty())
    {
      for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
      {
        if (headersMap_p.containsKey(header.getName()))
        {
          headersMap_p.put(header.getName(), header.getValue()); //fill value for the specified header
        }
      }
    }
  }

  /**
   * @param parametersMap_p
   *          parameters
   * @param request_p
   *          request
   */
  private void fillParametersMapFromRequest(Map<String, String> parametersMap_p, Request request_p)
  {
    if ((parametersMap_p != null) && !parametersMap_p.keySet().isEmpty())
    {
      List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();
      for (Parameter parametre : urlParametersType)
      {
        if (parametersMap_p.containsKey(parametre.getName()))
        {
          parametersMap_p.put(parametre.getName(), parametre.getValue()); //fill value for the specified parameter
        }
      }
    }
  }

  /**
   *
   * findAccesRI
   *
   * @param listAccesRi_p
   *          list access RI
   * @param demandeInfo_p
   *          demande info
   * @return List<AccesRI>
   */
  private List<AccesRI> findAccesRI(List<AccesRI> listAccesRi_p, DemandeInfoMutation demandeInfo_p)
  {
    List<AccesRI> listAcces = new ArrayList<>();
    if (listAccesRi_p != null)
    {

      for (AccesRI access : listAccesRi_p)
      {
        if ((demandeInfo_p.getNumIntervention() != null) && demandeInfo_p.getNumIntervention().equals(access.getNumIntervention()))
        {
          listAcces.add(access);
        }
      }
    }
    return listAcces;
  }

  /**
   * find AccesRI by State
   *
   * @param listAccesRi_p
   *          listaccessRi
   * @return List<AccesRI>
   */
  private List<AccesRI> findAccesRIbyState(List<AccesRI> listAccesRi_p)
  {
    List<AccesRI> listAcces = new ArrayList<>();
    if (listAccesRi_p != null)
    {

      for (AccesRI access : listAccesRi_p)
      {
        if ((access.getEtatAcces() != null) && EtatAccesRI.CONSTRUIT.name().equals(access.getEtatAcces().name()))
        {
          listAcces.add(access);
        }
      }
    }
    return listAcces;
  }

  /**
   * Validate Headers and URL Parameters
   *
   * @param tracabilite_p
   *          tracabilite
   * @param request_p
   *          request
   * @return Pair<DemandeInfoMutation, Retour>
   */
  @LogProcessBL
  private Pair<DemandeInfoMutation, Retour> PE0206_BL001_VerifierDonneesInfoMutation(Tracabilite tracabilite_p, Request request_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    DemandeInfoMutation demandeInfoMutation = new DemandeInfoMutation();

    //create a map to store all required headers names to validate, ignoring case of the header name
    Map<String, String> headersMap = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    headersMap.put(IHttpHeadersConsts.X_SOURCE, null);
    headersMap.put(IHttpHeadersConsts.X_PROCESS, null);
    headersMap.put(IHttpHeadersConsts.X_REQUEST_ID, null); // Check in the FrontEnd

    retour = checkRequestHeaders(tracabilite_p, headersMap, request_p);
    if (isRetourOK(retour))
    {
      Map<String, String> parametersMap = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
      parametersMap.put(INSTALLATEUR, null);
      parametersMap.put(NUMINTERVENTION, null);
      parametersMap.put(TYPEINTERVENTION, null);
      parametersMap.put(IDEXTERNERDV, null);

      retour = checkIRequestParameters(tracabilite_p, parametersMap, request_p);
      if (isRetourOK(retour))
      {
        demandeInfoMutation.setInstallateur(parametersMap.get(INSTALLATEUR));
        demandeInfoMutation.setNumIntervention(parametersMap.get(NUMINTERVENTION));
        demandeInfoMutation.setTypeIntervention(parametersMap.get(TYPEINTERVENTION));
        demandeInfoMutation.setIdExterneRdv(parametersMap.get(IDEXTERNERDV));
      }
    }
    _processContext.setDemandeInfo(demandeInfoMutation);
    return new Pair<>(demandeInfoMutation, retour);
  }

  /**
   * Builds the process response.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param accesRi_p
   *          AccesRI
   * @param dateDispo_p
   *          dateDispo
   * @param retour_p
   *          retour
   * @return reponseErreur
   */
  @LogProcessBL
  private Pair<ReponseErreur, PE0206_Retour> PE0206_BL002_FormaterReponseInfoMutation(Tracabilite tracabilite_p, AccesRI accesRi_p, String dateDispo_p, Retour retour_p)
  {
    ReponseErreur responseErreur = null;
    PE0206_Retour pe206 = null;

    if (isRetourOK(retour_p))
    {
      pe206 = new PE0206_Retour();
      pe206.setOi(accesRi_p.getCodeOI());
      pe206.setMutationPossible(true);
      pe206.setRefPrestationPrise(accesRi_p.getReferencePrestationPrise());
      List<PE0206_RouteOptique> lisPE0206 = transformListRoute(accesRi_p);
      pe206.setListeRouteOptique(lisPE0206);
      Pair<PE0206_Adresse, PE0206_ComplementAdresse> addressRItranform = transformAdresseRI(accesRi_p.getAdresse());
      pe206.setAdresse(addressRItranform._first);
      pe206.setComplementAdresse(addressRItranform._second);
      pe206.setReferencePM(accesRi_p.getReferencePM());
      pe206.setReferencePBO(accesRi_p.getReferencePBO());
      pe206.setPriseExisante(accesRi_p.isPrisePosee());
    }
    else if (IMegSpiritConsts.FLUX_BIENTOT_DISPONIBLE.equals(retour_p.getDiagnostic()) && IMegConsts.CAT4.equals(retour_p.getCategorie()))
    {
      pe206 = new PE0206_Retour();
      pe206.setOi(accesRi_p.getCodeOI());
      pe206.setMutationPossible(false);
      pe206.setDateDispo(dateDispo_p);
    }
    else if (IMegSpiritConsts.FLUX_INDISPONIBLE.equals(retour_p.getDiagnostic()) && IMegConsts.CAT4.equals(retour_p.getCategorie()))
    {
      pe206 = new PE0206_Retour();
      pe206.setOi(accesRi_p.getCodeOI());
      pe206.setMutationPossible(false);
    }
    else
    {

      responseErreur = new ReponseErreur();
      responseErreur.setError(retour_p.getDiagnostic());
      responseErreur.setErrorDescription(retour_p.getLibelle());

    }
    return new Pair<>(responseErreur, pe206);
  }

  /**
   *
   * Filter acces in the list listAccesRi_p
   *
   * @param tracabilite_p
   *          tracabilite
   * @param demandeInfoMutation_p
   *          demande info mutation
   * @param listAccesRi_p
   *          list access TI
   * @return Pair<InfoAcces, Retour>
   */
  @LogProcessBL
  private Pair<AccesRI, Retour> PE0206_BL100_FiltrerAcces(Tracabilite tracabilite_p, DemandeInfoMutation demandeInfoMutation_p, List<AccesRI> listAccesRi_p)
  {
    AccesRI accesri = null;
    Retour retour = RetourFactory.createOkRetour();
    if ((listAccesRi_p != null) && !listAccesRi_p.isEmpty())
    {
      if (RACCO.equals(demandeInfoMutation_p.getTypeIntervention()))
      {
        List<AccesRI> listaccesRi = findAccesRI(listAccesRi_p, demandeInfoMutation_p);
        if (listaccesRi.size() == 1)
        {
          retour = RetourFactory.createOkRetour();
          accesri = listaccesRi.get(0);
        }
        else if (listaccesRi.isEmpty())
        {
          String libelleErreur = MessageFormat.format(EMPTY_ACCES_EN_COURS_MESSAGE, demandeInfoMutation_p.getNumIntervention(), demandeInfoMutation_p.getInstallateur());
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, libelleErreur);
        }
        else
        {
          String libelleErreur = MessageFormat.format(PLUS_DONNEE_MESSAGE, listaccesRi.size(), demandeInfoMutation_p.getNumIntervention());
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PLUS_QU_UNE_DONNEE, libelleErreur);
        }

      }
      else
      {
        List<AccesRI> listaccesRi = findAccesRIbyState(listAccesRi_p);
        if (listaccesRi.size() == 1)
        {
          retour = RetourFactory.createOkRetour();
          accesri = listaccesRi.get(0);
        }
        else if (listaccesRi.isEmpty())
        {

          String libelleErreur = MessageFormat.format(EMPTY_ACCES_CONSTRUIT_MESSAGE, demandeInfoMutation_p.getIdExterneRdv());
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, libelleErreur);
        }
        else
        {
          String libelleErreur = MessageFormat.format(INVALID_ACCES_CONSTRUIT_MESSAGE, listaccesRi.size(), demandeInfoMutation_p.getIdExterneRdv());
          RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PLUS_QU_UNE_DONNEE, libelleErreur);
        }
      }

    }
    else

    {
      String libelleErreur = MessageFormat.format(EMPTY_VALID_ACCES_MESSAGE, demandeInfoMutation_p.getIdExterneRdv());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, libelleErreur);
    }

    return new Pair<>(accesri, retour);
  }

  /**
   * Check if the OI of Acces is eligible to the emutation service.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param demandeInfoMutation_p
   *          demande info
   * @param accessRi_p
   *          access Ri
   * @return Pair<String, Retour>
   *
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<String, Retour> PE0206_BL101_OIEligible(Tracabilite tracabilite_p, DemandeInfoMutation demandeInfoMutation_p, AccesRI accessRi_p) throws RavelException
  {

    BL5000_ObtenirConfigFluxPartenaire bl500 = new BL5000_ObtenirConfigFluxPartenaireBuilder().tracabilite(tracabilite_p).codeFlux(OI_MUTATION).nomPartenaire(accessRi_p.getCodeOI()).build();
    ConfigFluxOI configflux = bl500.execute(this);
    Retour retour = bl500.getRetour();
    String dateinfo = null;
    if (isRetourOK(retour))
    {
      dateinfo = configflux.getDateDispo();

      if (configflux.isDisponible())
      {
        retour = RetourFactory.createOkRetour();
      }
      else if (StringTools.isNotNullOrEmpty(dateinfo))
      {
        String libelle = MessageFormat.format(Messages.getString("PE0206.BL101.OIELigibleFluxBientotDisponible"), OI_MUTATION, accessRi_p.getCodeOI(), configflux.getDateDispo()); //$NON-NLS-1$
        retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.FLUX_BIENTOT_DISPONIBLE, libelle);
      }
      else
      {
        String libelle = MessageFormat.format(Messages.getString("PE0206.BL101.OIELigibleFluxIndisponible"), OI_MUTATION, accessRi_p.getCodeOI()); //$NON-NLS-1$
        retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.FLUX_INDISPONIBLE, libelle);
      }
    }
    return new Pair<>(dateinfo, retour);
  }

  /**
   * prepare response
   *
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @param pe206retour
   *          object retour
   * @param reponserreur_p
   *          erreur response
   */
  private void syncGetResponse(Request request_p, Tracabilite tracabilite_p, PE0206_Retour pe206retour, ReponseErreur reponserreur_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp = null;

      if (reponserreur_p != null)
      {
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(GsonTools.getIso8601Ms().toJson(reponserreur_p));
        ErrorCode errorCode = ErrorCode.KO_00500; //Unknown error

        if (IMegSpiritConsts.NON_RESPECT_STI.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00400;
        }
        else if (IMegConsts.DONNEE_INCONNUE.equals(reponserreur_p.getError()) || IMegSpiritConsts.PLUS_QU_UNE_DONNEE.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00404;
        }

        rsp = new Response(errorCode, ravelResponse);

      }
      else
      {
        //Add empty Json in case OK
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(GsonTools.getIso8601Ms().toJson(pe206retour));
        rsp = new Response(ErrorCode.OK_00200, ravelResponse);
      }

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PEI0147 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);

    }
  }

  /**
   * Adresse Transform Adresse RI
   *
   * @param adressRi_p
   *          adresse ri
   * @return
   */
  private Pair<PE0206_Adresse, PE0206_ComplementAdresse> transformAdresseRI(AdresseRI adressRi_p)
  {
    PE0206_Adresse adresse = null;
    PE0206_ComplementAdresse complementAdresse = null;
    if (adressRi_p != null)
    {
      adresse = new PE0206_Adresse();
      adresse.setCodePostal(adressRi_p.getCodePostal());
      adresse.setCommune(adressRi_p.getCommune());
      Integer num = adressRi_p.getNumeroVoie();
      adresse.setLibelleVoie(adressRi_p.getLibelleVoie());
      if (num != null)
      {
        adresse.setNumeroVoie(num.toString());
      }
      adresse.setComplementNumero(adressRi_p.getComplementNumeroVoie());
      if (adressRi_p.getReferencesAdresse() != null)
      {

        PE0206_ReferenceAdresse reference = new PE0206_ReferenceAdresse();
        ReferenceAdresseRI referAdressRi = adressRi_p.getReferencesAdresse();
        reference.setHexacle(referAdressRi.getHexacle());
        PE0206_HexacleVoie hexaclevoie = new PE0206_HexacleVoie();
        hexaclevoie.setCodeHexacleVoie(referAdressRi.getHexacle());
        QuadrupletRivoliRI quadruprivoliRI = referAdressRi.getRivoli();
        if (quadruprivoliRI != null)
        {
          PE0206_QuadrupletRivoli quadruprivoli = new PE0206_QuadrupletRivoli();
          quadruprivoli.setCodeInsee(quadruprivoliRI.getCodeInsee());
          quadruprivoli.setCodeRivoli(quadruprivoliRI.getCodeRivoli());
          quadruprivoli.setComplementNumeroVoie(quadruprivoliRI.getComplementNumeroVoie());
          quadruprivoli.setNumeroVoie(quadruprivoliRI.getNumeroVoie());
          reference.setRivoli(quadruprivoli);
          hexaclevoie.setNumeroVoie(quadruprivoliRI.getNumeroVoie());
          hexaclevoie.setComplementNumeroVoie(quadruprivoliRI.getComplementNumeroVoie());

        }
        reference.setHexacleVoie(hexaclevoie);
        adresse.setReferencesAdresse(reference);
      }

      complementAdresse = new PE0206_ComplementAdresse();
      complementAdresse.setBatiment(adressRi_p.getBatiment());
      complementAdresse.setEscalier(adressRi_p.getEscalier());
      complementAdresse.setEtage(adressRi_p.getEtage());
    }
    return new Pair<>(adresse, complementAdresse);
  }

  /**
   * Recuperation de la liste de route optique
   *
   * @param accesRi_p
   *          accesRi
   * @return PE0206_RouteOptique
   */
  private List<PE0206_RouteOptique> transformListRoute(AccesRI accesRi_p)
  {
    List<PE0206_RouteOptique> listRouteResult = new ArrayList<>();

    if ((accesRi_p != null) && (accesRi_p.getListeRouteOptique() != null))
    {
      ListeRouteOptique listRouteOptiqueObjetct = accesRi_p.getListeRouteOptique();
      List<RouteOptiqueRI> listRoute = listRouteOptiqueObjetct.getRouteOptiques();
      for (RouteOptiqueRI routeOptiqueRI : listRoute)
      {
        Fibre fibre = new Fibre(StringConstants.EMPTY_STRING, routeOptiqueRI.getReferenceCablePBO(), routeOptiqueRI.getInformationTubePBO(), routeOptiqueRI.getInformationFibrePBO(), StringConstants.EMPTY_STRING, accesRi_p.getReferencePrise());
        PE0206_PositionPMType positionPMType = new PE0206_PositionPMType();
        positionPMType.setNomModulePM(routeOptiqueRI.getNomModulePM());
        positionPMType.setPositionModulePM(routeOptiqueRI.getPositionModulePM());
        positionPMType.setReferenceCableModulePM(routeOptiqueRI.getReferenceCablePM());
        positionPMType.setInfoTubeModulePM(routeOptiqueRI.getInformationTubePM());
        positionPMType.setInfoFibreModulePM(routeOptiqueRI.getInformationFibrePM());
        PE0206_RouteOptique peiRouteOpt = new PE0206_RouteOptique();
        peiRouteOpt.setOc(routeOptiqueRI.getCodeOC());
        peiRouteOpt.setPositionPM(positionPMType);
        peiRouteOpt.setFibre(fibre);
        peiRouteOpt.setConnecteurPriseCouleur(routeOptiqueRI.getCouleurPriseConnecteur());
        peiRouteOpt.setConnecteurPriseNumero(routeOptiqueRI.getNumPriseConnecteur());
        listRouteResult.add(peiRouteOpt);
      }
    }

    return listRouteResult;
  }

  /**
   * Check validation of parameter GET
   *
   * @param parameter_p
   *          parameter
   * @param value_p
   *          value
   * @return
   */
  private Retour validConstraint(String parameter_p, String value_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    if (INSTALLATEUR.equals(parameter_p))
    {
      String[] constraint = { TypeInstallateur.LORI.name(), TypeInstallateur.SGTL.name(), TypeInstallateur.PC30.name() };
      if (!ArrayUtils.contains(constraint, value_p))
      {
        String delimiter = " , "; //$NON-NLS-1$
        String value_allow = String.join(delimiter, constraint);
        String libelleErreur = MessageFormat.format(PARAMETERS_CONSTRAINT_MESSAGE, parameter_p, value_allow);
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
      }
    }

    if (TYPEINTERVENTION.equals(parameter_p))
    {
      String[] constraint = { TypeIntervention.RACCO.name(), TypeIntervention.SAV.name() };
      if (!ArrayUtils.contains(constraint, value_p))
      {
        String delimiter = " , "; //$NON-NLS-1$
        String value_allow = String.join(delimiter, constraint);
        String libelleErreur = MessageFormat.format(PARAMETERS_CONSTRAINT_MESSAGE, parameter_p, value_allow);
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
      }
    }
    return retour;

  }
}
