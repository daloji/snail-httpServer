/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0215.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.fiat.shared.types.json.PFS;
import com.bytel.spirit.fiat.shared.types.json.Referentiel;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PE0215_Retour implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -6909890016723590644L;
  /**
   * responseErrreur
   */
  @SerializedName("responseErrreur")
  private ReponseErreur _reponseErreur; //TODO: check parameter names

  /**
   * referentiels
   */
  @SerializedName("Referentiels")
  private List<Referentiel> _referentiels;

  /**
   * pfs
   */
  @SerializedName("pfs")
  private List<PFS> _pfs;
  /**
   * retour
   */
  private transient Retour _retour;

  /**
   * @return the pfs
   */
  public List<PFS> getPfs()
  {
    return _pfs != null ? new ArrayList<>(_pfs) : null;
  }

  /**
   * @return the referentiels
   */
  public List<Referentiel> getReferentiels()
  {
    return _referentiels != null ? new ArrayList<>(_referentiels) : null;
  }

  /**
   * @return the reponseErreur
   */
  public ReponseErreur getReponseErreur()
  {
    return _reponseErreur;
  }

  /**
   * @return the retour
   */
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * @param pfs_p
   *          the pfs to set
   */
  public void setPfs(List<PFS> pfs_p)
  {
    _pfs = pfs_p != null ? new ArrayList<>(pfs_p) : null;
  }

  /**
   * @param referentiels_p
   *          the referentiels to set
   */
  public void setReferentiels(List<Referentiel> referentiels_p)
  {
    _referentiels = referentiels_p != null ? new ArrayList<>(referentiels_p) : null;
  }

  /**
   * @param reponseErreur_p
   *          the reponseErreur to set
   */
  public void setReponseErreur(ReponseErreur reponseErreur_p)
  {
    _reponseErreur = reponseErreur_p;
  }

  /**
   * @param retour_p
   *          the retour to set
   */
  public void setRetour(Retour retour_p)
  {
    _retour = retour_p;
  }

}
