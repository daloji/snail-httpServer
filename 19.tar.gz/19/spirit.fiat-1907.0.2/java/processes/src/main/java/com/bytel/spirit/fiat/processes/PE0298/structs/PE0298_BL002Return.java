/*******************************************************************************
* $Id: PE0298_BL002Return.java 15184 2019-01-02 15:09:51Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0298.structs;

import java.io.Serializable;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;

/**
 *
 * @author kbettenc
 * @version ($Revision: 15184 $ $Date: 2019-01-02 16:09:51 +0100 (mer. 02 janv. 2019) $)
 */
public class PE0298_BL002Return implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -252067624959271018L;

  /**
   * responseErrreur
   */
  private ReponseErreur _reponseErreur;

  /**
   * Process response
   */
  private PE0298_Reponse _pe0298Reponse;

  /**
   * retour
   */
  private transient Retour _retour;

  /**
   * @return the pe0298Reponse
   */
  public PE0298_Reponse getPe0298Reponse()
  {
    return _pe0298Reponse;
  }

  /**
   * @return the reponseErreur
   */
  public ReponseErreur getReponseErreur()
  {
    return _reponseErreur;
  }

  /**
   * @return the retour
   */
  public Retour getRetour()
  {
    return _retour;
  }

  /**
   * @param pe0298Reponse_p
   *          the pe0298Reponse to set
   */
  public void setPe0298Reponse(PE0298_Reponse pe0298Reponse_p)
  {
    _pe0298Reponse = pe0298Reponse_p;
  }

  /**
   * @param reponseErreur_p
   *          the reponseErreur to set
   */
  public void setReponseErreur(ReponseErreur reponseErreur_p)
  {
    _reponseErreur = reponseErreur_p;
  }

  /**
   * @param retour_p
   *          the retour to set
   */
  public void setRetour(Retour retour_p)
  {
    _retour = retour_p;
  }

}
