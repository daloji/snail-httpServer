/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0280.structs;

import java.io.Serializable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.bytel.spirit.fiat.shared.types.json.ComplementAdresse;
import com.bytel.spirit.fiat.shared.types.json.ReferencesAdresse;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author mfreire
 * @version ($Revision$ $Date$)
 */
@PE0280RequestConstraint
public class PE0280_Request implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 4082233249434252811L;

  /**
   *
   */
  @SerializedName("referencePrise")
  @Expose
  private String _referencePrise;

  /**
  *
  */
  @SerializedName("identifiantFibre")
  @Expose
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  private String _identifiantFibre;

  /**
  *
  */
  @SerializedName("motifMutation")
  @Expose
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  private String _motifMutation;

  /**
  *
  */
  @SerializedName("referencesAdresse")
  @Expose
  @Valid
  private ReferencesAdresse _referencesAdresse;

  /**
  *
  */
  @SerializedName("complementAdresseCmd")
  @Expose
  private ComplementAdresse _complementAdresseCmd;

  /**
  *
  */
  @SerializedName("complementAdresseTerrain")
  @Expose
  private ComplementAdresse _complementAdresseTerrain;

  /**
   *
   */
  @SerializedName("porte")
  @Expose
  private String _porte;

  /**
   *
   */
  public PE0280_Request()
  {
    super();
  }

  /**
   * @param referencePrise_p
   * @param identifiantFibre_p
   * @param motifMutation_p
   * @param referencesAdresse_p
   * @param complementAdresseCmd_p
   * @param complementAdresseTerrain_p
   * @param porte_p
   */
  @SuppressWarnings("javadoc")
  public PE0280_Request(String referencePrise_p, String identifiantFibre_p, String motifMutation_p, ReferencesAdresse referencesAdresse_p, ComplementAdresse complementAdresseCmd_p, ComplementAdresse complementAdresseTerrain_p, String porte_p)
  {
    super();
    _referencePrise = referencePrise_p;
    _identifiantFibre = identifiantFibre_p;
    _motifMutation = motifMutation_p;
    _referencesAdresse = referencesAdresse_p;
    _complementAdresseCmd = complementAdresseCmd_p;
    _complementAdresseTerrain = complementAdresseTerrain_p;
    _porte = porte_p;
  }

  /**
   * @return the complementAdresseCmd
   */
  public ComplementAdresse getComplementAdresseCmd()
  {
    return _complementAdresseCmd;
  }

  /**
   * @return the complementAdresseTerrain
   */
  public ComplementAdresse getComplementAdresseTerrain()
  {
    return _complementAdresseTerrain;
  }

  /**
   * @return the identifiantFibre
   */
  public String getIdentifiantFibre()
  {
    return _identifiantFibre;
  }

  /**
   * @return the motifMutation
   */
  public String getMotifMutation()
  {
    return _motifMutation;
  }

  /**
   * @return the porte
   */
  public String getPorte()
  {
    return _porte;
  }

  /**
   * @return the referencePrise
   */
  public String getReferencePrise()
  {
    return _referencePrise;
  }

  /**
   * @return the referencesAdresse
   */
  public ReferencesAdresse getReferencesAdresse()
  {
    return _referencesAdresse;
  }

  /**
   * @param complementAdresseCmd_p
   *          the complementAdresseCmd to set
   */
  public void setComplementAdresseCmd(ComplementAdresse complementAdresseCmd_p)
  {
    _complementAdresseCmd = complementAdresseCmd_p;
  }

  /**
   * @param complementAdresseTerrain_p
   *          the complementAdresseTerrain to set
   */
  public void setComplementAdresseTerrain(ComplementAdresse complementAdresseTerrain_p)
  {
    _complementAdresseTerrain = complementAdresseTerrain_p;
  }

  /**
   * @param identifiantFibre_p
   *          the identifiantFibre to set
   */
  public void setIdentifiantFibre(String identifiantFibre_p)
  {
    _identifiantFibre = identifiantFibre_p;
  }

  /**
   * @param motifMutation_p
   *          the motifMutation to set
   */
  public void setMotifMutation(String motifMutation_p)
  {
    _motifMutation = motifMutation_p;
  }

  /**
   * @param porte_p
   *          the porte to set
   */
  public void setPorte(String porte_p)
  {
    _porte = porte_p;
  }

  /**
   * @param referencePrise_p
   *          the referencePrise to set
   */
  public void setReferencePrise(String referencePrise_p)
  {
    _referencePrise = referencePrise_p;
  }

  /**
   * @param referencesAdresse_p
   *          the referencesAdresse to set
   */
  public void setReferencesAdresse(ReferencesAdresse referencesAdresse_p)
  {
    _referencesAdresse = referencesAdresse_p;
  }

}
