/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.squareup.moshi.Json;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0302_FaxPFS implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -2655473065752396806L;

  /**
   * impi
   */
  @Json(name = "impi")
  private List<String> _impi;

  /**
   * impu
   */
  @Json(name = "impu")
  private List<String> _impu;

  /**
   * @return the impi
   */
  public List<String> getImpi()
  {
    return _impi != null ? new ArrayList<>(_impi) : new ArrayList<>();
  }

  /**
   * @return the impu
   */
  public List<String> getImpu()
  {
    return _impu != null ? new ArrayList<>(_impu) : new ArrayList<>();
  }

  /**
   * @param impi_p
   *          the impi to set
   */
  public void setImpi(List<String> impi_p)
  {
    _impi = new ArrayList<>(impi_p);
  }

  /**
   * @param impu_p
   *          the impu to set
   */
  public void setImpu(List<String> impu_p)
  {
    _impu = new ArrayList<>(impu_p);
  }

}
