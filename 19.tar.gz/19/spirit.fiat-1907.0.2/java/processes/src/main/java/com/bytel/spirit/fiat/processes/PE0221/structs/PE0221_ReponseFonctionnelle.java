/*******************************************************************************
* $Id: PE0221_ReponseFonctionnelle.java 14346 2018-12-10 11:24:13Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0221.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.fiat.processes.PE0221.structs.types.AppelPfs;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author kbettenc
 * @version ($Revision: 14346 $ $Date: 2018-12-10 12:24:13 +0100 (lun. 10 déc. 2018) $)
 */
public class PE0221_ReponseFonctionnelle implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 2258090912716622815L;

  /**
   * Nombre d’objet retourné dans l’attribut items
   */
  @SerializedName("resultsCount")
  @Expose
  private String _resultsCount;

  /**
   * Liste des appels pfs
   */
  @SerializedName("items")
  @Expose
  private List<AppelPfs> _items;

  /**
   * @return the items
   */
  public List<AppelPfs> getItems()
  {
    return _items != null ? new ArrayList<>(_items) : new ArrayList<>();

  }

  /**
   * @return the resultsCount
   */
  public String getResultsCount()
  {
    return _resultsCount;
  }

  /**
   * @param items_p
   *          the items to set
   */
  public void setItems(List<AppelPfs> items_p)
  {
    _items = items_p != null ? new ArrayList<>(items_p) : new ArrayList<>();
  }

  /**
   * @param resultsCount_p
   *          the resultsCount to set
   */
  public void setResultsCount(String resultsCount_p)
  {
    _resultsCount = resultsCount_p;
  }

}
