/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : 814_837_RessourceMessage
 *  Package : com.bytel.spirit.fiat.processes.PE0275.structs
 *  Classe  : PE0275_BL001PutRetour
 *  Auteur  : sdiop
 *
 */

package com.bytel.spirit.fiat.processes.PE0275.structs;

import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.functional.types.json.MessagesPfs;

/**
 * @author fmonteir
 * @version ($Revision$ $Date$)
 */
public class PE0275_BL001PostRetour
{

  /**
   * messages Pfs
   */
  private MessagesPfs _messagesPfs;
  /**
   * Identifiant du message produit par SPIRIT
   */
  private String _idMessagerie;

  /**
   * Type de l’operation a executer
   */
  private OperationMessage _typeOperation;

  /**
   * Mode d’appel utilisés pour solliciter le service
   */
  private String _modeAppel;

  /**
   * Liste NoContrat B2R
   */
  private List<String> _listeContratOauth;

  public PE0275_BL001PostRetour()
  {
    super();
  }

  /**
   * @param messagesPfs_p
   *          messagesPfs_p
   * @param idMessage_p
   *          idMessage_p
   * @param typeOperation_p
   *          typeOperation_p
   * @param modeAppel_p
   *          modeAppel_p
   * @param listeContratOauth_p
   *          listeContratOauth_p
   */
  public PE0275_BL001PostRetour(MessagesPfs messagesPfs_p, String idMessagerie_p, OperationMessage typeOperation_p, String modeAppel_p, List<String> listeContratOauth_p)
  {
    _messagesPfs = messagesPfs_p;
    _idMessagerie = idMessagerie_p;
    _typeOperation = typeOperation_p;
    _modeAppel = modeAppel_p;
    _listeContratOauth = new ArrayList<>(listeContratOauth_p);
  }

  /**
   * @return _idMessage
   */
  public String getIdMessagerie()
  {
    return _idMessagerie;
  }

  /**
   * @return _listeContratOauth
   */
  public List<String> getListeContratOauth()
  {
    return _listeContratOauth != null ? new ArrayList<>(_listeContratOauth) : new ArrayList<>();
  }

  /**
   * @return value of messagesPfs
   */
  public MessagesPfs getMessagesPfs()
  {
    return _messagesPfs;
  }

  /**
   * @return _modeAppel
   */
  public String getModeAppel()
  {
    return _modeAppel;
  }

  /**
   * @return _typeOperation
   */
  public OperationMessage getTypeOperation()
  {
    return _typeOperation;
  }

  /**
   * @param idMessage_p
   *          _idMessage
   */
  public void setIdMessagerie(String idMessage_p)
  {
    _idMessagerie = idMessage_p;
  }

  /**
   * @param listeContratOauth_p
   *          _listeContratOauth
   */
  public void setListeContratOauth(List<String> listeContratOauth_p)
  {
    _listeContratOauth = listeContratOauth_p != null ? new ArrayList<>(listeContratOauth_p) : new ArrayList<>();

  }

  /**
   * @param messagesPfs_p
   *          The messagesPfs to set.
   */
  public void setMessagesPfs(MessagesPfs messagesPfs_p)
  {
    _messagesPfs = messagesPfs_p;
  }

  /**
   * @param modeAppel_p
   *          _modeAppel
   */
  public void setModeAppel(String modeAppel_p)
  {
    _modeAppel = modeAppel_p;
  }

  /**
   * @param typeOperation_p
   *          _typeOperation
   */
  public void setTypeOperation(OperationMessage typeOperation_p)
  {
    _typeOperation = typeOperation_p;
  }
}
