/*******************************************************************************
* $Id: PE0206_ComplementAdresse.java 14954 2018-12-20 11:10:00Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206.sti;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 14954 $ $Date: 2018-12-20 12:10:00 +0100 (jeu., 20 déc. 2018) $)
 */
public class PE0206_ComplementAdresse implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -690314998994822586L;

  /**
   * batiment
   */
  @SerializedName("batiment")
  @Expose
  private String _batiment;

  /**
   * escalier
   */
  @SerializedName("escalier")
  @Expose
  private String _escalier;

  /**
   * etage
   */
  @SerializedName("etage")
  @Expose
  private String _etage;

  /**
   * @return the batiment
   */
  public String getBatiment()
  {
    return _batiment;
  }

  /**
   * @return the escalier
   */
  public String getEscalier()
  {
    return _escalier;
  }

  /**
   * @return the etage
   */
  public String getEtage()
  {
    return _etage;
  }

  /**
   * @param batiment_p
   *          the batiment to set
   */
  public void setBatiment(String batiment_p)
  {
    _batiment = batiment_p;
  }

  /**
   * @param escalier_p
   *          the escalier to set
   */
  public void setEscalier(String escalier_p)
  {
    _escalier = escalier_p;
  }

  /**
   * @param etage_p
   *          the etage to set
   */
  public void setEtage(String etage_p)
  {
    _etage = etage_p;
  }

}
