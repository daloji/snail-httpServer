/*******************************************************************************
* $Id: PE0298_Audit.java 15184 2019-01-02 15:09:51Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0298.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.SerializedName;
import com.squareup.moshi.Json;

/**
 *
 * @author jramos
 * @version ($Revision: 15184 $ $Date: 2019-01-02 16:09:51 +0100 (mer. 02 janv. 2019) $)
 */
public class PE0298_Audit implements Serializable

{
  /**
   * Diagnostic
   *
   * @author jgregori
   * @version ($Revision: 15184 $ $Date: 2019-01-02 16:09:51 +0100 (mer. 02 janv. 2019) $)
   */
  public enum Diagnostic
  {
    /**
     * DESYNCHRO_PFS
     */
    DESYNCHRO_PFS,
    /**
     * SERVICE_NON_PROVISIONNE
     */
    SERVICE_NON_PROVISIONNE
  }

  /**
   *
   */
  private static final long serialVersionUID = -3802115787380561658L;

  /**
   * Type de desynchronisation detectee
   */
  @SerializedName("diagnostic")
  @Json(name = "diagnostic")
  private String _diagnostic;

  /**
   * Libelle libre
   */
  @SerializedName("libelle")
  @Json(name = "libelle")
  private String _libelle;

  /**
   * Liste des parametres incorrect sur la plateforme de service
   */
  @SerializedName("parametres")
  @Json(name = "parametres")
  private List<String> _parametres;

  /**
   *
   */
  public PE0298_Audit()
  {
    super();
  }

  /**
   * @param diagnostic_p
   *          diagnostic_p
   * @param libelle_p
   *          libelle_p
   */
  public PE0298_Audit(String diagnostic_p, String libelle_p)
  {
    super();
    _diagnostic = diagnostic_p;
    _libelle = libelle_p;
  }

  /**
   * Add a new parameter to the list of parameters
   *
   * @param parameter_p
   *          The parameter name to add
   */
  public void addParameter(String parameter_p)
  {
    if (_parametres == null)
    {
      _parametres = new ArrayList<>();
    }
    _parametres.add(parameter_p);
  }

  /**
   * Add a list of parameter to the list of parameters
   *
   * @param parameters_p
   *          The list of parameter names to add
   */
  public void addParameters(List<String> parameters_p)
  {
    if (_parametres == null)
    {
      _parametres = new ArrayList<>();
    }
    _parametres.addAll(parameters_p);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0298_Audit other = (PE0298_Audit) obj;
    if (_diagnostic == null)
    {
      if (other._diagnostic != null)
      {
        return false;
      }
    }
    else if (!_diagnostic.equals(other._diagnostic))
    {
      return false;
    }
    if (_libelle == null)
    {
      if (other._libelle != null)
      {
        return false;
      }
    }
    else if (!_libelle.equals(other._libelle))
    {
      return false;
    }
    if (_parametres == null)
    {
      if (other._parametres != null)
      {
        return false;
      }
    }
    else if (!_parametres.equals(other._parametres))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the diagnostic
   */
  public String getDiagnostic()
  {
    return _diagnostic;
  }

  /**
   * @return the libelle
   */
  public String getLibelle()
  {
    return _libelle;
  }

  /**
   * @return the parametres
   */
  public List<String> getParametres()
  {

    return _parametres != null ? new ArrayList<>(_parametres) : null;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_diagnostic == null) ? 0 : _diagnostic.hashCode());
    result = (prime * result) + ((_libelle == null) ? 0 : _libelle.hashCode());
    result = (prime * result) + ((_parametres == null) ? 0 : _parametres.hashCode());
    return result;
  }

  /**
   * @param diagnostic_p
   *          the diagnostic to set
   */
  public void setDiagnostic(String diagnostic_p)
  {
    _diagnostic = diagnostic_p;
  }

  /**
   * @param libelle_p
   *          the libelle to set
   */
  public void setLibelle(String libelle_p)
  {
    _libelle = libelle_p;
  }

  /**
   * @param parametres_p
   *          the parametres to set
   */
  public void setParametres(List<String> parametres_p)
  {
    _parametres = parametres_p != null ? new ArrayList<>(parametres_p) : null;
  }

  @Override
  public String toString()
  {
    return "Audit [_diagnostic=" + _diagnostic + ", _libelle=" + _libelle + ", _parametres=" + _parametres + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
  }

}
