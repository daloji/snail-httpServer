/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0279;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.cxf.common.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.oi.OI_SI004_Fibres;
import com.bytel.spirit.common.activities.oi.OI_SI004_Fibres.OI_SI004_FibresBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibre;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibres;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0279.structs.PE0279_BL001_VerifierDonneesFibresReturn;
import com.bytel.spirit.fiat.processes.PE0279.structs.PE0279_Retour;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0279_Fibres extends SpiritRestApiProcessSkeleton
{
  /**
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  public interface IRequestParameters
  {
    /**
    *
    */
    public static final String OI = "OI"; //$NON-NLS-1$
    /**
    *
    */
    public static final String LISTE_ETAT = "listeEtat"; //$NON-NLS-1$
    /**
     *
     */
    public static final String REFERENCE_PM = "referencePM"; //$NON-NLS-1$
    /**
     *
     */
    public static final String REFERENCE_PBO = "referencePBO"; //$NON-NLS-1$
    /**
    *
    */
    public static final String REF_PRESTATION_PRISE = "refPrestationPrise"; //$NON-NLS-1$

  }

  /**
   * PE0279_RessourcesEmutation context.
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  public static final class PE0279_FibresContext extends Context
  {
    /**
     *
     */
    private static final long serialVersionUID = 1691753815560906051L;
    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0279_BL001;

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }
  }

  /**
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * PE279_BL001_VerifierDonneesFibres.
     */
    PE0279_BL001(MandatoryProcessState.PRC_START, false, false),

    /**
     * PE0279_B500_FiltrerFibres.
     */
    PE0279_B500(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
     * PE279_BL002_FormaterReponseFibres.
     */
    PE0279_BL002(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * Authorized values for listeEtat
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  private enum ListeEtat
  {
    /**
     * fibre disponible
     */
    FIBRE_DISPONIBLE("fibre disponible"), //$NON-NLS-1$
    /**
     * fibre dédiée disponible
     */
    FIBRE_DEDIEE_DISPONIBLE("fibre dédiée disponible"), //$NON-NLS-1$
    /**
     * fibre réservée
     */
    FIBRE_RESERVEE("fibre réservée"), //$NON-NLS-1$
    /**
     * fibre occupée
     */
    FIBRE_OCCUPEE("fibre occupée"), //$NON-NLS-1$
    /**
     * fibre hors service
     */
    FIBRE_HORS_SERVICE("fibre hors service"); //$NON-NLS-1$

    /**
     * @param etat_p
     * @return
     */
    public static boolean containsValue(String etat_p)
    {
      EnumSet<ListeEtat> enumSet = EnumSet.allOf(ListeEtat.class);
      Iterator<ListeEtat> it = enumSet.iterator();
      while (it.hasNext())
      {
        ListeEtat le = it.next();
        if (le.getInputName().equals(etat_p))
        {
          return true;
        }
      }
      return false;
    }

    /**
     *
     */
    private final String _inputName;

    /**
     * Constructor
     *
     * @param string_p
     *          string
     */
    ListeEtat(String string_p)
    {
      _inputName = string_p;
    }

    /**
     * @return
     */
    String getInputName()
    {
      return _inputName;

    }
  }

  /**
   *
   */
  private static final long serialVersionUID = -6037433405457118327L;

  /**
   * Constant for invalid headers message
   */
  private static final String INVALID_HEADERS_MESSAGE = Messages.getString("PE0279.BL001.HeaderNullOrEmpty"); //$NON-NLS-1$

  /**
  *
  */
  private static final String INVALID_PARAMETERS_MESSAGE = Messages.getString("PE0279.BL001.ParametersNullOrEmpty"); //$NON-NLS-1$

  /**
  *
  */
  private static final String INVALID_FIELD_MESSAGE = Messages.getString("PE0279.BL001.InvalidFieldValue"); //$NON-NLS-1$

  /**
   * the provess context
   */
  private PE0279_FibresContext _processContext;

  /**
   *
   */
  public PE0279_Fibres()
  {
    //TODO Auto-generated constructor stub
  }

  @Override
  public String createDefaultFunctionalResponse(Retour arg0_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    super.initializeContext();
    _processContext = new PE0279_FibresContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    // TODO Auto-generated method stub
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    Pair<List<Fibre>, Retour> bl500Result = new Pair<>(null, RetourFactory.createOkRetour());

    try
    {
      _processContext.setState(State.PE0279_BL001);
      PE0279_BL001_VerifierDonneesFibresReturn bl001Result = PE0279_BL001_VerifierDonneesFibres(tracabilite_p, request_p);
      retour = bl001Result.getRetour();
      if (isRetourOK(retour))
      {
        OI_SI004_Fibres si004 = new OI_SI004_FibresBuilder().tracabilite(tracabilite_p).codeOi(bl001Result.getOi()).references(bl001Result.getReferencePM(), bl001Result.getReferencePBO(), bl001Result.getRefPrestationPrise()).build();
        Fibres fibres = si004.execute(this);
        retour = si004.getRetour();
        if (isRetourOK(retour))
        {
          _processContext.setState(State.PE0279_B500);
          bl500Result = PE0279_BL500_FiltrerFibres(tracabilite_p, fibres.getFibres(), bl001Result.getListeEtat());
          retour = bl500Result._second;
        }
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, e.getMessage());
    }
    finally
    {
      _processContext.setState(State.PE0279_BL002);
      Pair<ReponseErreur, PE0279_Retour> bl002Response = PE0279_BL002_FormaterReponseFibres(tracabilite_p, bl500Result._first, retour);
      this.setRetour(retour);
      syncGetResponse(request_p, tracabilite_p, bl002Response._second, bl002Response._first);
      _processContext.setState(State.ENDED);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // TODO Auto-generated method stub
  }

  /**
   * Get the URL parameters into the ProcessContext.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param parametersMap_p
   *          parameters
   * @param request_p
   *          request
   *
   * @return Object STI
   */
  private Retour checkIRequestParameters(Tracabilite tracabilite_p, final Map<String, String> parametersMap_p, final Request request_p)
  {
    //Fill the values of the required parameters, from the request object
    fillParametersMapFromRequest(parametersMap_p, request_p);

    Iterator<String> parametersIterator = parametersMap_p.keySet().iterator();
    //check if the values of the required parameters are set, if not return NOK immediately

    while (parametersIterator.hasNext())
    {
      String parameterName = parametersIterator.next();
      if (!IRequestParameters.LISTE_ETAT.equals(parameterName) && StringTools.isNullOrEmpty(parametersMap_p.get(parameterName)))
      {
        String libelleErreur = MessageFormat.format(INVALID_PARAMETERS_MESSAGE, parameterName);
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
      }
      if (IRequestParameters.LISTE_ETAT.equals(parameterName) && StringTools.isNotNullOrEmpty(parametersMap_p.get(parameterName)))
      {
        String[] etatArray = StringUtils.commaDelimitedListToStringArray(parametersMap_p.get(parameterName));
        etatArray = StringUtils.trimArrayElements(etatArray);
        for (String etat : etatArray)
        {
          if (!ListeEtat.containsValue(etat))
          {
            String libelleErreur = MessageFormat.format(INVALID_FIELD_MESSAGE, parameterName);
            RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
            return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
          }
        }
      }
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Validates that each key in the headersMap_p has a value in the request_p parameter, and if yes set the
   * corresponding value.
   *
   * @param tracabilite_p
   *          tracabilite
   * @param headersMap_p
   *          Map containing the header names as keys
   * @param request_p
   *          The original request containing all headers
   *
   * @return Retour OK if all the headers in the headersMap_p are set, NOK otherwise
   */
  private Retour checkRequestHeaders(Tracabilite tracabilite_p, Map<String, String> headersMap_p, final Request request_p)
  {
    //fill the values of the required headers from the request object
    fillHeaderMapFromRequest(headersMap_p, request_p);

    Iterator<String> headersIterator = headersMap_p.keySet().iterator();
    //check if the values of the required headers are set, if not return NOK immediately
    while (headersIterator.hasNext())
    {
      String headerName = headersIterator.next();
      if (StringTools.isNullOrEmpty(headersMap_p.get(headerName)))
      {
        String libelleErreur = MessageFormat.format(INVALID_HEADERS_MESSAGE, headerName);
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
      }
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Fill the values in the headersMap_p parameters, using the headers in the request_p parameter.
   *
   * @param headersMap_p
   *          The map containing the headers to fill
   * @param request_p
   *          The request object containing all the headers
   */
  private void fillHeaderMapFromRequest(final Map<String, String> headersMap_p, final Request request_p)
  {
    if ((headersMap_p != null) && !headersMap_p.keySet().isEmpty())
    {
      for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
      {
        if (headersMap_p.containsKey(header.getName()))
        {
          headersMap_p.put(header.getName(), header.getValue()); //fill value for the specified header
        }
      }
    }
  }

  /**
   * Fill the values in the parametersMap_p using the parameters in the request_p.
   *
   * @param parametersMap_p
   *          parameters
   * @param request_p
   *          request
   */
  private void fillParametersMapFromRequest(Map<String, String> parametersMap_p, Request request_p)
  {
    if ((parametersMap_p != null) && !parametersMap_p.keySet().isEmpty())
    {
      List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();
      for (Parameter parametre : urlParametersType)
      {
        if (parametersMap_p.containsKey(parametre.getName()))
        {
          parametersMap_p.put(parametre.getName(), parametre.getValue()); //fill value for the specified parameter
        }
      }
    }
  }

  /**
   * PE0279_BL001_VerifierDonneesFibres.
   *
   * @param tracabilite_p
   *          tracabilite_p
   * @param request_p
   *          request
   *
   * @return {@link PE0279_BL001_VerifierDonneesFibresReturn}
   */
  @LogProcessBL
  private PE0279_BL001_VerifierDonneesFibresReturn PE0279_BL001_VerifierDonneesFibres(Tracabilite tracabilite_p, Request request_p)
  {
    Retour retour = RetourFactory.createOkRetour();
    PE0279_BL001_VerifierDonneesFibresReturn bl001Return = new PE0279_BL001_VerifierDonneesFibresReturn(retour);

    //Crete a map to store all the required headers names to validate, ignoring case of the header name
    Map<String, String> headersMap = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    headersMap.put(IHttpHeadersConsts.X_SOURCE, null);
    headersMap.put(IHttpHeadersConsts.X_PROCESS, null);
    headersMap.put(IHttpHeadersConsts.X_REQUEST_ID, null);

    retour = checkRequestHeaders(tracabilite_p, headersMap, request_p);
    bl001Return.setRetour(retour);
    if (isRetourOK(retour))
    {
      Map<String, String> parametersMap = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
      parametersMap.put(IRequestParameters.OI, null);
      parametersMap.put(IRequestParameters.LISTE_ETAT, null);
      parametersMap.put(IRequestParameters.REFERENCE_PM, null);
      parametersMap.put(IRequestParameters.REFERENCE_PBO, null);
      parametersMap.put(IRequestParameters.REF_PRESTATION_PRISE, null);

      retour = checkIRequestParameters(tracabilite_p, parametersMap, request_p);
      bl001Return.setRetour(retour);
      if (isRetourOK(retour))
      {
        bl001Return.setOi(parametersMap.get(IRequestParameters.OI));
        String[] etatArray = StringUtils.commaDelimitedListToStringArray(parametersMap.get(IRequestParameters.LISTE_ETAT));
        bl001Return.setListeEtat(Arrays.asList(StringUtils.trimArrayElements(etatArray)));
        bl001Return.setReferencePM(parametersMap.get(IRequestParameters.REFERENCE_PM));
        bl001Return.setReferencePBO(parametersMap.get(IRequestParameters.REFERENCE_PBO));
        bl001Return.setRefPrestationPrise(parametersMap.get(IRequestParameters.REF_PRESTATION_PRISE));
      }
    }
    //log response
    RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, bl001Return.toString()));
    return bl001Return;
  }

  /**
   * PE0279_BL002_FormaterReponseFibres
   *
   * @param listeFibresFiltree_p
   *          ListeFibresFiltree
   * @param retour_p
   *          retour
   *
   * @return reponseErreur
   */
  @LogProcessBL
  private Pair<ReponseErreur, PE0279_Retour> PE0279_BL002_FormaterReponseFibres(Tracabilite tracabilite_p, List<Fibre> listeFibresFiltree_p, Retour retour_p)
  {
    ReponseErreur responseErreur = null;
    PE0279_Retour pe0279Retour = null;

    if (isRetourOK(retour_p))
    {
      pe0279Retour = new PE0279_Retour();

      if (!CollectionUtils.isEmpty(listeFibresFiltree_p))
      {
        List<com.bytel.spirit.fiat.shared.types.json.Fibre> fibres = new ArrayList<>();
        for (Fibre fibre : listeFibresFiltree_p)
        {
          fibres.add(new com.bytel.spirit.fiat.shared.types.json.Fibre(fibre));
        }
        pe0279Retour.setResultsCount(fibres.size());
        pe0279Retour.setItems(fibres);
      }
    }
    else
    {
      responseErreur = new ReponseErreur();
      responseErreur.setError(retour_p.getDiagnostic());
      responseErreur.setErrorDescription(retour_p.getLibelle());
    }
    return new Pair<ReponseErreur, PE0279_Retour>(responseErreur, pe0279Retour);
  }

  /**
   * PE0279_B500_FiltrerFibres
   *
   * @param tracabilite_p
   *          tracabilite
   * @param listeFibre_p
   *          ListeFibre
   * @param listeEtat_p
   *          ListEtat
   *
   * @return Pair of Fibres and Retour
   */
  @LogProcessBL
  private Pair<List<Fibre>, Retour> PE0279_BL500_FiltrerFibres(Tracabilite tracabilite_p, List<Fibre> listeFibre_p, List<String> listeEtat_p)
  {
    List<Fibre> listeFibresFiltree = new ArrayList<>();

    if (CollectionUtils.isEmpty(listeEtat_p))
    {
      listeFibresFiltree.addAll(listeFibre_p);
    }
    else
    {
      for (Fibre fibre : listeFibre_p)
      {
        if (listeEtat_p.contains(fibre.getEtatFibre()))
        {
          listeFibresFiltree.add(fibre);
        }
      }
    }
    return new Pair<>(listeFibresFiltree, RetourFactory.createOkRetour());
  }

  /**
   * prepare response
   *
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @param pe279retour
   *          object retour
   * @param reponserreur_p
   *          erreur response
   */
  private void syncGetResponse(Request request_p, Tracabilite tracabilite_p, PE0279_Retour pe279retour, ReponseErreur reponserreur_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
      Response rsp;

      if (reponserreur_p != null)
      {
        ravelResponse.setResult(GsonTools.getIso8601Ms().toJson(reponserreur_p));
        ErrorCode errorCode = ErrorCode.KO_00500; //Unknown error

        if (IMegSpiritConsts.NON_RESPECT_STI.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00400;
        }
        else if (IMegSpiritConsts.PBO_INCONNU.equals(reponserreur_p.getError()) || IMegSpiritConsts.ECHEC_PARTENAIRE.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00404;
        }
        else if (IMegConsts.SERVICE_TIERS_INDISPONIBLE.equals(reponserreur_p.getError()) || IMegSpiritConsts.FLUX_BIENTOT_DISPONIBLE.equals(reponserreur_p.getError()) || IMegSpiritConsts.FLUX_INDISPONIBLE.equals(reponserreur_p.getError()))
        {

          errorCode = ErrorCode.KO_00503;
        }

        rsp = new Response(errorCode, ravelResponse);
      }
      else
      {
        //Add empty Json in case OK
        ravelResponse.setResult(GsonTools.getIso8601Ms().toJson(pe279retour));
        rsp = new Response(ErrorCode.OK_00200, ravelResponse);
      }

      request_p.setResponse(rsp);
    }
  }

}
