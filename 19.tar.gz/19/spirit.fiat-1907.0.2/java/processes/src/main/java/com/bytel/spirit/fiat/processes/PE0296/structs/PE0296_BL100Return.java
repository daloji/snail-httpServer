/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0296.structs;

import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class PE0296_BL100Return extends AbstractBLReturn
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;
  /**
   *
   */
  List<String> _listeIdRessourceRaccordement = new ArrayList<String>();

  /**
   * @param retour_p
   *          retour
   */
  public PE0296_BL100Return(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @param retour_p
   *          retour
   * @param listeIdRessourceRaccordement_p
   *          listeIdRessourceRaccordement
   */
  public PE0296_BL100Return(Retour retour_p, List<String> listeIdRessourceRaccordement_p)
  {
    super(retour_p);
    _listeIdRessourceRaccordement = listeIdRessourceRaccordement_p;
  }

  /**
   * @return the listeIdRessourceRaccordement
   */
  public List<String> getListeIdRessourceRaccordement()
  {
    return _listeIdRessourceRaccordement != null ? new ArrayList<>(_listeIdRessourceRaccordement) : null;
  }

  /**
   * @param listeIdRessourceRaccordement_p
   *          the listeIdRessourceRaccordement to set
   */
  public void setListeIdRessourceRaccordement(List<String> listeIdRessourceRaccordement_p)
  {
    _listeIdRessourceRaccordement = listeIdRessourceRaccordement_p != null ? new ArrayList<>(listeIdRessourceRaccordement_p) : null;

  }

}
