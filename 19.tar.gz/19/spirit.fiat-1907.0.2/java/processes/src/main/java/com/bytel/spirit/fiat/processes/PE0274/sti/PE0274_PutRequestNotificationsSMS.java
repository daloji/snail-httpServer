/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.functional.types.json.NotificationSMS;
import com.squareup.moshi.Json;

/**
 * NotificationsSMS Payload
 *
 * @author fmonteir
 * @version ($Revision$ $Date$)
 */
public class PE0274_PutRequestNotificationsSMS implements Serializable
{
  /**
   * The id for serialization
   */
  private static final long serialVersionUID = 5477501727996207773L;

  /**
   * statutNotificationsSMS
   */
  @Json(name = "statutNotificationsSMS")
  private String _statutNotificationsSMS;

  /**
   * notificationsSMS
   */
  @Json(name = "notificationsSMS")
  private List<NotificationSMS> _notificationsSMS;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0274_PutRequestNotificationsSMS other = (PE0274_PutRequestNotificationsSMS) obj;
    if (_notificationsSMS == null)
    {
      if (other._notificationsSMS != null)
      {
        return false;
      }
    }
    else if (!_notificationsSMS.equals(other._notificationsSMS))
    {
      return false;
    }
    if (_statutNotificationsSMS == null)
    {
      if (other._statutNotificationsSMS != null)
      {
        return false;
      }
    }
    else if (!_statutNotificationsSMS.equals(other._statutNotificationsSMS))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the notificationsSMS
   */
  public List<NotificationSMS> getNotificationsSMS()
  {
    return _notificationsSMS != null ? new ArrayList<>(_notificationsSMS) : new ArrayList<>();
  }

  /**
   * @return the statutNotificationsSMS
   */
  public String getStatutNotificationsSMS()
  {
    return _statutNotificationsSMS;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_notificationsSMS == null) ? 0 : _notificationsSMS.hashCode());
    result = (prime * result) + ((_statutNotificationsSMS == null) ? 0 : _statutNotificationsSMS.hashCode());
    return result;
  }

  /**
   * @param notificationsSMS_p
   *          the notificationsSMS to set
   */
  public void setNotificationsSMS(List<NotificationSMS> notificationsSMS_p)
  {
    _notificationsSMS = new ArrayList<>(notificationsSMS_p);
  }

  /**
   * @param statutNotificationsSMS_p
   *          the statutNotificationsSMS to set
   */
  public void setStatutNotificationsSMS(String statutNotificationsSMS_p)
  {
    _statutNotificationsSMS = statutNotificationsSMS_p;
  }
}
