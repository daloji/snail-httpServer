/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PM001;

/**
 *
 * @author $Author$
 * @version ($Revision$ $Date$)
 */
public final class ConstantesRetour
{
  /**
   * Code retour OK
   */
  public static final String CODE_RETOUR_OK = "0000"; //$NON-NLS-1$

  /**
   * Libelle de retour OK
   */
  public static final String LIBELLE_RETOUR_OK = "TRAITE AVEC SUCCES"; //$NON-NLS-1$

  /**
   * Code retour MSISDN format incorrect
   */
  public static final String CODE_RETOUR_MSISDN_FORMAT_INCORRECT = "1000"; //$NON-NLS-1$

  /**
   * Libelle de retour MSISDN format incorrect
   */
  public static final String LIBELLE_RETOUR_MSISDN_FORMAT_INCORRECT = "MSISDN {0} AU FORMAT INCORRECT"; //$NON-NLS-1$

  /**
   * Code retour KO pendant la recherche du PFI
   */
  public static final String CODE_RETOUR_KO_PFI = "1001"; //$NON-NLS-1$

  /**
   * Libelle de retour KO pendant la recherche du PFI
   */
  public static final String LIBELLE_RETOUR_KO_PFI = "MSISDN {0} NON ACTIF"; //$NON-NLS-1$

  /**
   * Code retour KO pendant la recherche de l'instance VMS
   */
  public static final String CODE_RETOUR_KO_INSTANCE = "1003"; //$NON-NLS-1$

  /**
   * Libelle de retour KO pendant la recherche de l'instance VMS
   */
  public static final String LIBELLE_RETOUR_KO_INSTANCE = "INSTANCE DE VMS INTROUVABLE POUR LE MSISDN {0}"; //$NON-NLS-1$

  /**
   * Code retour IMSI au format incorrect
   */
  public static final String CODE_RETOUR_IMSI_FORMAT_INCORRECT = "1004"; //$NON-NLS-1$

  /**
   * Libelle de retour IMSI au format incorrect
   */
  public static final String LIBELLE_RETOUR_IMSI_FORMAT_INCORRECT = "IMSI {0,number,#} AU FORMAT INCORRECT"; //$NON-NLS-1$

  /**
   * Code retour ICCID au format incorrect
   */
  public static final String CODE_RETOUR_ICCID_FORMAT_INCORRECT = "1005"; //$NON-NLS-1$

  /**
   * Libelle de retour ICCID au format incorrect
   */
  public static final String LIBELLE_RETOUR_ICCID_FORMAT_INCORRECT = "ICCID {0,number,#} AU FORMAT INCORRECT"; //$NON-NLS-1$

  /**
   * Code retour IMSI au format incorrect
   */
  public static final String CODE_RETOUR_IMSI_INCONNU = "1006"; //$NON-NLS-1$

  /**
   * Libelle de retour IMSI au format incorrect
   */
  public static final String LIBELLE_RETOUR_IMSI_INCONNU = "IMSI {0,number,#} INCONNU"; //$NON-NLS-1$

  /**
   * Code retour ICCID au format incorrect
   */
  public static final String CODE_RETOUR_ICCID_INCONNU = "1007"; //$NON-NLS-1$

  /**
   * Libelle de retour ICCID au format incorrect
   */
  public static final String LIBELLE_RETOUR_ICCID_INCONNU = "ICCID {0,number,#} INCONNU"; //$NON-NLS-1$

  /**
   * Code retour KO technique bdd
   */
  public static final String CODE_RETOUR_KO_BDD = "2100"; //$NON-NLS-1$

  /**
   * Libelle de retour KO technique bdd
   */
  public static final String LIBELLE_RETOUR_KO_BDD = "ERREUR ORACLE [{0}]"; //$NON-NLS-1$

  /**
   *
   */
  private ConstantesRetour()
  {
    // TODO Auto-generated constructor stub
  }
}
