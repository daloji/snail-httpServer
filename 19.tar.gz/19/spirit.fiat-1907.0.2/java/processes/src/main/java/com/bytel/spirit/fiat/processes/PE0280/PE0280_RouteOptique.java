/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0280;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.oi.OI_SI005_MAJRouteOptique;
import com.bytel.spirit.common.activities.oi.OI_SI005_MAJRouteOptique.OI_SI005_MAJRouteOptiqueBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.ComplementAdresse;
import com.bytel.spirit.common.connector.oi.emutation.structs.ComplementAdresse.ComplementAdresseBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.CoordonneesGeo;
import com.bytel.spirit.common.connector.oi.emutation.structs.CoordonneesGeo.CoordonneesGeoBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.HexacleVoie;
import com.bytel.spirit.common.connector.oi.emutation.structs.HexacleVoie.HexacleVoieBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptiqueResponse;
import com.bytel.spirit.common.connector.oi.emutation.structs.QuadrupletRivoli;
import com.bytel.spirit.common.connector.oi.emutation.structs.QuadrupletRivoli.QuadrupletRivoliBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.ReferencesAdresse;
import com.bytel.spirit.common.connector.oi.emutation.structs.ReferencesAdresse.ReferencesAdresseBuilder;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0280.structs.PE0280_BL001_VerifierDonneesRouteOptiqueRetour;
import com.bytel.spirit.fiat.processes.PE0280.structs.PE0280_Request;
import com.bytel.spirit.fiat.processes.PE0280.structs.PE0280_Retour;

/**
 *
 * @author mfreire
 * @version ($Revision$ $Date$)
 */
public class PE0280_RouteOptique extends SpiritRestApiProcessSkeleton
{

  /**
   * Holds context data for E0280_RessourcesEmutation
   *
   * @author mfreire
   * @version ($Revision$ $Date$)
   */
  public static final class PE0280_RessourcesEmutationContext extends Context
  {

    /**
     *
     */
    private static final long serialVersionUID = -3468117458478978094L;

    /***
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0280_START;

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

  }

  /**
   *
   * @author mfreire
   * @version ($Revision$ $Date$)
   */

  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0280_START(MandatoryProcessState.PRC_START),

    /**
     *
     */
    PE0280_BL001(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
    *
    */
    PE0280_BL002(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
    *
    */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }

  }

  /**
   *
   */
  private static final long serialVersionUID = -9207643955285000867L;

  /**
   * COMPLEMENT_ADRESSE_CMD
   */
  public static final String COMPLEMENT_ADRESSE_CMD = "ComplementAdresseCmd"; //$NON-NLS-1$

  /**
   * COMPLEMENT_ADRESSE_TERRAIN
   */
  public static final String COMPLEMENT_ADRESSE_TERRAIN = "ComplementAdresseTerrain"; //$NON-NLS-1$

  /**
   * OI
   */
  public static final String OI = "OI"; //$NON-NLS-1$

  /**
   * REFPRESTATIONPRISE
   */
  public static final String REFPRESTATIONPRISE = "refPrestationPrise"; //$NON-NLS-1$

  /**
   * Constant for invalid headers message
   */
  private static final String INVALID_HEADERS_MESSAGE = Messages.getString("PE0280.BL001.HeaderNullOrEmpty"); //$NON-NLS-1$

  /**
  *
  */
  private static final String INVALID_PARAMETERS_MESSAGE = Messages.getString("PE0280.BL001.ParametersNullOrEmpty"); //$NON-NLS-1$

  /**
   * Process Context
   */
  private PE0280_RessourcesEmutationContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour arg0_p) throws RavelException
  {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    super.initializeContext();
    _processContext = new PE0280_RessourcesEmutationContext();

  }

  @Override
  public boolean isAsynchronous()
  {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public boolean isReplayable()
  {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    // TODO Auto-generated method stub

  }

  @Override
  protected void startMetroLog()
  {
    // TODO Auto-generated method stub

  }

  @Override
  @LogStartProcess
  protected void startPutProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    MAJRouteOptiqueResponse result = null;
    try
    {

      _processContext.setState(State.PE0280_BL001);
      Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour> retBL001 = PE0280_BL001_VerifierDonneesRouteOptique(tracabilite_p, request_p);

      retour = retBL001._second;
      if (isRetourOK(retour))
      {

        OI_SI005_MAJRouteOptique si005 = new OI_SI005_MAJRouteOptiqueBuilder()//
            .codeOi(retBL001._first.getOi())//
            .complementAdresseCmd(retBL001._first.getComplementAdresseCmd())//
            .complementAdresseTerrain(retBL001._first.getComplementAdresseTerrain())//
            .identifiantFibre(retBL001._first.getIdentifiantFibre())//
            .motifMutation(retBL001._first.getMotifMutation())//
            .porte(retBL001._first.getPorte())//
            .referencePrise(retBL001._first.getReferencePrise())//
            .referencesAdresse(retBL001._first.getReferenceAddresse())//
            .tracabilite(tracabilite_p)//
            .build();
        result = si005.execute(this);
        retour = si005.getRetour();
      }

    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, exception));
      retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, exception.getMessage());
    }
    finally
    {
      _processContext.setState(State.PE0280_BL002);
      Pair<ReponseErreur, PE0280_Retour> retBL002 = PE0280_BL002_FormaterReponseRouteOptique(tracabilite_p, result, retour);
      this.setRetour(retour);
      syncPutResponse(request_p, tracabilite_p, retBL002._second, retBL002._first);
      _processContext.setState(State.ENDED);
    }

  }

  /**
   * @param pe0280BodyRequest_p
   * @param string2_p
   * @param oi_p
   * @param refPrestationPrise_p
   * @return
   */
  private PE0280_BL001_VerifierDonneesRouteOptiqueRetour buildBl001Retour(PE0280_Request pe0280BodyRequest_p, String oi_p, String refPrestationPrise_p)
  {
    PE0280_BL001_VerifierDonneesRouteOptiqueRetour bl001 = new PE0280_BL001_VerifierDonneesRouteOptiqueRetour();

    ReferencesAdresse referencesAdresseOI = buildReferenceAdresse(pe0280BodyRequest_p);
    ComplementAdresse complementAdressCmdOI = buildComplementAdresse(pe0280BodyRequest_p);
    ComplementAdresse complementAdressTerrainOI = buildComplementAdressTerrainOI(pe0280BodyRequest_p);

    bl001.setOi(oi_p);
    bl001.setRefPresentationPrise(refPrestationPrise_p);
    bl001.setReferencePrise(pe0280BodyRequest_p.getReferencePrise());
    bl001.setIdentifiantFibre(pe0280BodyRequest_p.getIdentifiantFibre());
    bl001.setMotifMutation(pe0280BodyRequest_p.getMotifMutation());
    bl001.setReferenceAddresse(referencesAdresseOI);
    bl001.setComplementAdresseCmd(complementAdressCmdOI);
    bl001.setComplementAdresseTerrain(complementAdressTerrainOI);
    bl001.setPorte(pe0280BodyRequest_p.getPorte());
    return bl001;
  }

  /**
   * @param pe0280BodyRequest_p
   * @return
   */
  private ComplementAdresse buildComplementAdresse(PE0280_Request pe0280BodyRequest_p)
  {

    ComplementAdresse complementAdresse = null;
    if (pe0280BodyRequest_p.getComplementAdresseCmd() != null)
    {
      String batiment = pe0280BodyRequest_p.getComplementAdresseCmd().getBatiment();
      String escalier = pe0280BodyRequest_p.getComplementAdresseCmd().getEscalier();
      String etage = pe0280BodyRequest_p.getComplementAdresseCmd().getEtage();
      complementAdresse = new ComplementAdresseBuilder()//
          .batiment(batiment)//
          .escalier(escalier)//
          .etage(etage)//
          .build();
    }
    return complementAdresse;
  }

  /**
   * @param pe0280BodyRequest_p
   * @return
   */
  private ComplementAdresse buildComplementAdressTerrainOI(PE0280_Request pe0280BodyRequest_p)
  {
    ComplementAdresse complementAdresse = null;
    if (pe0280BodyRequest_p.getComplementAdresseTerrain() != null)
    {
      String batiment = pe0280BodyRequest_p.getComplementAdresseTerrain().getBatiment();
      String escalier = pe0280BodyRequest_p.getComplementAdresseTerrain().getEscalier();
      String etage = pe0280BodyRequest_p.getComplementAdresseTerrain().getEtage();

      complementAdresse = new ComplementAdresseBuilder()//
          .batiment(batiment)//
          .escalier(escalier)//
          .etage(etage)//
          .build();
    }
    return complementAdresse;
  }

  /**
   * @param pe0280BodyRequest_p
   * @return
   */
  private ReferencesAdresse buildReferenceAdresse(PE0280_Request pe0280BodyRequest_p)
  {

    ReferencesAdresse referencesAdresse = null;
    if (pe0280BodyRequest_p.getReferencesAdresse() != null)
    {
      QuadrupletRivoli rivoliOI = null;
      HexacleVoie hexacleVoie = null;
      CoordonneesGeo referenceGeo = null;
      if (pe0280BodyRequest_p.getReferencesAdresse().getRivoli() != null)
      {
        String codeInsee = pe0280BodyRequest_p.getReferencesAdresse().getRivoli().getCodeInsee();
        String codeRivoli = pe0280BodyRequest_p.getReferencesAdresse().getRivoli().getCodeRivoli();
        Integer numeroVoie = pe0280BodyRequest_p.getReferencesAdresse().getRivoli().getNumeroVoie();
        String complementNumeroVoie = pe0280BodyRequest_p.getReferencesAdresse().getRivoli().getComplementNumeroVoie();

        rivoliOI = new QuadrupletRivoliBuilder() //
            .codeInsee(codeInsee) //
            .codeRivoli(codeRivoli) //
            .numeroVoie(numeroVoie)//
            .complementNumeroVoie(complementNumeroVoie)//
            .build();
      }
      if (pe0280BodyRequest_p.getReferencesAdresse().getHexacleVoie() != null)
      {
        String hexacleCodeVoie = pe0280BodyRequest_p.getReferencesAdresse().getHexacleVoie().getCodeHexacleVoie();
        Integer hexNumeroVoie = pe0280BodyRequest_p.getReferencesAdresse().getHexacleVoie().getNumeroVoie();
        String hexCompNumeroVoie = pe0280BodyRequest_p.getReferencesAdresse().getHexacleVoie().getComplementNumeroVoie();

        hexacleVoie = new HexacleVoieBuilder()//
            .codeHexaclevoie(hexacleCodeVoie)//
            .numeroVoie(hexNumeroVoie)//
            .complementNumeroVoie(hexCompNumeroVoie)//
            .build();
      }
      if (pe0280BodyRequest_p.getReferencesAdresse().getReferenceGeo() != null)
      {
        referenceGeo = new CoordonneesGeoBuilder()//
            .typeProjection(pe0280BodyRequest_p.getReferencesAdresse().getReferenceGeo().getTypeProjection())//
            .coordonneesX(pe0280BodyRequest_p.getReferencesAdresse().getReferenceGeo().getCoordonneesX())//
            .coordonneesY(pe0280BodyRequest_p.getReferencesAdresse().getReferenceGeo().getTypeProjection())//
            .build();
      }

      referencesAdresse = new ReferencesAdresseBuilder()//
          .hexacle(pe0280BodyRequest_p.getReferencesAdresse().getHexacle())//
          .rivoli(rivoliOI)//
          .hexacleVoie(hexacleVoie)//
          .referenceGeographique(referenceGeo)//
          .identifiantImmeuble(pe0280BodyRequest_p.getReferencesAdresse().getIdentifiantImeuble())//
          .adresseLibre(pe0280BodyRequest_p.getReferencesAdresse().getAdresseLibre())//
          .build();
    }

    return referencesAdresse;
  }

  /**
   * @param tracabilite_p
   * @param parametersMap_p
   * @param request_p
   * @return
   */

  @SuppressWarnings("javadoc")
  private Retour checkIRequestParameters(Tracabilite tracabilite_p, final Map<String, String> parametersMap_p, final Request request_p)
  {
    //fill the values of the required parameters, from the request object
    fillParametersMapFromRequest(parametersMap_p, request_p);

    Iterator<String> parametersIterator = parametersMap_p.keySet().iterator();
    //check if the values of the required parameters are set, if not return with NOK immediately
    while (parametersIterator.hasNext())
    {
      String parameterName = parametersIterator.next();
      if (StringTools.isNullOrEmpty(parametersMap_p.get(parameterName)))
      {
        String libelleErreur = MessageFormat.format(INVALID_PARAMETERS_MESSAGE, parameterName);
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
      }
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Validates that each key in headersMap_p has a value in the request_p parameter, and if yes set the corresponding
   * value.
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param headersMap_p
   *          Map containing the header names as keys.
   * @param request_p
   *          The request The original request containing all headers
   *
   * @return Retour OK if all the headers in the headersMap_p are set, NOK otherwise
   */
  private Retour checkRequestHeaders(Tracabilite tracabilite_p, Map<String, String> headersMap_p, final Request request_p)
  {

    //fill the values of the required headers, from the request object
    fillHeaderMapFromRequest(headersMap_p, request_p);

    Iterator<String> headersIterator = headersMap_p.keySet().iterator();
    //check if the values of the required headers are set, if not return with NOK immediately
    while (headersIterator.hasNext())
    {
      String headerName = headersIterator.next();
      if (StringTools.isNullOrEmpty(headersMap_p.get(headerName)))
      {
        String libelleErreur = MessageFormat.format(INVALID_HEADERS_MESSAGE, headerName);
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
      }
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Fill the values in the headersMap_p parameters, using the headers in the request_p paramter.
   *
   * @param headersMap_p
   *          The map containing the headers to fill
   * @param request_p
   *          The request objetct containing all the headers
   */
  private void fillHeaderMapFromRequest(final Map<String, String> headersMap_p, final Request request_p)
  {
    if ((headersMap_p != null) && !headersMap_p.keySet().isEmpty())
    {
      for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
      {
        if (headersMap_p.containsKey(header.getName()))
        {
          headersMap_p.put(header.getName(), header.getValue()); //fill value for the specified header
        }
      }
    }
  }

  /**
   * @param parametersMap_p
   *          parameters
   * @param request_p
   *          request
   */
  private void fillParametersMapFromRequest(Map<String, String> parametersMap_p, Request request_p)
  {
    if ((parametersMap_p != null) && !parametersMap_p.keySet().isEmpty())
    {
      List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();
      for (Parameter parametre : urlParametersType)
      {
        if (parametersMap_p.containsKey(parametre.getName()))
        {
          parametersMap_p.put(parametre.getName(), parametre.getValue()); //fill value for the specified parameter
        }
      }
    }
  }

  /**
   *
   * @param tracabilite_p
   * @param request_p
   * @return
   */
  @LogProcessBL
  private Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour> PE0280_BL001_VerifierDonneesRouteOptique(Tracabilite tracabilite_p, Request request_p)
  {
    // Prepare the values to return
    Retour retour;
    PE0280_BL001_VerifierDonneesRouteOptiqueRetour bl001Retour = new PE0280_BL001_VerifierDonneesRouteOptiqueRetour();

    //Execute traitement

    //Validation headers

    //create a map to store all required headers names to validate, ignoring case of the header name
    Map<String, String> headersMap = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    headersMap.put(IHttpHeadersConsts.X_SOURCE, null);
    headersMap.put(IHttpHeadersConsts.X_PROCESS, null);
    headersMap.put(IHttpHeadersConsts.X_REQUEST_ID, null); // Check in the FrontEnd

    retour = checkRequestHeaders(tracabilite_p, headersMap, request_p);
    if (!isRetourOK(retour))
    {
      return new Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour>(null, retour);
    }

    //Validation Parameters
    Map<String, String> parametersMap = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    parametersMap.put(OI, null);
    parametersMap.put(REFPRESTATIONPRISE, null);
    retour = checkIRequestParameters(tracabilite_p, parametersMap, request_p);

    if (!isRetourOK(retour))
    {
      return new Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour>(null, retour);
    }

    //Validation JSON
    PE0280_Request pe0280BodyRequest;
    try
    {
      pe0280BodyRequest = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request_p.getPayload(), PE0280_Request.class);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PE0280.BL001.StiError") + "\\n" + ExceptionTools.getStringStackTrace(e))); //$NON-NLS-1$ //$NON-NLS-2$
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0280.BL001.StiError")); //$NON-NLS-1$
      return new Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour>(null, retour);
    }

    retour = validatePE0280BodyRequest(tracabilite_p, pe0280BodyRequest);

    if (RetourFactory.isRetourOK(retour))
    {
      bl001Retour = buildBl001Retour(pe0280BodyRequest, parametersMap.get(OI), parametersMap.get(REFPRESTATIONPRISE));
    }

    Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour> retValues = new Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour>(bl001Retour, retour);

    return retValues;
  }

  /**
   * @param tracabilite_p
   * @param majRouteOptiqueResponse_p
   * @param retour_p
   * @return
   */
  @LogProcessBL
  private Pair<ReponseErreur, PE0280_Retour> PE0280_BL002_FormaterReponseRouteOptique(Tracabilite tracabilite_p, MAJRouteOptiqueResponse majRouteOptiqueResponse_p, Retour retour_p)
  {
    ReponseErreur responseErreur = null;
    PE0280_Retour pe0280 = null;

    if (isRetourOK(retour_p))
    {
      pe0280 = PE0280_Retour.initFromMAJRouteOptiqueResponse(majRouteOptiqueResponse_p);
    }

    else
    {
      responseErreur = new ReponseErreur();
      responseErreur.setError(retour_p.getDiagnostic());
      responseErreur.setErrorDescription(retour_p.getLibelle());

    }
    return new Pair<>(responseErreur, pe0280);
  }

  /**
   * prepare response
   *
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @param pe280retour
   *          object retour
   * @param reponserreur_p
   *          erreur response
   */
  private void syncPutResponse(Request request_p, Tracabilite tracabilite_p, PE0280_Retour pe280retour, ReponseErreur reponserreur_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp = null;

      if (reponserreur_p != null)
      {
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(GsonTools.getIso8601Ms().toJson(reponserreur_p));
        ErrorCode errorCode = ErrorCode.KO_00500; //Unknown error

        if (IMegSpiritConsts.NON_RESPECT_STI.equals(reponserreur_p.getError()) || IMegSpiritConsts.FIBRE_INCONNUE.equals(reponserreur_p.getError()) || IMegSpiritConsts.PBO_INCONNU.equals(reponserreur_p.getError()) || IMegSpiritConsts.ADRESSE_INCONNUE.equals(reponserreur_p.getError()) || IMegSpiritConsts.INCOMPATIBILITE_COMMANDE.equals(reponserreur_p.getError()) || IMegSpiritConsts.MOTIF_INVALIDE.equals(reponserreur_p.getError()) || IMegSpiritConsts.ECHEC_PARTENAIRE.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00400;
        }
        else if (IMegSpiritConsts.PRESTATION_PRISE_INCONNUE.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00404;
        }
        else if (IMegConsts.SERVICE_TIERS_INDISPONIBLE.equals(reponserreur_p.getError()) || IMegSpiritConsts.FLUX_BIENTOT_DISPONIBLE.equals(reponserreur_p.getError()) || IMegSpiritConsts.FLUX_INDISPONIBLE.equals(reponserreur_p.getError()))
        {
          errorCode = ErrorCode.KO_00503;
        }
        else
        {
          errorCode = ErrorCode.KO_00500;
        }

        rsp = new Response(errorCode, ravelResponse);

      }
      else
      {
        //Add empty Json in case OK
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(GsonTools.getIso8601Ms().toJson(pe280retour));
        rsp = new Response(ErrorCode.OK_00200, ravelResponse);
      }

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PE0280 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);

    }
  }

  /**
   * Validates the presence of required and conditional elements in the PE0280_Request object as specified in the STI
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param request_p
   *          The request
   * @return OK if valid, NOK NON_RESPECT_STI otherwise.
   */
  private Retour validatePE0280BodyRequest(Tracabilite tracabilite_p, PE0280_Request request_p)
  {
    if (request_p != null)
    {
      ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
      Validator validator = factory.getValidator();
      Set<ConstraintViolation<PE0280_Request>> constraintViolations = validator.validate(request_p); //validate request with hibernate validation framework
      factory.close();
      if (!constraintViolations.isEmpty())
      {
        Map<String, List<String>> validationMessages = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);//stores validation messages grouped by its type (format, required, conditional,etc..)

        for (ConstraintViolation<PE0280_Request> c : constraintViolations)
        {
          List<String> messageList = validationMessages.get(c.getMessage()); //get the the list of fields with the error stored in the key
          if (messageList == null)
          {
            validationMessages.put(c.getMessage(), new ArrayList<>(Arrays.asList(c.getPropertyPath().toString()))); //stores the validation error type as key and all the fields with the same error in a list as value
          }
          else
          {
            messageList.add(c.getPropertyPath().toString()); //add a new field name to the list
          }
        }
        //Formats the output validation message, concatenating all the errors found
        StringBuilder validationMessageSb = new StringBuilder();
        for (Entry<String, List<String>> validationEntry : validationMessages.entrySet())
        {
          if (validationMessageSb.length() > 0)
          {
            validationMessageSb.append(' ');
          }
          Collections.sort(validationMessages.get(validationEntry.getKey())); //sort alphabetic
          validationMessageSb.append(MessageFormat.format(Messages.getString(validationEntry.getKey()), validationEntry.getValue()));
        }

        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, validationMessageSb.toString()));
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, validationMessageSb.toString());
      }
    }
    else
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PE0280.BL001.BodyError"))); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0280.BL001.BodyError")); //$NON-NLS-1$
    }
    return RetourFactory.createOkRetour();
  }

}