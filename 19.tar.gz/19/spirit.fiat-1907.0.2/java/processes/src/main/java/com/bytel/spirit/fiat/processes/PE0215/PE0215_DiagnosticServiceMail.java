/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0215;

import static java.util.Objects.isNull;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.StringJoiner;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.BooleanTools;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.AbstractBLReturn;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail.BL3700_RecupererPfiParMailBuilder;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective;
import com.bytel.spirit.common.activities.shared.structs.BL3700_Return;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechnique;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechniqueMail;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.TypeAction;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesIdentificationSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesProvisionneesSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.common.shared.utils.PFIFilter;
import com.bytel.spirit.common.shared.utils.PFIFilterOption;
import com.bytel.spirit.common.shared.utils.PFIUtils;
import com.bytel.spirit.common.shared.utils.st.StLacFilter;
import com.bytel.spirit.common.shared.utils.st.StPfsMailFilter;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0215.structs.PE0215_Retour;
import com.bytel.spirit.fiat.shared.types.json.Audit;
import com.bytel.spirit.fiat.shared.types.json.Audit.Diagnostic;
import com.bytel.spirit.fiat.shared.types.json.Erreur;
import com.bytel.spirit.fiat.shared.types.json.Erreur.TypeError;
import com.bytel.spirit.fiat.shared.types.json.PFS;
import com.bytel.spirit.fiat.shared.types.json.PFS.TypePfs;
import com.bytel.spirit.fiat.shared.types.json.Referentiel;
import com.bytel.spirit.fiat.shared.types.json.Referentiel.TypeService;
import com.bytel.spirit.fiat.shared.types.json.Ressource;
import com.bytel.spirit.fiat.shared.types.json.Ressource.EtatAllocation;
import com.bytel.spirit.fiat.shared.types.json.Ressource.EtatRessource;
import com.bytel.spirit.fiat.shared.types.json.Ressource.TypeRessource;
import com.bytel.spirit.fiat.shared.types.json.response.ReponseFonctionnellePI0150C;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
public final class PE0215_DiagnosticServiceMail extends SpiritProcessSkeleton
{

  /**
   *
   * @author jramos
   * @version ($Revision$ $Date$) Object de Retour de la BL001
   */
  public static final class PE0215_BL001Return extends AbstractBLReturn
  {

    /**
     * Serial UID
     */
    private static final long serialVersionUID = -7346027498253463922L;
    /**
     * Client Operateur
     */
    private String _clientOperateur;
    /**
     * NoCompte
     */
    private String _noCompte;
    /**
     * IdRequest
     */
    private String _idRequest;
    /**
     * LoginMail
     */
    private String _loginMail;
    /**
     * IdentifiantFonctionnelPa
     */
    private String _identifiantFonctionnelPa;
    /**
     * SourceDonnee
     */
    private EnumSet<SourceDonne> _sourceDonnee;
    /**
     * Audit
     */
    private Boolean _audit;

    /**
     * @param retour_p
     *          retour
     */

    public PE0215_BL001Return(Retour retour_p)
    {
      super(retour_p);
    }

    /**
     * @param retour_p
     *          retour
     * @param sourceDonnee_p
     *          sourceDonnee
     * @param audit_p
     *          audit
     */
    public PE0215_BL001Return(Retour retour_p, EnumSet<SourceDonne> sourceDonnee_p, Boolean audit_p)
    {
      super(retour_p);
      if (sourceDonnee_p != null)
      {
        _sourceDonnee = sourceDonnee_p.clone();
      }
      else
      {
        _sourceDonnee = EnumSet.noneOf(SourceDonne.class);
      }
      _audit = audit_p;
    }

    /**
     * @return the audit
     */
    public Boolean getAudit()
    {
      return _audit;
    }

    /**
     * @return the clientOperateur
     */
    public String getClientOperateur()
    {
      return _clientOperateur;
    }

    /**
     * @return the identifiantFonctionnelPa
     */
    public String getIdentifiantFonctionnelPa()
    {
      return _identifiantFonctionnelPa;
    }

    /**
     * @return the idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the loginmail
     */
    public String getLoginMail()
    {
      return _loginMail;
    }

    /**
     * @return the noCompte
     */
    public String getNoCompte()
    {
      return _noCompte;
    }

    /**
     * @return the sourceDonnee
     */
    public EnumSet<SourceDonne> getSourceDonnee()
    {
      if (_sourceDonnee != null)
      {
        return _sourceDonnee.clone();
      }
      return EnumSet.noneOf(SourceDonne.class);
    }

    /**
     * @param audit_p
     *          the audit to set
     */
    public void setAudit(Boolean audit_p)
    {
      _audit = audit_p;
    }

    /**
     * @param clientOperateur_p
     *          the clientOperateur to set
     */
    public void setClientOperateur(String clientOperateur_p)
    {
      _clientOperateur = clientOperateur_p;
    }

    /**
     * @param identifiantFonctionnelPa_p
     *          the identifiantFonctionnelPa to set
     */
    public void setIdentifiantFonctionnelPa(String identifiantFonctionnelPa_p)
    {
      _identifiantFonctionnelPa = identifiantFonctionnelPa_p;
    }

    /**
     * @param idRequest_p
     *          the idRequest to set
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param loginMail_p
     *          the loginMail to set
     */
    public void setLoginMail(String loginMail_p)
    {
      _loginMail = loginMail_p;
    }

    /**
     * @param noCompte_p
     *          the noCompte to set
     */
    public void setNoCompte(String noCompte_p)
    {
      _noCompte = noCompte_p;
    }

    /**
     * @param sourceDonnee_p
     *          the sourceDonnee to set
     */
    public void setSourceDonnee(EnumSet<SourceDonne> sourceDonnee_p)
    {
      if (sourceDonnee_p != null)
      {
        _sourceDonnee = sourceDonnee_p.clone();
      }
      else
      {
        _sourceDonnee = EnumSet.noneOf(SourceDonne.class);
      }
    }

  }

  /**
   *
   * @author jramos
   * @version ($Revision$ $Date$)
   *
   *          Object de Retour de la BL100
   */
  public static final class PE0215_BL100Return extends AbstractBLReturn
  {

    /**
     *
     */
    private static final long serialVersionUID = 1545315619290030034L;

    /**
     *
     */
    private List<String> _listeLoginMail;

    /**
     *
     */
    private PFI _pfi;

    /**
     * @param retour_p
     *          retour
     */

    public PE0215_BL100Return(Retour retour_p)
    {
      super(retour_p);
    }

    /**
     * @param retour_p
     *          retour
     * @param listeLoginMail_p
     *          list loginmail
     */
    public PE0215_BL100Return(Retour retour_p, List<String> listeLoginMail_p)
    {
      super(retour_p);
      _listeLoginMail = listeLoginMail_p != null ? new ArrayList<>(listeLoginMail_p) : new ArrayList<>();
    }

    /**
     * @return the listeLoginMail
     */
    public List<String> getListeLoginMail()
    {

      return _listeLoginMail != null ? new ArrayList<>(_listeLoginMail) : new ArrayList<>();
    }

    /**
     * @return the pfi
     */
    public PFI getPfi()
    {
      return _pfi;
    }

    /**
     * @param listeLoginMail_p
     *          the listeLoginMail to set
     */
    public void setListeLoginMail(List<String> listeLoginMail_p)
    {
      _listeLoginMail = listeLoginMail_p != null ? new ArrayList<>(listeLoginMail_p) : new ArrayList<>();

    }

    /**
     * @param pfi_p
     *          the pfi to set
     */
    public void setPfi(PFI pfi_p)
    {
      _pfi = pfi_p;
    }

  }

  /**
   *
   * @author jramos
   * @version ($Revision$ $Date$) Object de Retour du BL200
   */
  public static final class PE0215_BL200Return extends AbstractBLReturn

  {

    /**
     *
     */
    private static final long serialVersionUID = 207460858496890197L;

    /**
     * Liste de Referentiels
     */
    private List<Referentiel> _listeReferentiel;

    /**
     * @param retour_p
     *          retour
     */
    public PE0215_BL200Return(Retour retour_p)
    {
      super(retour_p);
    }

    /**
     * @return the listeReferentiel
     */
    public List<Referentiel> getListeReferentiel()
    {
      return _listeReferentiel != null ? new ArrayList<>(_listeReferentiel) : new ArrayList<>();
    }

    /**
     * @param listeReferentiel_p
     *          the listeReferentiel to set
     */
    public void setListeReferentiel(List<Referentiel> listeReferentiel_p)
    {
      _listeReferentiel = listeReferentiel_p != null ? new ArrayList<>(listeReferentiel_p) : new ArrayList<>();
    }

  }

  /**
   *
   * @author jramos
   * @version ($Revision$ $Date$)
   *
   *          Retour de la BL201
   */
  public static final class PE0215_BL201Return extends AbstractBLReturn
  {

    /**
     *
     */
    private static final long serialVersionUID = 2490175220242957843L;
    /**
     * Referentiel
     */
    private Referentiel _referentiel;

    /**
     * @param retour_p
     *          retour
     */
    public PE0215_BL201Return(Retour retour_p)
    {
      super(retour_p);
    }

    /**
     * @return the referentiel
     */
    public Referentiel getReferentiel()
    {
      return _referentiel;
    }

    /**
     * @param referentiel_p
     *          the referentiel to set
     */
    public void setReferentiel(Referentiel referentiel_p)
    {
      _referentiel = referentiel_p;
    }

  }

  /**
   *
   * @author jramos
   * @version ($Revision$ $Date$)
   *
   *          Object de Retour de la BL300
   */
  public static final class PE0215_BL300Return extends AbstractBLReturn
  {

    /**
     *
     */
    private static final long serialVersionUID = 5676330507451022876L;

    /**
     * List de Pfs objects
     */
    private List<PFS> _listePfs;

    /**
     * @param retour_p
     *          retour
     */
    public PE0215_BL300Return(Retour retour_p)
    {
      super(retour_p);
    }

    /**
     * @return the listePfs
     */
    public List<PFS> getListePfs()
    {
      return _listePfs != null ? new ArrayList<>(_listePfs) : new ArrayList<>();
    }

    /**
     * @param listePfs_p
     *          the listePfs to set
     */
    public void setListePfs(List<PFS> listePfs_p)
    {
      _listePfs = listePfs_p != null ? new ArrayList<>(listePfs_p) : new ArrayList<>();
    }

  }

  /**
   *
   * @author jramos
   * @version ($Revision$ $Date$) Object de Retour de la BL301
   */
  public static final class PE0215_BL301Return extends AbstractBLReturn
  {

    /**
     *
     */
    private static final long serialVersionUID = 6637322560477158013L;
    /**
     * Object PFS
     */
    private PFS _pfs;

    /**
     * @param retour_p
     *          retour
     */
    public PE0215_BL301Return(Retour retour_p)
    {
      super(retour_p);
    }

    /**
     * @return the pfs
     */
    public PFS getPfs()
    {
      return _pfs;
    }

    /**
     * @param pfs_p
     *          the pfs to set
     */
    public void setPfs(PFS pfs_p)
    {
      _pfs = pfs_p;
    }

  }

  /**
   *
   *
   * @author jramos
   * @version ($Revision$ $Date$)
   *
   *          Object returned in BL400
   */
  public static final class PE0215_BL400Return extends AbstractBLReturn
  {

    /**
     *
     */
    private static final long serialVersionUID = 4986723198913593660L;
    /**
     * List Referentiels
     */
    private List<Referentiel> _listeReferentiel;

    /**
     * List de PFS
     */
    private List<com.bytel.spirit.fiat.shared.types.json.PFS> _listePFS;

    /**
     * @param retour_p
     *          retour
     */
    public PE0215_BL400Return(Retour retour_p)
    {
      super(retour_p);
    }

    /**
     * @param retour_p
     *          retour
     * @param listeReferentiel_p
     *          liste de Referentiels
     * @param listePFS_p
     *          liste de PFS
     */
    public PE0215_BL400Return(Retour retour_p, List<Referentiel> listeReferentiel_p, List<com.bytel.spirit.fiat.shared.types.json.PFS> listePFS_p)
    {
      super(retour_p);
      if (listeReferentiel_p != null)
      {
        _listeReferentiel = new ArrayList<>(listeReferentiel_p);
      }
      else
      {
        _listeReferentiel = new ArrayList<>();
      }
      if (listePFS_p != null)
      {
        _listePFS = new ArrayList<>(listePFS_p);
      }
      else
      {
        _listePFS = new ArrayList<>();
      }
    }

    /**
     * @return the listePFS
     */
    public List<com.bytel.spirit.fiat.shared.types.json.PFS> getListePFS()
    {
      return (_listePFS != null) && !_listePFS.isEmpty() ? new ArrayList<>(_listePFS) : null;//if list is empty return null, to avoid an empty list in the json
    }

    /**
     * @return the listeReferentiel
     */
    public List<Referentiel> getListeReferentiel()
    {
      return (_listeReferentiel != null) && !_listeReferentiel.isEmpty() ? new ArrayList<>(_listeReferentiel) : null; //if list is empty return null, to avoid an empty list in the json
    }

    /**
     * @param listePFS_p
     *          the listePFS to set
     */
    public void setListePFS(List<com.bytel.spirit.fiat.shared.types.json.PFS> listePFS_p)
    {
      _listePFS = listePFS_p != null ? new ArrayList<>(listePFS_p) : new ArrayList<>();
    }

    /**
     * @param listeReferentiel_p
     *          the listeReferentiel to set
     */
    public void setListeReferentiel(List<Referentiel> listeReferentiel_p)
    {
      _listeReferentiel = listeReferentiel_p != null ? new ArrayList<>(listeReferentiel_p) : new ArrayList<>();
    }

  }

  /**
   *
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  public static final class PE0215_DiagnosticServiceMailContext extends Context
  {
    /**
     * Generate Unique Serial Identifier
     */
    private static final long serialVersionUID = -1471194140122905524L;

    /**
     * The clientOperateur from header
     */
    private String _clientOperateur;

    /**
     * Liste des noms des vues pour lesquels le service est ouvert
     */
    private EnumSet<SourceDonne> _sourceDonnes;

    /**
     * Indique si la comparaison entre les deux vues Référentiel et PFS doit être réalisé si l'appelant ne le précise pas
     * dans la requête émise
     */
    private Boolean _auditViews;

    /**
     * The timeout
     */
    private Duration _timeout;

    /***
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state;

    /**
     * LoginMail
     */

    private String _loginMail;

    /**
     * identifiantFonctionnelPa
     */
    private String _identifiantFonctionnelPa;

    /**
     * noCompte
     */
    private String _noCompte;

    /**
     * noCompte
     */
    private String _idRequest;

    /**
     * URI to use as parameter to BL5100. It defines the uri to th PEI0229
     */
    private String _uriPei0229;

    /**
     *
     */
    public PE0215_DiagnosticServiceMailContext()
    {
      super();

      _timeout = Duration.ofMinutes(0L);
      _state = State.PE0215_BL001;
      _auditViews = false;
      _sourceDonnes = EnumSet.noneOf(SourceDonne.class);
    }

    /**
     * @param sourceDonne_p
     *          the autorisedDataSource to set
     */
    public final void addSourceDonne(final SourceDonne sourceDonne_p)
    {
      _sourceDonnes.add(sourceDonne_p);
    }

    /**
     * @return the auditViews
     */
    public final Boolean getAuditViews()
    {
      return _auditViews;
    }

    /**
     * @return the clientOperateur
     */
    public final String getClientOperateur()
    {
      return _clientOperateur;
    }

    /**
     * @return the identifiantFonctionnelPa
     */
    public String getIdentifiantFonctionnelPa()
    {
      return _identifiantFonctionnelPa;
    }

    /**
     * @return the idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the loginMail
     */
    public String getLoginMail()
    {
      return _loginMail;
    }

    /**
     * @return the noCompte
     */
    public String getNoCompte()
    {
      return _noCompte;
    }

    /**
     * @return the autorisedDataSource
     */
    public final EnumSet<SourceDonne> getSourceDonnes()
    {
      if (_sourceDonnes != null)
      {
        return _sourceDonnes.clone();
      }
      return EnumSet.noneOf(SourceDonne.class);
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the timeout
     */
    public final Duration getTimeout()
    {
      return _timeout;
    }

    /**
     * @return the uri
     */
    public String getUriPei229()
    {
      return _uriPei0229;
    }

    @Override
    public int hashCode() //NOSONAR
    {
      final int prime = 31;
      int result = 1;
      result = (prime * result) + ((_state == null) ? 0 : _state.hashCode());
      return result;
    }

    /**
     * @param auditViews_p
     *          the auditViews to set
     */
    public final void setAuditViews(final Boolean auditViews_p)
    {
      _auditViews = auditViews_p;
    }

    /**
     * @param sourceDonne_p
     *          SourceDonne
     */
    public final void setAutorisedDataSource(final EnumSet<SourceDonne> sourceDonne_p)
    {
      if (sourceDonne_p != null)
      {
        _sourceDonnes = sourceDonne_p.clone();
      }
      else
      {
        _sourceDonnes = EnumSet.noneOf(SourceDonne.class);
      }
    }

    /**
     * @param clientOperateur_p
     *          the clientOperateur to set
     */
    public final void setClientOperateur(final String clientOperateur_p)
    {
      _clientOperateur = clientOperateur_p;
    }

    /**
     * @param identifiantFonctionnelPa_p
     *          the identifiantFonctionnelPa to set
     */
    public void setIdentifiantFonctionnelPa(String identifiantFonctionnelPa_p)
    {
      _identifiantFonctionnelPa = identifiantFonctionnelPa_p;
    }

    /**
     * @param idRequest_p
     *          the idRequest to set
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param loginMail_p
     *          the loginMail to set
     */
    public void setLoginMail(String loginMail_p)
    {
      _loginMail = loginMail_p;
    }

    /**
     * @param noCompte_p
     *          the noCompte to set
     */
    public void setNoCompte(String noCompte_p)
    {
      _noCompte = noCompte_p;
    }

    /**
     * @param sourceDonnes_p
     *          the sourceDonnes to set
     */
    public void setSourceDonnes(EnumSet<SourceDonne> sourceDonnes_p)
    {
      if (sourceDonnes_p != null)
      {
        _sourceDonnes = sourceDonnes_p.clone();
      }
      else
      {
        _sourceDonnes = EnumSet.noneOf(SourceDonne.class);
      }
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param timeout_p
     *          the timeout to set
     */
    public final void setTimeout(final Duration timeout_p)
    {
      _timeout = timeout_p;
    }

    /**
     * @param uri_p
     *          the uri to set
     */
    public void setUriPei229(String uri_p)
    {
      _uriPei0229 = uri_p;
    }

    @Override
    public String toString() //NOSONAR
    {
      StringBuilder builder = new StringBuilder();
      builder.append("PE0215_DiagnosticServiceMailContext [_state="); //$NON-NLS-1$
      builder.append(_state);
      builder.append("]"); //$NON-NLS-1$
      return builder.toString();
    }
  }

  /**
   * The Enum containing all process states
   *
   * @author jjoly
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * PE0215_BL001_VerifierDonnes
     */
    PE0215_BL001(MandatoryProcessState.PRC_START, false, false),

    /**
     * PE0215_BL100_RechercheListeLoginMail
     */
    PE0215_BL100(MandatoryProcessState.PRC_START, false, false),

    /**
     * PE0215_BL200_ConstruireVueReferentiel
     */
    PE0215_BL200(MandatoryProcessState.PRC_START, false, false),

    /**
     * PE0215_BL201_CreerObjetReferentiel
     */
    PE0215_BL201(MandatoryProcessState.PRC_START, false, false),

    /**
     * PE0215_BL300_ConstruireVuePfs
     */
    PE0215_BL300(MandatoryProcessState.PRC_START, false, false),

    /**
     * PE0215_BL301_CreerObjetPfs
     */
    PE0215_BL301(MandatoryProcessState.PRC_START, false, false),

    /**
     * PE0215_BL400_ComparerVues
     */
    PE0215_BL400(MandatoryProcessState.PRC_START, false, false),

    /**
     * PE0215_BL002_FormaterReponse
     */
    PE0215_BL002(MandatoryProcessState.PRC_START, false, false),

    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    private MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    private Boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    private Boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }

    /**
     * @return the asynchronousState
     */
    public Boolean getAsynchronousState()
    {
      return _asynchronousState;
    }

    /**
     * @return the replayableState
     */
    public final Boolean getReplayableState()
    {
      return _replayableState;
    }

    /**
     * @return the technicalState
     */
    public final MandatoryProcessState getTechnicalState()
    {
      return _technicalState;
    }

    /**
     * @param asynchronousState_p
     *          the asynchronousState to set
     */
    public void setAsynchronousState(final Boolean asynchronousState_p)
    {
      _asynchronousState = asynchronousState_p;
    }

    /**
     * @param replayableState_p
     *          the replayableState to set
     */
    public void setReplayableState(final Boolean replayableState_p)
    {
      _replayableState = replayableState_p;
    }

    /**
     * @param technicalState_p
     *          the technicalState to set
     */
    public void setTechnicalState(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
    }
  }

  /**
   * Possibles source donne (Data sources)
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  protected enum SourceDonne
  {
    /**
     *
     */
    REFERENTIEL,
    /**
     *
     */
    PFS
  }

  /**
   * Possible Url paramters this process can handle
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  protected enum UrlParameters
  {
    /**
     * loginMail
     */
    LOGIN_MAIL("loginMail"), //$NON-NLS-1$
    /**
     * noCompte
     */
    NO_COMPTE("noCompte"), //$NON-NLS-1$
    /**
     * idFonctionnelPa
     */
    ID_FONCTIONNEL_PA("idFonctionnelPa"), //$NON-NLS-1$
    /**
     * sourceDonnee
     */
    SOURCE_DONNE("sourceDonnee"), //$NON-NLS-1$
    /**
     * audit
     */
    AUDIT("audit"); //$NON-NLS-1$

    /**
     *
     */
    private String _paramName;

    /**
     * @param name_p
     *          name
     */
    private UrlParameters(String name_p)
    {
      setParamName(name_p);
    }

    /**
     * @return the paramName
     */
    public String getParamName()
    {
      return _paramName;
    }

    /**
     * @param paramName_p
     *          the paramName to set
     */
    public void setParamName(String paramName_p)
    {
      _paramName = paramName_p;
    }

  }

  /**
   * Possible values for Inchoerence
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  private enum Incoherences
  {
    /**
     * taillePieceJointe
     */
    taillePieceJointe,
    /**
     * volumeBoite
     */
    volumeBoite,
    /**
     * niveauRestriction
     */
    niveauRestriction,
    /**
     * idCompteMailPrincipal
     */
    idCompteMailPrincipal
  }

  /**
   *
   */
  private static final String ID_ACTION_CORRECTIVE_NULL_MSG = "idActionCorrective is null"; //$NON-NLS-1$

  /**
   * Process name constant PI0150B_TransfererCopierROMA
   */
  private static final String PI0150C_ConsulterROMA_PROCESS_NAME = "PI0150C_ConsulterROMA"; //$NON-NLS-1$

  /**
   * Priority to set in the call to KPSA DIAG in BL300
   */
  private static final int KPSA_DIAG_PRIORITE = 10;

  /**
   * Constant for action corrective creation error
   */
  private static final String ERROR_CREATION_ACTION_CORRECTIVE = Messages.getString("PE0215.BL400.ErrorDescrition"); //$NON-NLS-1$

  /**
   * Message for Service no Provisione
   */
  private static final String SERVICE_NON_PREVISIONE_MSG = Messages.getString("PE0215.BL301.ServiceNonPrevisione"); //$NON-NLS-1$
  /**
   * Message for PFS indisponible
   */
  private static final String PFS_INDISPONIBLE_MSG = Messages.getString("PE0215.BL301.PFSNonDisponible"); //$NON-NLS-1$
  /**
   * ERREUR_APPEL_INTERNE
   */
  private static final String ERREUR_APPEL_INTERNE = Messages.getString("PE0215.BL301.ErreurAppelInterne"); //$NON-NLS-1$

  /**
   * constant for parameter name URI_PEI0229
   */
  private static final String URI_PEI0229_PARAM = "URI_PEI0229"; //$NON-NLS-1$

  /**
   * Error Message if PEI0229 uri is not present in process configurtion
   */
  private static final String URI_PEI229_REQUIRED_MSG = MessageFormat.format(Messages.getString("PE0215.ConfigurationError"), URI_PEI0229_PARAM); //$NON-NLS-1$

  /**
   * separator of sourceDonne url parameter
   */
  private static final String SOURCE_DONNES_SEPARATOR = ","; //$NON-NLS-1$

  /**
   * Generate Unique Serial Identifier
   */
  private static final long serialVersionUID = -207678455363376515L;

  /**
   * Constant
   */
  private static final String SOURCE_DONNEE_DEFAULT_PARAM_NAME = "sourceDonneeParDefaut"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String AUDIT_VUES = "auditVues"; //$NON-NLS-1$

  /**
   * Constant for Audit libelle
   */
  private static final String BL400_AUDIT_LIBELLE = Messages.getString("PE0215.BL400.auditLibelle"); //$NON-NLS-1$

  /**
   * The process context.
   */
  private PE0215_DiagnosticServiceMailContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(final Retour retour_p) throws RavelException //NOSONAR
  {
    return ""; //$NON-NLS-1$
  }

  @Override
  public String getInternalState() //NOSONAR
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime() //NOSONAR
  {
    return _processContext.getTimeout();
  }

  @Override
  public MandatoryProcessState getTechnicalState() //NOSONAR
  {
    return _processContext.getState().getTechnicalState();
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0215_DiagnosticServiceMailContext();
  }

  @Override
  public boolean isAsynchronous() //NOSONAR
  {
    return _processContext.getState().getAsynchronousState();

  }

  @Override
  public boolean isReplayable() //NOSONAR
  {
    return _processContext.getState().getReplayableState();
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request arg0, Tracabilite arg1) throws RavelException
  {
    //do nothing
  }

  @Override
  protected void exitKOMetroLog(String arg0) //NOSONAR
  {
    // Not required for now in Ravel
  }

  @Override
  protected void startMetroLog() //NOSONAR
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    PE0215_BL001Return pe0215_BL001Return = new PE0215_BL001Return(RetourFactory.createOkRetour());
    PE0215_BL100Return pe0215_BL100Return = new PE0215_BL100Return(RetourFactory.createOkRetour());
    PE0215_BL200Return pe0215_BL200Return = new PE0215_BL200Return(RetourFactory.createOkRetour());
    PE0215_BL300Return pe0215_BL300Return = new PE0215_BL300Return(RetourFactory.createOkRetour());
    PE0215_BL400Return pe0215_BL400Return = new PE0215_BL400Return(RetourFactory.createOkRetour());

    List<Referentiel> listReferentielSortie = new ArrayList<>();
    List<PFS> listPFSSortie = new ArrayList<>();

    try
    {
      getProcessConfigParameters(tracabilite_p);
      if (StringTools.isNullOrEmpty(_processContext.getUriPei229()))
      {
        throw new RavelException(ExceptionType.INVALID_CONFIGURATION, ErrorCode.PRCESS_00002, URI_PEI229_REQUIRED_MSG);
      }

      pe0215_BL001Return = PE0215_BL001_VerifierDonnees(tracabilite_p, request_p);
      retour = pe0215_BL001Return.getRetour();

      if (isRetourOK(retour))
      {
        _processContext.setLoginMail(pe0215_BL001Return.getLoginMail());
        //CALL BL100
        pe0215_BL100Return = PE0215_BL100_RechercheListLoginMail(tracabilite_p, pe0215_BL001Return.getClientOperateur(), pe0215_BL001Return.getNoCompte(), pe0215_BL001Return.getIdentifiantFonctionnelPa(), pe0215_BL001Return.getLoginMail(), pe0215_BL001Return.getSourceDonnee());
        retour = pe0215_BL100Return.getRetour();
        if (isRetourOK(retour))
        {
          //CALL BL200
          pe0215_BL200Return = PE0215_BL200_ConstruireVueReferentiel(tracabilite_p, pe0215_BL001Return.getNoCompte(), pe0215_BL001Return.getClientOperateur(), pe0215_BL100Return.getListeLoginMail(), pe0215_BL001Return.getSourceDonnee());
          retour = pe0215_BL200Return.getRetour();
          listReferentielSortie = pe0215_BL200Return.getListeReferentiel();

          if (isRetourOK(retour))
          {
            //CALL BL300
            pe0215_BL300Return = PE0215_BL300_ConstruireVuePfs(tracabilite_p, pe0215_BL100Return.getListeLoginMail(), pe0215_BL001Return.getSourceDonnee());
            retour = pe0215_BL300Return.getRetour();
            listPFSSortie = pe0215_BL300Return.getListePfs();

            //Call BL400
            pe0215_BL400Return = PE0215_BL400_ComparerVues(tracabilite_p, pe0215_BL200Return.getListeReferentiel(), listPFSSortie, _processContext.getSourceDonnes(), _processContext.getAuditViews(), pe0215_BL100Return.getPfi());
            retour = pe0215_BL400Return.getRetour();
            listReferentielSortie = pe0215_BL400Return.getListeReferentiel();
            listPFSSortie = pe0215_BL400Return.getListePFS();
          }
        }
      }

    }
    catch (final Exception e)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
    }
    finally
    {
      PE0215_Retour processRetour = PE0215_BL002_FormaterReponse(tracabilite_p, retour, listReferentielSortie, listPFSSortie);
      setRetour(retour);
      syncResponse(tracabilite_p, request_p, processRetour);
    }
  }

  /**
   * Do the comparaison betwen the PFS and the ServiceTechnique. If differences are found, add a new string representing
   * the difference to the incoherences_p list.
   *
   * @param pfs_p
   *          The PFS
   * @param stPfsMail_p
   *          The ServiceTechnique of type PFS Mail
   * @return List of incoherences
   */
  private Pair<List<String>, StPfsMail> analyseIncoherencesSTMailPFS(com.bytel.spirit.fiat.shared.types.json.PFS pfs_p, StPfsMail stPfsMail_p)
  {
    List<String> incoherences = new ArrayList<>();

    if (isValidStPfsMail(stPfsMail_p))
    {
      DonneesProvisionneesSTPfsMail donnesProvisionneesSTPfsMail = stPfsMail_p.getDonneesProvisionneesStPfsMail();

      if (donnesProvisionneesSTPfsMail == null)
      {
        donnesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail(null, 0, 0, null);
      }

      Long pfs_pTaillePieceJointe = 0L;
      if (!isNull(pfs_p.getTaillePieceJointe()))
      {
        pfs_pTaillePieceJointe = pfs_p.getTaillePieceJointe();
      }

      if ((pfs_pTaillePieceJointe.intValue() != donnesProvisionneesSTPfsMail.getTaillePieceJointe()))
      {
        incoherences.add(Incoherences.taillePieceJointe.name());
      }
      Long pfs_pVolumeBoite = 0L;
      if (!isNull(pfs_p.getVolumeBoite()))
      {
        pfs_pVolumeBoite = pfs_p.getVolumeBoite();
      }
      if ((pfs_pVolumeBoite.intValue() != donnesProvisionneesSTPfsMail.getVolumeBoite()))
      {
        incoherences.add(Incoherences.volumeBoite.name());
      }

      if (!safeStringEquals(pfs_p.getNiveauRestriction(), donnesProvisionneesSTPfsMail.getNiveauRestriction()))
      {
        incoherences.add(Incoherences.niveauRestriction.name());
      }

      if (!safeStringEquals(pfs_p.getIdCompteMailPrincipal(), donnesProvisionneesSTPfsMail.getIdCompteMailPrincipal()))
      {
        incoherences.add(Incoherences.idCompteMailPrincipal.name());
      }
      if (!incoherences.isEmpty())
      {
        donnesProvisionneesSTPfsMail.setTaillePieceJointe(pfs_p.getTaillePieceJointe().intValue());
        donnesProvisionneesSTPfsMail.setVolumeBoite(pfs_p.getVolumeBoite().intValue());
        donnesProvisionneesSTPfsMail.setNiveauRestriction(pfs_p.getNiveauRestriction());
        donnesProvisionneesSTPfsMail.setIdCompteMailPrincipal(pfs_p.getIdCompteMailPrincipal());
        StPfsMail.class.cast(stPfsMail_p).setDonneesProvisionneesStPfsMail(donnesProvisionneesSTPfsMail);
      }
    }
    return new Pair<>(incoherences, stPfsMail_p);
  }

  /**
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @return Retour
   */
  private Retour checkAndExtractHeaders(final Request request_p, Tracabilite tracabilite_p)
  {

    Retour retour = RetourFactory.createOkRetour();

    // Verifying if Headers exists

    String clientOperateur = null;
    String process = null;
    String source = null;
    String requestId = null;

    // Verifying if Headers exists

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_CLIENT_OPERATEUR.equalsIgnoreCase(header.getName()))
      {
        clientOperateur = header.getValue();
      }
      else if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        process = header.getValue();
      }
      else if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        source = header.getValue();
      }
      else if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()))
      {
        requestId = header.getValue();
      }

    }

    // check if  one or more of headers are missing
    if (StringTools.containsOneNullOrEmpty(clientOperateur, source, process, requestId))
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$
      if (StringTools.isNullOrEmpty(clientOperateur))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), "X-Client-Operateur")); //$NON-NLS-1$ //$NON-NLS-2$
      }
      if (StringTools.isNullOrEmpty(source))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), "X-Source")); //$NON-NLS-1$//$NON-NLS-2$
      }
      if (StringTools.isNullOrEmpty(process))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), "X-Process")); //$NON-NLS-1$ //$NON-NLS-2$
      }
      if (StringTools.isNullOrEmpty(requestId))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), "X-Request-Id")); //$NON-NLS-1$ //$NON-NLS-2$
      }

      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, joiner.toString());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, joiner.toString()));

    }
    else
    {
      _processContext.setClientOperateur(clientOperateur);
      _processContext.setIdRequest(requestId);
    }

    return retour;

  }

  /**
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @return Retour Check if Url Parameters are Ok
   */
  private Retour checkAndExtractUrlParameters(final Request request_p, final Tracabilite tracabilite_p)
  {
    Retour retour = RetourFactory.createOkRetour();

    String loginMail = null;
    String sourceDonnee = null;
    String audit = null;
    String idFonctionnelPa = null;
    String noCompte = null;

    // Checks if Parameters exists
    for (Parameter parameter : request_p.getUrlParameters().getUrlParameters())
    {
      if (UrlParameters.LOGIN_MAIL.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        loginMail = parameter.getValue();
      }
      else if (UrlParameters.SOURCE_DONNE.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        sourceDonnee = parameter.getValue();
      }
      else if (UrlParameters.AUDIT.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        audit = parameter.getValue();
      }
      else if (UrlParameters.ID_FONCTIONNEL_PA.getParamName().equalsIgnoreCase(parameter.getName()))
      {

        idFonctionnelPa = parameter.getValue();
      }
      else if (UrlParameters.NO_COMPTE.getParamName().equalsIgnoreCase(parameter.getName()))
      {

        noCompte = parameter.getValue();
      }
    }

    // Check combinations of parameters required

    short group = -1;
    if (StringTools.isNotNullOrEmpty(loginMail))
    {
      group = 1;
    }
    else if (!StringTools.containsOneNullOrEmpty(idFonctionnelPa, noCompte))
    {
      group = 2;
      _processContext.setIdentifiantFonctionnelPa(idFonctionnelPa);
      _processContext.setNoCompte(noCompte);

    }
    else if (StringTools.isNotNullOrEmpty(noCompte))
    {
      group = 3;
      _processContext.setNoCompte(noCompte);
    }

    if (group == 1)
    {
      if (!isValidEmailLocalPart(loginMail))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0215.BL001.MailInvalide"), loginMail)); //$NON-NLS-1$
        return retour;
      }
      _processContext.setLoginMail(loginMail);
    }
    else if (group == -1)

    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0215.BL001.MandatoryError")); //$NON-NLS-1$
      return retour;
    }

    EnumSet<SourceDonne> sourceDonnesSet = EnumSet.noneOf(SourceDonne.class);
    try
    {
      //validate parameter sourceDonne if present
      sourceDonnesSet = extractSourceDonneFromStringParam(sourceDonnee);
    }
    finally
    {
      if ((sourceDonnesSet.isEmpty() && StringTools.isNotNullOrEmpty(sourceDonnee))) //param sourceDonne contains invalid values
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0215.BL001.SourceDonneeInvalide")); //$NON-NLS-1$
        return retour;
      }
      if (!sourceDonnesSet.isEmpty())
      {
        _processContext.setAutorisedDataSource(sourceDonnesSet);
      } //if sourceDonne not present in URL parameters the value will be the specified in the process configuration, REFERENTIEL by default
    }

    if (sourceDonnesSet.contains(SourceDonne.REFERENTIEL) && sourceDonnesSet.contains(SourceDonne.PFS))
    {
      if (StringTools.isNotNullOrEmpty(audit))
      {
        Boolean auditBool = getAuditValue(audit);
        if (auditBool != null)
        {
          _processContext.setAuditViews(Boolean.valueOf(audit));
        }
      }
    }

    return retour;

  }

  /**
   * Add the possible values of parameter sourceDonne to a Set of type SourceDonne
   *
   * @param sourceDonne_p
   *          The sourceDonne parameter
   * @return The Set containing the sourceDonne values, null if the sourceDonne_p contains invalid values or empty set if
   *         sourceDonne_p is empty
   */
  private EnumSet<SourceDonne> extractSourceDonneFromStringParam(String sourceDonne_p)
  {
    EnumSet<SourceDonne> sourceDonnes = EnumSet.noneOf(SourceDonne.class);

    if (StringTools.isNotNullOrEmpty(sourceDonne_p))
    {
      String[] sourceDonneStr = sourceDonne_p.trim().split(SOURCE_DONNES_SEPARATOR);
      for (String sd : sourceDonneStr)
      {
        if (StringTools.isNotNullOrEmpty(sd))
        {
          SourceDonne sourceDonne;
          try
          {
            sourceDonne = SourceDonne.valueOf(sd.trim());
            sourceDonnes.add(sourceDonne);
          }
          catch (Exception ex)
          {
            throw new IllegalArgumentException(Messages.getString("PE0215.BL001.SourceDonneeInvalide")); //$NON-NLS-1$
          }
        }

      }
    }
    return sourceDonnes;
  }

  /**
   * Find the diagnostic_p parameter in the list of Audits audits_p.
   *
   * @param audits_p
   *          The Audit list to find the diagnostic
   * @param diagnostic_p
   *          The diagnostic to find for
   * @return The Audit object if found, null otherwise
   */
  private Audit findAuditByDiagnostique(List<Audit> audits_p, Diagnostic diagnostic_p)
  {
    if ((diagnostic_p != null) && (audits_p != null) && !audits_p.isEmpty())
    {
      for (Audit audit : audits_p)
      {
        if (diagnostic_p.name().equals(audit.getDiagnostic()))
        {
          return audit;
        }
      }
    }
    return null;
  }

  /**
   * Get boolean value of audit parameter.
   *
   * @param audit_p
   *          The String audit parameter
   * @return The boolean value of audit
   */
  private Boolean getAuditValue(String audit_p)
  {
    Boolean audit = null;
    if (StringTools.isNotNullOrEmpty(audit_p))
    {
      try
      {
        audit = BooleanTools.toBooleanIgnoreCase(audit_p);
      }
      catch (Exception ex)
      {
        //ignore
      }
    }
    return audit;
  }

  /**
   * Converts the statut of the ServiceTechnique of type LAC or PFS to the statut of the Resource or Referentiel.
   *
   * @param st_p
   *          The ServiceTechnique (LAC or PFS)
   * @return A string representing the statut of the Ressource
   */
  private String getEtatFromServiceTechnique(ServiceTechnique st_p)
  {
    if (st_p == null)
    {
      return EtatAllocation.EN_COURS.name();
    }

    if (Statut.ACTIF.toString().equals(st_p.getStatut()))
    {

      return EtatAllocation.REALISE.toString();
    }
    else if (Statut.ECHEC.toString().equals(st_p.getStatut()))
    {
      return EtatAllocation.ECHEC.toString();

    }

    return EtatAllocation.EN_COURS.name();

  }

  /**
   * Load process parameters into the process context
   *
   * @param tracabilite_p
   *          Tracabilite
   */
  private void getProcessConfigParameters(Tracabilite tracabilite_p)
  {
    final String sourceDonneeConfig = getConfigParameter(SOURCE_DONNEE_DEFAULT_PARAM_NAME);
    final String uriPei229 = getConfigParameter(URI_PEI0229_PARAM);

    _processContext.setUriPei229(uriPei229);

    EnumSet<SourceDonne> sourceDonne = EnumSet.noneOf(SourceDonne.class);
    try
    {
      sourceDonne = extractSourceDonneFromStringParam(sourceDonneeConfig);
    }
    catch (IllegalArgumentException e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, MessageFormat.format(Messages.getString("PE0215.InvalidParameterValue"), "sourceDonneeAutorise", "[REFRENTIEL, PFS]"))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
    finally
    {
      if (sourceDonne.isEmpty())
      {//Set sourceDonne by default ( [REFRENTIEL, PFS])

        sourceDonne = EnumSet.allOf(SourceDonne.class);
      }
      _processContext.setSourceDonnes(sourceDonne);
    }

    final String auditConfig = getConfigParameter(AUDIT_VUES);

    if (StringTools.isNotNullOrEmpty(auditConfig))
    {
      Boolean auditBool = getAuditValue(auditConfig);
      _processContext.setAuditViews(auditBool);
    }
    else
    {//set audit by default
      RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, MessageFormat.format(Messages.getString("PE0215.InvalidParameterValue"), "auditVues", "false"))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      _processContext.setAuditViews(false);
    }

  }

  /**
   * @param email_p
   *          email
   * @return Boolean
   *
   *         Verifies is a email valid
   */
  private boolean isValidEmailLocalPart(final String email_p)
  {
    Pattern regex = Pattern.compile("^[A-Za-z0-9\\.!#$%&'*+/=?^_`{|}~-]+$"); //$NON-NLS-1$

    if (StringTools.isNullOrEmpty(email_p) || (email_p.length() < 1) || (email_p.length() > 64))
    {
      return false;
    }

    return regex.matcher(email_p).matches();
  }

  /**
   * Validates if ServiceTechnique is a ST PFS MAIL
   *
   * @param stMail_p
   *          ServiceTechnique to validate
   * @return true if valid, false otherwise
   */
  private boolean isValidStPfsMail(ServiceTechnique stMail_p)
  {
    return (stMail_p != null) && (TypeST.PFS.name().equals(stMail_p.getTypeServiceTechnique())) && (TypePFS.MAIL.name().equals(StPfsMail.class.cast(stMail_p).getTypePfs()));
  }

  /**
   *
   * @param tracabilite_p
   *          tracibilite
   * @param request_p
   *          The request
   * @return Object {@Code PE0215_BL001_VerifierDonneesReturn}
   *
   * @throws RavelException
   *           on errors
   */
  @LogProcessBL
  private PE0215_BL001Return PE0215_BL001_VerifierDonnees(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    final PE0215_BL001Return bl001return = new PE0215_BL001Return(RetourFactory.createOkRetour());

    Retour urlHeadersRetour = checkAndExtractHeaders(request_p, tracabilite_p);

    //return if headears are not conform as on STI
    if (!RetourFactory.isRetourOK(urlHeadersRetour))
    {
      bl001return.setRetour(urlHeadersRetour);
      return bl001return;
    }

    Retour urlParametersRetour = checkAndExtractUrlParameters(request_p, tracabilite_p);

    //return if paramters are not conform as on STI
    if (!RetourFactory.isRetourOK(urlParametersRetour))
    {
      bl001return.setRetour(urlParametersRetour);
      return bl001return;
    }

    bl001return.setLoginMail(_processContext.getLoginMail());
    bl001return.setIdentifiantFonctionnelPa(_processContext.getIdentifiantFonctionnelPa());

    bl001return.setSourceDonnee(_processContext.getSourceDonnes());
    bl001return.setAudit(_processContext.getAuditViews());

    if (StringTools.isNotNullOrEmpty(bl001return.getLoginMail()) && bl001return.getSourceDonnee().contains(SourceDonne.REFERENTIEL))
    {
      final BL3700_RecupererPfiParMail bl3700 = new BL3700_RecupererPfiParMailBuilder().tracabilite(tracabilite_p).mail(bl001return.getLoginMail()).build();
      BL3700_Return bl3700Reponse = bl3700.execute(this);

      if (!isRetourOK(bl3700.getRetour()))
      {
        if (IMegConsts.CAT4.equals(bl3700.getRetour().getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(bl3700.getRetour().getDiagnostic()))
        {
          bl001return.setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.LOGIN_MAIL_INCONNU, MessageFormat.format(Messages.getString("PE0215.BL100.MailIconnu"), bl001return.getLoginMail()))); //$NON-NLS-1$
        }
        else
        {
          bl001return.setRetour(bl3700.getRetour());
        }
      }
      else
      {
        _processContext.setClientOperateur(bl3700Reponse.getClientOperateur());
        _processContext.setNoCompte(bl3700Reponse.getNoCompte());
      }
    }
    bl001return.setIdRequest(_processContext.getIdRequest());
    bl001return.setClientOperateur(_processContext.getClientOperateur());
    bl001return.setNoCompte(_processContext.getNoCompte());

    return bl001return;

  }

  /**
   * Format response to the client
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param retourIn_p
   *          Retour to format
   * @param listRef_p
   *          list de Referentiels
   * @param listPFS_p
   *          list de PFS
   * @return {@link PE0215_Retour}
   */
  @LogProcessBL
  private PE0215_Retour PE0215_BL002_FormaterReponse(@SuppressWarnings("unused") final Tracabilite tracabilite_p, Retour retourIn_p, List<Referentiel> listRef_p, List<com.bytel.spirit.fiat.shared.types.json.PFS> listPFS_p)
  {
    PE0215_Retour processRetour = new PE0215_Retour();

    if (RetourFactory.isRetourKO(retourIn_p))
    {
      ReponseErreur reponseErreur = new ReponseErreur();
      reponseErreur.setError(retourIn_p.getDiagnostic());
      reponseErreur.setErrorDescription(retourIn_p.getLibelle());
      processRetour.setReponseErreur(reponseErreur);
    }
    processRetour.setReferentiels(listRef_p);
    processRetour.setPfs(listPFS_p);
    processRetour.setRetour(retourIn_p);
    return processRetour;
  }

  /**
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param clientOperateur_p
   *          the X-Client-Operateur set in the request
   * @param noCompte_p
   *          Identifiant utilisé par le client opérateur pour désigner le portefeuille commercial
   * @param identifiantFonctionnelPa_p
   *          Identifiant fonctionnel PA de type compte accès ou compte accès secondaire
   * @param loginMail_p
   *          Préfixe de l'adresse mail de la ressource de type email du portefeuille source
   * @param sourceDonnee_p
   *          Source de donnée
   * @return Object {@Code PE0215_BL100_RechercheListLoginMailReturn}
   *
   * @throws RavelException
   *           on errors
   */
  @LogProcessBL
  private PE0215_BL100Return PE0215_BL100_RechercheListLoginMail(final Tracabilite tracabilite_p, final String clientOperateur_p, final String noCompte_p, final String identifiantFonctionnelPa_p, final String loginMail_p, final EnumSet<SourceDonne> sourceDonnee_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    List<String> listeLoginMail = new ArrayList<>();
    final PE0215_BL100Return bl100Return = new PE0215_BL100Return(RetourFactory.createOkRetour());

    if (!sourceDonnee_p.contains(SourceDonne.REFERENTIEL) && StringTools.isNotNullOrEmpty(loginMail_p))
    {
      listeLoginMail.add(loginMail_p);
    }
    else
    {
      //Load PFI using clientOperateur and noCompte
      final Pair<Retour, PFI> rpg = RPGProxy.getInstance().pfiLireUn(tracabilite_p, clientOperateur_p, noCompte_p);
      if (!isRetourOK(rpg._first))
      {
        if (IMegConsts.CAT4.equals(rpg._first.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(rpg._first.getDiagnostic()))
        {
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_COMPTE_INCONNU, MessageFormat.format(Messages.getString("PE0215.BL100.noCompteIconnu"), noCompte_p)); //$NON-NLS-1$
        }
        else
        {
          RetourFactory.recopyRetour(retour, rpg._first);
        }

        bl100Return.setRetour(retour);
        return bl100Return;
      }
      bl100Return.setPfi(rpg._second);
      //Filter the PA list to find the PA of type COMPTE_ACCES and COMPTE_ACCES_SECONDAIRE in the state ACTIF. (The resultant list will have both types)
      final List<PA> paCompteAccesList = PFIUtils.filterPA(rpg._second, new PFIFilter(PFIFilterOption.TYPE_PA, TypePA.COMPTE_ACCES.name(), TypePA.COMPTE_ACCES_SECONDAIRE.name()), new PFIFilter(PFIFilterOption.STATUT, Statut.ACTIF.name()));
      if (paCompteAccesList.isEmpty())
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ID_PA_INCONNU, Messages.getString("PE0215.BL100.noPAactif")); //$NON-NLS-1$

        bl100Return.setRetour(retour);
        return bl100Return;
      }

      if (StringTools.isNotNullOrEmpty(identifiantFonctionnelPa_p))
      {
        final List<PA> listPA = PFIUtils.filterPA(paCompteAccesList, new PFIFilter(PFIFilterOption.IDENTIFIANT_FONCTIONNEL_PA, identifiantFonctionnelPa_p));
        if (listPA.isEmpty())
        {
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ID_PA_INCONNU, Messages.getString("PE0215.BL100.idPAIconnu")); //$NON-NLS-1$
        }
        else
        {
          PA paca = listPA.get(0);
          if (TypePA.COMPTE_ACCES.name().equals(paca.getTypePA()))
          {
            listeLoginMail.add(paca.getPaTypeCompteAcces().getEmailLogin());
          }
          else if (TypePA.COMPTE_ACCES_SECONDAIRE.name().equals(paca.getTypePA()))
          {
            listeLoginMail.add(paca.getPaTypeCompteAccesSecondaire().getLoginEmail());
          }
        }
      }
      else if (StringTools.isNotNullOrEmpty(loginMail_p))
      {
        final List<PA> listPA = new ArrayList<>();
        for (PA o : paCompteAccesList)
        {
          if (TypePA.COMPTE_ACCES.name().equals(o.getTypePA()))
          {
            if (loginMail_p.equals(o.getPaTypeCompteAcces().getEmailLogin()))
            {
              listPA.add(o);
            }
          }
          else if (TypePA.COMPTE_ACCES_SECONDAIRE.name().equals(o.getTypePA()))
          {
            if (loginMail_p.equals(o.getPaTypeCompteAccesSecondaire().getLoginEmail()))
            {
              listPA.add(o);
            }
          }
        }

        if (listPA.isEmpty())
        {
          retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.LOGIN_MAIL_INCONNU, MessageFormat.format(Messages.getString("PE0215.BL100.loginMailIconnu"), loginMail_p)); //$NON-NLS-1$
        }
        else
        {
          for (PA o : listPA)
          {
            if (TypePA.COMPTE_ACCES.name().equals(o.getTypePA()))
            {
              listeLoginMail.add(o.getPaTypeCompteAcces().getEmailLogin());
            }
            else if (TypePA.COMPTE_ACCES_SECONDAIRE.name().equals(o.getTypePA()))
            {
              listeLoginMail.add(o.getPaTypeCompteAccesSecondaire().getLoginEmail());
            }
          }
        }
      }
      else
      {
        for (PA o : paCompteAccesList)
        {
          if (TypePA.COMPTE_ACCES.name().equals(o.getTypePA()))
          {
            listeLoginMail.add(o.getPaTypeCompteAcces().getEmailLogin());
          }
          else if (TypePA.COMPTE_ACCES_SECONDAIRE.name().equals(o.getTypePA()))
          {
            listeLoginMail.add(o.getPaTypeCompteAccesSecondaire().getLoginEmail());
          }
        }
      }
    }

    bl100Return.setRetour(retour);
    bl100Return.setListeLoginMail(listeLoginMail);
    return bl100Return;
  }

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @param noCompte_p
   *          numero de compte
   * @param clientOperateur_p
   *          client Operateur
   * @param listeLoginMail_p
   *          list de LoginMaiL
   * @param sourceDonnee_p
   *          sourceDonnee
   * @return Pair avec Retour , Liste de Referentiels
   * @throws RavelException
   *           Exception
   */
  @LogProcessBL
  private PE0215_BL200Return PE0215_BL200_ConstruireVueReferentiel(final Tracabilite tracabilite_p, String noCompte_p, String clientOperateur_p, List<String> listeLoginMail_p, EnumSet<SourceDonne> sourceDonnee_p) throws RavelException
  {

    PE0215_BL200Return bl200Return = new PE0215_BL200Return(RetourFactory.createOkRetour());
    ServiceTechnique stLac;
    ServiceTechnique stPfsMail;
    List<Referentiel> referentielRetour = new ArrayList<>();

    if (sourceDonnee_p.contains(SourceDonne.REFERENTIEL))
    {
      ConnectorResponse<Retour, List<ServiceTechnique>> lireTousParPfi = RSTProxy.getInstance().serviceTechniqueLireTousParPfi(tracabilite_p, clientOperateur_p, noCompte_p, null, null);
      List<ServiceTechnique> listeSt = lireTousParPfi._second;
      if (StringConstants.NOK.equals(lireTousParPfi._first.getResultat()))
      {
        if (!(IMegConsts.CAT4.equals(lireTousParPfi._first.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(lireTousParPfi._first.getDiagnostic())))
        {
          bl200Return.setRetour(lireTousParPfi._first);
          return bl200Return;
        }
      }

      for (String loginmail : listeLoginMail_p)
      {
        stLac = null;
        stPfsMail = null;

        if ((listeSt != null) && !listeSt.isEmpty())
        {
          stLac = new StLacFilter()//
              .whereStatutIsNot(Statut.INACTIF)//
              .whereTypeRessourceIsEqual(com.bytel.spirit.common.shared.saab.res.TypeRessource.ADRESSE_MAIL)//
              .whereIdRessourceIsEqual(loginmail)//
              .getFirst(lireTousParPfi._second);

          stPfsMail = new StPfsMailFilter() //
              .whereStatutIsNot(Statut.INACTIF) //
              .whereAddresseMailIsEqual(loginmail) //
              .getFirst(lireTousParPfi._second);
        }
        // CALL BL201
        PE0215_BL201Return resultBL201 = PE0215_BL201_CreerObjectReferentiel(tracabilite_p, loginmail, stPfsMail, stLac);
        referentielRetour.add(resultBL201.getReferentiel());

      }
      bl200Return.setListeReferentiel(referentielRetour);
    }
    return bl200Return;

  }

  /**
   * Creates a Referentiel object.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param loginMail_p
   *          LoginMail
   * @param stPfsMail_p
   *          ServiceTechnique
   * @param stLAC_p
   *          ServiceTechnique
   * @return Pair Retour-Referenciel
   *
   */
  @LogProcessBL
  private PE0215_BL201Return PE0215_BL201_CreerObjectReferentiel(@SuppressWarnings("unused") final Tracabilite tracabilite_p, String loginMail_p, ServiceTechnique stPfsMail_p, ServiceTechnique stLAC_p)
  {

    PE0215_BL201Return bl201Return = new PE0215_BL201Return(RetourFactory.createOkRetour());

    Ressource ressource = new Ressource();
    ressource.setTypeRessource(TypeRessource.ADRESSE_MAIL.toString());
    ressource.setEtatRessource(EtatRessource.ALLOUE.toString());
    ressource.setEtatAllocation(getEtatFromServiceTechnique(stLAC_p));

    Referentiel referentiel = new Referentiel();
    referentiel.setTypeService(TypeService.MAIL.name());
    referentiel.setLoginMail(loginMail_p);
    referentiel.setRessources(Arrays.asList(ressource));
    referentiel.setEtatProvisioning(getEtatFromServiceTechnique(stPfsMail_p));

    if (stPfsMail_p != null)
    {
      referentiel.setServicetechniques(Arrays.asList(stPfsMail_p));

      if (isValidStPfsMail(stPfsMail_p))
      {
        DonneesIdentificationSTPfsMail donnesIdentificationSTPfsMail = StPfsMail.class.cast(stPfsMail_p).getDonneesIdentificationStPfsMail();
        DonneesProvisionneesSTPfsMail donnesProvisionneesSTPfsMail = StPfsMail.class.cast(stPfsMail_p).getDonneesProvisionneesStPfsMail();
        if (donnesProvisionneesSTPfsMail == null)
        {
          donnesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail(null, 0, 0, null);
        }
        referentiel.setTypeServiceMail(donnesIdentificationSTPfsMail.getTypeServiceMail());
        referentiel.setTaillePieceJointe((long) donnesProvisionneesSTPfsMail.getTaillePieceJointe());
        referentiel.setVolumeBoite((long) donnesProvisionneesSTPfsMail.getVolumeBoite());
        referentiel.setNiveauRestriction(donnesProvisionneesSTPfsMail.getNiveauRestriction());
      }
      referentiel.setNoCompte(stPfsMail_p.getNoCompte());
      referentiel.setClientOperateur(stPfsMail_p.getClientOperateur());
      referentiel.setIdStPfs(stPfsMail_p.getIdSt());
    }

    bl201Return.setReferentiel(referentiel);
    return bl201Return;
  }

  /**
   * Calls KPSA Diag to build the PFS view.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param listLoginMail_p
   *          Liste des adresses Mail
   * @param sourceDonnee_p
   *          sourceDonne
   * @return Object {@Code PE0215_BL300_ConstruireVuePfsReturn}
   *
   * @throws RavelException
   *           on errors
   */
  @LogProcessBL
  private PE0215_BL300Return PE0215_BL300_ConstruireVuePfs(Tracabilite tracabilite_p, final List<String> listLoginMail_p, EnumSet<SourceDonne> sourceDonnee_p) throws RavelException
  {
    final PE0215_BL300Return bl300Return = new PE0215_BL300Return(RetourFactory.createOkRetour());

    List<PFS> pfslist = new ArrayList<>();
    Retour retourBloquant = null;
    Retour retour = RetourFactory.createOkRetour();
    if (sourceDonnee_p.contains(SourceDonne.PFS))
    {
      for (String loginMail : listLoginMail_p)
      {
        ReponseFonctionnellePI0150C reponseFonctionnelle = null;
        if (isNull(retourBloquant))
        {
          PROV_SI002_ExecuterProcessus provSI002 = new PROV_SI002_ExecuterProcessusBuilder().tracabilite(getTracabilite())//set Tracabilite
              .priorite(KPSA_DIAG_PRIORITE)//set priority
              .processus(PI0150C_ConsulterROMA_PROCESS_NAME)//set Process name to call
              .noms(Arrays.asList("nomDomaine", "adresseMail")) //set names //$NON-NLS-1$ //$NON-NLS-2$
              .valeurs(Arrays.asList("bbox.fr", loginMail))//set values //$NON-NLS-1$
              .build();
          ResponseConnector response = provSI002.execute(this);
          retour = provSI002.getRetour();

          if (isRetourOK(retour))
          {
            reponseFonctionnelle = response.getFunctionalResponse(ReponseFonctionnellePI0150C.class, GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ssZ));
          }
        }

        PFS pfs = null;
        if (isNull(retourBloquant))
        {
          if (RetourFactory.isRetourNOK(retour) && IMegConsts.CAT1.equals(retour.getCategorie()))
          {
            retourBloquant = RetourFactory.createRetour(retour.getResultat(), retour.getCategorie(), retour.getDiagnostic(), retour.getLibelle());
          }

          PE0215_BL301Return bl301Return = PE0215_BL301_CreerObjetPfs(tracabilite_p, loginMail, retour, reponseFonctionnelle);
          retour = RetourFactory.recopyRetour(retour, bl301Return.getRetour());
          pfs = bl301Return.getPfs();
        }
        else
        {
          PE0215_BL301Return bl301Return = PE0215_BL301_CreerObjetPfs(tracabilite_p, loginMail, retourBloquant, null);
          retour = RetourFactory.recopyRetour(retour, bl301Return.getRetour());
          pfs = bl301Return.getPfs();
        }

        pfslist.add(pfs);

      }
      bl300Return.setListePfs(pfslist);
      bl300Return.setRetour(retour);
    }
    return bl300Return;
  }

  /**
   * Create object PFS
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param loginMail_p
   *          Adresse Mail
   * @param retour_p
   *          Object {@Code Retour}
   * @param reponseFonctionnelle_p
   *          Object {@Code ReponseFonctionnellePI0150C}
   * @return Object {@Code PE0215_BL301_CreerObjetPfsReturn}
   *
   * @throws RavelException
   *           on errors
   */
  @LogProcessBL
  private PE0215_BL301Return PE0215_BL301_CreerObjetPfs(@SuppressWarnings("unused") final Tracabilite tracabilite_p, final String loginMail_p, final Retour retour_p, final ReponseFonctionnellePI0150C reponseFonctionnelle_p) throws RavelException
  {

    final PE0215_BL301Return bl301Return = new PE0215_BL301Return(RetourFactory.createOkRetour());

    final PFS pfs = new PFS();
    pfs.setLoginMail(loginMail_p);
    pfs.setTypePfs(TypePfs.ROMA.toString());

    if (RetourFactory.isRetourNOK(retour_p))
    {
      if (IMegConsts.CAT4.equals(retour_p.getCategorie()) && IMegSpiritConsts.MAIL_INCONNU.equals(retour_p.getDiagnostic()))
      {
        Audit audit = new Audit(Audit.Diagnostic.SERVICE_NON_PROVISIONNE.name(), SERVICE_NON_PREVISIONE_MSG);
        pfs.setAudits(Arrays.asList(audit));
      }
      else if (IMegConsts.CAT2.equals(retour_p.getCategorie()) && IMegConsts.SERVICE_TIERS_INDISPONIBLE.equals(retour_p.getDiagnostic()))
      {
        Erreur erreur = new Erreur(Erreur.TypeError.PFS_INDISPONIBLE.name(), MessageFormat.format(PFS_INDISPONIBLE_MSG, TypePfs.ROMA.name()));
        pfs.setErreurs(Arrays.asList(erreur));
      }
      else if (IMegConsts.CAT1.equals(retour_p.getCategorie()))
      {
        Erreur erreur = new Erreur(Erreur.TypeError.ERREUR_INTERNE.name(), ERREUR_APPEL_INTERNE);
        pfs.setErreurs(Arrays.asList(erreur));
      }
      else
      {
        Erreur erreur = new Erreur(retour_p.getDiagnostic(), retour_p.getLibelle());
        pfs.setErreurs(Arrays.asList(erreur));
      }

      bl301Return.setPfs(pfs);
      return bl301Return;

    }
    pfs.setIdCompteMail(reponseFonctionnelle_p.getIdCompteMail());
    pfs.setIdCompteMailPrincipal(reponseFonctionnelle_p.getIdCompteMailPrincipal());
    pfs.setTypeServiceMail(reponseFonctionnelle_p.getTypeServiceMail());
    pfs.setLoginMail(reponseFonctionnelle_p.getLoginMail());
    pfs.setTaillePieceJointe(reponseFonctionnelle_p.getTaillePieceJointe());
    pfs.setVolumeBoite(reponseFonctionnelle_p.getVolumeBoite());
    pfs.setNiveauRestriction(reponseFonctionnelle_p.getNiveauRestriction());
    pfs.setAntivirus(reponseFonctionnelle_p.getAntivirus());
    pfs.setAntispam(reponseFonctionnelle_p.getAntispam());
    pfs.setDateCreationCompte(reponseFonctionnelle_p.getDateCreationCompte());
    pfs.setDateModificationCompte(reponseFonctionnelle_p.getDateModificationCompte());

    bl301Return.setPfs(pfs);
    return bl301Return;
  }

  /**
   * @param tracabilite_p
   *          Tracabilite
   * @param listeReferentiel_p
   *          liste de Referentiel
   * @param listePFS_p
   *          liste de PFS
   * @param sourceDonnee_p
   *          Set de sources
   * @param audit_p
   *          Audit
   * @param pfi_p
   *          Oject PFI
   * @return BL400Return
   */
  @LogProcessBL
  private PE0215_BL400Return PE0215_BL400_ComparerVues(final Tracabilite tracabilite_p, List<Referentiel> listeReferentiel_p, List<com.bytel.spirit.fiat.shared.types.json.PFS> listePFS_p, EnumSet<SourceDonne> sourceDonnee_p, Boolean audit_p, PFI pfi_p)
  {

    Boolean creerActionCorrective;

    if ((listeReferentiel_p != null) && (!listeReferentiel_p.isEmpty()) && (listePFS_p != null) && (!listePFS_p.isEmpty()) && audit_p)
    {

      // For each PFS
      for (com.bytel.spirit.fiat.shared.types.json.PFS pfs : listePFS_p)
      {

        // PfsItem have list Erreurs Empty
        if ((pfs.getErreurs() == null) || pfs.getErreurs().isEmpty())
        {
          creerActionCorrective = false;
          //Filters list Referentiels by loginmail
          List<Referentiel> listReferentiel = listeReferentiel_p.stream().filter(o -> o.getLoginMail().equals(pfs.getLoginMail())).collect(Collectors.toList());

          // Check if list returned is empty or not and get list of ServiceTechniques from Referentiel filtered
          List<ServiceTechnique> listServiceTechniques = new ArrayList<>();

          if (!listReferentiel.isEmpty())
          {
            listServiceTechniques = listReferentiel.get(0).getServicetechniques();
          }

          StPfsMail stMail = null;
          if (listServiceTechniques != null)
          {
            // Filter List de ServicesTechniques
            stMail = new StPfsMailFilter().getFirst(listServiceTechniques);
          }

          PA paca = null;
          if (pfi_p.getPa() != null)
          {// Filters the list by the LoginMail of CompteAccess and CompteAccessSecondaire
            List<PA> pacaList = PFIUtils.filterPA(pfi_p.getPa(), new PFIFilter(PFIFilterOption.TYPE_PA, TypePA.COMPTE_ACCES.name(), TypePA.COMPTE_ACCES_SECONDAIRE.name()), new PFIFilter(PFIFilterOption.STATUT, Statut.ACTIF.name()), new PFIFilter(PFIFilterOption.PA_CA_CAS_LOGIN, pfs.getLoginMail()));

            if (!pacaList.isEmpty())
            {
              paca = pacaList.get(0);
            }
          }

          if ((stMail != null) && Statut.ACTIF.toString().equals(stMail.getStatut()))
          {
            if (findAuditByDiagnostique(pfs.getAudits(), Diagnostic.SERVICE_NON_PROVISIONNE) != null)
            {
              stMail.setStatut(Statut.INACTIF.name());
              creerActionCorrective = true;
            }
            else
            {
              Pair<List<String>, StPfsMail> listServiceTechniquePair = analyseIncoherencesSTMailPFS(pfs, stMail);
              List<String> incoherences = listServiceTechniquePair._first;
              stMail = listServiceTechniquePair._second;
              if (!incoherences.isEmpty())
              {
                creerActionCorrective = true;
                Audit audit = new Audit(Audit.Diagnostic.DESYNCHRO_PFS.name(), BL400_AUDIT_LIBELLE);
                audit.addParameters(incoherences);
                pfs.addAudit(audit);
              }
            }

            if (creerActionCorrective && (paca != null))
            {

              //Build ServiceTechnique list with only stMail inside
              ActionServiceTechniqueMail actionServiceTechnique = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), stMail.getStatut(), stMail.getDateModification());
              actionServiceTechnique.setIdSt(stMail.getIdSt());
              actionServiceTechnique.setTypePfs(stMail.getTypePfs());
              actionServiceTechnique.setCommentaire(stMail.getCommentaire());
              actionServiceTechnique.setDonneesProvisionneesStPfsMail(stMail.getDonneesProvisionneesStPfsMail());

              List<ActionServiceTechnique> astList = Arrays.asList(actionServiceTechnique);
              String idExterne = _processContext.getIdRequest() + pfs.getLoginMail();
              Retour bl5100Retour = null;
              String idActionCorrective = null;
              try
              {
                ActionCorrective actionCorrective = new ActionCorrective(stMail.getClientOperateur(), stMail.getNoCompte());
                actionCorrective.setActionsServicesTechniques(astList);
                BL5100_CreerActionCorrective bl5100 = new BL5100_CreerActionCorrective.BL5100_CreerActionCorrectiveBuilder() // create BL5100_CreerActionCorrective
                    .idExterne(idExterne).actionCorrective(actionCorrective).tracabilite(tracabilite_p) //set Tracabilite
                    .build();

                idActionCorrective = bl5100.execute(this);
                bl5100Retour = bl5100.getRetour();
              }
              catch (RavelException e)
              {
                RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(ERROR_CREATION_ACTION_CORRECTIVE, e.getMessage())));
              }
              finally
              {
                if (bl5100Retour == null)
                {
                  bl5100Retour = RetourFactory.createNOK(IMegConsts.CAT2, Consts.SERVICE_INDISPONIBLE.name(), Messages.getString("PE0215.BL400.ErrorBL5100")); //$NON-NLS-1$
                }
              }

              if (!isRetourOK(bl5100Retour))
              {
                RavelLogger.log(new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, bl5100Retour.getDiagnostic() + ": " + bl5100Retour.getLibelle())); //$NON-NLS-1$
                pfs.addErreur(new Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), MessageFormat.format(ERROR_CREATION_ACTION_CORRECTIVE, bl5100Retour.getDiagnostic())));
              }
              else
              {
                if (StringTools.isNotNullOrEmpty(idActionCorrective))
                {
                  pfs.setIdActionCorrective(idActionCorrective);
                }
                else
                {
                  RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(ERROR_CREATION_ACTION_CORRECTIVE, ID_ACTION_CORRECTIVE_NULL_MSG)));
                }
              }
            }
          }
        }
      }
    }
    return new PE0215_BL400Return(RetourFactory.createOkRetour(), listeReferentiel_p, listePFS_p);
  }

  /**
   * Compares 2 Strings without throwing exception if any of them is null.
   *
   * @param input_p
   *          First string to compare
   * @param compareTo_p
   *          Second string to compare
   * @return true if both strings are equals, false otherwise
   */
  private boolean safeStringEquals(String input_p, String compareTo_p)
  {
    if (((input_p == null) && (compareTo_p == null)) || ((input_p != null) && input_p.equals(compareTo_p)))
    {
      return true;
    }
    return false;
  }

  /**
   * send a sync response for requester.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param request_p
   *          The request object
   * @param pe2015Retour_p
   *          The Return
   */
  private void syncResponse(Tracabilite tracabilite_p, Request request_p, PE0215_Retour pe2015Retour_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp;
      ErrorCode errorCode;

      if (pe2015Retour_p.getReponseErreur() != null)
      {
        ravelResponse.setDataType("application/json"); //$NON-NLS-1$
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe2015Retour_p.getReponseErreur()));

        switch (pe2015Retour_p.getReponseErreur().getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.LOGIN_MAIL_INCONNU:
          case IMegSpiritConsts.ID_PA_INCONNU:
          case IMegSpiritConsts.NO_COMPTE_INCONNU:
            errorCode = ErrorCode.KO_00404;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        rsp = new Response(errorCode, ravelResponse);
      }

      else
      {
        //Add Json response in case OK
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).toJson(pe2015Retour_p));
        rsp = new Response(ErrorCode.OK_00200, ravelResponse);
      }

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PE0215 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);
    }
  }

}
