/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.squareup.moshi.Json;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0274_BL100GetReponse implements Serializable
{
  /**
   * Id for serialization
   */
  private static final long serialVersionUID = 2597865407795825200L;

  /**
   * resultsCount
   */
  @Json(name = "resultsCount")
  private int _resultsCount;

  /**
   * items
   */
  @Json(name = "items")
  private List<RessourceMessageries> _items;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0274_BL100GetReponse other = (PE0274_BL100GetReponse) obj;
    if (_items == null)
    {
      if (other._items != null)
      {
        return false;
      }
    }
    else if (!_items.equals(other._items))
    {
      return false;
    }
    if (_resultsCount != other._resultsCount)
    {
      return false;
    }
    return true;
  }

  /**
   * @return the items
   */
  public List<RessourceMessageries> getItems()
  {
    return (_items != null) ? new ArrayList<>(_items) : new ArrayList<>();
  }

  /**
   * @return the resultsCount
   */
  public int getResultsCount()
  {
    return _resultsCount;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_items == null) ? 0 : _items.hashCode());
    result = (prime * result) + _resultsCount;
    return result;
  }

  /**
   * @param items_p
   *          the items to set
   */
  public void setItems(List<RessourceMessageries> items_p)
  {
    _items = new ArrayList<>(items_p);
  }

  /**
   * @param resultsCount_p
   *          the resultsCount to set
   */
  public void setResultsCount(int resultsCount_p)
  {
    _resultsCount = resultsCount_p;
  }

  @Override
  public String toString()
  {
    return "PE0274_BL100GetReponse [_resultsCount=" + _resultsCount + ", _items=" + _items + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }
}
