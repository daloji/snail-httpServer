/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.json.annotations.RavelPolymorphism;
import com.bytel.ravel.common.json.annotations.RavelPolymorphismProfil;
import com.bytel.ravel.common.json.annotations.RavelPolymorphisms;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.squareup.moshi.Json;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
@RavelPolymorphisms({ @RavelPolymorphismProfil( //
    name = SpiritConstants.JSON_PROFILE_STARK, //
    type = "typePfs", //
    value = { //
        @RavelPolymorphism(type = "PCM", clazz = PE0302_PfsPcm.class), //
        @RavelPolymorphism(type = "SAM", clazz = PE0302_PfsSam.class) //
    }) //
})
public class PE0302_PFS implements Serializable
{
  /**
   *
   * @author pramos
   * @version ($Revision$ $Date$)
   */
  public enum typePfs
  {
    /**
    *
    */
    SAM,
    /**
    *
    */
    PCM
  }

  /**
   *
   */
  private static final long serialVersionUID = 5273539314705576861L;

  /**
   * typePfs
   */
  @Json(name = "typePfs")
  private String _typePfs;

  /**
   * noTelephone
   */
  @Json(name = "noTelephone")
  private String _noTelephone;

  /**
   * audits
   */
  @Json(name = "audits")
  private List<PE0302_Audit> _audits;

  /**
   * erreurs
   */
  @Json(name = "erreurs")
  private List<PE0302_Erreur> _erreurs;

  /**
   * @param typePfs_p
   * @param noTelephone_p
   */
  public PE0302_PFS(String typePfs_p, String noTelephone_p)
  {
    super();
    _typePfs = typePfs_p;
    _noTelephone = noTelephone_p;

  }

  /**
   * @return the audits
   */
  public List<PE0302_Audit> getAudits()
  {
    return _audits != null ? new ArrayList<>(_audits) : new ArrayList<>();
  }

  /**
   * @return the erreurs
   */
  public List<PE0302_Erreur> getErreurs()
  {
    return _erreurs != null ? new ArrayList<>(_erreurs) : new ArrayList<>();
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the typePfs
   */
  public String getTypePfs()
  {
    return _typePfs;
  }

  /**
   * @param audits_p
   *          the audits to set
   */
  public void setAudits(List<PE0302_Audit> audits_p)
  {
    _audits = new ArrayList<>(audits_p);
  }

  /**
   * @param erreurs_p
   *          the erreurs to set
   */
  public void setErreurs(List<PE0302_Erreur> erreurs_p)
  {
    _erreurs = new ArrayList<>(erreurs_p);
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param typePfs_p
   *          the typePfs to set
   */
  public void setTypePfs(String typePfs_p)
  {
    _typePfs = typePfs_p;
  }

}
