/**
 *
 */
package com.bytel.spirit.fiat.processes.PE0298.structs;

import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;

/**
 * @author kbettenc
 *
 */
public class PE0298_BL001Return extends AbstractBLReturn
{
  /**
   *
   */
  private static final long serialVersionUID = -4852001305024692353L;

  /**
   * Numero de télephone
   */
  private String _noTelephone;

  /**
   * Liste de source donnée
   */
  private List<String> _listeSourceDonnee;

  /**
   * Flag pour declencher un audit entre les 2 vues référentiel SPIRIT et les plateformes réseaux
   */
  private Boolean _audit;

  /**
   * Identifiant de la demande
   */
  private String _idRequest;

  private String _clientOperateur;

  private String _noCompte;

  /**
   * Default constructor
   */
  public PE0298_BL001Return(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @param noTelephone_p
   * @param audit_p
   * @param modeAppel_p
   * @param listeSourceDonnee_p
   */
  public PE0298_BL001Return(Retour retour_p, String noTelephone_p, List<String> listeSourceDonnee_p, Boolean audit_p, String idRequest_p, String clientOperateur_p, String noCompte_p)
  {
    super(retour_p);
    _noTelephone = noTelephone_p;
    _listeSourceDonnee = listeSourceDonnee_p != null ? new ArrayList<>(listeSourceDonnee_p) : new ArrayList<>();
    _audit = audit_p;
    _idRequest = idRequest_p;
    _clientOperateur = clientOperateur_p;
    _noCompte = noCompte_p;
  }

  /**
   * @param sourceDonnee_p
   *          the contratOuath to add
   */
  public void addSourceDonnee(String sourceDonnee_p)
  {
    if (_listeSourceDonnee == null)
    {
      _listeSourceDonnee = new ArrayList<>();
    }
    _listeSourceDonnee.add(sourceDonnee_p);
  }

  /**
   * @return the audit
   */
  public Boolean getAudit()
  {
    return _audit;
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the idRequest
   */
  public String getIdRequest()
  {
    return _idRequest;
  }

  /**
   * @return the listeContratOauth
   */
  public List<String> getListeSourceDonnee()
  {
    return _listeSourceDonnee != null ? new ArrayList<>(_listeSourceDonnee) : new ArrayList<>();
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @param audit_p
   *          the audit to set
   */
  public void setAudit(Boolean audit_p)
  {
    _audit = audit_p;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param idRequest_p
   *          the idRequest to set
   */
  public void setIdRequest(String idRequest_p)
  {
    _idRequest = idRequest_p;
  }

  /**
   * @param listeSourceDonnee_p
   *          the listeSourceDonnee_p to set
   */
  public void setListeSourceDonnee(List<String> listeSourceDonnee_p)
  {
    _listeSourceDonnee = listeSourceDonnee_p != null ? new ArrayList<>(listeSourceDonnee_p) : new ArrayList<>();
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }
}
