/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0296.structs;

import java.util.EnumSet;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;
import com.bytel.spirit.fiat.processes.PE0296.PE0296_DiagnosticRaccordement.SourceDonnee;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class PE0296_BL001Return extends AbstractBLReturn
{

  /**
  *
  */
  private static final long serialVersionUID = 1L;
  /**
   * Client Operateur
   */
  private String _clientOperateur;
  /**
   * NoCompte
   */
  private String _noCompte;

  /**
   * idRaccordement
   */
  private String _idRaccordement;

  /**
   * IdentifiantFonctionnelPa
   */
  private String _identifiantFonctionnelPa;

  /**
   * SourceDonnee
   */
  private EnumSet<SourceDonnee> _sourceDonnee;
  /**
   * Audit
   */
  private Boolean _audit;

  /**
   * requestID
   */
  private String _requestID;

  /**
   * @param retour_p
   *          retour
   */
  public PE0296_BL001Return(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @param retour_p
   *          retour
   * @param sourceDonnee_p
   *          sourceDonnee
   * @param audit_p
   *          audit
   * @param requestID_p
   *          requestID
   */
  public PE0296_BL001Return(Retour retour_p, EnumSet<SourceDonnee> sourceDonnee_p, Boolean audit_p, String requestID_p)
  {
    super(retour_p);
    _sourceDonnee = EnumSet.copyOf(sourceDonnee_p);
    _audit = audit_p;
    _requestID = requestID_p;
  }

  /**
   * @return the audit
   */
  public Boolean getAudit()
  {
    return _audit;
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the identifiantFonctionnelPa
   */
  public String getIdentifiantFonctionnelPa()
  {
    return _identifiantFonctionnelPa;
  }

  /**
   * @return the idRaccordement
   */
  public String getIdRaccordement()
  {
    return _idRaccordement;
  }

  /**
   * @return the noCompte
   */
  public String getNoCompte()
  {
    return _noCompte;
  }

  /**
   * @return the requestID
   */
  public String getRequestID()
  {
    return _requestID;
  }

  /**
   * @return the sourceDonnee
   */
  public EnumSet<SourceDonnee> getSourceDonnee()
  {
    if (_sourceDonnee != null)
    {
      return _sourceDonnee.clone();
    }
    return EnumSet.noneOf(SourceDonnee.class);
  }

  /**
   * @param audit_p
   *          the audit to set
   */
  public void setAudit(Boolean audit_p)
  {
    _audit = audit_p;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param identifiantFonctionnelPa_p
   *          the identifiantFonctionnelPa to set
   */
  public void setIdentifiantFonctionnelPa(String identifiantFonctionnelPa_p)
  {
    _identifiantFonctionnelPa = identifiantFonctionnelPa_p;
  }

  /**
   * @param idRaccordement_p
   *          the idRaccordement to set
   */
  public void setIdRaccordement(String idRaccordement_p)
  {
    _idRaccordement = idRaccordement_p;
  }

  /**
   * @param noCompte_p
   *          the noCompte to set
   */
  public void setNoCompte(String noCompte_p)
  {
    _noCompte = noCompte_p;
  }

  /**
   * @param requestID_p
   *          the requestID to set
   */
  public void setRequestID(String requestID_p)
  {
    _requestID = requestID_p;
  }

  /**
   * @param sourceDonnee_p
   *          the sourceDonnee to set
   */
  public void setSourceDonnee(EnumSet<SourceDonnee> sourceDonnee_p)
  {
    if (sourceDonnee_p != null)
    {
      _sourceDonnee = sourceDonnee_p.clone();
    }
    else
    {
      _sourceDonnee = EnumSet.noneOf(SourceDonnee.class);
    }
  }
}
