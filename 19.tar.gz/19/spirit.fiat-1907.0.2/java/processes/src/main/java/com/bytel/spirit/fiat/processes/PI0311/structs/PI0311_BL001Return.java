/**
 *
 */
package com.bytel.spirit.fiat.processes.PI0311.structs;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;

/**
 * @author mbaptist
 *
 */
public class PI0311_BL001Return extends AbstractBLReturn
{

  /**
   * 
   */
  private static final long serialVersionUID = 7169346574558901093L;

  /**
   * Numero de télephone
   */
  private String _idVmsStw;

  /**
   * Numero de télephone
   */
  private String _noTelephone;

  /**
   * Default constructor
   */
  public PI0311_BL001Return(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @param idVmsStw_p
   * @param noTelephone_p
   */
  public PI0311_BL001Return(Retour retour_p, String idVmsStw_p, String noTelephone_p)
  {
    super(retour_p);
    _idVmsStw = idVmsStw_p;
    _noTelephone = noTelephone_p;
  }

  /**
   * @return the _idVmsStw
   */
  public String getIdVmsStw()
  {
    return _idVmsStw;
  }

  /**
   * @return the _noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @param _idVmsStw
   *          the _idVmsStw to set
   */
  public void setIdVmsStw(String idVmsStw_p)
  {
    this._idVmsStw = idVmsStw_p;
  }

  /**
   * @param _noTelephone
   *          the _noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    this._noTelephone = noTelephone_p;
  }
}
