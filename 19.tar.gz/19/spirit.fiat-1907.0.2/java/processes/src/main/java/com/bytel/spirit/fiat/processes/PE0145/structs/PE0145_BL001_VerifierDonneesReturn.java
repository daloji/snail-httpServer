/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0145.structs;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;

/**
 *
 * @author jbrites
 * @version ($Revision$ $Date$)
 */
public class PE0145_BL001_VerifierDonneesReturn extends AbstractBLReturn
{

  /**
   *
   */
  private static final long serialVersionUID = -5386279297166554840L;

  /**
   * The client operateur
   */
  private String _clientOperateur;

  /**
   * The portefeuille commercial Source
   */
  private String _noCompteSource;

  /**
   * The portefeuille commercial Cible
   */
  private String _noCompteCible;

  /**
   * The Source email adress
   */
  private String _adresseMailSource;

  /**
   * The Cible email adress
   */
  private String _adresseMailCible;

  /**
   * The transfer mode
   */
  private String _modeTransfert;

  /**
   * @param retour_p
   *          retour
   */
  public PE0145_BL001_VerifierDonneesReturn(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @return the adresseMailCible
   */
  public String getAdresseMailCible()
  {
    return _adresseMailCible;
  }

  /**
   * @return the adresseMailSource
   */
  public String getAdresseMailSource()
  {
    return _adresseMailSource;
  }

  /**
   * @return the clientOperateur
   */
  public String getClientOperateur()
  {
    return _clientOperateur;
  }

  /**
   * @return the modeTransfert
   */
  public String getModeTransfert()
  {
    return _modeTransfert;
  }

  /**
   * @return the noCompteCible
   */
  public String getNoCompteCible()
  {
    return _noCompteCible;
  }

  /**
   * @return the noCompteSource
   */
  public String getNoCompteSource()
  {
    return _noCompteSource;
  }

  /**
   * @param adresseMailCible_p
   *          the adresseMailCible to set
   */
  public void setAdresseMailCible(String adresseMailCible_p)
  {
    _adresseMailCible = adresseMailCible_p;
  }

  /**
   * @param adresseMailSource_p
   *          the adresseMailSource to set
   */
  public void setAdresseMailSource(String adresseMailSource_p)
  {
    _adresseMailSource = adresseMailSource_p;
  }

  /**
   * @param clientOperateur_p
   *          the clientOperateur to set
   */
  public void setClientOperateur(String clientOperateur_p)
  {
    _clientOperateur = clientOperateur_p;
  }

  /**
   * @param modeTransfert_p
   *          the modeTransfert to set
   */
  public void setModeTransfert(String modeTransfert_p)
  {
    _modeTransfert = modeTransfert_p;
  }

  /**
   * @param noCompteCible_p
   *          the noCompteCible to set
   */
  public void setNoCompteCible(String noCompteCible_p)
  {
    _noCompteCible = noCompteCible_p;
  }

  /**
   * @param noCompteSource_p
   *          the noCompteSource to set
   */
  public void setNoCompteSource(String noCompteSource_p)
  {
    _noCompteSource = noCompteSource_p;
  }
}
