/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0276.structs;

import com.bytel.spirit.fiat.processes.structs.GetResponse;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PE0276_BL100Reponse extends GetResponse<AnnoncesAccueil>
{

  /**
   *
   */
  private static final long serialVersionUID = -334756890198539886L;

}
