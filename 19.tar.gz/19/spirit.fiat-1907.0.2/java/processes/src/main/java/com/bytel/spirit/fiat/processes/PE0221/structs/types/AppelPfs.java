/**
 *
 */
package com.bytel.spirit.fiat.processes.PE0221.structs.types;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * @author mbaptist
 *
 */
public class AppelPfs implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = -2055769687062234277L;

  /**
   * numero appelant
   */
  @SerializedName("numeroAppelant")
  @Expose
  private String _numeroAppelant;

  /**
   * numero appelé
   */
  @SerializedName("numeroAppele")
  @Expose
  private String _numeroAppele;

  /**
   * Data debut
   */
  @SerializedName("dateDebut")
  @Expose
  private LocalDateTime _dateDebut;

  /**
   * Date Fin
   */
  @SerializedName("dateFin")
  @Expose
  private LocalDateTime _dateFin;

  /**
   * Typologie de l'appel
   */
  @SerializedName("typologieAppel")
  @Expose
  private String _typologieAppel;

  /**
   * Statut d'aboutissement de l'appel
   */
  @SerializedName("aboutissement")
  @Expose
  private String _aboutissement;

  /**
   * Numéro auquel l'appel a été transféré
   */
  private String _numeroTransfert;

  /**
   * @return the aboutissement
   */
  public String getAboutissement()
  {
    return _aboutissement;
  }

  /**
   * @return the dateDebut
   */
  public LocalDateTime getDateDebut()
  {
    return _dateDebut;
  }

  /**
   * @return the dateFin
   */
  public LocalDateTime getDateFin()
  {
    return _dateFin;
  }

  /**
   * @return the numeroAppelant
   */
  public String getNumeroAppelant()
  {
    return _numeroAppelant;
  }

  /**
   * @return the numeroAppele
   */
  public String getNumeroAppele()
  {
    return _numeroAppele;
  }

  /**
   * @return the numeroTransfert
   */
  public String getNumeroTransfert()
  {
    return _numeroTransfert;
  }

  /**
   * @return the typologieAppel
   */
  public String getTypologieAppel()
  {
    return _typologieAppel;
  }

  /**
   * @param aboutissement_p
   *          the aboutissement to set
   */
  public void setAboutissement(String aboutissement_p)
  {
    _aboutissement = aboutissement_p;
  }

  /**
   * @param dateDebut_p
   *          the dateDebut to set
   */
  public void setDateDebut(LocalDateTime dateDebut_p)
  {
    _dateDebut = dateDebut_p;
  }

  /**
   * @param dateFin_p
   *          the dateFin to set
   */
  public void setDateFin(LocalDateTime dateFin_p)
  {
    _dateFin = dateFin_p;
  }

  /**
   * @param numeroAppelant_p
   *          the numeroAppelant to set
   */
  public void setNumeroAppelant(String numeroAppelant_p)
  {
    _numeroAppelant = numeroAppelant_p;
  }

  /**
   * @param numeroAppele_p
   *          the numeroAppele to set
   */
  public void setNumeroAppele(String numeroAppele_p)
  {
    _numeroAppele = numeroAppele_p;
  }

  /**
   * @param numeroTransfert_p
   *          the numeroTransfert to set
   */
  public void setNumeroTransfert(String numeroTransfert_p)
  {
    _numeroTransfert = numeroTransfert_p;
  }

  /**
   * @param typologieAppel_p
   *          the typologieAppel to set
   */
  public void setTypologieAppel(String typologieAppel_p)
  {
    _typologieAppel = typologieAppel_p;
  }

}
