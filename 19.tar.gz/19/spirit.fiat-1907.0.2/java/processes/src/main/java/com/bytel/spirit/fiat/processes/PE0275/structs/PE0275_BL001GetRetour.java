/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0275.structs;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author vloureir
 * @version ($Revision$ $Date$)
 */
public class PE0275_BL001GetRetour
{
  /**
   * ID of the mailbox
   */
  private String _idMessagerie;

  /**
   * ID Message
   */
  private String _idMessage;

  /**
   * Type operation
   */
  private OperationMessage _typeOperation;

  /**
   * mode appel
   */
  private String _modeAppel;

  /**
   * List contracts auth
   */
  private List<String> _listeContratOauth;

  /**
   * @return the idMessage
   */
  public String getIdMessage()
  {
    return _idMessage;
  }

  /**
   * @return the idMessagerie
   */
  public String getIdMessagerie()
  {
    return _idMessagerie;
  }

  /**
   * @return the listeContratOauth
   */
  public List<String> getListeContratOauth()
  {
    return _listeContratOauth != null ? new ArrayList<>(_listeContratOauth) : new ArrayList<>();
  }

  /**
   * @return the modeAppel
   */
  public String getModeAppel()
  {
    return _modeAppel;
  }

  /**
   * @return the typeOperation
   */
  public OperationMessage getTypeOperation()
  {
    return _typeOperation;
  }

  /**
   * @param idMessage_p
   *          the idMessage to set
   */
  public void setIdMessage(String idMessage_p)
  {
    _idMessage = idMessage_p;
  }

  /**
   * @param idMessagerie_p
   *          the idMessagerie to set
   */
  public void setIdMessagerie(String idMessagerie_p)
  {
    _idMessagerie = idMessagerie_p;
  }

  /**
   * @param listeContratOauth_p
   *          the listeContratOauth to set
   */
  public void setListeContratOauth(List<String> listeContratOauth_p)
  {
    _listeContratOauth = new ArrayList<>(listeContratOauth_p);
  }

  /**
   * @param modeAppel_p
   *          the modeAppel to set
   */
  public void setModeAppel(String modeAppel_p)
  {
    _modeAppel = modeAppel_p;
  }

  /**
   * @param typeOperation_p
   *          the typeOperation to set
   */
  public void setTypeOperation(OperationMessage typeOperation_p)
  {
    _typeOperation = typeOperation_p;
  }
}
