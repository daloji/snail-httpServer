/**
 *
 */
package com.bytel.spirit.fiat.processes.PE0221.structs;

import com.bytel.spirit.common.shared.misc.error.ReponseErreur;

/**
 * @author mbaptist
 *
 */
public class PE0221_BL002Return
{
  /**
   * Le reponse erreur
   */
  private ReponseErreur _reponseErreur;

  /**
   * Le reponse du process
   */
  private PE0221_GetResponse _pe0221getRetour;

  /**
   * @return the pe0221_retour_GET
   */
  public PE0221_GetResponse getPe0221RetourGET()
  {
    return _pe0221getRetour;
  }

  /**
   * @return the reponseErreur
   */
  public ReponseErreur getReponseErreur()
  {
    return _reponseErreur;
  }

  /**
   * @param pe0221getRetour_p
   *          the pe0221_retourGET to set
   */
  public void setPe0221RetourGET(PE0221_GetResponse pe0221getRetour_p)
  {
    _pe0221getRetour = pe0221getRetour_p;
  }

  /**
   * @param reponseErreur_p
   *          the reponseErreur to set
   */
  public void setReponseErreur(ReponseErreur reponseErreur_p)
  {
    _reponseErreur = reponseErreur_p;
  }

}
