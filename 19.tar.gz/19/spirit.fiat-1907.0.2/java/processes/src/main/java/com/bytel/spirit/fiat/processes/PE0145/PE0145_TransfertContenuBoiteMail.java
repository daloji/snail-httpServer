/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0145;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.*;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.types.json.request.ServiceMailRequest;
import com.bytel.spirit.common.shared.types.json.request.ServiceMailTransfertRequest;
import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0145.structs.PE0145_BL001_VerifierDonneesReturn;
import com.bytel.spirit.fiat.processes.PE0145.structs.PE0145_BL100_PreparerTransfertContenuBoiteMailReturn;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PE0145_TransfertContenuBoiteMail extends SpiritProcessSkeleton
{
  /**
   * Process context
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public static final class PE0145_TransfertContenuBoiteMailContext extends Context
  {
    /**
     * The generated UID
     */
    private static final long serialVersionUID = 4018142641825841458L;

    /**
     * The clientOperateur from header
     */
    private String _xClientOperateur;

    /***
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0145_BL001;

    /**
     * The source from header
     */
    private String _xSource;

    /**
     * The process from header
     */
    private String _xProcess;

    /**
     * The requestId from header
     */
    private String _xRequestId;

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the xClientOperateur
     */
    public String getxClientOperateur()
    {
      return _xClientOperateur;
    }

    /**
     * @return the xProcess
     */
    public String getxProcess()
    {
      return _xProcess;
    }

    /**
     * @return the xRequestId
     */
    public String getxRequestId()
    {
      return _xRequestId;
    }

    /**
     * @return the xSource
     */
    public String getxSource()
    {
      return _xSource;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param xClientOperateur_p
     *          the xClientOperateur to set
     */
    public void setxClientOperateur(String xClientOperateur_p)
    {
      _xClientOperateur = xClientOperateur_p;
    }

    /**
     * @param xProcess_p
     *          the xProcess to set
     */
    public void setxProcess(String xProcess_p)
    {
      _xProcess = xProcess_p;
    }

    /**
     * @param xRequestId_p
     *          the xRequestId to set
     */
    public void setxRequestId(String xRequestId_p)
    {
      _xRequestId = xRequestId_p;
    }

    /**
     * @param xSource_p
     *          the xSource to set
     */
    public void setxSource(String xSource_p)
    {
      _xSource = xSource_p;
    }

  }

  /**
   * The Enum containing all process states
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * Verifier_Donnes
     */
    PE0145_BL001(MandatoryProcessState.PRC_START, false, false),
    /**
     * Formater_Reponse
     */
    PE0145_BL002(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * Preparer_Transfert
     */
    PE0145_BL100(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * Lancer_Orchestrateur
     */
    PE0145_SI002(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * GererErreurProsper
     */
    PE0145_BL005(MandatoryProcessState.PRC_RUNNING, true, true),
    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * Constant for process name in call to PROV_SI002
   */
  private static final String PI0150B_TRANSFERER_COPIER_ROMA_PROCESS_NAME = "PI0150B_TransfererCopierROMA"; //$NON-NLS-1$

  /**
   * Priority of call PROV_SI002
   */
  private static final int CALL_PROV_SI002_PRIORITY = 10;

  /**
   * Constant for bbox.fr domaine
   */
  private static final String DOMAINE_BBOX_FR = "bbox.fr"; //$NON-NLS-1$

  /**
   * Constant for mode
   */
  private static final String MODE_TRANSFERT_NAME = "mode"; //$NON-NLS-1$

  /**
   * Constant for idCompteMailCible
   */
  private static final String ID_COMPTE_MAIL_CIBLE_NAME = "idCompteMailCible"; //$NON-NLS-1$

  /**
   * Constant for adresseMailCible
   */
  private static final String ADRESSE_MAIL_CIBLE_NAME = "adresseMailCible"; //$NON-NLS-1$

  /**
   * Constant for idCompteMailSource
   */
  private static final String ID_COMPTE_MAIL_SOURCE_NAME = "idCompteMailSource"; //$NON-NLS-1$

  /**
   * Constant for name adressMailSource
   */
  private static final String ADRESSE_MAIL_SOURCE_NAME = "adresseMailSource"; //$NON-NLS-1$

  /**
   * Constant for nomDomaine
   */
  private static final String NOM_DOMAINE_NAME = "nomDomaine"; //$NON-NLS-1$

  /**
   * Type ST Niveau 2
   */
  private static final String TYPE_ST_MAIL = "MAIL"; //$NON-NLS-1$

  /**
   * Type ST Niveau 1
   */
  private static final String TYPE_ST_PFS = "PFS"; //$NON-NLS-1$

  /**
   * The generated UID
   */
  private static final long serialVersionUID = 1323492390814662192L;

  /**
   * The MAIL_INCONNU message
   */
  private static final String MESSAGE_MAIL_INCONNU = Messages.getString("PE0145.BL100.UnknownAddressMail"); //$NON-NLS-1$

  /**
   * The MAIL_INACTIF message
   */
  private static final String MESSAGE_MAIL_INACTIF = Messages.getString("PE0145.BL100.InactiveAddressMail"); //$NON-NLS-1$

  /**
   * DONNEES_IDENTIFICATION_NULL
   */
  private static final String DONNEES_IDENTIFICATION_NULL = Messages.getString("PE0145.BL100.DonneesIdentificationStPfsMailNull"); //$NON-NLS-1$

  /**
   * The process context.
   */
  private PE0145_TransfertContenuBoiteMailContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return ""; //$NON-NLS-1$
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0145_TransfertContenuBoiteMailContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = this.getRetour();
    if (State.PE0145_BL005.equals(_processContext.getState()))
    {
      retour = PE0145_BL005_GererErreurPROSPER(tracabilite_p, retour);
    }
    _processContext.setState(State.ENDED);
    this.setRetour(retour);
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel

  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel

  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = null;
    try
    {
      PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100Result = new PE0145_BL100_PreparerTransfertContenuBoiteMailReturn(null);

      //Call BL001
      PE0145_BL001_VerifierDonneesReturn bl001Result = PE0145_BL001_VerifierDonnees(tracabilite_p, request_p);
      retour = bl001Result.getRetour();

      if (RetourFactory.isRetourOK(retour))
      {
        //Call BL100
        _processContext.setState(State.PE0145_BL100);
        bl100Result = PE0145_BL100_PreparerTransfertContenuBoiteMail(tracabilite_p, bl001Result.getClientOperateur(), bl001Result.getNoCompteSource(), bl001Result.getAdresseMailSource(), bl001Result.getNoCompteCible(), bl001Result.getAdresseMailCible());
        retour = bl100Result.getRetour();
      }

      if (RetourFactory.isRetourOK(retour))
      {
        // Call SI002
        _processContext.setState(State.PE0145_SI002);

        List<String> noms = new ArrayList<>();
        noms.add(NOM_DOMAINE_NAME);
        noms.add(ADRESSE_MAIL_SOURCE_NAME);
        noms.add(ID_COMPTE_MAIL_SOURCE_NAME);
        noms.add(ADRESSE_MAIL_CIBLE_NAME);
        noms.add(ID_COMPTE_MAIL_CIBLE_NAME);
        noms.add(MODE_TRANSFERT_NAME);

        List<String> valeurs = new ArrayList<>();
        valeurs.add(DOMAINE_BBOX_FR);
        valeurs.add(bl001Result.getAdresseMailSource());
        valeurs.add(bl100Result.getIdCompteMailSource());
        valeurs.add(bl001Result.getAdresseMailCible());
        valeurs.add(bl100Result.getIdCompteMailCible());
        valeurs.add(bl001Result.getModeTransfert());

        PROV_SI002_ExecuterProcessus si002 = new PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder().tracabilite(tracabilite_p)//
            .cles(Collections.emptyList())//
            .priorite(CALL_PROV_SI002_PRIORITY)//
            .processus(PI0150B_TRANSFERER_COPIER_ROMA_PROCESS_NAME)//
            .noms(noms)//
            .valeurs(valeurs)//
            .build();
        si002.execute(this);

        retour = si002.getRetour();
      }
    }
    catch (Exception ex)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, ex.getMessage());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ex));
    }
    finally
    {
      //Call BL002
      _processContext.setState(State.PE0145_BL002);
      Pair<ReponseErreur, Retour> bl002Result = PE0145_BL002_FormaterReponse(tracabilite_p, retour);
      this.setRetour(retour);
      _processContext.setState(State.PE0145_BL005);
      syncResponse(tracabilite_p, request_p, bl002Result._first);
    }
  }

  /**
   * @param tracabilite_p
   *          The trace
   * @param request_p
   *          The request
   *
   * @return The retour
   */
  private Retour checkHeaders(Tracabilite tracabilite_p, final Request request_p)
  {
    String clientOperateur = null;
    String source = null;
    String process = null;

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_CLIENT_OPERATEUR.equalsIgnoreCase(header.getName()))
      {
        clientOperateur = header.getValue();
      }
      else if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        process = header.getValue();
      }
      else if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        source = header.getValue();
      }
    }

    if (StringTools.isNullOrEmpty(clientOperateur))
    {
      String libelleErreur = MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_CLIENT_OPERATEUR); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }
    if (StringTools.isNullOrEmpty(source))
    {
      String libelleErreur = MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_SOURCE); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }
    if (StringTools.isNullOrEmpty(process))
    {
      String libelleErreur = MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_PROCESS); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }
    if (StringTools.isNullOrEmpty(tracabilite_p.getIdCorrelationByTel()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID))); //$NON-NLS-1$
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID)); //$NON-NLS-1$
    }
    if (StringTools.isNullOrEmpty(getMessageId()))
    {
      String libelleErreur = MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_MESSAGE_ID); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }

    _processContext.setxClientOperateur(clientOperateur);
    _processContext.setxSource(source);
    _processContext.setxProcess(process);

    return RetourFactory.createOkRetour();
  }

  /**
   * Validates Json object received in the request parameter.
   *
   * @param request_p
   *          The request
   * @param tracabilite_p
   *          Tracabilite
   * @return PE0145_BL001_verifierDonnesReturn
   * @throws RavelException
   *           Thrown If bl1700 throws RavelException
   */
  @LogProcessBL
  private PE0145_BL001_VerifierDonneesReturn PE0145_BL001_VerifierDonnees(Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    ServiceMailTransfertRequest serviceMailTransfertRequest = null;
    PE0145_BL001_VerifierDonneesReturn bl001_VerifierDonneesReturn = new PE0145_BL001_VerifierDonneesReturn(retour);

    /*---------- Verification headers et STI ----------*/
    try
    {
      retour = checkHeaders(tracabilite_p, request_p);
      bl001_VerifierDonneesReturn.setRetour(retour);

      //check STI
      if (isRetourOK(retour))
      {
        serviceMailTransfertRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request_p.getPayload(), ServiceMailTransfertRequest.class);
      }
      else
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, retour.getLibelle());
        bl001_VerifierDonneesReturn.setRetour(retour);
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PE0145.BL001.StiError") + "\\n" + ExceptionTools.getStringStackTrace(e))); //$NON-NLS-1$ //$NON-NLS-2$

      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0145.BL001.StiError")); //$NON-NLS-1$
      bl001_VerifierDonneesReturn.setRetour(retour);
    }

    if (serviceMailTransfertRequest != null)
    {
      ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
      Validator validator = factory.getValidator();
      Set<ConstraintViolation<ServiceMailRequest>> constraintViolations = validator.validate(serviceMailTransfertRequest);

      if (!constraintViolations.isEmpty())
      {
        StringBuilder requiredAttrSb = new StringBuilder();
        StringBuilder formatErrAttrSb = new StringBuilder();
        StringBuilder invalidAttrSb = new StringBuilder();
        for (ConstraintViolation<ServiceMailRequest> c : constraintViolations)
        {
          if (IMessageFormatKeys.REQUIRED_FILED.equals(c.getMessage()))
          {
            requiredAttrSb.append("[").append(c.getPropertyPath()).append("]"); //$NON-NLS-1$ //$NON-NLS-2$
          }
          if (IMessageFormatKeys.INVALID_FORMAT.equals(c.getMessage()))
          {
            formatErrAttrSb.append("[").append(c.getPropertyPath()).append("]"); //$NON-NLS-1$ //$NON-NLS-2$
          }
          if (IMessageFormatKeys.INVALID_FIELD_VALUE.equals(c.getMessage()))
          {
            invalidAttrSb.append("[").append(c.getPropertyPath()).append("]"); //$NON-NLS-1$ //$NON-NLS-2$
          }
        }
        StringBuilder validationMessageSb = new StringBuilder();
        if (StringTools.isNotNullOrEmpty(requiredAttrSb.toString()))
        {
          validationMessageSb.append(MessageFormat.format(Messages.getString(IMessageFormatKeys.REQUIRED_FILED), requiredAttrSb.toString()));
        }
        if (StringTools.isNotNullOrEmpty(formatErrAttrSb.toString()))
        {
          validationMessageSb.append(MessageFormat.format(Messages.getString(IMessageFormatKeys.INVALID_FORMAT), formatErrAttrSb.toString()));
        }
        if (StringTools.isNotNullOrEmpty(invalidAttrSb.toString()))
        {
          validationMessageSb.append(MessageFormat.format(Messages.getString(IMessageFormatKeys.INVALID_FIELD_VALUE), invalidAttrSb.toString()));
        }

        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, validationMessageSb.toString()));
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, validationMessageSb.toString());

      }
      else
      {
        bl001_VerifierDonneesReturn.setClientOperateur(_processContext.getxClientOperateur());
        bl001_VerifierDonneesReturn.setNoCompteSource(serviceMailTransfertRequest.getPortefeuilleServicesSource().getNoCompte());
        bl001_VerifierDonneesReturn.setNoCompteCible(serviceMailTransfertRequest.getPortefeuilleServicesCible().getNoCompte());
        bl001_VerifierDonneesReturn.setAdresseMailSource(serviceMailTransfertRequest.getIdentifiantAccesSource().getLoginMail());
        bl001_VerifierDonneesReturn.setAdresseMailCible(serviceMailTransfertRequest.getIdentifiantAccesCible().getLoginMail());
        bl001_VerifierDonneesReturn.setModeTransfert(serviceMailTransfertRequest.getModeTransfert());
      }

      factory.close();
    }

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, _processContext.getxClientOperateur());
    refFonc.put(IRefFoncConstants.NO_COMPTE, bl001_VerifierDonneesReturn.getNoCompteCible());

    BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder()//initialize builder
        .tracabilite(tracabilite_p)//set tracabilite
        .refFonc(refFonc) //set refFonc
        .build();
    bl1700.execute(this);

    bl001_VerifierDonneesReturn.setRetour(retour);
    return bl001_VerifierDonneesReturn;
  }

  /**
   * Format response to the client
   *
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @param inRetour
   *          Result of bl001.
   * @return {@link ReponseErreur}
   */
  @LogProcessBL
  private Pair<ReponseErreur, Retour> PE0145_BL002_FormaterReponse(Tracabilite tracabilite_p, Retour inRetour)
  {
    if (!RetourFactory.isRetourOK(inRetour))
    {
      ReponseErreur responseErreur = new ReponseErreur();
      responseErreur.setError(inRetour.getDiagnostic());
      responseErreur.setErrorDescription(inRetour.getLibelle());

      return new Pair<>(responseErreur, inRetour);
    }
    return new Pair<>(null, RetourFactory.createOkRetour());
  }

  /**
   * BL005
   *
   * @param tracabilite_p
   *          tracabilite
   * @param retour_p
   *          retour
   * @return retour ok
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Retour PE0145_BL005_GererErreurPROSPER(Tracabilite tracabilite_p, Retour retour_p) throws RavelException
  {
    return RetourFactory.createOkRetour();
  }

  /**
   *
   * @param clientOperateur_p
   *          Client operator holding the commercial portfolio to be reconciled
   * @param noCompteSource_p
   *          Identifier used by the client operator to designate the commercial portfolio that owns the source mailbox
   *          account
   * @param adresseMailSource_p
   *          The source email address
   * @param noCompteCible_p
   *          Identifier used by the client operator to designate the commercial portfolio that owns the target mailbox
   *          account
   * @param adresseMailCible_p
   *          Email address of the target mail account
   * @param tracabilite_p
   *          Tracabilite
   * @return BL100_PreparerTransfertContenuBoiteMailReturn
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  private PE0145_BL100_PreparerTransfertContenuBoiteMailReturn PE0145_BL100_PreparerTransfertContenuBoiteMail(Tracabilite tracabilite_p, String clientOperateur_p, String noCompteSource_p, String adresseMailSource_p, String noCompteCible_p, String adresseMailCible_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100Result = new PE0145_BL100_PreparerTransfertContenuBoiteMailReturn(retour);

    //Récupérer la liste des ST PFS MAIL du Pfi Source
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = RSTProxy.getInstance().serviceTechniqueLireTousParPfi(tracabilite_p, clientOperateur_p, noCompteSource_p, TYPE_ST_PFS, TYPE_ST_MAIL);

    if (RetourFactory.isRetourKO(rstResponse._first))
    {
      if (IMegConsts.CAT4.equals(rstResponse._first.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(rstResponse._first.getDiagnostic()))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(MESSAGE_MAIL_INCONNU, adresseMailSource_p, noCompteSource_p));
        bl100Result.setRetour(retour);

      }
      else
      {
        bl100Result.setRetour(rstResponse._first);

      }
      return bl100Result;
    }

    //Find ServiceTechnique de type PFS having addresse mail equal to adresseMailSource_p
    ServiceTechnique sTSource = null;
    StPfsMail stPfsMail = null;

    for (ServiceTechnique st : rstResponse._second)
    {
      stPfsMail = StPfsMail.class.cast(st);

      if ((stPfsMail != null) && (stPfsMail.getDonneesProvisionneesStPfsMail() != null) && StringTools.isNotNullOrEmpty(stPfsMail.getDonneesProvisionneesStPfsMail().getAdresseMail()) && stPfsMail.getDonneesProvisionneesStPfsMail().getAdresseMail().equals(adresseMailSource_p))
      {
        sTSource = st;
        break;
      }
    }

    if (sTSource == null)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(MESSAGE_MAIL_INCONNU, adresseMailSource_p, noCompteSource_p));
      bl100Result.setRetour(retour);
      return bl100Result;
    }
    if (!Statut.ACTIF.name().equals(sTSource.getStatut()))
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(MESSAGE_MAIL_INACTIF, adresseMailSource_p));
      bl100Result.setRetour(retour);
      return bl100Result;
    }
    if ((stPfsMail != null) && (stPfsMail.getDonneesIdentificationStPfsMail() != null))
    {
      bl100Result.setIdCompteMailSource(stPfsMail.getDonneesIdentificationStPfsMail().getIdCompteMail());
    }
    else
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.DONNEE_INDISPONIBLE, DONNEES_IDENTIFICATION_NULL);
      bl100Result.setRetour(retour);
      return bl100Result;
    }

    //Get list of ST PFS MAIL of Pfi Cible
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponseCible = RSTProxy.getInstance().serviceTechniqueLireTousParPfi(tracabilite_p, clientOperateur_p, noCompteCible_p, TYPE_ST_PFS, TYPE_ST_MAIL);

    if (RetourFactory.isRetourKO(rstResponseCible._first))
    {
      if (IMegConsts.CAT4.equals(rstResponseCible._first.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(rstResponseCible._first.getDiagnostic()))
      {
        retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(MESSAGE_MAIL_INCONNU, adresseMailCible_p, noCompteCible_p));
        bl100Result.setRetour(retour);
      }
      else
      {
        bl100Result.setRetour(rstResponseCible._first);
      }
      return bl100Result;
    }

    //Find ServiceTechnique de type PFS having mail equal to adresseMailCible_p
    ServiceTechnique sTCible = null;
    StPfsMail stPfsMailCible = null;

    for (ServiceTechnique st : rstResponseCible._second)
    {
      stPfsMailCible = StPfsMail.class.cast(st);

      if ((stPfsMailCible != null) && StringTools.isNotNullOrEmpty(stPfsMailCible.getDonneesProvisionneesStPfsMail().getAdresseMail()) && stPfsMailCible.getDonneesProvisionneesStPfsMail().getAdresseMail().equals(adresseMailCible_p))
      {
        sTCible = st;
        break;
      }
    }

    if (sTCible == null)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(MESSAGE_MAIL_INCONNU, adresseMailCible_p, noCompteCible_p));
      bl100Result.setRetour(retour);
      return bl100Result;
    }

    if (!Statut.ACTIF.name().equals(sTCible.getStatut()))
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(MESSAGE_MAIL_INACTIF, adresseMailCible_p));
      bl100Result.setRetour(retour);
      return bl100Result;
    }

    if ((stPfsMailCible != null) && (stPfsMailCible.getDonneesIdentificationStPfsMail() != null))
    {
      bl100Result.setIdCompteMailCible(stPfsMailCible.getDonneesIdentificationStPfsMail().getIdCompteMail());
    }
    else
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.DONNEE_INDISPONIBLE, DONNEES_IDENTIFICATION_NULL);
      bl100Result.setRetour(retour);
      return bl100Result;
    }

    return bl100Result;
  }

  /**
   * send a sync response for requester.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param request_p
   *          The request object
   * @param reponserreur_p
   *          the reponserreur
   */
  private void syncResponse(Tracabilite tracabilite_p, Request request_p, ReponseErreur reponserreur_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp;
      ErrorCode errorCode;

      if (reponserreur_p != null)
      {
        ravelResponse.setDataType("application/json"); //$NON-NLS-1$
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponserreur_p));

        switch (reponserreur_p.getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.MAIL_INCONNU:
          case IMegSpiritConsts.NO_COMPTE_INCONNU:
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.PFS_INDISPO:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        rsp = new Response(errorCode, ravelResponse);
      }

      else
      {
        //Add empty Json in case OK
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(""); //$NON-NLS-1$
        rsp = new Response(ErrorCode.OK_00204, ravelResponse);
      }

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PE0145 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);
    }
  }
}