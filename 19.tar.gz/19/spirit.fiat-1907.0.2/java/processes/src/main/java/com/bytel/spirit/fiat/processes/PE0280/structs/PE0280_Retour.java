/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0280.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptiqueResponse;
import com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_Fibre;
import com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_PositionPM;
import com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_StiRouteOptique;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author mfreire
 * @version ($Revision$ $Date$)
 */
public class PE0280_Retour implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 2524824274666261151L;

  /**
   * Mapping between PE0280_Retour and MAJRouteOptiqueResponse
   *
   * @param majRouteOptiqueResponse_p
   *          majRouteOptiqueResponse
   * @return
   *
   */

  public static PE0280_Retour initFromMAJRouteOptiqueResponse(MAJRouteOptiqueResponse majRouteOptiqueResponse_p)
  {
    PE0280_Retour pe0280 = new PE0280_Retour();
    pe0280.setNumeroDecharge(majRouteOptiqueResponse_p.getNumeroDecharge());

    List<PE0280_StiRouteOptique> listeRouteOptique = new ArrayList<>();
    PE0280_StiRouteOptique routeOptique = null;
    for (com.bytel.spirit.common.connector.oi.emutation.structs.RouteOptique routeOptiqueOI : majRouteOptiqueResponse_p.getRoutesOptiques())
    {
      routeOptique = new PE0280_StiRouteOptique();
      routeOptique.setOc(routeOptiqueOI.getOc());
      routeOptique.setPositionPM(new PE0280_PositionPM(routeOptiqueOI.getPositionPM()));
      routeOptique.setFibre(new PE0280_Fibre(StringConstants.EMPTY_STRING, routeOptiqueOI.getReferenceCablePBO(), routeOptiqueOI.getInformationTubePBO(), routeOptiqueOI.getInformationFibrePBO(), StringConstants.EMPTY_STRING, majRouteOptiqueResponse_p.getReferencePrise()));
      routeOptique.setConnecteurPriseNumero(routeOptiqueOI.getConnecteurPriseNumero());
      routeOptique.setConnecteurPriseCouleur(routeOptiqueOI.getConnecteurPriseCouleur());

      listeRouteOptique.add(routeOptique);
    }

    pe0280.setRoutesOptiques(listeRouteOptique);
    pe0280.setReferencePM(majRouteOptiqueResponse_p.getReferencePM());
    pe0280.setReferencePMT(majRouteOptiqueResponse_p.getReferencePMT());
    pe0280.setReferencePBO(majRouteOptiqueResponse_p.getReferencePBO());

    return pe0280;
  }

  /** The numeroDecharge. */
  @SerializedName("numeroDeCharge")
  @Expose
  private String _numeroDecharge;
  /** The routesOptiques. */
  @SerializedName("listeRouteOptique")
  @Expose
  private List<PE0280_StiRouteOptique> _routesOptiques;

  /** The referencePM. */
  @SerializedName("ReferencePM")
  @Expose
  private String _referencePM;

  /** The referencePMT. */
  @SerializedName("ReferencePMT")
  @Expose
  private String _referencePMT;

  /** The referencePBO. */
  @SerializedName("ReferencePBO")
  @Expose
  private String _referencePBO;

  /**
   * @return the numeroDecharge
   */
  public String getNumeroDecharge()
  {
    return _numeroDecharge;
  }

  /**
   * @return the referencePBO
   */
  public String getReferencePBO()
  {
    return _referencePBO;
  }

  /**
   * @return the referencePM
   */
  public String getReferencePM()
  {
    return _referencePM;
  }

  /**
   * @return the referencePMT
   */
  public String getReferencePMT()
  {
    return _referencePMT;
  }

  /**
   * @return the routesOptiques
   */
  public List<PE0280_StiRouteOptique> getRoutesOptiques()
  {
    if (_routesOptiques != null)
    {
      return new ArrayList<>(_routesOptiques);
    }
    return null;
  }

  /**
   * @param numeroDecharge_p
   *          the numeroDecharge to set
   */
  public void setNumeroDecharge(String numeroDecharge_p)
  {
    _numeroDecharge = numeroDecharge_p;
  }

  /**
   * @param referencePBO_p
   *          the referencePBO to set
   */
  public void setReferencePBO(String referencePBO_p)
  {
    _referencePBO = referencePBO_p;
  }

  /**
   * @param referencePM_p
   *          the referencePM to set
   */
  public void setReferencePM(String referencePM_p)
  {
    _referencePM = referencePM_p;
  }

  /**
   * @param referencePMT_p
   *          the referencePMT to set
   */
  public void setReferencePMT(String referencePMT_p)
  {
    _referencePMT = referencePMT_p;
  }

  /**
   * @param routesOptiques_p
   *          the routesOptiques to set
   */
  public void setRoutesOptiques(List<PE0280_StiRouteOptique> routesOptiques_p)
  {
    if (routesOptiques_p != null)
    {
      _routesOptiques = new ArrayList<>(routesOptiques_p);
    }
    else
    {
      _routesOptiques = null;

    }
  }
}
