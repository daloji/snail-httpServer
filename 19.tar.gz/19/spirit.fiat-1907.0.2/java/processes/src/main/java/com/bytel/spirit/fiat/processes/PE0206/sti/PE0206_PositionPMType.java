/*******************************************************************************
* $Id: PE0206_PositionPMType.java 14745 2018-12-17 14:04:01Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206.sti;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 14745 $ $Date: 2018-12-17 15:04:01 +0100 (lun., 17 déc. 2018) $)
 */
public class PE0206_PositionPMType implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * NomModulePM
   */
  @SerializedName("NomModulePM")
  @Expose
  private String _nomModulePM;

  /**
   * PositionModulePM
   */
  @SerializedName("PositionModulePM")
  @Expose
  private String _positionModulePM;

  /**
   * ReferenceCablePM
   */
  @SerializedName("ReferenceCableModulePM")
  @Expose
  private String _referenceCableModulePM;

  /**
   * InfoTubeModulePM
   */
  @SerializedName("InfoTubeModulePM")
  @Expose
  private String _infoTubeModulePM;

  /**
   * InfoTubeModulePM
   */
  @SerializedName("InfoFibreModulePM")
  @Expose
  private String _infoFibreModulePM;

  /**
   * @return the infoFibreModulePM
   */
  public String getInfoFibreModulePM()
  {
    return _infoFibreModulePM;
  }

  /**
   * @return the infoTubeModulePM
   */
  public String getInfoTubeModulePM()
  {
    return _infoTubeModulePM;
  }

  /**
   * @return the nomModulePM
   */
  public String getNomModulePM()
  {
    return _nomModulePM;
  }

  /**
   * @return the positionModulePM
   */
  public String getPositionModulePM()
  {
    return _positionModulePM;
  }

  /**
   * @return the referenceCableModulePM
   */
  public String getReferenceCableModulePM()
  {
    return _referenceCableModulePM;
  }

  /**
   * @param infoFibreModulePM_p
   *          the infoFibreModulePM to set
   */
  public void setInfoFibreModulePM(String infoFibreModulePM_p)
  {
    _infoFibreModulePM = infoFibreModulePM_p;
  }

  /**
   * @param infoTubeModulePM_p
   *          the infoTubeModulePM to set
   */
  public void setInfoTubeModulePM(String infoTubeModulePM_p)
  {
    _infoTubeModulePM = infoTubeModulePM_p;
  }

  /**
   * @param nomModulePM_p
   *          the nomModulePM to set
   */
  public void setNomModulePM(String nomModulePM_p)
  {
    _nomModulePM = nomModulePM_p;
  }

  /**
   * @param positionModulePM_p
   *          the positionModulePM to set
   */
  public void setPositionModulePM(String positionModulePM_p)
  {
    _positionModulePM = positionModulePM_p;
  }

  /**
   * @param referenceCableModulePM_p
   *          the referenceCableModulePM to set
   */
  public void setReferenceCableModulePM(String referenceCableModulePM_p)
  {
    _referenceCableModulePM = referenceCableModulePM_p;
  }

}
