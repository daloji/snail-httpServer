/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0275.structs;

/**
 *
 * @author vloureir
 * @version ($Revision$ $Date$)
 */
public enum OperationMessage
{

  LISTER_MESSAGE("listerMessage"), // //$NON-NLS-1$
  TELECHARGER_MESSAGE("telechargerMessage"), // //$NON-NLS-1$
  MODIFIER_STATUT_MESSAGE("modifierStatutMessage"), // //$NON-NLS-1$
  SUPPRIMER_MESSAGE("supprimerMessage"), // //$NON-NLS-1$
  DEPOSER_MESSAGE("deposerMessage"); //$NON-NLS-1$

  /**
   * Value
   */
  private final String _value;

  /**
   * Default constructor
   *
   * @param value
   */
  OperationMessage(String value)
  {
    this._value = value;
  }

  /**
   * Get value
   *
   * @return
   */
  public String getValue()
  {
    return this._value;
  }

}
