/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0221.structs;

import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.fiat.processes.PE0221.structs.types.Appel;
import com.bytel.spirit.fiat.processes.structs.XItem;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PE0221_GetResponse extends XItem
{
  /**
   * Serial UID
   */
  private static final long serialVersionUID = -1089605937854997330L;

  /**
  *
  */
  @SerializedName("nombreAppelsEnAbsence")
  @Expose
  private int _nombreAppelsEnAbsence;

  /**
  *
  */
  @SerializedName("nombreAppelsRecu")
  @Expose
  private int _nombreAppelsRecu;

  /**
  *
  */
  @SerializedName("nombreAppelsEmis")
  @Expose
  private int _nombreAppelsEmis;

  /**
  *
  */
  @SerializedName("appels")
  @Expose
  private List<Appel> _appels;

  @Override
  public boolean equals(Object obj)
  {
    if (obj == null)
    {
      return false;
    }

    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0221_GetResponse other = (PE0221_GetResponse) obj;
    if (_appels == null)
    {
      if (other._appels != null)
      {
        return false;
      }
    }
    else if (!_appels.equals(other._appels))
    {
      return false;
    }
    if (_nombreAppelsEmis != other._nombreAppelsEmis)
    {
      return false;
    }
    if (_nombreAppelsEnAbsence != other._nombreAppelsEnAbsence)
    {
      return false;
    }
    if (_nombreAppelsRecu != other._nombreAppelsRecu)
    {
      return false;
    }
    return true;
  }

  /**
   * @return the appels
   */
  public List<Appel> getAppels()
  {
    return _appels != null ? new ArrayList<>(_appels) : new ArrayList<>();
  }

  /**
   * @return the nombreAppelsEmis
   */
  public int getNombreAppelsEmis()
  {
    return _nombreAppelsEmis;
  }

  /**
   * @return the nombreAppelsEnAbsence
   */
  public int getNombreAppelsEnAbsence()
  {
    return _nombreAppelsEnAbsence;
  }

  /**
   * @return the nombreAppelsRecu
   */
  public int getNombreAppelsRecu()
  {
    return _nombreAppelsRecu;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_appels == null) ? 0 : _appels.hashCode());
    result = (prime * result) + _nombreAppelsEmis;
    result = (prime * result) + _nombreAppelsEnAbsence;
    result = (prime * result) + _nombreAppelsRecu;
    return result;
  }

  /**
   * @param appels_p
   *          the appels to set
   */
  public void setAppels(List<Appel> appels_p)
  {
    _appels = appels_p != null ? new ArrayList<>(appels_p) : new ArrayList<>();
  }

  /**
   * @param nombreAppelsEmis_p
   *          the nombreAppelsEmis to set
   */
  public void setNombreAppelsEmis(int nombreAppelsEmis_p)
  {
    _nombreAppelsEmis = nombreAppelsEmis_p;
  }

  /**
   * @param nombreAppelsEnAbsence_p
   *          the nombreAppelsEnAbsence to set
   */
  public void setNombreAppelsEnAbsence(int nombreAppelsEnAbsence_p)
  {
    _nombreAppelsEnAbsence = nombreAppelsEnAbsence_p;
  }

  /**
   * @param nombreAppelsRecu_p
   *          the nombreAppelsRecu to set
   */
  public void setNombreAppelsRecu(int nombreAppelsRecu_p)
  {
    _nombreAppelsRecu = nombreAppelsRecu_p;
  }

  @Override
  public String toString()
  {
    return "PE0221_GetResponse [_nombreAppelsEnAbsence=" + _nombreAppelsEnAbsence + ", _nombreAppelsRecu=" + _nombreAppelsRecu + ", _nombreAppelsEmis=" + _nombreAppelsEmis + ", _appels=" + _appels + "]";
  }

}
