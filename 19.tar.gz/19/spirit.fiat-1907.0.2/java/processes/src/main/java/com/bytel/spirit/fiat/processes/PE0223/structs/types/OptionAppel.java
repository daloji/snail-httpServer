/*******************************************************************************
 * $Id: OptionAppel.java 9946 2018-09-07 12:07:40Z jiantila $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223.structs.types;

import com.bytel.spirit.fiat.processes.structs.XItem;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 9946 $ $Date: 2018-09-07 14:07:40 +0200 (Fri, 07 Sep 2018) $)
 */
public class OptionAppel extends XItem
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * id
   */
  @SerializedName("idOptionAppel")
  @Expose
  private String _idOptionAppel;

  /**
   * noTelephone
   */
  @SerializedName("noTelephone")
  @Expose
  private String _noTelephone;

  /**
   * status
   */
  @SerializedName("statut")
  @Expose
  private String _statut;

  /**
   * type
   */
  @SerializedName("type")
  @Expose
  private String _type;

  /**
   * mode renvoi
   */
  @SerializedName("modeRenvoi")
  @Expose
  private String _modeRenvoi;

  /**
   * mode renvoi
   */
  @SerializedName("numeroRenvoi")
  @Expose
  private String _numeroRenvoi;

  /**
   * nombre sonnerie
   */
  @SerializedName("nombreSonneries")
  @Expose
  private String _nombreSonneries;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    OptionAppel other = (OptionAppel) obj;
    if (_idOptionAppel == null)
    {
      if (other._idOptionAppel != null)
      {
        return false;
      }
    }
    else if (!_idOptionAppel.equals(other._idOptionAppel))
    {
      return false;
    }
    if (_modeRenvoi == null)
    {
      if (other._modeRenvoi != null)
      {
        return false;
      }
    }
    else if (!_modeRenvoi.equals(other._modeRenvoi))
    {
      return false;
    }
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    if (_nombreSonneries == null)
    {
      if (other._nombreSonneries != null)
      {
        return false;
      }
    }
    else if (!_nombreSonneries.equals(other._nombreSonneries))
    {
      return false;
    }
    if (_numeroRenvoi == null)
    {
      if (other._numeroRenvoi != null)
      {
        return false;
      }
    }
    else if (!_numeroRenvoi.equals(other._numeroRenvoi))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    if (_type == null)
    {
      if (other._type != null)
      {
        return false;
      }
    }
    else if (!_type.equals(other._type))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the idOptionAppel
   */
  public String getIdOptionAppel()
  {
    return _idOptionAppel;
  }

  /**
   * @return the modeRenvoi
   */
  public String getModeRenvoi()
  {
    return _modeRenvoi;
  }

  /**
   * @return the nombreSonneries
   */
  public String getNombreSonneries()
  {
    return _nombreSonneries;
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the numeroRenvoi
   */
  public String getNumeroRenvoi()
  {
    return _numeroRenvoi;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the type
   */
  public String getType()
  {
    return _type;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_idOptionAppel == null) ? 0 : _idOptionAppel.hashCode());
    result = (prime * result) + ((_modeRenvoi == null) ? 0 : _modeRenvoi.hashCode());
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    result = (prime * result) + ((_nombreSonneries == null) ? 0 : _nombreSonneries.hashCode());
    result = (prime * result) + ((_numeroRenvoi == null) ? 0 : _numeroRenvoi.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    result = (prime * result) + ((_type == null) ? 0 : _type.hashCode());
    return result;
  }

  /**
   * @param idOptionAppel_p
   *          the idOptionAppel to set
   */
  public void setIdOptionAppel(String idOptionAppel_p)
  {
    _idOptionAppel = idOptionAppel_p;
  }

  /**
   * @param modeRenvoi_p
   *          the modeRenvoi to set
   */
  public void setModeRenvoi(String modeRenvoi_p)
  {
    _modeRenvoi = modeRenvoi_p;
  }

  /**
   * @param nombreSonneries_p
   *          the nombreSonneries to set
   */
  public void setNombreSonneries(String nombreSonneries_p)
  {
    _nombreSonneries = nombreSonneries_p;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param numeroRenvoi_p
   *          the numeroRenvoi to set
   */
  public void setNumeroRenvoi(String numeroRenvoi_p)
  {
    _numeroRenvoi = numeroRenvoi_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param type_p
   *          the type to set
   */
  public void setType(String type_p)
  {
    _type = type_p;
  }

  @Override
  public String toString()
  {
    return "OptionAppel [_idOptionAppel=" + _idOptionAppel + ", _noTelephone=" + _noTelephone + ", _statut=" + _statut + ", _type=" + _type + ", _modeRenvoi=" + _modeRenvoi + ", _numeroRenvoi=" + _numeroRenvoi + ", _nombreSonneries=" + _nombreSonneries + "]";
  }

}
