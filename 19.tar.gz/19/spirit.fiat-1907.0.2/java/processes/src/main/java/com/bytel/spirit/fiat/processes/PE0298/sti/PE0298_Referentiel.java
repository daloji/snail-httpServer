/*******************************************************************************
* $Id: PE0298_Referentiel.java 16144 2019-01-22 10:53:19Z jsantos $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0298.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.squareup.moshi.Json;

/**
 *
 * @author kbettenc
 * @version ($Revision: 16144 $ $Date: 2019-01-22 11:53:19 +0100 (mar. 22 janv. 2019) $)
 */
public class PE0298_Referentiel implements Serializable
{
  /**
   *
   * EtatProvisionning
   *
   */
  public enum EtatProvisionning
  {
    /**
     * REALISE
     */
    REALISE,
    /**
     * ECHEC
     */
    ECHEC,
    /**
     * EN_COURS
     */
    EN_COURS;
  }

  /**
   *
   * TypeService
   */
  public enum TypeService
  {
    /**
     * MESSAGERIE
     */
    MESSAGERIE;
  }

  /**
   *
   */
  private static final long serialVersionUID = -5441045790599865954L;

  @Json(name = "typeService")
  private String _typeService;

  @Json(name = "noTelephone")
  private String _noTelephone;

  @Json(name = "ressources")
  private List<PE0298_Ressource> _ressources;

  @Json(name = "typeMessagerie")
  private String _typeMessagerie;

  @Json(name = "etatProvisioning")
  private String _etatProvisioning;

  @Json(name = "audits")
  private List<PE0298_Audit> _audits;

  @Json(name = "erreurs")
  private List<PE0298_Erreur> _erreurs;

  private transient List<ServiceTechnique> _listeST;

  /**
   *
   */
  public PE0298_Referentiel()
  {
    //empty constructor
  }

  /**
   * @param audit_p
   *          the audit to add
   */
  public void addAudit(PE0298_Audit audit_p)
  {
    if (_audits == null)
    {
      _audits = new ArrayList<>();
    }
    _audits.add(audit_p);
  }

  /**
   * @param erreur_p
   *          the erreur to add
   */
  public void addErreur(PE0298_Erreur erreur_p)
  {
    if (_erreurs == null)
    {
      _erreurs = new ArrayList<>();
    }
    _erreurs.add(erreur_p);
  }

  /**
   * @param ressource_p
   *          the ressource to add
   */
  public void addRessource(PE0298_Ressource ressource_p)
  {
    if (_ressources == null)
    {
      _ressources = new ArrayList<>();
    }
    _ressources.add(ressource_p);
  }

  /**
   * @param serviceTechnique_p
   *          the audit to add
   */
  public void addST(ServiceTechnique serviceTechnique_p)
  {
    if (_listeST == null)
    {
      _listeST = new ArrayList<>();
    }
    _listeST.add(serviceTechnique_p);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0298_Referentiel other = (PE0298_Referentiel) obj;
    if (_audits == null)
    {
      if (other._audits != null)
      {
        return false;
      }
    }
    else if (!_audits.equals(other._audits))
    {
      return false;
    }
    if (_erreurs == null)
    {
      if (other._erreurs != null)
      {
        return false;
      }
    }
    else if (!_erreurs.equals(other._erreurs))
    {
      return false;
    }
    if (_etatProvisioning == null)
    {
      if (other._etatProvisioning != null)
      {
        return false;
      }
    }
    else if (!_etatProvisioning.equals(other._etatProvisioning))
    {
      return false;
    }
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    if (_ressources == null)
    {
      if (other._ressources != null)
      {
        return false;
      }
    }
    else if (!_ressources.equals(other._ressources))
    {
      return false;
    }
    if (_typeMessagerie == null)
    {
      if (other._typeMessagerie != null)
      {
        return false;
      }
    }
    else if (!_typeMessagerie.equals(other._typeMessagerie))
    {
      return false;
    }
    if (_typeService == null)
    {
      if (other._typeService != null)
      {
        return false;
      }
    }
    else if (!_typeService.equals(other._typeService))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the audits
   */
  public List<PE0298_Audit> getAudits()
  {
    return _audits != null ? new ArrayList<>(_audits) : new ArrayList<>();
  }

  /**
   * @return the erreurs
   */
  public List<PE0298_Erreur> getErreurs()
  {
    return _erreurs != null ? new ArrayList<>(_erreurs) : new ArrayList<>();
  }

  /**
   * @return the etatProvisioning
   */
  public String getEtatProvisioning()
  {
    return _etatProvisioning;
  }

  /**
   * @return the listeST
   */
  public List<ServiceTechnique> getListeST()
  {
    return _listeST != null ? new ArrayList<>(_listeST) : new ArrayList<>();
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the ressources
   */
  public List<PE0298_Ressource> getRessources()
  {
    return _ressources != null ? new ArrayList<>(_ressources) : new ArrayList<>();
  }

  /**
   * @return the typeMessagerie
   */
  public String getTypeMessagerie()
  {
    return _typeMessagerie;
  }

  /**
   * @return the typeService
   */
  public String getTypeService()
  {
    return _typeService;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_audits == null) ? 0 : _audits.hashCode());
    result = (prime * result) + ((_erreurs == null) ? 0 : _erreurs.hashCode());
    result = (prime * result) + ((_etatProvisioning == null) ? 0 : _etatProvisioning.hashCode());
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    result = (prime * result) + ((_ressources == null) ? 0 : _ressources.hashCode());
    result = (prime * result) + ((_typeMessagerie == null) ? 0 : _typeMessagerie.hashCode());
    result = (prime * result) + ((_typeService == null) ? 0 : _typeService.hashCode());
    return result;
  }

  /**
   * @param audits_p
   *          the audits to set
   */
  public void setAudits(List<PE0298_Audit> audits_p)
  {
    _audits = audits_p != null ? new ArrayList<>(audits_p) : new ArrayList<>();
  }

  /**
   * @param erreurs_p
   *          the erreurs to set
   */
  public void setErreurs(List<PE0298_Erreur> erreurs_p)
  {
    _erreurs = erreurs_p != null ? new ArrayList<>(erreurs_p) : new ArrayList<>();
  }

  /**
   * @param etatProvisioning_p
   *          the etatProvisioning to set
   */
  public void setEtatProvisioning(String etatProvisioning_p)
  {
    _etatProvisioning = etatProvisioning_p;
  }

  /**
   * @param listeST_p
   *          the listeST to set
   */
  public void setListeST(List<ServiceTechnique> listeST_p)
  {
    _listeST = listeST_p != null ? new ArrayList<>(listeST_p) : new ArrayList<>();
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param ressources_p
   *          the ressources to set
   */
  public void setRessources(List<PE0298_Ressource> ressources_p)
  {
    _ressources = ressources_p != null ? new ArrayList<>(ressources_p) : new ArrayList<>();
  }

  /**
   * @param typeMessagerie_p
   *          the typeMessagerie to set
   */
  public void setTypeMessagerie(String typeMessagerie_p)
  {
    _typeMessagerie = typeMessagerie_p;
  }

  /**
   * @param typeService_p
   *          the typeService to set
   */
  public void setTypeService(String typeService_p)
  {
    _typeService = typeService_p;
  }

}
