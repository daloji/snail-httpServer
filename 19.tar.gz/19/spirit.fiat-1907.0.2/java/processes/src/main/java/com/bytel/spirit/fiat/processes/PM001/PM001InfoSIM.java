/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PM001;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.common.utils.StringTools.PaddingDirection;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogContinueProcess;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.connectors.gdr.GDRProxy;
import com.bytel.spirit.common.connectors.gdr.InfoSIM;
import com.bytel.spirit.common.connectors.gdr.ReturnCode;
import com.bytel.spirit.common.connectors.gdr.TypeCardDescription;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.generated.infosim.Activable;
import com.bytel.spirit.fiat.processes.generated.infosim.CodeRetour;
import com.bytel.spirit.fiat.processes.generated.infosim.DonneesFonctionnelles;
import com.bytel.spirit.fiat.processes.generated.infosim.IdentificationSim;
import com.bytel.spirit.fiat.processes.generated.infosim.InfoSimIn;
import com.bytel.spirit.fiat.processes.generated.infosim.InfoSimOut;
import com.bytel.spirit.fiat.processes.generated.infosim.InformationsSim;
import com.bytel.spirit.fiat.processes.generated.infosim.LibelleTypeCarte;
import com.bytel.spirit.fiat.processes.generated.infosim.ReponseTechnique;

/**
 * Searches for SIM card information based on a list of IMSIs and ICCIDs
 *
 * @author $Author$
 * @version ($Revision: 27166 $ $Date$)
 */
public class PM001InfoSIM extends SpiritProcessSkeleton
{

  /**
   * The enumeration to input Parameters Url
   *
   * @author $author$
   * @version ($Revision$ $Date$)
   */
  public enum ParameterUrl
  {
    /**
     * Username ST / SST caller.
     */
    idAppelant,

    /**
     * Consultation identifier Flow
     */
    idFlux
  }

  /**
   * PM001 states
   *
   */
  private enum State
  {
    /**
     * The next step to execute is:
     */
    PM001_BL001(MandatoryProcessState.PRC_START),

    /**
     * Step to call
     */
    PM001_BL100(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
     *
     */
    PM001_BL002(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Default constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    private State(MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    private State(MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * Holds context data for PM001_InfoSIMC
   *
   */
  static class PM001InfoSIMContext extends Context
  {
    /**
     * The Generated UID.
     */
    private static final long serialVersionUID = 7327972369600353770L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    State _state = State.PM001_BL001;

    /**
     * GDR connector ID.
     */
    String _gdrConnectorId;

    /**
     * The idAppelant.
     */
    String _idAppelant;

    /**
     * The idFlux.
     */
    String _idFlux;

    /**
     * continueProcess input data.
     */
    Request _continueProcess_request;

    /**
     * Information for the SIM obtained from a search by IMSI or ICCID
     */
    List<InformationsSim> _informationsSims;

    /**
     * String with the regular expression define in the configuration file for Imsi
     */
    String _patternImsi;

    /**
     * String with the regular expression define in the configuration file for Iccid
     */
    String _patternIccid;

    /**
     * Regular expression to validate the Imsi
     */
    Pattern _regexImsi;

    /**
     * Regular expression to validate the Iccid
     */
    Pattern _regexIccid;

    /**
     * The request made asking for info based on a IMSI or ICCID
     */
    InfoSimIn _infoSimRequestIn;

    /**
     * The tracability
     */
    Tracabilite _tracabilite;
  }

  /**
   *
   */
  public static final String CODE_ERREUR_BDD_KO = "2100";

  /**
   * Process name constant.
   */
  private static final String PROCESS_NAME = "PM001_InfoSIM"; //$NON-NLS-1$

  /**
   * Unique UID for the current context class
   */
  private static final long serialVersionUID = 724201403982111054L;

  /**
   * PATTERN_IMSI parameter name on the process configuration file, for a validation regular expression
   */
  private static final String PATTERN_IMSI = "PatternImsi"; //$NON-NLS-1$

  /**
   * PATTERN_ICCID parameter name on the process configuration file, for a validation regular expression
   */
  private static final String PATTERN_ICCID = "PatternIccid"; //$NON-NLS-1$

  /**
   * ID for the GDR connector
   */
  private static final String GDR_CONNECTOR_ID = "GDRConnectorId"; //$NON-NLS-1$

  /**
   * The process' context.
   */
  PM001InfoSIMContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return ""; //$NON-NLS-1$
  }

  @Override
  public String getInternalState()
  {
    return _processContext._state.toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext._state._technicalState;
  }

  @Override
  public void initializeContext()
  {
    // Initialization of the context cannot be done in the constructor
    // because
    // processes are allocated only at startup and cloned when a new process
    // is expected.
    _processContext = new PM001InfoSIMContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext._state._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext._state._replayableState;
  }

  @Override
  @LogContinueProcess
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    // TODO Auto-generated method stub
  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    getUrlparametersIntoProcessContext(request_p);

    getPayloadFromrequest(request_p);

    //log INFO
    SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.INFO, tracabilite_p, PROCESS_NAME);
    logEvent.addField(ParameterUrl.idAppelant.name(), _processContext._idAppelant, false);
    logEvent.addField(ParameterUrl.idFlux.name(), _processContext._idFlux, false);
    RavelLogger.log(logEvent);

    _processContext._tracabilite = tracabilite_p;

    if (!checkParams(request_p))
    {
      return;
    }

    ArrayList<InformationsSim> infoSimList = null;

    infoSimList = new ArrayList<InformationsSim>();
    _processContext._state = State.PM001_BL100;

    ConnectorResponse<InfoSIM, Retour> connectorResponse = null;

    try
    {
      for (IdentificationSim identificationSim : this._processContext._infoSimRequestIn.getIdenficationSims())
      {
        if (identificationSim.getIccid() != null)
        {
          if (this.checkIccid(identificationSim.getIccid())._first)
          {
            connectorResponse = GDRProxy.getInstance().rechercheInformationsICCID(tracabilite_p, identificationSim.getIccid());
            if (connectorResponse._first != null)
            {
              infoSimList.add(this.mapGDRInformationsSimToProcess(connectorResponse._first));
            }
            else
            {
              infoSimList.add(this.iccidNotFound(identificationSim.getIccid()));
            }
          }
          else
          {
            infoSimList.add(this.iccidInvalid(identificationSim.getIccid()));
          }
        }

        if (identificationSim.getImsi() != null)
        {
          if (this.checkImsi(identificationSim.getImsi())._first)
          {

            connectorResponse = GDRProxy.getInstance().rechercheInformationsIMSI(tracabilite_p, identificationSim.getImsi());
            if (connectorResponse._first != null)
            {
              infoSimList.add(this.mapGDRInformationsSimToProcess(connectorResponse._first));
            }
            else
            {
              infoSimList.add(this.imsiNotFound(identificationSim.getImsi()));
            }
          }
          else
          {
            infoSimList.add(this.imsiInvalid(identificationSim.getImsi()));
          }
        }
      }

      if (connectorResponse != null)
      {
        setRetour(connectorResponse._second);
      }
    }
    catch (RavelException ravelException) //if exception during database access
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, ravelException.getMessage()));

      ReponseTechnique reponseTechnique = new ReponseTechnique();
      reponseTechnique.setCodeErreur(CODE_ERREUR_BDD_KO);
      reponseTechnique.setCodeRetourPrincipal(CodeRetour.NOK);
      reponseTechnique.setLibelleErreur(ravelException.getMessage());
      retourSynchrone(request_p, reponseTechnique);
      return;
    }
    terminateProcess(request_p, infoSimList);
    return;
  }

  /**
   * @param iccid_p
   *          Iccid to check
   * @return true if Iccid is valid, false otherwise
   * @throws RavelException
   *           error thrown
   */
  private Pair<Boolean, String> checkIccid(Long iccid_p) throws RavelException
  {
    Pair<Boolean, String> ret = new Pair<Boolean, String>(true, StringConstants.EMPTY_STRING);

    if (iccid_p != null)
    {
      if (_processContext._regexIccid.matcher(iccid_p.toString()).matches() == false)
      {
        String message = MessageFormat.format(Messages.getString("PM001_InfoSIM.InvalidICCID"), iccid_p, PATTERN_ICCID); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext._tracabilite, message));
        ret._first = false;
        ret._second = message;
      }
    }
    return ret;
  }

  /**
   * @param imsi_p
   *          Imsi to check
   * @return true if Imsi is valid, false otherwise with error message attached
   * @throws RavelException
   *           error thrown
   */
  private Pair<Boolean, String> checkImsi(Long imsi_p) throws RavelException
  {
    Pair<Boolean, String> ret = new Pair<Boolean, String>(true, StringConstants.EMPTY_STRING);
    if (imsi_p != null)
    {
      if (_processContext._regexImsi.matcher(imsi_p.toString()).matches() == false)
      {
        String message = MessageFormat.format(Messages.getString("PM001_InfoSIM.InvalidIMSI"), imsi_p, PATTERN_IMSI); //$NON-NLS-1$
        RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext._tracabilite, message));
        ret._first = false;
        ret._second = message;
      }
    }

    return ret;
  }

  /**
   * Check if a parameter is missing from the process configuration
   *
   * @param request_p
   *          fill the request.Response with error if parameter is missing
   * @param paramName_p
   *          the parameter to test
   * @return the parameter value, or null if not present
   * @throws RavelException
   *           on response marshaling
   */
  private String checkParam(Request request_p, String paramName_p) throws RavelException
  {
    String paramValue = getConfigParameter(paramName_p);

    if (paramValue == null)
    {
      String message = MessageFormat.format(Messages.getString("PM001_InfoSIM.ParameterMissing"), paramName_p); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, _processContext._tracabilite, message));
      returnNOK(request_p, IMegConsts.CAT1, IMegConsts.CONFIGURATION_INVALIDE, message);
    }
    return paramValue;
  }

  /**
   * Check the parameters in the request and in the configuration file.
   *
   * @param request_p
   *          The input request.
   * @return true if the parameters are OK.
   * @throws RavelException
   *           on ravel errors.
   */
  private boolean checkParams(Request request_p) throws RavelException
  {
    _processContext._patternImsi = checkParam(request_p, PATTERN_IMSI);
    if (_processContext._patternImsi == null)
    {
      return false;
    }

    _processContext._patternIccid = checkParam(request_p, PATTERN_ICCID);
    if (_processContext._patternIccid == null)
    {
      return false;
    }

    _processContext._gdrConnectorId = checkParam(request_p, GDR_CONNECTOR_ID);
    if (_processContext._gdrConnectorId == null)
    {
      return false;
    }
    // compiles the regular expressions objects
    _processContext._regexImsi = Pattern.compile(_processContext._patternImsi);
    _processContext._regexIccid = Pattern.compile(_processContext._patternIccid);

    return true;
  }

  /**
   * @param request_p
   *          Request
   * @throws RavelException
   *           on error
   */
  private void getPayloadFromrequest(Request request_p) throws RavelException
  {
    String payloadWithoutXmlHeader = request_p.getPayload().replaceAll("\\<\\?xml(.+?)\\?\\>", StringConstants.EMPTY_STRING).trim(); //$NON-NLS-1$
    _processContext._infoSimRequestIn = MarshallTools.unmarshall(InfoSimIn.class, payloadWithoutXmlHeader);
  }

  /**
   * Gets the URL parameters into the ProcessContext
   *
   * @param request_p
   *          request
   */
  private void getUrlparametersIntoProcessContext(Request request_p)
  {
    // get url parameters
    List<Parameter> urlParametersType = request_p.getUrlParameters().getUrlParameters();

    // idAppelant and idFlux are mandatory.
    for (Parameter parameter : urlParametersType)
    {
      if (parameter.getName().equalsIgnoreCase(ParameterUrl.idAppelant.name()))
      {
        _processContext._idAppelant = parameter.getValue();
        continue;
      }

      if (parameter.getName().equalsIgnoreCase(ParameterUrl.idFlux.name()))
      {
        _processContext._idFlux = parameter.getValue();
        continue;
      }
    }

  }

  /**
   * Return object for when the ICCID is invalid
   *
   * @param iccid_p
   *          the invalid ICCID
   * @return object to be returned
   */
  private InformationsSim iccidInvalid(Long iccid_p)
  {
    InformationsSim informationsSim = new InformationsSim();
    informationsSim.setIccid(iccid_p);
    informationsSim.setCodeRetourSecondaire(CodeRetour.NOK);
    informationsSim.setCodeErreur(ConstantesRetour.CODE_RETOUR_ICCID_FORMAT_INCORRECT);
    informationsSim.setLibelleErreur(MessageFormat.format(ConstantesRetour.LIBELLE_RETOUR_ICCID_FORMAT_INCORRECT, iccid_p));
    return informationsSim;
  }

  /**
   * Return object for when the ICCID is nout found
   *
   * @param iccid_p
   *          the ICCID that was nout found
   * @return object to be returned
   */
  private InformationsSim iccidNotFound(Long iccid_p)
  {
    InformationsSim informationsSim = new InformationsSim();
    informationsSim.setIccid(iccid_p);
    informationsSim.setCodeRetourSecondaire(CodeRetour.NOK);
    informationsSim.setCodeErreur(ConstantesRetour.CODE_RETOUR_ICCID_INCONNU);
    informationsSim.setLibelleErreur(MessageFormat.format(ConstantesRetour.LIBELLE_RETOUR_ICCID_INCONNU, iccid_p));
    return informationsSim;
  }

  /**
   * Return object for when the IMSI is invalid
   *
   * @param imsi_p
   *          the invalid IMSI
   * @return object to be returned
   */

  private InformationsSim imsiInvalid(Long imsi_p)
  {
    InformationsSim informationsSim = new InformationsSim();
    informationsSim.setImsi(imsi_p);
    informationsSim.setCodeRetourSecondaire(CodeRetour.NOK);
    informationsSim.setCodeErreur(ConstantesRetour.CODE_RETOUR_IMSI_FORMAT_INCORRECT);
    informationsSim.setLibelleErreur(MessageFormat.format(ConstantesRetour.LIBELLE_RETOUR_IMSI_FORMAT_INCORRECT, imsi_p));

    return informationsSim;
  }

  /**
   * Return object for when the IMSI is not found
   *
   * @param imsi_p
   *          the IMSI not found
   * @return object to be returned
   */

  private InformationsSim imsiNotFound(Long imsi_p)
  {
    InformationsSim informationsSim = new InformationsSim();
    informationsSim.setImsi(imsi_p);
    informationsSim.setCodeRetourSecondaire(CodeRetour.NOK);
    informationsSim.setCodeErreur(ConstantesRetour.CODE_RETOUR_IMSI_INCONNU);
    informationsSim.setLibelleErreur(MessageFormat.format(ConstantesRetour.LIBELLE_RETOUR_IMSI_INCONNU, imsi_p));

    return informationsSim;
  }

  /**
   * Maps the Activable property from the GDR result object to a process object
   *
   * @param activable_p
   *          Activable property from the GDR
   * @return Activable from the process
   */
  private Activable mapActivable(com.bytel.spirit.common.connectors.gdr.Activable activable_p)
  {
    Activable ret = null;

    if (com.bytel.spirit.common.connectors.gdr.Activable.N == activable_p)
    {
      ret = Activable.N;
    }

    if (com.bytel.spirit.common.connectors.gdr.Activable.O == activable_p)
    {
      ret = Activable.O;
    }

    return ret;
  }

  /**
   * Maps the data from InformationsSim from GDR connector to the InformationsSim in the process
   *
   * @param informationSimGdr_p
   *          The InformationsSim from GDR connector to be mapped
   * @return The process InformationsSim with the data mapped
   *
   */
  private InformationsSim mapGDRInformationsSimToProcess(InfoSIM informationSimGdr_p)
  {
    InformationsSim isNew = new InformationsSim();
    isNew.setImsi(informationSimGdr_p.getImsi());
    isNew.setIccid(informationSimGdr_p.getIccid());
    isNew.setHlr(informationSimGdr_p.getHlr());
    isNew.setTypeGencod(informationSimGdr_p.getTypeGencod());
    isNew.setCodePin1(padToLeft(informationSimGdr_p.getCodePin1(), 4));
    isNew.setCodePin2(padToLeft(informationSimGdr_p.getCodePin2(), 4));
    isNew.setCodePuk1(padToLeft(informationSimGdr_p.getCodePuk1(), 8));
    isNew.setCodePuk2(padToLeft(informationSimGdr_p.getCodePuk2(), 8));
    isNew.setTypeCarte(informationSimGdr_p.getTypeCarte());
    isNew.setLibelleTypeCarte(this.mapLibelleTypeCarte(informationSimGdr_p.getLibelleTypeCarte()));
    isNew.setProfilElectrique(informationSimGdr_p.getProfilElectrique());
    isNew.setTypeSim(informationSimGdr_p.getTypeSim());
    isNew.setTypageReseau(informationSimGdr_p.getTypageReseau());
    isNew.setActivable(this.mapActivable(informationSimGdr_p.getActivable()));
    isNew.setEtatSim(informationSimGdr_p.getEtatSim());

    if (informationSimGdr_p.getCodeRetourSecondaire() == ReturnCode.OK)
    {
      isNew.setCodeRetourSecondaire(CodeRetour.OK);
    }
    else
    {
      isNew.setCodeRetourSecondaire(CodeRetour.NOK);
    }

    return isNew;
  }

  /**
   * Maps the LibelleTypeCarte from GDR connector to the one returned by the process
   *
   * @param libelleTypeCarte_p
   *          The libelleTypeCarte to be mapped
   * @return The process libelleTypeCarte
   */
  private LibelleTypeCarte mapLibelleTypeCarte(TypeCardDescription libelleTypeCarte_p)
  {
    LibelleTypeCarte ret = null;

    if (TypeCardDescription.ISO == libelleTypeCarte_p)
    {
      ret = LibelleTypeCarte.ISO;
    }

    if (TypeCardDescription.PLUG_IN == libelleTypeCarte_p)
    {
      ret = LibelleTypeCarte.PLUG_IN;
    }

    if (TypeCardDescription.UNIVERSEL == libelleTypeCarte_p)
    {
      ret = LibelleTypeCarte.UNIVERSEL;
    }

    return ret;
  }

  /**
   * adds '0' to the String until the length is reached.
   *
   * @param codePinPuk_p
   *          The String to be completed
   * @param len
   *          The total length
   * @return The String with additional zeros on the left
   */
  private String padToLeft(String codePinPuk_p, int len)
  {
    return StringTools.pad(codePinPuk_p, len, PaddingDirection.LEFT, '0');
  }

  /**
   * The synchronized response to the caller.
   *
   * @param request_p
   *          The input request.
   * @param reponseTechnique_p
   *          Technical response to be used
   * @throws RavelException
   *           on error
   */
  private void retourSynchrone(Request request_p, ReponseTechnique reponseTechnique_p) throws RavelException
  {
    InfoSimOut infosimResponse = new InfoSimOut();
    DonneesFonctionnelles donnesFonc = new DonneesFonctionnelles();
    infosimResponse.setDonneesFonctionnelles(donnesFonc);

    ErrorCode errorCode = ErrorCode.OK_00200;
    if (reponseTechnique_p == null)
    {
      ReponseTechnique rt = new ReponseTechnique();
      rt.setCodeRetourPrincipal(CodeRetour.OK);
      infosimResponse.setReponseTechnique(rt);
    }
    else
    {
      infosimResponse.setReponseTechnique(reponseTechnique_p);
      errorCode = ErrorCode.KO_00500;
    }

    if (this._processContext._informationsSims != null)
    {
      for (int i = 0; i < this._processContext._informationsSims.size(); i++)
      {
        InformationsSim is = this._processContext._informationsSims.get(i);
        donnesFonc.getInfomationsSims().add(is);
      }
    }

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setResult(MarshallTools.marshall(infosimResponse));

    Response rsp = new Response(errorCode, ravelResponse);
    request_p.setResponse(rsp);

    _processContext._state = State.ENDED;
  }

  /**
   * Return a NOK to the caller.
   *
   * @param request_p
   *          The input request.
   * @param categorie_p
   *          The category error.
   * @param diagnostic_p
   *          The diagnostic error.
   * @param libelle_p
   *          The label error.
   * @throws RavelException
   *           On retour marshaling error.
   */
  private void returnNOK(Request request_p, String categorie_p, String diagnostic_p, String libelle_p) throws RavelException
  {
    ReponseTechnique reponseTechnique = new ReponseTechnique();
    reponseTechnique.setCodeRetourPrincipal(CodeRetour.NOK);
    reponseTechnique.setCodeErreur(categorie_p);
    reponseTechnique.setLibelleErreur(String.format("%s %s", diagnostic_p, libelle_p)); //$NON-NLS-1$
    retourSynchrone(request_p, reponseTechnique);
  }

  /**
   * Method to MapperRetour and synchronous return
   *
   * @param request_p
   *          The input request.
   * @param informationsSim_p
   *          object {@link InfoSIM} with SIM information
   * @throws RavelException
   *           On retour marshaling error.
   */
  private void terminateProcess(Request request_p, List<InformationsSim> informationsSim_p) throws RavelException
  {
    _processContext._informationsSims = informationsSim_p;
    retourSynchrone(request_p, null);
  }
}
