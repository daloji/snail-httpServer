/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0280.structs;

import com.bytel.spirit.common.connector.oi.emutation.structs.ComplementAdresse;
import com.bytel.spirit.common.connector.oi.emutation.structs.ReferencesAdresse;

/**
 *
 * @author mfreire
 * @version ($Revision$ $Date$)
 */
public class PE0280_BL001_VerifierDonneesRouteOptiqueRetour
{

  /**
   * Serial Version
   */
  private static final long serialVersionUID = -73263909868561124L;

  /**
   *
   */
  private String _oi;

  /**
   *
   */

  private String _refPresentationPrise;

  /**
   *
   */

  private String _referencePrise;

  /**
   *
   */

  private String _identifiantFibre;

  /**
  *
  */

  private ReferencesAdresse _referenceAddresse;

  /**
  *
  */

  private ComplementAdresse _complementAdresseCmd;

  /**
  *
  */

  private ComplementAdresse _complementAdresseTerrain;

  /**
   *
   */

  private String _motifMutation;

  /**
  *
  */

  private String _porte;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0280_BL001_VerifierDonneesRouteOptiqueRetour other = (PE0280_BL001_VerifierDonneesRouteOptiqueRetour) obj;
    if (_identifiantFibre == null)
    {
      if (other._identifiantFibre != null)
      {
        return false;
      }
    }
    else if (!_identifiantFibre.equals(other._identifiantFibre))
    {
      return false;
    }
    if (_motifMutation == null)
    {
      if (other._motifMutation != null)
      {
        return false;
      }
    }
    else if (!_motifMutation.equals(other._motifMutation))
    {
      return false;
    }
    if (_oi == null)
    {
      if (other._oi != null)
      {
        return false;
      }
    }
    else if (!_oi.equals(other._oi))
    {
      return false;
    }
    if (_refPresentationPrise == null)
    {
      if (other._refPresentationPrise != null)
      {
        return false;
      }
    }
    else if (!_refPresentationPrise.equals(other._refPresentationPrise))
    {
      return false;
    }
    if (_referencePrise == null)
    {
      if (other._referencePrise != null)
      {
        return false;
      }
    }
    else if (!_referencePrise.equals(other._referencePrise))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the complementAdresseCmd
   */
  public ComplementAdresse getComplementAdresseCmd()
  {
    return _complementAdresseCmd;
  }

  /**
   * @return the complementAdresseTerrain
   */
  public ComplementAdresse getComplementAdresseTerrain()
  {
    return _complementAdresseTerrain;
  }

  /**
   * @return the identifiantFibre
   */
  public String getIdentifiantFibre()
  {
    return _identifiantFibre;
  }

  /**
   * @return the motifMutation
   */
  public String getMotifMutation()
  {
    return _motifMutation;
  }

  /**
   * @return the oi
   */
  public String getOi()
  {
    return _oi;
  }

  /**
   * @return the porte
   */
  public String getPorte()
  {
    return _porte;
  }

  /**
   * @return the referenceAddresse
   */
  public ReferencesAdresse getReferenceAddresse()
  {
    return _referenceAddresse;
  }

  /**
   * @return the referencePrise
   */
  public String getReferencePrise()
  {
    return _referencePrise;
  }

  /**
   * @return the refPresentationPrise
   */
  public String getRefPresentationPrise()
  {
    return _refPresentationPrise;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_identifiantFibre == null) ? 0 : _identifiantFibre.hashCode());
    result = (prime * result) + ((_motifMutation == null) ? 0 : _motifMutation.hashCode());
    result = (prime * result) + ((_oi == null) ? 0 : _oi.hashCode());
    result = (prime * result) + ((_refPresentationPrise == null) ? 0 : _refPresentationPrise.hashCode());
    result = (prime * result) + ((_referencePrise == null) ? 0 : _referencePrise.hashCode());
    return result;
  }

  /**
   * @param complementAdresseCmd_p
   *          the complementAdresseCmd to set
   */
  public void setComplementAdresseCmd(ComplementAdresse complementAdresseCmd_p)
  {
    _complementAdresseCmd = complementAdresseCmd_p;
  }

  /**
   * @param complementAdresseTerrain_p
   *          the complementAdresseTerrain to set
   */
  public void setComplementAdresseTerrain(ComplementAdresse complementAdresseTerrain_p)
  {
    _complementAdresseTerrain = complementAdresseTerrain_p;
  }

  /**
   * @param identifiantFibre_p
   *          the identifiantFibre to set
   */
  public void setIdentifiantFibre(String identifiantFibre_p)
  {
    _identifiantFibre = identifiantFibre_p;
  }

  /**
   * @param motifMutation_p
   *          the motifMutation to set
   */
  public void setMotifMutation(String motifMutation_p)
  {
    _motifMutation = motifMutation_p;
  }

  /**
   * @param oi_p
   *          the oi to set
   */
  public void setOi(String oi_p)
  {
    _oi = oi_p;
  }

  /**
   * @param porte_p
   *          the porte to set
   */
  public void setPorte(String porte_p)
  {
    _porte = porte_p;
  }

  /**
   * @param referenceAddresse_p
   *          the referenceAddresse to set
   */
  public void setReferenceAddresse(ReferencesAdresse referenceAddresse_p)
  {
    _referenceAddresse = referenceAddresse_p;
  }

  /**
   * @param referencePrise_p
   *          the referencePrise to set
   */
  public void setReferencePrise(String referencePrise_p)
  {
    _referencePrise = referencePrise_p;
  }

  /**
   * @param refPresentationPrise_p
   *          the refPresentationPrise to set
   */
  public void setRefPresentationPrise(String refPresentationPrise_p)
  {
    _refPresentationPrise = refPresentationPrise_p;
  }

  @Override
  public String toString()
  {

    return "PE0280_BL001_VerifierDonneesRouteOptique [_oi=" + _oi + ", _refPresentationPrise=" + _refPresentationPrise + ", _referencePrise=" + _referencePrise + ", _identifiantFibre=" + _identifiantFibre + ", _motifMutation=" + _motifMutation + "]";
  }

}
