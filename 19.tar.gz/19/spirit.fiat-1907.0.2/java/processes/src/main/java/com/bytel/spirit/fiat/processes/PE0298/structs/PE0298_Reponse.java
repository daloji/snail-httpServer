/*******************************************************************************
* $Id: PE0298_Reponse.java 16144 2019-01-22 10:53:19Z jsantos $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0298.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_PFS;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Referentiel;
import com.squareup.moshi.Json;

/**
 *
 * @author kbettenc
 * @version ($Revision: 16144 $ $Date: 2019-01-22 11:53:19 +0100 (mar. 22 janv. 2019) $)
 */
public class PE0298_Reponse implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -2639150851192514568L;

  /**
   * The referentiel
   */
  @Json(name = "referentiels")
  private List<PE0298_Referentiel> _referentiel;

  /**
   * The pfs
   */
  @Json(name = "pfs")
  private List<PE0298_PFS> _pfs;

  /**
   * The idActionCorrective
   */
  @Json(name = "idActionCorrective")
  private String _idActionCorrective;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0298_Reponse other = (PE0298_Reponse) obj;
    if (_idActionCorrective == null)
    {
      if (other._idActionCorrective != null)
      {
        return false;
      }
    }
    else if (!_idActionCorrective.equals(other._idActionCorrective))
    {
      return false;
    }
    if (_pfs == null)
    {
      if (other._pfs != null)
      {
        return false;
      }
    }
    else if (!_pfs.equals(other._pfs))
    {
      return false;
    }
    if (_referentiel == null)
    {
      if (other._referentiel != null)
      {
        return false;
      }
    }
    else if (!_referentiel.equals(other._referentiel))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the idActionCorrective
   */
  public String getIdActionCorrective()
  {
    return _idActionCorrective;
  }

  /**
   * @return the pfs
   */
  public List<PE0298_PFS> getPfs()
  {
    return _pfs != null ? new ArrayList<>(_pfs) : null;
  }

  /**
   * @return the referentiel
   */
  public List<PE0298_Referentiel> getReferentiel()
  {
    return _referentiel != null ? new ArrayList<>(_referentiel) : null;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_idActionCorrective == null) ? 0 : _idActionCorrective.hashCode());
    result = (prime * result) + ((_pfs == null) ? 0 : _pfs.hashCode());
    result = (prime * result) + ((_referentiel == null) ? 0 : _referentiel.hashCode());
    return result;
  }

  /**
   * @param idActionCorrective_p
   *          the idActionCorrective to set
   */
  public void setIdActionCorrective(String idActionCorrective_p)
  {
    _idActionCorrective = idActionCorrective_p;
  }

  /**
   * @param pfs_p
   *          the pfs to set
   */
  public void setPfs(List<PE0298_PFS> pfs_p)
  {
    _pfs = pfs_p != null ? new ArrayList<>(pfs_p) : null;
  }

  /**
   * @param referentiel_p
   *          the referentiel to set
   */
  public void setReferentiel(List<PE0298_Referentiel> referentiel_p)
  {
    _referentiel = referentiel_p != null ? new ArrayList<>(referentiel_p) : null;
  }
}
