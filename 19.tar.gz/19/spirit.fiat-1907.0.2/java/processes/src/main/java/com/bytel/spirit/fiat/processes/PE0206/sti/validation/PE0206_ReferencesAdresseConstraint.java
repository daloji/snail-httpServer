/*******************************************************************************
 * $Id: PE0206_ReferencesAdresseConstraint.java 15579 2019-01-09 14:42:30Z fbarnabe $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206.sti.validation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;

/**
 *
 * @author jiantila
 * @version ($Revision: 15579 $ $Date: 2019-01-09 15:42:30 +0100 (mer., 09 janv. 2019) $)
 */
@Documented
@Target({ TYPE })
@Retention(RUNTIME)
@Constraint(validatedBy = { PE0206_ReferencesAdresseConstraintValidator.class })
public @interface PE0206_ReferencesAdresseConstraint
{
  /**
   * Allows the specification of validation groups, to which this constraint belongs.
   *
   * @return Validation groups
   */
  Class<?>[] groups() default {};

  /**
   * The message to return when the instance of "ClientTitulaire" fails the validation.
   *
   * @return Error message
   */
  String message() default IValidationConst.ATTRIBUT_COND_MANQUANT;

  /**
   * Assign custom payload objects to a constraint.
   *
   * @return Custom payload
   */
  Class<? extends Payload>[] payload() default {};

}
