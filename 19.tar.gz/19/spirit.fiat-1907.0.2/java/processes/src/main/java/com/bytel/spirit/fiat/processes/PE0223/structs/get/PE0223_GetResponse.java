/*******************************************************************************
* $Id: PE0223_GetResponse.java 18930 2019-03-22 17:23:38Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223.structs.get;

import com.bytel.spirit.fiat.processes.PE0223.structs.types.OptionAppel;
import com.bytel.spirit.fiat.processes.structs.GetResponse;

/**
 *
 * @author pcarreir
 * @version ($Revision: 18930 $ $Date: 2019-03-22 18:23:38 +0100 (ven. 22 mars 2019) $)
 */
public class PE0223_GetResponse extends GetResponse<OptionAppel>
{
  /**
   * The serial version UID
   */
  private static final long serialVersionUID = -7318405735720536318L;

}
