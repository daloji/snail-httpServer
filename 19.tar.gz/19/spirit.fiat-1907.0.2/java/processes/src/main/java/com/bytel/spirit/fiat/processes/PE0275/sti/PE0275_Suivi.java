/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : 814_837_RessourceMessage
 *  Package : com.bytel.spirit.fiat.processes.PE0275.structs
 *  Classe  : PE0275_Suivi
 *  Auteur  : sdiop
 *
 */

package com.bytel.spirit.fiat.processes.PE0275.sti;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.squareup.moshi.Json;

/**
 * @author sdiop
 * @version ($Revision$ $Date$)
 */
public class PE0275_Suivi implements Serializable
{
  /**
   * Serial UID
   */
  private static final long serialVersionUID = -5345059731933873972L;

  /**
   * statutLecture
   */
  @Json(name = "statutLecture")
  private String _statutLecture;

  /**
   * dateCreation
   */
  @Json(name = "dateLecture")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateLecture;

  /**
   * Default constructor
   */
  public PE0275_Suivi()
  {
    super();
  }

  /**
   * Argument constructor
   *
   * @param statutLecture_p
   *          statutLecture
   * @param statutArchivage_p
   *          statutArchivage
   */
  public PE0275_Suivi(String statutLecture_p, LocalDateTime statutArchivage_p)
  {
    _statutLecture = statutLecture_p;
    _dateLecture = statutArchivage_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0275_Suivi other = (PE0275_Suivi) obj;
    if (_dateLecture == null)
    {
      if (other._dateLecture != null)
      {
        return false;
      }
    }
    else if (!_dateLecture.equals(other._dateLecture))
    {
      return false;
    }
    if (_statutLecture == null)
    {
      if (other._statutLecture != null)
      {
        return false;
      }
    }
    else if (!_statutLecture.equals(other._statutLecture))
    {
      return false;
    }
    return true;
  }

  /**
   * @return _dateLecture
   */
  public LocalDateTime getDateLecture()
  {
    return _dateLecture;
  }

  /**
   * @return _statutLecture
   */
  public String getStatutLecture()
  {
    return _statutLecture;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_dateLecture == null) ? 0 : _dateLecture.hashCode());
    result = (prime * result) + ((_statutLecture == null) ? 0 : _statutLecture.hashCode());
    return result;
  }

  /**
   * @param dateLecture_p
   *          _dateLecture
   */
  public void setDateLecture(LocalDateTime dateLecture_p)
  {
    _dateLecture = dateLecture_p;
  }

  /**
   * @param statutLecture_p
   *          _statutLecture
   */
  public void setStatutLecture(String statutLecture_p)
  {
    _statutLecture = statutLecture_p;
  }

  @Override
  public String toString()
  {
    return "PE0275_Suivi [_statutLecture=" + _statutLecture + ", _dateLecture=" + _dateLecture + "]";
  }

}
