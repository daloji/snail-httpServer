/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang3.StringUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.net.mms.MMSConstants.Charset;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.npbt.NPBT_SI037_RecupererNoContratParNoTelephone;
import com.bytel.spirit.common.activities.npbt.NPBT_SI037_RecupererNoContratParNoTelephone.NPBT_SI037_RecupererNoContratParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.npbt.NPBT_SI038_RecupererTypeVms;
import com.bytel.spirit.common.activities.npbt.NPBT_SI038_RecupererTypeVms.NPBT_SI038_RecupererTypeVmsBuilder;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail.BL3700_RecupererPfiParMailBuilder;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.BL5280_RecupererTypeAccesNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5280_RecupererTypeAccesNoTelephone.BL5280_RecupererTypeAccesNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.BL5290_RecupererTypeVms;
import com.bytel.spirit.common.activities.shared.BL5290_RecupererTypeVms.BL5290_RecupererTypeVmsBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL3700_Return;
import com.bytel.spirit.common.activities.shared.structs.BL5270_Return;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.str.structs.ResultContratEtPartition;
import com.bytel.spirit.common.fiat.config.Autorisation;
import com.bytel.spirit.common.fiat.config.RessourceMessageriesConfig;
import com.bytel.spirit.common.shared.functional.types.json.AppelantInterdit;
import com.bytel.spirit.common.shared.functional.types.json.AppelantsInterditsPfs;
import com.bytel.spirit.common.shared.functional.types.json.Destinataire;
import com.bytel.spirit.common.shared.functional.types.json.DroitAccesADistancePfs;
import com.bytel.spirit.common.shared.functional.types.json.MessageriePfs;
import com.bytel.spirit.common.shared.functional.types.json.NotificationEmail;
import com.bytel.spirit.common.shared.functional.types.json.NotificationEmailPfs;
import com.bytel.spirit.common.shared.functional.types.json.NotificationSMS;
import com.bytel.spirit.common.shared.functional.types.json.NotificationSmsPfs;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL002GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL100GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL201GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL202GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL203GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL204GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestAppelantsInterdits;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestCodePin;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestDestinataires;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestNotificationsEmail;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestNotificationsSMS;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestStatutMessagerie;
import com.bytel.spirit.fiat.processes.PE0274.sti.RessourceMessageries;
import com.bytel.spirit.fiat.processes.PE0274.structs.OperationMessageries;
import com.bytel.spirit.fiat.processes.structs.XAction;
import com.bytel.spirit.fiat.processes.structs.XLink;

import io.netty.util.internal.StringUtil;

/**
 * PE0274_RessourceMessageries
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0274_RessourceMessageries extends SpiritRestApiProcessSkeleton
{
  /**
   * Process Context
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  public static final class PE0274_RessourceMessageriesContext extends Context
  {
    /**
     * The id for serialization
     */
    private static final long serialVersionUID = -7431497246721902262L;

    /**
     * Contains the next step to execute. Initialized with the first step to execute
     */
    private State _state = State.PE0274_START;

    /**
     * Contains the process configuration
     */
    private transient RessourceMessageriesConfig _configurationPE0274;

    /**
     * idRequest
     */
    private String _idRequest;

    /**
     * The retour of the process
     */
    private Retour _processRetour;

    /**
     * Numero telephone
     */
    private String _noTelephone;

    /**
     * Adresse Mail
     */
    private String _adresseMail;

    /**
     * action
     */
    private String _action;

    /**
     * identifiant Messagerie produit par SPIRIT
     */
    private String _idMessagerie;

    /**
     * Adresse Mail B2R
     */
    private String _adresseMailOauth;

    /**
     * Liste NoContrat B2R
     */
    private List<String> _listeContratOauth;

    /**
     * action a réaliser par le processus
     */
    private OperationMessageries _typeOperation;

    /**
     * typePfs
     */
    private String _typePfs;

    /**
     * idMessageriePfs
     */
    private String _idMessageriePfs;

    /**
     * statutMessagerie
     */
    private String _statutMessagerie;

    /**
     * statutRappel
     */
    private String _statutRappel;

    /**
     * codePin
     */
    private String _codePin;

    /**
     * appelantsInterdits
     */
    private List<AppelantInterdit> _appelantsInterdits;

    /**
     * statutNotificationsEmail
     */
    private String _statutNotificationsEmail;

    /**
     * statutNotificationsSMS
     */
    private String _statutNotificationsSMS;

    /**
     * notificationsEmail
     */
    private List<NotificationEmail> _notificationsEmail;

    /**
     * notificationsSMS
     */
    private List<NotificationSMS> _notificationsSMS;

    /**
     * destinataires
     */
    private List<Destinataire> _destinataires;

    /**
     * Mode d’appel utilisés pour solliciter le service
     */
    private String _modeAppel;

    /**
     * @return the action
     */
    public String getAction()
    {
      return _action;
    }

    /**
     * @return the adresseMail
     */
    public String getAdresseMail()
    {
      return _adresseMail;
    }

    /**
     * @return the adresseMailOauth
     */
    public String getAdresseMailOauth()
    {
      return _adresseMailOauth;
    }

    /**
     * @return the appelantsInterdits
     */
    public List<AppelantInterdit> getAppelantsInterdits()
    {
      return _appelantsInterdits != null ? new ArrayList<>(_appelantsInterdits) : new ArrayList<>();
    }

    /**
     * @return the codePin
     */
    public String getCodePin()
    {
      return _codePin;
    }

    /**
     * @return value of _configurationPE0276
     */
    public RessourceMessageriesConfig getConfigurationPE0274()
    {
      return _configurationPE0274;
    }

    /**
     * @return the destinataires
     */
    public List<Destinataire> getDestinataires()
    {
      return _destinataires != null ? new ArrayList<>(_destinataires) : new ArrayList<>();
    }

    /**
     * @return the idMessagerie
     */
    public String getIdMessagerie()
    {
      return _idMessagerie;
    }

    /**
     * @return the idMessageriePfs
     */
    public String getIdMessageriePfs()
    {
      return _idMessageriePfs;
    }

    /**
     * @return the idRequest
     */
    public String getIdRequest()
    {
      return _idRequest;
    }

    /**
     * @return the listeContratOauth
     */
    public List<String> getListeContratOauth()
    {
      return _listeContratOauth != null ? new ArrayList<>(_listeContratOauth) : new ArrayList<>();
    }

    /**
     * @return the modeAppel
     */
    public String getModeAppel()
    {
      return _modeAppel;
    }

    /**
     * @return the noTelephone
     */
    public String getNoTelephone()
    {
      return _noTelephone;
    }

    /**
     * @return the notificationsEmail
     */
    public List<NotificationEmail> getNotificationsEmail()
    {
      return _notificationsEmail != null ? new ArrayList<>(_notificationsEmail) : new ArrayList<>();
    }

    /**
     * @return value of notificationsSMS
     */
    public List<NotificationSMS> getNotificationsSMS()
    {
      return _notificationsSMS != null ? new ArrayList<>(_notificationsSMS) : new ArrayList<>();
    }

    /**
     * @return the processRetour
     */
    public Retour getProcessRetour()
    {
      return _processRetour;
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the statutMessagerie
     */
    public String getStatutMessagerie()
    {
      return _statutMessagerie;
    }

    /**
     * @return the statutNotificationsEmail
     */
    public String getStatutNotificationsEmail()
    {
      return _statutNotificationsEmail;
    }

    /**
     * @return value of statutNotificationsSMS
     */
    public String getStatutNotificationsSMS()
    {
      return _statutNotificationsSMS;
    }

    /**
     * @return the statutRappel
     */
    public String getStatutRappel()
    {
      return _statutRappel;
    }

    /**
     * @return the typeOperation
     */
    public OperationMessageries getTypeOperation()
    {
      return _typeOperation;
    }

    /**
     * @return the typePfs
     */
    public String getTypePfs()
    {
      return _typePfs;
    }

    /**
     * @param action_p
     *          the action to set
     */
    public void setAction(String action_p)
    {
      _action = action_p;
    }

    /**
     * @param adresseMail_p
     *          the adresseMail to set
     */
    public void setAdresseMail(String adresseMail_p)
    {
      _adresseMail = adresseMail_p;
    }

    /**
     * @param adresseMailOauth_p
     *          the adresseMailOauth to set
     */
    public void setAdresseMailOauth(String adresseMailOauth_p)
    {
      _adresseMailOauth = adresseMailOauth_p;
    }

    /**
     * @param appelantsInterdits_p
     *          the appelantsInterdits to set
     */
    public void setAppelantsInterdits(List<AppelantInterdit> appelantsInterdits_p)
    {
      _appelantsInterdits = new ArrayList<>(appelantsInterdits_p);
    }

    /**
     * @param codePin_p
     *          the codePin to set
     */
    public void setCodePin(String codePin_p)
    {
      _codePin = codePin_p;
    }

    /**
     * @param configurationPE0274_p
     *          The _configurationPE0274 to set.
     */
    public void setConfigurationPE0274(RessourceMessageriesConfig configurationPE0274_p)
    {
      _configurationPE0274 = configurationPE0274_p;
    }

    /**
     * @param destinataires_p
     *          the destinataires to set
     */
    public void setDestinataires(List<Destinataire> destinataires_p)
    {
      _destinataires = new ArrayList<>(destinataires_p);
    }

    /**
     * @param idMessagerie_p
     *          the idMessagerie to set
     */
    public void setIdMessagerie(String idMessagerie_p)
    {
      _idMessagerie = idMessagerie_p;
    }

    /**
     * @param idMessageriePfs_p
     *          the idMessageriePfs to set
     */
    public void setIdMessageriePfs(String idMessageriePfs_p)
    {
      _idMessageriePfs = idMessageriePfs_p;
    }

    /**
     * @param idRequest_p
     *          the idRequest to set
     */
    public void setIdRequest(String idRequest_p)
    {
      _idRequest = idRequest_p;
    }

    /**
     * @param listeContratOauth_p
     *          the listeContratOauth to set
     */
    public void setListeContratOauth(List<String> listeContratOauth_p)
    {
      _listeContratOauth = new ArrayList<>(listeContratOauth_p);
    }

    /**
     * @param modeAppel_p
     *          the modeAppel to set
     */
    public void setModeAppel(String modeAppel_p)
    {
      _modeAppel = modeAppel_p;
    }

    /**
     * @param noTelephone_p
     *          the noTelephone to set
     */
    public void setNoTelephone(String noTelephone_p)
    {
      _noTelephone = noTelephone_p;
    }

    /**
     * @param notificationsEmail_p
     *          the notificationsEmail to set
     */
    public void setNotificationsEmail(List<NotificationEmail> notificationsEmail_p)
    {
      _notificationsEmail = new ArrayList<>(notificationsEmail_p);
    }

    /**
     * @param notificationsSMS_p
     *          The notificationsSMS to set.
     */
    public void setNotificationsSMS(List<NotificationSMS> notificationsSMS_p)
    {
      _notificationsSMS = new ArrayList<>(notificationsSMS_p);
    }

    /**
     * @param processRetour_p
     *          the processRetour to set
     */
    public void setProcessRetour(Retour processRetour_p)
    {
      _processRetour = processRetour_p;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param statutMessagerie_p
     *          the statutMessagerie to set
     */
    public void setStatutMessagerie(String statutMessagerie_p)
    {
      _statutMessagerie = statutMessagerie_p;
    }

    /**
     * @param statutNotificationsEmail_p
     *          the statutNotificationsEmail to set
     */
    public void setStatutNotificationsEmail(String statutNotificationsEmail_p)
    {
      _statutNotificationsEmail = statutNotificationsEmail_p;
    }

    /**
     * @param statutNotificationsSMS_p
     *          The statutNotificationsSMS to set.
     */
    public void setStatutNotificationsSMS(String statutNotificationsSMS_p)
    {
      _statutNotificationsSMS = statutNotificationsSMS_p;
    }

    /**
     * @param statutRappel_p
     *          the statutRappel to set
     */
    public void setStatutRappel(String statutRappel_p)
    {
      _statutRappel = statutRappel_p;
    }

    /**
     * @param typeOperation_p
     *          the typeOperation to set
     */
    public void setTypeOperation(OperationMessageries typeOperation_p)
    {
      _typeOperation = typeOperation_p;
    }

    /**
     * @param typePfs_p
     *          the typePfs to set
     */
    public void setTypePfs(String typePfs_p)
    {
      _typePfs = typePfs_p;
    }
  }

  /**
   * Process states.
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0274_START(MandatoryProcessState.PRC_START),
    /**
     * Step to call GET_BL001
     */
    PE0274_GET_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call GET BL100
     */
    PE0274_GET_BL100(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call GET BL200
     */
    PE0274_GET_BL200(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call GET BL201
     */
    PE0274_GET_BL201(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call GET BL202
     */
    PE0274_GET_BL202(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call GET BL203
     */
    PE0274_GET_BL203(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call GET BL002
     */
    PE0274_GET_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT_BL001
     */
    PE0274_PUT_BL001(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL300
     */
    PE0274_PUT_BL300(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL301
     */
    PE0274_PUT_BL301(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL302
     */
    PE0274_PUT_BL302(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL303
     */
    PE0274_PUT_BL303(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL304
     */
    PE0274_PUT_BL304(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL305
     */
    PE0274_PUT_BL305(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL306
     */
    PE0274_PUT_BL306(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL307
     */
    PE0274_PUT_BL307(MandatoryProcessState.PRC_RUNNING),
    /**
     * Step to call PUT BL002
     */
    PE0274_PUT_BL002(MandatoryProcessState.PRC_RUNNING),
    /**
     * Terminal state.
     */
    PE0274_END(MandatoryProcessState.PRC_STOP);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * @return the technicalState
     */
    public MandatoryProcessState getTechnicalState()
    {
      return _technicalState;
    }

    /**
     * @return the asynchronousState
     */
    public boolean isAsynchronousState()
    {
      return _asynchronousState;
    }

    /**
     * @return the replayableState
     */
    public boolean isReplayableState()
    {
      return _replayableState;
    }
  }

  /**
   * UrlParameters this process can handle
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  protected enum QueryParameters
  {
    /**
     * loginMail
     */
    ADRESSE_MAIL("adresseMail"), //$NON-NLS-1$
    /**
     * noCompte
     */
    NO_TELEPHONE("noTelephone"), //$NON-NLS-1$
    /**
     * action
     */
    ACTION("action"); //$NON-NLS-1$

    /**
     *
     */
    private String _paramName;

    /**
     * @param paramName_p
     *          name
     */
    private QueryParameters(String paramName_p)
    {
      _paramName = paramName_p;
    }

    /**
     * @return the paramName
     */
    public String getParamName()
    {
      return _paramName;
    }

  }

  /**
   * Possible values in Metadata.SOUS_RESSOURCE
   *
   * @author bferreir
   * @version ($Revision$ $Date$)
   */
  private enum SousRessource
  {
    /**
     *
     */
    MESSAGERIES("messageries"), //$NON-NLS-1$
    /**
     *
     */
    INTERDICTIONS_DEPOT_MESSAGES("interdictions-depot-messages"), //$NON-NLS-1$
    /**
     *
     */
    NOTIFICATIONS_SMS("notifications-sms"), //$NON-NLS-1$
    /**
     *
     */
    NOTIFICATIONS_EMAIL("notifications-email"), //$NON-NLS-1$
    /**
     *
     */
    MESSAGERIES_A_DISTANCE("messageries-a-distance"), //$NON-NLS-1$
    /**
     *
     */
    STATUT("statut"), //$NON-NLS-1$
    /**
     *
     */
    GESTION_VVM("vvm"), //$NON-NLS-1$
    /**
     *
     */
    PIN("pin"); //$NON-NLS-1$

    /**
     * Value
     */
    private final String _value;

    /**
     * @param value_p
     *          value
     */
    private SousRessource(String value_p)
    {
      _value = value_p;
    }

    /**
     * @return value
     */
    public String getValue()
    {
      return _value;
    }
  }

  /**
   * The id for serialization
   */
  private static final long serialVersionUID = 7431787475528124882L;

  /**
   * NO_TELEPHONE
   */
  private static final String NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   * ADRESSE_EMAIL
   */
  private static final String ADRESSE_EMAIL = "adresseEmail"; //$NON-NLS-1$

  /**
   * NOM
   */
  private static final String NOM = "nom"; //$NON-NLS-1$

  /**
   * NOM_DOMAINE
   */
  private static final String NOM_DOMAINE = "nomDomaine"; //$NON-NLS-1$

  /**
   * ADRESSE_MAIL
   */
  private static final String ADRESSE_MAIL = "adresseMail"; //$NON-NLS-1$

  /**
   * ID_MESSAGERIE_PFS
   */
  private static final String ID_MESSAGERIE_PFS = "idMessageriePfs"; //$NON-NLS-1$

  /**
   * TYPE_PFS
   */
  private static final String TYPE_PFS = "typePfs"; //$NON-NLS-1$

  /**
   * code pin
   */
  private static final String CODE_PIN = "codePin"; //$NON-NLS-1$

  /**
   * STATUT_MESSAGERIE
   */
  private static final String STATUT_MESSAGERIE = "statutMessagerie"; //$NON-NLS-1$

  /**
   * STATUT_RAPPEL
   */
  private static final String STATUT_RAPPEL = "statutRappel"; //$NON-NLS-1$

  /**
   * STATUT_NOTIFICATIONS_EMAIL
   */
  private static final String STATUT_NOTIFICATIONS_EMAIL = "statutNotificationsEmail"; //$NON-NLS-1$

  /**
   * ACTION
   */
  private static final String ACTION = "action"; //$NON-NLS-1$

  /**
   * GP
   */
  private static final String GP = "GP"; //$NON-NLS-1$

  /**
   * idMessagerieSeparator
   */
  private static final String SEPARATOR_ID_MESSAGERIE = "#"; //$NON-NLS-1$

  /**
   * COMMA_SEPARATOR
   */
  private static final String COMMA_SEPARATOR = ","; //$NON-NLS-1$

  /**
   * EMAIL_SEPARATOR
   */
  private static final String EMAIL_SEPARATOR = "@"; //$NON-NLS-1$

  /**
   * The constant for FileError message
   */
  private static final String MESSAGE_FILE_ERROR = Messages.getString("PE0274.FileError"); //$NON-NLS-1$

  /**
   * The constant for BL001.missingParameter message
   */
  private static final String MESSAGE_MISSING_PARAMETER = Messages.getString("PE0274.BL001.MissingParameter"); //$NON-NLS-1$

  /**
   * The constant for BL001.NoParameter message
   */
  private static final String MESSAGE_NO_PARAMETER = Messages.getString("PE0274.BL001.NoParameter"); //$NON-NLS-1$

  /**
   * The constant for NoParam message
   */
  private static final String MESSAGE_NO_PARAM = Messages.getString("PE0274.NoParam"); //$NON-NLS-1$

  /**
   * The constant for BL001.HeaderNullOrEmpty message
   */
  private static final String MESSAGE_INVALID_HEADER = Messages.getString("PE0274.BL001.HeaderNullOrEmpty"); //$NON-NLS-1$

  /**
   * PE0274.BL001.NoMetadataCanal
   */
  private static final String MESSAGE_NO_METADATA_CANAL = Messages.getString("PE0274.BL001.NoMetadataCanal"); //$NON-NLS-1$

  /**
   * BL100_ListerMessagerieError
   */
  private static final String MESSAGE_LIST_MESSAGERIE_NOT_SUPPORTED = Messages.getString("PE0274.BL100_ListerMessagerieError"); //$NON-NLS-1$
  /**
   * Message to return if the phonenumber is not valid
   */
  private static final String MESSAGE_NON_RESPECT_STI = Messages.getString("PE0274.BL5280.nonRespectSti"); //$NON-NLS-1$

  /**
   * Message to return if the phoneNumber in unknown.
   */
  private static final String MESSAGE_NO_TELEPHONE_INCONNU = Messages.getString("PE0274.NoTelephoneInconnu"); //$NON-NLS-1$

  /**
   * Message to return if the adresseMail in unknown.
   */
  private static final String MESSAGE_ADRESSE_MAIL_INCONNUE = Messages.getString("PE0274.AdresseMailInconnu"); //$NON-NLS-1$

  /**
   * Message to return if the adresseMail is incorrecte.
   */
  private static final String MESSAGE_ADRESSE_MAIL_INCORRECTE = Messages.getString("PE0274.AdresseMailIncorrecte"); //$NON-NLS-1$

  /**
   * Message to return if the service is unavailable
   */
  private static final String MESSAGE_SERVICE_INDISPONIBLE = Messages.getString("PE0274.ServiceIndisponible"); //$NON-NLS-1$

  /**
   * Message to return if an error occured while decrypting the idMessagerie
   */
  private static final String MESSAGE_ID_MESSAGERIE_INCONNU = Messages.getString("PE0274.BL200.IdMessagrieInconnu"); //$NON-NLS-1$

  /**
   * MESSAGE_OPERATION_NON_AUTORISEE
   */
  private static final String MESSAGE_OPERATION_NON_AUTORISEE = Messages.getString("PE0274.BL200.OperationNonAutorisee"); //$NON-NLS-1$

  /**
   * MESSAGE_ACCES_REFUSE
   */
  private static final String MESSAGE_ACCES_REFUSE = "Accès refuse"; //$NON-NLS-1$

  /**
   * MESSAGE_ERROR_DECRYPTING_ID_MESSAGERIE
   */
  private static final String MESSAGE_ERROR_DECRYPTING_ID_MESSAGERIE = "Error decrypting idMessagerie"; //$NON-NLS-1$

  /**
   * MESSAGE_EMPTY_BODY
   */
  private static final String MESSAGE_EMPTY_BODY = Messages.getString("PE0274.BodyNullOrEmpty"); //$NON-NLS-1$

  /**
   * MESSAGE_SOUS_RESSOURCE_NON_AUTORISEE
   */
  private static final String MESSAGE_SOUS_RESSOURCE_NON_AUTORISEE = Messages.getString("PE0274.SousRessourceNonAuthorise"); //$NON-NLS-1$

  /**
   * Configuration path Param
   */
  private static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * PARAM_ID_MESSAGERIE constant
   */
  private static final String PARAM_ID_MESSAGERIE = "idMessagerie"; //$NON-NLS-1$

  /**
   * URL_MESSAGERIES
   */
  private static final String URL_MESSAGERIES = "/messageries/"; //$NON-NLS-1$

  /**
   * URL_LIGNES_TEL
   */
  private static final String URL_LIGNES_TEL = "/lignes-tel/"; //$NON-NLS-1$

  /**
   * URL_DEMAND_FAX
   */
  private static final String URL_DEMAND_FAX = "/demande-envoyer-fax"; //$NON-NLS-1$

  /**
   * URL_COMPTES_MAIL
   */
  private static final String URL_COMPTES_MAIL = "/comptes-mail/"; //$NON-NLS-1$

  /**
   * URL_INTERDICTIONS_DEPOT_MESSAGES
   */
  private static final String URL_INTERDICTIONS_DEPOT_MESSAGES = "/interdictions-depot-messages"; //$NON-NLS-1$

  /**
   * URL_MESSAGERIES_A_DISTANCE
   */
  private static final String URL_MESSAGERIES_A_DISTANCE = "/messageries-a-distance"; //$NON-NLS-1$

  /**
   * URL_NOTIFICATIONS_EMAIL
   */
  private static final String URL_NOTIFICATIONS_EMAIL = "/notifications-email"; //$NON-NLS-1$

  /**
   * URL_NOTIFICATIONS_SMS
   */
  private static final String URL_NOTIFICATIONS_SMS = "/notifications-sms"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_NOTIFICATION_EMAIL
   */
  private static final String PROCESS_CONSULTER_NOTIFICATION_EMAIL = "consulterNotificationEmail"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_NOTIFICATION_SMS
   */
  private static final String PROCESS_CONSULTER_NOTIFICATION_SMS = "consulterNotificationSMS"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_INTERDICTION_DEPOT
   */
  private static final String PROCESS_CONSULTER_INTERDICTION_DEPOT = "consulterInterdictionDepot"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_MESSAGERIE_A_DISTANCE
   */
  private static final String PROCESS_CONSULTER_MESSAGERIE_A_DISTANCE = "consulterMessagerieADistance"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_MESSAGERIE_VMS_PFS
   */
  private static final String PROCESS_CONSULTER_MESSAGERIE_VMS_PFS = "consulterMessagerieVmsPfs"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_MESSAGERIE_MAIL_PFS
   */
  private static final String PROCESS_CONSULTER_MESSAGERIE_MAIL_PFS = "consulterMessagerieMailPfs"; //$NON-NLS-1$

  /**
   * ACTION_MODIFIER_CODE_PIN
   */
  private static final String ACTION_MODIFIER_CODE_PIN = "modifierCodePin"; //$NON-NLS-1$

  /**
   * ACTION_MODIFIER_CODE_PIN
   */
  private static final String ACTION_REINITIALISER_CODE_PIN = "reinitialiserCodePin"; //$NON-NLS-1$

  /**
   * VMS
   */
  private static final String VMS = "VMS"; //$NON-NLS-1$

  /**
   * FIXE
   */
  private static final String FIXE = "FIXE"; //$NON-NLS-1$

  /**
   * MOBILE
   */
  private static final String MOBILE = "MOBILE"; //$NON-NLS-1$

  /**
   * VOIX
   */
  private static final Object VOIX = "VOIX"; //$NON-NLS-1$

  /**
   * FAX
   */
  private static final Object FAX = "FAX"; //$NON-NLS-1$

  /**
   * MAIL
   */
  private static final String MAIL = "MAIL"; //$NON-NLS-1$

  /**
   * CVG
   */
  private static final Object CVG = "CVG"; //$NON-NLS-1$

  /**
   * CLIENT_SP_ROLE
   */
  private static final Object CLIENT_SP_ROLE = "CLIENT_SP"; //$NON-NLS-1$

  /**
   * EMAIL_TECHNIQUE
   */
  private static final String EMAIL_TECHNIQUE = "emailTechnique"; //$NON-NLS-1$

  /**
   * PIECE_JOINTE
   */
  private static final String PIECE_JOINTE = "pieceJointe"; //$NON-NLS-1$

  /**
   * STATUT_NOTIFICATIONS_SMS
   */
  private static final String STATUT_NOTIFICATIONS_SMS = "statutNotificationsSMS"; //$NON-NLS-1$

  /**
   * DESACTIVER
   */
  private static final String DESACTIVER = "desactiver"; //$NON-NLS-1$

  /**
   * REINITIALISER
   */
  private static final String REINITIALISER = "reinitialiser"; //$NON-NLS-1$

  /**
   * PE0274_STI_ERROR
   */
  private static final String PE0274_STI_ERROR = Messages.getString("PE0274.StiError");

  /**
   * Process context instance
   */
  protected PE0274_RessourceMessageriesContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return StringConstants.EMPTY_STRING;
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState().getTechnicalState();
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0274_RessourceMessageriesContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState().isAsynchronousState();
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState().isReplayableState();
  }

  @Override
  protected void exitKOMetroLog(String s_p)
  {
    // Not required for now in Ravel
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param request_p
   *          Object technique «virtuel» regroupant l'ensemble des informations fournies en entrées du service REST
   *          (PATH + paramètres de l'URL, headers http, body http)
   * @return Retour
   * @throws RavelException
   *           On errors
   */
  @LogProcessBL
  protected Retour PE0274_BL001_VerifierDonneesConsultation(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {
    try
    {
      // Load process config file
      Retour retourLoadConfig = loadConfigFile();
      if (RetourFactory.isRetourNOK(retourLoadConfig))
      {
        return retourLoadConfig;
      }

      // Get the header parameters
      Retour retourHeaders = checkRequestHeaders(tracabilite_p, request_p);
      if (!isRetourOK(retourHeaders))
      {
        return retourHeaders;
      }

      //Set ModeAppel
      _processContext.setModeAppel(request_p.getMetadata(IMetadata.METADATA_CANAL));

      Map<String, String> refFonc = new HashMap<>();
      refFonc.put(IRefFoncConstants.ID_EXTERNE, _processContext.getIdRequest());

      //Set the typeOperation
      Retour retourMetadata = checkSousRessource(request_p, refFonc);
      if (!isRetourOK(retourMetadata))
      {
        return retourMetadata;
      }

      BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder() //
          .tracabilite(tracabilite_p) //
          .refFonc(refFonc) //
          .build();
      bl1700.execute(this);

      // Retour OK
      return RetourFactory.createOkRetour();
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
      return RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage());
    }
  }

  /**
   * Cette activité porte les contrôles de la STI<br>
   * <br>
   *
   * @param tracabilite_p
   *          Object {@Code Tracabilite}
   * @param request_p
   *          Object technique «virtuel» regroupant l'ensemble des informations fournies en entrées du service REST
   *          (PATH + paramètres de l'URL, headers http, body http)
   * @return Retour
   * @throws RavelException
   *           On errors
   * @throws UnsupportedEncodingException
   *           On error
   */
  @LogProcessBL
  protected Retour PE0274_BL001_VerifierDonneesModification(final Tracabilite tracabilite_p, final Request request_p) throws RavelException, UnsupportedEncodingException
  {
    Retour retour;
    // Load process config file
    retour = loadConfigFile();
    if (RetourFactory.isRetourNOK(retour))
    {
      return retour;
    }

    // Get the header parameters
    retour = checkRequestHeaders(tracabilite_p, request_p);
    if (!isRetourOK(retour))
    {
      return retour;
    }

    //Get ModeAppel
    if (StringTools.isNullOrEmpty(request_p.getMetadata(IMetadata.METADATA_CANAL)))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_NO_METADATA_CANAL);
    }
    _processContext.setModeAppel(request_p.getMetadata(IMetadata.METADATA_CANAL));

    //Get the idMessagerie
    if (StringTools.isNullOrEmpty(request_p.getUrlDynamicParameters()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, PARAM_ID_MESSAGERIE));
    }
    _processContext.setIdMessagerie(request_p.getUrlDynamicParameters());

    //Get the typeOperation from the SOUS-RESSOURCE
    retour = checkSousRessource(request_p);
    if (!isRetourOK(retour))
    {
      return retour;
    }

    if (OperationMessageries.GESTION_VVM.equals(_processContext.getTypeOperation()))
    {
      for (Parameter parameter : request_p.getUrlParameters().getUrlParameters())
      {
        if (QueryParameters.ACTION.getParamName().equalsIgnoreCase(parameter.getName()))
        {
          _processContext.setAction(parameter.getValue());
          break;
        }
      }

      if (StringUtils.isEmpty(_processContext.getAction()) || !Arrays.asList(DESACTIVER, REINITIALISER).contains(_processContext.getAction()))
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, QueryParameters.ACTION.getParamName()));
      }
      return RetourFactory.createOkRetour();
    }
    else if (OperationMessageries.MODIFIER_CODE_PIN.equals(_processContext.getTypeOperation()))
    {
      for (Parameter parameter : request_p.getUrlParameters().getUrlParameters())
      {
        if (QueryParameters.ACTION.getParamName().equalsIgnoreCase(parameter.getName()))
        {
          _processContext.setAction(parameter.getValue());
          break;
        }
      }

      if (StringUtils.isEmpty(_processContext.getAction()) || !(ACTION_REINITIALISER_CODE_PIN.equals(_processContext.getAction()) || ACTION_MODIFIER_CODE_PIN.equals(_processContext.getAction())))
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, QueryParameters.ACTION.getParamName()));
      }
    }

    if (!(OperationMessageries.MODIFIER_CODE_PIN.equals(_processContext.getTypeOperation()) && ACTION_REINITIALISER_CODE_PIN.equals(_processContext.getAction())))
    {
      retour = checkBody(request_p);
      if (!isRetourOK(retour))
      {
        return retour;
      }
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * PE0274_BL002_FormaterReponseConsultation
   *
   * @param retourIn_p
   *          retourBL100
   * @param reponseIn_p
   *          reponseBL100
   * @return Pair<ReponseErreur, PE0274_BL002GetReponse>
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  protected Pair<Retour, PE0274_BL002GetReponse> PE0274_BL002_FormaterReponseConsultation(Retour retourIn_p, String reponseIn_p) throws RavelException
  {
    if (!isRetourOK(retourIn_p))
    {
      ReponseErreur reponseErreur = new ReponseErreur();
      reponseErreur.setError(retourIn_p.getDiagnostic());
      reponseErreur.setErrorDescription(retourIn_p.getLibelle());
      return new Pair<>(retourIn_p, new PE0274_BL002GetReponse(reponseErreur, null));
    }
    return new Pair<>(retourIn_p, new PE0274_BL002GetReponse(null, reponseIn_p));
  }

  /**
   * PE0274_BL002_FormaterReponseModification
   *
   * @param retourIn_p
   *          retourBL100
   * @return Pair<ReponseErreur, PE0274_BL002GetReponse>
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  protected Pair<Retour, ReponseErreur> PE0274_BL002_FormaterReponseModification(Retour retourIn_p) throws RavelException
  {
    if (!isRetourOK(retourIn_p))
    {
      ReponseErreur reponseErreur = new ReponseErreur();
      reponseErreur.setError(retourIn_p.getDiagnostic());
      reponseErreur.setErrorDescription(retourIn_p.getLibelle());
      return new Pair<>(retourIn_p, reponseErreur);
    }
    return new Pair<>(RetourFactory.createOkRetour(), null);
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    String reponse = null;
    OperationMessageries typeOperation;

    // Call BL001
    _processContext.setState(State.PE0274_GET_BL001);
    Retour retourBL001 = PE0274_BL001_VerifierDonneesConsultation(tracabilite_p, request_p);
    _processContext.setProcessRetour(retourBL001);

    try
    {
      if (RetourFactory.isRetourOK(retourBL001))
      {
        typeOperation = _processContext.getTypeOperation();
        if (OperationMessageries.LISTER_MESSAGERIE.equals(typeOperation))
        {
          // Call BL100
          _processContext.setState(State.PE0274_GET_BL100);
          Pair<Retour, String> bl100 = PE0274_BL100_ListerMessagerie(tracabilite_p, _processContext.getNoTelephone(), _processContext.getAdresseMail(), _processContext.getAdresseMailOauth(), _processContext.getModeAppel(), _processContext.getListeContratOauth());
          reponse = bl100._second;
          _processContext.setProcessRetour(bl100._first);
        }
        else
        {
          //Call BL200-3
          _processContext.setState(State.PE0274_GET_BL200);
          Pair<Retour, String> bl200 = PE0274_BL200_LireOptionsMessagerie(tracabilite_p, _processContext.getIdMessagerie(), _processContext.getTypeOperation(), _processContext.getModeAppel(), _processContext.getListeContratOauth());
          reponse = bl200._second;
          _processContext.setProcessRetour(bl200._first);
        }
      }
    }
    catch (final Exception e)
    {
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()));
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
    }
    finally
    {
      _processContext.setState(State.PE0274_GET_BL002);
      Pair<Retour, PE0274_BL002GetReponse> retourBL002 = PE0274_BL002_FormaterReponseConsultation(_processContext.getProcessRetour(), reponse);
      _processContext.setProcessRetour(retourBL002._first);
      setRetour(_processContext.getProcessRetour());
      syncGetResponse(request_p, retourBL002._second);
      _processContext.setState(State.PE0274_END);
    }
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  @Override
  @LogStartProcess
  protected void startPutProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = null;

    try
    {
      // Call BL001
      _processContext.setState(State.PE0274_PUT_BL001);
      retour = PE0274_BL001_VerifierDonneesModification(tracabilite_p, request_p);

      if (RetourFactory.isRetourOK(retour))
      {
        // Call BL300
        _processContext.setState(State.PE0274_PUT_BL300);
        retour = PE0274_BL300_PreparerModifierMessagerie(_processContext.getIdMessagerie(), _processContext.getModeAppel(), _processContext.getTypeOperation(), _processContext.getListeContratOauth());

        if (isRetourOK(retour))
        {
          switch (_processContext.getTypeOperation())
          {
            case MODIFIER_STATUT_MESSAGERIE:
              _processContext.setState(State.PE0274_PUT_BL301);
              retour = PE0274_BL301_ModifierStatutMessagerie(tracabilite_p, _processContext.getTypePfs(), _processContext.getIdMessageriePfs());
              break;
            case MODIFIER_INTERDICTIONS_DEPOT_MESSAGES:
              _processContext.setState(State.PE0274_PUT_BL302);
              retour = PE0274_BL302_ModifierInterdictionsDepotMessages(tracabilite_p, _processContext.getTypePfs(), _processContext.getIdMessageriePfs());
              break;
            case MODIFIER_CODE_PIN:
              _processContext.setState(State.PE0274_PUT_BL303);
              retour = PE0274_BL303_ModifierCodePin(tracabilite_p, _processContext.getTypePfs(), _processContext.getIdMessageriePfs(), _processContext.getCodePin());
              break;
            case MODIFIER_NOTIFICATIONS_EMAIL:
              _processContext.setState(State.PE0274_PUT_BL304);
              retour = PE0274_BL304_ModifierNotificationsEmail(tracabilite_p, _processContext.getTypePfs(), _processContext.getIdMessageriePfs());
              break;
            case MODIFIER_MESSAGERIES_A_DISTANCE:
              _processContext.setState(State.PE0274_PUT_BL305);
              retour = PE0274_BL305_ModifierMessageriesADistance(tracabilite_p, _processContext.getTypePfs(), _processContext.getIdMessageriePfs());
              break;
            case GESTION_VVM:
              _processContext.setState(State.PE0274_PUT_BL306);
              retour = PE0274_BL306_GestionVVM(tracabilite_p, _processContext.getTypePfs(), _processContext.getIdMessageriePfs());
              break;
            case MODIFIER_NOTIFICATIONS_SMS:
              _processContext.setState(State.PE0274_PUT_BL307);
              retour = PE0274_BL307_ModifierNotificationsSMS(tracabilite_p, _processContext.getTypePfs(), _processContext.getIdMessageriePfs());
              break;
            default:
              //Should never happen
              throw new IllegalStateException();
          }
        }
      }
      _processContext.setProcessRetour(retour);
    }
    catch (final Exception e)
    {
      _processContext.setProcessRetour(RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.TRAITEMENT_ARRETE, e.getMessage()));
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, e));
    }
    finally
    {
      _processContext.setState(State.PE0274_PUT_BL002);
      Pair<Retour, ReponseErreur> retourBL002 = PE0274_BL002_FormaterReponseModification(_processContext.getProcessRetour());
      _processContext.setProcessRetour(retourBL002._first);
      setRetour(_processContext.getProcessRetour());
      syncPutResponse(request_p, retourBL002._second);
      _processContext.setState(State.PE0274_END);
    }
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param pe0274BL002GetReponse_p
   *          Response of PE0274BL002GetReturn
   * @throws RavelException
   *           On error
   */
  protected void syncGetResponse(Request request_p, PE0274_BL002GetReponse pe0274BL002GetReponse_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

      if (pe0274BL002GetReponse_p.getReponseErreur() != null)
      {
        ErrorCode errorCode;
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(pe0274BL002GetReponse_p.getReponseErreur(), ReponseErreur.class));
        switch (pe0274BL002GetReponse_p.getReponseErreur().getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ACCES_REFUSE:
            errorCode = ErrorCode.KO_00403;
            break;
          case IMegSpiritConsts.ADRESSE_MAIL_INCONNU:
          case IMegSpiritConsts.NO_TELEPHONE_INCONNU:
          case IMegSpiritConsts.SERVICE_NON_PROVISIONNE:
          case IMegSpiritConsts.KO_PFS:
          case IMegSpiritConsts.ID_MESSAGERIE_INCONNU:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.TYPE_CONTENU_NON_SUPPORTE:
            errorCode = ErrorCode.KO_00415;
            break;
          case IMegSpiritConsts.MIGRATION_EN_COURS:
          case IMegSpiritConsts.PFS_INDISPO:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        // Set content type
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(pe0274BL002GetReponse_p.getReponse());
        request_p.setResponse(new Response(ErrorCode.OK_00200, ravelResponse));
      }
    }
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param reponseErreur_p
   *          ResponseErreur
   * @throws RavelException
   *           On error
   */
  protected void syncPutResponse(Request request_p, ReponseErreur reponseErreur_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

      if (reponseErreur_p != null)
      {
        ErrorCode errorCode;
        ravelResponse.setResult(RavelJsonTools.getInstance().toJson(reponseErreur_p, ReponseErreur.class));
        switch (reponseErreur_p.getError())
        {
          case IMegSpiritConsts.NON_RESPECT_STI:
            errorCode = ErrorCode.KO_00400;
            break;
          case IMegSpiritConsts.ACCES_REFUSE:
            errorCode = ErrorCode.KO_00403;
            break;
          case IMegSpiritConsts.ID_MESSAGERIE_INCONNU:
          case IMegSpiritConsts.KO_PFS:
            errorCode = ErrorCode.KO_00404;
            break;
          case IMegSpiritConsts.TYPE_CONTENU_NON_SUPPORTE:
            errorCode = ErrorCode.KO_00415;
            break;
          case IMegSpiritConsts.MIGRATION_EN_COURS:
          case IMegSpiritConsts.PFS_INDISPO:
            errorCode = ErrorCode.KO_00503;
            break;
          default:
            errorCode = ErrorCode.KO_00500;
            break;
        }
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        request_p.setResponse(new Response(errorCode, ravelResponse));
      }
      else
      {
        request_p.setResponse(new Response(ErrorCode.OK_00204, ravelResponse));
      }
    }
  }

  /**
   * The the value of the request body.
   *
   * @param request_p
   *          Ravel request
   *
   * @return {@link Retour}
   * @throws RavelException
   *           On error
   * @throws UnsupportedEncodingException
   *           On error
   */
  private Retour checkBody(Request request_p) throws RavelException, UnsupportedEncodingException
  {
    if (StringTools.isNullOrEmpty(request_p.getPayload()))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_EMPTY_BODY);
    }

    switch (_processContext.getTypeOperation())
    {
      case MODIFIER_STATUT_MESSAGERIE:
        PE0274_PutRequestStatutMessagerie payloadStatutMessagerie = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0274_PutRequestStatutMessagerie.class);
        if (payloadStatutMessagerie == null)
        {
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_EMPTY_BODY);
        }
        _processContext.setStatutMessagerie(payloadStatutMessagerie.getStatutMessagerie());
        _processContext.setStatutRappel(payloadStatutMessagerie.getStatutRappel());
        break;
      case MODIFIER_CODE_PIN:
        Retour retourParameter = checkQueryParameter(request_p, null);
        if (!isRetourOK(retourParameter))
        {
          return retourParameter;
        }
        if (ACTION_MODIFIER_CODE_PIN.equals(_processContext.getAction()))
        {
          PE0274_PutRequestCodePin putRequestCodePin = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0274_PutRequestCodePin.class);
          if (putRequestCodePin == null)
          {
            return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_EMPTY_BODY);
          }
          _processContext.setCodePin(putRequestCodePin.getCodePin());
        }
        break;
      case MODIFIER_INTERDICTIONS_DEPOT_MESSAGES:
        PE0274_PutRequestAppelantsInterdits putRequestAppelantsInterdits = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0274_PutRequestAppelantsInterdits.class);
        if ((putRequestAppelantsInterdits == null) || putRequestAppelantsInterdits.getAppelantsInterdits().isEmpty())
        {
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_EMPTY_BODY);
        }
        _processContext.setAppelantsInterdits(putRequestAppelantsInterdits.getAppelantsInterdits());
        break;
      case MODIFIER_NOTIFICATIONS_EMAIL:
        PE0274_PutRequestNotificationsEmail putRequestNotificationsEmail = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0274_PutRequestNotificationsEmail.class);
        if (putRequestNotificationsEmail == null)
        {
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_EMPTY_BODY);
        }
        _processContext.setStatutNotificationsEmail(putRequestNotificationsEmail.getStatutNotificationsEmail());
        _processContext.setNotificationsEmail(putRequestNotificationsEmail.getNotificationsEmail());
        break;
      case MODIFIER_NOTIFICATIONS_SMS:
        PE0274_PutRequestNotificationsSMS payloadSMS = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0274_PutRequestNotificationsSMS.class);
        if (payloadSMS == null)
        {
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_EMPTY_BODY);
        }
        _processContext.setStatutNotificationsSMS(payloadSMS.getStatutNotificationsSMS());
        if (payloadSMS.getNotificationsSMS().size() > 1)
        {
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, PE0274_STI_ERROR);
        }
        _processContext.setNotificationsSMS(payloadSMS.getNotificationsSMS());
        break;
      case MODIFIER_MESSAGERIES_A_DISTANCE:
        PE0274_PutRequestDestinataires putRequestDestinataires = RavelJsonTools.getInstance().fromJson(request_p.getPayload(), PE0274_PutRequestDestinataires.class);
        if (putRequestDestinataires == null)
        {
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_EMPTY_BODY);
        }
        _processContext.setDestinataires(putRequestDestinataires.getDestinataires());
        break;
      default:
        //Should never Happen
        throw new IllegalArgumentException();
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Validate if there is at least one parameter with name adresseMail or noTelephone.
   *
   * @param request_p
   *          request
   * @param refFonc_p
   *          refFonc
   * @return {@link Retour}
   * @throws UnsupportedEncodingException
   *           In case of URL decoding error
   */
  private Retour checkQueryParameter(Request request_p, Map<String, String> refFonc_p) throws UnsupportedEncodingException
  {
    if (request_p.getUrlParameters().getUrlParameters().isEmpty())
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_NO_PARAMETER);
    }

    for (Parameter parameter : request_p.getUrlParameters().getUrlParameters())
    {
      if (QueryParameters.ADRESSE_MAIL.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        if (StringTools.isNullOrEmpty(parameter.getValue()))
        {
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, QueryParameters.ADRESSE_MAIL.getParamName()));
        }
        _processContext.setAdresseMail(URLDecoder.decode(parameter.getValue(), Charset.UTF8.getCharset()));
        refFonc_p.put(IRefFoncConstants.ADRESSE_MAIL, _processContext.getAdresseMail());
      }
      else if (QueryParameters.NO_TELEPHONE.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        if (StringTools.isNullOrEmpty(parameter.getValue()))
        {
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, QueryParameters.NO_TELEPHONE.getParamName()));
        }
        _processContext.setNoTelephone(parameter.getValue());
        refFonc_p.put(IRefFoncConstants.NO_TELEPHONE, _processContext.getNoTelephone());
      }
      else if (QueryParameters.ACTION.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        if (StringTools.isNullOrEmpty(parameter.getValue()))
        {
          return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, QueryParameters.ACTION.getParamName()));
        }
        _processContext.setAction(parameter.getValue());
      }
      else
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MESSAGE_NO_PARAMETER);
      }
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Validates that each key in headersMap_p has a value in the request_p parameter, and if yes set the corresponding
   * value.
   *
   * @param tracabilite_p
   *          The tracabilite
   * @param request_p
   *          The request The original request containing all headers
   *
   * @return Retour OK if all the headers in the headersMap_p are set, NOK otherwise
   */
  private Retour checkRequestHeaders(Tracabilite tracabilite_p, final Request request_p)
  {
    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        _processContext.setIdRequest(header.getValue());
      }

      if (IHttpHeadersConsts.X_OAUTH2_LOGIN.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        _processContext.setAdresseMailOauth(header.getValue());
      }

      if (IHttpHeadersConsts.X_OAUTH2_IDCONTRATS.equalsIgnoreCase(header.getName()) && !StringTools.isNullOrEmpty(header.getValue()))
      {
        List<String> listContratOauth = new ArrayList<>();
        String[] listeContract = header.getValue().trim().split(StringConstants.SEMICOLON_SEPARATOR);
        for (String contract : listeContract)
        {
          String[] contractElement = contract.split(COMMA_SEPARATOR);
          String[] idContract = contractElement[0].split("="); //$NON-NLS-1$
          listContratOauth.add(idContract[1]);
        }
        _processContext.setListeContratOauth(listContratOauth);
      }
    }

    if (StringTools.isNullOrEmpty(_processContext.getIdRequest()))
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_REQUEST_ID)));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_HEADER, IHttpHeadersConsts.X_REQUEST_ID));
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * Get the value of the SOUS_RESSOURCE and set the PUT typeOperation
   *
   * @param request_p
   *          request
   * @return {@link Retour}
   */
  private Retour checkSousRessource(Request request_p)
  {
    String sousRessource = request_p.getMetadata(IMetadata.SOUS_RESSOURCE);

    if (SousRessource.STATUT.getValue().equals(sousRessource))
    {
      _processContext.setTypeOperation(OperationMessageries.MODIFIER_STATUT_MESSAGERIE);
    }
    else if (SousRessource.INTERDICTIONS_DEPOT_MESSAGES.getValue().equals(sousRessource))
    {
      _processContext.setTypeOperation(OperationMessageries.MODIFIER_INTERDICTIONS_DEPOT_MESSAGES);
    }
    else if (SousRessource.PIN.getValue().equals(sousRessource))
    {
      _processContext.setTypeOperation(OperationMessageries.MODIFIER_CODE_PIN);
    }
    else if (SousRessource.NOTIFICATIONS_EMAIL.getValue().equals(sousRessource))
    {
      _processContext.setTypeOperation(OperationMessageries.MODIFIER_NOTIFICATIONS_EMAIL);
    }
    else if (SousRessource.NOTIFICATIONS_SMS.getValue().equals(sousRessource))
    {
      _processContext.setTypeOperation(OperationMessageries.MODIFIER_NOTIFICATIONS_SMS);
    }
    else if (SousRessource.GESTION_VVM.getValue().equals(sousRessource))
    {
      _processContext.setTypeOperation(OperationMessageries.GESTION_VVM);
    }
    else if (SousRessource.MESSAGERIES_A_DISTANCE.getValue().equals(sousRessource))
    {
      _processContext.setTypeOperation(OperationMessageries.MODIFIER_MESSAGERIES_A_DISTANCE);
    }
    else
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_SOUS_RESSOURCE_NON_AUTORISEE, sousRessource));
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * Get the value of the SOUS_RESSOURCE and set the GET typeOperation
   *
   * @param request_p
   *          request
   * @param refFonc_p
   *          RefFonc
   * @return {@link Retour}
   * @throws UnsupportedEncodingException
   *           In case of URL decoding error
   */
  private Retour checkSousRessource(Request request_p, Map<String, String> refFonc_p) throws UnsupportedEncodingException
  {
    String sousRessource = request_p.getMetadata(IMetadata.SOUS_RESSOURCE);

    if (SousRessource.MESSAGERIES.getValue().equals(sousRessource))
    {
      Retour retourQueryParameter = checkQueryParameter(request_p, refFonc_p);
      if (!isRetourOK(retourQueryParameter))
      {
        return retourQueryParameter;
      }
      _processContext.setTypeOperation(OperationMessageries.LISTER_MESSAGERIE);
    }
    else
    {
      if (SousRessource.INTERDICTIONS_DEPOT_MESSAGES.getValue().equals(sousRessource))
      {
        _processContext.setTypeOperation(OperationMessageries.LIRE_INTERDICTION_DEPOT_MESSAGE);
      }
      else if (SousRessource.NOTIFICATIONS_EMAIL.getValue().equals(sousRessource))
      {
        _processContext.setTypeOperation(OperationMessageries.LIRE_NOTIFICATION_EMAIL);
      }
      else if (SousRessource.NOTIFICATIONS_SMS.getValue().equals(sousRessource))
      {
        _processContext.setTypeOperation(OperationMessageries.LISTER_NOTIFICATIONS_SMS);
      }
      else if (SousRessource.MESSAGERIES_A_DISTANCE.getValue().equals(sousRessource))
      {
        _processContext.setTypeOperation(OperationMessageries.LIRE_MESSAGERIE_A_DISTANCE);
      }

      if (StringTools.isNullOrEmpty(request_p.getUrlDynamicParameters()))
      {
        return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_MISSING_PARAMETER, PARAM_ID_MESSAGERIE));
      }
      _processContext.setIdMessagerie(request_p.getUrlDynamicParameters());
      refFonc_p.put(IRefFoncConstants.ID_MESSAGERIE, _processContext.getIdMessagerie());
    }

    return RetourFactory.createOkRetour();
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param processus_p
   *          processus
   * @param listeParametres_p
   *          listeParametres
   * @param priorite_p
   *          priorite
   * @return {@link Retour}
   * @throws RavelException
   *           On error
   */
  private Pair<Retour, ResponseConnector> executeSI002(Tracabilite tracabilite_p, String processus_p, ListeParametre listeParametres_p, Integer priorite_p) throws RavelException
  {
    PROV_SI002_ExecuterProcessus si002 = new PROV_SI002_ExecuterProcessusBuilder() //
        .tracabilite(tracabilite_p) //
        .processus(processus_p) //
        .listeParametres(listeParametres_p) //
        .priorite(priorite_p) //
        .build();
    ResponseConnector response = si002.execute(this);
    Retour retourProv = si002.getRetour();

    if (!isRetourOK(retourProv))
    {
      if (IMegConsts.CAT1.equals(retourProv.getCategorie()))
      {
        return new Pair<>(RetourFactory.createNOK(retourProv.getCategorie(), IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE), null);
      }
      else if (IMegConsts.CAT2.equals(retourProv.getCategorie()))
      {
        return new Pair<>(RetourFactory.createNOK(retourProv.getCategorie(), IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPONIBLE), null);
      }
      else
      {
        return new Pair<>(retourProv, null);
      }
    }
    return new Pair<>(RetourFactory.createOkRetour(), response);
  }

  /**
   * Load process configuration file into process context
   *
   * @return {@link Retour}
   */
  private Retour loadConfigFile()
  {
    // Load config
    String configPE0274Param = getConfigParameter(PARAM_CONFIG_PATH);

    if (!StringTools.isNullOrEmpty(configPE0274Param))
    {
      try
      {
        Path configPE0274Path = Paths.get(configPE0274Param);
        String configPE0274File = new String(Files.readAllBytes(configPE0274Path));
        _processContext.setConfigurationPE0274(MarshallTools.unmarshall(RessourceMessageriesConfig.class, configPE0274File));

        return RetourFactory.createOkRetour();
      }
      catch (Exception exception)
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_FILE_ERROR, exception.getMessage()));
      }
    }
    return RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.CONFIGURATION_INVALIDE, MessageFormat.format(MESSAGE_NO_PARAM, PARAM_CONFIG_PATH));
  }

  /**
   * PE0274_BL100_ListerMessagerie
   *
   * @param tracabilite_p
   *          tracabilite
   * @param noTelephone_p
   *          noTelephone
   * @param adresseMail_p
   *          adresseMail
   * @param adresseMailOauth_p
   *          adresseMailOauth
   * @param modeAppel_p
   *          modeAppel
   * @param listeContratOauth_p
   *          listeContratOauth
   * @return Pair of {@link Retour} and {@link PE0274_BL100GetReponse}
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Retour, String> PE0274_BL100_ListerMessagerie(Tracabilite tracabilite_p, String noTelephone_p, String adresseMail_p, String adresseMailOauth_p, String modeAppel_p, List<String> listeContratOauth_p) throws RavelException
  {
    String noContrat = null;
    String partition = null;
    String typeMessagerie;
    String loginEmail = null;
    String nomDomaineEmail = null;
    String typePfs = null;
    String noCompte = null;
    String clientOperateur = null;
    String typeAcces = null;
    Retour retour;

    if (!StringUtil.isNullOrEmpty(noTelephone_p))
    {
      typeMessagerie = VMS;
      BL5280_RecupererTypeAccesNoTelephone bl5280 = new BL5280_RecupererTypeAccesNoTelephoneBuilder() //
          .tracabilite(tracabilite_p) //
          .noTelephone(noTelephone_p) //
          .build();
      typeAcces = bl5280.execute(this);
      if (!isRetourOK(bl5280.getRetour()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_NON_RESPECT_STI, noTelephone_p)), null);
      }

      if (typeAcces.equals(FIXE))
      {
        BL5270_RecupererPfiParNoTelephone bl5270 = new BL5270_RecupererPfiParNoTelephoneBuilder() //
            .tracabilite(tracabilite_p) //
            .noTelephone(noTelephone_p) //
            .build();
        BL5270_Return bl5270Return = bl5270.execute(this);
        retour = bl5270.getRetour();
        clientOperateur = bl5270Return != null ? bl5270Return.getClientOperateur() : null;
        noContrat = bl5270Return != null ? bl5270Return.getNoContrat() : null;
        noCompte = bl5270Return != null ? bl5270Return.getNoCompte() : null;
      }
      else
      {
        //noContrat = SI037
        NPBT_SI037_RecupererNoContratParNoTelephone si037 = new NPBT_SI037_RecupererNoContratParNoTelephoneBuilder() //
            .tracabilite(tracabilite_p) //
            .noTelephone(noTelephone_p) //
            .build();
        Pair<Retour, ResultContratEtPartition> si037Reponse = si037.execute(this);
        retour = si037Reponse._first;
        if (isRetourOK(retour))
        {
          ResultContratEtPartition resultContrat = si037Reponse._second;
          partition = resultContrat.getPartition();
          noContrat = resultContrat.getNumContrat();
          if (IMetadata.CANAL_B2R.equals(modeAppel_p) && !GP.equals(partition))
          {
            return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MESSAGE_LIST_MESSAGERIE_NOT_SUPPORTED), null);
          }
        }
      }

      if (!isRetourOK(retour))
      {
        if (IMegConsts.CAT4.equals(retour.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(retour.getDiagnostic()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_INCONNU, MessageFormat.format(MESSAGE_NO_TELEPHONE_INCONNU, noTelephone_p)), null);
        }
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE), null);
      }
      if (typeAcces.equals(FIXE))
      {
        BL5290_RecupererTypeVms bl5290 = new BL5290_RecupererTypeVmsBuilder() //
            .tracabilite(tracabilite_p) //
            .noTelephone(noTelephone_p) //
            .noCompte(noCompte) //
            .clientOperateur(clientOperateur) //
            .build();
        typePfs = bl5290.execute(this);
        retour = bl5290.getRetour();
      }
      else
      {
        //typePfs = SI038
        NPBT_SI038_RecupererTypeVms si038 = new NPBT_SI038_RecupererTypeVmsBuilder() //
            .tracabilite(tracabilite_p) //
            .noTelephone(noTelephone_p) //
            .build();
        Pair<Retour, String> si038Reponse = si038.execute(this);
        retour = si038Reponse._first;
        typePfs = si038Reponse._second;
      }
      if (!isRetourOK(retour))
      {
        if (IMegConsts.CAT4.equals(retour.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(retour.getDiagnostic()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_INCONNU, MessageFormat.format(MESSAGE_NO_TELEPHONE_INCONNU, noTelephone_p)), null);
        }
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE), null);
      }
    }
    else
    {
      typeMessagerie = MAIL;

      String[] loginEtDomaine = adresseMail_p.split(EMAIL_SEPARATOR);

      if (loginEtDomaine.length != 2)
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_ADRESSE_MAIL_INCORRECTE, adresseMail_p)), null);
      }

      loginEmail = loginEtDomaine[0];
      nomDomaineEmail = loginEtDomaine[1];

      //Call BL3700
      BL3700_RecupererPfiParMail bl3700 = new BL3700_RecupererPfiParMailBuilder() //
          .tracabilite(tracabilite_p) //
          .mail(loginEmail) //
          .build();
      BL3700_Return bl3700Return = bl3700.execute(this);
      retour = bl3700.getRetour();

      if (!isRetourOK(retour))
      {
        if (IMegConsts.CAT4.equals(retour.getCategorie()) && IMegConsts.DONNEE_INCONNUE.equals(retour.getDiagnostic()))
        {
          return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ADRESSE_MAIL_INCONNU, MessageFormat.format(MESSAGE_ADRESSE_MAIL_INCONNUE, adresseMail_p)), null);
        }
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, retour.getLibelle()), null);
      }

      noContrat = bl3700Return.getnoContrat();

      if (!StringUtil.isNullOrEmpty(adresseMailOauth_p) && adresseMailOauth_p.contains(EMAIL_SEPARATOR))
      {
        String[] loginEtDomaineOauth = adresseMailOauth_p.split(EMAIL_SEPARATOR);
        String loginEmailOauth = loginEtDomaineOauth[0];
        String nomDomaineEmailOauth = loginEtDomaineOauth[1];
        if (!StringUtil.isNullOrEmpty(nomDomaineEmailOauth) && _processContext.getConfigurationPE0274().getListeDomaineEmail().getDomain().contains(nomDomaineEmailOauth))
        {
          loginEmail = loginEmailOauth;
          nomDomaineEmail = nomDomaineEmailOauth;
        }
      }
    }

    if (IMetadata.CANAL_B2R.equalsIgnoreCase(modeAppel_p))
    {
      if ((listeContratOauth_p.isEmpty()) || !listeContratOauth_p.contains(noContrat))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MESSAGE_ACCES_REFUSE), null);
      }
    }

    PROV_SI002_ExecuterProcessusBuilder si002Builder = new PROV_SI002_ExecuterProcessusBuilder().tracabilite(tracabilite_p);
    if (MAIL.equals(typeMessagerie))
    {
      ListeParametre listeParametres = new ListeParametre();
      listeParametres.add(ADRESSE_MAIL, loginEmail);
      listeParametres.add(NOM_DOMAINE, nomDomaineEmail);
      si002Builder = si002Builder //
          .processus(PROCESS_CONSULTER_MESSAGERIE_MAIL_PFS) //
          .listeParametres(listeParametres) //
          .priorite(10);
    }
    else
    {
      ListeParametre listeParametres = new ListeParametre();
      listeParametres.add(NO_TELEPHONE, noTelephone_p);
      listeParametres.add(TYPE_PFS, typePfs);
      si002Builder = si002Builder //
          .processus(PROCESS_CONSULTER_MESSAGERIE_VMS_PFS) //
          .listeParametres(listeParametres) //
          .priorite(10); //
    }
    PROV_SI002_ExecuterProcessus si002 = si002Builder.build();

    ResponseConnector si002Return = si002.execute(this);
    Retour retourProv = si002.getRetour();
    if (!isRetourOK(retourProv))
    {
      if (IMegConsts.CAT1.equals(retourProv.getCategorie()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE), null);
      }
      else if (IMegConsts.CAT2.equals(retourProv.getCategorie()))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPONIBLE), null);
      }
      else
      {
        return new Pair<>(retourProv, null);
      }
    }
    ReponseFonctionnelle<MessageriePfs> responseFonctionnelle = si002Return.getReponseFonctionnelle(MessageriePfs.class);
    List<RessourceMessageries> listeRessourceMessageries = new ArrayList<>();
    for (MessageriePfs messageriePfs : responseFonctionnelle.getItems())
    {
      RessourceMessageries ressourceMessagerie = new RessourceMessageries(messageriePfs);
      String idMessagerie = noContrat + SEPARATOR_ID_MESSAGERIE + messageriePfs.getIdMessageriePfs() + SEPARATOR_ID_MESSAGERIE + messageriePfs.getTypeMessagerie() + SEPARATOR_ID_MESSAGERIE + messageriePfs.getTypePfs();
      String encryptedIdMessagerie = PasswordEncrypter.encryptForURL(idMessagerie);
      ressourceMessagerie.setIdMessagerie(encryptedIdMessagerie);

      if (IMetadata.CANAL_B2R.equalsIgnoreCase(modeAppel_p))
      {
        if (VOIX.equals(messageriePfs.getTypeMessagerie()))
        {
          ressourceMessagerie.putLink("lireAnnoncesAccueil", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/annonces-accueil/caracteristiques")); //$NON-NLS-1$ //$NON-NLS-2$
          ressourceMessagerie.putLink("lireNotificationsEmail", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_EMAIL)); //$NON-NLS-1$
          ressourceMessagerie.putLink("lireMessages", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/messages")); //$NON-NLS-1$ //$NON-NLS-2$
          ressourceMessagerie.putLink("lireMessageriesADistance", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_MESSAGERIES_A_DISTANCE)); //$NON-NLS-1$ /
          ressourceMessagerie.putLink("lireInterdictionsDepot", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_INTERDICTIONS_DEPOT_MESSAGES)); //$NON-NLS-1$ /
          ressourceMessagerie.putAction("modifierStatutsMessagerie", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + "/statut", MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$ //$NON-NLS-2$
          ressourceMessagerie.putLink(XLink.SELF, new XLink(URL_LIGNES_TEL + noTelephone_p + "/messageries")); //$NON-NLS-1$

          boolean putModifierCodePinAction = false;
          for (String role : getRoles())
          {
            if (CLIENT_SP_ROLE.equals(role))
            {
              putModifierCodePinAction = true;
            }
          }

          if (putModifierCodePinAction)
          {
            ressourceMessagerie.putAction(ACTION_MODIFIER_CODE_PIN, new XAction(URL_MESSAGERIES + encryptedIdMessagerie + "/pin?action=modifierCodePin", MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$
          }

          if (MOBILE.equals(typeAcces) && CVG.equals(typePfs))
          {
            ressourceMessagerie.putAction(ACTION_REINITIALISER_CODE_PIN, new XAction(URL_MESSAGERIES + encryptedIdMessagerie + "/pin?action=reinitialiserCodePin", MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$
          }

        }
        else if (FAX.equals(messageriePfs.getTypeMessagerie()))
        {
          ressourceMessagerie.putLink("lireNotificationsEmail", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_EMAIL));
          ressourceMessagerie.putLink("lireNotificationsSMS", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_SMS));
          ressourceMessagerie.putLink("lireMessages", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/messages")); //$NON-NLS-1$

          ressourceMessagerie.putAction("demandeEnvoyerFax", new XAction(URL_DEMAND_FAX, MediaType.APPLICATION_JSON, HttpConstants.POST_METHOD)); //$NON-NLS-1$
          ressourceMessagerie.putLink(XLink.SELF, new XLink(URL_LIGNES_TEL + noTelephone_p + "/messageries")); //$NON-NLS-1$
        }
        else if (MAIL.equals(messageriePfs.getTypeMessagerie()))
        {
          ressourceMessagerie.putLink(XLink.SELF, new XLink(URL_COMPTES_MAIL + adresseMail_p + "/messageries")); //$NON-NLS-1$
        }
      }
      listeRessourceMessageries.add(ressourceMessagerie);
    }

    PE0274_BL100GetReponse reponse = new PE0274_BL100GetReponse();
    reponse.setItems(listeRessourceMessageries);
    reponse.setResultsCount(listeRessourceMessageries.size());

    return new Pair<>(RetourFactory.createOkRetour(), RavelJsonTools.getInstance().toJson(reponse, PE0274_BL100GetReponse.class));
  }

  /**
   *
   * @param tracabilite_p
   *          tracabilite
   * @param idMessagerie_p
   *          idMessagerie
   * @param typeOperation_p
   *          typeOperation_p
   * @param modeAppel_p
   *          modeAppel_p
   * @param listeContratOauth_p
   *          listeContratOauth_p
   * @return Pair of {@link Retour} and {@link String}
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Retour, String> PE0274_BL200_LireOptionsMessagerie(Tracabilite tracabilite_p, String idMessagerie_p, OperationMessageries typeOperation_p, String modeAppel_p, List<String> listeContratOauth_p) throws RavelException
  {
    String idMessagerieDecrypted, noContrat, idMessageriePfs, typeMessagerie, typePfs;

    try
    {
      idMessagerieDecrypted = PasswordDecrypter.decryptForURL(idMessagerie_p);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, MESSAGE_ERROR_DECRYPTING_ID_MESSAGERIE, e));
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGERIE_INCONNU, idMessagerie_p)), null);
    }

    // Get the parameters type and noTelephone
    String[] parametresMessagerie = idMessagerieDecrypted.split(SEPARATOR_ID_MESSAGERIE);
    if (parametresMessagerie.length == 4)
    {
      noContrat = parametresMessagerie[0];
      idMessageriePfs = parametresMessagerie[1];
      typeMessagerie = parametresMessagerie[2];
      typePfs = parametresMessagerie[3];
    }
    else
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGERIE_INCONNU, idMessagerie_p)), null);
    }

    if (IMetadata.CANAL_B2R.equalsIgnoreCase(modeAppel_p))
    {
      if ((listeContratOauth_p.isEmpty()) || !listeContratOauth_p.contains(noContrat))
      {
        return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MESSAGE_ACCES_REFUSE), null);
      }
    }

    Autorisation autorisation = null;
    OperationMessageries operation = null;
    for (Autorisation aut : _processContext.getConfigurationPE0274().getOperationOptionMessagerieAutorisee().getAutorisation())
    {
      if (typeMessagerie.equalsIgnoreCase(aut.getTypeMessagerie()))
      {
        autorisation = aut;
        break;
      }
    }

    if (autorisation != null)
    {
      for (String op : autorisation.getOperations())
      {
        if (typeOperation_p.getValue().equalsIgnoreCase(op))
        {
          operation = typeOperation_p;
          break;
        }
      }
    }

    if ((autorisation == null) || (operation == null))
    {
      return new Pair<>(RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NON_AUTORISEE, idMessagerie_p)), null);
    }

    switch (operation)
    {
      case LIRE_MESSAGERIE_A_DISTANCE:
        return PE0274_BL201_LireOptionMessagerieADistance(tracabilite_p, idMessagerie_p, modeAppel_p, typePfs, idMessageriePfs);
      case LIRE_INTERDICTION_DEPOT_MESSAGE:
        return PE0274_BL202_LireOptionInterdictionDepotMessage(tracabilite_p, idMessagerie_p, modeAppel_p, typePfs, idMessageriePfs);
      case LISTER_NOTIFICATIONS_SMS:
        return PE0274_BL204_LireOptionNotificationSMS(tracabilite_p, idMessagerie_p, modeAppel_p, typePfs, idMessageriePfs);
      default:
        return PE0274_BL203_LireOptionNotificationEmail(tracabilite_p, idMessagerie_p, modeAppel_p, typePfs, idMessageriePfs);
    }
  }

  /**
   * PE0274_BL201_LireOptionMessagerieADistance
   *
   * @param tracabilite_p
   *          tracabilite
   * @param idMessagerie_p
   *          idMessagerie
   * @param modeAppel_p
   *          modeAppel
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessageriePfs
   * @return Pair of {@link Retour} and {@link PE0274_BL201GetReponse}
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Retour, String> PE0274_BL201_LireOptionMessagerieADistance(Tracabilite tracabilite_p, String idMessagerie_p, String modeAppel_p, String typePfs_p, String idMessageriePfs_p) throws RavelException
  {
    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);

    Pair<Retour, ResponseConnector> returnSI002 = executeSI002(tracabilite_p, PROCESS_CONSULTER_MESSAGERIE_A_DISTANCE, listeParametres, 10);
    if (!isRetourOK(returnSI002._first))
    {
      return new Pair<>(returnSI002._first, null);
    }

    ReponseFonctionnelle<DroitAccesADistancePfs> responseFonctionnelle = returnSI002._second.getReponseFonctionnelle(DroitAccesADistancePfs.class);
    PE0274_BL201GetReponse reponse = new PE0274_BL201GetReponse();
    reponse.setDestinataires(responseFonctionnelle.getItems().get(0).getDestinataires());
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(modeAppel_p))
    {
      reponse.putLink(XLink.SELF, new XLink(URL_MESSAGERIES + idMessagerie_p + URL_MESSAGERIES_A_DISTANCE));
      reponse.putAction("modifierConsultationADistance", new XAction(URL_MESSAGERIES + idMessagerie_p + URL_MESSAGERIES_A_DISTANCE, MediaType.APPLICATION_JSON, HttpMethod.PUT)); //$NON-NLS-1$
    }
    return new Pair<>(RetourFactory.createOkRetour(), RavelJsonTools.getInstance().toJson(reponse, PE0274_BL201GetReponse.class));
  }

  /**
   * PE0274_BL202_LireOptionInterdictionDepotMessage
   *
   * @param tracabilite_p
   *          tracabilite
   * @param idMessagerie_p
   *          idMessagerie
   * @param modeAppel_p
   *          modeAppel
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessageriePfs
   * @return Pair of {@link Retour} and {@link PE0274_BL202GetReponse}
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Retour, String> PE0274_BL202_LireOptionInterdictionDepotMessage(Tracabilite tracabilite_p, String idMessagerie_p, String modeAppel_p, String typePfs_p, String idMessageriePfs_p) throws RavelException
  {
    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);

    Pair<Retour, ResponseConnector> returnSI002 = executeSI002(tracabilite_p, PROCESS_CONSULTER_INTERDICTION_DEPOT, listeParametres, 10);
    if (!isRetourOK(returnSI002._first))
    {
      return new Pair<>(returnSI002._first, null);
    }

    ReponseFonctionnelle<AppelantsInterditsPfs> responseFonctionnelle = returnSI002._second.getReponseFonctionnelle(AppelantsInterditsPfs.class);
    PE0274_BL202GetReponse reponse = new PE0274_BL202GetReponse();
    reponse.setAppelantsInterdits(responseFonctionnelle.getItems().get(0).getAppelantsInterdits());
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(modeAppel_p))
    {
      reponse.putLink(XLink.SELF, new XLink(URL_MESSAGERIES + idMessagerie_p + URL_INTERDICTIONS_DEPOT_MESSAGES));
      reponse.putAction("modifierInterdictionsDepotMessages", new XAction(URL_MESSAGERIES + idMessagerie_p + URL_INTERDICTIONS_DEPOT_MESSAGES, MediaType.APPLICATION_JSON, HttpMethod.PUT)); //$NON-NLS-1$
    }
    return new Pair<>(RetourFactory.createOkRetour(), RavelJsonTools.getInstance().toJson(reponse, PE0274_BL202GetReponse.class));
  }

  /**
   * PE0274_BL203_LireOptionNotificationEmail
   *
   * @param tracabilite_p
   *          tracabilite
   * @param idMessagerie_p
   *          idMessagerie
   * @param modeAppel_p
   *          modeAppel
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessageriePfs
   * @return Pair of {@link Retour} and {@link PE0274_BL203GetReponse}
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Retour, String> PE0274_BL203_LireOptionNotificationEmail(Tracabilite tracabilite_p, String idMessagerie_p, String modeAppel_p, String typePfs_p, String idMessageriePfs_p) throws RavelException
  {
    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);

    Pair<Retour, ResponseConnector> returnSI002 = executeSI002(tracabilite_p, PROCESS_CONSULTER_NOTIFICATION_EMAIL, listeParametres, 10);
    if (!isRetourOK(returnSI002._first))
    {
      return new Pair<>(returnSI002._first, null);
    }

    ReponseFonctionnelle<NotificationEmailPfs> responseFonctionnelle = returnSI002._second.getReponseFonctionnelle(NotificationEmailPfs.class);
    PE0274_BL203GetReponse reponse = new PE0274_BL203GetReponse();
    reponse.setStatutNotificationsEmail(responseFonctionnelle.getItems().get(0).getStatutNotificationsEmail());
    reponse.setNotificationsEmail(responseFonctionnelle.getItems().get(0).getNotificationsEmail());
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(modeAppel_p))
    {
      reponse.putLink(XLink.SELF, new XLink(URL_MESSAGERIES + idMessagerie_p + URL_NOTIFICATIONS_EMAIL));
      reponse.putAction("modifierNotificationsEmail", new XAction(URL_MESSAGERIES + idMessagerie_p + URL_NOTIFICATIONS_EMAIL, MediaType.APPLICATION_JSON, HttpMethod.PUT)); //$NON-NLS-1$
    }
    return new Pair<>(RetourFactory.createOkRetour(), RavelJsonTools.getInstance().toJson(reponse, PE0274_BL203GetReponse.class));
  }

  /**
   * PE0274_BL204_LireOptionNotificationSMS
   *
   * @param tracabilite_p
   *          tracabilite
   * @param idMessagerie_p
   *          idMessagerie
   * @param modeAppel_p
   *          modeAppel
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessageriePfs
   * @return Pair of {@link Retour} and {@link PE0274_BL204GetReponse}
   * @throws RavelException
   *           exception
   */
  @LogProcessBL
  private Pair<Retour, String> PE0274_BL204_LireOptionNotificationSMS(Tracabilite tracabilite_p, String idMessagerie_p, String modeAppel_p, String typePfs_p, String idMessageriePfs_p) throws RavelException
  {
    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);

    Pair<Retour, ResponseConnector> returnSI002 = executeSI002(tracabilite_p, PROCESS_CONSULTER_NOTIFICATION_SMS, listeParametres, 10);
    if (!isRetourOK(returnSI002._first))
    {
      return new Pair<>(returnSI002._first, null);
    }

    ReponseFonctionnelle<NotificationSmsPfs> responseFonctionnelle = returnSI002._second.getReponseFonctionnelle(NotificationSmsPfs.class);
    PE0274_BL204GetReponse reponse = new PE0274_BL204GetReponse();
    reponse.setStatutNotificationsSMS(responseFonctionnelle.getItems().get(0).getStatutNotificationsSMS());
    reponse.setNotificationsSMS(responseFonctionnelle.getItems().get(0).getNotificationsSMS());
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(modeAppel_p))
    {
      reponse.putLink(XLink.SELF, new XLink(URL_MESSAGERIES + idMessagerie_p + URL_NOTIFICATIONS_SMS));
      reponse.putAction("modifierNotificationsSMS", new XAction(URL_MESSAGERIES + idMessagerie_p + URL_NOTIFICATIONS_SMS, MediaType.APPLICATION_JSON, HttpMethod.PUT)); //$NON-NLS-1$
    }
    return new Pair<>(RetourFactory.createOkRetour(), RavelJsonTools.getInstance().toJson(reponse, PE0274_BL204GetReponse.class));
  }

  /**
   * Cette activité permet de modifier la ressource messagerie ou une de ses sous-ressources.
   *
   * @param idMessagerie_p
   *          idMessagerie encrypte
   * @param modeAppel_p
   *          modeAppel
   * @param typeOperation_p
   *          typeOperation
   * @param listeContratOauth_p
   *          listeContratOauth
   *
   * @return {@link Retour}
   */
  @LogProcessBL
  private Retour PE0274_BL300_PreparerModifierMessagerie(String idMessagerie_p, String modeAppel_p, OperationMessageries typeOperation_p, List<String> listeContratOauth_p)
  {
    String idMessagerieDecrypted, noContrat, typeMessagerie;

    // Déchiffrer idMessagerie
    try
    {
      idMessagerieDecrypted = PasswordDecrypter.decryptForURL(idMessagerie_p);
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, MESSAGE_ERROR_DECRYPTING_ID_MESSAGERIE, e));
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGERIE_INCONNU, idMessagerie_p));
    }

    //décodage d'idMessagerie
    String[] parametresMessagerie = idMessagerieDecrypted.split(SEPARATOR_ID_MESSAGERIE);
    if (parametresMessagerie.length == 4)
    {
      noContrat = parametresMessagerie[0];
      _processContext.setIdMessageriePfs(parametresMessagerie[1]);
      typeMessagerie = parametresMessagerie[2];
      _processContext.setTypePfs(parametresMessagerie[3]);
    }
    else
    {
      return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ID_MESSAGERIE_INCONNU, MessageFormat.format(MESSAGE_ID_MESSAGERIE_INCONNU, idMessagerie_p));
    }

    //La valorisation de sTypeOperation en fonction de metadata.SOUS-RESSOURCE est fait dans la BL001_VerifierDonneesModification

    // Contrôler que l’opération demandée est autorisée sur le type de messagerie
    Autorisation autorisation = null;
    OperationMessageries operation = null;
    for (Autorisation aut : _processContext.getConfigurationPE0274().getOperationOptionMessagerieAutorisee().getAutorisation())
    {
      if (typeMessagerie.equalsIgnoreCase(aut.getTypeMessagerie()))
      {
        autorisation = aut;
        break;
      }
    }

    if (autorisation != null)
    {
      for (String op : autorisation.getOperations())
      {
        if (typeOperation_p.getValue().equalsIgnoreCase(op))
        {
          operation = typeOperation_p;
          break;
        }
      }
    }

    if ((autorisation == null) || (operation == null))
    {
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_OPERATION_NON_AUTORISEE, idMessagerie_p));
    }

    // Contrôle des autorisations sur le numéro contrat dans le cas d'un appel via B2R
    if (IMetadata.CANAL_B2R.equalsIgnoreCase(modeAppel_p))
    {
      if ((listeContratOauth_p.isEmpty()) || !listeContratOauth_p.contains(noContrat))
      {
        return RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, MESSAGE_ACCES_REFUSE);
      }
    }
    return RetourFactory.createOkRetour();
  }

  /**
   * ModifierStatutMessagerie
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessageriePfs
   *
   * @return {@link Retour}
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Retour PE0274_BL301_ModifierStatutMessagerie(Tracabilite tracabilite_p, String typePfs_p, String idMessageriePfs_p) throws RavelException
  {
    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);

    if (_processContext.getStatutMessagerie() != null)
    {
      listeParametres.add(STATUT_MESSAGERIE, _processContext.getStatutMessagerie());
    }

    if (_processContext.getStatutRappel() != null)
    {
      listeParametres.add(STATUT_RAPPEL, _processContext.getStatutRappel());
    }

    return executeSI002(tracabilite_p, OperationMessageries.MODIFIER_STATUT_MESSAGERIE.getValue(), listeParametres, 10)._first;
  }

  /**
   * ModifierInterdictionsDepotMessages
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessageriePfs
   *
   * @return {@link Retour}
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Retour PE0274_BL302_ModifierInterdictionsDepotMessages(Tracabilite tracabilite_p, String typePfs_p, String idMessageriePfs_p) throws RavelException
  {
    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);

    for (AppelantInterdit appelantInterdit : _processContext.getAppelantsInterdits())
    {
      listeParametres.add(NO_TELEPHONE, appelantInterdit.getNoTelephone());
      if (StringTools.isNotNullOrEmpty(appelantInterdit.getNom()))
      {
        listeParametres.add(NOM, appelantInterdit.getNom());
      }
    }

    return executeSI002(tracabilite_p, OperationMessageries.MODIFIER_INTERDICTIONS_DEPOT_MESSAGES.getValue(), listeParametres, 10)._first;
  }

  /**
   * ModifierCodePin
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessageriePfs
   * @param codePin_p
   *          codePin
   *
   * @return {@link Retour}
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Retour PE0274_BL303_ModifierCodePin(Tracabilite tracabilite_p, String typePfs_p, String idMessageriePfs_p, String codePin_p) throws RavelException
  {
    //La recuperation de la valeur du paramètre "action" est fait dans la BL001_VerifierDonneesModification

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);
    listeParametres.add(ACTION, _processContext.getAction());
    if (ACTION_MODIFIER_CODE_PIN.equals(_processContext.getAction()))
    {
      listeParametres.add(CODE_PIN, codePin_p);
    }

    return executeSI002(tracabilite_p, OperationMessageries.MODIFIER_CODE_PIN.getValue(), listeParametres, 10)._first;
  }

  /**
   * ModifierNotificationsEmail
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessageriePfs
   *
   * @return Retour
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Retour PE0274_BL304_ModifierNotificationsEmail(Tracabilite tracabilite_p, String typePfs_p, String idMessageriePfs_p) throws RavelException
  {
    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);

    if (StringTools.isNotNullOrEmpty(_processContext.getStatutNotificationsEmail()))
    {
      listeParametres.add(STATUT_NOTIFICATIONS_EMAIL, _processContext.getStatutNotificationsEmail());
    }
    for (NotificationEmail notificationEmail : _processContext.getNotificationsEmail())
    {
      listeParametres.add(ADRESSE_EMAIL, notificationEmail.getAdresseEmail());
      listeParametres.add(EMAIL_TECHNIQUE, Boolean.toString(notificationEmail.isEmailTechnique()));
      listeParametres.add(PIECE_JOINTE, Boolean.toString(notificationEmail.isPieceJointe()));
    }

    return executeSI002(tracabilite_p, OperationMessageries.MODIFIER_NOTIFICATIONS_EMAIL.getValue(), listeParametres, 10)._first;
  }

  /**
   * ModifierMessageriesADistance
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessageriePfs
   *
   * @return {@link Retour}
   * @throws RavelException
   *           On error
   */
  @LogProcessBL
  private Retour PE0274_BL305_ModifierMessageriesADistance(Tracabilite tracabilite_p, String typePfs_p, String idMessageriePfs_p) throws RavelException
  {
    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);

    for (Destinataire destinataire : _processContext.getDestinataires())
    {
      listeParametres.add(NO_TELEPHONE, destinataire.getNoTelephone());
    }

    return executeSI002(tracabilite_p, OperationMessageries.MODIFIER_MESSAGERIES_A_DISTANCE.getValue(), listeParametres, 10)._first;
  }

  /**
   * GestionVVM
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessagerie
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PE0274_BL306_GestionVVM(Tracabilite tracabilite_p, String typePfs_p, String idMessageriePfs_p) throws RavelException
  {
    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);
    listeParametres.add(ACTION, _processContext.getAction());
    return executeSI002(tracabilite_p, OperationMessageries.GESTION_VVM.getValue(), listeParametres, 10)._first;
  }

  /**
   * ModifierNotificationsSMS
   *
   * @param tracabilite_p
   *          tracabilite
   * @param typePfs_p
   *          typePfs
   * @param idMessageriePfs_p
   *          idMessageriePfs
   * @return Retour
   * @throws RavelException
   *           on error
   */
  @LogProcessBL
  private Retour PE0274_BL307_ModifierNotificationsSMS(Tracabilite tracabilite_p, String typePfs_p, String idMessageriePfs_p) throws RavelException
  {
    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, idMessageriePfs_p);
    listeParametres.add(TYPE_PFS, typePfs_p);
    listeParametres.add(STATUT_NOTIFICATIONS_SMS, _processContext.getStatutNotificationsSMS());
    for (NotificationSMS notificationSMS : _processContext.getNotificationsSMS())
    {
      listeParametres.add(NO_TELEPHONE, notificationSMS.getNoTelephone());
    }
    return executeSI002(tracabilite_p, OperationMessageries.MODIFIER_NOTIFICATIONS_SMS.getValue(), listeParametres, 10)._first;
  }
}