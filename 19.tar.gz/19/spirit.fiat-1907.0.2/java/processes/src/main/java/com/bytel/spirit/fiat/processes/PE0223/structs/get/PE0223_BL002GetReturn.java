/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223.structs.get;

import com.bytel.spirit.common.shared.misc.error.ReponseErreur;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PE0223_BL002GetReturn
{
  /**
   * Le reponse erreur
   */
  private ReponseErreur _reponseErreur;

  /**
   * Le reponse du process
   */
  private PE0223_GetResponse _pe0223getRetour;

  /**
   * @param reponseErreur_p
   *          The error reponse
   * @param pe0223getRetour_p
   *          The reponse
   */
  public PE0223_BL002GetReturn(ReponseErreur reponseErreur_p, PE0223_GetResponse pe0223getRetour_p)
  {
    _reponseErreur = reponseErreur_p;
    _pe0223getRetour = pe0223getRetour_p;
  }

  /**
   * @return value of pe0223getRetour
   */
  public PE0223_GetResponse getPe0223getRetour()
  {
    return _pe0223getRetour;
  }

  /**
   * @return value of reponseErreur
   */
  public ReponseErreur getReponseErreur()
  {
    return _reponseErreur;
  }

  /**
   * @param pe0223getRetour_p
   *          The pe0223getRetour to set.
   */
  public void setPe0223getRetour(PE0223_GetResponse pe0223getRetour_p)
  {
    _pe0223getRetour = pe0223getRetour_p;
  }

  /**
   * @param reponseErreur_p
   *          The reponseErreur to set.
   */
  public void setReponseErreur(ReponseErreur reponseErreur_p)
  {
    _reponseErreur = reponseErreur_p;
  }
}
