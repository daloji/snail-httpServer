/*******************************************************************************
* $Id: PE0298_Ressource.java 17459 2019-02-20 15:49:20Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0298.sti;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;
import com.squareup.moshi.Json;

/**
 *
 * @author jramos
 * @version ($Revision: 17459 $ $Date: 2019-02-20 16:49:20 +0100 (mer. 20 févr. 2019) $)
 */
public final class PE0298_Ressource implements Serializable
{

  /**
   *
   * @EtatAllocation
   *
   */
  public enum EtatAllocation
  {
    /**
     * REALISE
     */
    REALISE,
    /**
     * ECHEC
     */
    ECHEC,
    /**
     * EN_COURS
     */
    EN_COURS;
  }

  /**
   *
   * @EtatRessource
   *
   */
  public enum EtatRessource
  {
    /**
     * LIBRE
     */
    LIBRE,
    /**
     * BLACKLISTE
     */
    BLACKLISTE,
    /**
     * PROPOSE
     */
    PROPOSE,
    /**
     * RESERVE
     */
    RESERVE,
    /**
     * ALLOUE
     */
    ALLOUE,
    /**
     * GELE
     */
    GELE,
    /**
     * QUARANTAINE
     */
    QUARANTAINE;
  }

  /**
   *
   * @TypeRessource
   *
   */
  public enum TypeRessource
  {
    /**
     * NUMERO_TELEPHONE
     */
    NUMERO_TELEPHONE;
  }

  /**
   *
   */
  private static final long serialVersionUID = -467814801600941137L;

  /**
   * Type de Ressource
   */
  @SerializedName("typeRessource")
  @Json(name = "typeRessource")
  private String _typeRessource;

  /**
   * Etat de la Ressource
   */
  @SerializedName("etatRessource")
  @Json(name = "etatRessource")
  private String _etatRessource;

  /**
   * Etat allocation Ressource
   */
  @SerializedName("etatAllocation")
  @Json(name = "etatAllocation")
  private String _etatAllocation;

  /**
   * Default Constructor
   */
  public PE0298_Ressource()
  {
    super();
  }

  /**
   * @param typeRessource_p
   *          typeRessource
   * @param etatRessource_p
   *          etatRessource
   * @param etatAllocation_p
   *          etatAllocation
   */
  public PE0298_Ressource(String typeRessource_p, String etatRessource_p, String etatAllocation_p)
  {
    super();
    _typeRessource = typeRessource_p;
    _etatRessource = etatRessource_p;
    _etatAllocation = etatAllocation_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0298_Ressource other = (PE0298_Ressource) obj;
    if (_etatAllocation == null)
    {
      if (other._etatAllocation != null)
      {
        return false;
      }
    }
    else if (!_etatAllocation.equals(other._etatAllocation))
    {
      return false;
    }
    if (_etatRessource == null)
    {
      if (other._etatRessource != null)
      {
        return false;
      }
    }
    else if (!_etatRessource.equals(other._etatRessource))
    {
      return false;
    }
    if (_typeRessource == null)
    {
      if (other._typeRessource != null)
      {
        return false;
      }
    }
    else if (!_typeRessource.equals(other._typeRessource))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the etatAllocation
   */
  public String getEtatAllocation()
  {
    return _etatAllocation;
  }

  /**
   * @return the etatRessource
   */
  public String getEtatRessource()
  {
    return _etatRessource;
  }

  /**
   * @return the typeRessource
   */
  public String getTypeRessource()
  {
    return _typeRessource;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_etatAllocation == null) ? 0 : _etatAllocation.hashCode());
    result = (prime * result) + ((_etatRessource == null) ? 0 : _etatRessource.hashCode());
    result = (prime * result) + ((_typeRessource == null) ? 0 : _typeRessource.hashCode());
    return result;
  }

  /**
   * @param etatAllocation_p
   *          the etatAllocation to set
   */
  public void setEtatAllocation(String etatAllocation_p)
  {
    _etatAllocation = etatAllocation_p;
  }

  /**
   * @param etatRessource_p
   *          the etatRessource to set
   */
  public void setEtatRessource(String etatRessource_p)
  {
    _etatRessource = etatRessource_p;
  }

  /**
   * @param typeRessource_p
   *          the typeRessource to set
   */
  public void setTypeRessource(String typeRessource_p)
  {
    _typeRessource = typeRessource_p;
  }

  @Override
  public String toString()
  {
    return "Ressource [_typeRessource=" + _typeRessource + ", _etatRessource=" + _etatRessource + ", _etatAllocation=" + _etatAllocation + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
  }
}
