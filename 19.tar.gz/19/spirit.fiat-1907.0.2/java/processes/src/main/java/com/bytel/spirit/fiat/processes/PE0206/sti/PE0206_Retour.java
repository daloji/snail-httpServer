/*******************************************************************************
 * $Id: PE0206_Retour.java 14970 2018-12-20 12:34:16Z jiantila $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206.sti;

import static java.util.Objects.isNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 14970 $ $Date: 2018-12-20 13:34:16 +0100 (jeu., 20 déc. 2018) $)
 */
public class PE0206_Retour implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * OI
   */
  @SerializedName("OI")
  @Expose
  private String _oi;

  /**
   * mutationPossible
   */
  @SerializedName("mutationPossible")
  @Expose
  private Boolean _mutationPossible;
  /**
   * refPrestationPrise
   */
  @SerializedName("refPrestationPrise")
  @Expose
  private String _refPrestationPrise;

  /**
   * typeIntervention
   */
  @SerializedName("typeIntervention")
  @Expose
  private String _typeIntervention;

  /**
   * adresse
   */
  @SerializedName("adresse")
  @Expose
  private PE0206_Adresse _adresse;

  /**
   * complementAdresse
   */
  @SerializedName("complementAdresse")
  @Expose
  private PE0206_ComplementAdresse _complementAdresse;
  /**
   * referencePM
   */
  @SerializedName("referencePM")
  @Expose
  private String _referencePM;
  /**
   * referencePBO
   */
  @SerializedName("referencePBO")
  @Expose
  private String _referencePBO;

  /**
   * adressePBO
   */
  @SerializedName("adressePBO")
  @Expose
  private PE0206_Adresse _adressePbo;

  /**
   * listeRouteOptique
   */
  @SerializedName("listeRouteOptique")
  @Expose
  private List<PE0206_RouteOptique> _listeRouteOptique;
  /**
   * priseExisante
   */
  @SerializedName("priseExisante")
  @Expose
  private Boolean _priseExisante;

  /**
   * priseExisante
   */
  @SerializedName("dateDispo")
  @Expose
  private String _dateDispo;

  /**
   * @return the adresse
   */
  public PE0206_Adresse getAdresse()
  {
    return _adresse;
  }

  /**
   * @return the adressePbo
   */
  public PE0206_Adresse getAdressePbo()
  {
    return _adressePbo;
  }

  /**
   * @return the complementAdresse
   */
  public PE0206_ComplementAdresse getComplementAdresse()
  {
    return _complementAdresse;
  }

  /**
   * @return the dateDispo
   */
  public String getDateDispo()
  {
    return _dateDispo;
  }

  /**
   * @return the listeRouteOptique
   */
  public List<PE0206_RouteOptique> getListeRouteOptique()
  {

    if (isNull(_listeRouteOptique))
    {
      return null;
    }
    return Collections.unmodifiableList(_listeRouteOptique);
  }

  /**
   * @return the mutationPossible
   */
  public Boolean getMutationPossible()
  {
    return _mutationPossible;
  }

  /**
   * @return the oi
   */
  public String getOi()
  {
    return _oi;
  }

  /**
   * @return the priseExisante
   */
  public boolean getPriseExisante()
  {
    return _priseExisante;
  }

  /**
   * @return the referencePBO
   */
  public String getReferencePBO()
  {
    return _referencePBO;
  }

  /**
   * @return the referencePM
   */
  public String getReferencePM()
  {
    return _referencePM;
  }

  /**
   * @return the refPrestationPrise
   */
  public String getRefPrestationPrise()
  {
    return _refPrestationPrise;
  }

  /**
   * @return the typeIntervention
   */
  public String getTypeIntervention()
  {
    return _typeIntervention;
  }

  /**
   * @return the mutationPossible
   */
  public boolean isMutationPossible()
  {
    return _mutationPossible;
  }

  /**
   * @param adresse_p
   *          the adresse to set
   */
  public void setAdresse(PE0206_Adresse adresse_p)
  {
    _adresse = adresse_p;
  }

  /**
   * @param adressePbo_p
   *          the adressePbo to set
   */
  public void setAdressePbo(PE0206_Adresse adressePbo_p)
  {
    _adressePbo = adressePbo_p;
  }

  /**
   * @param complementAdresse_p
   *          the complementAdresse to set
   */
  public void setComplementAdresse(PE0206_ComplementAdresse complementAdresse_p)
  {
    _complementAdresse = complementAdresse_p;
  }

  /**
   * @param dateDispo_p
   *          the dateDispo to set
   */
  public void setDateDispo(String dateDispo_p)
  {
    _dateDispo = dateDispo_p;
  }

  /**
   * @param listeRouteOptique_p
   *          the listeRouteOptique to set
   */
  public void setListeRouteOptique(List<PE0206_RouteOptique> listeRouteOptique_p)
  {

    if (isNull(listeRouteOptique_p))
    {
      _listeRouteOptique = null;
    }
    else
    {
      _listeRouteOptique = new ArrayList<>(listeRouteOptique_p);
    }
  }

  /**
   * @param mutationPossible_p
   *          the mutationPossible to set
   */
  public void setMutationPossible(boolean mutationPossible_p)
  {
    _mutationPossible = mutationPossible_p;
  }

  /**
   * @param mutationPossible_p
   *          the mutationPossible to set
   */
  public void setMutationPossible(Boolean mutationPossible_p)
  {
    _mutationPossible = mutationPossible_p;
  }

  /**
   * @param oi_p
   *          the oi to set
   */
  public void setOi(String oi_p)
  {
    _oi = oi_p;
  }

  /**
   * @param priseExisante_p
   *          the priseExisante to set
   */
  public void setPriseExisante(boolean priseExisante_p)
  {
    _priseExisante = priseExisante_p;
  }

  /**
   * @param priseExisante_p
   *          the priseExisante to set
   */
  public void setPriseExisante(Boolean priseExisante_p)
  {
    _priseExisante = priseExisante_p;
  }

  /**
   * @param referencePBO_p
   *          the referencePBO to set
   */
  public void setReferencePBO(String referencePBO_p)
  {
    _referencePBO = referencePBO_p;
  }

  /**
   * @param referencePM_p
   *          the referencePM to set
   */
  public void setReferencePM(String referencePM_p)
  {
    _referencePM = referencePM_p;
  }

  /**
   * @param refPrestationPrise_p
   *          the refPrestationPrise to set
   */
  public void setRefPrestationPrise(String refPrestationPrise_p)
  {
    _refPrestationPrise = refPrestationPrise_p;
  }

  /**
   * @param typeIntervention_p
   *          the typeIntervention to set
   */
  public void setTypeIntervention(String typeIntervention_p)
  {
    _typeIntervention = typeIntervention_p;
  }

}
