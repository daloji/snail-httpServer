/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0275.structs;

import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_GetBL100Reponse;

/**
 *
 * @author vloureir
 * @version ($Revision$ $Date$)
 */
public class PE0275_BL002GetReturn
{
  /**
   * Le reponse erreur
   */
  private ReponseErreur _reponseErreur;

  /**
   * Le reponse du process Lister
   */
  private PE0275_GetBL100Reponse _pe0275BL100Retour;

  /**
   * Le reponse du process Telecharger
   */
  private byte[] _contenuMedia;

  /**
   * @param reponseErreur_p
   *          reponseErreur
   * @param pe0275bl100Retour_p
   *          PE0275bl100Retour
   */
  public PE0275_BL002GetReturn(ReponseErreur reponseErreur_p, PE0275_GetBL100Reponse pe0275bl100Retour_p, byte[] contenuMedia_p)
  {
    super();
    _reponseErreur = reponseErreur_p;
    _pe0275BL100Retour = pe0275bl100Retour_p;
    _contenuMedia = contenuMedia_p == null ? null : contenuMedia_p.clone();
  }

  /**
   * @return the contenuMedia
   */
  public byte[] getContenuMedia()
  {
    return _contenuMedia == null ? null : _contenuMedia.clone();
  }

  /**
   * @return the PE0275BL100Retour
   */
  public PE0275_GetBL100Reponse getPE0275BL100Retour()
  {
    return _pe0275BL100Retour;
  }

  /**
   * @return the reponseErreur
   */
  public ReponseErreur getReponseErreur()
  {
    return _reponseErreur;
  }

  /**
   * @param contenuMedia_p
   *          the contenuMedia to set
   */
  public void setContenuMedia(byte[] contenuMedia_p)
  {
    _contenuMedia = contenuMedia_p == null ? null : contenuMedia_p.clone();
  }

  /**
   * @param pe0275bl100Retour_p
   *          the PE0275BL100Retour to set
   */
  public void setPE0275BL100Retour(PE0275_GetBL100Reponse pe0275bl100Retour_p)
  {
    _pe0275BL100Retour = pe0275bl100Retour_p;
  }

  /**
   * @param reponseErreur_p
   *          the reponseErreur to set
   */
  public void setReponseErreur(ReponseErreur reponseErreur_p)
  {
    _reponseErreur = reponseErreur_p;
  }

}
