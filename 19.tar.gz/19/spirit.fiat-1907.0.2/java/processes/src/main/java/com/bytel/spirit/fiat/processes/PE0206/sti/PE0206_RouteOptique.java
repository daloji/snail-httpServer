/*******************************************************************************
* $Id: PE0206_RouteOptique.java 14745 2018-12-17 14:04:01Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206.sti;

import java.io.Serializable;

import com.bytel.spirit.fiat.shared.types.json.Fibre;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 14745 $ $Date: 2018-12-17 15:04:01 +0100 (lun., 17 déc. 2018) $)
 */
public class PE0206_RouteOptique implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /** The OC. */
  @SerializedName("OC")
  @Expose
  private String _oc;

  /** The positionPM. */
  @SerializedName("PositionPM")
  @Expose
  private PE0206_PositionPMType _positionPM;

  /** The connecteurPriseNumero. */
  @SerializedName("ConnecteurPriseNumero")
  @Expose
  private Integer _connecteurPriseNumero;

  /** The connecteurPriseCouleur. */
  @SerializedName("ConnecteurPriseCouleur")
  @Expose
  private String _connecteurPriseCouleur;

  /**
   * Fibre
   */
  @SerializedName("Fibre")
  @Expose
  private Fibre _fibre;

  /**
   * @return the connecteurPriseCouleur
   */
  public String getConnecteurPriseCouleur()
  {
    return _connecteurPriseCouleur;
  }

  /**
   * @return the connecteurPriseNumero
   */
  public Integer getConnecteurPriseNumero()
  {
    return _connecteurPriseNumero;
  }

  /**
   * @return the fibre
   */
  public Fibre getFibre()
  {
    return _fibre;
  }

  /**
   * @return the oc
   */
  public String getOc()
  {
    return _oc;
  }

  /**
   * @return the positionPM
   */
  public PE0206_PositionPMType getPositionPM()
  {
    return _positionPM;
  }

  /**
   * @param connecteurPriseCouleur_p
   *          the connecteurPriseCouleur to set
   */
  public void setConnecteurPriseCouleur(String connecteurPriseCouleur_p)
  {
    _connecteurPriseCouleur = connecteurPriseCouleur_p;
  }

  /**
   * @param connecteurPriseNumero_p
   *          the connecteurPriseNumero to set
   */
  public void setConnecteurPriseNumero(Integer connecteurPriseNumero_p)
  {
    _connecteurPriseNumero = connecteurPriseNumero_p;
  }

  /**
   * @param fibre_p
   *          the fibre to set
   */
  public void setFibre(Fibre fibre_p)
  {
    _fibre = fibre_p;
  }

  /**
   * @param oc_p
   *          the oc to set
   */
  public void setOc(String oc_p)
  {
    _oc = oc_p;
  }

  /**
   * @param positionPM_p
   *          the positionPM to set
   */
  public void setPositionPM(PE0206_PositionPMType positionPM_p)
  {
    _positionPM = positionPM_p;
  }

}
