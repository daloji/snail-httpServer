/*******************************************************************************
* $Id: PE0206_HexacleVoie.java 16650 2019-02-04 14:57:47Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206.sti;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 16650 $ $Date: 2019-02-04 15:57:47 +0100 (lun., 04 févr. 2019) $)
 */
public class PE0206_HexacleVoie implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * codeHexacleVoie
   */
  @SerializedName("codeHexacleVoie")
  @Expose
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  @Size(min = 1, max = 10, message = IMessageFormatKeys.INVALID_FORMAT)
  private String _codeHexacleVoie;

  /**
   * numeroVoie
   */
  @SerializedName("numeroVoie")
  @Expose
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  @Min(value = 0, message = IMessageFormatKeys.INVALID_FORMAT)
  private Integer _numeroVoie;

  /**
   * complementNumeroVoie
   */
  @SerializedName("complementNumeroVoie")
  @Expose
  private String _complementNumeroVoie;

  /**
   * @return the codeHexacleVoie
   */
  public String getCodeHexacleVoie()
  {
    return _codeHexacleVoie;
  }

  /**
   * @return the complementNumeroVoie
   */
  public String getComplementNumeroVoie()
  {
    return _complementNumeroVoie;
  }

  /**
   * @return the numeroVoie
   */
  public Integer getNumeroVoie()
  {
    return _numeroVoie;
  }

  /**
   * @param codeHexacleVoie_p
   *          the codeHexacleVoie to set
   */
  public void setCodeHexacleVoie(String codeHexacleVoie_p)
  {
    _codeHexacleVoie = codeHexacleVoie_p;
  }

  /**
   * @param complementNumeroVoie_p
   *          the complementNumeroVoie to set
   */
  public void setComplementNumeroVoie(String complementNumeroVoie_p)
  {
    _complementNumeroVoie = complementNumeroVoie_p;
  }

  /**
   * @param numeroVoie_p
   *          the numeroVoie to set
   */
  public void setNumeroVoie(Integer numeroVoie_p)
  {
    _numeroVoie = numeroVoie_p;
  }

}
