/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0145;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionTools;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.process.AbstractBLReturn;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.types.json.request.ServiceMailRequest;
import com.bytel.spirit.common.shared.types.json.request.ServiceMailTransfertRequest;
import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.bytel.spirit.fiat.processes.Messages;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
public class PE0145_TransfertContenuBoiteMailBouchon extends SpiritProcessSkeleton
{
  /**
   * Process context
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public static final class PE0145_TransfertContenuBoiteMailContext extends Context
  {

    /**
     * The generated UID
     */
    private static final long serialVersionUID = 4018142641825841458L;
    /***
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0145_BL001;

    /**
     * The clientOperateur from header
     */
    private String _xClientOperateur;

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @return the xClientOperateur
     */
    public String getXClientOperateur()
    {
      return _xClientOperateur;
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

    /**
     * @param xClientOperateur_p
     *          the xClientOperateur to set
     */
    public void setXClientOperateur(String xClientOperateur_p)
    {
      _xClientOperateur = xClientOperateur_p;
    }

  }

  /**
   * The Enum containing all process states
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  public enum State
  {
    /**
     * Verifier_Donnes
     */
    PE0145_BL001(MandatoryProcessState.PRC_START, false, false),
    /**
     * Formater_Reponse
     */
    PE0145_BL002(MandatoryProcessState.PRC_RUNNING, false, false),
    /**
     * Terminal state.
     */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          is replayable state
     * @param asynchronous_p
     *          is asynchronous state
     */
    private State(final MandatoryProcessState technicalState_p, boolean replayable_p, boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }
  }

  /**
   * Defines the structure of the returned object in PEI0042_BL001_VerifierDonnes
   *
   * @author jgregori
   * @version ($Revision$ $Date$)
   */
  static class BL001_VerifierDonneesReturn extends AbstractBLReturn
  {

    /**
     * Generated UID
     */
    private static final long serialVersionUID = 3210771927349438155L;

    /**
     * @param retour_p
     *          retour
     */
    public BL001_VerifierDonneesReturn(Retour retour_p)
    {
      super(retour_p);
    }

  }

  /**
   * The generated UID
   */
  private static final long serialVersionUID = 1323492390814662192L;

  /**
   * The process context.
   */
  private PE0145_TransfertContenuBoiteMailContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour retour_p) throws RavelException
  {
    return ""; //$NON-NLS-1$
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    _processContext = new PE0145_TransfertContenuBoiteMailContext();
  }

  @Override
  public boolean isAsynchronous()
  {
    return _processContext.getState()._asynchronousState;
  }

  @Override
  public boolean isReplayable()
  {
    return _processContext.getState()._replayableState;
  }

  @Override
  protected void continueProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    //do nothing

  }

  @Override
  protected void exitKOMetroLog(String reason_p)
  {
    // Not required for now in Ravel

  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel

  }

  @Override
  @LogProcessBL
  protected void startProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    BL001_VerifierDonneesReturn bl001Result = PE0145_BL001_VerifierDonnes(request_p, tracabilite_p);
    _processContext.setState(State.PE0145_BL002);
    ReponseErreur reponseErreur = PE0145_BL002_FormaterReponse(bl001Result.getRetour(), tracabilite_p);
    _processContext.setState(State.ENDED);
    syncResponse(request_p, tracabilite_p, reponseErreur);
  }

  /**
   * @param tracabilite_p
   *          The trace
   * @param request_p
   *          The request
   *
   * @return The retour
   */
  private Retour checkHeaders(Tracabilite tracabilite_p, final Request request_p)
  {
    String clientOperateur = null;
    String source = null;
    String process = null;

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_CLIENT_OPERATEUR.equalsIgnoreCase(header.getName()))
      {
        clientOperateur = header.getValue();
      }
      else if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        process = header.getValue();
      }
      else if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        source = header.getValue();
      }
    }

    if (StringTools.isNullOrEmpty(clientOperateur))
    {
      String libelleErreur = MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_CLIENT_OPERATEUR); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }
    if (StringTools.isNullOrEmpty(source))
    {
      String libelleErreur = MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_SOURCE); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }
    if (StringTools.isNullOrEmpty(process))
    {
      String libelleErreur = MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_PROCESS); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }
    if (StringTools.isNullOrEmpty(tracabilite_p.getIdCorrelationByTel()))
    {
      String libelleErreur = MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID); //$NON-NLS-1$
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, libelleErreur));
      return RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur);
    }

    _processContext.setXClientOperateur(clientOperateur);

    return RetourFactory.createOkRetour();
  }

  /**
   * Validates Json object received in the request parameter.
   *
   * @param request_p
   *          The request
   * @param tracabilite_p
   *          Tracabilite
   * @return PE0145_BL001_verifierDonnesReturn
   * @throws RavelException
   *           Thrown If bl1700 throws RavelException
   */
  @LogProcessBL
  private BL001_VerifierDonneesReturn PE0145_BL001_VerifierDonnes(final Request request_p, Tracabilite tracabilite_p) throws RavelException
  {
    Retour retour = RetourFactory.createOkRetour();

    ServiceMailTransfertRequest serviceMailTransfertRequest = null;
    try
    {
      retour = checkHeaders(tracabilite_p, request_p);

      //check STI
      if (isRetourOK(retour))
      {
        serviceMailTransfertRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ, DateTimeFormatPattern.yyyy_dash_MM_dash_dd).fromJson(request_p.getPayload(), ServiceMailTransfertRequest.class);
      }
    }
    catch (Exception e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, Messages.getString("PE0145.BL001.StiError") + "\\n" + ExceptionTools.getStringStackTrace(e))); //$NON-NLS-1$ //$NON-NLS-2$

      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0145.BL001.StiError")); //$NON-NLS-1$
    }

    if (serviceMailTransfertRequest != null)
    {
      ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
      Validator validator = factory.getValidator();
      Set<ConstraintViolation<ServiceMailRequest>> constraintViolations = validator.validate(serviceMailTransfertRequest);

      if (!constraintViolations.isEmpty())
      {
        StringBuilder requiredAttrSb = new StringBuilder();
        StringBuilder formatErrAttrSb = new StringBuilder();
        StringBuilder invalidAttrSb = new StringBuilder();
        for (ConstraintViolation<ServiceMailRequest> c : constraintViolations)
        {
          if (IMessageFormatKeys.REQUIRED_FILED.equals(c.getMessage()))
          {
            requiredAttrSb.append("[").append(c.getPropertyPath()).append("]"); //$NON-NLS-1$ //$NON-NLS-2$
          }
          if (IMessageFormatKeys.INVALID_FORMAT.equals(c.getMessage()))
          {
            formatErrAttrSb.append("[").append(c.getPropertyPath()).append("]"); //$NON-NLS-1$ //$NON-NLS-2$
          }
          if (IMessageFormatKeys.INVALID_FIELD_VALUE.equals(c.getMessage()))
          {
            invalidAttrSb.append("[").append(c.getPropertyPath()).append("]"); //$NON-NLS-1$ //$NON-NLS-2$
          }
        }
        StringBuilder validationMessageSb = new StringBuilder();
        if (StringTools.isNotNullOrEmpty(requiredAttrSb.toString()))
        {
          validationMessageSb.append(MessageFormat.format(Messages.getString(IMessageFormatKeys.REQUIRED_FILED), requiredAttrSb.toString()));
        }
        if (StringTools.isNotNullOrEmpty(formatErrAttrSb.toString()))
        {
          validationMessageSb.append(MessageFormat.format(Messages.getString(IMessageFormatKeys.INVALID_FORMAT), formatErrAttrSb.toString()));
        }
        if (StringTools.isNotNullOrEmpty(invalidAttrSb.toString()))
        {
          validationMessageSb.append(MessageFormat.format(Messages.getString(IMessageFormatKeys.INVALID_FIELD_VALUE), invalidAttrSb.toString()));
        }

        RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, validationMessageSb.toString()));
        retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, validationMessageSb.toString());

      }
      factory.close();
    }

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, _processContext.getXClientOperateur());

    BL1700_AjouterRefFonc bl1700 = new BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder()//initialize builder
        .tracabilite(tracabilite_p)//set tracabilite
        .refFonc(refFonc) //set refFonc
        .build();
    bl1700.execute(this);

    return new BL001_VerifierDonneesReturn(retour);
  }

  /**
   * Format response to the client
   *
   * @param bl001Retour
   *          Result of bl001.
   * @param tracabilite_p
   *          {@link Tracabilite}
   * @return {@link ReponseErreur}
   */
  @LogProcessBL
  private ReponseErreur PE0145_BL002_FormaterReponse(Retour bl001Retour, Tracabilite tracabilite_p)
  {
    ReponseErreur response = null;

    if (!RetourFactory.isRetourOK(bl001Retour))
    {
      response = new ReponseErreur();
      if (IMegConsts.CAT3.equals(bl001Retour.getCategorie()) && IMegSpiritConsts.NON_RESPECT_STI.equals(bl001Retour.getDiagnostic()))
      {
        response.setError(bl001Retour.getDiagnostic());
        response.setErrorDescription(bl001Retour.getLibelle());
      }
      else
      {
        response.setError(IMegSpiritConsts.ERREUR_INTERNE);
        response.setErrorDescription(bl001Retour.getLibelle());
      }
    }
    return response;
  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param tracabilite_p
   *          Tracabilite
   * @param reponserreur_p
   *          the reponserreur
   */
  private void syncResponse(Request request_p, Tracabilite tracabilite_p, ReponseErreur reponserreur_p)
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp = null;

      if (reponserreur_p != null)
      {
        ravelResponse.setDataType("application/json"); //$NON-NLS-1$
        ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponserreur_p));
        rsp = new Response(ErrorCode.KO_00400, ravelResponse);

      }
      else
      {
        //Add empty Json in case OK
        ravelResponse.setDataType(HttpConstants.CONTENT_TYPE_JSON);
        ravelResponse.setResult(""); //$NON-NLS-1$
        rsp = new Response(ErrorCode.OK_00204, ravelResponse);
      }

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PEI0142 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);

    }
  }
}