/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0279.structs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.bytel.spirit.fiat.shared.types.json.Fibre;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0279_Retour
{
  /**
   *
   */
  private static final long serialVersionUID = 6282112928366211862L;

  /**
   * Number of Fibres
   */
  @SerializedName("resultsCount")
  @Expose
  private int _resultsCount;

  /**
   * Fibres
   */
  @SerializedName("items")
  @Expose
  private List<Fibre> _items;

  /**
   * @return the items
   */
  public List<Fibre> getItems()
  {
    return _items != null ? Collections.unmodifiableList(_items) : new ArrayList<>();
  }

  /**
   * @return the resultsCount
   */
  public int getResultsCount()
  {
    return _resultsCount;
  }

  /**
   * @param items_p
   *          the items to set
   */
  public void setItems(List<Fibre> items_p)
  {
    _items = items_p != null ? new ArrayList<>(items_p) : new ArrayList<>();
  }

  /**
   * @param resultsCount_p
   *          the resultsCount to set
   */
  public void setResultsCount(int resultsCount_p)
  {
    _resultsCount = resultsCount_p;
  }

}
