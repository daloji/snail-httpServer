/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274.sti;

import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.functional.types.json.AppelantInterdit;
import com.bytel.spirit.fiat.processes.structs.XItem;
import com.squareup.moshi.Json;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0274_BL202GetReponse extends XItem
{
  /**
   * Id for serialization
   */
  private static final long serialVersionUID = 358664427244981055L;

  /**
   * appelantsInterdits
   */
  @Json(name = "appelantsInterdits")
  private List<AppelantInterdit> _appelantsInterdits;

  @Override
  public boolean equals(Object obj)
  {
    if (obj == null)
    {
      return false;
    }
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0274_BL202GetReponse other = (PE0274_BL202GetReponse) obj;
    if (_appelantsInterdits == null)
    {
      if (other._appelantsInterdits != null)
      {
        return false;
      }
    }
    else if (!_appelantsInterdits.equals(other._appelantsInterdits))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the appelantsInterdits
   */
  public List<AppelantInterdit> getAppelantsInterdits()
  {
    return _appelantsInterdits != null ? new ArrayList<>(_appelantsInterdits) : new ArrayList<>();
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_appelantsInterdits == null) ? 0 : _appelantsInterdits.hashCode());
    return result;
  }

  /**
   * @param appelantsInterdits_p
   *          the appelantsInterdits to set
   */
  public void setAppelantsInterdits(List<AppelantInterdit> appelantsInterdits_p)
  {
    _appelantsInterdits = new ArrayList<>(appelantsInterdits_p);
  }

  @Override
  public String toString()
  {
    return "PE0274_BL202GetReponse [_appelantsInterdits=" + _appelantsInterdits + "]";
  }
}
