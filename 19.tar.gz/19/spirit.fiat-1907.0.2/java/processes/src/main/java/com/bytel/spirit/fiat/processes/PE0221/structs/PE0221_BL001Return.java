/**
 *
 */
package com.bytel.spirit.fiat.processes.PE0221.structs;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.ListUtils;

/**
 * @author mbaptist
 *
 */
public final class PE0221_BL001Return
{
  /**
   * Numero de télephone
   */
  private String _noTelephone;

  /**
   * Nombre max d'appel à remonter
   */
  private Integer _limit;

  /**
   * date debut de la recherche
   */
  private LocalDateTime _dateDebutRecherche;

  /**
   * Mode d’appel utilisés pour solliciter le service
   */
  private String _modeAppel;

  /**
   * Liste NoContrat B2R
   */
  private List<String> _listeContratOauth = new ArrayList<>();

  /**
   * Constructor
   *
   * @param dateDebutRecherche_p
   *          Date debut de la recherche
   */
  public PE0221_BL001Return(final LocalDateTime dateDebutRecherche_p)
  {
    super();

    _dateDebutRecherche = dateDebutRecherche_p;
  }

  /**
   * Constructor
   *
   * @param noTelephone_p
   *          Numero Telephone
   * @param limit_p
   *          Nombre max d'appel à remonter
   * @param dateDebutRecherche_p
   *          Date debut de la recherche
   * @param modeAppel_p
   *          Obligatoire Si oRetour.resultat = OK, Sinon Vide
   * @param listeContratOauth_p
   */
  public PE0221_BL001Return(final String noTelephone_p, final Integer limit_p, final LocalDateTime dateDebutRecherche_p, final String modeAppel_p, final List<String> listeContratOauth_p)
  {
    super();

    _noTelephone = noTelephone_p;
    _limit = limit_p;
    _dateDebutRecherche = dateDebutRecherche_p;
    _modeAppel = modeAppel_p;
    _listeContratOauth = ListUtils.emptyIfNull(listeContratOauth_p);
  }

  /**
   * @param contratOuath_p
   *          the contratOuath to add
   */
  public void addContratOauth(final String contratOuath_p)
  {
    if (_listeContratOauth == null)
    {
      _listeContratOauth = new ArrayList<>();
    }
    _listeContratOauth.add(contratOuath_p);
  }

  @Override
  public boolean equals(final Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0221_BL001Return other = (PE0221_BL001Return) obj;
    if (_dateDebutRecherche == null)
    {
      if (other._dateDebutRecherche != null)
      {
        return false;
      }
    }
    else if (!_dateDebutRecherche.equals(other._dateDebutRecherche))
    {
      return false;
    }
    if (_limit == null)
    {
      if (other._limit != null)
      {
        return false;
      }
    }
    else if (!_limit.equals(other._limit))
    {
      return false;
    }
    if (_listeContratOauth == null)
    {
      if (other._listeContratOauth != null)
      {
        return false;
      }
    }
    else if (!_listeContratOauth.equals(other._listeContratOauth))
    {
      return false;
    }
    if (_modeAppel == null)
    {
      if (other._modeAppel != null)
      {
        return false;
      }
    }
    else if (!_modeAppel.equals(other._modeAppel))
    {
      return false;
    }
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateDebutRecherche
   */
  public final LocalDateTime getDateDebutRecherche()
  {
    return _dateDebutRecherche;
  }

  /**
   * @return the limit
   */
  public Integer getLimit()
  {
    return _limit;
  }

  /**
   * @return the listeContratOauth
   */
  public List<String> getListeContratOauth()
  {
    return new ArrayList<>(_listeContratOauth);
  }

  /**
   * @return the modeAppel
   */
  public String getModeAppel()
  {
    return _modeAppel;
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_dateDebutRecherche == null) ? 0 : _dateDebutRecherche.hashCode());
    result = (prime * result) + ((_limit == null) ? 0 : _limit.hashCode());
    result = (prime * result) + ((_listeContratOauth == null) ? 0 : _listeContratOauth.hashCode());
    result = (prime * result) + ((_modeAppel == null) ? 0 : _modeAppel.hashCode());
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    return result;
  }

  /**
   * @param dateDebutRecherche_p
   *          the dateDebutRecherche to set
   */
  public final void setDateDebutRecherche(final LocalDateTime dateDebutRecherche_p)
  {
    _dateDebutRecherche = dateDebutRecherche_p;
  }

  /**
   * @param limit_p
   *          the limit to set
   */
  public void setLimit(final Integer limit_p)
  {
    _limit = limit_p;
  }

  /**
   * @param listeContratOauth_p
   *          the listeContratOauth to set
   */
  public void setListeContratOauth(final List<String> listeContratOauth_p)
  {
    _listeContratOauth = ListUtils.emptyIfNull(listeContratOauth_p);
  }

  /**
   * @param modeAppel_p
   *          the modeAppel to set
   */
  public void setModeAppel(final String modeAppel_p)
  {
    _modeAppel = modeAppel_p;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(final String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  @Override
  public String toString()
  {
    final StringBuilder builder = new StringBuilder();
    builder.append("PE0221_BL001Return [_noTelephone="); //$NON-NLS-1$
    builder.append(_noTelephone);
    builder.append(", _limit="); //$NON-NLS-1$
    builder.append(_limit);
    builder.append(", _dateDebutRecherche="); //$NON-NLS-1$
    builder.append(_dateDebutRecherche);
    builder.append(", _modeAppel="); //$NON-NLS-1$
    builder.append(_modeAppel);
    builder.append(", _listeContratOauth="); //$NON-NLS-1$
    builder.append(_listeContratOauth);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
