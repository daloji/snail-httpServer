/*******************************************************************************
* $Id: AppelComparator.java 14281 2018-12-07 10:30:32Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0221.structs.types;

import java.util.Comparator;

/**
 *
 * @author kbettenc
 * @version ($Revision: 14281 $ $Date: 2018-12-07 11:30:32 +0100 (ven. 07 déc. 2018) $)
 */
public class AppelComparator implements Comparator<Appel>
{

  @Override
  public int compare(Appel appel1_p, Appel appel2_p)
  {
    int result = appel1_p.getDate().compareTo(appel2_p.getDate());
    if (result == 0)
    {
      result = appel1_p.getNumeroAppelant().compareTo(appel2_p.getNumeroAppelant());
    }
    return result;
  }

}
