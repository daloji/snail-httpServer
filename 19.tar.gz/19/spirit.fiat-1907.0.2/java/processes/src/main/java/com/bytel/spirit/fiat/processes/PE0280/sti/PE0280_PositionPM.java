/*******************************************************************************
* $Id: PositionPM.java 11493 2018-10-12 10:10:44Z mfreire $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0280.sti;

import java.io.Serializable;

import com.bytel.spirit.common.connector.oi.emutation.structs.PositionPM;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jstrub
 * @version ($Revision: 11493 $ $Date: 2018-10-12 12:10:44 +0200 (ven. 12 oct. 2018) $)
 */
public class PE0280_PositionPM implements Serializable
{
  /**
   * Builder to build {@link PositionPM}.
   */
  public static final class PE0280_PositionPMBuilder
  {

    /** The nomModulePM. */
    private String _nomModulePM;
    /** The positionModulePM. */
    private String _positionModulePM;
    /** The referenceCableModulePM. */
    private String _referenceCableModulePM;
    /** The infoTubeModulePM. */
    private String _infoTubeModulePM;
    /** The infoFibreModulePM. */
    private String _infoFibreModulePM;

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public PE0280_PositionPM build()
    {
      return new PE0280_PositionPM(_nomModulePM, _positionModulePM, _referenceCableModulePM, _infoTubeModulePM, _infoFibreModulePM);
    }

    /**
     * Builder method for _infoFibreModulePM parameter.
     *
     * @param infoFibreModulePM_p
     *          field to set
     * @return builder
     */
    public PE0280_PositionPMBuilder infoFibreModulePM(String infoFibreModulePM_p)
    {
      this._infoFibreModulePM = infoFibreModulePM_p;
      return this;
    }

    /**
     * Builder method for _infoTubeModulePM parameter.
     *
     * @param infoTubeModulePM_p
     *          field to set
     * @return builder
     */
    public PE0280_PositionPMBuilder infoTubeModulePM(String infoTubeModulePM_p)
    {
      this._infoTubeModulePM = infoTubeModulePM_p;
      return this;
    }

    /**
     * Builder method for _nomModulePM parameter.
     *
     * @param nomModulePM_p
     *          field to set
     * @return builder
     */
    public PE0280_PositionPMBuilder nomModulePM(String nomModulePM_p)
    {
      this._nomModulePM = nomModulePM_p;
      return this;
    }

    /**
     * Builder method for _positionModulePM parameter.
     *
     * @param positionModulePM_p
     *          field to set
     * @return builder
     */
    public PE0280_PositionPMBuilder positionModulePM(String positionModulePM_p)
    {
      this._positionModulePM = positionModulePM_p;
      return this;
    }

    /**
     * Builder method for _referenceCableModulePM parameter.
     *
     * @param referenceCableModulePM_p
     *          field to set
     * @return builder
     */
    public PE0280_PositionPMBuilder referenceCableModulePM(String referenceCableModulePM_p)
    {
      this._referenceCableModulePM = referenceCableModulePM_p;
      return this;
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = 7113810592578479133L;

  /** The nomModulePM. */
  @SerializedName("NomModulePM")
  @Expose
  private final String _nomModulePM;

  /** The positionModulePM. */
  @SerializedName("PositionModulePM")
  @Expose
  private final String _positionModulePM;

  /** The referenceCableModulePM. */
  @SerializedName("ReferenceCableModulePM")
  @Expose
  private final String _referenceCableModulePM;

  /** The infoTubeModulePM. */
  @SerializedName("InfoTubeModulePM")
  @Expose
  private final String _infoTubeModulePM;

  /** The infoFibreModulePM. */
  @SerializedName("InfoFibreModulePM")
  @Expose
  private final String _infoFibreModulePM;

  public PE0280_PositionPM(com.bytel.spirit.common.connector.oi.emutation.structs.PositionPM positionPM_p)
  {
    _nomModulePM = positionPM_p.getNomModulePM();
    _positionModulePM = positionPM_p.getPositionModulePM();
    _referenceCableModulePM = positionPM_p.getReferenceCableModulePM();
    _infoTubeModulePM = positionPM_p.getInfoTubeModulePM();
    _infoFibreModulePM = positionPM_p.getInfoFibreModulePM();
  }

  /**
   * @param nomModulePM_p
   *          the nomModulePM
   * @param positionModulePM_p
   *          the positionModulePM
   * @param referenceCableModulePM_p
   *          the referenceCableModulePM
   * @param infoTubeModulePM_p
   *          the infoTubeModulePM
   * @param infoFibreModulePM_p
   *          the infoFibreModulePM
   */
  public PE0280_PositionPM(String nomModulePM_p, String positionModulePM_p, String referenceCableModulePM_p, String infoTubeModulePM_p, String infoFibreModulePM_p)
  {
    _nomModulePM = nomModulePM_p;
    _positionModulePM = positionModulePM_p;
    _referenceCableModulePM = referenceCableModulePM_p;
    _infoTubeModulePM = infoTubeModulePM_p;
    _infoFibreModulePM = infoFibreModulePM_p;
  }

  /**
   * @return the infoFibreModulePM
   */
  public String getInfoFibreModulePM()
  {
    return _infoFibreModulePM;
  }

  /**
   * @return the infoTubeModulePM
   */
  public String getInfoTubeModulePM()
  {
    return _infoTubeModulePM;
  }

  /**
   * @return the nomModulePM
   */
  public String getNomModulePM()
  {
    return _nomModulePM;
  }

  /**
   * @return the positionModulePM
   */
  public String getPositionModulePM()
  {
    return _positionModulePM;
  }

  /**
   * @return the referenceCableModulePM
   */
  public String getReferenceCableModulePM()
  {
    return _referenceCableModulePM;
  }

}
