/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0276.structs;

import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.fiat.processes.structs.GetResponse;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
public class PE0276_BL002GetReturn
{
  /**
   * Le reponse erreur
   */
  private ReponseErreur _reponseErreur;

  /**
   * Le reponse du process Lister
   */
  private GetResponse<AnnoncesAccueil> _pe0276BL100Retour;

  /**
   * Le reponse du process Telecharger
   */
  private byte[] _contenuMedia;

  /**
   * @param reponseErreur_p
   * @param pe0276bl100Retour_p
   * @param contenuMedia_p
   */
  public PE0276_BL002GetReturn(ReponseErreur reponseErreur_p, GetResponse<AnnoncesAccueil> pe0276bl100Retour_p, byte[] contenuMedia_p)
  {
    super();
    _reponseErreur = reponseErreur_p;
    _pe0276BL100Retour = pe0276bl100Retour_p;
    _contenuMedia = contenuMedia_p == null ? null : contenuMedia_p.clone();
  }

  /**
   * @return the contenuMedia
   */
  public byte[] getContenuMedia()
  {
    return _contenuMedia == null ? null : _contenuMedia.clone();
  }

  /**
   * @return the pe0276BL100Retour
   */
  public GetResponse<AnnoncesAccueil> getPe0276BL100Retour()
  {
    return _pe0276BL100Retour;
  }

  /**
   * @return the reponseErreur
   */
  public ReponseErreur getReponseErreur()
  {
    return _reponseErreur;
  }

  /**
   * @param contenuMedia_p
   *          the contenuMedia to set
   */
  public void setContenuMedia(byte[] contenuMedia_p)
  {
    _contenuMedia = contenuMedia_p == null ? null : contenuMedia_p.clone();
  }

  /**
   * @param pe0276bl100Retour_p
   *          the pe0276BL100Retour to set
   */
  public void setPe0276BL100Retour(GetResponse<AnnoncesAccueil> pe0276bl100Retour_p)
  {
    _pe0276BL100Retour = pe0276bl100Retour_p;
  }

  /**
   * @param reponseErreur_p
   *          the reponseErreur to set
   */
  public void setReponseErreur(ReponseErreur reponseErreur_p)
  {
    _reponseErreur = reponseErreur_p;
  }

}
