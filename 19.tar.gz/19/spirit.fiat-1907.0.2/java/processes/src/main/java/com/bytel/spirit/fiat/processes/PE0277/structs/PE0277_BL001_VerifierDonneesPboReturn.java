/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0277.structs;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;

/**
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
public class PE0277_BL001_VerifierDonneesPboReturn extends AbstractBLReturn
{
  /**
   *
   */
  private static final long serialVersionUID = -5386279986166555630L;

  /**
   * The OI
   */
  private String _oi;

  /**
   * The refPrestationPrise
   */
  private String _refPrestationPrise;

  /**
   * @param retour_p
   *          retour
   */
  public PE0277_BL001_VerifierDonneesPboReturn(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @return the oI
   */
  public String getOi()
  {
    return _oi;
  }

  /**
   * @return the refPrestationPrise
   */
  public String getRefPrestationPrise()
  {
    return _refPrestationPrise;
  }

  /**
   * @param oi_p
   *          the oI to set
   */
  public void setOi(String oi_p)
  {
    _oi = oi_p;
  }

  /**
   * @param refPrestationPrise_p
   *          the refPrestationPrise to set
   */
  public void setRefPrestationPrise(String refPrestationPrise_p)
  {
    _refPrestationPrise = refPrestationPrise_p;
  }

}
