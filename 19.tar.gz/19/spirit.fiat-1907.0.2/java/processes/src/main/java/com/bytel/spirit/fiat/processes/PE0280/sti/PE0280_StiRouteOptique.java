/*******************************************************************************
* $Id: RouteOptique.java 11493 2018-10-12 10:10:44Z mfreire $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0280.sti;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jstrub
 * @version ($Revision: 11493 $ $Date: 2018-10-12 12:10:44 +0200 (ven. 12 oct. 2018) $)
 */
public class PE0280_StiRouteOptique implements Serializable
{

  /**
   * Builder to build {@link PE0280_StiRouteOptique}.
   */
  public static final class RouteOptiqueBuilder
  {

    /** The OC. */
    private String _oc;
    /** The positionPM. */
    private PE0280_PositionPM _positionPM;
    /** The fibre */
    private PE0280_Fibre _fibre;
    /** The connecteurPriseNumero. */
    private Integer _connecteurPriseNumero;
    /** The connecteurPriseCouleur. */
    private String _connecteurPriseCouleur;

    /**
     * Builder method of the builder.
     *
     * @return built class
     */
    public PE0280_StiRouteOptique build()
    {
      return new PE0280_StiRouteOptique(_oc, _positionPM, _fibre, _connecteurPriseNumero, _connecteurPriseCouleur);
    }

    /**
     * Builder method for _connecteurPriseCouleur parameter.
     *
     * @param connecteurPriseCouleur_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder connecteurPriseCouleur(String connecteurPriseCouleur_p)
    {
      this._connecteurPriseCouleur = connecteurPriseCouleur_p;
      return this;
    }

    /**
     * Builder method for _connecteurPriseNumero parameter.
     *
     * @param connecteurPriseNumero_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder connecteurPriseNumero(Integer connecteurPriseNumero_p)
    {
      this._connecteurPriseNumero = connecteurPriseNumero_p;
      return this;
    }

    /**
     * Builder method for _fibre parameter.
     *
     * @param fibre_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder fibre(PE0280_Fibre fibre_p)
    {
      this._fibre = fibre_p;
      return this;
    }

    /**
     * Builder method for _oc parameter.
     *
     * @param oc_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder oc(String oc_p)
    {
      this._oc = oc_p;
      return this;
    }

    /**
     * Builder method for _positionPM parameter.
     *
     * @param positionPM_p
     *          field to set
     * @return builder
     */
    public RouteOptiqueBuilder positionPM(PE0280_PositionPM positionPM_p)
    {
      this._positionPM = positionPM_p;
      return this;
    }
  }

  /**
   *
   */
  private static final long serialVersionUID = -1455521537272046911L;

  /** The OC. */
  @SerializedName("OC")
  @Expose
  private String _oc;

  /** The positionPM. */
  @SerializedName("PositionPM")
  @Expose
  private PE0280_PositionPM _positionPM;

  /** The fibre. */
  @SerializedName("Fibre")
  @Expose
  private PE0280_Fibre _fibre;

  /** The connecteurPriseNumero. */
  @SerializedName("ConnecteurPriseNumero")
  @Expose
  private Integer _connecteurPriseNumero;

  /** The connecteurPriseCouleur. */
  @SerializedName("ConnecteurPriseCouleur")
  @Expose
  private String _connecteurPriseCouleur;

  /**
   *
   */
  public PE0280_StiRouteOptique()
  {
    // empty constructor
  }

  /**
   * @param oc_p
   *          the OC
   * @param positionPM_p
   *          the positionPM
   * @param referenceCablePBO_p
   *          the referenceCablePBO
   * @param connecteurPriseNumero_p
   *          the connecteurPriseNumero
   * @param connecteurPriseCouleur_p
   *          the connecteurPriseCouleur
   */
  public PE0280_StiRouteOptique(String oc_p, PE0280_PositionPM positionPM_p, PE0280_Fibre fibre_p, Integer connecteurPriseNumero_p, String connecteurPriseCouleur_p)
  {
    _oc = oc_p;
    _positionPM = positionPM_p;
    _fibre = fibre_p;
    _connecteurPriseNumero = connecteurPriseNumero_p;
    _connecteurPriseCouleur = connecteurPriseCouleur_p;
  }

  /**
   * @return the connecteurPriseCouleur
   */
  public String getConnecteurPriseCouleur()
  {
    return _connecteurPriseCouleur;
  }

  /**
   * @return the connecteurPriseNumero
   */
  public Integer getConnecteurPriseNumero()
  {
    return _connecteurPriseNumero;
  }

  /**
   * @return the fibre
   */
  public PE0280_Fibre getFibre()
  {
    return _fibre;
  }

  /**
   * @return the oc
   */
  public String getOc()
  {
    return _oc;
  }

  /**
   * @return the positionPM
   */
  public PE0280_PositionPM getPositionPM()
  {
    return _positionPM;
  }

  /**
   * @param connecteurPriseCouleur_p
   *          the connecteurPriseCouleur to set
   */
  public void setConnecteurPriseCouleur(String connecteurPriseCouleur_p)
  {
    _connecteurPriseCouleur = connecteurPriseCouleur_p;
  }

  /**
   * @param connecteurPriseNumero_p
   *          the connecteurPriseNumero to set
   */
  public void setConnecteurPriseNumero(Integer connecteurPriseNumero_p)
  {
    _connecteurPriseNumero = connecteurPriseNumero_p;
  }

  /**
   * @param fibre_p
   *          the fibre to set
   */
  public void setFibre(PE0280_Fibre fibre_p)
  {
    _fibre = fibre_p;
  }

  /**
   * @param oc_p
   *          the oc to set
   */
  public void setOc(String oc_p)
  {
    _oc = oc_p;
  }

  /**
   * @param positionPM_p
   *          the positionPM to set
   */
  public void setPositionPM(PE0280_PositionPM positionPM_p)
  {
    _positionPM = positionPM_p;
  }

}
