/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274.sti;

import com.bytel.spirit.common.shared.misc.error.ReponseErreur;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0274_BL002GetReponse
{
  /**
   * Le reponse erreur
   */
  private ReponseErreur _reponseErreur;

  /**
   * Le reponse du process GET
   */
  private String _reponse;

  /**
   * @param reponseErreur_p
   *          reponseErreur
   * @param reponse_p
   *          json reponse
   */
  public PE0274_BL002GetReponse(ReponseErreur reponseErreur_p, String reponse_p)
  {
    _reponseErreur = reponseErreur_p;
    _reponse = reponse_p;
  }

  /**
   * @return the pe0274BL100Retour
   */
  public String getReponse()
  {
    return _reponse;
  }

  /**
   * @return the reponseErreur
   */
  public ReponseErreur getReponseErreur()
  {
    return _reponseErreur;
  }

  /**
   * @param reponse_p
   *          the response to set
   */
  public void setReponse(String reponse_p)
  {
    _reponse = reponse_p;
  }

  /**
   * @param reponseErreur_p
   *          the reponseErreur to set
   */
  public void setReponseErreur(ReponseErreur reponseErreur_p)
  {
    _reponseErreur = reponseErreur_p;
  }
}
