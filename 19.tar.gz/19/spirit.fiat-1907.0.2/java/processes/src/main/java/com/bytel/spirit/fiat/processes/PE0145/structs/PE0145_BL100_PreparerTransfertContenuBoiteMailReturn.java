/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0145.structs;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;

/**
 *
 * @author jbrites
 * @version ($Revision$ $Date$)
 */
public class PE0145_BL100_PreparerTransfertContenuBoiteMailReturn extends AbstractBLReturn
{
  /**
   * Generated UID
   */
  private static final long serialVersionUID = -8639407475937689536L;

  /**
   * The source mailbox ID
   */
  private String _idCompteMailSource;

  /**
   * The target mailbox ID
   */
  private String _idCompteMailCible;

  /**
   *
   * @param retour_p
   *          retour_p
   */
  public PE0145_BL100_PreparerTransfertContenuBoiteMailReturn(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @return the idCompteMailCible
   */
  public String getIdCompteMailCible()
  {
    return _idCompteMailCible;
  }

  /**
   * @return the idCompteMailSource
   */
  public String getIdCompteMailSource()
  {
    return _idCompteMailSource;
  }

  /**
   * @param idCompteMailCible_p
   *          the idCompteMailCible to set
   */
  public void setIdCompteMailCible(String idCompteMailCible_p)
  {
    _idCompteMailCible = idCompteMailCible_p;
  }

  /**
   * @param idCompteMailSource_p
   *          the idCompteMailSource to set
   */
  public void setIdCompteMailSource(String idCompteMailSource_p)
  {
    _idCompteMailSource = idCompteMailSource_p;
  }
}
