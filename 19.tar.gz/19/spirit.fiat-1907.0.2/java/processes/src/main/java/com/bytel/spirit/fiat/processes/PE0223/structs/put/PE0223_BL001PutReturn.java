/*******************************************************************************
* $Id: PE0223_BL001Retour.java 9999 2018-09-10 15:27:06Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223.structs.put;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.ListUtils;

/**
 *
 * @author pcarreir
 * @version ($Revision: 9999 $ $Date: 2018-09-10 17:27:06 +0200 (Mon, 10 Sep 2018) $)
 */
public class PE0223_BL001PutReturn
{
  /**
   * The noTelephone from the request
   */
  private String _noTelephone;

  /**
   * The IdOptionAppel
   */
  private String _idOptionAppel;

  /**
   * The type operation for the request;
   */
  private String _typeOperation;

  /**
   * The modeAppel from the request
   */
  private String _modeAppel;

  /**
   * The type option for the request;
   */
  private String _typeOptionAppel;

  /**
   * statut option attribute
   */
  private String _statutOptionAppel;

  /**
   * modeRenvoi attribute
   */
  private String _modeRenvoi;

  /**
   * numeroRenvoi attribute
   */
  private String _numeroRenvoi;

  /**
   * nombreSonneries attribute
   */
  private String _nombreSonneries;

  /**
   * noContrat attribute
   */
  private String _noContrat;

  /**
   * The Liste NoContrat B2R from the request
   */
  private List<String> _listeContratOauth = new ArrayList<>();

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0223_BL001PutReturn other = (PE0223_BL001PutReturn) obj;
    if (_idOptionAppel == null)
    {
      if (other._idOptionAppel != null)
      {
        return false;
      }
    }
    else if (!_idOptionAppel.equals(other._idOptionAppel))
    {
      return false;
    }
    if (_listeContratOauth == null)
    {
      if (other._listeContratOauth != null)
      {
        return false;
      }
    }
    else if (!_listeContratOauth.equals(other._listeContratOauth))
    {
      return false;
    }
    if (_modeAppel == null)
    {
      if (other._modeAppel != null)
      {
        return false;
      }
    }
    else if (!_modeAppel.equals(other._modeAppel))
    {
      return false;
    }
    if (_modeRenvoi == null)
    {
      if (other._modeRenvoi != null)
      {
        return false;
      }
    }
    else if (!_modeRenvoi.equals(other._modeRenvoi))
    {
      return false;
    }
    if (_noContrat == null)
    {
      if (other._noContrat != null)
      {
        return false;
      }
    }
    else if (!_noContrat.equals(other._noContrat))
    {
      return false;
    }
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    if (_nombreSonneries == null)
    {
      if (other._nombreSonneries != null)
      {
        return false;
      }
    }
    else if (!_nombreSonneries.equals(other._nombreSonneries))
    {
      return false;
    }
    if (_numeroRenvoi == null)
    {
      if (other._numeroRenvoi != null)
      {
        return false;
      }
    }
    else if (!_numeroRenvoi.equals(other._numeroRenvoi))
    {
      return false;
    }
    if (_statutOptionAppel == null)
    {
      if (other._statutOptionAppel != null)
      {
        return false;
      }
    }
    else if (!_statutOptionAppel.equals(other._statutOptionAppel))
    {
      return false;
    }
    if (_typeOperation == null)
    {
      if (other._typeOperation != null)
      {
        return false;
      }
    }
    else if (!_typeOperation.equals(other._typeOperation))
    {
      return false;
    }
    if (_typeOptionAppel == null)
    {
      if (other._typeOptionAppel != null)
      {
        return false;
      }
    }
    else if (!_typeOptionAppel.equals(other._typeOptionAppel))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the idOptionAppel
   */
  public String getIdOptionAppel()
  {
    return _idOptionAppel;
  }

  /**
   * @return the listeContratOauth
   */
  public List<String> getListeContratOauth()
  {
    return new ArrayList<>(_listeContratOauth);
  }

  /**
   * @return the modeAppel
   */
  public String getModeAppel()
  {
    return _modeAppel;
  }

  /**
   * @return the modeRenvoi
   */
  public String getModeRenvoi()
  {
    return _modeRenvoi;
  }

  /**
   * @return value of noContrat
   */
  public String getNoContrat()
  {
    return _noContrat;
  }

  /**
   * @return the nombreSonneries
   */
  public String getNombreSonneries()
  {
    return _nombreSonneries;
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the numeroRenvoi
   */
  public String getNumeroRenvoi()
  {
    return _numeroRenvoi;
  }

  /**
   * @return the statutOptionAppel
   */
  public String getStatutOptionAppel()
  {
    return _statutOptionAppel;
  }

  /**
   * @return the typeOperation
   */
  public String getTypeOperation()
  {
    return _typeOperation;
  }

  /**
   * @return the typeOptionAppel
   */
  public String getTypeOptionAppel()
  {
    return _typeOptionAppel;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_idOptionAppel == null) ? 0 : _idOptionAppel.hashCode());
    result = (prime * result) + ((_listeContratOauth == null) ? 0 : _listeContratOauth.hashCode());
    result = (prime * result) + ((_modeAppel == null) ? 0 : _modeAppel.hashCode());
    result = (prime * result) + ((_modeRenvoi == null) ? 0 : _modeRenvoi.hashCode());
    result = (prime * result) + ((_noContrat == null) ? 0 : _noContrat.hashCode());
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    result = (prime * result) + ((_nombreSonneries == null) ? 0 : _nombreSonneries.hashCode());
    result = (prime * result) + ((_numeroRenvoi == null) ? 0 : _numeroRenvoi.hashCode());
    result = (prime * result) + ((_statutOptionAppel == null) ? 0 : _statutOptionAppel.hashCode());
    result = (prime * result) + ((_typeOperation == null) ? 0 : _typeOperation.hashCode());
    result = (prime * result) + ((_typeOptionAppel == null) ? 0 : _typeOptionAppel.hashCode());
    return result;
  }

  /**
   * @param idOptionAppel_p
   *          the idOptionAppel to set
   */
  public void setIdOptionAppel(String idOptionAppel_p)
  {
    _idOptionAppel = idOptionAppel_p;
  }

  /**
   * @param listeContratOauth_p
   *          the listeContratOauth to set
   */
  public void setListeContratOauth(List<String> listeContratOauth_p)
  {
    _listeContratOauth = ListUtils.emptyIfNull(listeContratOauth_p);
  }

  /**
   * @param modeAppel_p
   *          the modeAppel to set
   */
  public void setModeAppel(String modeAppel_p)
  {
    _modeAppel = modeAppel_p;
  }

  /**
   * @param modeRenvoi_p
   *          the modeRenvoi to set
   */
  public void setModeRenvoi(String modeRenvoi_p)
  {
    _modeRenvoi = modeRenvoi_p;
  }

  /**
   * @param noContrat_p
   *          The noContrat to set.
   */
  public void setNoContrat(String noContrat_p)
  {
    _noContrat = noContrat_p;
  }

  /**
   * @param nombreSonneries_p
   *          the nombreSonneries to set
   */
  public void setNombreSonneries(String nombreSonneries_p)
  {
    _nombreSonneries = nombreSonneries_p;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param numeroRenvoi_p
   *          the numeroRenvoi to set
   */
  public void setNumeroRenvoi(String numeroRenvoi_p)
  {
    _numeroRenvoi = numeroRenvoi_p;
  }

  /**
   * @param statutOptionAppel_p
   *          the statutOptionAppel to set
   */
  public void setStatutOptionAppel(String statutOptionAppel_p)
  {
    _statutOptionAppel = statutOptionAppel_p;
  }

  /**
   * @param typeOperation_p
   *          the typeOperation to set
   */
  public void setTypeOperation(String typeOperation_p)
  {
    _typeOperation = typeOperation_p;
  }

  /**
   * @param typeOptionAppel_p
   *          the typeOptionAppel to set
   */
  public void setTypeOptionAppel(String typeOptionAppel_p)
  {
    _typeOptionAppel = typeOptionAppel_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PE0223_BL001PutReturn [_noTelephone="); //$NON-NLS-1$
    builder.append(_noTelephone);
    builder.append(", _idOptionAppel="); //$NON-NLS-1$
    builder.append(_idOptionAppel);
    builder.append(", _typeOperation="); //$NON-NLS-1$
    builder.append(_typeOperation);
    builder.append(", _modeAppel="); //$NON-NLS-1$
    builder.append(_modeAppel);
    builder.append(", _typeOptionAppel="); //$NON-NLS-1$
    builder.append(_typeOptionAppel);
    builder.append(", _statutOptionAppel="); //$NON-NLS-1$
    builder.append(_statutOptionAppel);
    builder.append(", _modeRenvoi="); //$NON-NLS-1$
    builder.append(_modeRenvoi);
    builder.append(", _numeroRenvoi="); //$NON-NLS-1$
    builder.append(_numeroRenvoi);
    builder.append(", _nombreSonneries="); //$NON-NLS-1$
    builder.append(_nombreSonneries);
    builder.append(", _noContrat="); //$NON-NLS-1$
    builder.append(_noContrat);
    builder.append(", _listeContratOauth="); //$NON-NLS-1$
    builder.append(_listeContratOauth);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
