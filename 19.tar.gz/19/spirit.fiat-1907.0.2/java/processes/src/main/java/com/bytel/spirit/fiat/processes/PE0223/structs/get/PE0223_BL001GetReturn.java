/**
 *
 */
package com.bytel.spirit.fiat.processes.PE0223.structs.get;

import java.util.ArrayList;
import java.util.List;

/**
 * @author jpais
 *
 */
public class PE0223_BL001GetReturn
{
  /**
   * Numero de télephone
   */
  private String _noTelephone;

  /**
   * Mode d’appel utilisés pour solliciter le service
   */
  private String _modeAppel;

  /**
   * Liste NoContrat B2R
   */
  private List<String> _listeContratOauth;

  /**
   * Default constructor
   */
  public PE0223_BL001GetReturn()
  {
    // Default constructor
  }

  /**
   * @param noTelephone_p
   *          The telephone number
   * @param modeAppel_p
   *          The call mode
   * @param listeContratOauth_p
   *          The auth contract list
   */
  public PE0223_BL001GetReturn(String noTelephone_p, String modeAppel_p, List<String> listeContratOauth_p)
  {
    super();
    _noTelephone = noTelephone_p;
    _modeAppel = modeAppel_p;
    _listeContratOauth = listeContratOauth_p != null ? new ArrayList<>(listeContratOauth_p) : new ArrayList<>();
  }

  /**
   * @param contratOuath_p
   *          the contratOuath to add
   */
  public void addContratOauth(String contratOuath_p)
  {
    if (_listeContratOauth == null)
    {
      _listeContratOauth = new ArrayList<>();
    }
    _listeContratOauth.add(contratOuath_p);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0223_BL001GetReturn other = (PE0223_BL001GetReturn) obj;
    if (_listeContratOauth == null)
    {
      if (other._listeContratOauth != null)
      {
        return false;
      }
    }
    else if (!_listeContratOauth.equals(other._listeContratOauth))
    {
      return false;
    }
    if (_modeAppel == null)
    {
      if (other._modeAppel != null)
      {
        return false;
      }
    }
    else if (!_modeAppel.equals(other._modeAppel))
    {
      return false;
    }
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the listeContratOauth
   */
  public List<String> getListeContratOauth()
  {
    return _listeContratOauth != null ? new ArrayList<>(_listeContratOauth) : new ArrayList<>();
  }

  /**
   * @return the modeAppel
   */
  public String getModeAppel()
  {
    return _modeAppel;
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_listeContratOauth == null) ? 0 : _listeContratOauth.hashCode());
    result = (prime * result) + ((_modeAppel == null) ? 0 : _modeAppel.hashCode());
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    return result;
  }

  /**
   * @param listeContratOauth_p
   *          the listeContratOauth to set
   */
  public void setListeContratOauth(List<String> listeContratOauth_p)
  {
    _listeContratOauth = new ArrayList<>(listeContratOauth_p);
  }

  /**
   * @param modeAppel_p
   *          the modeAppel to set
   */
  public void setModeAppel(String modeAppel_p)
  {
    _modeAppel = modeAppel_p;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }
}
