/*******************************************************************************
* $Id: PE0206_CoordonneesGeo.java 16650 2019-02-04 14:57:47Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206.sti;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 16650 $ $Date: 2019-02-04 15:57:47 +0100 (lun., 04 févr. 2019) $)
 */
public class PE0206_CoordonneesGeo implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * typeProjection
   */
  @SerializedName("typeProjection")
  @Expose
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  @Size(min = 1, max = 10, message = IMessageFormatKeys.INVALID_FORMAT)
  private String _typeProjection;

  /**
   * coordonneesY
   */
  @SerializedName("coordonneesY")
  @Expose
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  private String _coordonneesY;

  /**
   * coordonneesX
   */
  @SerializedName("coordonneesX")
  @Expose
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  private String _coordonneesX;

  /**
   * @return the coordonneesX
   */
  public String getCoordonneesX()
  {
    return _coordonneesX;
  }

  /**
   * @return the coordonneesY
   */
  public String getCoordonneesY()
  {
    return _coordonneesY;
  }

  /**
   * @return the typeProjection
   */
  public String getTypeProjection()
  {
    return _typeProjection;
  }

  /**
   * @param coordonneesX_p
   *          the coordonneesX to set
   */
  public void setCoordonneesX(String coordonneesX_p)
  {
    _coordonneesX = coordonneesX_p;
  }

  /**
   * @param coordonneesY_p
   *          the coordonneesY to set
   */
  public void setCoordonneesY(String coordonneesY_p)
  {
    _coordonneesY = coordonneesY_p;
  }

  /**
   * @param typeProjection_p
   *          the typeProjection to set
   */
  public void setTypeProjection(String typeProjection_p)
  {
    _typeProjection = typeProjection_p;
  }
}
