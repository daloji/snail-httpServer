/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223.structs.put;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PE0223_PutRequest implements Serializable
{
  /**
   * The serial UID
   */
  private static final long serialVersionUID = -4013071196398100676L;

  /**
   * statut attribute
   */
  @SerializedName("statut")
  @Expose
  private String _statut;

  /**
   * modeRenvoi attribute
   */
  @SerializedName("modeRenvoi")
  @Expose
  private String _modeRenvoi;

  /**
   * numeroRenvoi attribute
   */
  @SerializedName("numeroRenvoi")
  @Expose
  private String _numeroRenvoi;

  /**
   * nombreSonneries attribute
   */
  @SerializedName("nombreSonneries")
  @Expose
  private String _nombreSonneries;

  /**
   * Default constructor
   */
  public PE0223_PutRequest()
  {
    super();
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0223_PutRequest other = (PE0223_PutRequest) obj;
    if (_modeRenvoi == null)
    {
      if (other._modeRenvoi != null)
      {
        return false;
      }
    }
    else if (!_modeRenvoi.equals(other._modeRenvoi))
    {
      return false;
    }
    if (_nombreSonneries == null)
    {
      if (other._nombreSonneries != null)
      {
        return false;
      }
    }
    else if (!_nombreSonneries.equals(other._nombreSonneries))
    {
      return false;
    }
    if (_numeroRenvoi == null)
    {
      if (other._numeroRenvoi != null)
      {
        return false;
      }
    }
    else if (!_numeroRenvoi.equals(other._numeroRenvoi))
    {
      return false;
    }
    if (_statut == null)
    {
      if (other._statut != null)
      {
        return false;
      }
    }
    else if (!_statut.equals(other._statut))
    {
      return false;
    }
    return true;
  }

  /**
   * @return value of modeRenvoi
   */
  public String getModeRenvoi()
  {
    return _modeRenvoi;
  }

  /**
   * @return value of nombreSonneries
   */
  public String getNombreSonneries()
  {
    return _nombreSonneries;
  }

  /**
   * @return value of numeroRenvoi
   */
  public String getNumeroRenvoi()
  {
    return _numeroRenvoi;
  }

  /**
   * @return value of statut
   */
  public String getStatut()
  {
    return _statut;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_modeRenvoi == null) ? 0 : _modeRenvoi.hashCode());
    result = (prime * result) + ((_nombreSonneries == null) ? 0 : _nombreSonneries.hashCode());
    result = (prime * result) + ((_numeroRenvoi == null) ? 0 : _numeroRenvoi.hashCode());
    result = (prime * result) + ((_statut == null) ? 0 : _statut.hashCode());
    return result;
  }

  /**
   * @param modeRenvoi_p
   *          the modeRenvoi to set
   */
  public void setModeRenvoi(String modeRenvoi_p)
  {
    _modeRenvoi = modeRenvoi_p;
  }

  /**
   * @param nombreSonneries_p
   *          the nombreSonneries to set
   */
  public void setNombreSonneries(String nombreSonneries_p)
  {
    _nombreSonneries = nombreSonneries_p;
  }

  /**
   * @param numeroRenvoi_p
   *          the numeroRenvoi to set
   */
  public void setNumeroRenvoi(String numeroRenvoi_p)
  {
    _numeroRenvoi = numeroRenvoi_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  @Override
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append("PE0223_PutRequest [_statut="); //$NON-NLS-1$
    builder.append(_statut);
    builder.append(", _modeRenvoi="); //$NON-NLS-1$
    builder.append(_modeRenvoi);
    builder.append(", _numeroRenvoi="); //$NON-NLS-1$
    builder.append(_numeroRenvoi);
    builder.append(", _nombreSonneries="); //$NON-NLS-1$
    builder.append(_nombreSonneries);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }
}
