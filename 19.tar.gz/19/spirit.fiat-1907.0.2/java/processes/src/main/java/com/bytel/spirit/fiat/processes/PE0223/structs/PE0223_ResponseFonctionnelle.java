/*******************************************************************************
* $Id: PE0223_ResponseFonctionnelle.java 14346 2018-12-10 11:24:13Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223.structs;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.functional.types.json.OptionAppelPfs;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author pcarreir
 * @version ($Revision: 14346 $ $Date: 2018-12-10 12:24:13 +0100 (lun. 10 déc. 2018) $)
 */
public class PE0223_ResponseFonctionnelle implements Serializable
{
  /**
   * The serial version UID
   */
  private static final long serialVersionUID = -2554484805281040218L;

  /**
   * results count
   */
  @SerializedName("resultsCount")
  @Expose
  private Integer _resultsCount;

  /**
   * items
   */
  @SerializedName("items")
  @Expose
  private List<OptionAppelPfs> _items;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0223_ResponseFonctionnelle other = (PE0223_ResponseFonctionnelle) obj;
    if (_items == null)
    {
      if (other._items != null)
      {
        return false;
      }
    }
    else if (!_items.equals(other._items))
    {
      return false;
    }
    if (_resultsCount == null)
    {
      if (other._resultsCount != null)
      {
        return false;
      }
    }
    else if (!_resultsCount.equals(other._resultsCount))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the items
   */
  public List<OptionAppelPfs> getItems()
  {
    return _items != null ? new ArrayList<>(_items) : new ArrayList<>();
  }

  /**
   * @return the resultsCount
   */
  public Integer getResultsCount()
  {
    return _resultsCount;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_items == null) ? 0 : _items.hashCode());
    result = (prime * result) + ((_resultsCount == null) ? 0 : _resultsCount.hashCode());
    return result;
  }

  /**
   * @param items_p
   *          the items to set
   */
  public void setItems(List<OptionAppelPfs> items_p)
  {
    _items = items_p != null ? new ArrayList<>(items_p) : new ArrayList<>();
  }

  /**
   * @param resultsCount_p
   *          the resultsCount to set
   */
  public void setResultsCount(Integer resultsCount_p)
  {
    _resultsCount = resultsCount_p;
  }

  @Override
  public String toString()
  {
    return "ResponseFonctionnelle [_resultsCount=" + _resultsCount + ", _items=" + _items + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }
}
