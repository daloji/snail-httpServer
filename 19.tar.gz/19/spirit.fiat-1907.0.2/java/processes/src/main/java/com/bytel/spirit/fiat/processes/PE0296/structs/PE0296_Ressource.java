/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0296.structs;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class PE0296_Ressource implements Serializable
{

  /**
   *
   * @EtatAllocation
   *
   */
  public enum EtatAllocation
  {
    /**
     * REALISE
     */
    REALISE,
    /**
     * ECHEC
     */
    ECHEC,
    /**
     * EN_COURS
     */
    EN_COURS;
  }

  /**
   *
   * @EtatRessource
   *
   */
  public enum EtatRessource
  {

    /**
     * RESERVE
     */
    RESERVE,
    /**
     * ALLOUE
     */
    ALLOUE;
  }

  /**
   *
   * @TypeRessource
   *
   */
  public enum TypeRessource
  {
    /**
     * RACCORDEMENT
     */
    RACCORDEMENT,
    /**
     * PORT_P2P
     */
    PORT_P2P;
  }

  /**
   *
   */
  private static final long serialVersionUID = 2268395294647499690L;

  /**
   * Type de Ressource
   */
  @Json(name = "typeRessource")
  private String _typeRessource;

  /**
   * Etat de la Ressource
   */
  @Json(name = "etatRessource")
  private String _etatRessource;

  /**
   * Etat allocation Ressource
   */
  @Json(name = "etatAllocation")
  private String _etatAllocation;

  /**
   * codeAccesTechnique
   */
  @Json(name = "codeAccesTechnique")
  private String _codeAccesTechnique;

  /**
   * NomNR
   */
  @Json(name = "nomNR")
  private String _nomNR;

  /**
   * NomOLT
   */
  @Json(name = "nomOLT")
  private String _nomOLT;

  /**
   * positionCarte
   */
  @Json(name = "positionCarte")
  private String _positionCarte;

  /**
   * positionRelativePort
   */
  @Json(name = "positionRelativePort")
  private String _positionRelativePort;

  /**
   * distanceCompatible
   */
  @Json(name = "distanceCompatible")
  private String _distanceCompatible;

  /**
   *
   */
  public PE0296_Ressource()
  {
    super();
  }

  /**
   * @param typeRessource_p
   *          typeRessource
   * @param etatRessource_p
   *          etatRessource
   * @param etatAllocation_p
   *          etatAllocation
   */
  public PE0296_Ressource(String typeRessource_p, String etatRessource_p, String etatAllocation_p)
  {
    super();
    _typeRessource = typeRessource_p;
    _etatRessource = etatRessource_p;
    _etatAllocation = etatAllocation_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0296_Ressource other = (PE0296_Ressource) obj;
    if (_codeAccesTechnique == null)
    {
      if (other._codeAccesTechnique != null)
      {
        return false;
      }
    }
    else if (!_codeAccesTechnique.equals(other._codeAccesTechnique))
    {
      return false;
    }
    if (_distanceCompatible == null)
    {
      if (other._distanceCompatible != null)
      {
        return false;
      }
    }
    else if (!_distanceCompatible.equals(other._distanceCompatible))
    {
      return false;
    }
    if (_etatAllocation == null)
    {
      if (other._etatAllocation != null)
      {
        return false;
      }
    }
    else if (!_etatAllocation.equals(other._etatAllocation))
    {
      return false;
    }
    if (_etatRessource == null)
    {
      if (other._etatRessource != null)
      {
        return false;
      }
    }
    else if (!_etatRessource.equals(other._etatRessource))
    {
      return false;
    }
    if (_nomNR == null)
    {
      if (other._nomNR != null)
      {
        return false;
      }
    }
    else if (!_nomNR.equals(other._nomNR))
    {
      return false;
    }
    if (_nomOLT == null)
    {
      if (other._nomOLT != null)
      {
        return false;
      }
    }
    else if (!_nomOLT.equals(other._nomOLT))
    {
      return false;
    }
    if (_positionCarte == null)
    {
      if (other._positionCarte != null)
      {
        return false;
      }
    }
    else if (!_positionCarte.equals(other._positionCarte))
    {
      return false;
    }
    if (_positionRelativePort == null)
    {
      if (other._positionRelativePort != null)
      {
        return false;
      }
    }
    else if (!_positionRelativePort.equals(other._positionRelativePort))
    {
      return false;
    }
    if (_typeRessource == null)
    {
      if (other._typeRessource != null)
      {
        return false;
      }
    }
    else if (!_typeRessource.equals(other._typeRessource))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the codeAccesTechnique
   */
  public String getCodeAccesTechnique()
  {
    return _codeAccesTechnique;
  }

  /**
   * @return the distanceCompatible
   */
  public String getDistanceCompatible()
  {
    return _distanceCompatible;
  }

  /**
   * @return the etatAllocation
   */
  public String getEtatAllocation()
  {
    return _etatAllocation;
  }

  /**
   * @return the etatRessource
   */
  public String getEtatRessource()
  {
    return _etatRessource;
  }

  /**
   * @return the nomNR
   */
  public String getNomNR()
  {
    return _nomNR;
  }

  /**
   * @return the nomOLT
   */
  public String getNomOLT()
  {
    return _nomOLT;
  }

  /**
   * @return the positionCarte
   */
  public String getPositionCarte()
  {
    return _positionCarte;
  }

  /**
   * @return the positionRelativePort
   */
  public String getPositionRelativePort()
  {
    return _positionRelativePort;
  }

  /**
   * @return the typeRessource
   */
  public String getTypeRessource()
  {
    return _typeRessource;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_codeAccesTechnique == null) ? 0 : _codeAccesTechnique.hashCode());
    result = (prime * result) + ((_distanceCompatible == null) ? 0 : _distanceCompatible.hashCode());
    result = (prime * result) + ((_etatAllocation == null) ? 0 : _etatAllocation.hashCode());
    result = (prime * result) + ((_etatRessource == null) ? 0 : _etatRessource.hashCode());
    result = (prime * result) + ((_nomNR == null) ? 0 : _nomNR.hashCode());
    result = (prime * result) + ((_nomOLT == null) ? 0 : _nomOLT.hashCode());
    result = (prime * result) + ((_positionCarte == null) ? 0 : _positionCarte.hashCode());
    result = (prime * result) + ((_positionRelativePort == null) ? 0 : _positionRelativePort.hashCode());
    result = (prime * result) + ((_typeRessource == null) ? 0 : _typeRessource.hashCode());
    return result;
  }

  /**
   * @param codeAccesTechnique_p
   *          the codeAccesTechnique to set
   */
  public void setCodeAccesTechnique(String codeAccesTechnique_p)
  {
    _codeAccesTechnique = codeAccesTechnique_p;
  }

  /**
   * @param distanceCompatible_p
   *          the distanceCompatible to set
   */
  public void setDistanceCompatible(String distanceCompatible_p)
  {
    _distanceCompatible = distanceCompatible_p;
  }

  /**
   * @param etatAllocation_p
   *          the etatAllocation to set
   */
  public void setEtatAllocation(String etatAllocation_p)
  {
    _etatAllocation = etatAllocation_p;
  }

  /**
   * @param etatRessource_p
   *          the etatRessource to set
   */
  public void setEtatRessource(String etatRessource_p)
  {
    _etatRessource = etatRessource_p;
  }

  /**
   * @param nomNR_p
   *          the nomNR to set
   */
  public void setNomNR(String nomNR_p)
  {
    _nomNR = nomNR_p;
  }

  /**
   * @param nomOLT_p
   *          the nomOLT to set
   */
  public void setNomOLT(String nomOLT_p)
  {
    _nomOLT = nomOLT_p;
  }

  /**
   * @param positionCarte_p
   *          the positionCarte to set
   */
  public void setPositionCarte(String positionCarte_p)
  {
    _positionCarte = positionCarte_p;
  }

  /**
   * @param positionRelativePort_p
   *          the positionRelativePort to set
   */
  public void setPositionRelativePort(String positionRelativePort_p)
  {
    _positionRelativePort = positionRelativePort_p;
  }

  /**
   * @param typeRessource_p
   *          the typeRessource to set
   */
  public void setTypeRessource(String typeRessource_p)
  {
    _typeRessource = typeRessource_p;
  }

}
