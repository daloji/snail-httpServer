/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PI0311.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PI0311_Erreur implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -2320210533854484616L;

  /**
   * field error
   */
  @Json(name = "error")
  private String _error;

  /**
   * field error_description
   */
  @Json(name = "error_description")
  private String _errorDescription;

  /**
   * @return the error
   */
  public String getError()
  {
    return _error;
  }

  /**
   * @return the error_description
   */
  public String getErrorDescription()
  {
    return _errorDescription;
  }

  /**
   * @param error_p
   *          the error to set
   */
  public void setError(String error_p)
  {
    _error = error_p;
  }

  /**
   * @param error_description_p
   *          the error_description to set
   */
  public void setErrorDescription(String error_description_p)
  {
    _errorDescription = error_description_p;
  }
}
