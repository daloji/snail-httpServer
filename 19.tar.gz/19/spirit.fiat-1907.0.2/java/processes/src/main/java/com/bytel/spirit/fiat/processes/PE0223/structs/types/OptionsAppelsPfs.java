/*******************************************************************************
* $Id: OptionsAppelsPfs.java 9946 2018-09-07 12:07:40Z jiantila $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223.structs.types;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 9946 $ $Date: 2018-09-07 14:07:40 +0200 (Fri, 07 Sep 2018) $)
 */
public class OptionsAppelsPfs implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * status
   */
  @SerializedName("statut")
  @Expose
  private String _statut;

  /**
   * type
   */
  @SerializedName("type")
  @Expose
  private String _type;

  /**
   * mode renvoi
   */
  @SerializedName("modeRenvoi")
  @Expose
  private String _modeRenvoi;

  /**
   * numero renvoi
   */
  @SerializedName("numeroRenvoi")
  @Expose
  private String _numeroRenvoi;

  /**
   * nombre sonnerie
   */
  @SerializedName("nombreSonneries")
  @Expose
  private String _nombreSonneries;

  /**
   * @return the modeRenvoi
   */
  public String getModeRenvoi()
  {
    return _modeRenvoi;
  }

  /**
   * @return the nombreSonneries
   */
  public String getNombreSonneries()
  {
    return _nombreSonneries;
  }

  /**
   * @return the numeroRenvoi
   */
  public String getNumeroRenvoi()
  {
    return _numeroRenvoi;
  }

  /**
   * @return the statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return the type
   */
  public String getType()
  {
    return _type;
  }

  /**
   * @param modeRenvoi_p
   *          the modeRenvoi to set
   */
  public void setModeRenvoi(String modeRenvoi_p)
  {
    _modeRenvoi = modeRenvoi_p;
  }

  /**
   * @param nombreSonneries_p
   *          the nombreSonneries to set
   */
  public void setNombreSonneries(String nombreSonneries_p)
  {
    _nombreSonneries = nombreSonneries_p;
  }

  /**
   * @param numeroRenvoi_p
   *          the numeroRenvoi to set
   */
  public void setNumeroRenvoi(String numeroRenvoi_p)
  {
    _numeroRenvoi = numeroRenvoi_p;
  }

  /**
   * @param statut_p
   *          the statut to set
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param type_p
   *          the type to set
   */
  public void setType(String type_p)
  {
    _type = type_p;
  }

}
