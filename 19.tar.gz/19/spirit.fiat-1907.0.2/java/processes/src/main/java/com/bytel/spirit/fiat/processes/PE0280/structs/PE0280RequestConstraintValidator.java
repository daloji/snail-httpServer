/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0280.structs;

import java.util.EnumSet;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.spirit.common.generated.ws.ftth.emutation.MotifMutationType;
import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.bytel.spirit.fiat.shared.types.json.ComplementAdresse;
import com.bytel.spirit.fiat.shared.types.json.ReferencesAdresse;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0280RequestConstraintValidator implements ConstraintValidator<PE0280RequestConstraint, PE0280_Request>
{

  @Override
  public boolean isValid(PE0280_Request requestPE0280_p, ConstraintValidatorContext context_p)
  {
    if (StringTools.isNullOrEmpty(requestPE0280_p.getMotifMutation()))
    {
      return true; //validation is done at the PE0280_Request level
    }

    context_p.disableDefaultConstraintViolation();

    Pair<Boolean, MotifMutationType> motifValidPair = isValidMotif(requestPE0280_p.getMotifMutation(), context_p);
    MotifMutationType motif = motifValidPair._second;

    boolean motifValid = motifValidPair._first;
    if (!motifValid)
    {
      return false;
    }

    boolean isvalidReferencePrise = isValidReferencePrise(requestPE0280_p.getReferencePrise(), motif, context_p);
    boolean isValidReferenceAdresse = isValidReferenceAdresse(requestPE0280_p.getReferencesAdresse(), motif, context_p);
    boolean isValidComplementAdresse = isValidComplementAdresseCmd(requestPE0280_p.getComplementAdresseCmd(), motif, context_p);

    return isvalidReferencePrise && isValidReferenceAdresse && isValidComplementAdresse;
  }

  /**
   * Validates if complementAdresseCmd is present given a motif and adds a constraint validation into the context if not
   * valid.
   *
   * @param complementAdresseCmd_p
   *          The field complementAdresseCmd
   * @param motif_p
   *          The motif
   * @param context_p
   *          The context of validation
   * @return True if referencePrise is present or if it is not required for the motif in parameter, false otherwise
   */
  private boolean isValidComplementAdresseCmd(ComplementAdresse complementAdresseCmd_p, MotifMutationType motif_p, ConstraintValidatorContext context_p)
  {

    EnumSet<MotifMutationType> dependingMotifs = EnumSet.of(MotifMutationType.ADRESSE_CLIENT_ERRONÉE, //
        MotifMutationType.BÂTIMENT_CLIENT_ERRONÉ, //
        MotifMutationType.ESCALIER_CLIENT_ERRONÉ, //
        MotifMutationType.ETAGE_CLIENT_ERRONÉ);

    if ((null == complementAdresseCmd_p) && dependingMotifs.contains(motif_p))
    {
      context_p.buildConstraintViolationWithTemplate(IMessageFormatKeys.CONDITIONAL_FIELD).addPropertyNode("_complementAdresseCmd").addConstraintViolation(); //$NON-NLS-1$
      return false;
    }

    return true;
  }

  /**
   * Validate the motif in parameter as valid value of the enum MotifMutationType
   *
   * @param motif_p
   *          The motif to validate
   * @param context_p
   *          The validation context
   * @return True if the motif parameter is valid, false otherwise.
   */
  private Pair<Boolean, MotifMutationType> isValidMotif(String motif_p, ConstraintValidatorContext context_p)
  {
    Pair<Boolean, MotifMutationType> result;
    MotifMutationType motif = null;
    try
    {
      motif = MotifMutationType.fromValue(motif_p);
      result = new Pair<>(true, motif);
    }
    catch (Exception ignore)
    {
      context_p.buildConstraintViolationWithTemplate(IMessageFormatKeys.INVALID_FORMAT).addPropertyNode("_motifMutation").addConstraintViolation(); //$NON-NLS-1$
      result = new Pair<>(false, null);
    }

    return result;
  }

  /**
   * Validates if referenceAdresse is present given a motif and adds a constraint validation into the context if not
   * valid.
   *
   * @param referenceAdresse_p
   *          The field referenceAdresse
   * @param motif_p
   *          The motif
   * @param context_p
   *          The context of validation
   * @return True if referencePrise is present or if it is not required for the motif in parameter, false otherwise
   */
  private boolean isValidReferenceAdresse(ReferencesAdresse referenceAdresse_p, MotifMutationType motif_p, ConstraintValidatorContext context_p)
  {

    if ((null == referenceAdresse_p) && (MotifMutationType.ADRESSE_CLIENT_ERRONÉE == motif_p))
    {
      context_p.buildConstraintViolationWithTemplate(IMessageFormatKeys.CONDITIONAL_FIELD).addPropertyNode("_referencesAdresse").addConstraintViolation(); //$NON-NLS-1$
      return false;
    }
    return true;
  }

  /**
   * Validates if referencePrise is present given a motif and adds a constraint validation into the context if not
   * valid.
   *
   * @param referencePrise_p
   *          The field referencePrise
   * @param motif_p
   *          The motif
   * @param context_p
   *          The context of validation
   * @return True if referencePrise is present or if it is not required for the motif in parameter, false otherwise
   */
  private boolean isValidReferencePrise(String referencePrise_p, MotifMutationType motif_p, ConstraintValidatorContext context_p)
  {

    EnumSet<MotifMutationType> dependingMotifs = EnumSet.of(MotifMutationType.ADRESSE_CLIENT_ERRONÉE, //
        MotifMutationType.BÂTIMENT_CLIENT_ERRONÉ, //
        MotifMutationType.ESCALIER_CLIENT_ERRONÉ, //
        MotifMutationType.ETAGE_CLIENT_ERRONÉ, //
        MotifMutationType.PTO_EXISTANTE_ALORS_QUE_PTO_À_CONSTRUIRE_DANS_LA_COMMANDE_OC, //
        MotifMutationType.PTO_À_CONSTRUIRE_ALORS_QUE_PTO_EXISTANTE_DANS_LA_COMMANDE_OC, //
        MotifMutationType.RÉFÉRENCE_PTO_ERRONÉE, //
        MotifMutationType.COMMANDE_HOTLINE);

    if (StringTools.isNullOrEmpty(referencePrise_p) && dependingMotifs.contains(motif_p))
    {
      context_p.buildConstraintViolationWithTemplate(IMessageFormatKeys.CONDITIONAL_FIELD).addPropertyNode("_referencePrise").addConstraintViolation(); //$NON-NLS-1$
      return false;
    }

    return true;
  }
}
