/*******************************************************************************
* $Id: PE0206_QuadrupletRivoli.java 16650 2019-02-04 14:57:47Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206.sti;

import java.io.Serializable;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.bytel.spirit.common.shared.types.json.validation.IMessageFormatKeys;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author jiantila
 * @version ($Revision: 16650 $ $Date: 2019-02-04 15:57:47 +0100 (lun., 04 févr. 2019) $)
 */
public class PE0206_QuadrupletRivoli implements Serializable
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  /**
   * hexacle
   */
  @SerializedName("codeInsee")
  @Expose
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  @Size(min = 1, max = 5, message = IMessageFormatKeys.INVALID_FORMAT)
  private String _codeInsee;

  /**
   * hexacle
   */
  @SerializedName("codeRivoli")
  @Expose
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  @Size(min = 1, max = 4, message = IMessageFormatKeys.INVALID_FORMAT)
  private String _codeRivoli;

  /**
   * hexacle
   */
  @SerializedName("numeroVoie")
  @Expose
  @NotNull(message = IMessageFormatKeys.REQUIRED_FILED)
  @Min(value = 0, message = IMessageFormatKeys.INVALID_FORMAT)
  private Integer _numeroVoie;

  /**
   * hexacle
   */
  @SerializedName("complementNumeroVoie")
  @Expose
  private String _complementNumeroVoie;

  /**
   * @return the codeInsee
   */
  public String getCodeInsee()
  {
    return _codeInsee;
  }

  /**
   * @return the codeRivoli
   */
  public String getCodeRivoli()
  {
    return _codeRivoli;
  }

  /**
   * @return the complementNumeroVoie
   */
  public String getComplementNumeroVoie()
  {
    return _complementNumeroVoie;
  }

  /**
   * @return the numeroVoie
   */
  public Integer getNumeroVoie()
  {
    return _numeroVoie;
  }

  /**
   * @param codeInsee_p
   *          the codeInsee to set
   */
  public void setCodeInsee(String codeInsee_p)
  {
    _codeInsee = codeInsee_p;
  }

  /**
   * @param codeRivoli_p
   *          the codeRivoli to set
   */
  public void setCodeRivoli(String codeRivoli_p)
  {
    _codeRivoli = codeRivoli_p;
  }

  /**
   * @param complementNumeroVoie_p
   *          the complementNumeroVoie to set
   */
  public void setComplementNumeroVoie(String complementNumeroVoie_p)
  {
    _complementNumeroVoie = complementNumeroVoie_p;
  }

  /**
   * @param numeroVoie_p
   *          the numeroVoie to set
   */
  public void setNumeroVoie(Integer numeroVoie_p)
  {
    _numeroVoie = numeroVoie_p;
  }

}
