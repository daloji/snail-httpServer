/*******************************************************************************
 * $Id$
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223.structs.put;

/**
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public interface IOptionAppelConsts
{
  /**
   * STATUT_ACTIF constant
   */
  public static final String STATUT_ACTIF = "ACTIF"; //$NON-NLS-1$

  /**
   * STATUT_INACTIF constant
   */
  public static final String STATUT_INACTIF = "INACTIF"; //$NON-NLS-1$

  /**
   * STATUT_ACTIF constant
   */
  public static final String STATUT_SUSPENDU = "SUSPENDU"; //$NON-NLS-1$

  /**
   * RENVOI_LIGNE_OCCUPEE constant
   */
  public static final String TYPE_RENVOI_LIGNE_OCCUPEE = "RENVOI_LIGNE_OCCUPEE"; //$NON-NLS-1$

  /**
   * RENVOI_NON_REPONSE constant
   */
  public static final String TYPE_RENVOI_NON_REPONSE = "RENVOI_NON_REPONSE"; //$NON-NLS-1$

  /**
   * RENVOI_LIGNE_INDISPONIBLE constant
   */
  public static final String TYPE_RENVOI_LIGNE_INDISPONIBLE = "RENVOI_LIGNE_INDISPONIBLE"; //$NON-NLS-1$

  /**
   * RENVOI_INCONDITIONNEL constant
   */
  public static final String TYPE_RENVOI_INCONDITIONNEL = "RENVOI_INCONDITIONNEL"; //$NON-NLS-1$
  
  /**
   * TYPE_APPEL_INCOGNITO constant
   */
  public static final String TYPE_APPEL_INCOGNITO = "APPEL_INCOGNITO"; //$NON-NLS-1$
  
  /**
   * TYPE_APPEL_DOUBLE_APPEL constant
   */
  public static final String TYPE_APPEL_DOUBLE_APPEL = "DOUBLE_APPEL"; //$NON-NLS-1$

  /**
   * MODE_RENVOI_VMS constant
   */
  public static final String MODE_RENVOI_VMS = "VMS"; //$NON-NLS-1$

  /**
   * MODE_RENVOI_NUMERO constant
   */
  public static final String MODE_RENVOI_NUMERO = "NUMERO"; //$NON-NLS-1$
}
