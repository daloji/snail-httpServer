/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274.sti;

import java.time.LocalDateTime;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.common.shared.functional.types.json.MessageriePfs;
import com.bytel.spirit.fiat.processes.structs.XItem;
import com.squareup.moshi.Json;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class RessourceMessageries extends XItem
{
  /**
   *
   */
  private static final long serialVersionUID = -6485699446451705005L;

  /**
   * idMessagerie
   */
  @Json(name = "idMessagerie")
  private String _idMessagerie;

  /**
   * typePfs
   */
  @Json(name = "typePfs")
  private String _typePfs;

  /**
   * typeMessagerie
   */
  @Json(name = "typeMessagerie")
  private String _typeMessagerie;

  /**
   * nombreMessagesNonLus
   */
  @Json(name = "nombreMessagesNonLus")
  private Integer _nombreMessagesNonLus;

  /**
   * dateDernierLectureMessage
   */
  @Json(name = "dateDerniereLectureMessage")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateDerniereLectureMessage;

  /**
   * dateDernierDepotMessage
   */
  @Json(name = "dateDerniereDepotMessage")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateDerniereDepotMessage;

  /**
   * statutMessagerie
   */
  @Json(name = "statutMessagerie")
  private String _statutMessagerie;

  /**
   * dureeMaximaleMessageAccueil
   */
  @Json(name = "dureeMaximaleMessageAccueil")
  private String _dureeMaximaleMessageAccueil;

  /**
   * dureeMaximaleMessageDepose
   */
  @Json(name = "dureeMaximaleMessageDepose")
  private String _dureeMaximaleMessageDepose;

  /**
   * nombreMaximalMessagesAutorise
   */
  @Json(name = "nombreMaximalMessagesAutorise")
  private Integer _nombreMaximalMessagesAutorise;

  /**
   * dureeMaximaleSauvegardeMessagesNonLus
   */
  @Json(name = "dureeMaximaleSauvegardeMessagesNonLus")
  private String _dureeMaximaleSauvegardeMessagesNonLus;

  /**
   * dureeMaximaleSauvegardeMessagesLus
   */
  @Json(name = "dureeMaximaleSauvegardeMessagesLus")
  private String _dureeMaximaleSauvegardeMessagesLus;

  /**
   * The statutRappel
   */
  @Json(name = "statutRappel")
  private String _statutRappel;

  /**
   * Default constructor
   */
  public RessourceMessageries()
  {
    //Nothing to do
  }

  /**
   * Create a RessourceMessageries from a MessageriePfs object
   *
   * @param messageriePfs_p
   *          messageriePfs
   */
  public RessourceMessageries(MessageriePfs messageriePfs_p)
  {
    _typePfs = messageriePfs_p.getTypePfs();
    _typeMessagerie = messageriePfs_p.getTypeMessagerie();
    _nombreMessagesNonLus = messageriePfs_p.getNombreMessagesNonLus();
    _dateDerniereLectureMessage = messageriePfs_p.getDateDerniereLectureMessage();
    _dateDerniereDepotMessage = messageriePfs_p.getDateDernierDepotMessage();
    _statutMessagerie = messageriePfs_p.getStatutMessagerie();
    if ("VOIX".equals(_typeMessagerie)) //$NON-NLS-1$
    {
      _statutRappel = messageriePfs_p.getStatutRappel();
      _dureeMaximaleMessageAccueil = messageriePfs_p.getDureeMaximaleMessageAccueil();
      _dureeMaximaleMessageDepose = messageriePfs_p.getDureeMaximaleMessageDepose();
      _nombreMaximalMessagesAutorise = messageriePfs_p.getNombreMaximalMessageAutorise();
      _dureeMaximaleSauvegardeMessagesNonLus = messageriePfs_p.getDureeMaximaleSauvegardeMessagesNonLus();
      _dureeMaximaleSauvegardeMessagesLus = messageriePfs_p.getDureeMaximaleSauvegardeMessagesLus();
    }
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (!super.equals(obj))
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    RessourceMessageries other = (RessourceMessageries) obj;
    if (_dateDerniereDepotMessage == null)
    {
      if (other._dateDerniereDepotMessage != null)
      {
        return false;
      }
    }
    else if (!_dateDerniereDepotMessage.equals(other._dateDerniereDepotMessage))
    {
      return false;
    }
    if (_dateDerniereLectureMessage == null)
    {
      if (other._dateDerniereLectureMessage != null)
      {
        return false;
      }
    }
    else if (!_dateDerniereLectureMessage.equals(other._dateDerniereLectureMessage))
    {
      return false;
    }
    if (_dureeMaximaleMessageAccueil == null)
    {
      if (other._dureeMaximaleMessageAccueil != null)
      {
        return false;
      }
    }
    else if (!_dureeMaximaleMessageAccueil.equals(other._dureeMaximaleMessageAccueil))
    {
      return false;
    }
    if (_dureeMaximaleMessageDepose == null)
    {
      if (other._dureeMaximaleMessageDepose != null)
      {
        return false;
      }
    }
    else if (!_dureeMaximaleMessageDepose.equals(other._dureeMaximaleMessageDepose))
    {
      return false;
    }
    if (_dureeMaximaleSauvegardeMessagesLus == null)
    {
      if (other._dureeMaximaleSauvegardeMessagesLus != null)
      {
        return false;
      }
    }
    else if (!_dureeMaximaleSauvegardeMessagesLus.equals(other._dureeMaximaleSauvegardeMessagesLus))
    {
      return false;
    }
    if (_dureeMaximaleSauvegardeMessagesNonLus == null)
    {
      if (other._dureeMaximaleSauvegardeMessagesNonLus != null)
      {
        return false;
      }
    }
    else if (!_dureeMaximaleSauvegardeMessagesNonLus.equals(other._dureeMaximaleSauvegardeMessagesNonLus))
    {
      return false;
    }
    if (_idMessagerie == null)
    {
      if (other._idMessagerie != null)
      {
        return false;
      }
    }
    else if (!_idMessagerie.equals(other._idMessagerie))
    {
      return false;
    }
    if (_nombreMaximalMessagesAutorise == null)
    {
      if (other._nombreMaximalMessagesAutorise != null)
      {
        return false;
      }
    }
    else if (!_nombreMaximalMessagesAutorise.equals(other._nombreMaximalMessagesAutorise))
    {
      return false;
    }
    if (_nombreMessagesNonLus == null)
    {
      if (other._nombreMessagesNonLus != null)
      {
        return false;
      }
    }
    else if (!_nombreMessagesNonLus.equals(other._nombreMessagesNonLus))
    {
      return false;
    }
    if (_statutMessagerie == null)
    {
      if (other._statutMessagerie != null)
      {
        return false;
      }
    }
    else if (!_statutMessagerie.equals(other._statutMessagerie))
    {
      return false;
    }
    if (_statutRappel == null)
    {
      if (other._statutRappel != null)
      {
        return false;
      }
    }
    else if (!_statutRappel.equals(other._statutRappel))
    {
      return false;
    }
    if (_typeMessagerie == null)
    {
      if (other._typeMessagerie != null)
      {
        return false;
      }
    }
    else if (!_typeMessagerie.equals(other._typeMessagerie))
    {
      return false;
    }
    if (_typePfs == null)
    {
      if (other._typePfs != null)
      {
        return false;
      }
    }
    else if (!_typePfs.equals(other._typePfs))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the dateDerniereDepotMessage
   */
  public LocalDateTime getDateDerniereDepotMessage()
  {
    return _dateDerniereDepotMessage;
  }

  /**
   * @return the dateDerniereLectureMessage
   */
  public LocalDateTime getDateDerniereLectureMessage()
  {
    return _dateDerniereLectureMessage;
  }

  /**
   * @return the dureeMaximaleMessageAccueil
   */
  public String getDureeMaximaleMessageAccueil()
  {
    return _dureeMaximaleMessageAccueil;
  }

  /**
   * @return the dureeMaximaleMessageDepose
   */
  public String getDureeMaximaleMessageDepose()
  {
    return _dureeMaximaleMessageDepose;
  }

  /**
   * @return the dureeMaximaleSauvegardeMessagesLus
   */
  public String getDureeMaximaleSauvegardeMessagesLus()
  {
    return _dureeMaximaleSauvegardeMessagesLus;
  }

  /**
   * @return the dureeMaximaleSauvegardeMessagesNonLus
   */
  public String getDureeMaximaleSauvegardeMessagesNonLus()
  {
    return _dureeMaximaleSauvegardeMessagesNonLus;
  }

  /**
   * @return the idMessagerie
   */
  public String getIdMessagerie()
  {
    return _idMessagerie;
  }

  /**
   * @return the nombreMaximalMessagesAutorise
   */
  public Integer getNombreMaximalMessagesAutorise()
  {
    return _nombreMaximalMessagesAutorise;
  }

  /**
   * @return the nombreMessagesNonLus
   */
  public Integer getNombreMessagesNonLus()
  {
    return _nombreMessagesNonLus;
  }

  /**
   * @return the statutMessagerie
   */
  public String getStatutMessagerie()
  {
    return _statutMessagerie;
  }

  /**
   * @return the statutRappel
   */
  public String getStatutRappel()
  {
    return _statutRappel;
  }

  /**
   * @return the typeMessagerie
   */
  public String getTypeMessagerie()
  {
    return _typeMessagerie;
  }

  /**
   * @return the typePfs
   */
  public String getTypePfs()
  {
    return _typePfs;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = super.hashCode();
    result = (prime * result) + ((_dateDerniereDepotMessage == null) ? 0 : _dateDerniereDepotMessage.hashCode());
    result = (prime * result) + ((_dateDerniereLectureMessage == null) ? 0 : _dateDerniereLectureMessage.hashCode());
    result = (prime * result) + ((_dureeMaximaleMessageAccueil == null) ? 0 : _dureeMaximaleMessageAccueil.hashCode());
    result = (prime * result) + ((_dureeMaximaleMessageDepose == null) ? 0 : _dureeMaximaleMessageDepose.hashCode());
    result = (prime * result) + ((_dureeMaximaleSauvegardeMessagesLus == null) ? 0 : _dureeMaximaleSauvegardeMessagesLus.hashCode());
    result = (prime * result) + ((_dureeMaximaleSauvegardeMessagesNonLus == null) ? 0 : _dureeMaximaleSauvegardeMessagesNonLus.hashCode());
    result = (prime * result) + ((_idMessagerie == null) ? 0 : _idMessagerie.hashCode());
    result = (prime * result) + ((_nombreMaximalMessagesAutorise == null) ? 0 : _nombreMaximalMessagesAutorise.hashCode());
    result = (prime * result) + ((_nombreMessagesNonLus == null) ? 0 : _nombreMessagesNonLus.hashCode());
    result = (prime * result) + ((_statutMessagerie == null) ? 0 : _statutMessagerie.hashCode());
    result = (prime * result) + ((_statutRappel == null) ? 0 : _statutRappel.hashCode());
    result = (prime * result) + ((_typeMessagerie == null) ? 0 : _typeMessagerie.hashCode());
    result = (prime * result) + ((_typePfs == null) ? 0 : _typePfs.hashCode());
    return result;
  }

  /**
   * @param dateDerniereDepotMessage_p
   *          the dateDerniereDepotMessage to set
   */
  public void setDateDerniereDepotMessage(LocalDateTime dateDerniereDepotMessage_p)
  {
    _dateDerniereDepotMessage = dateDerniereDepotMessage_p;
  }

  /**
   * @param dateDerniereLectureMessage_p
   *          the dateDerniereLectureMessage to set
   */
  public void setDateDerniereLectureMessage(LocalDateTime dateDerniereLectureMessage_p)
  {
    _dateDerniereLectureMessage = dateDerniereLectureMessage_p;
  }

  /**
   * @param dureeMaximaleMessageAccueil_p
   *          the dureeMaximaleMessageAccueil to set
   */
  public void setDureeMaximaleMessageAccueil(String dureeMaximaleMessageAccueil_p)
  {
    _dureeMaximaleMessageAccueil = dureeMaximaleMessageAccueil_p;
  }

  /**
   * @param dureeMaximaleMessageDepose_p
   *          the dureeMaximaleMessageDepose to set
   */
  public void setDureeMaximaleMessageDepose(String dureeMaximaleMessageDepose_p)
  {
    _dureeMaximaleMessageDepose = dureeMaximaleMessageDepose_p;
  }

  /**
   * @param dureeMaximaleSauvegardeMessagesLus_p
   *          the dureeMaximaleSauvegardeMessagesLus to set
   */
  public void setDureeMaximaleSauvegardeMessagesLus(String dureeMaximaleSauvegardeMessagesLus_p)
  {
    _dureeMaximaleSauvegardeMessagesLus = dureeMaximaleSauvegardeMessagesLus_p;
  }

  /**
   * @param dureeMaximaleSauvegardeMessagesNonLus_p
   *          the dureeMaximaleSauvegardeMessagesNonLus to set
   */
  public void setDureeMaximaleSauvegardeMessagesNonLus(String dureeMaximaleSauvegardeMessagesNonLus_p)
  {
    _dureeMaximaleSauvegardeMessagesNonLus = dureeMaximaleSauvegardeMessagesNonLus_p;
  }

  /**
   * @param idMessagerie_p
   *          the idMessagerie to set
   */
  public void setIdMessagerie(String idMessagerie_p)
  {
    _idMessagerie = idMessagerie_p;
  }

  /**
   * @param nombreMaximalMessagesAutorise_p
   *          the nombreMaximalMessagesAutorise to set
   */
  public void setNombreMaximalMessagesAutorise(Integer nombreMaximalMessagesAutorise_p)
  {
    _nombreMaximalMessagesAutorise = nombreMaximalMessagesAutorise_p;
  }

  /**
   * @param nombreMessagesNonLus_p
   *          the nombreMessagesNonLus to set
   */
  public void setNombreMessagesNonLus(Integer nombreMessagesNonLus_p)
  {
    _nombreMessagesNonLus = nombreMessagesNonLus_p;
  }

  /**
   * @param statutMessagerie_p
   *          the statutMessagerie to set
   */
  public void setStatutMessagerie(String statutMessagerie_p)
  {
    _statutMessagerie = statutMessagerie_p;
  }

  /**
   * @param statutRappel_p
   *          the statutRappel to set
   */
  public void setStatutRappel(String statutRappel_p)
  {
    _statutRappel = statutRappel_p;
  }

  /**
   * @param typeMessagerie_p
   *          the typeMessagerie to set
   */
  public void setTypeMessagerie(String typeMessagerie_p)
  {
    _typeMessagerie = typeMessagerie_p;
  }

  /**
   * @param typePfs_p
   *          the typePfs to set
   */
  public void setTypePfs(String typePfs_p)
  {
    _typePfs = typePfs_p;
  }

  @Override
  public String toString()
  {
    return "RessourceMessageries [_idMessagerie=" + _idMessagerie + ", _typePfs=" + _typePfs + ", _typeMessagerie=" + _typeMessagerie + ", _nombreMessagesNonLus=" + _nombreMessagesNonLus + ", _dateDerniereLectureMessage=" + _dateDerniereLectureMessage + ", _dateDerniereDepotMessage=" + _dateDerniereDepotMessage + ", _statutMessagerie=" + _statutMessagerie + ", _dureeMaximaleMessageAccueil=" + _dureeMaximaleMessageAccueil + ", _dureeMaximaleMessageDepose=" + _dureeMaximaleMessageDepose + ", _nombreMaximalMessagesAutorise=" + _nombreMaximalMessagesAutorise + ", _dureeMaximaleSauvegardeMessagesNonLus=" + _dureeMaximaleSauvegardeMessagesNonLus + ", _dureeMaximaleSauvegardeMessagesLus=" + _dureeMaximaleSauvegardeMessagesLus + ", _statutRappel=" + _statutRappel + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$
  }

}
