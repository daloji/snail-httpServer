/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0276.structs;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author jpais
 * @version ($Revision$ $Date$)
 */
public class PE0276_PutRequest implements Serializable
{
  /**
   * Serial UID
   */
  private static final long serialVersionUID = -471609968477210305L;

  /**
   * statutAnnonce
   */
  @Json(name = "statutAnnonce")
  private String _statutAnnonce;

  /**
   * Default constructor
   */
  public PE0276_PutRequest()
  {
    // Default constructor
  }

  /**
   * Default constructor
   */
  public PE0276_PutRequest(String statutAnnonce_p)
  {
    _statutAnnonce = statutAnnonce_p;
  }

  /**
   * @return value of _statutAnnonce
   */
  public String getStatutAnnonce()
  {
    return _statutAnnonce;
  }

  /**
   * @param statutAnnonce_p
   *          The _statutAnnonce to set.
   */
  public void setStatutAnnonce(String statutAnnonce_p)
  {
    _statutAnnonce = statutAnnonce_p;
  }
}
