/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.functional.types.json.NotificationEmail;
import com.squareup.moshi.Json;

/**
 * NotificationsEmail Payload
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0274_PutRequestNotificationsEmail implements Serializable
{
  /**
   * The id for serialization
   */
  private static final long serialVersionUID = -6966688303236051939L;

  /**
   * statutNotificationsEmail
   */
  @Json(name = "statutNotificationsEmail")
  private String _statutNotificationsEmail;

  /**
   * notificationsEmail
   */
  @Json(name = "notificationsEmail")
  private List<NotificationEmail> _notificationsEmail;

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0274_PutRequestNotificationsEmail other = (PE0274_PutRequestNotificationsEmail) obj;
    if (_notificationsEmail == null)
    {
      if (other._notificationsEmail != null)
      {
        return false;
      }
    }
    else if (!_notificationsEmail.equals(other._notificationsEmail))
    {
      return false;
    }
    if (_statutNotificationsEmail == null)
    {
      if (other._statutNotificationsEmail != null)
      {
        return false;
      }
    }
    else if (!_statutNotificationsEmail.equals(other._statutNotificationsEmail))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the notificationsEmail
   */
  public List<NotificationEmail> getNotificationsEmail()
  {
    return _notificationsEmail != null ? new ArrayList<>(_notificationsEmail) : new ArrayList<>();
  }

  /**
   * @return the statutNotificationsEmail
   */
  public String getStatutNotificationsEmail()
  {
    return _statutNotificationsEmail;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_notificationsEmail == null) ? 0 : _notificationsEmail.hashCode());
    result = (prime * result) + ((_statutNotificationsEmail == null) ? 0 : _statutNotificationsEmail.hashCode());
    return result;
  }

  /**
   * @param notificationsEmail_p
   *          the notificationsEmail to set
   */
  public void setNotificationsEmail(List<NotificationEmail> notificationsEmail_p)
  {
    _notificationsEmail = new ArrayList<>(notificationsEmail_p);
  }

  /**
   * @param statutNotificationsEmail_p
   *          the statutNotificationsEmail to set
   */
  public void setStatutNotificationsEmail(String statutNotificationsEmail_p)
  {
    _statutNotificationsEmail = statutNotificationsEmail_p;
  }
}
