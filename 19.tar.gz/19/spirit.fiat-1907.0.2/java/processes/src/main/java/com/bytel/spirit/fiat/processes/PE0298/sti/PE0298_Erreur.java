/*******************************************************************************
* $Id: PE0298_Erreur.java 15184 2019-01-02 15:09:51Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0298.sti;

import java.io.Serializable;

import com.google.gson.annotations.SerializedName;
import com.squareup.moshi.Json;

/**
 *
 * @author jramos
 * @version ($Revision: 15184 $ $Date: 2019-01-02 16:09:51 +0100 (mer. 02 janv. 2019) $)
 */
public final class PE0298_Erreur implements Serializable
{

  /**
   *
   * @author jramos
   * @version ($Revision: 15184 $ $Date: 2019-01-02 16:09:51 +0100 (mer. 02 janv. 2019) $)
   */
  public enum TypeError
  {
    /**
     * DESYNCHRO_PFS
     */
    PFS_INDISPONIBLE,
    /**
     * SERVICE_NON_PROVISIONNE
     */
    ECHEC_ACTION_CORRECTIVE,
    /**
     * ERREUR_INTERNE
     */
    ERREUR_INTERNE
  }

  /**
   *
   */
  private static final long serialVersionUID = -5944254302106946282L;

  /**
   *
   */
  @SerializedName("error")
  @Json(name = "error")
  private String _error;

  /**
   *
   */
  @SerializedName("error_description")
  @Json(name = "error_description")
  private String _errorDescription;

  /**
   *
   */
  public PE0298_Erreur()
  {
    super();
  }

  /**
   * @param error_p
   *          error
   * @param errorDescription_p
   *          error description
   *
   */
  public PE0298_Erreur(String error_p, String errorDescription_p)
  {
    super();
    _error = error_p;
    _errorDescription = errorDescription_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0298_Erreur other = (PE0298_Erreur) obj;
    if (_error == null)
    {
      if (other._error != null)
      {
        return false;
      }
    }
    else if (!_error.equals(other._error))
    {
      return false;
    }
    if (_errorDescription == null)
    {
      if (other._errorDescription != null)
      {
        return false;
      }
    }
    else if (!_errorDescription.equals(other._errorDescription))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the error
   */
  public String getError()
  {
    return _error;
  }

  /**
   * @return the errorDescription
   */
  public String getErrorDescription()
  {
    return _errorDescription;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_error == null) ? 0 : _error.hashCode());
    result = (prime * result) + ((_errorDescription == null) ? 0 : _errorDescription.hashCode());
    return result;
  }

  /**
   * @param error_p
   *          the error to set
   */
  public void setError(String error_p)
  {
    _error = error_p;
  }

  /**
   * @param errorDescription_p
   *          the errorDescription to set
   */
  public void setErrorDescription(String errorDescription_p)
  {
    _errorDescription = errorDescription_p;
  }

  @Override
  public String toString()
  {
    return "Erreur [_error=" + _error + ", _error_description=" + _errorDescription + "]"; //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
  }

}
