/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0296;

import java.text.MessageFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.StringJoiner;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.IRavelJsonAdapter;
import com.bytel.ravel.common.json.RavelJson.RavelJsonBuilder;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.BooleanTools;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringTools;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.aspectJ.LogProcessBL;
import com.bytel.ravel.services.aspectJ.LogStartProcess;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.MandatoryProcessState;
import com.bytel.ravel.services.process.activity.Context;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.DonneesIdentificationSTPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.StPfsOlt;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritRestApiProcessSkeleton;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceAggrege;
import com.bytel.spirit.common.shared.saab.res.RessourceAggregeP2P;
import com.bytel.spirit.common.shared.saab.res.TypeRaccordement;
import com.bytel.spirit.common.shared.saab.res.TypeRessource;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.utils.PFIFilter;
import com.bytel.spirit.common.shared.utils.PFIFilter.Operation;
import com.bytel.spirit.common.shared.utils.PFIFilterOption;
import com.bytel.spirit.common.shared.utils.PFIUtils;
import com.bytel.spirit.common.shared.utils.st.StLacFilter;
import com.bytel.spirit.common.shared.utils.st.StPfsOltFilter;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_BL001Return;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_BL100Return;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_BL200Return;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_Erreur;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_Referentiel;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_Referentiel.EtatProvisioning;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_Referentiel.TypeService;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_Ressource;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_Ressource.EtatAllocation;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_Ressource.EtatRessource;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_Retour;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class PE0296_DiagnosticRaccordement extends SpiritRestApiProcessSkeleton
{

  /**
   * Holds context data for PE0296_Diagnostic_Raccordement
   *
   * @author jramos
   * @version ($Revision$ $Date$)
   */
  public static final class PE0296_DiagnosticRaccordementContext extends Context
  {

    /**
     * Serial Version
     */
    private static final long serialVersionUID = -3468117458478978094L;

    /***
     * Contains the next step to execute. Initialized with the first step to execute.
     */
    private State _state = State.PE0296_START;

    /**
     * The clientOperateur from header
     */
    private String _clientOperateur;

    /**
     * noCompte
     */
    private String _noCompte;

    /**
     * identifiantFonctionnelPa
     */
    private String _identifiantFonctionnelPa;

    /**
     * idRaccordement
     */
    private String _idRaccordement;

    /**
     * Liste des noms des vues pour lesquels le service est ouvert
     */
    private EnumSet<SourceDonnee> _sourceDonnees;

    /**
     *
     */
    private Boolean _audit;

    /**
     *
     */
    private String _requestId;

    /**
     * @return the audit
     */
    public Boolean getAudit()
    {
      return _audit;
    }

    /**
     * @return the clientOperateur
     */
    public String getClientOperateur()
    {
      return _clientOperateur;
    }

    /**
     * @return the identifiantFonctionnelPa
     */
    public String getIdentifiantFonctionnelPa()
    {
      return _identifiantFonctionnelPa;
    }

    /**
     * @return the idRaccordement
     */
    public String getIdRaccordement()
    {
      return _idRaccordement;
    }

    /**
     * @return the noCompte
     */
    public String getNoCompte()
    {
      return _noCompte;
    }

    /**
     * @return the requestId
     */
    public String getRequestId()
    {
      return _requestId;
    }

    /**
     * @return the sourceDonnees
     */
    public EnumSet<SourceDonnee> getSourceDonnees()
    {
      if (_sourceDonnees != null)
      {
        return _sourceDonnees.clone();
      }
      return EnumSet.noneOf(SourceDonnee.class);
    }

    /**
     * @return the state
     */
    public State getState()
    {
      return _state;
    }

    /**
     * @param audit_p
     *          the audit to set
     */
    public void setAudit(Boolean audit_p)
    {
      _audit = audit_p;
    }

    /**
     * @param clientOperateur_p
     *          the clientOperateur to set
     */
    public void setClientOperateur(String clientOperateur_p)
    {
      _clientOperateur = clientOperateur_p;
    }

    /**
     * @param identifiantFonctionnelPa_p
     *          the identifiantFonctionnelPa to set
     */
    public void setIdentifiantFonctionnelPa(String identifiantFonctionnelPa_p)
    {
      _identifiantFonctionnelPa = identifiantFonctionnelPa_p;
    }

    /**
     * @param idRaccordement_p
     *          the idRaccordement to set
     */
    public void setIdRaccordement(String idRaccordement_p)
    {
      _idRaccordement = idRaccordement_p;
    }

    /**
     * @param noCompte_p
     *          the noCompte to set
     */
    public void setNoCompte(String noCompte_p)
    {
      _noCompte = noCompte_p;
    }

    /**
     * @param requestId_p
     *          the requestId to set
     */
    public void setRequestId(String requestId_p)
    {
      _requestId = requestId_p;
    }

    /**
     * @param sourceDonnees_p
     *          the sourceDonnes to set
     */
    public void setSourceDonnees(EnumSet<SourceDonnee> sourceDonnees_p)
    {
      if (sourceDonnees_p != null)
      {
        _sourceDonnees = sourceDonnees_p.clone();
      }
      else
      {
        _sourceDonnees.add(SourceDonnee.REFERENTIEL);
      }
    }

    /**
     * @param state_p
     *          the state to set
     */
    public void setState(State state_p)
    {
      _state = state_p;
    }

  }

  /**
   * Possibles source donne (Data sources)
   *
   * @author jramos
   * @version ($Revision$ $Date$)
   */
  public enum SourceDonnee
  {
    /**
     * Referentiel
     */
    REFERENTIEL;

  }

  /**
   *
   * @author jramos
   * @version ($Revision$ $Date$)
   */

  public enum State
  {
    /**
     * The next step to execute is:
     */
    PE0296_START(MandatoryProcessState.PRC_START),

    /**
    *
    */
    PE0296_BL001(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
    *
    */
    PE0296_BL002(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
    *
    */
    PE0296_BL005(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
    *
    */
    PE0296_BL100(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
    *
    */
    PE0296_BL200(MandatoryProcessState.PRC_RUNNING, false, false),

    /**
    *
    */
    ENDED(MandatoryProcessState.PRC_STOP, false, false);

    /**
     * Technical state associated.
     */
    protected MandatoryProcessState _technicalState = MandatoryProcessState.PRC_START;

    /**
     * The asynchronous state.
     */
    protected boolean _asynchronousState = false;

    /**
     * Replayable state.
     */
    protected boolean _replayableState = false;

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     */
    State(final MandatoryProcessState technicalState_p)
    {
      _technicalState = technicalState_p;
      _replayableState = false;
      _asynchronousState = false;
    }

    /**
     * Constructor.
     *
     * @param technicalState_p
     *          The {@link MandatoryProcessState} associated
     * @param replayable_p
     *          <code>true</code> if the state is replayable. <code>false</code> otherwise.
     * @param asynchronous_p
     *          The asynchronous state
     */
    State(final MandatoryProcessState technicalState_p, final Boolean replayable_p, final Boolean asynchronous_p)
    {
      _technicalState = technicalState_p;
      _replayableState = replayable_p;
      _asynchronousState = asynchronous_p;
    }

  }

  /**
   * Possible Url parameters this process can handle
   *
   * @author jramos
   * @version ($Revision$ $Date$)
   */
  protected enum UrlParameters
  {
    /**
     * clientOperateur
     */
    CLIENT_OPERATEUR("clientOperateur"), //$NON-NLS-1$
    /**
     * noCompte
     */
    NO_COMPTE("noCompte"), //$NON-NLS-1$
    /**
     * idFonctionnelPa
     */
    ID_FONCTIONNEL_PA("idFonctionnelPa"), //$NON-NLS-1$

    /**
     * idRaccordement
     */
    ID_RACCORDEMENT("idRaccordement"), //$NON-NLS-1$

    /**
     * sourceDonnee
     */
    SOURCE_DONNEE("sourceDonnee"), //$NON-NLS-1$
    /**
     * audit
     */
    AUDIT("audit"); //$NON-NLS-1$

    /**
     * Parameter name
     */
    private String _paramName;

    /**
     * @param name_p
     *          name
     */
    private UrlParameters(String name_p)
    {
      setParamName(name_p);
    }

    /**
     * @return the paramName
     */
    public String getParamName()
    {
      return _paramName;
    }

    /**
     * @param paramName_p
     *          the paramName to set
     */
    public void setParamName(String paramName_p)
    {
      _paramName = paramName_p;
    }

  }

  /**
   * Constant
   */
  private static final String SOURCE_DONNEE_DEFAULT = "sourceDonneeParDefaut"; //$NON-NLS-1$

  /**
   * Constant
   */
  private static final String AUDIT_DEFAULT = "auditParDefaut"; //$NON-NLS-1$

  /**
   * separator of sourceDonne url parameter
   */
  private static final String SOURCE_DONNES_SEPARATOR = ","; //$NON-NLS-1$

  /**
   * Serial Version
   */
  private static final long serialVersionUID = 1L;

  /**
   * Process Context
   */
  private PE0296_DiagnosticRaccordementContext _processContext;

  @Override
  public String createDefaultFunctionalResponse(Retour arg0_p) throws RavelException
  {
    return MarshallTools.marshall(arg0_p);
  }

  @Override
  public String getInternalState()
  {
    return _processContext.getState().toString();
  }

  @Override
  public Duration getSleepTime()
  {
    return Duration.ofMinutes(0);
  }

  @Override
  public MandatoryProcessState getTechnicalState()
  {
    return _processContext.getState()._technicalState;
  }

  @Override
  public void initializeContext()
  {
    super.initializeContext();
    _processContext = new PE0296_DiagnosticRaccordementContext();

  }

  @Override
  public boolean isAsynchronous()
  {
    return false;
  }

  @Override
  public boolean isReplayable()
  {
    return false;
  }

  @Override
  protected void exitKOMetroLog(String arg0_p)
  {
    ///
  }

  @Override
  @LogStartProcess
  protected void startGetProcess(Request request_p, Tracabilite tracabilite_p) throws RavelException
  {

    PE0296_BL001Return bl001Return = null;
    PE0296_BL100Return bl100Return = null;
    PE0296_BL200Return bl200Return = null;
    PE0296_Retour pe0296Retour = null;
    Retour retour = RetourFactory.createOkRetour();

    getProcessConfigParameters(tracabilite_p);

    bl001Return = PE0296_BL001_VerifierDonnees(tracabilite_p, request_p);
    retour = bl001Return.getRetour();

    if (isRetourOK(retour))
    {
      bl100Return = PE0296_BL100_RechercherListeIdRessourceRaccordement(tracabilite_p, bl001Return);
      retour = bl100Return.getRetour();
      if (isRetourOK(retour))
      {
        bl200Return = PE0296_BL200_ConstruireVueReferentiel(tracabilite_p, bl001Return, bl100Return.getListeIdRessourceRaccordement());
        retour = bl200Return.getRetour();
      }
    }
    if ((bl200Return != null) && (bl200Return.getListeReferentiel() != null))
    {
      pe0296Retour = PE0296_BL002_FormaterReponse(tracabilite_p, retour, bl200Return.getListeReferentiel());
    }
    else
    {
      pe0296Retour = PE0296_BL002_FormaterReponse(tracabilite_p, retour, null);
    }
    retour = PE0296_BL005_GererErreurPROSPER(tracabilite_p, retour);
    syncResponse(request_p, tracabilite_p, pe0296Retour);
    this.setRetour(retour);
    _processContext.setState(State.ENDED);
  }

  @Override
  protected void startMetroLog()
  {
    // Not required for now in Ravel
  }

  /**
   * Check is headers from Request
   *
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @return Retour
   */
  private Retour checkAndExtractHeaders(final Request request_p, Tracabilite tracabilite_p)
  {

    Retour retour = RetourFactory.createOkRetour();

    // Verifying if Headers exists

    String requestId = null;
    String process = null;
    String source = null;

    // Verifying if Headers exists

    for (RavelRequest.RequestHeader header : request_p.getRequestHeader())
    {
      if (IHttpHeadersConsts.X_REQUEST_ID.equalsIgnoreCase(header.getName()))
      {
        requestId = header.getValue();
      }
      else if (IHttpHeadersConsts.X_PROCESS.equalsIgnoreCase(header.getName()))
      {
        process = header.getValue();
      }
      else if (IHttpHeadersConsts.X_SOURCE.equalsIgnoreCase(header.getName()))
      {
        source = header.getValue();
      }

    }

    // check if  one or more of headers are missing
    if (StringTools.containsOneNullOrEmpty(requestId, source, process))
    {
      final StringJoiner joiner = new StringJoiner(", "); //$NON-NLS-1$
      if (StringTools.isNullOrEmpty(requestId))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), "X-Request-Id")); //$NON-NLS-1$ //$NON-NLS-2$
      }
      if (StringTools.isNullOrEmpty(source))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), "X-Source")); //$NON-NLS-1$//$NON-NLS-2$
      }
      if (StringTools.isNullOrEmpty(process))
      {
        joiner.add(MessageFormat.format(Messages.getString("Validation.RequiredField"), "X-Process")); //$NON-NLS-1$ //$NON-NLS-2$
      }

      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, joiner.toString());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.ERROR, tracabilite_p, joiner.toString()));

    }
    else
    {
      _processContext.setRequestId(requestId);
    }

    return retour;

  }

  /**
   * Check Url Parameters
   *
   * @param request_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   * @return Retour Check if Url Parameters are Ok
   */
  private Retour checkAndExtractUrlParameters(final Request request_p, final Tracabilite tracabilite_p)
  {
    Retour retour = RetourFactory.createOkRetour();

    String clientOperateur = null;
    String sourceDonnee = null;
    String audit = null;
    String idFonctionnelPa = null;
    String idRaccordement = null;
    String noCompte = null;

    // Checks if Parameters exists
    for (Parameter parameter : request_p.getUrlParameters().getUrlParameters())
    {
      if (UrlParameters.CLIENT_OPERATEUR.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        clientOperateur = parameter.getValue();
      }
      else if (UrlParameters.NO_COMPTE.getParamName().equalsIgnoreCase(parameter.getName()))
      {

        noCompte = parameter.getValue();
      }
      else if (UrlParameters.ID_FONCTIONNEL_PA.getParamName().equalsIgnoreCase(parameter.getName()))
      {

        idFonctionnelPa = parameter.getValue();
      }
      else if (UrlParameters.ID_RACCORDEMENT.getParamName().equalsIgnoreCase(parameter.getName()))
      {

        idRaccordement = parameter.getValue();
      }
      else if (UrlParameters.SOURCE_DONNEE.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        sourceDonnee = parameter.getValue();
      }
      else if (UrlParameters.AUDIT.getParamName().equalsIgnoreCase(parameter.getName()))
      {
        audit = parameter.getValue();
      }
    }

    EnumSet<SourceDonnee> sourceDonneeSet = EnumSet.noneOf(SourceDonnee.class);
    try
    {
      //validate parameter sourceDonne if present
      sourceDonneeSet = extractSourceDonneeFromStringParam(sourceDonnee);
    }
    finally
    {
      if (!sourceDonneeSet.isEmpty())
      {
        _processContext.setSourceDonnees(sourceDonneeSet);
      } //if sourceDonne not present in URL parameters the value will be the specified in the process configuration, REFERENTIEL by default
    }

    if (StringTools.isNotNullOrEmpty(audit))
    {
      Boolean auditBool = getAuditValue(audit);
      if (auditBool != null)
      {
        _processContext.setAudit(Boolean.valueOf(audit));
      }
    }

    _processContext.setClientOperateur(clientOperateur);
    _processContext.setIdentifiantFonctionnelPa(idFonctionnelPa);
    _processContext.setIdRaccordement(idRaccordement);
    _processContext.setNoCompte(noCompte);

    // Check combinations of parameters required

    short group = -1;
    if (!StringTools.containsOneNullOrEmpty(_processContext.getClientOperateur(), _processContext.getNoCompte(), _processContext.getIdentifiantFonctionnelPa(), _processContext.getSourceDonnees().toString(), _processContext.getAudit().toString()))
    {
      group = 1;
    }
    else if (!StringTools.containsOneNullOrEmpty(_processContext.getClientOperateur(), _processContext.getNoCompte(), _processContext.getSourceDonnees().toString(), _processContext.getAudit().toString()))
    {
      group = 2;
    }
    else if (!StringTools.containsOneNullOrEmpty(_processContext.getIdRaccordement(), _processContext.getSourceDonnees().toString(), _processContext.getAudit().toString()))
    {
      group = 3;
    }
    if (group == -1)
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ENTREE_INCORRECTE, ""); //$NON-NLS-1$
    }

    return retour;

  }

  /**
   * Add the possible values of parameter sourceDonnee to a Set of type SourceDonnee
   *
   * @param sourceDonnee_p
   *          The sourceDonnee parameter
   * @return The Set containing the sourceDonnee values, null if the sourceDonnee_p contains invalid values or empty set
   *         if sourceDonnee_p is empty
   */
  private EnumSet<SourceDonnee> extractSourceDonneeFromStringParam(String sourceDonnee_p)
  {
    EnumSet<SourceDonnee> sourceDonnees = EnumSet.noneOf(SourceDonnee.class);

    if (StringTools.isNotNullOrEmpty(sourceDonnee_p))
    {
      String[] sourceDonneeStr = sourceDonnee_p.trim().split(SOURCE_DONNES_SEPARATOR);
      for (String sd : sourceDonneeStr)
      {
        if (StringTools.isNotNullOrEmpty(sd))
        {
          SourceDonnee sourceDonnee;
          try
          {
            sourceDonnee = SourceDonnee.valueOf(sd.trim());
            sourceDonnees.add(sourceDonnee);
          }
          catch (Exception ex)
          {
            throw new IllegalArgumentException(Messages.getString("PE0296.BL001.SourceDonneeInvalide")); //$NON-NLS-1$
          }
        }

      }
    }
    return sourceDonnees;
  }

  /**
   * Filters List of ServiceTechniques
   *
   * @param listST_p
   *          listST
   * @param ressourceAggregeP2P_p
   *          ressourceAggregeP2P
   * @return List<StPfsOlt>
   */
  private List<StPfsOlt> filterListSTPfsOlt(List<ServiceTechnique> listST_p, RessourceAggregeP2P ressourceAggregeP2P_p)
  {

    List<StPfsOlt> listStPfsOlt = new ArrayList<>();

    List<ServiceTechnique> listeSTFilteredPfsOlt;

    StPfsOlt temp;
    DonneesIdentificationSTPfsOlt donnesIdentification;

    // Filter list of services techniques by PFS OLT
    listeSTFilteredPfsOlt = new StPfsOltFilter().filter(listST_p);

    for (ServiceTechnique st : listeSTFilteredPfsOlt)
    {
      temp = StPfsOlt.class.cast(st);
      donnesIdentification = temp.getDonneesIdentificationPfsOlt();
      if ((donnesIdentification != null) && donnesIdentification.getNomOlt().equals(ressourceAggregeP2P_p.getNomOLT()) && donnesIdentification.getPositionCarte().equals(Integer.toString(ressourceAggregeP2P_p.getPositionCarteP2P())) && donnesIdentification.getPositionRelativePort().equals(Integer.toString(ressourceAggregeP2P_p.getPositionRelativePortP2P())))
      {
        listStPfsOlt.add(temp);

      }
    }
    return listStPfsOlt;
  }

  /**
   * Get boolean value of audit parameter.
   *
   * @param audit_p
   *          The String audit parameter
   * @return The boolean value of audit
   */
  private Boolean getAuditValue(String audit_p)
  {
    Boolean audit = null;
    if (StringTools.isNotNullOrEmpty(audit_p))
    {
      try
      {
        audit = BooleanTools.toBooleanIgnoreCase(audit_p);
      }
      catch (Exception ex)
      {
        audit = false;
      }
    }
    return audit;
  }

  /**
   * Load process parameters into the process context
   *
   * @param tracabilite_p
   *          Tracabilite
   */
  private void getProcessConfigParameters(Tracabilite tracabilite_p)
  {
    final String sourceDonneeConfig = getConfigParameter(SOURCE_DONNEE_DEFAULT);
    final String auditConfig = getConfigParameter(AUDIT_DEFAULT);

    EnumSet<SourceDonnee> sourceDonnee = EnumSet.noneOf(SourceDonnee.class);
    try
    {
      sourceDonnee = extractSourceDonneeFromStringParam(sourceDonneeConfig);
    }
    catch (IllegalArgumentException e)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, MessageFormat.format(Messages.getString("PE0296.InvalidParameterValue"), "sourceDonneeAutorise", "[REFERENTIEL, PFS]"))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
    finally
    {
      if (sourceDonnee.isEmpty())
      {
        sourceDonnee = EnumSet.allOf(SourceDonnee.class);
      }
      _processContext.setSourceDonnees(sourceDonnee);
    }

    if (StringTools.isNotNullOrEmpty(auditConfig))
    {
      Boolean auditBool = getAuditValue(auditConfig);
      _processContext.setAudit(auditBool);
    }
    else
    {//set audit by default
      RavelLogger.log(new SpiritLogEvent(LogSeverity.WARNING, tracabilite_p, MessageFormat.format(Messages.getString("PE0296.InvalidParameterValue"), "auditVues", "false"))); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
      _processContext.setAudit(false);
    }

  }

  /**
   * Verification UrlParameters and Headers from request
   *
   * @param tracabilite_p
   *          tracibilite
   * @param request_p
   *          The request
   * @return Object {@Code PE0296_BL001_VerifierDonneesReturn}
   *
   * @throws RavelException
   *           on errors
   */
  @LogProcessBL
  private PE0296_BL001Return PE0296_BL001_VerifierDonnees(final Tracabilite tracabilite_p, final Request request_p) throws RavelException
  {

    _processContext.setState(State.PE0296_BL001);

    PE0296_BL001Return bl001return = new PE0296_BL001Return(RetourFactory.createOkRetour());

    Retour retour = checkAndExtractHeaders(request_p, tracabilite_p);

    // Check if Headers are Ok
    if (!isRetourOK(retour))
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, null);
      bl001return.setRetour(retour);
      this.setRetour(retour);
      return bl001return;
    }

    // Check if UrlParameters are Ok
    retour = checkAndExtractUrlParameters(request_p, tracabilite_p);

    if (!isRetourOK(retour))
    {
      retour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, null);
      bl001return.setRetour(retour);
      this.setRetour(retour);
      return bl001return;
    }

    bl001return.setClientOperateur(_processContext.getClientOperateur());
    bl001return.setIdentifiantFonctionnelPa(_processContext.getIdentifiantFonctionnelPa());
    bl001return.setIdRaccordement(_processContext.getIdRaccordement());
    bl001return.setNoCompte(_processContext.getNoCompte());
    bl001return.setSourceDonnee(_processContext.getSourceDonnees());
    bl001return.setAudit(_processContext.getAudit());
    bl001return.setRequestID(_processContext.getRequestId());

    bl001return.setRetour(retour);
    this.setRetour(retour);
    return bl001return;

  }

  /**
   * * Response formatter add erreur to response if the previous BLs sends an error, if not create a response ok.
   *
   * @param tracabilite_p
   *          Tracabilite
   * @param retour_p
   *          Retour of previous BL
   * @param listReferentiel_p
   *          list Referentiel
   *
   * @return {@link PE0296_Retour}
   */
  @LogProcessBL
  private PE0296_Retour PE0296_BL002_FormaterReponse(Tracabilite tracabilite_p, Retour retour_p, List<PE0296_Referentiel> listReferentiel_p)
  {
    _processContext.setState(State.PE0296_BL002);
    PE0296_Retour pe0296Retour = new PE0296_Retour();

    if (!isRetourOK(retour_p))
    {
      pe0296Retour.setError(retour_p.getDiagnostic());
      pe0296Retour.setErrordescription(retour_p.getLibelle());
    }
    else
    {
      pe0296Retour.setListReferentiel(listReferentiel_p);
    }

    return pe0296Retour;
  }

  /**
   * @param tracabilite_p
   *          The tracability
   * @param retour_p
   *          The retour to handle
   * @return {@link Retour}
   * @throws RavelException
   *           Exception thrown if something fails
   */
  @LogProcessBL
  private Retour PE0296_BL005_GererErreurPROSPER(Tracabilite tracabilite_p, Retour retour_p) throws RavelException
  {
    _processContext.setState(State.PE0296_BL005);

    return RetourFactory.createOkRetour();
  }

  /**
   * @param tracabilite_p
   *          tracabilite_
   * @param bl001Return_p
   *          bl001Return
   * @return PE0296_BL100Return
   * @throws RavelException
   *           Exception
   */
  @LogProcessBL
  private PE0296_BL100Return PE0296_BL100_RechercherListeIdRessourceRaccordement(Tracabilite tracabilite_p, PE0296_BL001Return bl001Return_p) throws RavelException
  {
    _processContext.setState(State.PE0296_BL100);
    PE0296_BL100Return bl100Return = new PE0296_BL100Return(RetourFactory.createOkRetour());

    ConnectorResponse<Retour, PFI> rpglireunRetour = null;

    List<PA> listePALigneFixe = new ArrayList<PA>();
    List<PA> listePALigneFixe2 = new ArrayList<PA>();

    List<String> temp = new ArrayList<>();

    if ((bl001Return_p != null) && StringTools.isNotNullOrEmpty(bl001Return_p.getIdRaccordement()))
    {
      temp.add(bl001Return_p.getIdRaccordement());
      bl100Return.setListeIdRessourceRaccordement(temp);
    }
    else
    {
      if (bl001Return_p != null)
      {
        rpglireunRetour = RPGProxy.getInstance().pfiLireUn(tracabilite_p, bl001Return_p.getClientOperateur(), bl001Return_p.getNoCompte());

        if (!isRetourOK(rpglireunRetour._first))
        {
          if (IMegConsts.DONNEE_INCONNUE.equals(rpglireunRetour._first.getDiagnostic()))
          {
            bl100Return.setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_COMPTE_INCONNU, MessageFormat.format(Messages.getString("PE0296.BL100.noCompteIconnu"), bl001Return_p.getNoCompte(), bl001Return_p.getClientOperateur()))); //$NON-NLS-1$
            return bl100Return;
          }
          bl100Return.setRetour(rpglireunRetour._first);
          return bl100Return;
        }

        PFIFilter type = new PFIFilter(PFIFilterOption.TYPE_PA, TypePA.LIGNE_FIXE.toString());
        PFIFilter statut = new PFIFilter(PFIFilterOption.STATUT, Statut.ACTIF.toString());
        PFIFilter idRaccordement = new PFIFilter(PFIFilterOption.IDENTIFIANT_RACCORDEMENT_PA, Operation.NOT_EQUALS, null);
        if (rpglireunRetour._second != null)
        {
          listePALigneFixe = PFIUtils.filterPA(rpglireunRetour._second.getPa(), type, statut, idRaccordement);
        }

        if (listePALigneFixe.isEmpty())
        {
          bl100Return.setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ID_PA_INCONNU, Messages.getString("PE0296.BL100.ID_PA_INCONNU"))); //$NON-NLS-1$
          return bl100Return;
        }

        PFIFilter idFonctionnelPa = new PFIFilter(PFIFilterOption.IDENTIFIANT_FONCTIONNEL_PA, bl001Return_p.getIdentifiantFonctionnelPa());

        if (StringTools.isNotNullOrEmpty(bl001Return_p.getIdentifiantFonctionnelPa()))
        {
          listePALigneFixe2 = PFIUtils.filterPA(listePALigneFixe, idFonctionnelPa);
          if (listePALigneFixe2.isEmpty())
          {
            bl100Return.setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ID_PA_INCONNU, MessageFormat.format(Messages.getString("PE0296.BL100.ID_PA_INCONNU_IDFONCTIONNEL"), bl001Return_p.getIdentifiantFonctionnelPa(), bl001Return_p.getClientOperateur(), bl001Return_p.getNoCompte()))); //$NON-NLS-1$
            return bl100Return;
          }
          listePALigneFixe = new ArrayList<>(listePALigneFixe2);
        }

        for (PA pa : listePALigneFixe)
        {
          temp.add(pa.getPaTypeLigneFixe().getIdRaccordement());
          bl100Return.setListeIdRessourceRaccordement(temp);
        }
      }
    }
    return bl100Return;
  }

  /**
   * @param tracabilite_p
   *          tracabilite
   * @param bl001Return_p
   *          bl001Return
   * @param listeIdRessourceRaccordement_p
   *          listeIdRessourceRaccordement
   * @return PE0296_BL200Return
   * @throws RavelException
   *           Exception
   */
  @LogProcessBL
  private PE0296_BL200Return PE0296_BL200_ConstruireVueReferentiel(Tracabilite tracabilite_p, PE0296_BL001Return bl001Return_p, List<String> listeIdRessourceRaccordement_p) throws RavelException
  {
    _processContext.setState(State.PE0296_BL200);

    Retour retour = RetourFactory.createOkRetour();

    PE0296_BL200Return bl200Return = new PE0296_BL200Return(RetourFactory.createOkRetour());

    List<ServiceTechnique> listeST = null;

    List<PE0296_Referentiel> listeReferentiel = new ArrayList<PE0296_Referentiel>();

    if ((bl001Return_p == null) || (bl001Return_p.getSourceDonnee() == null) || !bl001Return_p.getSourceDonnee().contains(SourceDonnee.REFERENTIEL))
    {
      return bl200Return;
    }

    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = null;
    // Chaque Ressource Raccordement est diagnostiqué indépendement
    List<PE0296_Erreur> listErreur = new ArrayList<>();

    for (String idRessourceRaccordement : listeIdRessourceRaccordement_p)
    {
      PE0296_Referentiel referentiel = new PE0296_Referentiel();
      referentiel.setClientOperateur(bl001Return_p.getClientOperateur());
      referentiel.setNoCompte(bl001Return_p.getNoCompte());
      referentiel.setIdRaccordement(idRessourceRaccordement);
      referentiel.setTypeService(TypeService.RACCORDEMENT.toString());
      listeReferentiel.add(referentiel);

      // On recherche la Ressource Raccordement

      ressourceLireUnRetour = RESProxy.getInstance().ressourceLireUn(tracabilite_p, idRessourceRaccordement, TypeRessource.RACCO.toString());
      retour = ressourceLireUnRetour._first;
      if (!isRetourOK(retour) && !IMegConsts.DONNEE_INCONNUE.equals(ressourceLireUnRetour._first.getDiagnostic()))
      {
        bl200Return.setRetour(retour);
        bl200Return.setListeReferentiel(listeReferentiel);
        return bl200Return;
      }
      //en cas d'erreur Type Donnee Inconnue on l'ignore
      retour = RetourFactory.createOkRetour();
      if ((ressourceLireUnRetour._second != null) && !EtatRessource.RESERVE.toString().equals(ressourceLireUnRetour._second.getStatut()) && !EtatRessource.ALLOUE.toString().equals(ressourceLireUnRetour._second.getStatut()))
      {
        ressourceLireUnRetour._second = null;
      }

      if (ressourceLireUnRetour._second == null)
      {
        if (StringTools.isNotNullOrEmpty(bl001Return_p.getIdRaccordement()))
        {
          bl200Return.setRetour(RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.RACCO_INCONNU, MessageFormat.format(Messages.getString("PE0296.BL200.RACCO_INCONNU"), idRessourceRaccordement))); //$NON-NLS-1$
          bl200Return.setListeReferentiel(listeReferentiel);
          return bl200Return;
        }

        referentiel.setEtatProvisioning(EtatProvisioning.ECHEC.toString());
        PE0296_Erreur erreur = new PE0296_Erreur(IMegConsts.DONNEE_INCONNUE, MessageFormat.format(Messages.getString("PE0296.BL200.RACCO_INCONNU_ASSOCIE"), idRessourceRaccordement)); //$NON-NLS-1$
        listErreur.add(erreur);
        referentiel.setErreurs(listErreur);
        continue;

      }
      // Si le service est appelé avec un idRaccordement, on recherche le PFI

      ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = null;

      if (StringTools.isNotNullOrEmpty(bl001Return_p.getIdRaccordement()))
      {

        stLireUnRetour = RSTProxy.getInstance().serviceTechniqueLireUn(tracabilite_p, ressourceLireUnRetour._second.getIdSt());
        retour = stLireUnRetour._first;
        if (!isRetourOK(retour) && !IMegConsts.DONNEE_INCONNUE.equals(retour.getDiagnostic()))
        {
          bl200Return.setRetour(retour);
          bl200Return.setListeReferentiel(listeReferentiel);
          return bl200Return;
        }

        if ((stLireUnRetour._second != null) && !stLireUnRetour._second.isEmpty())
        {
          bl001Return_p.setClientOperateur(stLireUnRetour._second.get(0).getClientOperateur());
          bl001Return_p.setNoCompte(stLireUnRetour._second.get(0).getNoCompte());
          referentiel.setClientOperateur(bl001Return_p.getClientOperateur());
          referentiel.setNoCompte(bl001Return_p.getNoCompte());
        }

      }

      ConnectorResponse<Retour, List<ServiceTechnique>> stLireTousRetour = null;

      // On recherche tous les Services Techniques du PFI

      if ((listeST == null) && StringTools.isNotNullOrEmpty(bl001Return_p.getClientOperateur()) && StringTools.isNotNullOrEmpty(bl001Return_p.getNoCompte()))
      {
        stLireTousRetour = RSTProxy.getInstance().serviceTechniqueLireTousParPfi(tracabilite_p, bl001Return_p.getClientOperateur(), bl001Return_p.getNoCompte(), null, null);
        retour = stLireTousRetour._first;
        listeST = stLireTousRetour._second;
        if (!isRetourOK(retour))
        {
          if (IMegConsts.DONNEE_INCONNUE.equals(retour.getDiagnostic()))
          {
            listeST = new ArrayList<ServiceTechnique>();
          }
          else
          {
            bl200Return.setRetour(retour);
            bl200Return.setListeReferentiel(listeReferentiel);
            return bl200Return;
          }
        }
      }

      ServiceTechnique stlac = null;
      List<ServiceTechnique> listestlac = new ArrayList<ServiceTechnique>();

      if ((stLireTousRetour != null) && (stLireTousRetour._second != null))
      {
        // filter st by type RACCO and idRessource
        listestlac = new StLacFilter()//
            .whereTypeRessourceIsEqual(TypeRessource.RACCO)//
            .whereIdRessourceIsEqual(idRessourceRaccordement)//
            .filter(listeST);
      }
      if (listestlac.isEmpty())
      {
        //
      }
      else if (listestlac.size() > 1)
      {
        PE0296_Erreur erreur = new PE0296_Erreur(IMegSpiritConsts.ERREUR_INTERNE, MessageFormat.format(Messages.getString("PE0296.BL200.PLUSIEURS_LAC"), idRessourceRaccordement)); //$NON-NLS-1$
        listErreur.add(erreur);
        referentiel.setErreurs(listErreur);
        referentiel.setEtatProvisioning(EtatProvisioning.ECHEC.toString());
        continue;
      }
      else
      {
        stlac = listestlac.get(0);
      }

      // On recherche l’objet RessourceAggrege correspondant à la Ressource Raccordement Demandee

      ConnectorResponse<Retour, RessourceAggrege> raP2PLireUnRetour = null;

      if ((ressourceLireUnRetour._second != null) && (ressourceLireUnRetour._second.getRessourceRaccordement() != null) && TypeRaccordement.P2P.toString().equals(ressourceLireUnRetour._second.getRessourceRaccordement().getTypeRaccordement()))
      {
        raP2PLireUnRetour = RESProxy.getInstance().pad3101RessourceAggregeP2PLireUn(tracabilite_p, TypeRaccordement.P2P.toString(), idRessourceRaccordement);
        retour = raP2PLireUnRetour._first;
        if (!isRetourOK(retour) && !IMegConsts.DONNEE_INCONNUE.equals(retour.getDiagnostic()))
        {
          bl200Return.setRetour(retour);
          bl200Return.setListeReferentiel(listeReferentiel);

          return bl200Return;
        }
      }

      RessourceAggregeP2P ressourceAggregeP2P = null;
      List<StPfsOlt> listeSTPFS = new ArrayList<>();

      if ((ressourceLireUnRetour._second.getRessourceRaccordement() != null) && TypeRaccordement.P2P.toString().equals(ressourceLireUnRetour._second.getRessourceRaccordement().getTypeRaccordement()))
      {
        if ((raP2PLireUnRetour != null) && (raP2PLireUnRetour._second != null))
        {
          ressourceAggregeP2P = RessourceAggregeP2P.class.cast(raP2PLireUnRetour._second);
          listeSTPFS = filterListSTPfsOlt(listeST, ressourceAggregeP2P);
        }

      }

      // L’ensemble des éléments ont étés collectés :
      // On construit les objets Ressource
      // La Ressource RACCORDEMENT :

      PE0296_Ressource ressource = new PE0296_Ressource();
      ressource.setTypeRessource(PE0296_Ressource.TypeRessource.RACCORDEMENT.toString());
      ressource.setEtatRessource(ressourceLireUnRetour._second.getStatut());

      if (EtatRessource.RESERVE.toString().equals(ressourceLireUnRetour._second.getStatut()))
      {
        ressource.setEtatAllocation(EtatAllocation.EN_COURS.toString());
      }
      else if (EtatRessource.ALLOUE.toString().equals(ressourceLireUnRetour._second.getStatut()))
      {
        if ((stlac == null) || (!com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString().equals(stlac.getStatut()) && !com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString().equals(stlac.getStatut())))
        {
          ressource.setEtatAllocation(EtatAllocation.EN_COURS.toString());
        }
        else if (Statut.ACTIF.toString().equals(stlac.getStatut()))
        {
          ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
        }
        else if (com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString().equals(stlac.getStatut()))
        {
          ressource.setEtatAllocation(EtatAllocation.ECHEC.toString());
        }
      }

      if ((ressourceLireUnRetour._second != null) && (ressourceLireUnRetour._second.getRessourceRaccordement() != null))
      {
        ressource.setCodeAccesTechnique(ressourceLireUnRetour._second.getRessourceRaccordement().getCodeAccesTechnique());
        ressource.setNomNR(ressourceLireUnRetour._second.getRessourceRaccordement().getNomNR());
      }

      List<PE0296_Ressource> listTempRessources = new ArrayList<>();
      if (referentiel.getRessources() != null)
      {
        listTempRessources = referentiel.getRessources();
      }
      listTempRessources.add(ressource);
      referentiel.setRessources(listTempRessources);

      if ((ressourceLireUnRetour._second != null) && (ressourceLireUnRetour._second.getRessourceRaccordement() != null) && TypeRaccordement.P2P.toString().equals(ressourceLireUnRetour._second.getRessourceRaccordement().getTypeRaccordement()))
      {
        if ((raP2PLireUnRetour != null) && (raP2PLireUnRetour._second != null))
        {
          ressourceAggregeP2P = RessourceAggregeP2P.class.cast(raP2PLireUnRetour._second);
        }
        ressource = new PE0296_Ressource();
        ressource.setTypeRessource(TypeRessource.PORT_P2P.toString());
        ressource.setEtatRessource(EtatRessource.ALLOUE.toString());
        ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
        if (ressourceAggregeP2P != null)
        {
          ressource.setNomOLT(ressourceAggregeP2P.getNomOLT());
          ressource.setPositionCarte(String.valueOf(ressourceAggregeP2P.getPositionCarteP2P()));
          ressource.setPositionRelativePort(String.valueOf(ressourceAggregeP2P.getPositionRelativePortP2P()));
          ressource.setDistanceCompatible(String.valueOf(ressourceAggregeP2P.getDistanceCompatible()));
        }

        if (referentiel.getRessources() != null)
        {
          listTempRessources = referentiel.getRessources();
        }
        listTempRessources.add(ressource);
        referentiel.setRessources(listTempRessources);
      }

      // On calcul l’étatProvisioning

      if ((ressourceLireUnRetour._second != null) && (ressourceLireUnRetour._second.getRessourceRaccordement() != null) && TypeRaccordement.P2P.toString().equals(ressourceLireUnRetour._second.getRessourceRaccordement().getTypeRaccordement()))
      {
        if (listeSTPFS.isEmpty())
        {
          referentiel.setEtatProvisioning(EtatProvisioning.EN_COURS.toString());
        }
        else
        {
          StPfsOlt sTPFSOLT = listeSTPFS.get(0);
          if (com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString().equals(sTPFSOLT.getStatut()))
          {
            referentiel.setEtatProvisioning(EtatAllocation.ECHEC.toString());
          }
          else if (com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString().equals(sTPFSOLT.getStatut()))
          {
            referentiel.setEtatProvisioning(EtatAllocation.REALISE.toString());
            if (sTPFSOLT.getDonneesProvisionnesPfsOlt() != null)
            {
              referentiel.setVlan(sTPFSOLT.getDonneesProvisionnesPfsOlt().getVlan());
            }

          }
          else
          {
            referentiel.setEtatProvisioning(EtatAllocation.EN_COURS.toString());

          }

        }
      }

    }
    bl200Return.setRetour(retour);
    bl200Return.setListeReferentiel(listeReferentiel);
    return bl200Return;
  }

  /**
   * Serializes the object in obj parameter and returns a string representing the object as json.
   *
   * @param obj
   *          The object to eserialize
   * @param clazz
   *          The class type of the objet to serialize from
   * @return The json String
   * @throws RavelException
   *           If thrown by the Json builder
   */
  private <T> String serializeWithMoshi(T obj, Class<T> clazz) throws RavelException
  {
    IRavelJson jsonBuilder = new RavelJsonBuilder() //
        .profil("STARK")//$NON-NLS-1$
        .build();
    final IRavelJsonAdapter<T> adapter = jsonBuilder.adapter(clazz);

    return adapter.toJson(obj);

  }

  /**
   * send a sync response for requester.
   *
   * @param request_p
   *          The request object
   * @param tracabilite_p
   *          Tracabilite
   * @param pe0296Retour_p
   *          the pe0296Retour
   * @throws RavelException
   *           Exception
   */
  private void syncResponse(Request request_p, Tracabilite tracabilite_p, PE0296_Retour pe0296Retour_p) throws RavelException
  {
    if (request_p != null)
    {
      IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
      Response rsp = null;
      ErrorCode errorCode = ErrorCode.KO_00503;

      if (pe0296Retour_p != null)
      {
        ravelResponse.setDataType("application/json"); //$NON-NLS-1$
        ravelResponse.setResult(serializeWithMoshi(pe0296Retour_p, PE0296_Retour.class));
        String erreur = pe0296Retour_p.getError();

        if (erreur == null)
        {
          errorCode = ErrorCode.OK_00200;
        }
        else
        {
          //mapping of error code according to STI
          switch (erreur)
          {
            case IMegSpiritConsts.NON_RESPECT_STI:
              errorCode = ErrorCode.KO_00400;
              break;
            case IMegSpiritConsts.ID_PA_INCONNU:
            case IMegSpiritConsts.NO_COMPTE_INCONNU:
              errorCode = ErrorCode.KO_00404;
              break;
            case IMegSpiritConsts.ERREUR_INTERNE:
              errorCode = ErrorCode.KO_00500;
              break;
            case IMegSpiritConsts.REJEU_TECHNIQUE:
              errorCode = ErrorCode.KO_00503;

          }
        }
      }

      rsp = new Response(errorCode, ravelResponse);

      request_p.setResponse(rsp);
      //log response
      SpiritLogEvent logEvent = new SpiritLogEvent(LogSeverity.DEBUG, tracabilite_p, "PE0296 response"); //$NON-NLS-1$
      logEvent.addField(IMegConsts.RESULTAT, ravelResponse.getResult(), false);
      RavelLogger.log(logEvent);

    }
  }

}
