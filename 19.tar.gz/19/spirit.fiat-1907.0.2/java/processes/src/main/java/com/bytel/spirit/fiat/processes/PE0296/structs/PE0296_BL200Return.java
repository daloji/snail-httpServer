/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0296.structs;

import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
public class PE0296_BL200Return extends AbstractBLReturn
{

  /**
   *
   */
  private static final long serialVersionUID = 1L;
  /**
   * Liste de PE0296Referentiel
   */
  List<PE0296_Referentiel> _listeReferentiel;

  /**
   * @param retour_p
   *          retour
   */
  public PE0296_BL200Return(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @param retour_p
   *          retour
   * @param listeReferentiel_p
   *          listePE0296Referentiel
   */
  public PE0296_BL200Return(Retour retour_p, List<PE0296_Referentiel> listeReferentiel_p)
  {
    super(retour_p);
    _listeReferentiel = listeReferentiel_p;
  }

  /**
   * @return the listeReferentiel
   */
  public List<PE0296_Referentiel> getListeReferentiel()
  {
    return _listeReferentiel != null ? new ArrayList<>(_listeReferentiel) : null;

  }

  /**
   * @param listeReferentiel_p
   *          the listeReferentiel to set
   */
  public void setListeReferentiel(List<PE0296_Referentiel> listeReferentiel_p)
  {
    _listeReferentiel = listeReferentiel_p != null ? new ArrayList<>(listeReferentiel_p) : null;

  }

}
