/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 *
 * @author lmerces
 * @version ($Revision$ $Date$)
 */
public class Messages
{
  /**
   * the internal BUNDLE_NAME.
   */
  private static final String BUNDLE_NAME = "com.bytel.spirit.fiat.processes.messages"; //$NON-NLS-1$

  /**
   * the internal RESOURCE_BUNDLE.
   */
  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(Messages.BUNDLE_NAME);

  /**
   * Get the string value.
   *
   * @param key
   *          the key
   * @return the value
   */
  public static String getString(String key)
  {
    try
    {
      return Messages.RESOURCE_BUNDLE.getString(key);
    }
    catch (MissingResourceException e)
    {
      return '!' + key + '!';
    }
  }

  /**
   * default constructor
   */
  private Messages()
  {
  }
}
