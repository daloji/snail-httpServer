/*******************************************************************************
* $Id: PE0298_BL200Return.java 16144 2019-01-22 10:53:19Z jsantos $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0298.structs;

import java.util.ArrayList;
import java.util.List;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.services.process.AbstractBLReturn;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Referentiel;

/**
 *
 * @author kbettenc
 * @version ($Revision: 16144 $ $Date: 2019-01-22 11:53:19 +0100 (mar. 22 janv. 2019) $)
 */
public class PE0298_BL200Return extends AbstractBLReturn
{

  /**
   *
   */
  private static final long serialVersionUID = -1775031457529104414L;

  /**
   * Identifiant de la demande
   */
  private List<PE0298_Referentiel> _listeReferentiel;

  /**
   * @param retour_p
   */
  public PE0298_BL200Return(Retour retour_p)
  {
    super(retour_p);
  }

  /**
   * @param retour_p
   * @param referentiel_p
   * @param stPfsVmsStw_p
   * @param stlac_p
   */
  public PE0298_BL200Return(Retour retour_p, List<PE0298_Referentiel> listeReferentiel_p)
  {
    super(retour_p);
    _listeReferentiel = listeReferentiel_p != null ? new ArrayList<>(listeReferentiel_p) : null;
  }

  /**
   * @return the listeReferentiel
   */
  public List<PE0298_Referentiel> getListeReferentiel()
  {
    return _listeReferentiel != null ? new ArrayList<>(_listeReferentiel) : new ArrayList<>();
  }

  /**
   * @param listeReferentiel_p
   *          the listeReferentiel to set
   */
  public void setListeReferentiel(List<PE0298_Referentiel> listeReferentiel_p)
  {
    _listeReferentiel = listeReferentiel_p != null ? new ArrayList<>(listeReferentiel_p) : new ArrayList<>();
  }
}
