/*******************************************************************************
 * $Id: PE0223_RetourBL100.java 9939 2018-09-07 08:29:42Z jiantila $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223.structs.get;

/**
 *
 * @author jiantila
 * @version ($Revision: 9939 $ $Date: 2018-09-07 10:29:42 +0200 (Fri, 07 Sep 2018) $)
 */
public class PE0223_BL100GetRetour
{
  /**
   *
   */
  private String _sMotdePassePCM;

  /**
   *
   */
  private String _sidPublicComptelms;

  /**
   * @return the sidPublicComptelms
   */
  public String getSidPublicComptelms()
  {
    return _sidPublicComptelms;
  }

  /**
   * @return the sMotdePassePCM
   */
  public String getsMotdePassePCM()
  {
    return _sMotdePassePCM;
  }

  /**
   * @param sidPublicComptelms_p
   *          the sidPublicComptelms to set
   */
  public void setSidPublicComptelms(String sidPublicComptelms_p)
  {
    _sidPublicComptelms = sidPublicComptelms_p;
  }

  /**
   * @param sMotdePassePCM_p
   *          the sMotdePassePCM to set
   */
  public void setsMotdePassePCM(String sMotdePassePCM_p)
  {
    _sMotdePassePCM = sMotdePassePCM_p;
  }

}
