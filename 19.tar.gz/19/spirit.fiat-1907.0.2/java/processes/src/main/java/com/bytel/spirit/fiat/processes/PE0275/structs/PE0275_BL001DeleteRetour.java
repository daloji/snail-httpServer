/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0275.structs;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
public class PE0275_BL001DeleteRetour
{
	
	/**
	 * Liste des Identifiants de message à supprimer
	 */
	private String _listIdMessage;

	/**
	 * Type de l’operation a executer
	 */
	private OperationMessage _typeOperation;

	/**
	 * Mode d’appel utilisés pour solliciter le service
	 */
	private String _modeAppel;

	/**
	 * List contracts auth
	 */
	private List<String> _listeContratOauth;

	/**
	 * @return the listIdMessage
	 */
	public String getListIdMessage()
	{
		return _listIdMessage;
	}

	/**
	 * @param listIdMessage_p
	 *            the_p listIdMessage to set
	 */
	public void setListIdMessage(String listIdMessage_p)
	{
		_listIdMessage = listIdMessage_p;
	}

	/**
	 * @return the _typeOperation
	 */
	public OperationMessage getTypeOperation()
	{
		return _typeOperation;
	}

	/**
	 * @param typeOperation_p
	 *            the typeOperation to set
	 */
	public void setTypeOperation(OperationMessage typeOperation_p)
	{
		_typeOperation = typeOperation_p;
	}

	/**
	 * @return the modeAppel
	 */
	public String getModeAppel()
	{
		return _modeAppel;
	}

	/**
	 * @param modeAppel_p
	 *            the modeAppel to set
	 */
	public void setModeAppel(String modeAppel_p)
	{
		_modeAppel = modeAppel_p;
	}

	/**
	 * @return the listeContratOauth
	 */
	public List<String> getListeContratOauth()
	{
		return _listeContratOauth != null ? new ArrayList<>(_listeContratOauth) : new ArrayList<>();
	}

	/**
	 * @param listeContratOauth_p
	 *            the listeContratOauth to set
	 */
	public void setListeContratOauth(List<String> listeContratOauth_p)
	{
		_listeContratOauth = new ArrayList<>(listeContratOauth_p);
	}
}
