/*******************************************************************************
* $Id: PE0298_PFS.java 15495 2019-01-08 14:56:48Z kbettenc $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0298.sti;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.squareup.moshi.Json;

/**
 *
 * @author kbettenc
 * @version ($Revision: 15495 $ $Date: 2019-01-08 15:56:48 +0100 (mar. 08 janv. 2019) $)
 */
public class PE0298_PFS implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = -8762821168754777471L;

  @Json(name = "typePfs")
  private String _typePfs;

  @Json(name = "noTelephone")
  private String _noTelephone;

  @Json(name = "typeMessagerie")
  private String _typeMessagerie;

  @Json(name = "statutMessagerie")
  private String _statutMessagerie;

  @Json(name = "adresseMailNotification")
  private String _adresseMailNotification;

  @Json(name = "statutNotificationEmail")
  private String _statutNotificationEmail;

  @Json(name = "audits")
  private List<PE0298_Audit> _audits;

  @Json(name = "erreurs")
  private List<PE0298_Erreur> _erreurs;

  /**
   *
   */
  public PE0298_PFS()
  {
    //Default constructor
  }

  /**
   * @param typePfs_p
   * @param noTelephone_p
   * @param typeMessagerie_p
   * @param statutMessagerie_p
   * @param adresseMailNotification_p
   * @param statutNotificationEmail_p
   * @param audits_p
   * @param erreurs_p
   */
  public PE0298_PFS(String typePfs_p, String noTelephone_p, String typeMessagerie_p, String statutMessagerie_p, String adresseMailNotification_p, String statutNotificationEmail_p, List<PE0298_Audit> audits_p, List<PE0298_Erreur> erreurs_p)
  {
    super();
    _typePfs = typePfs_p;
    _noTelephone = noTelephone_p;
    _typeMessagerie = typeMessagerie_p;
    _statutMessagerie = statutMessagerie_p;
    _adresseMailNotification = adresseMailNotification_p;
    _statutNotificationEmail = statutNotificationEmail_p;
    _audits = new ArrayList<>(audits_p);
    _erreurs = new ArrayList<>(erreurs_p);
  }

  /**
   * Add an PE0298_Audit object to the audit list
   *
   * @param audit_p
   *          The audit objet to add
   */
  public void addAudit(PE0298_Audit audit_p)
  {
    if (_audits == null)
    {
      _audits = new ArrayList<>();
    }
    _audits.add(audit_p);
  }

  /**
   * Add an PE0298_Erreur object to the list erreurs
   *
   * @param erreur_p
   *          The erreur objet to add.
   */
  public void addErreur(PE0298_Erreur erreur_p)
  {
    if (_erreurs == null)
    {
      _erreurs = new ArrayList<>();
    }
    _erreurs.add(erreur_p);
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0298_PFS other = (PE0298_PFS) obj;
    if (_adresseMailNotification == null)
    {
      if (other._adresseMailNotification != null)
      {
        return false;
      }
    }
    else if (!_adresseMailNotification.equals(other._adresseMailNotification))
    {
      return false;
    }
    if (_audits == null)
    {
      if (other._audits != null)
      {
        return false;
      }
    }
    else if (!_audits.equals(other._audits))
    {
      return false;
    }
    if (_erreurs == null)
    {
      if (other._erreurs != null)
      {
        return false;
      }
    }
    else if (!_erreurs.equals(other._erreurs))
    {
      return false;
    }
    if (_noTelephone == null)
    {
      if (other._noTelephone != null)
      {
        return false;
      }
    }
    else if (!_noTelephone.equals(other._noTelephone))
    {
      return false;
    }
    if (_statutMessagerie == null)
    {
      if (other._statutMessagerie != null)
      {
        return false;
      }
    }
    else if (!_statutMessagerie.equals(other._statutMessagerie))
    {
      return false;
    }
    if (_statutNotificationEmail == null)
    {
      if (other._statutNotificationEmail != null)
      {
        return false;
      }
    }
    else if (!_statutNotificationEmail.equals(other._statutNotificationEmail))
    {
      return false;
    }
    if (_typeMessagerie == null)
    {
      if (other._typeMessagerie != null)
      {
        return false;
      }
    }
    else if (!_typeMessagerie.equals(other._typeMessagerie))
    {
      return false;
    }
    if (_typePfs == null)
    {
      if (other._typePfs != null)
      {
        return false;
      }
    }
    else if (!_typePfs.equals(other._typePfs))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the adresseMailNotification
   */
  public String getAdresseMailNotification()
  {
    return _adresseMailNotification;
  }

  /**
   * @return the audits
   */
  public List<PE0298_Audit> getAudits()
  {
    return _audits != null ? new ArrayList<>(_audits) : new ArrayList<>();
  }

  /**
   * @return the erreurs
   */
  public List<PE0298_Erreur> getErreurs()
  {
    return _erreurs != null ? new ArrayList<>(_erreurs) : new ArrayList<>();
  }

  /**
   * @return the noTelephone
   */
  public String getNoTelephone()
  {
    return _noTelephone;
  }

  /**
   * @return the statutMessagerie
   */
  public String getStatutMessagerie()
  {
    return _statutMessagerie;
  }

  /**
   * @return the statutNotificationEmail
   */
  public String getStatutNotificationEmail()
  {
    return _statutNotificationEmail;
  }

  /**
   * @return the typeMessagerie
   */
  public String getTypeMessagerie()
  {
    return _typeMessagerie;
  }

  /**
   * @return the typePfs
   */
  public String getTypePfs()
  {
    return _typePfs;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_adresseMailNotification == null) ? 0 : _adresseMailNotification.hashCode());
    result = (prime * result) + ((_audits == null) ? 0 : _audits.hashCode());
    result = (prime * result) + ((_erreurs == null) ? 0 : _erreurs.hashCode());
    result = (prime * result) + ((_noTelephone == null) ? 0 : _noTelephone.hashCode());
    result = (prime * result) + ((_statutMessagerie == null) ? 0 : _statutMessagerie.hashCode());
    result = (prime * result) + ((_statutNotificationEmail == null) ? 0 : _statutNotificationEmail.hashCode());
    result = (prime * result) + ((_typeMessagerie == null) ? 0 : _typeMessagerie.hashCode());
    result = (prime * result) + ((_typePfs == null) ? 0 : _typePfs.hashCode());
    return result;
  }

  /**
   * @param adresseMailNotification_p
   *          the adresseMailNotification to set
   */
  public void setAdresseMailNotification(String adresseMailNotification_p)
  {
    _adresseMailNotification = adresseMailNotification_p;
  }

  /**
   * @param audits_p
   *          the audits to set
   */
  public void setAudits(List<PE0298_Audit> audits_p)
  {
    _audits = audits_p != null ? new ArrayList<>(audits_p) : null;
  }

  /**
   * @param erreurs_p
   *          the erreurs to set
   */
  public void setErreurs(List<PE0298_Erreur> erreurs_p)
  {
    _erreurs = erreurs_p != null ? new ArrayList<>(erreurs_p) : null;
  }

  /**
   * @param noTelephone_p
   *          the noTelephone to set
   */
  public void setNoTelephone(String noTelephone_p)
  {
    _noTelephone = noTelephone_p;
  }

  /**
   * @param statutMessagerie_p
   *          the statutMessagerie to set
   */
  public void setStatutMessagerie(String statutMessagerie_p)
  {
    _statutMessagerie = statutMessagerie_p;
  }

  /**
   * @param statutNotificationEmail_p
   *          the statutNotificationEmail to set
   */
  public void setStatutNotificationEmail(String statutNotificationEmail_p)
  {
    _statutNotificationEmail = statutNotificationEmail_p;
  }

  /**
   * @param typeMessagerie_p
   *          the typeMessagerie to set
   */
  public void setTypeMessagerie(String typeMessagerie_p)
  {
    _typeMessagerie = typeMessagerie_p;
  }

  /**
   * @param typePfs_p
   *          the typePfs to set
   */
  public void setTypePfs(String typePfs_p)
  {
    _typePfs = typePfs_p;
  }
}
