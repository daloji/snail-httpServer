/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0280.sti;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.bytel.spirit.common.shared.misc.validation.IValidationConst;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
public class PE0280_Fibre implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 2198225501779982364L;

  /**
   * Identifiant de la fibre au PBO dans le référentiel de l'Opérateur d'Immeuble
   */
  @SerializedName("identifiantFibre")
  @Expose
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  private String _identifiantFibre;

  /**
   * Identifiant du cable au PBO dans le référentiel de l'Opérateur d'Immeuble
   */
  @SerializedName("referenceCablePBO")
  @Expose
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Size(max = 30, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private String _referenceCablePBO;

  /**
   * Couleur du tube de la fibre au PBO
   */
  @SerializedName("informationTubePBO")
  @Expose
  @NotNull(message = IValidationConst.ATTRIBUT_OBLIGATOIRE_MANQUANT)
  @Size(max = 20, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private String _informationTubePBO;

  /**
   * Couleur de la fibre au PBO
   */
  @SerializedName("informationFibrePBO")
  @Expose
  @Size(max = 20, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private String _informationFibrePBO;

  /**
   * Etat de la fibre en Ingénierie mono-fibre
   */
  @SerializedName("etatFibre")
  @Expose
  private String _etatFibre;

  /**
   * Numéro de la PTO attribuée
   */
  @SerializedName("referencePrise")
  @Expose
  @Size(max = 30, message = IValidationConst.FORMAT_ATTRIBUT_NON_RESPECTE)
  private String _referencePrise;

  /**
   * @param fibre_p
   *          Fibre
   */
  public PE0280_Fibre(com.bytel.spirit.common.connector.oi.emutation.structs.Fibre fibre_p)
  {
    _identifiantFibre = fibre_p.getIdentifiantFibre();
    _referenceCablePBO = fibre_p.getReferenceCablePBO();
    _informationTubePBO = fibre_p.getInformationTubePBO();
    _informationFibrePBO = fibre_p.getInformationFibrePBO();
    _etatFibre = fibre_p.getEtatFibre();
    _referencePrise = fibre_p.getReferencePrise();
  }

  /**
   * @param identifiantFibre_p
   *          IdentifiantFibre
   * @param referenceCablePBO_p
   *          ReferenceCablePBO
   * @param informationTubePBO_p
   *          InformationTubePBO
   * @param informationFibrePBO_p
   *          InformationFibrePBO
   * @param etatFibre_p
   *          EtatFibre
   * @param referencePrise_p
   *          ReferencePrise
   */
  public PE0280_Fibre(String identifiantFibre_p, String referenceCablePBO_p, String informationTubePBO_p, String informationFibrePBO_p, String etatFibre_p, String referencePrise_p)
  {
    _identifiantFibre = identifiantFibre_p;
    _referenceCablePBO = referenceCablePBO_p;
    _informationTubePBO = informationTubePBO_p;
    _informationFibrePBO = informationFibrePBO_p;
    _etatFibre = etatFibre_p;
    _referencePrise = referencePrise_p;
  }

  @Override
  public boolean equals(Object obj)
  {
    if (this == obj)
    {
      return true;
    }
    if (obj == null)
    {
      return false;
    }
    if (getClass() != obj.getClass())
    {
      return false;
    }
    PE0280_Fibre other = (PE0280_Fibre) obj;
    if (_etatFibre == null)
    {
      if (other._etatFibre != null)
      {
        return false;
      }
    }
    else if (!_etatFibre.equals(other._etatFibre))
    {
      return false;
    }
    if (_identifiantFibre == null)
    {
      if (other._identifiantFibre != null)
      {
        return false;
      }
    }
    else if (!_identifiantFibre.equals(other._identifiantFibre))
    {
      return false;
    }
    if (_informationFibrePBO == null)
    {
      if (other._informationFibrePBO != null)
      {
        return false;
      }
    }
    else if (!_informationFibrePBO.equals(other._informationFibrePBO))
    {
      return false;
    }
    if (_informationTubePBO == null)
    {
      if (other._informationTubePBO != null)
      {
        return false;
      }
    }
    else if (!_informationTubePBO.equals(other._informationTubePBO))
    {
      return false;
    }
    if (_referenceCablePBO == null)
    {
      if (other._referenceCablePBO != null)
      {
        return false;
      }
    }
    else if (!_referenceCablePBO.equals(other._referenceCablePBO))
    {
      return false;
    }
    if (_referencePrise == null)
    {
      if (other._referencePrise != null)
      {
        return false;
      }
    }
    else if (!_referencePrise.equals(other._referencePrise))
    {
      return false;
    }
    return true;
  }

  /**
   * @return the etatFibre
   */
  public String getEtatFibre()
  {
    return _etatFibre;
  }

  /**
   * @return the identifiantFibre
   */
  public String getIdentifiantFibre()
  {
    return _identifiantFibre;
  }

  /**
   * @return the informationFibrePBO
   */
  public String getInformationFibrePBO()
  {
    return _informationFibrePBO;
  }

  /**
   * @return the informationTubePBO
   */
  public String getInformationTubePBO()
  {
    return _informationTubePBO;
  }

  /**
   * @return the referenceCablePBO
   */
  public String getReferenceCablePBO()
  {
    return _referenceCablePBO;
  }

  /**
   * @return the referencePrise
   */
  public String getReferencePrise()
  {
    return _referencePrise;
  }

  @Override
  public int hashCode()
  {
    final int prime = 31;
    int result = 1;
    result = (prime * result) + ((_etatFibre == null) ? 0 : _etatFibre.hashCode());
    result = (prime * result) + ((_identifiantFibre == null) ? 0 : _identifiantFibre.hashCode());
    result = (prime * result) + ((_informationFibrePBO == null) ? 0 : _informationFibrePBO.hashCode());
    result = (prime * result) + ((_informationTubePBO == null) ? 0 : _informationTubePBO.hashCode());
    result = (prime * result) + ((_referenceCablePBO == null) ? 0 : _referenceCablePBO.hashCode());
    result = (prime * result) + ((_referencePrise == null) ? 0 : _referencePrise.hashCode());
    return result;
  }

  /**
   * @param etatFibre_p
   *          the etatFibre to set
   */
  public void setEtatFibre(String etatFibre_p)
  {
    _etatFibre = etatFibre_p;
  }

  /**
   * @param identifiantFibre_p
   *          the identifiantFibre to set
   */
  public void setIdentifiantFibre(String identifiantFibre_p)
  {
    _identifiantFibre = identifiantFibre_p;
  }

  /**
   * @param informationFibrePBO_p
   *          the informationFibrePBO to set
   */
  public void setInformationFibrePBO(String informationFibrePBO_p)
  {
    _informationFibrePBO = informationFibrePBO_p;
  }

  /**
   * @param informationTubePBO_p
   *          the informationTubePBO to set
   */
  public void setInformationTubePBO(String informationTubePBO_p)
  {
    _informationTubePBO = informationTubePBO_p;
  }

  /**
   * @param referenceCablePBO_p
   *          the referenceCablePBO to set
   */
  public void setReferenceCablePBO(String referenceCablePBO_p)
  {
    _referenceCablePBO = referenceCablePBO_p;
  }

  /**
   * @param referencePrise_p
   *          the referencePrise to set
   */
  public void setReferencePrise(String referencePrise_p)
  {
    _referencePrise = referencePrise_p;
  }

  @Override
  public String toString()
  {
    return "Fibre [_identifiantFibre=" + _identifiantFibre + ", _referenceCablePBO=" + _referenceCablePBO + ", _informationTubePBO=" + _informationTubePBO + ", _informationFibrePBO=" + _informationFibrePBO + ", _etatFibre=" + _etatFibre + ", _referencePrise=" + _referencePrise + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$
  }
}
