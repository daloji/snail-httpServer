/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0275.sti;

import java.time.LocalDateTime;
import java.util.Objects;

import com.bytel.ravel.common.json.annotations.RavelLocalDateTimeFormat;
import com.bytel.ravel.common.json.format.impl.IsoShortOffsetDateTimeWithMillis;
import com.bytel.spirit.fiat.processes.structs.XItem;
import com.squareup.moshi.Json;

/**
 *
 * @author vloureir
 * @version ($Revision$ $Date$)
 */
public class PE0275_MessagesPFS extends XItem
{

  /**
   * Serial ID
   */
  private static final long serialVersionUID = -3453224580362472983L;

  /**
   * idMessagePFS
   */
  @Json(name = "idMessage")
  private String _idMessage;

  /**
   * idMessagerie
   */
  @Json(name = "idMessagerie")
  private String _idMessagerie;

  /**
   * expediteur
   */
  @Json(name = "expediteur")
  private String _expediteur;

  /**
   * typeMessage
   */
  @Json(name = "typeMessage")
  private String _typeMessage;

  /**
   * dateCreation
   */
  @Json(name = "dateDepot")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateDepot;

  /**
   * statutMessage
   */
  @Json(name = "statut")
  private String _statut;

  /**
   * duree
   */
  @Json(name = "duree")
  private String _duree;

  /**
   * typeMessage
   */
  @Json(name = "suivi")
  private PE0275_Suivi _suivi;

  /**
   * idCorrelation
   */
  @Json(name = "idCorrelation")
  private String _idCorrelation;

  /**
   * nbPages
   */
  @Json(name = "nbPages")
  private Integer _nbPages;

  /**
   * dateEnvoi
   */
  @Json(name = "dateEnvoi")
  @RavelLocalDateTimeFormat(IsoShortOffsetDateTimeWithMillis.class)
  private LocalDateTime _dateEnvoi;

  /**
   * destinataire
   */
  @Json(name = "destinataire")
  private String _destinataire;

  /**
   * emailNotification
   */
  @Json(name = "emailNotification")
  private String _emailNotification;

  /**
   * emailCopieFax
   */
  @Json(name = "emailCopieFax")
  private String _emailCopieFax;

  /**
   * @return value of _dateDepot
   */
  public LocalDateTime getDateDepot()
  {
    return _dateDepot;
  }

  /**
   * @return the dateEnvoi
   */
  public LocalDateTime getDateEnvoi()
  {
    return _dateEnvoi;
  }

  /**
   * @return the destinataire
   */
  public String getDestinataire()
  {
    return _destinataire;
  }

  /**
   * @return value of _duree
   */
  public String getDuree()
  {
    return _duree;
  }

  /**
   * @return the emailCopieFax
   */
  public String getEmailCopieFax()
  {
    return _emailCopieFax;
  }

  /**
   * @return the emailNotification
   */
  public String getEmailNotification()
  {
    return _emailNotification;
  }

  /**
   * @return value of _expediteur
   */
  public String getExpediteur()
  {
    return _expediteur;
  }

  /**
   * @return the idCorrelation
   */
  public String getIdCorrelation()
  {
    return _idCorrelation;
  }

  /**
   * @return value of _idMessage
   */
  public String getIdMessage()
  {
    return _idMessage;
  }

  /**
   * @return value of _idMessagerie
   */
  public String getIdMessagerie()
  {
    return _idMessagerie;
  }

  /**
   * @return the nbPages
   */
  public Integer getNbPages()
  {
    return _nbPages;
  }

  /**
   * @return value of _statut
   */
  public String getStatut()
  {
    return _statut;
  }

  /**
   * @return value of _suivi
   */
  public PE0275_Suivi getSuivi()
  {
    return _suivi;
  }

  /**
   * @return value of _typeMessage
   */
  public String getTypeMessage()
  {
    return _typeMessage;
  }

  /**
   * @param dateDepot_p
   *          The _dateDepot to set.
   */
  public void setDateDepot(LocalDateTime dateDepot_p)
  {
    _dateDepot = dateDepot_p;
  }

  /**
   * @param dateEnvoi_p
   *          the dateEnvoi to set
   */
  public void setDateEnvoi(LocalDateTime dateEnvoi_p)
  {
    _dateEnvoi = dateEnvoi_p;
  }

  /**
   * @param destinataire_p
   *          the destinataire to set
   */
  public void setDestinataire(String destinataire_p)
  {
    _destinataire = destinataire_p;
  }

  /**
   * @param duree_p
   *          The _duree to set.
   */
  public void setDuree(String duree_p)
  {
    _duree = duree_p;
  }

  /**
   * @param emailCopieFax_p
   *          the emailCopieFax to set
   */
  public void setEmailCopieFax(String emailCopieFax_p)
  {
    _emailCopieFax = emailCopieFax_p;
  }

  /**
   * @param emailNotification_p
   *          the emailNotification to set
   */
  public void setEmailNotification(String emailNotification_p)
  {
    _emailNotification = emailNotification_p;
  }

  /**
   * @param expediteur_p
   *          The _expediteur to set.
   */
  public void setExpediteur(String expediteur_p)
  {
    _expediteur = expediteur_p;
  }

  /**
   * @param idCorrelation_p
   *          the idCorrelation to set
   */
  public void setIdCorrelation(String idCorrelation_p)
  {
    _idCorrelation = idCorrelation_p;
  }

  /**
   * @param idMessage_p
   *          The _idMessage to set.
   */
  public void setIdMessage(String idMessage_p)
  {
    _idMessage = idMessage_p;
  }

  /**
   * @param idMessagerie_p
   *          The _idMessagerie to set.
   */
  public void setIdMessagerie(String idMessagerie_p)
  {
    _idMessagerie = idMessagerie_p;
  }

  /**
   * @param nbPages_p
   *          the nbPages to set
   */
  public void setNbPages(Integer nbPages_p)
  {
    _nbPages = nbPages_p;
  }

  /**
   * @param statut_p
   *          The _statut to set.
   */
  public void setStatut(String statut_p)
  {
    _statut = statut_p;
  }

  /**
   * @param suivi_p
   *          The _suivi to set.
   */
  public void setSuivi(PE0275_Suivi suivi_p)
  {
    _suivi = suivi_p;
  }

  /**
   * @param typeMessage_p
   *          The _typeMessage to set.
   */
  public void setTypeMessage(String typeMessage_p)
  {
    _typeMessage = typeMessage_p;
  }

  @Override
  public boolean equals(Object o_p)
  {
    if (this == o_p)
      return true;
    if (o_p == null || getClass() != o_p.getClass())
      return false;
    if (!super.equals(o_p))
      return false;
    PE0275_MessagesPFS that = (PE0275_MessagesPFS) o_p;
    return Objects.equals(_idMessage, that._idMessage) && Objects.equals(_idMessagerie, that._idMessagerie) && Objects.equals(_expediteur, that._expediteur) && Objects.equals(_typeMessage, that._typeMessage) && Objects.equals(_dateDepot, that._dateDepot) && Objects.equals(_statut, that._statut) && Objects.equals(_duree, that._duree) && Objects.equals(_suivi, that._suivi) && Objects.equals(_idCorrelation, that._idCorrelation) && Objects.equals(_nbPages, that._nbPages) && Objects.equals(_dateEnvoi, that._dateEnvoi) && Objects.equals(_destinataire, that._destinataire) && Objects.equals(_emailNotification, that._emailNotification) && Objects.equals(_emailCopieFax, that._emailCopieFax);
  }

  @Override
  public int hashCode()
  {
    return Objects.hash(super.hashCode(), _idMessage, _idMessagerie, _expediteur, _typeMessage, _dateDepot, _statut, _duree, _suivi, _idCorrelation, _nbPages, _dateEnvoi, _destinataire, _emailNotification, _emailCopieFax);
  }

  @Override
  public String toString()
  {
    return "PE0275_MessagesPFS [_idMessage=" + _idMessage + ", _idMessagerie=" + _idMessagerie + ", _expediteur=" + _expediteur + ", _typeMessage=" + _typeMessage + ", _dateDepot=" + _dateDepot + ", _statut=" + _statut + ", _duree=" + _duree + ", _suivi=" + _suivi + "]";
  }

}
