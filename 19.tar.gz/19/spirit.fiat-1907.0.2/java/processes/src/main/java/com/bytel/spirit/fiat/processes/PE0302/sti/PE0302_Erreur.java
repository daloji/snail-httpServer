/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302.sti;

import java.io.Serializable;

import com.squareup.moshi.Json;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
public class PE0302_Erreur implements Serializable
{
  /**
   *
   */
  private static final long serialVersionUID = 4036593248979904237L;

  /**
   * field error
   */
  @Json(name = "error")
  private String _error;

  /**
   * field error_description
   */
  @Json(name = "error_description")
  private String _errorDescription;

  /**
   * @return the error
   */
  public String getError()
  {
    return _error;
  }

  /**
   * @return the error_description
   */
  public String getErrorDescription()
  {
    return _errorDescription;
  }

  /**
   * @param error_p
   *          the error to set
   */
  public void setError(String error_p)
  {
    _error = error_p;
  }

  /**
   * @param error_description_p
   *          the error_description to set
   */
  public void setErrorDescription(String error_description_p)
  {
    _errorDescription = error_description_p;
  }
}
