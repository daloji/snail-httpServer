/*******************************************************************************
* $Id: PE0298_EffectuerDiagMessagerieVMSTest.java 21701 2019-05-21 15:24:06Z fbarnabe $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0298;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI026_LireRessourceNoTelephone;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI026_LireRessourceNoTelephone.OSSFAI_SI026_LireRessourceNoTelephoneBuilder;
import com.bytel.spirit.common.activities.ossfai.structs.si026.OSSFAI_SI026_Return;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective.BL5100_CreerActionCorrectiveBuilder;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.connectors.air.AIRProxy;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelleParameterizedType;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.ink.generated.Dataset;
import com.bytel.spirit.common.connectors.ink.generated.DatasetParam;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderDataResponse;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderResponse;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.MessageriePfs;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechnique;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechniqueVmsCvm;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechniqueVmsStw;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.TypeAction;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmscvm.DonneesIdentificationSTPfsVmsCvm;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmscvm.DonneesProvisionneesSTPfsVmsCvm;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmscvm.StPfsVmsCvm;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.DonneesIdentificationSTPfsVmsStw;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.DonneesProvisionneesSTPfsVmsStw;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.vmsstw.StPfsVmsStw;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.ressources.SpiritConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeVoip;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Audit;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Audit.Diagnostic;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Erreur;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Erreur.TypeError;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_PFS;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Referentiel;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Referentiel.EtatProvisionning;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Referentiel.TypeService;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Ressource;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Ressource.EtatAllocation;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Ressource.EtatRessource;
import com.bytel.spirit.fiat.processes.PE0298.sti.PE0298_Ressource.TypeRessource;
import com.bytel.spirit.fiat.processes.PE0298.structs.PE0298_Reponse;
import com.bytel.spirit.fiat.shared.types.json.Referentiel.EtatProvisioning;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author kbettenc
 * @version ($Revision: 21701 $ $Date: 2019-05-21 17:24:06 +0200 (mar. 21 mai 2019) $)
 */
@RunWith(PowerMockRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PrepareForTest({ PE0298_EffectuerDiagMessagerieVMS.class, BL5270_RecupererPfiParNoTelephone.class, BL5270_RecupererPfiParNoTelephoneBuilder.class, BL5100_CreerActionCorrective.class, BL5100_CreerActionCorrectiveBuilder.class, PROV_SI002_ExecuterProcessus.class, PROV_SI002_ExecuterProcessusBuilder.class, AIRProxy.class, RPGProxy.class, RSTProxy.class })
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
public class PE0298_EffectuerDiagMessagerieVMSTest
{
  /**
   *
   */
  private static final String PE0298_BL400_INCOHERENCE_TYPE_MESSAGERIE = "PE0298.BL400.IncoherenceTypeMessagerie"; //$NON-NLS-1$

  /**
   *
   */
  private static final String TYPE_RESSOURCE_NUMERO_TELEPHONE = "NUMERO_TELEPHONE"; //$NON-NLS-1$

  /**
   *
   */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ID_ST = "idSt"; //$NON-NLS-1$ 

  /**
  *
  */
  private static final String ID_ST_LIEN_ALLOCATION = "idStLienAllocation"; //$NON-NLS-1$

  /**
   *
   */
  private static final String NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CONSULTER_MESSAGERIE_VMS_PFS = "consulterMessagerieVmsPfs"; //$NON-NLS-1$

  /**
   *
   */
  private static final String NOM_PRENOM_UTILISATEUR = "nomPrenomUtilisateur"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ADRESSE_MAIL = "adresseMail"; //$NON-NLS-1$

  /**
   *
   */
  private static final String TYPE_MESSAGERIE = "typeMessagerie"; //$NON-NLS-1$

  /**
   *
   */
  private static final String LIGNE_MARCHE = "ligneMarche"; //$NON-NLS-1$

  /**
   *
   */
  private static final String IDENTIFIANT_FONCTIONNEL_PA = "identifiantFonctionnelPa"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS = "PE0298_EffectuerDiagMessagerieVMS"; //$NON-NLS-1$

  /**
   * bean Factory generation
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * Constant for action corrective creation error
   */
  private static final String ERROR_CREATION_ACTION_CORRECTIVE = Messages.getString("PE0298.BL400.ErrorDescrition"); //$NON-NLS-1$

  /**
   * PARAM_NO_TELEPHONE constant
   */
  private static final String PARAM_NO_TELEPHONE = NO_TELEPHONE;

  /**
   * The constant for BL001.ParameterNullOrEmpty message
   */
  private static final String MESSAGE_PARAMETER_NULL_OR_EMPTY = Messages.getString("PE0298.BL001.ParameterNullOrEmpty"); //$NON-NLS-1$

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    Parameter parameter = new Parameter();

    parameter.setName(name_p);
    parameter.setValue(value_p);

    return parameter;
  }

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Mock de {@Code PROV_SI002_ExecuterProcessus}
   */
  @MockStrict
  protected PROV_SI002_ExecuterProcessus _provSI002Mock;

  /**
   * PROV_SI002_ExecuterProcessusBuilder
   */
  @MockStrict
  PROV_SI002_ExecuterProcessusBuilder _si002_mockbuilder;

  /**
   * OSSFAI_SI026_LireRessourceNoTelephoneBuilder
   */
  @MockStrict
  OSSFAI_SI026_LireRessourceNoTelephoneBuilder _ossFaiSI026_mockbuilder;

  /**
   * OSSFAI_SI026_LireRessourceNoTelephone
   */
  @MockStrict
  OSSFAI_SI026_LireRessourceNoTelephone _ossFaiSI026;

  /**
   * Mock de {@Code BL5270_RecupererPfiParNoTelephone}
   */
  @MockStrict
  protected BL5270_RecupererPfiParNoTelephone _bl5270Mock;

  /**
   * Mock de {@Code BL5100_CreerActionCorrective}
   */
  @MockStrict
  protected BL5100_CreerActionCorrective _bl5100Mock;

  /**
   * Mock de {@Code BL5100_CreerActionCorrective}
   */
  @MockStrict
  protected BL5100_CreerActionCorrectiveBuilder _bl5100MockBuilder;

  /**
   * Mock de {@Code ResponseConnector}
   */
  @MockStrict
  protected ResponseConnector _responseConnectorMock;

  /**
   * Mock de {@Code RPGProxy}
   */
  @MockStrict
  protected RPGProxy _rpgMock;

  /**
   * Mock de {@Code RSTProxy}
   */
  @MockStrict
  protected RSTProxy _rstMock;

  /**
   * Instance to evaluate
   */
  @MockNice("getConfigParameter")
  private PE0298_EffectuerDiagMessagerieVMS _processInstance;

  /**
   * Tracabilite
   */
  Tracabilite _tracabilite;

  /**
   * Mock de {@code AIRProxy}
   */
  @MockStrict
  private AIRProxy _airProxyMock;

  /**
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _processInstance = new PE0298_EffectuerDiagMessagerieVMS();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojoWithFullData(Tracabilite.class);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(null);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setRefFonc(new HashMap<>());

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(AIRProxy.class);
    PowerMock.mockStaticStrict(RPGProxy.class);
    PowerMock.mockStaticStrict(RSTProxy.class);
  }

  /**
   * Method that does the needed clean up.<br/>
   *
   * <b>Entrées:</b> N/A for this test method. <br/>
   * <b>Attendu:</b> Clean up of some of our data.
   *
   */
  @After
  public void tearDown()
  {
    _processInstance = null;
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS#PE0298_BL001_VerifierDonnees} KO car STI non
   * respecté<BR>
   * <b>Entrées:</b> Paramètre noTelephone manquant<br/>
   * <b>Attendu:</b> Error NOK, CAT-3, NON_RESPECT_STI <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_001() throws Throwable
  {
    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, null);

    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);
    ReponseErreur reponseErreur = RavelJsonTools.getInstance().fromJson(response.getResult(), ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(IMegSpiritConsts.NON_RESPECT_STI, reponseErreur.getError());
    Assert.assertEquals(MessageFormat.format(MESSAGE_PARAMETER_NULL_OR_EMPTY, PARAM_NO_TELEPHONE), reponseErreur.getErrorDescription());

  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS#PE0298_BL001_VerifierDonnees} KO car BL5270 KO<BR>
   * <b>Entrées:</b> BL5270 retourne KO CAT-4 DONNEE_INCONNUE<br/>
   * <b>Attendu:</b> KO 404, {"error":"NO_TELEPHONE_INCONNU","error_description":"Numéro Téléphone noTelephone
   * inconnu"}<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_002() throws Throwable
  {
    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    Retour retourBL5270 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "donnee inconnue"); //$NON-NLS-1$
    createAIRMock(_tracabilite, retourBL5270, NO_TELEPHONE, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);
    PowerMock.verify();

    ReponseErreur reponseErreur = RavelJsonTools.getInstance().fromJson(response.getResult(), ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(IMegSpiritConsts.NO_TELEPHONE_INCONNU, reponseErreur.getError());
    Assert.assertEquals(MessageFormat.format(Messages.getString("PE0298.BL001.NumeroTelephoneInconnu"), NO_TELEPHONE), reponseErreur.getErrorDescription());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS#PE0298_BL001_VerifierDonnees} KO car BL5270 KO<BR>
   * <b>Entrées:</b> RSTProxy retourne KO CAT-1 ERREUR_TECHNIQUE<br/>
   * <b>Attendu:</b> KO 500 {error="ERREUR_INTERNE",error_description="erreur technique"}} <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_003() throws Throwable
  {
    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    Retour retourBL5270 = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, "erreur technique"); //$NON-NLS-1$
    createAIRMock(_tracabilite, retourBL5270, NO_TELEPHONE, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    ReponseErreur reponseErreur = RavelJsonTools.getInstance().fromJson(response.getResult(), ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(retourBL5270.getDiagnostic(), reponseErreur.getError());
    Assert.assertEquals(retourBL5270.getLibelle(), reponseErreur.getErrorDescription());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS#PE0298_BL200_ConstruireVueReferentiel} KO car
   * serviceTechniqueLireTousParPfi KO <BR>
   * <b>Entrées:</b> RSTProxy retourne KO CAT-1 ERREUR_TECHNIQUE<br/>
   * <b>Attendu:</b> KO 500 {error="ERREUR_TECHNIQUE",error_description="erreur technique"}} <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_004() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    Retour retourRST = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, "erreur technique"); //$NON-NLS-1$

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, retourRST, null, CLIENT_OPERATEUR, NO_COMPTE);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    ReponseErreur reponseErreur = RavelJsonTools.getInstance().fromJson(response.getResult(), ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(retourRST.getDiagnostic(), reponseErreur.getError());
    Assert.assertEquals(retourRST.getLibelle(), reponseErreur.getErrorDescription());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS#PE0298_BL200_ConstruireVueReferentiel} KO car
   * serviceTechniqueLireTousParPfi KO <BR>
   * <b>Entrées:</b> RSTProxy retourne KO CAT-4 DONNEE_INCONNUE<br/>
   * <b>Attendu:</b> OK, {"referentiels":[{"erreurs":[{"error":"ERREUR_INTERNE","error_description":"Probleme QOD sur la
   * ressource NO_TELEPHONE
   * ERREUR_TECHNIQUE"}],"etatProvisioning":"EN_COURS","noTelephone":"noTelephone","typeService":"MESSAGERIE"}]}<br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_005() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    Retour retourRST = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "donnée inconnue"); //$NON-NLS-1$
    Retour retourOssFaiSI026 = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, "erreur technique");

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, retourRST, null, CLIENT_OPERATEUR, NO_COMPTE);
    prepareOssFai_SI026(retourOssFaiSI026, _tracabilite, NO_TELEPHONE, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);
    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    referentielExpected.setEtatProvisioning(EtatProvisionning.EN_COURS.toString());
    referentielExpected.addErreur(new PE0298_Erreur(IMegSpiritConsts.ERREUR_INTERNE, Messages.getString("PE0298.BL001.ProblemeQOD") + retourOssFaiSI026.getDiagnostic()));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertNull(pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel sans audit OK avec un service
   * technique LAC inactif<BR>
   * <b>Entrées:</b> RSTProxy retourne uniquement un STLAC inactif<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li>noTelephone = "noTelephone"</li>
   * <li>typeService = "MESSAGERIE"</li>
   * <li>etatProvisionning = "EN_COURS"</li>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_006() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = new ArrayList<>();
    ServiceTechnique serviceTechniqueLAC = new StLienAllocationCommercial(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.INACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, null, null, null, NO_TELEPHONE, TYPE_RESSOURCE_NUMERO_TELEPHONE);
    listeServiceTechnique.add(serviceTechniqueLAC);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION));

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);
    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    referentielExpected.setEtatProvisioning(EtatProvisionning.EN_COURS.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatRessource(PE0298_Ressource.EtatRessource.ALLOUE.toString());
    ressource.setEtatAllocation(EtatAllocation.EN_COURS.toString());
    referentielExpected.setRessources(Arrays.asList(ressource));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertNull(pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel sans audit OK avec un service
   * technique LAC actif<BR>
   * <b>Entrées:</b> RSTProxy retourne uniquement un STLAC actif<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#EN_COURS}}
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </li>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_007() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION));

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);
    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    referentielExpected.setEtatProvisioning(EtatProvisioning.EN_COURS.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(PE0298_Ressource.EtatRessource.ALLOUE.toString());
    referentielExpected.setRessources(Arrays.asList(ressource));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertNull(pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel sans audit OK avec un service
   * technique LAC en échec<BR>
   * <b>Entrées:</b> RSTProxy retourne uniquement un STLAC en échec<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#EN_COURS}}
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#ECHEC}
   * </ul>
   * </li>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_008() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION));

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);
    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    referentielExpected.setEtatProvisioning(EtatProvisionning.EN_COURS.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.ECHEC.toString());
    ressource.setEtatRessource(PE0298_Ressource.EtatRessource.ALLOUE.toString());
    referentielExpected.setRessources(Arrays.asList(ressource));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertNull(pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel sans audit OK avec un service
   * technique PFS STW inactifc<BR>
   * <b>Entrées:</b> RSTProxy retourne uniquement un ST PFS STW inactif<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#EN_COURS}}</li>
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatRessource = {@link EtatRessource#ALLOUE}
   * <li/>etatAllocation = {@link EtatAllocation#EN_COURS}
   * </ul>
   * </ul>
   * </li>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_009() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = new ArrayList<>();
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.INACTIF.name(), CLIENT_OPERATEUR, NO_COMPTE, null);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);
    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    referentielExpected.setEtatProvisioning(EtatProvisionning.EN_COURS.toString());
    PE0298_Ressource ressourceExpected = new PE0298_Ressource();
    ressourceExpected.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressourceExpected.setEtatRessource(ossfaiSI026Return.getStatut());
    ressourceExpected.setEtatAllocation(EtatAllocation.EN_COURS.toString());
    referentielExpected.addRessource(ressourceExpected);

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertNull(pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel sans audit OK avec un service
   * technique PFS STW actif<BR>
   * <b>Entrées:</b> RSTProxy retourne uniquement un ST PFS STW actif<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatRessource = {@link EtatRessource#ALLOUE}
   * <li/>etatAllocation = {@link EtatAllocation#EN_COURS}
   * </ul>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_010() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = new ArrayList<>();

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);
    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    referentielExpected.setEtatProvisioning(EtatProvisioning.REALISE.toString());
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsStw.getTypeUsage());
    PE0298_Ressource ressourceExpected = new PE0298_Ressource();
    ressourceExpected.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressourceExpected.setEtatRessource(ossfaiSI026Return.getStatut());
    ressourceExpected.setEtatAllocation(EtatAllocation.EN_COURS.toString());
    referentielExpected.addRessource(ressourceExpected);

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertNull(pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel sans audit OK avec un service
   * technique PFS STW en échec<BR>
   * <b>Entrées:</b> RSTProxy retourne uniquement un ST PFS STW échec<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#ECHEC}}
   * <li/>typeMessagerie = "typeMessagerie"
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_011() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = new ArrayList<>();

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);
    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    referentielExpected.setEtatProvisioning(EtatProvisioning.ECHEC.toString());
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsStw.getTypeUsage());
    PE0298_Ressource ressourceExpected = new PE0298_Ressource();
    ressourceExpected.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressourceExpected.setEtatRessource(ossfaiSI026Return.getStatut());
    ressourceExpected.setEtatAllocation(EtatAllocation.EN_COURS.toString());
    referentielExpected.addRessource(ressourceExpected);

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertNull(pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel sans audit OK avec un service
   * technique LAC actif et un service technique PFS STW actif<BR>
   * <b>Entrées:</b> RSTProxy retourne un ST LAC actif un ST PFS STW actif<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_012() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);
    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(ossfaiSI026Return.getStatut());
    referentielExpected.addRessource(ressource);
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsStw.getTypeUsage());
    referentielExpected.setEtatProvisioning(EtatProvisionning.REALISE.toString());

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertNull(pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel et PFS sans audit avec un
   * service technique LAC actif et un service technique PFS STW actif avec appel PROV_SI0002 KO<BR>
   * <b>Entrées:</b> PROV_SI002 KO CAT-4 DONNEE_INCONNUE<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </ul>
   * </li>
   * <li>PFS :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typePfs = VMS_STW
   * <li>audit =
   * <ul>
   * <li/>diagnostic = SERVICE_NON_PROVISIONNE
   * <li/>libelle = Service non provisionne sur la PFS
   * </ul>
   * </li>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_013() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);
    ListeParametre listeParametresSI002 = new ListeParametre();
    listeParametresSI002.add(NO_TELEPHONE, NO_TELEPHONE);

    Retour retourProvSI002 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "donnée inconnue"); //$NON-NLS-1$

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, "REFERENTIEL,PFS", null); //$NON-NLS-1$

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION));
    prepareProv_SI002(retourProvSI002, _tracabilite, listeParametresSI002, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(PE0298_Ressource.EtatRessource.ALLOUE.toString());
    referentielExpected.setRessources(Arrays.asList(ressource));
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsStw.getTypeUsage());
    referentielExpected.setEtatProvisioning(EtatProvisionning.REALISE.toString());

    PE0298_PFS pfsExpected = new PE0298_PFS();
    pfsExpected.setNoTelephone(NO_TELEPHONE);
    pfsExpected.addAudit(new PE0298_Audit(IMegSpiritConsts.SERVICE_NON_PROVISIONNE, Messages.getString("PE0298.BL301.ServiceNonProvisionne")));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertEquals(Arrays.asList(pfsExpected), pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel et PFS sans audit avec un
   * service technique LAC actif et un service technique PFS STW actif avec appel PROV_SI0002 KO<BR>
   * <b>Entrées:</b> PROV_SI002 KO CAT-1 ERREUR_TECHNIQUE<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </ul>
   * </li>
   * <li>PFS :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typePfs = VMS_STW
   * <li>erreur =
   * <ul>
   * <li/>diagnostic = ERREUR_INTERNE
   * <li/>libelle = Erreur d'appel interne sur le service en charge de la connexion a la PFS
   * </ul>
   * </li>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_014() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);
    ListeParametre listeParametresSI002 = new ListeParametre();
    listeParametresSI002.add(NO_TELEPHONE, NO_TELEPHONE);

    Retour retourProvSI002 = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, "ERREUR_TECHNIQUE"); //$NON-NLS-1$

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, "REFERENTIEL,PFS", null); //$NON-NLS-1$

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION));
    prepareProv_SI002(retourProvSI002, _tracabilite, listeParametresSI002, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(PE0298_Ressource.EtatRessource.ALLOUE.toString());
    referentielExpected.setRessources(Arrays.asList(ressource));
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsStw.getTypeUsage());
    referentielExpected.setEtatProvisioning(EtatProvisionning.REALISE.toString());

    PE0298_PFS pfsExpected = new PE0298_PFS();
    pfsExpected.setNoTelephone(NO_TELEPHONE);
    pfsExpected.setErreurs(Arrays.asList(new PE0298_Erreur(IMegSpiritConsts.ERREUR_INTERNE, Messages.getString("PE0298.BL301.ErreurInterne"))));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertEquals(Arrays.asList(pfsExpected), pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel et PFS, avec audit. Incohérence
   * du typeMessagerie trouvé dans le ST PFS STW et le PFS<BR>
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li>erreur =
   * <ul>
   * <li/>diagnostic = NO_TELEPHONE_INCONNU
   * <li/>libelle = libellé de l'erreur du BL5270 (ici, donnée inconnue)
   * </ul>
   * </li>
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </ul>
   * </li>
   * <li>PFS :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typePfs = VMS_STW
   * <li>audit =
   * <ul>
   * <li/>diagnostic = {@link Diagnostic#DESYNCHRO_PFS}
   * <li/>libelle = Le service messagerie ne devrait pas être provisionné sur la VMS
   * </ul>
   * </li>
   * <li>erreur =
   * <ul>
   * <li/>diagnostic = {@link TypeError#ECHEC_ACTION_CORRECTIVE}
   * <li/>libelle = libellé de l'erreur du BL5100 (ici, erreur technique)
   * </ul>
   * </li>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_016() throws Throwable
  {

    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);
    ListeParametre listeParametresSI002 = new ListeParametre();
    listeParametresSI002.add(NO_TELEPHONE, NO_TELEPHONE);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, "REFERENTIEL,PFS", Boolean.TRUE); //$NON-NLS-1$

    ReponseFonctionnelle<MessageriePfs> reponseFonctionnelle = createReponseFonctionnelle();
    reponseFonctionnelle.getItems().get(0).setTypeMessagerie("FAX"); //$NON-NLS-1$
    reponseFonctionnelle.getItems().get(0).setTypePfs(TypePFS.VMS_STW.toString());
    ResponseConnector responseConnector = createResponseConnector(reponseFonctionnelle);

    Retour retourOk = RetourFactory.createOkRetour();

    createAIRMock(_tracabilite, retourOk, NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, retourOk, pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, retourOk, listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);
    prepareProv_SI002(retourOk, _tracabilite, listeParametresSI002, responseConnector);

    ActionServiceTechniqueVmsStw actionServiceTechnique = new ActionServiceTechniqueVmsStw(TypeAction.MODIFICATION.name(), com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), null);
    actionServiceTechnique.setIdSt(ID_ST);
    actionServiceTechnique.setTypePfs(TypePFS.VMS_STW.toString());
    actionServiceTechnique.setDonneesProvisionneesStPfsVmsStw(donneesProvisionneesSTPfsVmsStw);

    List<ActionServiceTechnique> astList = Arrays.asList(actionServiceTechnique);

    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);
    actionCorrective.setActionsServicesTechniques(astList);
    Retour retourBL5100 = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, "erreur technique"); //$NON-NLS-1$
    String idActionCorrective = "idActionCorrective"; //$NON-NLS-1$
    createBL5100Mock(_tracabilite, retourBL5100, _tracabilite.getIdCorrelationByTel() + NO_TELEPHONE, actionCorrective, idActionCorrective);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(ossfaiSI026Return.getStatut());
    referentielExpected.setRessources(Arrays.asList(ressource));
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsStw.getTypeUsage());
    referentielExpected.setEtatProvisioning(EtatProvisionning.REALISE.toString());

    PE0298_PFS pfsExpected = new PE0298_PFS();
    pfsExpected.setNoTelephone(NO_TELEPHONE);
    pfsExpected.setTypePfs(TypePFS.VMS_STW.toString());
    pfsExpected.setTypeMessagerie(reponseFonctionnelle.getItems().get(0).getTypeMessagerie());
    pfsExpected.setStatutMessagerie(reponseFonctionnelle.getItems().get(0).getStatutMessagerie());
    pfsExpected.setAudits(Arrays.asList(new PE0298_Audit(Diagnostic.DESYNCHRO_PFS.toString(), Messages.getString("PE0298.BL400.LibelleDesynchroPfs"))));
    pfsExpected.getAudits().get(0).addParameter(TYPE_MESSAGERIE);

    pfsExpected.setErreurs(Arrays.asList(new PE0298_Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), MessageFormat.format(ERROR_CREATION_ACTION_CORRECTIVE, retourBL5100.getDiagnostic()))));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertEquals(Arrays.asList(pfsExpected), pe0298_Reponse.getPfs());
    Assert.assertEquals(idActionCorrective, pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel et PFS, avec audit. Le service
   * messagerie ne devrait pas être provisionné sur la VMS<BR>
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#EN_COURS}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li>erreur =
   * <ul>
   * <li/>diagnostic = NO_TELEPHONE_INCONNU
   * <li/>libelle = libellé de l'erreur du BL5270 (ici, donnée inconnue)
   * </ul>
   * </li>
   * </ul>
   * </li>
   * <li>PFS :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typePfs = VMS_STW
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_017() throws Throwable
  {

    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = new ArrayList<>();

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.INACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);
    ListeParametre listeParametresSI002 = new ListeParametre();
    listeParametresSI002.add(NO_TELEPHONE, NO_TELEPHONE);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, "REFERENTIEL,PFS", Boolean.TRUE); //$NON-NLS-1$

    ReponseFonctionnelle<MessageriePfs> reponseFonctionnelle = createReponseFonctionnelle();
    reponseFonctionnelle.getItems().get(0).setTypeMessagerie("FAX"); //$NON-NLS-1$
    reponseFonctionnelle.getItems().get(0).setTypePfs(TypePFS.VMS_STW.toString());
    ResponseConnector responseConnector = createResponseConnector(reponseFonctionnelle);

    Retour retourOk = RetourFactory.createOkRetour();

    createAIRMock(_tracabilite, retourOk, NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, retourOk, pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, retourOk, listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);
    prepareProv_SI002(retourOk, _tracabilite, listeParametresSI002, responseConnector);

    ActionServiceTechniqueVmsStw actionServiceTechnique = new ActionServiceTechniqueVmsStw(TypeAction.MODIFICATION.name(), com.bytel.spirit.common.shared.saab.rst.Statut.INACTIF.toString(), null);
    actionServiceTechnique.setIdSt(ID_ST);
    actionServiceTechnique.setTypePfs(TypePFS.VMS_STW.toString());
    actionServiceTechnique.setDonneesProvisionneesStPfsVmsStw(donneesProvisionneesSTPfsVmsStw);

    List<ActionServiceTechnique> astList = Arrays.asList(actionServiceTechnique);

    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);
    actionCorrective.setActionsServicesTechniques(astList);
    Retour retourBL5100 = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, "erreur technique"); //$NON-NLS-1$
    String idActionCorrective = "idActionCorrective"; //$NON-NLS-1$
    createBL5100Mock(_tracabilite, retourBL5100, _tracabilite.getIdCorrelationByTel() + NO_TELEPHONE, actionCorrective, idActionCorrective);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    referentielExpected.setEtatProvisioning(EtatProvisionning.EN_COURS.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatRessource(ossfaiSI026Return.getStatut());
    ressource.setEtatAllocation(EtatAllocation.EN_COURS.toString());
    referentielExpected.setRessources(Arrays.asList(ressource));

    PE0298_PFS pfsExpected = new PE0298_PFS();
    pfsExpected.setNoTelephone(NO_TELEPHONE);
    pfsExpected.setTypePfs(TypePFS.VMS_STW.toString());
    pfsExpected.setTypeMessagerie(reponseFonctionnelle.getItems().get(0).getTypeMessagerie());
    pfsExpected.setStatutMessagerie(reponseFonctionnelle.getItems().get(0).getStatutMessagerie());

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertEquals(Arrays.asList(pfsExpected), pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} KO, stPfsVmsStw et stPfsVmsCvm trouvés - migration en
   * cours<BR>
   * <b>Entrées:</b> BL200 retourne NOK/CAT-2/MIGRATION_EN_COURS/Migration des donnees messagerie en cours<br/>
   * <b>Attendu: KO 503 {error="MIGRATION_EN_COURS",error_description="Migration des donnees messagerie en cours"}}
   * <br/>
   * </b> <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_018() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);
    DonneesIdentificationSTPfsVmsCvm donneesIdentificationSTPfsVmsCvm = new DonneesIdentificationSTPfsVmsCvm(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsCvm donneesProvisionneesSTPfsVmsCvm = new DonneesProvisionneesSTPfsVmsCvm(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsCvm = new StPfsVmsCvm(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsCvm, donneesProvisionneesSTPfsVmsCvm);
    listeServiceTechnique.add(serviceTechniquePfsVmsCvm);

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, null, null);

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());

    ReponseErreur reponseErreur = RavelJsonTools.getInstance().fromJson(response.getResult(), ReponseErreur.class);

    Assert.assertEquals(IMegSpiritConsts.MIGRATION_EN_COURS, reponseErreur.getError());
    Assert.assertEquals(Messages.getString("PE0298.MigrationEnCours"), reponseErreur.getErrorDescription()); //$NON-NLS-1$
    Assert.assertNull(pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel et PFS, avec audit. Incohérence
   * du typeMessagerie trouvé dans le ST PFS CVM et le PFS<BR>
   * <b>Entrées:</b> <br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li>erreur =
   * <ul>
   * <li/>diagnostic = NO_TELEPHONE_INCONNU
   * <li/>libelle = libellé de l'erreur du BL5270 (ici, donnée inconnue)
   * </ul>
   * </li>
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </ul>
   * </li>
   * <li>PFS :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typePfs = VMS_CVM
   * <li>audit =
   * <ul>
   * <li/>diagnostic = {@link Diagnostic#DESYNCHRO_PFS}
   * <li/>libelle = Le service messagerie ne devrait pas être provisionné sur la VMS
   * </ul>
   * </li>
   * <li>erreur =
   * <ul>
   * <li/>diagnostic = {@link TypeError#ECHEC_ACTION_CORRECTIVE}
   * <li/>libelle = libellé de l'erreur du BL5100 (ici, erreur technique)
   * </ul>
   * </li>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_019() throws Throwable
  {

    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    DonneesIdentificationSTPfsVmsCvm donneesIdentificationSTPfsVmsCvm = new DonneesIdentificationSTPfsVmsCvm(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsCvm donneesProvisionneesSTPfsVmsCvm = new DonneesProvisionneesSTPfsVmsCvm(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsCvm = new StPfsVmsCvm(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsCvm, donneesProvisionneesSTPfsVmsCvm);
    listeServiceTechnique.add(serviceTechniquePfsVmsCvm);
    ListeParametre listeParametresSI002 = new ListeParametre();
    listeParametresSI002.add(NO_TELEPHONE, NO_TELEPHONE);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, "REFERENTIEL,PFS", Boolean.TRUE); //$NON-NLS-1$

    ReponseFonctionnelle<MessageriePfs> reponseFonctionnelle = createReponseFonctionnelle();
    reponseFonctionnelle.getItems().get(0).setTypeMessagerie("FAX"); //$NON-NLS-1$
    reponseFonctionnelle.getItems().get(0).setTypePfs(TypePFS.VMS_CVM.toString());
    ResponseConnector responseConnector = createResponseConnector(reponseFonctionnelle);

    Retour retourOk = RetourFactory.createOkRetour();

    createAIRMock(_tracabilite, retourOk, NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, retourOk, pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, retourOk, listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);
    prepareProv_SI002(retourOk, _tracabilite, listeParametresSI002, responseConnector);

    ActionServiceTechniqueVmsCvm actionServiceTechnique = new ActionServiceTechniqueVmsCvm(TypeAction.MODIFICATION.name(), com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), null);
    actionServiceTechnique.setIdSt(ID_ST);
    actionServiceTechnique.setTypePfs(TypePFS.VMS_CVM.toString());
    actionServiceTechnique.setDonneesProvisionneesStPfsVmsCvm(donneesProvisionneesSTPfsVmsCvm);

    List<ActionServiceTechnique> astList = Arrays.asList(actionServiceTechnique);

    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);
    actionCorrective.setActionsServicesTechniques(astList);
    Retour retourBL5100 = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, "erreur technique"); //$NON-NLS-1$
    String idActionCorrective = "idActionCorrective"; //$NON-NLS-1$
    createBL5100Mock(_tracabilite, retourBL5100, _tracabilite.getIdCorrelationByTel() + NO_TELEPHONE, actionCorrective, idActionCorrective);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(ossfaiSI026Return.getStatut());
    referentielExpected.setRessources(Arrays.asList(ressource));
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsCvm.getTypeUsage());
    referentielExpected.setEtatProvisioning(EtatProvisionning.REALISE.toString());

    PE0298_PFS pfsExpected = new PE0298_PFS();
    pfsExpected.setNoTelephone(NO_TELEPHONE);
    pfsExpected.setTypePfs(TypePFS.VMS_CVM.toString());
    pfsExpected.setTypeMessagerie(reponseFonctionnelle.getItems().get(0).getTypeMessagerie());
    pfsExpected.setStatutMessagerie(reponseFonctionnelle.getItems().get(0).getStatutMessagerie());
    pfsExpected.setAudits(Arrays.asList(new PE0298_Audit(Diagnostic.DESYNCHRO_PFS.toString(), Messages.getString("PE0298.BL400.LibelleDesynchroPfs"))));
    pfsExpected.getAudits().get(0).addParameter(TYPE_MESSAGERIE);

    pfsExpected.setErreurs(Arrays.asList(new PE0298_Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), MessageFormat.format(ERROR_CREATION_ACTION_CORRECTIVE, retourBL5100.getDiagnostic()))));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertEquals(Arrays.asList(pfsExpected), pe0298_Reponse.getPfs());
    Assert.assertEquals(idActionCorrective, pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> {@link PE0298_EffectuerDiagMessagerieVMS} avec vue Referentiel et PFS avec audit avec un
   * service technique LAC actif et un service technique PFS STW actif avec appel PROV_SI0002 KO<BR>
   * <b>Entrées:</b> PROV_SI002 KO CAT-4 DONNEE_INCONNUE<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </ul>
   * </li>
   * <li>PFS :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typePfs = VMS_STW
   * <li>audit =
   * <ul>
   * <li/>diagnostic = {@link Diagnostic#DESYNCHRO_PFS}
   * <li/>libelle = Le service messagerie ne devrait pas être provisionné sur la VMS
   * </ul>
   * </li>
   * <li>erreur =
   * <ul>
   * <li/>diagnostic = {@link TypeError#ECHEC_ACTION_CORRECTIVE}
   * <li/>libelle = libellé de l'erreur du BL5100 (ici, erreur technique)
   * </ul>
   * </li>
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_020() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);
    ListeParametre listeParametresSI002 = new ListeParametre();
    listeParametresSI002.add(NO_TELEPHONE, NO_TELEPHONE);

    ActionServiceTechniqueVmsStw actionServiceTechnique = new ActionServiceTechniqueVmsStw(TypeAction.MODIFICATION.name(), com.bytel.spirit.common.shared.saab.rst.Statut.INACTIF.toString(), null);
    actionServiceTechnique.setIdSt(ID_ST);

    List<ActionServiceTechnique> astList = Arrays.asList(actionServiceTechnique);
    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);
    actionCorrective.setActionsServicesTechniques(astList);
    Retour retourBL5100 = RetourFactory.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, "erreur technique"); //$NON-NLS-1$
    String idActionCorrective = "idActionCorrective"; //$NON-NLS-1$
    createBL5100Mock(_tracabilite, retourBL5100, _tracabilite.getIdCorrelationByTel() + NO_TELEPHONE, actionCorrective, idActionCorrective);

    Retour retourProvSI002 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "donnée inconnue"); //$NON-NLS-1$

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, "REFERENTIEL,PFS", Boolean.TRUE); //$NON-NLS-1$

    createAIRMock(_tracabilite, RetourFactory.createOkRetour(), NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, RetourFactory.createOkRetour(), pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, RetourFactory.createOkRetour(), listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION));
    prepareProv_SI002(retourProvSI002, _tracabilite, listeParametresSI002, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(PE0298_Ressource.EtatRessource.ALLOUE.toString());
    referentielExpected.setRessources(Arrays.asList(ressource));
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsStw.getTypeUsage());
    referentielExpected.setEtatProvisioning(EtatProvisionning.REALISE.toString());

    PE0298_PFS pfsExpected = new PE0298_PFS();
    pfsExpected.setNoTelephone(NO_TELEPHONE);
    pfsExpected.addAudit(new PE0298_Audit(IMegSpiritConsts.SERVICE_NON_PROVISIONNE, Messages.getString("PE0298.BL301.ServiceNonProvisionne")));
    pfsExpected.addErreur(new PE0298_Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), MessageFormat.format(ERROR_CREATION_ACTION_CORRECTIVE, retourBL5100.getDiagnostic())));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertEquals(Arrays.asList(pfsExpected), pe0298_Reponse.getPfs());
    Assert.assertEquals(idActionCorrective, pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> Cas de test nominal du {@link PE0298_EffectuerDiagMessagerieVMS} avec vue REFERENTIEL ET PFS,
   * sans audit<BR>
   * <b>Entrées:</b> Toutes les entrées sont valides : audit = false<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </ul>
   * </li>
   * <li>PFS :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typePfs = VMS_STW
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_Nominal_001() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);
    ListeParametre listeParametresSI002 = new ListeParametre();
    listeParametresSI002.add(NO_TELEPHONE, NO_TELEPHONE);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, "REFERENTIEL,PFS", null); //$NON-NLS-1$

    ReponseFonctionnelle<MessageriePfs> reponseFonctionnelle = createReponseFonctionnelle();
    reponseFonctionnelle.getItems().get(0).setTypePfs(TypePFS.VMS_STW.toString());
    ResponseConnector responseConnector = createResponseConnector(reponseFonctionnelle);

    Retour retourOk = RetourFactory.createOkRetour();
    createAIRMock(_tracabilite, retourOk, NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, retourOk, pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, retourOk, listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);
    prepareProv_SI002(retourOk, _tracabilite, listeParametresSI002, responseConnector);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(ossfaiSI026Return.getStatut());
    referentielExpected.setRessources(Arrays.asList(ressource));
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsStw.getTypeUsage());
    referentielExpected.setEtatProvisioning(EtatProvisionning.REALISE.toString());

    PE0298_PFS pfsExpected = new PE0298_PFS();
    pfsExpected.setNoTelephone(NO_TELEPHONE);
    pfsExpected.setTypePfs(TypePFS.VMS_STW.toString());
    pfsExpected.setTypeMessagerie(reponseFonctionnelle.getItems().get(0).getTypeMessagerie());
    pfsExpected.setStatutMessagerie(reponseFonctionnelle.getItems().get(0).getStatutMessagerie());

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertEquals(Arrays.asList(pfsExpected), pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> Cas de test nominal du {@link PE0298_EffectuerDiagMessagerieVMS} avec vue REFERENTIEL ET PFS,
   * avec audit<BR>
   * <b>Entrées:</b> Toutes les entrées sont valides : audit = true<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </ul>
   * </li>
   * <li>PFS :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typePfs = VMS_STW
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_Nominal_002() throws Throwable
  {

    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    DonneesIdentificationSTPfsVmsStw donneesIdentificationSTPfsVmsSt = new DonneesIdentificationSTPfsVmsStw(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsStw donneesProvisionneesSTPfsVmsStw = new DonneesProvisionneesSTPfsVmsStw(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsStw = new StPfsVmsStw(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsSt, donneesProvisionneesSTPfsVmsStw);
    listeServiceTechnique.add(serviceTechniquePfsVmsStw);
    ListeParametre listeParametresSI002 = new ListeParametre();
    listeParametresSI002.add(NO_TELEPHONE, NO_TELEPHONE);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, "REFERENTIEL,PFS", Boolean.TRUE); //$NON-NLS-1$

    ReponseFonctionnelle<MessageriePfs> reponseFonctionnelle = new ReponseFonctionnelle<>();
    List<MessageriePfs> listeMessageriePfs = new ArrayList<>();
    MessageriePfs messageriePfs = __podam.manufacturePojo(MessageriePfs.class);
    messageriePfs.setTypeMessagerie(TYPE_MESSAGERIE);
    messageriePfs.setTypePfs(TypePFS.VMS_STW.toString());
    listeMessageriePfs.add(messageriePfs);

    reponseFonctionnelle.setResultsCount(1);
    reponseFonctionnelle.setItems(listeMessageriePfs);

    ResponseConnector responseConnector = createResponseConnector(reponseFonctionnelle);

    Retour retourOk = RetourFactory.createOkRetour();

    createAIRMock(_tracabilite, retourOk, NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, retourOk, pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, retourOk, listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);
    prepareProv_SI002(retourOk, _tracabilite, listeParametresSI002, responseConnector);

    ActionServiceTechniqueVmsStw actionServiceTechnique = new ActionServiceTechniqueVmsStw(TypeAction.MODIFICATION.name(), com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), null);
    actionServiceTechnique.setIdSt(ID_ST);
    actionServiceTechnique.setTypePfs(TypePFS.VMS_STW.toString());
    actionServiceTechnique.setDonneesProvisionneesStPfsVmsStw(donneesProvisionneesSTPfsVmsStw);

    List<ActionServiceTechnique> astList = Arrays.asList(actionServiceTechnique);

    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);
    actionCorrective.setActionsServicesTechniques(astList);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(ossfaiSI026Return.getStatut());
    referentielExpected.setRessources(Arrays.asList(ressource));
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsStw.getTypeUsage());
    referentielExpected.setEtatProvisioning(EtatProvisionning.REALISE.toString());

    PE0298_PFS pfsExpected = new PE0298_PFS();
    pfsExpected.setNoTelephone(NO_TELEPHONE);
    pfsExpected.setTypePfs(TypePFS.VMS_STW.toString());
    pfsExpected.setTypeMessagerie(reponseFonctionnelle.getItems().get(0).getTypeMessagerie());
    pfsExpected.setStatutMessagerie(reponseFonctionnelle.getItems().get(0).getStatutMessagerie());

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertEquals(Arrays.asList(pfsExpected), pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> Cas de test nominal du {@link PE0298_EffectuerDiagMessagerieVMS} avec vue REFERENTIEL ET PFS,
   * sans audit<BR>
   * <b>Entrées:</b> Toutes les entrées sont valides : audit = false<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </ul>
   * </li>
   * <li>PFS :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typePfs = VMS_CVM
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_Nominal_003() throws Throwable
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    DonneesIdentificationSTPfsVmsCvm donneesIdentificationSTPfsVmsCvm = new DonneesIdentificationSTPfsVmsCvm(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsCvm donneesProvisionneesSTPfsVmsCvm = new DonneesProvisionneesSTPfsVmsCvm(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsCvm = new StPfsVmsCvm(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsCvm, donneesProvisionneesSTPfsVmsCvm);
    listeServiceTechnique.add(serviceTechniquePfsVmsCvm);
    ListeParametre listeParametresSI002 = new ListeParametre();
    listeParametresSI002.add(NO_TELEPHONE, NO_TELEPHONE);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, "REFERENTIEL,PFS", null); //$NON-NLS-1$

    ReponseFonctionnelle<MessageriePfs> reponseFonctionnelle = createReponseFonctionnelle();
    reponseFonctionnelle.getItems().get(0).setTypePfs(TypePFS.VMS_CVM.toString());
    ResponseConnector responseConnector = createResponseConnector(reponseFonctionnelle);

    Retour retourOk = RetourFactory.createOkRetour();
    createAIRMock(_tracabilite, retourOk, NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, retourOk, pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, retourOk, listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);
    prepareProv_SI002(retourOk, _tracabilite, listeParametresSI002, responseConnector);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(ossfaiSI026Return.getStatut());
    referentielExpected.setRessources(Arrays.asList(ressource));
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsCvm.getTypeUsage());
    referentielExpected.setEtatProvisioning(EtatProvisionning.REALISE.toString());

    PE0298_PFS pfsExpected = new PE0298_PFS();
    pfsExpected.setNoTelephone(NO_TELEPHONE);
    pfsExpected.setTypePfs(TypePFS.VMS_CVM.toString());
    pfsExpected.setTypeMessagerie(reponseFonctionnelle.getItems().get(0).getTypeMessagerie());
    pfsExpected.setStatutMessagerie(reponseFonctionnelle.getItems().get(0).getStatutMessagerie());

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertEquals(Arrays.asList(pfsExpected), pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * <b>Cas de test:</b> Cas de test nominal du {@link PE0298_EffectuerDiagMessagerieVMS} avec vue REFERENTIEL ET PFS,
   * avec audit<BR>
   * <b>Entrées:</b> Toutes les entrées sont valides : audit = true<br/>
   * <b>Attendu:</b>
   * <ul>
   * <li>Resultat: OK</li>
   * <li>Referentiel :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typeService = {@link TypeService#MESSAGERIE}
   * <li/>etatProvisionning = {@link EtatProvisioning#REALISE}}
   * <li/>typeMessagerie = "typeMessagerie"
   * <li/>ressource =
   * <ul>
   * <li/>typeRessource = NO_TELEPHONE
   * <li/>etatAllocation = {@link EtatAllocation#REALISE}
   * </ul>
   * </ul>
   * </li>
   * <li>PFS :
   * <ul>
   * <li/>noTelephone = "noTelephone"
   * <li/>typePfs = VMS_CVM
   * </ul>
   * </li>
   * </ul>
   * <br/>
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void testPE0298_EffectuerDiagMessagerieVMS_Nominal_004() throws Throwable
  {

    List<IndexRecherchePfi> listeIndexRecherchePfi = createListeIndexRecherchePfi(CLIENT_OPERATEUR, NO_COMPTE);
    PFI pfi = createPfi(NO_TELEPHONE);

    List<ServiceTechnique> listeServiceTechnique = createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF, NO_TELEPHONE, CLIENT_OPERATEUR, NO_COMPTE, ID_ST);

    DonneesIdentificationSTPfsVmsCvm donneesIdentificationSTPfsVmsCvm = new DonneesIdentificationSTPfsVmsCvm(IDENTIFIANT_FONCTIONNEL_PA);
    DonneesProvisionneesSTPfsVmsCvm donneesProvisionneesSTPfsVmsCvm = new DonneesProvisionneesSTPfsVmsCvm(NO_TELEPHONE, TYPE_MESSAGERIE, LIGNE_MARCHE, ADRESSE_MAIL, NOM_PRENOM_UTILISATEUR);
    ServiceTechnique serviceTechniquePfsVmsCvm = new StPfsVmsCvm(ID_ST, com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), CLIENT_OPERATEUR, NO_COMPTE, donneesIdentificationSTPfsVmsCvm, donneesProvisionneesSTPfsVmsCvm);
    listeServiceTechnique.add(serviceTechniquePfsVmsCvm);
    ListeParametre listeParametresSI002 = new ListeParametre();
    listeParametresSI002.add(NO_TELEPHONE, NO_TELEPHONE);

    final Request request = prepareRequest(_tracabilite, HttpMethod.GET, NO_TELEPHONE, "REFERENTIEL,PFS", Boolean.TRUE); //$NON-NLS-1$

    ReponseFonctionnelle<MessageriePfs> reponseFonctionnelle = new ReponseFonctionnelle<>();
    List<MessageriePfs> listeMessageriePfs = new ArrayList<>();
    MessageriePfs messageriePfs = __podam.manufacturePojo(MessageriePfs.class);
    messageriePfs.setTypeMessagerie(TYPE_MESSAGERIE);
    messageriePfs.setTypePfs(TypePFS.VMS_CVM.toString());
    listeMessageriePfs.add(messageriePfs);

    reponseFonctionnelle.setResultsCount(1);
    reponseFonctionnelle.setItems(listeMessageriePfs);

    ResponseConnector responseConnector = createResponseConnector(reponseFonctionnelle);

    Retour retourOk = RetourFactory.createOkRetour();

    createAIRMock(_tracabilite, retourOk, NO_TELEPHONE, listeIndexRecherchePfi);
    createMockRPGpfiLireUn(_tracabilite, retourOk, pfi, listeIndexRecherchePfi.get(0).getClientOperateur(), listeIndexRecherchePfi.get(0).getNoCompte());
    createMockRSTserviceTechniqueLireTousParPfi(_tracabilite, retourOk, listeServiceTechnique, CLIENT_OPERATEUR, NO_COMPTE);
    OSSFAI_SI026_Return ossfaiSI026Return = new OSSFAI_SI026_Return(PE0298_Ressource.EtatRessource.ALLOUE.toString(), ID_ST_LIEN_ALLOCATION);
    prepareOssFai_SI026(RetourFactoryForTU.createOkRetour(), _tracabilite, NO_TELEPHONE, ossfaiSI026Return);
    prepareProv_SI002(retourOk, _tracabilite, listeParametresSI002, responseConnector);

    ActionServiceTechniqueVmsCvm actionServiceTechnique = new ActionServiceTechniqueVmsCvm(TypeAction.MODIFICATION.name(), com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString(), null);
    actionServiceTechnique.setIdSt(ID_ST);
    actionServiceTechnique.setTypePfs(TypePFS.VMS_CVM.toString());
    actionServiceTechnique.setDonneesProvisionneesStPfsVmsCvm(donneesProvisionneesSTPfsVmsCvm);

    List<ActionServiceTechnique> astList = Arrays.asList(actionServiceTechnique);

    ActionCorrective actionCorrective = new ActionCorrective(CLIENT_OPERATEUR, NO_COMPTE);
    actionCorrective.setActionsServicesTechniques(astList);

    PowerMock.replayAll();
    Response response = executeStartProcess(request, PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS);

    PE0298_Reponse pe0298_Reponse = RavelJsonTools.getInstance().fromJson(response.getResult(), PE0298_Reponse.class);

    PE0298_Referentiel referentielExpected = new PE0298_Referentiel();
    referentielExpected.setNoTelephone(NO_TELEPHONE);
    referentielExpected.setTypeService(TypeService.MESSAGERIE.toString());
    PE0298_Ressource ressource = new PE0298_Ressource();
    ressource.setTypeRessource(TypeRessource.NUMERO_TELEPHONE.toString());
    ressource.setEtatAllocation(EtatAllocation.REALISE.toString());
    ressource.setEtatRessource(ossfaiSI026Return.getStatut());
    referentielExpected.setRessources(Arrays.asList(ressource));
    referentielExpected.setTypeMessagerie(donneesProvisionneesSTPfsVmsCvm.getTypeUsage());
    referentielExpected.setEtatProvisioning(EtatProvisionning.REALISE.toString());

    PE0298_PFS pfsExpected = new PE0298_PFS();
    pfsExpected.setNoTelephone(NO_TELEPHONE);
    pfsExpected.setTypePfs(TypePFS.VMS_CVM.toString());
    pfsExpected.setTypeMessagerie(reponseFonctionnelle.getItems().get(0).getTypeMessagerie());
    pfsExpected.setStatutMessagerie(reponseFonctionnelle.getItems().get(0).getStatutMessagerie());

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertEquals(Arrays.asList(referentielExpected), pe0298_Reponse.getReferentiel());
    Assert.assertEquals(Arrays.asList(pfsExpected), pe0298_Reponse.getPfs());
    Assert.assertNull(pe0298_Reponse.getIdActionCorrective());
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("BSS_ENT"); //$NON-NLS-1$
    requestHeader_p.add(hdr);
  }

  /**
   * Creates mock for method pfiLireUnFiltrerOCResilie
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour_p
   *          the retour
   * @param indexRecherchePfiList
   *          the list of indexRecherchePfi
   * @param noTelephone_p
   *          the phone number
   * @throws Exception
   *           on errors
   */
  private void createAIRMock(Tracabilite tracabilite_p, Retour retour_p, String noTelephone_p, List<IndexRecherchePfi> indexRecherchePfiList) throws Exception
  {
    EasyMock.expect(AIRProxy.getInstance()).andReturn(_airProxyMock);
    EasyMock.expect(_airProxyMock.indexRechercherPfiLireTousParCleRecherche(tracabilite_p, "NUMERO_TELEPHONE", noTelephone_p)).andReturn(new ConnectorResponse<>(retour_p, indexRecherchePfiList)); //$NON-NLS-1$
  }

  /**
   * prepareProv_SI002
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour_p
   *          retour
   * @param idExterne_p
   *          the idExterne
   * @param actionCorrective_p
   *          the actionCorrective
   * @param idActionCorrective_p
   *          hte idActionCorrective
   * @throws Exception
   *           excetpion
   */
  private void createBL5100Mock(Tracabilite tracabilite_p, Retour retour_p, String idExterne_p, ActionCorrective actionCorrective_p, String idActionCorrective_p) throws Exception
  {
    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100MockBuilder);
    EasyMock.expect(_bl5100MockBuilder.idExterne(idExterne_p)).andReturn(_bl5100MockBuilder);
    EasyMock.expect(_bl5100MockBuilder.actionCorrective(actionCorrective_p)).andReturn(_bl5100MockBuilder);
    EasyMock.expect(_bl5100MockBuilder.tracabilite(tracabilite_p)).andReturn(_bl5100MockBuilder);
    EasyMock.expect(_bl5100MockBuilder.build()).andReturn(_bl5100Mock);
    EasyMock.expect(_bl5100Mock.execute(_processInstance)).andReturn(idActionCorrective_p);
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * @param clientOperateur
   *          the clientOperateur
   * @param noCompte
   *          the noCompte
   * @return the list of IndexRecherchePfi created
   */
  private List<IndexRecherchePfi> createListeIndexRecherchePfi(String clientOperateur, String noCompte)
  {
    List<IndexRecherchePfi> listeIndexRecherchePfi = new ArrayList<>();
    IndexRecherchePfi indexRecherchePfi = __podam.manufacturePojo(IndexRecherchePfi.class);
    indexRecherchePfi.setClientOperateur(clientOperateur);
    indexRecherchePfi.setNoCompte(noCompte);
    listeIndexRecherchePfi.add(indexRecherchePfi);
    return listeIndexRecherchePfi;
  }

  /**
   * @param statut_p
   *          the statut
   * @param noTelephone
   *          the noTelephone
   * @param clientOperateur
   *          the clientOperateur
   * @param noCompte
   *          the noCompte
   * @param idSt
   *          the idSt
   * @return the list of ServiceTechnique created
   */
  private List<ServiceTechnique> createListeServiceTechniqueLAC(com.bytel.spirit.common.shared.saab.rst.Statut statut_p, String noTelephone, String clientOperateur, String noCompte, String idSt)
  {
    List<ServiceTechnique> listeServiceTechnique = new ArrayList<>();
    ServiceTechnique serviceTechniqueLAC = new StLienAllocationCommercial(idSt, statut_p.toString(), clientOperateur, noCompte, null, null, null, noTelephone, TYPE_RESSOURCE_NUMERO_TELEPHONE);
    listeServiceTechnique.add(serviceTechniqueLAC);

    return listeServiceTechnique;
  }

  /**
   * Creates mock for class in {@link RPGProxy}
   *
   * @param tracabilite_p
   *          the tracabilite
   *
   * @param retour_p
   *          the retour
   * @param pfi_p
   *          the pfi
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @throws RavelException
   *           on errors
   */
  private void createMockRPGpfiLireUn(Tracabilite tracabilite_p, Retour retour_p, PFI pfi_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    ConnectorResponse<Retour, PFI> expectedResponse = new ConnectorResponse<>(retour_p, pfi_p);
    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock);
    EasyMock.expect(_rpgMock.pfiLireUn(tracabilite_p, clientOperateur_p, noCompte_p)).andReturn(expectedResponse);
  }

  /**
   * Creates mock for class in {@link RPGProxy}
   *
   * @param tracabilite_p
   *          the tracabilite
   * @param retour_p
   *          the retour
   * @param listeServiceTechnique_p
   *          the pfi
   * @param clientOperateur_p
   *          the clientOperateur
   * @param noCompte_p
   *          the noCompte
   * @throws RavelException
   *           on errors
   */
  private void createMockRSTserviceTechniqueLireTousParPfi(Tracabilite tracabilite_p, Retour retour_p, List<ServiceTechnique> listeServiceTechnique_p, String clientOperateur_p, String noCompte_p) throws RavelException
  {
    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retour_p, listeServiceTechnique_p);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstMock);
    EasyMock.expect(_rstMock.serviceTechniqueLireTousParPfi(tracabilite_p, clientOperateur_p, noCompte_p, null, null)).andReturn(expectedResponse);
  }

  /**
   * @param noTelephone
   *          the noTelephone
   * @return the pf created
   */
  private PFI createPfi(String noTelephone)
  {
    PFI pfi = __podam.manufacturePojo(PFI.class);
    pfi.getPa().get(0).setStatut(Statut.ACTIF);
    pfi.getPa().get(0).setTypePA("VOIP"); //$NON-NLS-1$
    PaTypeVoip paTypeVoip = new PaTypeVoip(noTelephone, pfi.getPa().get(0).getPaTypeVoip().getCodeRio(), pfi.getPa().get(2).getPaTypeVoip().getNumeroPortTelephonique());
    pfi.getPa().get(0).setPaTypeVoip(paTypeVoip);
    return pfi;
  }

  /**
   * Create a {@codeReponseFonctionnellePI0212D}
   *
   * @return the ReponseFonctionnellePI0212D created
   */
  private ReponseFonctionnelle<MessageriePfs> createReponseFonctionnelle()
  {
    ReponseFonctionnelle reponseFonctionnelle = new ReponseFonctionnelle();
    List<MessageriePfs> listeMessageriePfs = new ArrayList<>();
    MessageriePfs messageriePfs = __podam.manufacturePojo(MessageriePfs.class);

    listeMessageriePfs.add(messageriePfs);

    reponseFonctionnelle.setResultsCount(1);
    reponseFonctionnelle.setItems(listeMessageriePfs);

    return reponseFonctionnelle;
  }

  /**
   * Create Response connector
   *
   * @param reponseFonctionnellePI0212D_p
   *          the reponseFonctionnellePI0212D
   *
   * @return ResponseConnector
   */
  private ResponseConnector createResponseConnector(ReponseFonctionnelle<MessageriePfs> reponseFonctionnellePI0212D_p) throws RavelException
  {
    com.bytel.spirit.common.connectors.ink.generated.Response response = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector reponseConnector = __podam.manufacturePojo(ResponseConnector.class);
    String result = RavelJsonTools.getInstance().toJson(reponseFonctionnellePI0212D_p, new ReponseFonctionnelleParameterizedType<>(MessageriePfs.class));

    Dataset dataset = new Dataset();
    List<DatasetParam> listdata = new ArrayList<>();
    DatasetParam datasetparam = new DatasetParam();
    datasetparam.setIndex(1);
    datasetparam.setName("reponseFonctionnelle"); //$NON-NLS-1$
    datasetparam.setValue(result);
    listdata.add(datasetparam);
    dataset.getParams().add(datasetparam);
    ServiceOrderDataResponse serviceData = new ServiceOrderDataResponse();
    serviceData.setDataset(dataset);
    ServiceOrderResponse so = new ServiceOrderResponse();
    so.setSod(serviceData);
    response.setSo(so);
    reponseConnector.setResponse(response);
    return reponseConnector;
  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           on errors The throwable.
   */
  private Response executeStartProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _processInstance.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * prepareProv_SI002
   *
   * @param retour_p
   *          retour
   * @param tracabilite_p
   *          the tracabilite
   * @param ossfai_SI026_Return_p
   * @param noms_p
   *          the list of noms
   * @param valeurs_p
   *          the list of valeurs
   * @param ossfai_SI026_Return_p
   *          reponseconnector
   * @throws Exception
   *           excetpion
   */
  private void prepareOssFai_SI026(Retour retour_p, Tracabilite tracabilite_p, String noTelephone_p, OSSFAI_SI026_Return ossfai_SI026_Return_p) throws Exception
  {
    PowerMock.expectNew(OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class).andReturn(_ossFaiSI026_mockbuilder);
    EasyMock.expect(_ossFaiSI026_mockbuilder.tracabilite(tracabilite_p)).andReturn(_ossFaiSI026_mockbuilder);
    EasyMock.expect(_ossFaiSI026_mockbuilder.noTelephone(noTelephone_p)).andReturn(_ossFaiSI026_mockbuilder);
    EasyMock.expect(_ossFaiSI026_mockbuilder.build()).andReturn(_ossFaiSI026);
    EasyMock.expect(_ossFaiSI026.execute(_processInstance)).andReturn(ossfai_SI026_Return_p);
    EasyMock.expect(_ossFaiSI026.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * prepareProv_SI002
   *
   * @param retour_p
   *          retour
   * @param tracabilite_p
   *          the tracabilite
   * @param listeParametres_p
   *          the ListeParametre with noms and values
   * @param reponseConnector_p
   *          reponseconnector
   * @throws Exception
   *           excetpion
   */
  private void prepareProv_SI002(Retour retour_p, Tracabilite tracabilite_p, ListeParametre listeParametres_p, ResponseConnector reponseConnector_p) throws Exception
  {
    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.tracabilite(tracabilite_p)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.processus(CONSULTER_MESSAGERIE_VMS_PFS)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.priorite(10)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.listeParametres(listeParametres_p)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.build()).andReturn(_provSI002Mock);
    EasyMock.expect(_provSI002Mock.execute(_processInstance)).andReturn(reponseConnector_p);
    EasyMock.expect(_provSI002Mock.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * Create a Generic Request to call PE0221_JournalAppels
   *
   * @param tracabilite_p
   *          tracabilite
   * @param noTelephone_p
   *          The noTelephone to add to the urlParameters
   * @param methode_p
   *          The method The noJours to add to the urlParameters
   * @param sourceDonnee_p
   *          the sourceDonnee
   * @param audit_p
   *          the audit
   * @return GenericRequest to call PE0298_EffectuerDiagMessagerieVMS
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String methode_p, String noTelephone_p, String sourceDonnee_p, Boolean audit_p) throws RavelException
  {
    Request request = new Request(PE0298_EFFECTUER_DIAG_MESSAGERIE_VMS, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParams = urlParametersType.getUrlParameters();
    addXHeaders(request.getRequestHeader(), tracabilite_p);

    if (noTelephone_p != null)
    {
      urlParams.add(createParameter(NO_TELEPHONE, noTelephone_p));
    }
    if (sourceDonnee_p != null)
    {
      urlParams.add(createParameter("sourceDonnee", sourceDonnee_p)); //$NON-NLS-1$
    }
    if (audit_p != null)
    {
      urlParams.add(createParameter("audit", audit_p.toString())); //$NON-NLS-1$
    }

    urlParametersType.setUrlParameters(urlParams);

    request.setUrlParameters(urlParametersType);

    return request;
  }

}
