/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0296;

import static org.junit.Assert.assertEquals;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.json.IRavelJson;
import com.bytel.ravel.common.json.IRavelJsonAdapter;
import com.bytel.ravel.common.json.RavelJson.RavelJsonBuilder;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.connectors.res.RESProxy;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.DonneesIdentificationSTPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.DonneesProvisionneesSTPfsOlt;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.olt.StPfsOlt;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.res.Ressource;
import com.bytel.spirit.common.shared.saab.res.RessourceAggrege;
import com.bytel.spirit.common.shared.saab.res.RessourceAggregeP2P;
import com.bytel.spirit.common.shared.saab.res.RessourceRaccordement;
import com.bytel.spirit.common.shared.saab.rpg.AccessTechniqueCommercial;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeLigneFixe;
import com.bytel.spirit.common.shared.saab.rpg.RaccordementCommercial;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_Ressource.EtatRessource;
import com.bytel.spirit.fiat.processes.PE0296.structs.PE0296_Retour;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jramos
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ RPGProxy.class, RESProxy.class, RSTProxy.class })
public class PE0296_Diagnostic_RaccordementTest
{

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * SPRING context
   */
  @SuppressWarnings("unused")
  private static ClassPathXmlApplicationContext __context;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void beforeClassSetup() throws RavelException
  {
    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Run before tests
   *
   * @throws Exception
   *           throw exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * RPG Proxy
   */
  @MockStrict
  private RPGProxy _rpgProxy;

  /**
   * RST Proxy
   */
  @MockStrict
  private RSTProxy _rstProxy;

  /**
   * RES Proxy
   */
  @MockStrict
  private RESProxy _resProxy;

  /**
   * Instance of {@link PE0296_DiagnosticRaccordement}
   */
  private PE0296_DiagnosticRaccordement _processInstance;

  /**
   * Test Case CALLS BL100 -- RPGProxy.pfiLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT is EMPTY <br>
   * CALLS BL100 -- RPGProxy.pfiLireUn and returns NOK CAT4 NO_COMPTE_INCONNU<br>
   *
   * Result PE0296_Retour -- ListReferenciel Empty -- Erreur -- NO_COMPTE_INCONNU <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_001() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_COMPTE_INCONNU, MessageFormat.format(Messages.getString("PE0296.BL100.noCompteIconnu"), "noCompte", "clientOperateur")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, null);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());
    assertEquals(IMegSpiritConsts.NO_COMPTE_INCONNU, retourPE0296.getError());

  }

  /**
   * Test Case CALLS BL100 -- RPGProxy.pfiLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALLS BL100 -- RPGProxy.pfiLireUn and returns NOK CAT4 DONNEE_INCONNUE<br>
   *
   * Result PE0296_Retour -- ListReferenciel Empty -- Erreur -- NO_COMPTE_INCONNU <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_002() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour1 = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, MessageFormat.format(Messages.getString("PE0296.BL100.noCompteIconnu"), "noCompte", "clientOperateur")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour1, null);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());
    assertEquals(IMegSpiritConsts.NO_COMPTE_INCONNU, retourPE0296.getError());

  }

  /**
   * Test Case CALLS BL100 -- RPGProxy.pfiLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALLS BL100 -- RPGProxy.pfiLireUn and returns OK and PFI null<br>
   *
   * Result PE0296_Retour -- ListReferenciel Empty -- Erreur -- ID_PA_INCONNU <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_003() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, null);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());
    assertEquals(IMegSpiritConsts.ID_PA_INCONNU, retourPE0296.getError());

  }

  /**
   * Test Case CALLS BL100 -- RPGProxy.pfiLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALLS BL100 -- RPGProxy.pfiLireUn and returns OK and PFI not null<br>
   * Filters PFI AND Returns a empty list because IdRaccordement is empty <br>
   *
   * Result PE0296_Retour -- ListReferenciel Empty -- Erreur -- ID_PA_INCONNU <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_004() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("ID", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());
    assertEquals(IMegSpiritConsts.ID_PA_INCONNU, retourPE0296.getError());

  }

  /**
   * Test Case CALLS BL100 -- RPGProxy.pfiLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT are EMPTY <br>
   * CALLS BL100 -- RPGProxy.pfiLireUn and returns OK and PFI not null<br>
   * Filters PFI AND Returns a list because IdRaccordement is not empty <br>
   * Filters PFI AND Returns a empty list because IDENTIFIANT_FONCTIONNEL_PA is diferent <br>
   *
   * Result PE0296_Retour -- ListReferenciel Empty -- Erreur -- ID_PA_INCONNU <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_005() throws Throwable
  {

    Request request = setRequest();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("ID", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());
    assertEquals(IMegSpiritConsts.ID_PA_INCONNU, retourPE0296.getError());

  }

  /**
   * Test Case CALLS BL200 -- RESProxy.ressourceLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALLS BL100 -- RPGProxy.pfiLireUn and returns OK and PFI not null<br>
   * Filters PFI AND Returns a list because IdRaccordement is not empty <br>
   * Filters PFI AND Returns a empty list because IDENTIFIANT_FONCTIONNEL_PA is diferent <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS NOK CAT4 RACCO_INCONNU<br>
   *
   * Result PE0296_Retour -- ListReferenciel Empty -- Erreur -- RACCO_INCONNU <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_006() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.RACCO_INCONNU, ""); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, null);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());
    assertEquals(IMegSpiritConsts.RACCO_INCONNU, retourPE0296.getError());

  }

  /**
   * Test Case CALLS BL200 -- RESProxy.ressourceLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT AND ID_FONCTIONNEL_PA are EMPTY <br>
   * CALLS BL100 -- RPGProxy.pfiLireUn and returns OK and PFI not null<br>
   * Filters PFI AND Returns a list because IdRaccordement is not empty <br>
   * Filters PFI AND Returns a empty list because IDENTIFIANT_FONCTIONNEL_PA is diferent <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS NOK CAT4 RACCO_INCONNU<br>
   *
   * Result PE0296_Retour -- ListReferenciel Empty -- Erreur -- RACCO_INCONNU <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_006a() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.RACCO_INCONNU, ""); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, null);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());
    assertEquals(IMegSpiritConsts.RACCO_INCONNU, retourPE0296.getError());

  }

  /**
   * Test Case CALLS BL200 -- RESProxy.ressourceLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT is NOT EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   *
   * Result PE0296_Retour -- ListReferenciel Empty -- Erreur -- RACCO_INCONNU <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_007() throws Throwable
  {

    Request request = setRequest1();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    Ressource ressource = new Ressource("idRessource", "typeRessource", "statut"); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());
    assertEquals(IMegSpiritConsts.RACCO_INCONNU, retourPE0296.getError());

  }

  /**
   * Test Case CALLS BL200 -- RESProxy.ressourceLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALLS BL100 -- RPGProxy.pfiLireUn and returns OK and PFI not null<br>
   * Filters PFI AND Returns a list because IdRaccordement is not empty <br>
   * Filters PFI AND Returns a empty list because IDENTIFIANT_FONCTIONNEL_PA is diferent <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   *
   * Result PE0296_Retour -- ListReferenciel NOT EMPTY OK_0200 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_008() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement(""); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    Ressource ressource = new Ressource("idRessource", "typeRessource", "ALLOUE1"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(""), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(1, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT is NOT EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn AND RETURNS OK <br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireTousParPfi AND RETURNS NOK CAT4 RACCO_INCONNU<br>
   * Result PE0296_Retour -- ListReferenciel EMPTY K0_0503 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_009() throws Throwable
  {

    Request request = setRequest1();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    Ressource ressource = new Ressource("idRessource", "typeRessource", EtatRessource.RESERVE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    List<ServiceTechnique> listST = new ArrayList<>();
    StLienAllocationCommercial stlac = new StLienAllocationCommercial("idSt", "statut", "clientOperateur", "noCompte", "typeObjetCommercial", "clientOperateur", "noCompte", "idRessource", "typeRessource"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$
    listST.add(stlac);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, listST);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(stLireUnRetour).once(); //$NON-NLS-1$

    retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.RACCO_INCONNU, ""); //$NON-NLS-1$
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireTousRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, new ArrayList<ServiceTechnique>());
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireTousRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT is NOT EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn AND RETURNS NOK CAT4 RACCO_INCONNU<br>
   *
   * Result PE0296_Retour -- ListReferenciel EMPTY K0_0503 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_010() throws Throwable
  {

    Request request = setRequest1();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    Ressource ressource = new Ressource("idRessource", "typeRessource", EtatRessource.RESERVE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.RACCO_INCONNU, ""); //$NON-NLS-1$
    List<ServiceTechnique> listST = new ArrayList<>();
    StLienAllocationCommercial stlac = new StLienAllocationCommercial("idSt", "statut", "clientOperateur", "noCompte", "typeObjetCommercial", "clientOperateur", "noCompte", "idRessource", "typeRessource"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$
    listST.add(stlac);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, listST);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(stLireUnRetour).once(); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireTousParPfi AND RETURNS NOK CAT4 RACCO_INCONNU<br>
   * Result PE0296_Retour -- ListReferenciel EMPTY K0_0503 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_011() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    Ressource ressource = new Ressource("idRessource", "typeRessource", EtatRessource.RESERVE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.RACCO_INCONNU, ""); //$NON-NLS-1$
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireTousRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, new ArrayList<ServiceTechnique>());
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireTousRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireTousParPfi AND RETURNS NOK CAT4 DONNEE_INCONNU AND LIST
   * EMPTY<br>
   * CALL BL200 -- RESProxy.pad3101RessourceAggregeP2PLireUn AND RETURNS NOK CAT4 ACCES_DONNEES_INDISPONIBLE
   *
   * Result PE0296_Retour -- ListReferenciel EMPTY K0_0503 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_012() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    Ressource ressource = new Ressource("idRessource", "P2P", EtatRessource.RESERVE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    RessourceRaccordement ressourceRaccordement = new RessourceRaccordement("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setRessourceRaccordement(ressourceRaccordement);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, ""); //$NON-NLS-1$
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, new ArrayList<ServiceTechnique>());
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireUnRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.ACCES_DONNEES_INDISPONIBLE, ""); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, RessourceAggrege> raP2PLireUnRetour = new ConnectorResponse<Retour, RessourceAggrege>(retour, null);
    EasyMock.expect(_resProxy.pad3101RessourceAggregeP2PLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("P2P"), EasyMock.eq("IdRaccordement"))).andReturn(raP2PLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireTousParPfi AND RETURNS OK AND LIST NOT EMPTY<br>
   * FILTERS LIST ST AND RETURNS +1 - <br>
   *
   * Result PE0296_Retour -- ListReferenciel NOT EMPTY OK_0200 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_013() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    Ressource ressource = new Ressource("idRessource", "P2P", EtatRessource.RESERVE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    List<ServiceTechnique> listST = new ArrayList<>();
    StLienAllocationCommercial stlac1 = new StLienAllocationCommercial("idSt", "statut", "clientOperateur", "noCompte", "typeObjetCommercial", "ocClientOperateur", "ocNoCompte", "IdRaccordement", "RACCO"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$//$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$
    StLienAllocationCommercial stlac2 = new StLienAllocationCommercial("idSt", "statut", "clientOperateur", "noCompte", "typeObjetCommercial", "ocClientOperateur", "ocNoCompte", "IdRaccordement", "RACCO"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$//$NON-NLS-4$//$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$//$NON-NLS-8$ //$NON-NLS-9$
    listST.add(stlac1);
    listST.add(stlac2);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, listST);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireUnRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(1, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireTousParPfi AND RETURNS OK AND LIST NOT EMPTY<br>
   * FILTERS LIST ST AND RETURNS 1 - <br>
   *
   * CALL BL200 -- RESProxy.pad3101RessourceAggregeP2PLireUn AND RETURNS OK AND RESSOURCEAGGREGE NOT NULL
   *
   * Result PE0296_Retour -- ListReferenciel NOT EMPTY OK_0200 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_014() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    Ressource ressource = new Ressource("idRessource", "P2P", EtatRessource.RESERVE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    RessourceRaccordement ressourceRaccordement = new RessourceRaccordement("P2P", "codeAccesTechnique"); //$NON-NLS-1$//$NON-NLS-2$
    ressource.setRessourceRaccordement(ressourceRaccordement);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    List<ServiceTechnique> listST = new ArrayList<>();
    StLienAllocationCommercial stlac1 = new StLienAllocationCommercial("idSt", "statut", "clientOperateur", "noCompte", "typeObjetCommercial", "ocClientOperateur", "ocNoCompte", "IdRaccordement", "RACCO"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$
    listST.add(stlac1);
    DonneesIdentificationSTPfsOlt donneesIdentificationStPfsOlt = new DonneesIdentificationSTPfsOlt("nomOLt", "1", "3", "4"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    StPfsOlt stPfsOlt = new StPfsOlt("idSt", "statut", "clientOperateur", "noCompte", donneesIdentificationStPfsOlt); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
    listST.add(stPfsOlt);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, listST);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireUnRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    RessourceAggregeP2P ressourceAggrege = new RessourceAggregeP2P("nomOLT", 1, 2, 3); //$NON-NLS-1$
    ressourceAggrege.setPositionRelativePortP2P(3);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, RessourceAggrege> raP2PLireUnRetour = new ConnectorResponse<Retour, RessourceAggrege>(retour, ressourceAggrege);
    EasyMock.expect(_resProxy.pad3101RessourceAggregeP2PLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("P2P"), EasyMock.eq("IdRaccordement"))).andReturn(raP2PLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(1, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireTousParPfi AND RETURNS OK AND LIST NOT EMPTY<br>
   * FILTERS LIST ST AND RETURNS 1 - <br>
   *
   * CALL BL200 -- RESProxy.pad3101RessourceAggregeP2PLireUn AND RETURNS OK AND RESSOURCEAGGREGE NOT NULL
   *
   * Result PE0296_Retour -- ListReferenciel NOT EMPTY OK_0200 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_015() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    Ressource ressource = new Ressource("idRessource", "P2P", EtatRessource.ALLOUE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    RessourceRaccordement ressourceRaccordement = new RessourceRaccordement("P2P", "codeAccesTechnique"); //$NON-NLS-1$//$NON-NLS-2$
    ressource.setRessourceRaccordement(ressourceRaccordement);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    List<ServiceTechnique> listST = new ArrayList<>();
    StLienAllocationCommercial stlac1 = new StLienAllocationCommercial("idSt", "ACTIF1", "clientOperateur", "noCompte", "typeObjetCommercial", "ocClientOperateur", "ocNoCompte", "IdRaccordement", "RACCO"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$
    listST.add(stlac1);
    DonneesIdentificationSTPfsOlt donneesIdentificationStPfsOlt = new DonneesIdentificationSTPfsOlt("nomOLt", "1", "3", "4"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    StPfsOlt stPfsOlt = new StPfsOlt("idSt", "statut", "clientOperateur", "noCompte", donneesIdentificationStPfsOlt); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
    listST.add(stPfsOlt);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, listST);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireUnRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    RessourceAggregeP2P ressourceAggrege = new RessourceAggregeP2P("nomOLT", 1, 2, 3); //$NON-NLS-1$
    ressourceAggrege.setPositionRelativePortP2P(3);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, RessourceAggrege> raP2PLireUnRetour = new ConnectorResponse<Retour, RessourceAggrege>(retour, ressourceAggrege);
    EasyMock.expect(_resProxy.pad3101RessourceAggregeP2PLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("P2P"), EasyMock.eq("IdRaccordement"))).andReturn(raP2PLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(1, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireTousParPfi AND RETURNS OK AND LIST NOT EMPTY<br>
   * FILTERS LIST ST AND RETURNS 1 - <br>
   *
   * CALL BL200 -- RESProxy.pad3101RessourceAggregeP2PLireUn AND RETURNS OK AND RESSOURCEAGGREGE NOT NULL
   *
   * Result PE0296_Retour -- ListReferenciel NOT EMPTY OK_0200 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_016() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    Ressource ressource = new Ressource("idRessource", "P2P", EtatRessource.ALLOUE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    RessourceRaccordement ressourceRaccordement = new RessourceRaccordement("P2P", "codeAccesTechnique"); //$NON-NLS-1$//$NON-NLS-2$
    ressource.setRessourceRaccordement(ressourceRaccordement);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    List<ServiceTechnique> listST = new ArrayList<>();
    StLienAllocationCommercial stlac1 = new StLienAllocationCommercial("idSt", Statut.ACTIF.toString(), "clientOperateur", "noCompte", "typeObjetCommercial", "ocClientOperateur", "ocNoCompte", "IdRaccordement", "RACCO"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$
    listST.add(stlac1);
    DonneesIdentificationSTPfsOlt donneesIdentificationStPfsOlt = new DonneesIdentificationSTPfsOlt("nomOLt", "1", "3", "4"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    StPfsOlt stPfsOlt = new StPfsOlt("idSt", "statut", "clientOperateur", "noCompte", donneesIdentificationStPfsOlt); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
    listST.add(stPfsOlt);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, listST);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireUnRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    RessourceAggregeP2P ressourceAggrege = new RessourceAggregeP2P("nomOLT", 1, 2, 3); //$NON-NLS-1$
    ressourceAggrege.setPositionRelativePortP2P(3);

    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, RessourceAggrege> raP2PLireUnRetour = new ConnectorResponse<Retour, RessourceAggrege>(retour, ressourceAggrege);
    EasyMock.expect(_resProxy.pad3101RessourceAggregeP2PLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("P2P"), EasyMock.eq("IdRaccordement"))).andReturn(raP2PLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(1, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireTousParPfi AND RETURNS OK AND LIST NOT EMPTY<br>
   * FILTERS LIST ST AND RETURNS 1 - <br>
   *
   * CALL BL200 -- RESProxy.pad3101RessourceAggregeP2PLireUn AND RETURNS OK AND RESSOURCEAGGREGE NOT NULL
   *
   * Result PE0296_Retour -- ListReferenciel NOT EMPTY OK_0200 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_017() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    Ressource ressource = new Ressource("idRessource", "P2P", EtatRessource.ALLOUE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    RessourceRaccordement ressourceRaccordement = new RessourceRaccordement("P2P", "codeAccesTechnique"); //$NON-NLS-1$//$NON-NLS-2$
    ressource.setRessourceRaccordement(ressourceRaccordement);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    List<ServiceTechnique> listST = new ArrayList<>();
    StLienAllocationCommercial stlac1 = new StLienAllocationCommercial("idSt", com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString(), "clientOperateur", "noCompte", "typeObjetCommercial", "ocClientOperateur", "ocNoCompte", "IdRaccordement", "RACCO"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$
    listST.add(stlac1);
    DonneesIdentificationSTPfsOlt donneesIdentificationStPfsOlt = new DonneesIdentificationSTPfsOlt("nomOLt", "1", "3", "4"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    StPfsOlt stPfsOlt = new StPfsOlt("idSt", "statut", "clientOperateur", "noCompte", donneesIdentificationStPfsOlt); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
    listST.add(stPfsOlt);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, listST);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireUnRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    RessourceAggregeP2P ressourceAggrege = new RessourceAggregeP2P("nomOLT", 1, 2, 3); //$NON-NLS-1$
    ressourceAggrege.setPositionRelativePortP2P(3);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, RessourceAggrege> raP2PLireUnRetour = new ConnectorResponse<Retour, RessourceAggrege>(retour, ressourceAggrege);
    EasyMock.expect(_resProxy.pad3101RessourceAggregeP2PLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("P2P"), EasyMock.eq("IdRaccordement"))).andReturn(raP2PLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(1, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireTousParPfi AND RETURNS OK AND LIST NOT EMPTY<br>
   * FILTERS LIST ST AND RETURNS 1 - <br>
   *
   * CALL BL200 -- RESProxy.pad3101RessourceAggregeP2PLireUn AND RETURNS OK AND RESSOURCEAGGREGE NOT NULL
   *
   * Result PE0296_Retour -- ListReferenciel NOT EMPTY OK_0200 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_018() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    Ressource ressource = new Ressource("idRessource", "P2P", EtatRessource.ALLOUE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    RessourceRaccordement ressourceRaccordement = new RessourceRaccordement("P2P", "codeAccesTechnique"); //$NON-NLS-1$//$NON-NLS-2$
    ressource.setRessourceRaccordement(ressourceRaccordement);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    List<ServiceTechnique> listST = new ArrayList<>();
    StLienAllocationCommercial stlac1 = new StLienAllocationCommercial("idSt", com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString(), "clientOperateur", "noCompte", "typeObjetCommercial", "ocClientOperateur", "ocNoCompte", "IdRaccordement", "RACCO"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$
    listST.add(stlac1);
    DonneesIdentificationSTPfsOlt donneesIdentificationStPfsOlt = new DonneesIdentificationSTPfsOlt("nomOLt", "1", "3", "4"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    StPfsOlt stPfsOlt = new StPfsOlt("idSt", "ECHEC", "clientOperateur", "noCompte", donneesIdentificationStPfsOlt); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
    listST.add(stPfsOlt);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, listST);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireUnRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    RessourceAggregeP2P ressourceAggrege = new RessourceAggregeP2P("nomOLT", 1, 2, 3); //$NON-NLS-1$
    ressourceAggrege.setPositionRelativePortP2P(3);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, RessourceAggrege> raP2PLireUnRetour = new ConnectorResponse<Retour, RessourceAggrege>(retour, ressourceAggrege);
    EasyMock.expect(_resProxy.pad3101RessourceAggregeP2PLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("P2P"), EasyMock.eq("IdRaccordement"))).andReturn(raP2PLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(1, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireTousParPfi AND RETURNS OK AND LIST NOT EMPTY<br>
   * FILTERS LIST ST AND RETURNS 1 - <br>
   *
   * CALL BL200 -- RESProxy.pad3101RessourceAggregeP2PLireUn AND RETURNS OK AND RESSOURCEAGGREGE NOT NULL
   *
   * Result PE0296_Retour -- ListReferenciel NOT EMPTY OK_0200 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_019() throws Throwable
  {

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, pfi);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    Ressource ressource = new Ressource("idRessource", "P2P", EtatRessource.ALLOUE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    RessourceRaccordement ressourceRaccordement = new RessourceRaccordement("P2P", "codeAccesTechnique"); //$NON-NLS-1$//$NON-NLS-2$
    ressource.setRessourceRaccordement(ressourceRaccordement);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    List<ServiceTechnique> listST = new ArrayList<>();
    StLienAllocationCommercial stlac1 = new StLienAllocationCommercial("idSt", com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString(), "clientOperateur", "noCompte", "typeObjetCommercial", "ocClientOperateur", "ocNoCompte", "IdRaccordement", "RACCO"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$
    listST.add(stlac1);
    DonneesIdentificationSTPfsOlt donneesIdentificationStPfsOlt = new DonneesIdentificationSTPfsOlt("nomOLt", "1", "3", "4"); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    DonneesProvisionneesSTPfsOlt donnesProvisionneesSTPfsOlt = new DonneesProvisionneesSTPfsOlt("codeAccesTechnique", "vlan2"); //$NON-NLS-1$ //$NON-NLS-2$
    StPfsOlt stPfsOlt = new StPfsOlt("idSt", "ACTIF", "clientOperateur", "noCompte", donneesIdentificationStPfsOlt); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
    stPfsOlt.setDonneesProvisionnesPfsOlt(donnesProvisionneesSTPfsOlt);
    listST.add(stPfsOlt);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, listST);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireUnRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    RessourceAggregeP2P ressourceAggrege = new RessourceAggregeP2P("nomOLT", 1, 2, 3); //$NON-NLS-1$
    ressourceAggrege.setPositionRelativePortP2P(3);
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, RessourceAggrege> raP2PLireUnRetour = new ConnectorResponse<Retour, RessourceAggrege>(retour, ressourceAggrege);
    EasyMock.expect(_resProxy.pad3101RessourceAggregeP2PLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("P2P"), EasyMock.eq("IdRaccordement"))).andReturn(raP2PLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(1, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn.
   *
   * CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT is NOT EMPTY, IdFonctionnelPa and clientOperateur are empty (group 3) <br>
   * CALL BL200 -- RESProxy.getInstance().ressourceLireUn AND RETURNS OK AND RESSOURCE NOT NULL<br>
   * CALL BL200 -- RSTProxy.getInstance().serviceTechniqueLireUn AND LIST NOT EMPTY<br>
   *
   * Result PE0296_Retour -- ListReferenciel NOT EMPTY OK_200 <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_020() throws Throwable
  {

    Request request = setRequestGroup3();

    Retour retour = RetourFactory.createOkRetour();

    PFI pfi = new PFI("clientOperateur", "noCompte", Statut.ACTIF, "ligneMarche", null, null, null); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<PA> paList = new ArrayList<>();
    PA pa = new PA("idFonctionnelPa", TypePA.LIGNE_FIXE.toString(), Statut.ACTIF, null, null); //$NON-NLS-1$
    PaTypeLigneFixe paTypeLigneFixe = new PaTypeLigneFixe();
    AccessTechniqueCommercial accessTechniqueCommercial = new AccessTechniqueCommercial("P2P", "codeAccesTechnique"); //$NON-NLS-1$ //$NON-NLS-2$
    RaccordementCommercial raccordementCommercial = new RaccordementCommercial(accessTechniqueCommercial, "codeNro"); //$NON-NLS-1$
    paTypeLigneFixe.setRaccordementCommercial(raccordementCommercial);
    paTypeLigneFixe.setIdRaccordement("IdRaccordement"); //$NON-NLS-1$
    paTypeLigneFixe.setDistance(10);
    pa.setPaTypeLigneFixe(paTypeLigneFixe);
    paList.add(pa);
    pfi.setPa(paList);

    Ressource ressource = new Ressource("idRessource", "typeRessource", EtatRessource.RESERVE.toString()); //$NON-NLS-1$ //$NON-NLS-2$
    ressource.setIdSt("idSt"); //$NON-NLS-1$
    EasyMock.expect(RESProxy.getInstance()).andReturn(_resProxy).once();
    ConnectorResponse<Retour, Ressource> ressourceLireUnRetour = new ConnectorResponse<Retour, Ressource>(retour, ressource);
    EasyMock.expect(_resProxy.ressourceLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("IdRaccordement"), EasyMock.eq("RACCO"))).andReturn(ressourceLireUnRetour).once(); //$NON-NLS-1$//$NON-NLS-2$

    List<ServiceTechnique> listST = new ArrayList<>();
    StLienAllocationCommercial stlac = new StLienAllocationCommercial("idSt", "statut", "clientOperateur", "noCompte", "typeObjetCommercial", "clientOperateur", "noCompte", "idRessource", "typeRessource"); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$
    listST.add(stlac);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    ConnectorResponse<Retour, List<ServiceTechnique>> stLireUnRetour = new ConnectorResponse<Retour, List<ServiceTechnique>>(retour, listST);
    EasyMock.expect(_rstProxy.serviceTechniqueLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("idSt"))).andReturn(stLireUnRetour).once(); //$NON-NLS-1$

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy).once();
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"), EasyMock.isNull(), EasyMock.isNull())).andReturn(stLireUnRetour).once(); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(1, retourPE0296.getListReferentiel().size());

  }

  /**
   * Test Case CALLS BL100 -- RPGProxy.pfiLireUn.
   *
   * PROCESS PARAMETERS ARE INVALID CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALLS BL100 -- RPGProxy.pfiLireUn and returns NOK CAT4 NO_COMPTE_INCONNU<br>
   *
   * Result PE0296_Retour -- ListReferenciel Empty -- Erreur -- NO_COMPTE_INCONNU <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_PARAM000() throws Throwable
  {

    ProcessManager.getInstance().getProcessParams().clear();
    Map<String, String> map = new HashMap<>();
    map.put("sourceDonneeParDefaut", "REFERENTIEL1"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("auditParDefaut", "FALSE2"); //$NON-NLS-1$ //$NON-NLS-2$

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_COMPTE_INCONNU, MessageFormat.format(Messages.getString("PE0296.BL100.noCompteIconnu"), "noCompte", "clientOperateur")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, null);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());
    assertEquals(IMegSpiritConsts.NO_COMPTE_INCONNU, retourPE0296.getError());

  }

  /**
   * Test Case CALLS BL100 -- RPGProxy.pfiLireUn.
   *
   * PROCESS PARAMETERS ARE EMPTY CALLS BL001 and returns OK . <br>
   * CALLS BL100 <br>
   * ID_RACCORDEMENT and ID_FONCTIONNEL_PA are EMPTY <br>
   * CALLS BL100 -- RPGProxy.pfiLireUn and returns NOK CAT4 NO_COMPTE_INCONNU<br>
   *
   * Result PE0296_Retour -- ListReferenciel Empty -- Erreur -- NO_COMPTE_INCONNU <br>
   *
   *
   * @throws Throwable
   *           Exception
   */

  @Test
  public void PE0296_Nominal_PARAM001() throws Throwable
  {

    ProcessManager.getInstance().getProcessParams().clear();

    Request request = setRequestGroup2();

    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_COMPTE_INCONNU, MessageFormat.format(Messages.getString("PE0296.BL100.noCompteIconnu"), "noCompte", "clientOperateur")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgProxy).once();
    ConnectorResponse<Retour, PFI> retourLireUn = new ConnectorResponse<Retour, PFI>(retour, null);
    EasyMock.expect(_rpgProxy.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq("clientOperateur"), EasyMock.eq("noCompte"))).andReturn(retourLireUn).once(); //$NON-NLS-1$//$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retourPE0296 = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(0, retourPE0296.getListReferentiel().size());
    assertEquals(IMegSpiritConsts.NO_COMPTE_INCONNU, retourPE0296.getError());

  }

  /**
   * Test Case Request Header X_PROCESS is empty
   *
   * Result
   *
   * @throws Throwable
   *           Exception
   */
  @Test
  public void PE0296_Nominal_RequestHeader_001() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, ""); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter temp = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.CLIENT_OPERATEUR.getParamName(), "clientOperateur");//$NON-NLS-1$
    list.add(temp);
    Parameter temp1 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.NO_COMPTE.getParamName(), "noCompte");//$NON-NLS-1$
    list.add(temp1);
    Parameter temp2 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_FONCTIONNEL_PA.getParamName(), "idFonctionnelPa");//$NON-NLS-1$
    list.add(temp2);
    Parameter temp3 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_RACCORDEMENT.getParamName(), "idRaccordement");//$NON-NLS-1$
    list.add(temp3);
    Parameter temp4 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.SOURCE_DONNEE.getParamName(), "REFERENTIEL");//$NON-NLS-1$
    list.add(temp4);
    Parameter temp5 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.AUDIT.getParamName(), "false");//$NON-NLS-1$
    list.add(temp5);
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retour = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(0, retour.getListReferentiel().size());

  }

  /**
   * Test Case Request Header X_REQUEST_ID is empty
   *
   * Result
   *
   * @throws Throwable
   *           Exception
   */
  @Test
  public void PE0296_Nominal_RequestHeader_002() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "2231321"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, ""); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter temp = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.CLIENT_OPERATEUR.getParamName(), "clientOperateur");//$NON-NLS-1$
    list.add(temp);
    Parameter temp1 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.NO_COMPTE.getParamName(), "noCompte");//$NON-NLS-1$
    list.add(temp1);
    Parameter temp2 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_FONCTIONNEL_PA.getParamName(), "idFonctionnelPa");//$NON-NLS-1$
    list.add(temp2);
    Parameter temp3 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_RACCORDEMENT.getParamName(), "idRaccordement");//$NON-NLS-1$
    list.add(temp3);
    Parameter temp4 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.SOURCE_DONNEE.getParamName(), "REFERENTIEL");//$NON-NLS-1$
    list.add(temp4);
    Parameter temp5 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.AUDIT.getParamName(), "false");//$NON-NLS-1$
    list.add(temp5);
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retour = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(0, retour.getListReferentiel().size());

  }

  /**
   * Test Case Request Header X_SOURCE is empty
   *
   * Result
   *
   * @throws Throwable
   *           Exception
   */
  @Test
  public void PE0296_Nominal_RequestHeader_003() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "2231321"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "fffff"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, ""); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter temp = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.CLIENT_OPERATEUR.getParamName(), "clientOperateur");//$NON-NLS-1$
    list.add(temp);
    Parameter temp1 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.NO_COMPTE.getParamName(), "noCompte");//$NON-NLS-1$
    list.add(temp1);
    Parameter temp2 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_FONCTIONNEL_PA.getParamName(), "idFonctionnelPa");//$NON-NLS-1$
    list.add(temp2);
    Parameter temp3 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_RACCORDEMENT.getParamName(), "idRaccordement");//$NON-NLS-1$
    list.add(temp3);
    Parameter temp4 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.SOURCE_DONNEE.getParamName(), "REFERENTIEL");//$NON-NLS-1$
    list.add(temp4);
    Parameter temp5 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.AUDIT.getParamName(), "false");//$NON-NLS-1$
    list.add(temp5);
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retour = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(0, retour.getListReferentiel().size());

  }

  /**
   * Test Case Request URLParameters are all empty
   *
   * Result NOK
   *
   * @throws Throwable
   *           Exception
   */
  @Test
  public void PE0296_Nominal_RequestURLParameters_001() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "2231321"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "fffff"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "xxxxx"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter temp = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.CLIENT_OPERATEUR.getParamName(), "");//$NON-NLS-1$
    list.add(temp);
    Parameter temp1 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.NO_COMPTE.getParamName(), "");//$NON-NLS-1$
    list.add(temp1);
    Parameter temp2 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_FONCTIONNEL_PA.getParamName(), "");//$NON-NLS-1$
    list.add(temp2);
    Parameter temp3 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_RACCORDEMENT.getParamName(), "");//$NON-NLS-1$
    list.add(temp3);
    Parameter temp4 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.SOURCE_DONNEE.getParamName(), "");//$NON-NLS-1$
    list.add(temp4);
    Parameter temp5 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.AUDIT.getParamName(), "");//$NON-NLS-1$
    list.add(temp5);
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    String result = response.getGenericResponse().getResult();

    PE0296_Retour retour = deserializeWithMoshi(result, PE0296_Retour.class);

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(0, retour.getListReferentiel().size());

  }

  /**
   * Sets the test
   */
  @Before
  public void setUp()
  {
    _processInstance = new PE0296_DiagnosticRaccordement();
    _processInstance.initializeContext();

    Map<String, String> map = new HashMap<>();
    map.put("sourceDonneeParDefaut", "REFERENTIEL"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("auditParDefaut", "FALSE"); //$NON-NLS-1$ //$NON-NLS-2$

    Map<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);

    PowerMock.resetAll();
    PowerMock.mockStatic(RSTProxy.class);
    PowerMock.mockStatic(RESProxy.class);
    PowerMock.mockStatic(RPGProxy.class);

  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Deserializes the string in jsonString parameter and returns an instance of the deserialized object.
   *
   * @param jsonString
   *          The string to deserialize
   * @param clazz
   *          The class type of the objet to deserialize to
   * @return The deserialized object
   * @throws RavelException
   *           If thrown by the Json builder
   */
  private <T> T deserializeWithMoshi(String jsonString, Class<T> clazz) throws RavelException
  {
    IRavelJson jsonBuilder = new RavelJsonBuilder() //
        .profil("STARK")//$NON-NLS-1$
        .build();
    final IRavelJsonAdapter<T> adapter = jsonBuilder.adapter(clazz);

    return adapter.fromJson(jsonString);

  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * Request URLParameter IdRaccordement is empty
   *
   * @return Request
   */
  private Request setRequest()
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter temp = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.CLIENT_OPERATEUR.getParamName(), "clientOperateur");//$NON-NLS-1$
    list.add(temp);
    Parameter temp1 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.NO_COMPTE.getParamName(), "noCompte");//$NON-NLS-1$
    list.add(temp1);
    Parameter temp2 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_FONCTIONNEL_PA.getParamName(), "idFonctionnelPa");//$NON-NLS-1$
    list.add(temp2);
    Parameter temp3 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_RACCORDEMENT.getParamName(), "");//$NON-NLS-1$
    list.add(temp3);
    Parameter temp4 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.SOURCE_DONNEE.getParamName(), "REFERENTIEL");//$NON-NLS-1$
    list.add(temp4);
    Parameter temp5 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.AUDIT.getParamName(), "false");//$NON-NLS-1$
    list.add(temp5);
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    return request;
  }

  /**
   * Request URLParameter IdRaccordement is not empty
   *
   * @return Request
   */
  private Request setRequest1()
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter temp = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.CLIENT_OPERATEUR.getParamName(), "clientOperateur");//$NON-NLS-1$
    list.add(temp);
    Parameter temp1 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.NO_COMPTE.getParamName(), "noCompte");//$NON-NLS-1$
    list.add(temp1);
    Parameter temp2 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_FONCTIONNEL_PA.getParamName(), "idFonctionnelPa");//$NON-NLS-1$
    list.add(temp2);
    Parameter temp3 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_RACCORDEMENT.getParamName(), "IdRaccordement");//$NON-NLS-1$
    list.add(temp3);
    Parameter temp4 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.SOURCE_DONNEE.getParamName(), "REFERENTIEL");//$NON-NLS-1$
    list.add(temp4);
    Parameter temp5 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.AUDIT.getParamName(), "false");//$NON-NLS-1$
    list.add(temp5);
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    return request;
  }

  /**
   * Request URLParameter IdRaccordement and idFonctionnelPA are empty
   *
   * @return Request
   */
  private Request setRequestGroup2()
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter temp = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.CLIENT_OPERATEUR.getParamName(), "clientOperateur");//$NON-NLS-1$
    list.add(temp);
    Parameter temp1 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.NO_COMPTE.getParamName(), "noCompte");//$NON-NLS-1$
    list.add(temp1);
    Parameter temp2 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_FONCTIONNEL_PA.getParamName(), "");//$NON-NLS-1$
    list.add(temp2);
    Parameter temp3 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_RACCORDEMENT.getParamName(), "");//$NON-NLS-1$
    list.add(temp3);
    Parameter temp4 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.SOURCE_DONNEE.getParamName(), "REFERENTIEL");//$NON-NLS-1$
    list.add(temp4);
    Parameter temp5 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.AUDIT.getParamName(), "false");//$NON-NLS-1$
    list.add(temp5);
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    return request;
  }

  /**
   * Request URLParameter IdRaccordement, idFonctionnelPA and clientOperateur are empty
   *
   * @return Request
   */
  private Request setRequestGroup3()
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter temp = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.CLIENT_OPERATEUR.getParamName(), "");//$NON-NLS-1$
    list.add(temp);
    Parameter temp1 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.NO_COMPTE.getParamName(), "noCompte");//$NON-NLS-1$
    list.add(temp1);
    Parameter temp2 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_FONCTIONNEL_PA.getParamName(), "");//$NON-NLS-1$
    list.add(temp2);
    Parameter temp3 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.ID_RACCORDEMENT.getParamName(), "IdRaccordement");//$NON-NLS-1$
    list.add(temp3);
    Parameter temp4 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.SOURCE_DONNEE.getParamName(), "REFERENTIEL");//$NON-NLS-1$
    list.add(temp4);
    Parameter temp5 = new Parameter(PE0296_DiagnosticRaccordement.UrlParameters.AUDIT.getParamName(), "false");//$NON-NLS-1$
    list.add(temp5);
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    return request;
  }
}
