/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0279;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.cxf.common.util.CollectionUtils;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.StringUtils;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.oi.OI_SI004_Fibres;
import com.bytel.spirit.common.activities.oi.OI_SI004_Fibres.OI_SI004_FibresBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibre;
import com.bytel.spirit.common.connector.oi.emutation.structs.Fibres;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.PE0279.structs.PE0279_BL001_VerifierDonneesFibresReturn;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ ProcessManager.class, OI_SI004_Fibres.class, OI_SI004_FibresBuilder.class, PE0279_Fibres.class })
public class PE0279_FibresTest
{

  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  /**
   *
   */
  private static final String PE0279_BL001_VerifierDonneesFibres = "PE0279_BL001_VerifierDonneesFibres"; //$NON-NLS-1$
  /**
   *
   */
  private static final String PE0279_BL500_FiltrerFibres = "PE0279_BL500_FiltrerFibres"; //$NON-NLS-1$

  /**
   *
   */
  private static final String OI = "OI"; //$NON-NLS-1$

  /**
   *
   */
  private static final String LISTETAT = "listeEtat"; //$NON-NLS-1$

  /**
   *
   */
  private static final String REFERENCEPM = "referencePM"; //$NON-NLS-1$

  /**
   *
   */
  private static final String REFERENCEPBO = "referencePBO"; //$NON-NLS-1$
  /**
  *
  */
  private static final String REF_PRESTATION_PRISE = "refPrestationPrise"; //$NON-NLS-1$

  /**
   * Podam instance
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  static
  {
    __podam = new PodamFactoryImpl();
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void beforeClassSetup() throws RavelException
  {
    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Run before tests
   *
   * @throws Exception
   *           throw exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
  *
  */
  @MockStrict
  private OI_SI004_FibresBuilder _si004BuilderMock;

  /**
  *
  */
  @MockStrict
  private OI_SI004_Fibres _si004Mock;

  /**
   * PE0279_RessourceEmutation
   */
  private PE0279_Fibres _processInstance;
  /**
  *
  */
  @MockStrict
  private ProcessManager _pmMock;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           On error
   */
  @Before
  public void init() throws RavelException
  {
    _processInstance = new PE0279_Fibres();
    _processInstance.initializeContext();

    PowerMock.resetAll();
    PowerMock.mockStatic(ProcessManager.class);
    PowerMock.mockStatic(OI_SI004_Fibres.class);
    PowerMock.mockStatic(OI_SI004_FibresBuilder.class);

  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0279_BL001_VerifierDonneesInfoMutation_KO_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    fillRequestHeaders(request, xClientOperateur);

    PE0279_BL001_VerifierDonneesFibresReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0279_BL001_VerifierDonneesFibres, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour.getRetour().getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour.getRetour().getDiagnostic());
    assertEquals("Header X-Process null ou vide.", bl001Retour.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0279_BL001_VerifierDonneesInfoMutation_KO_002() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xSource);

    PE0279_BL001_VerifierDonneesFibresReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0279_BL001_VerifierDonneesFibres, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour.getRetour().getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour.getRetour().getDiagnostic());
    assertEquals("Header X-Request-Id null ou vide.", bl001Retour.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0279_BL001_VerifierDonneesInfoMutation_KO_003() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xSource, xRequestId);

    PE0279_BL001_VerifierDonneesFibresReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0279_BL001_VerifierDonneesFibres, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour.getRetour().getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour.getRetour().getDiagnostic());
    assertEquals("Header X-Source null ou vide.", bl001Retour.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0279_BL001_VerifierDonneesInfoMutation_KO_004() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    Parameter listEtat = new Parameter(LISTETAT, " fibre disponible,  fibre réservée , fibre occupée ");//$NON-NLS-1$
    List<Parameter> list = new ArrayList<>();
    list.add(listEtat);
    Parameter referencePm = new Parameter(REFERENCEPM, "PM");//$NON-NLS-1$
    list.add(referencePm);
    Parameter referencePBO = new Parameter(REFERENCEPBO, "PB"); //$NON-NLS-1$
    list.add(referencePBO);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    PE0279_BL001_VerifierDonneesFibresReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0279_BL001_VerifierDonneesFibres, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour.getRetour().getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour.getRetour().getDiagnostic());
    assertEquals("Paramètre OI null", bl001Retour.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0279_BL001_VerifierDonneesInfoMutation_KO_005() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL");//$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(LISTETAT, " cable disponible,  cable réservée , cable occupée ");//$NON-NLS-1$
    list.add(listEtat);
    Parameter referencePm = new Parameter(REFERENCEPM, "PM");//$NON-NLS-1$
    list.add(referencePm);
    Parameter referencePBO = new Parameter(REFERENCEPBO, "PB"); //$NON-NLS-1$
    list.add(referencePBO);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    PE0279_BL001_VerifierDonneesFibresReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0279_BL001_VerifierDonneesFibres, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour.getRetour().getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour.getRetour().getDiagnostic());
    assertEquals("La valeur spécifiée dans listeEtat n'est pas autorisée", bl001Retour.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0279_BL001_VerifierDonneesInfoMutation_KO_006() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL");//$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(LISTETAT, " fibre disponible,  fibre réservée , fibre occupée ");//$NON-NLS-1$
    list.add(listEtat);
    Parameter referencePBO = new Parameter(REFERENCEPBO, "PB"); //$NON-NLS-1$
    list.add(referencePBO);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    PE0279_BL001_VerifierDonneesFibresReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0279_BL001_VerifierDonneesFibres, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour.getRetour().getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour.getRetour().getDiagnostic());
    assertEquals("Paramètre referencePM null", bl001Retour.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0279_BL001_VerifierDonneesInfoMutation_KO_007() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL");//$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(LISTETAT, " fibre disponible,  fibre réservée , fibre occupée ");//$NON-NLS-1$
    list.add(listEtat);
    Parameter referencePm = new Parameter(REFERENCEPM, "PM");//$NON-NLS-1$
    list.add(referencePm);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    PE0279_BL001_VerifierDonneesFibresReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0279_BL001_VerifierDonneesFibres, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour.getRetour().getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour.getRetour().getDiagnostic());
    assertEquals("Paramètre referencePBO null", bl001Retour.getRetour().getLibelle()); //$NON-NLS-1$

  }

  /**
   * Respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0279_BL001_VerifierDonneesInfoMutation_OK() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL");//$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(LISTETAT, " fibre disponible,  fibre réservée , fibre occupée ");//$NON-NLS-1$
    list.add(listEtat);
    Parameter referencePm = new Parameter(REFERENCEPM, "PM");//$NON-NLS-1$
    list.add(referencePm);
    Parameter referencePBO = new Parameter(REFERENCEPBO, "PB"); //$NON-NLS-1$
    list.add(referencePBO);
    Parameter referencePrise = new Parameter(REF_PRESTATION_PRISE, "PRISE"); //$NON-NLS-1$
    list.add(referencePrise);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    PE0279_BL001_VerifierDonneesFibresReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0279_BL001_VerifierDonneesFibres, tracabilite, request);
    assertEquals(StringConstants.OK, bl001Retour.getRetour().getResultat());
    assertNull(bl001Retour.getRetour().getCategorie());
    assertNull(bl001Retour.getRetour().getDiagnostic());
    assertNull(bl001Retour.getRetour().getLibelle());

    assertEquals(oi.getValue(), bl001Retour.getOi());
    String[] etatArray = StringUtils.commaDelimitedListToStringArray(listEtat.getValue());
    etatArray = StringUtils.trimArrayElements(etatArray);
    assertEquals(Arrays.asList(etatArray), bl001Retour.getListeEtat());
    assertEquals(referencePm.getValue(), bl001Retour.getReferencePM());
    assertEquals(referencePBO.getValue(), bl001Retour.getReferencePBO());

  }

  /**
   * Test Nominal. return OK with list empty <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0279_BL500_FiltrerFibres_OK() throws Throwable
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Pair<String, String> pairListEtat = new Pair<String, String>(LISTETAT, " fibre disponible,  fibre réservée , fibre occupée ");//$NON-NLS-1$
    String[] etatArray = StringUtils.commaDelimitedListToStringArray(pairListEtat._second);
    etatArray = StringUtils.trimArrayElements(etatArray);
    List<String> listEtat = Arrays.asList(etatArray);

    List<Fibre> listFibres = new ArrayList<Fibre>();
    Fibre f1 = __podam.manufacturePojo(Fibre.class);
    listFibres.add(f1);
    Fibre f2 = __podam.manufacturePojo(Fibre.class);
    listFibres.add(f2);

    Pair<List<Fibre>, Retour> bl500Result = Whitebox.invokeMethod(_processInstance, PE0279_BL500_FiltrerFibres, tracabilite, listFibres, listEtat);

    assertEquals(StringConstants.OK, bl500Result._second.getResultat());
    assertEquals(true, CollectionUtils.isEmpty(bl500Result._first));
  }

  /**
   * Test Nominal. return NOK<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0279_Nominal_NOK_001() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL");//$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(LISTETAT, " fibre disponible,  fibre réservée , fibre occupée ");//$NON-NLS-1$
    list.add(listEtat);
    Parameter referencePm = new Parameter(REFERENCEPM, "PM");//$NON-NLS-1$
    list.add(referencePm);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"error\":\"NON_RESPECT_STI\",\"error_description\":\"Paramètre referencePBO null\"}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);

  }

  /**
   * Test Nominal. return OK with no empty list<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0279_Nominal_OK_001() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL");//$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(LISTETAT, " fibre disponible,  fibre réservée , fibre occupée ");//$NON-NLS-1$
    list.add(listEtat);
    Parameter referencePm = new Parameter(REFERENCEPM, "PM");//$NON-NLS-1$
    list.add(referencePm);
    Parameter referencePBO = new Parameter(REFERENCEPBO, "PB"); //$NON-NLS-1$
    list.add(referencePBO);
    Parameter referencePrestationPrise = new Parameter(REF_PRESTATION_PRISE, "PRISE"); //$NON-NLS-1$
    list.add(referencePrestationPrise);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    PowerMock.expectNew(OI_SI004_FibresBuilder.class).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.codeOi(EasyMock.anyString())).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.references(EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString())).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.build()).andReturn(_si004Mock);
    List<Fibre> listFibres = new ArrayList<Fibre>();
    listFibres.add(new Fibre("Fibre 143865", "B 03", "03:VER Tiret 1", "11:VER", "fibre disponible", "FI-0026-6752")); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$//$NON-NLS-5$ //$NON-NLS-6$
    listFibres.add(new Fibre("Fibre 095366", "B 03", "03:VER Tiret 1", "12:JAU", "fibre réservée", "FI-0089-3319")); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$//$NON-NLS-5$ //$NON-NLS-6$
    Fibres fibres = new Fibres(listFibres);
    EasyMock.expect(_si004Mock.execute(_processInstance)).andReturn(fibres);
    EasyMock.expect(_si004Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"resultsCount\":2,\"items\":[{\"identifiantFibre\":\"Fibre 143865\",\"referenceCablePBO\":\"B 03\",\"informationTubePBO\":\"03:VER Tiret 1\",\"informationFibrePBO\":\"11:VER\",\"etatFibre\":\"fibre disponible\",\"referencePrise\":\"FI-0026-6752\"},{\"identifiantFibre\":\"Fibre 095366\",\"referenceCablePBO\":\"B 03\",\"informationTubePBO\":\"03:VER Tiret 1\",\"informationFibrePBO\":\"12:JAU\",\"etatFibre\":\"fibre réservée\",\"referencePrise\":\"FI-0089-3319\"}]}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);

  }

  /**
   * Test Nominal. return OK with empty list<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0279_Nominal_OK_002() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL");//$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(LISTETAT, " fibre disponible,  fibre réservée , fibre occupée ");//$NON-NLS-1$
    list.add(listEtat);
    Parameter referencePm = new Parameter(REFERENCEPM, "PM");//$NON-NLS-1$
    list.add(referencePm);
    Parameter referencePBO = new Parameter(REFERENCEPBO, "PB"); //$NON-NLS-1$
    list.add(referencePBO);
    Parameter referencePrestationPrise = new Parameter(REF_PRESTATION_PRISE, "PRISE"); //$NON-NLS-1$
    list.add(referencePrestationPrise);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    PowerMock.expectNew(OI_SI004_FibresBuilder.class).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.codeOi(EasyMock.anyString())).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.references(EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString())).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.build()).andReturn(_si004Mock);
    List<Fibre> listFibres = new ArrayList<Fibre>();
    Fibre f1 = __podam.manufacturePojo(Fibre.class);
    listFibres.add(f1);
    Fibre f2 = __podam.manufacturePojo(Fibre.class);
    listFibres.add(f2);
    Fibres fibres = new Fibres(listFibres);
    EasyMock.expect(_si004Mock.execute(_processInstance)).andReturn(fibres);
    EasyMock.expect(_si004Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    assertEquals("{\"resultsCount\":0}", result); //$NON-NLS-1$

  }

  /**
   * Test Nominal. return OK no filter<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0279_Nominal_OK_003() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL");//$NON-NLS-1$
    list.add(oi);
    Parameter referencePm = new Parameter(REFERENCEPM, "PM");//$NON-NLS-1$
    list.add(referencePm);
    Parameter referencePBO = new Parameter(REFERENCEPBO, "PB"); //$NON-NLS-1$
    list.add(referencePBO);
    Parameter referencePrestationPrise = new Parameter(REF_PRESTATION_PRISE, "PRISE"); //$NON-NLS-1$
    list.add(referencePrestationPrise);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    PowerMock.expectNew(OI_SI004_FibresBuilder.class).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.codeOi(EasyMock.anyString())).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.references(EasyMock.anyString(), EasyMock.anyString(), EasyMock.anyString())).andReturn(_si004BuilderMock);
    EasyMock.expect(_si004BuilderMock.build()).andReturn(_si004Mock);
    List<Fibre> listFibres = new ArrayList<Fibre>();
    listFibres.add(new Fibre("Fibre 143865", "B 03", "03:VER Tiret 1", "11:VER", "fibre disponible", "FI-0026-6752")); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$//$NON-NLS-5$ //$NON-NLS-6$
    listFibres.add(new Fibre("Fibre 095366", "B 03", "03:VER Tiret 1", "12:JAU", "fibre réservée", "FI-0089-3319")); //$NON-NLS-1$ //$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$//$NON-NLS-5$ //$NON-NLS-6$
    Fibres fibres = new Fibres(listFibres);
    EasyMock.expect(_si004Mock.execute(_processInstance)).andReturn(fibres);
    EasyMock.expect(_si004Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"resultsCount\":2,\"items\":[{\"identifiantFibre\":\"Fibre 143865\",\"referenceCablePBO\":\"B 03\",\"informationTubePBO\":\"03:VER Tiret 1\",\"informationFibrePBO\":\"11:VER\",\"etatFibre\":\"fibre disponible\",\"referencePrise\":\"FI-0026-6752\"},{\"identifiantFibre\":\"Fibre 095366\",\"referenceCablePBO\":\"B 03\",\"informationTubePBO\":\"03:VER Tiret 1\",\"informationFibrePBO\":\"12:JAU\",\"etatFibre\":\"fibre réservée\",\"referencePrise\":\"FI-0089-3319\"}]}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);

  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Create ProcessManager mock
   */
  private void createProcessManagerManagerMock()
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<String, Map<String, String>>();
    processParams.put("", new HashMap<String, String>()); //$NON-NLS-1$
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_pmMock).anyTimes();
    EasyMock.expect(_pmMock.getProcessParams()).andReturn(processParams).anyTimes();

  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }
}
