/*******************************************************************************
 * $Id: PM001_InfoSIM_Test.java 29996 2016-02-19 11:46:36Z vborrego $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.processes.PM001;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.RandomStringUtils;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.utils.MarshallTools;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.ACManagerUtil;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.gdr.GDRProxy;
import com.bytel.spirit.common.connectors.gdr.IGDRConnector;
import com.bytel.spirit.common.connectors.gdr.InfoSIM;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.generated.infosim.CodeRetour;
import com.bytel.spirit.fiat.processes.generated.infosim.IdentificationSim;
import com.bytel.spirit.fiat.processes.generated.infosim.InfoSimIn;
import com.bytel.spirit.fiat.processes.generated.infosim.InfoSimOut;
import com.bytel.spirit.fiat.processes.generated.infosim.InformationsSim;
import com.bytel.spirit.fiat.processes.generated.infosim.ReponseTechnique;

/**
 *
 * @author $Author: vborrego $
 * @version ($Revision: 27166 $ $Date: 2016-02-19 12:46:36 +0100 (ven., 19 févr. 2016) $)
 */
//Déclaration du runner de test pour lancer les TUs avec le runner PowerMock
@RunWith(PowerMockRunner.class)
//Préparation des classes pour les tests, toutes les classes comportant des méthodes statiques à mocker doivent être présentes dans l'annotation
@PrepareForTest({ GDRProxy.class })
//To avoid: SecretKeyFactory.getInstance() throws exception for all algorithms in unit tests
@PowerMockIgnore("javax.crypto.*")
public class PM001InfoSIM_Test
{
  /**
   *
   */
  private static final String BASE_INDISPONIBLE = "Base indisponible";

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PM001_InfoSIM"; //$NON-NLS-1$

  /**
   * The default pin or puk code.
   */
  public static final String EMPTY_CODE = "00000000"; //$NON-NLS-1$

  /**
   * idAppelant
   */
  public static final String ID_APPELANT = "idAppelant"; //$NON-NLS-1$

  /**
   * idAppelant
   */
  public static final String ID_FLUX = RandomStringUtils.randomAlphanumeric(32);

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    Parameter parameter = new Parameter();

    parameter.setName(name_p);
    parameter.setValue(value_p);

    return parameter;
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   */
  @BeforeClass
  public static void init()
  {
    ACManagerUtil.resetACManager();
    new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    HashMap<String, String> map = new HashMap<String, String>();
    map.put("PatternImsi", "[0-9]{15}"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("PatternIccid", "893320[0-9]{13}"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("GDRConnectorId", IGDRConnector.BEAN_ID); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    processParams.put(StringConstants.EMPTY_STRING, map);
  }

  /**
   * GDR database proxy mock
   */
  @MockStrict
  private GDRProxy _gdrConnector;

  /**
   * The _current process.
   */
  PM001InfoSIM _currentProcess;

  /**
   * Called before each test with the annotation @Before to clean the connectors.
   */
  @Before
  public void beforeTest()
  {

    // context initialization
    _currentProcess = new PM001InfoSIM();
    _currentProcess.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_currentProcess.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(Test_Consts.DEFAULT_MSGID);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    // On initialise toutes les classes à mocker comportant un appel à une méthode statique
    // Dans notre cas on mock statiquemement toutes les classes des activités et des proxys appelés (pour les createContexte et les getInstance)
    PowerMock.mockStaticStrict(GDRProxy.class);
  }

  /**
   * Test le cas où le ICCID est invalide. <br/>
   *
   * <b>Entrées:</b>Entrée invalide (IMSI).<br/>
   * <b>Attendu:</b> Le Imsi avec a code de erreur CODE_RETOUR_ICCID_FORMAT_INCORRECT. <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PM001_InfoSIM_Test_000() throws Throwable
  {
    Request request = prepareRequest(null, null, null, "123456"); //$NON-NLS-1$

    //Prepare mock
    //RESDatabaseProxy should not be called ! If it's called, an assertion error is thrown !
    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);

    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();

    Assert.assertEquals(null, response.getGenericResponse().getDataType());
    showResponse(response);

    InfoSimOut resp = MarshallTools.unmarshall(InfoSimOut.class, response.getGenericResponse().getResult());

    List<InformationsSim> info = resp.getDonneesFonctionnelles().getInfomationsSims();
    Assert.assertEquals(1, info.size());

    for (InformationsSim is : info)
    {
      Assert.assertEquals(ConstantesRetour.CODE_RETOUR_ICCID_FORMAT_INCORRECT, is.getCodeErreur());
      Assert.assertEquals(new Long(123456), is.getIccid());
    }
  }

  /**
   * Test le cas où le IMSI est connu. <br/>
   *
   * <b>Entrées:</b>Entrée valides et un IMSI connu.<br/>
   * <b>Attendu:</b>InformationsSim valorisée. <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PM001_InfoSIM_Test_001() throws Throwable
  {
    InfoSIM mockResult = new InfoSIM();
    mockResult.setImsi(208209813988492L);
    mockResult.setIccid(8933209805139884923L);
    mockResult.setCodePuk1(null);
    Retour mockRetour = new Retour();
    mockRetour.setResultat(StringConstants.OK);

    //Prepare mock
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_gdrConnector);
    EasyMock.expect(_gdrConnector.rechercheInformationsIMSI(_tracabilite, mockResult.getImsi())).andReturn(new ConnectorResponse<InfoSIM, Retour>(mockResult, mockRetour));
    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Request request = prepareRequest(ID_APPELANT, ID_FLUX, mockResult.getImsi().toString(), null);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
    Assert.assertEquals(null, response.getGenericResponse().getDataType());
    showResponse(response);

    InfoSimOut resp = MarshallTools.unmarshall(InfoSimOut.class, response.getGenericResponse().getResult());

    Assert.assertEquals(1, resp.getDonneesFonctionnelles().getInfomationsSims().size());

    for (InformationsSim is : resp.getDonneesFonctionnelles().getInfomationsSims())
    {
      Assert.assertEquals(mockResult.getIccid(), is.getIccid());
      Assert.assertEquals(mockResult.getImsi(), is.getImsi());
      Assert.assertEquals(EMPTY_CODE, is.getCodePuk1());
    }

  }

  /**
   * Test le cas où le IMSI n'est connu. <br/>
   *
   * <b>Entrées:</b>Entrée valides et un IMSI qui n'est connu.<br/>
   * <b>Attendu:</b>. Erreur CODE_RETOUR_IMSI_INCONNU avec le IMSI <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PM001_InfoSIM_Test_002() throws Throwable
  {
    Retour mockRetour = new Retour();
    mockRetour.setResultat(StringConstants.OK);

    //Prepare mock
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_gdrConnector);
    EasyMock.expect(_gdrConnector.rechercheInformationsIMSI(_tracabilite, 208209813988493L)).andReturn(new ConnectorResponse<InfoSIM, Retour>(null, mockRetour));
    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Request request = prepareRequest(ID_APPELANT, ID_FLUX, "208209813988493", null); //$NON-NLS-1$
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
    Assert.assertEquals(null, response.getGenericResponse().getDataType());
    showResponse(response);

    InfoSimOut resp = MarshallTools.unmarshall(InfoSimOut.class, response.getGenericResponse().getResult());
    List<InformationsSim> info = resp.getDonneesFonctionnelles().getInfomationsSims();
    Assert.assertEquals(1, info.size());

    for (InformationsSim is : info)
    {
      Assert.assertEquals(ConstantesRetour.CODE_RETOUR_IMSI_INCONNU, is.getCodeErreur());
      Assert.assertEquals(new Long(208209813988493L), is.getImsi());
    }

  }

  /**
   * Test le cas où le ICCID est connu. <br/>
   *
   * <b>Entrées:</b>Entrée valides et un ICCID connu.<br/>
   * <b>Attendu:</b>InformationsSim valorisée. <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PM001_InfoSIM_Test_003() throws Throwable
  {
    InfoSIM mockResult = new InfoSIM();
    mockResult.setImsi(208209813988492L);
    mockResult.setIccid(8933209805139884923L);
    mockResult.setCodePuk1("1138"); //$NON-NLS-1$
    Retour mockRetour = new Retour();
    mockRetour.setResultat(StringConstants.OK);

    //Prepare mock
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_gdrConnector);
    EasyMock.expect(_gdrConnector.rechercheInformationsICCID(_tracabilite, mockResult.getIccid())).andReturn(new ConnectorResponse<InfoSIM, Retour>(mockResult, mockRetour));
    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Request request = prepareRequest(ID_APPELANT, ID_FLUX, null, mockResult.getIccid().toString());
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
    Assert.assertEquals(null, response.getGenericResponse().getDataType());
    showResponse(response);

    InfoSimOut resp = MarshallTools.unmarshall(InfoSimOut.class, response.getGenericResponse().getResult());
    Assert.assertEquals(1, resp.getDonneesFonctionnelles().getInfomationsSims().size());

    for (InformationsSim is : resp.getDonneesFonctionnelles().getInfomationsSims())
    {
      Assert.assertEquals(null, is.getCodeErreur());
      Assert.assertEquals(new Long(208209813988492L), is.getImsi());
      Assert.assertEquals(new Long(8933209805139884923L), is.getIccid());
      Assert.assertEquals("00001138", is.getCodePuk1()); // pin and puk codes should always be 8 char long, completed with zeros. //$NON-NLS-1$
    }
  }

  /**
   * Test le cas où un ICCID n'est connu. <br/>
   *
   * <b>Entrées:</b>Entrée valides et un ICCID qui n'est connu.<br/>
   * <b>Attendu:</b>Erreur CODE_RETOUR_ICCID_INCONNU et le ICCID <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PM001_InfoSIM_Test_004() throws Throwable
  {
    Retour mockRetour = new Retour();
    mockRetour.setResultat(StringConstants.OK);

    //Prepare mock
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_gdrConnector);
    EasyMock.expect(_gdrConnector.rechercheInformationsICCID(_tracabilite, 8933209805139884923L)).andReturn(new ConnectorResponse<InfoSIM, Retour>(null, mockRetour));
    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Request request = prepareRequest(ID_APPELANT, ID_FLUX, null, "8933209805139884923"); //$NON-NLS-1$
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
    Assert.assertEquals(null, response.getGenericResponse().getDataType());
    showResponse(response);

    InfoSimOut resp = MarshallTools.unmarshall(InfoSimOut.class, response.getGenericResponse().getResult());
    List<InformationsSim> info = resp.getDonneesFonctionnelles().getInfomationsSims();
    Assert.assertEquals(1, info.size());

    for (InformationsSim is : info)
    {
      Assert.assertEquals(ConstantesRetour.CODE_RETOUR_ICCID_INCONNU, is.getCodeErreur());
      Assert.assertEquals(new Long(8933209805139884923L), is.getIccid());
    }

  }

  /**
   * Test le cas où le IMSI est invalide. <br/>
   *
   * <b>Entrées:</b>Entrée invalides (IMSI).<br/>
   * <b>Attendu:</b>Erreur CODE_RETOUR_IMSI_FORMAT_INCORRECT et le IMSI <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PM001_InfoSIM_Test_005() throws Throwable
  {
    Request request = prepareRequest(ID_APPELANT, ID_FLUX, "54321", null); //$NON-NLS-1$
    //Prepare mock
    //RESDatabaseProxy should not be called ! If it's called, an assertion error is thrown !
    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
    Assert.assertEquals(null, response.getGenericResponse().getDataType());
    showResponse(response);

    InfoSimOut resp = MarshallTools.unmarshall(InfoSimOut.class, response.getGenericResponse().getResult());

    List<InformationsSim> info = resp.getDonneesFonctionnelles().getInfomationsSims();
    Assert.assertEquals(1, info.size());

    for (InformationsSim is : info)
    {
      Assert.assertEquals(ConstantesRetour.CODE_RETOUR_IMSI_FORMAT_INCORRECT, is.getCodeErreur());
      Assert.assertEquals(new Long(54321), is.getImsi());
    }
  }

  /**
   * Test le cas où il y a une melange de valide et invalide imsis <br/>
   *
   * <b>Entrées:</b>Entrée invalides e invalides (IMSI).<br/>
   * <b>Attendu:</b>Un erreur CODE_RETOUR_IMSI_FORMAT_INCORRECT pour le invalide IMSI <br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PM001_InfoSIM_Test_006() throws Throwable
  {
    Retour mockRetour = new Retour();
    mockRetour.setResultat(StringConstants.OK);

    //Prepare mock
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_gdrConnector);
    EasyMock.expect(_gdrConnector.rechercheInformationsIMSI(_tracabilite, 999990000000000L)).andReturn(new ConnectorResponse<InfoSIM, Retour>(null, mockRetour));
    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Request request = new Request("PM001_InfoSIM", "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    InfoSimIn infoSimIn = new InfoSimIn();

    IdentificationSim idSim1 = new IdentificationSim();
    idSim1.setImsi(999990000000000L);
    infoSimIn.getIdenficationSims().add(idSim1);

    IdentificationSim idSim2 = new IdentificationSim();
    idSim2.setImsi(99999000000L);
    infoSimIn.getIdenficationSims().add(idSim2);

    request.setPayload(MarshallTools.marshall(infoSimIn));

    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
    Assert.assertEquals(null, response.getGenericResponse().getDataType());
    showResponse(response);

    InfoSimOut resp = MarshallTools.unmarshall(InfoSimOut.class, response.getGenericResponse().getResult());

    List<InformationsSim> info = resp.getDonneesFonctionnelles().getInfomationsSims();

    Assert.assertEquals(2, info.size());

    int nrInvalidImsis = 0;

    for (InformationsSim is : info)
    {
      System.out.println(is.getCodeErreur());
      if (ConstantesRetour.CODE_RETOUR_IMSI_FORMAT_INCORRECT.equals(is.getCodeErreur()))
      {
        nrInvalidImsis++;
      }
    }

    Assert.assertEquals(1, nrInvalidImsis);
  }

  /**
   * Test le cas où un ICCID n'est connu : SQLException thrown <br/>
   *
   * <b>Entrées:</b>Entrée valides et SQLException levée à l'appel de la méthode rechercheInformationsICCID du
   * connecteur GDR <br/>
   * <b>Attendu:</b>HTTP KO 500 avec ReponseTechnique {CodeErreur = 2100; CodeRetourPrincipal = NOK; LibelleErreur =
   * exception.getMessage ("BASE_INDISPONIBLE" pour le test)}<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PM001_InfoSIM_Test_007() throws Throwable
  {
    Retour mockRetour = new Retour();
    mockRetour.setResultat(StringConstants.OK);

    //Prepare mock
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_gdrConnector);
    EasyMock.expect(_gdrConnector.rechercheInformationsICCID(_tracabilite, 8933209805139884923L)).andThrow(new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.KO_00500, BASE_INDISPONIBLE));

    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Request request = prepareRequest(ID_APPELANT, ID_FLUX, null, "8933209805139884923"); //$NON-NLS-1$

    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    assertEquals(null, response.getGenericResponse().getDataType());

    InfoSimOut resp = MarshallTools.unmarshall(InfoSimOut.class, response.getGenericResponse().getResult());

    assertTrue(resp.getDonneesFonctionnelles().getInfomationsSims().isEmpty());

    ReponseTechnique reponseTechniqueExpected = new ReponseTechnique();
    reponseTechniqueExpected.setCodeErreur(PM001InfoSIM.CODE_ERREUR_BDD_KO);
    reponseTechniqueExpected.setCodeRetourPrincipal(CodeRetour.NOK);
    reponseTechniqueExpected.setLibelleErreur(BASE_INDISPONIBLE);
    assertEquals(reponseTechniqueExpected, resp.getReponseTechnique());
  }

  /**
   * Test le cas où un IMSI n'est connu : SQLException thrown <br/>
   *
   * <b>Entrées:</b>Entrée valides et SQLException levée à l'appel de la méthode rechercheInformationsIMSI du connecteur
   * GDR <br/>
   * <b>Attendu:</b>HTTP KO 500 avec ReponseTechnique {CodeErreur = 2100; CodeRetourPrincipal = NOK; LibelleErreur =
   * exception.getMessage ("BASE_INDISPONIBLE" pour le test)}<br/>
   *
   * @throws Throwable
   *           on error
   */
  @Test
  public void PM001_InfoSIM_Test_008() throws Throwable
  {
    Retour mockRetour = new Retour();
    mockRetour.setResultat(StringConstants.OK);

    //Prepare mock
    EasyMock.expect(GDRProxy.getInstance()).andReturn(_gdrConnector);
    EasyMock.expect(_gdrConnector.rechercheInformationsIMSI(_tracabilite, 999990000000000L)).andThrow(new RavelException(ExceptionType.DATABASE_ERROR, ErrorCode.KO_00500, BASE_INDISPONIBLE));

    // On enregistre le scénario des appels
    PowerMock.replayAll();
    //Prepare mock

    Request request = prepareRequest(ID_APPELANT, ID_FLUX, "999990000000000", null); //$NON-NLS-1$

    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
    Assert.assertEquals(null, response.getGenericResponse().getDataType());
    showResponse(response);

    InfoSimOut resp = MarshallTools.unmarshall(InfoSimOut.class, response.getGenericResponse().getResult());

    assertTrue(resp.getDonneesFonctionnelles().getInfomationsSims().isEmpty());

    ReponseTechnique reponseTechniqueExpected = new ReponseTechnique();
    reponseTechniqueExpected.setCodeErreur(PM001InfoSIM.CODE_ERREUR_BDD_KO);
    reponseTechniqueExpected.setCodeRetourPrincipal(CodeRetour.NOK);
    reponseTechniqueExpected.setLibelleErreur(BASE_INDISPONIBLE);
    assertEquals(reponseTechniqueExpected, resp.getReponseTechnique());

  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _currentProcess.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * Create a Generic Request to call PM001_InfoSIM
   *
   * @param imsi_p
   *          The IMSI
   * @param iccid_p
   *          The ICCID
   * @return GenericRequest to call PM001_InfoSIM
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(String idAppelant_p, String idFlux_p, String imsi_p, String iccid_p) throws RavelException
  {
    Request request = new Request("PM001_InfoSIM", "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    InfoSimIn infoSimIn = new InfoSimIn();

    IdentificationSim idSim = new IdentificationSim();
    if (imsi_p != null)
    {
      idSim.setImsi(Long.valueOf(imsi_p));
    }
    if (iccid_p != null)
    {
      idSim.setIccid(Long.valueOf(iccid_p));
    }
    infoSimIn.getIdenficationSims().add(idSim);
    request.setPayload(MarshallTools.marshall(infoSimIn));

    UrlParameters urlParametersType = new UrlParameters();

    if (idAppelant_p != null)
    {
      urlParametersType.getUrlParameters().add(createParameter(PM001InfoSIM.ParameterUrl.idAppelant.name(), idAppelant_p));
    }

    if (idFlux_p != null)
    {
      urlParametersType.getUrlParameters().add(createParameter(PM001InfoSIM.ParameterUrl.idFlux.name(), idFlux_p));
    }

    request.setUrlParameters(urlParametersType);

    return request;
  }

  /**
   * @param response
   *          the response to be shown
   * @throws RavelException
   *           on error
   */
  private void showResponse(Response response) throws RavelException
  {
    java.util.logging.Logger.getAnonymousLogger().info(response.getMarshalledResponse());
  }
}
