/*******************************************************************************
* $Id: PE0206_InfosMutationTest.java 15381 2019-01-07 11:47:17Z jpais $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0206;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.parameter.ParameterManager;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI018_RecupererInfosAccesFTTH;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI018_RecupererInfosAccesFTTH.OSSFAI_SI018_RecupererInfosAccesFTTHBuilder;
import com.bytel.spirit.common.connectors.padawanFTTH.PadawanFTTHConnectorProxy;
import com.bytel.spirit.common.generated.configfluxOI.ConfigFluxOI;
import com.bytel.spirit.common.generated.ws.access.ftth.AccesRI;
import com.bytel.spirit.common.generated.ws.access.ftth.AccesRI.ListeRouteOptique;
import com.bytel.spirit.common.generated.ws.access.ftth.AccuseReception;
import com.bytel.spirit.common.generated.ws.access.ftth.AdresseRI;
import com.bytel.spirit.common.generated.ws.access.ftth.EtatAccesRI;
import com.bytel.spirit.common.generated.ws.access.ftth.QuadrupletRivoliRI;
import com.bytel.spirit.common.generated.ws.access.ftth.RecupererInfosAccesResponse;
import com.bytel.spirit.common.generated.ws.access.ftth.RecupererInfosAccesType;
import com.bytel.spirit.common.generated.ws.access.ftth.ReferenceAdresseRI;
import com.bytel.spirit.common.generated.ws.access.ftth.RouteOptiqueRI;
import com.bytel.spirit.common.generated.ws.access.ftth.TypeAr;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.types.parameters.ConfigFluxOIFilter;
import com.bytel.spirit.fiat.processes.PE0206.PE0206_InfosMutation.DemandeInfoMutation;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_Adresse;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_ComplementAdresse;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_HexacleVoie;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_PositionPMType;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_QuadrupletRivoli;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_ReferenceAdresse;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_Retour;
import com.bytel.spirit.fiat.processes.PE0206.sti.PE0206_RouteOptique;
import com.bytel.spirit.fiat.shared.types.json.Fibre;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision: 15381 $ $Date: 2019-01-07 12:47:17 +0100 (lun., 07 janv. 2019) $)
 */

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PrepareForTest({ ParameterManager.class, PE0206_InfosMutation.class, ProcessManager.class, PadawanFTTHConnectorProxy.class, OSSFAI_SI018_RecupererInfosAccesFTTH.class, OSSFAI_SI018_RecupererInfosAccesFTTHBuilder.class })
public class PE0206_InfosMutationTest
{
  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  /**
   * INFO_MUTATION_ACTION
   */
  private static final String INFO_MUTATION_ACTION = "infoMutation"; //$NON-NLS-1$
  /**
   *
   */
  private static final String PE0206_BL002_FormaterReponseInfoMutation = "PE0206_BL002_FormaterReponseInfoMutation"; //$NON-NLS-1$
  /**
   *
   */
  private static final String PE0206_BL001_VerifierDonneesInfoMutation = "PE0206_BL001_VerifierDonneesInfoMutation"; //$NON-NLS-1$

  /**
  *
  */
  private static final String PE0206_BL100_FiltrerAcces = "PE0206_BL100_FiltrerAcces"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PE0206_BL101_OIEligible = "PE0206_BL101_OIEligible"; //$NON-NLS-1$

  /**
   * INSTALLATEUR
   */
  public static final String INSTALLATEUR = "installateur"; //$NON-NLS-1$
  /**
   * NUMINTERVENTION
   */
  public static final String NUMINTERVENTION = "numIntervention"; //$NON-NLS-1$
  /**
   * TYPEINTERVENTION
   */
  public static final String TYPEINTERVENTION = "typeIntervention"; //$NON-NLS-1$
  /**
   * IDEXTERNERDV
   */
  public static final String IDEXTERNERDV = "idExterneRdv"; //$NON-NLS-1$

  /**
   * Podam instance
   */
  private static PodamFactory __podam = new PodamFactoryImpl();
  static
  {
    __podam = new PodamFactoryImpl();
  }

  /**
   * Run before tests
   *
   * @throws Exception
   *           throw exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
  *
  */
  @MockStrict
  private ProcessManager _pmMock;

  /**
  *
  */
  @MockStrict
  private ParameterManager _paramManag;
  /**
  *
  */
  @MockStrict
  private OSSFAI_SI018_RecupererInfosAccesFTTHBuilder _si018BuilderMock;

  /**
  *
  */
  @MockStrict
  private OSSFAI_SI018_RecupererInfosAccesFTTH _si018Mock;
  /**
   *
   */
  @MockStrict
  private PadawanFTTHConnectorProxy _padawnFtthProxy;
  /**
   * PE0206_RessourcesEmutation
   */
  private PE0206_InfosMutation _processInstance;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @Before
  public void init() throws RavelException
  {
    _processInstance = new PE0206_InfosMutation();
    _processInstance.initializeContext();

    PowerMock.resetAll();
    PowerMock.mockStatic(ProcessManager.class);
    PowerMock.mockStatic(ParameterManager.class);
    PowerMock.mockStatic(PadawanFTTHConnectorProxy.class);
    PowerMock.mockStatic(OSSFAI_SI018_RecupererInfosAccesFTTH.class);
    PowerMock.mockStatic(OSSFAI_SI018_RecupererInfosAccesFTTHBuilder.class);

  }

  /**
   * Non respect de la STI (parameter X-Process empty or null)
   *
   * expect Retour (NOK,CAT3,Header X-Process null ou vide.)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL001_VerifierDonneesInfoMutation_KO_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    fillRequestHeaders(request, xClientOperateur);

    Pair<DemandeInfoMutation, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL001_VerifierDonneesInfoMutation, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals(bl001Retour._second.getLibelle(), "Header X-Process null ou vide."); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI (parameter X-Request-Id empty or null)
   *
   * expect Retour (NOK,CAT3,Header X-Request-Id null ou vide.)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL001_VerifierDonneesInfoMutation_KO_002() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xSource);

    Pair<DemandeInfoMutation, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL001_VerifierDonneesInfoMutation, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals(bl001Retour._second.getLibelle(), "Header X-Request-Id null ou vide."); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI (parameter X-Source empty or null)
   *
   * expect Retour (NOK,CAT3,Header X-Source null ou vide.)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL001_VerifierDonneesInfoMutation_KO_003() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xSource, xRequestId);

    Pair<DemandeInfoMutation, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL001_VerifierDonneesInfoMutation, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals(bl001Retour._second.getLibelle(), "Header X-Source null ou vide."); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI (parameter GET idExterneRdv empty )
   *
   * expect Retour (NOK,CAT3,Paramètre idExterneRdv null.)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL001_VerifierDonneesInfoMutation_KO_004() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    Pair<DemandeInfoMutation, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL001_VerifierDonneesInfoMutation, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals(bl001Retour._second.getLibelle(), "Paramètre idExterneRdv null"); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI (parameter GET installateur empty )
   *
   * expect Retour (NOK,CAT3,Paramètre installateur null.)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL001_VerifierDonneesInfoMutation_KO_005() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(IDEXTERNERDV, "idexternRdv"));//$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    Pair<DemandeInfoMutation, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL001_VerifierDonneesInfoMutation, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals(bl001Retour._second.getLibelle(), "Paramètre installateur null"); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI (parameter GET numIntervention empty )
   *
   * expect Retour (NOK,CAT3,Paramètre numIntervention null.)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL001_VerifierDonneesInfoMutation_KO_006() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(IDEXTERNERDV, "idexternRdv")); //$NON-NLS-1$
    list.add(new Parameter(INSTALLATEUR, "PC30")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    Pair<DemandeInfoMutation, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL001_VerifierDonneesInfoMutation, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals(bl001Retour._second.getLibelle(), "Paramètre numIntervention null"); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI (parameter GET typeIntervention empty )
   *
   * expect Retour (NOK,CAT3,Paramètre typeIntervention null.)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL001_VerifierDonneesInfoMutation_KO_007() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(IDEXTERNERDV, "idexternRdv")); //$NON-NLS-1$
    list.add(new Parameter(INSTALLATEUR, "PC30")); //$NON-NLS-1$
    list.add(new Parameter(NUMINTERVENTION, "numintervention")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    Pair<DemandeInfoMutation, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL001_VerifierDonneesInfoMutation, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals(bl001Retour._second.getLibelle(), "Paramètre typeIntervention null"); //$NON-NLS-1$

  }

  /**
   * BL001 Nominal
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL001_VerifierDonneesInfoMutation_OK_001() throws Exception
  {

    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();

    list.add(new Parameter(IDEXTERNERDV, "idexternRdv")); //$NON-NLS-1$
    list.add(new Parameter(INSTALLATEUR, "PC30")); //$NON-NLS-1$
    list.add(new Parameter(NUMINTERVENTION, "numintervention")); //$NON-NLS-1$
    list.add(new Parameter(TYPEINTERVENTION, "SAV")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    Pair<DemandeInfoMutation, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL001_VerifierDonneesInfoMutation, tracabilite, request);

    assertEquals(StringConstants.OK, bl001Retour._second.getResultat());
    assertEquals("idexternRdv", bl001Retour._first.getIdExterneRdv()); //$NON-NLS-1$
    assertEquals("PC30", bl001Retour._first.getInstallateur()); //$NON-NLS-1$
    assertEquals("SAV", bl001Retour._first.getTypeIntervention()); //$NON-NLS-1$
    assertEquals("numintervention", bl001Retour._first.getNumIntervention()); //$NON-NLS-1$

  }

  /**
   * PE0206_BL002_FormaterReponseInfoMutation KO
   *
   * Retour KO (CAT4/FLUX_BIENTOT_DISPONIBLE)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL002_FormaterReponseInfoMutation_KO_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.FLUX_BIENTOT_DISPONIBLE, StringConstants.EMPTY_STRING);
    Pair<ReponseErreur, PE0206_Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL002_FormaterReponseInfoMutation, tracabilite, accesRi, StringConstants.EMPTY_STRING, retour);
    assertEquals(null, bl001Retour._first);
    assertEquals(bl001Retour._second.getDateDispo(), StringConstants.EMPTY_STRING);
    assertEquals(bl001Retour._second.isMutationPossible(), false);
    assertEquals(bl001Retour._second.getOi(), accesRi.getCodeOI());

  }

  /**
   * PE0206_BL002_FormaterReponseInfoMutation KO
   *
   * Retour KO (CAT4/FLUX_INDISPONIBLE)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL002_FormaterReponseInfoMutation_KO_002() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.FLUX_INDISPONIBLE, StringConstants.EMPTY_STRING);
    Pair<ReponseErreur, PE0206_Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL002_FormaterReponseInfoMutation, tracabilite, accesRi, StringConstants.EMPTY_STRING, retour);
    assertEquals(null, bl001Retour._first);
    assertEquals(bl001Retour._second.isMutationPossible(), false);
    assertEquals(bl001Retour._second.getOi(), accesRi.getCodeOI());

  }

  /**
   * PE0206_BL002_FormaterReponseInfoMutation KO
   *
   * Retour KO (CAT1/DONNEE_INVALIDE)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL002_FormaterReponseInfoMutation_KO_003() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.DONNEE_INVALIDE, StringConstants.EMPTY_STRING);
    Pair<ReponseErreur, PE0206_Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL002_FormaterReponseInfoMutation, tracabilite, accesRi, StringConstants.EMPTY_STRING, retour);
    assertEquals(null, bl001Retour._second);
    assertEquals(retour.getLibelle(), bl001Retour._first.getErrorDescription());
    assertEquals(retour.getDiagnostic(), bl001Retour._first.getError());
  }

  /**
   * Nominal PE0206_BL002_FormaterReponseInfoMutation OK
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL002_FormaterReponseInfoMutation_OK_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    Retour retour = RetourFactory.createOkRetour();
    Pair<ReponseErreur, PE0206_Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL002_FormaterReponseInfoMutation, tracabilite, accesRi, StringConstants.EMPTY_STRING, retour);
    assertEquals(null, bl001Retour._first);
    assertEquals(bl001Retour._second.getAdresse().getCodePostal(), accesRi.getAdresse().getCodePostal());
    assertEquals(bl001Retour._second.getAdresse().getCodePostal(), accesRi.getAdresse().getCodePostal());
    assertEquals(bl001Retour._second.isMutationPossible(), true);
    assertEquals(bl001Retour._second.getPriseExisante(), accesRi.isPrisePosee());
    assertEquals(bl001Retour._second.getOi(), accesRi.getCodeOI());

  }

  /**
   * PE0206_BL100_FiltrerAcces_OK cas type d'intervention RACCO
   *
   * @throws Exception
   */
  @Test
  public void PE0206_BL100_FiltrerAcces_0K_001() throws Exception
  {
    String numintervention = "numintervention"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    DemandeInfoMutation demandeinfo = __podam.manufacturePojo(DemandeInfoMutation.class);
    demandeinfo.setTypeIntervention("RACCO"); //$NON-NLS-1$
    demandeinfo.setNumIntervention(numintervention);
    demandeinfo.setInstallateur("installateur"); //$NON-NLS-1$
    AccesRI accesRiexpected = __podam.manufacturePojo(AccesRI.class);
    accesRiexpected.setNumIntervention(numintervention);
    List<AccesRI> listaccesRi = new ArrayList<>();
    listaccesRi.add(accesRiexpected);
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    listaccesRi.add(accesRi);
    accesRi = __podam.manufacturePojo(AccesRI.class);
    listaccesRi.add(accesRi);
    Pair<AccesRI, Retour> bl100Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL100_FiltrerAcces, tracabilite, demandeinfo, listaccesRi);

    assertEquals(StringConstants.OK, bl100Retour._second.getResultat());
    assertEquals(accesRiexpected.getCodeOI(), bl100Retour._first.getCodeOI());
    assertEquals(accesRiexpected.getAdresse(), bl100Retour._first.getAdresse());
    assertEquals(accesRiexpected.getEtatAcces(), bl100Retour._first.getEtatAcces());
    assertEquals(accesRiexpected.getNumIntervention(), bl100Retour._first.getNumIntervention());
    assertEquals(accesRiexpected.getReferencePBO(), bl100Retour._first.getReferencePBO());
    assertEquals(accesRiexpected.getReferencePM(), bl100Retour._first.getReferencePM());
    assertEquals(accesRiexpected.getReferencePrestationPrise(), bl100Retour._first.getReferencePrestationPrise());
    assertEquals(accesRiexpected.getReferencePrise(), bl100Retour._first.getReferencePrise());

  }

  /**
   * PE0206_BL100_FiltrerAcces_0K_002
   *
   * @throws Exception
   */
  @Test
  public void PE0206_BL100_FiltrerAcces_0K_002() throws Exception
  {
    String numintervention = "numintervention"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    DemandeInfoMutation demandeinfo = __podam.manufacturePojo(DemandeInfoMutation.class);
    demandeinfo.setNumIntervention(numintervention);
    demandeinfo.setInstallateur("installateur"); //$NON-NLS-1$
    demandeinfo.setIdExterneRdv("IdExterneRdv"); //$NON-NLS-1$
    AccesRI accesRiexpected = __podam.manufacturePojo(AccesRI.class);
    accesRiexpected.setEtatAcces(EtatAccesRI.CONSTRUIT);
    accesRiexpected.setNumIntervention(numintervention);
    List<AccesRI> listaccesRi = new ArrayList<>();
    listaccesRi.add(accesRiexpected);
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setNumIntervention(numintervention);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    listaccesRi.add(accesRi);
    accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    listaccesRi.add(accesRi);
    Pair<AccesRI, Retour> bl100Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL100_FiltrerAcces, tracabilite, demandeinfo, listaccesRi);
    assertEquals(StringConstants.OK, bl100Retour._second.getResultat());
    assertEquals(accesRiexpected.getCodeOI(), bl100Retour._first.getCodeOI());
    assertEquals(accesRiexpected.getAdresse(), bl100Retour._first.getAdresse());
    assertEquals(accesRiexpected.getEtatAcces(), bl100Retour._first.getEtatAcces());
    assertEquals(accesRiexpected.getNumIntervention(), bl100Retour._first.getNumIntervention());
    assertEquals(accesRiexpected.getReferencePBO(), bl100Retour._first.getReferencePBO());
    assertEquals(accesRiexpected.getReferencePM(), bl100Retour._first.getReferencePM());
    assertEquals(accesRiexpected.getReferencePrestationPrise(), bl100Retour._first.getReferencePrestationPrise());
    assertEquals(accesRiexpected.getReferencePrise(), bl100Retour._first.getReferencePrise());

  }

  /**
   * PE0206_BL100_FiltrerAcces_K0_001 Donneé Invonnue ( "Aucun accès en cours de construction référencés avec ce numéro
   * d'intervention numintervention pour l'installateur installateur")
   *
   *
   * @throws Exception
   */
  @Test
  public void PE0206_BL100_FiltrerAcces_K0_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    DemandeInfoMutation demandeinfo = __podam.manufacturePojo(DemandeInfoMutation.class);
    demandeinfo.setTypeIntervention("RACCO"); //$NON-NLS-1$
    demandeinfo.setNumIntervention("numintervention"); //$NON-NLS-1$
    demandeinfo.setInstallateur("installateur"); //$NON-NLS-1$
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    List<AccesRI> listaccesRi = new ArrayList<>();
    listaccesRi.add(accesRi);
    AccesRI accesRiexpected = __podam.manufacturePojo(AccesRI.class);
    listaccesRi.add(accesRiexpected);
    Pair<AccesRI, Retour> bl100Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL100_FiltrerAcces, tracabilite, demandeinfo, listaccesRi);
    String expectlibelle = "Aucun accès en cours de construction référencés avec ce numéro d'intervention numintervention pour l'installateur installateur"; //$NON-NLS-1$

    assertEquals(StringConstants.NOK, bl100Retour._second.getResultat());
    assertEquals(IMegConsts.CAT4, bl100Retour._second.getCategorie());
    assertEquals(expectlibelle, bl100Retour._second.getLibelle());
    assertEquals(IMegConsts.DONNEE_INCONNUE, bl100Retour._second.getDiagnostic());
  }

  /**
   * PE0206_BL100_FiltrerAcces_K0_002
   *
   * @throws Exception
   */
  @Test
  public void PE0206_BL100_FiltrerAcces_K0_002() throws Exception
  {
    String numintervention = "numintervention"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    DemandeInfoMutation demandeinfo = __podam.manufacturePojo(DemandeInfoMutation.class);
    demandeinfo.setTypeIntervention("RACCO"); //$NON-NLS-1$
    demandeinfo.setNumIntervention(numintervention);
    demandeinfo.setInstallateur("installateur"); //$NON-NLS-1$
    AccesRI accesRiexpected = __podam.manufacturePojo(AccesRI.class);
    accesRiexpected.setNumIntervention(numintervention);
    List<AccesRI> listaccesRi = new ArrayList<>();
    listaccesRi.add(accesRiexpected);
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setNumIntervention(numintervention);
    listaccesRi.add(accesRi);
    accesRi = __podam.manufacturePojo(AccesRI.class);
    listaccesRi.add(accesRi);
    Pair<AccesRI, Retour> bl100Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL100_FiltrerAcces, tracabilite, demandeinfo, listaccesRi);

    String expectlibelle = "Il existe 2 accès en cours de construction référencés avec le même numéro d'intervention numintervention"; //$NON-NLS-1$

    assertEquals(StringConstants.NOK, bl100Retour._second.getResultat());
    assertEquals(IMegConsts.CAT4, bl100Retour._second.getCategorie());
    assertEquals(expectlibelle, bl100Retour._second.getLibelle());
    assertEquals(IMegSpiritConsts.PLUS_QU_UNE_DONNEE, bl100Retour._second.getDiagnostic());
  }

  /**
   * PE0206_BL100_FiltrerAcces_K0_003
   *
   * @throws Exception
   */
  @Test
  public void PE0206_BL100_FiltrerAcces_K0_003() throws Exception
  {
    String numintervention = "numintervention"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    DemandeInfoMutation demandeinfo = __podam.manufacturePojo(DemandeInfoMutation.class);
    demandeinfo.setNumIntervention(numintervention);
    demandeinfo.setInstallateur("installateur"); //$NON-NLS-1$
    demandeinfo.setIdExterneRdv("IdExterneRdv"); //$NON-NLS-1$
    AccesRI accesRiexpected = __podam.manufacturePojo(AccesRI.class);
    accesRiexpected.setNumIntervention(numintervention);
    accesRiexpected.setEtatAcces(EtatAccesRI.CONSTRUIT);
    List<AccesRI> listaccesRi = new ArrayList<>();
    listaccesRi.add(accesRiexpected);
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setNumIntervention(numintervention);
    accesRi.setEtatAcces(EtatAccesRI.CONSTRUIT);
    listaccesRi.add(accesRi);
    accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setEtatAcces(EtatAccesRI.CONSTRUIT);
    listaccesRi.add(accesRi);
    Pair<AccesRI, Retour> bl100Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL100_FiltrerAcces, tracabilite, demandeinfo, listaccesRi);

    String expectlibelle = "Il existe 3 accès à l'état construit référencés avec l'id IdExterneRdv"; //$NON-NLS-1$

    assertEquals(StringConstants.NOK, bl100Retour._second.getResultat());
    assertEquals(IMegConsts.CAT4, bl100Retour._second.getCategorie());
    assertEquals(expectlibelle, bl100Retour._second.getLibelle());
    assertEquals(IMegSpiritConsts.PLUS_QU_UNE_DONNEE, bl100Retour._second.getDiagnostic());
  }

  /**
   * PE0206_BL100_FiltrerAcces_K0_004 cas type intervention != RACCO list accesRI Empty Retour (KO
   *
   * Retour KO/CAT4/DONNEE_INCONNUE/Aucun accès à l'état construit référencé associé à l'id IdExterneRdv
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL100_FiltrerAcces_K0_004() throws Exception
  {
    String numintervention = "numintervention"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    DemandeInfoMutation demandeinfo = __podam.manufacturePojo(DemandeInfoMutation.class);
    demandeinfo.setNumIntervention(numintervention);
    demandeinfo.setInstallateur("installateur"); //$NON-NLS-1$
    demandeinfo.setIdExterneRdv("IdExterneRdv"); //$NON-NLS-1$
    AccesRI accesRiexpected = __podam.manufacturePojo(AccesRI.class);
    accesRiexpected.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    accesRiexpected.setNumIntervention(numintervention);
    List<AccesRI> listaccesRi = new ArrayList<>();
    listaccesRi.add(accesRiexpected);
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setNumIntervention(numintervention);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    listaccesRi.add(accesRi);
    accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    listaccesRi.add(accesRi);
    Pair<AccesRI, Retour> bl100Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL100_FiltrerAcces, tracabilite, demandeinfo, listaccesRi);

    String expectlibelle = "Aucun accès à l'état construit référencé associé  à l'id IdExterneRdv"; //$NON-NLS-1$

    assertEquals(StringConstants.NOK, bl100Retour._second.getResultat());
    assertEquals(IMegConsts.CAT4, bl100Retour._second.getCategorie());
    assertEquals(expectlibelle, bl100Retour._second.getLibelle());
    assertEquals(IMegConsts.DONNEE_INCONNUE, bl100Retour._second.getDiagnostic());
  }

  /**
   * PE0206_BL100_FiltrerAcces_K0_004 cas type intervention != RACCO list accesRI Empty Retour (KO
   *
   * Retour KO/CAT4/DONNEE_INCONNUE/Aucun accès valide associé à l'id IdExterneRdv
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL100_FiltrerAcces_K0_005() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    DemandeInfoMutation demandeinfo = __podam.manufacturePojo(DemandeInfoMutation.class);
    demandeinfo.setIdExterneRdv("IdExterneRdv"); //$NON-NLS-1$
    List<AccesRI> listaccesRi = null;
    Pair<AccesRI, Retour> bl100Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL100_FiltrerAcces, tracabilite, demandeinfo, listaccesRi);

    String expectlibelle = "Aucun accès valide associé à l'id IdExterneRdv"; //$NON-NLS-1$

    assertEquals(StringConstants.NOK, bl100Retour._second.getResultat());
    assertEquals(IMegConsts.CAT4, bl100Retour._second.getCategorie());
    assertEquals(expectlibelle, bl100Retour._second.getLibelle());
    assertEquals(IMegConsts.DONNEE_INCONNUE, bl100Retour._second.getDiagnostic());
  }

  /**
   * PE0206_BL101_OIEligible_0K_001
   *
   *
   *
   * @throws Exception
   */
  @Test
  public void PE0206_BL101_OIEligible_0K_001() throws Exception
  {
    String numintervention = "numintervention"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    DemandeInfoMutation demandeinfo = __podam.manufacturePojo(DemandeInfoMutation.class);
    demandeinfo.setNumIntervention(numintervention);
    demandeinfo.setInstallateur("installateur"); //$NON-NLS-1$
    demandeinfo.setIdExterneRdv("IdExterneRdv"); //$NON-NLS-1$
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    ConfigFluxOI configflux = __podam.manufacturePojo(ConfigFluxOI.class);
    configflux.setDisponible(true);
    mockParameterManager(configflux);
    PowerMock.replayAll();
    Pair<String, Retour> bl100Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL101_OIEligible, tracabilite, demandeinfo, accesRi);
    PowerMock.verifyAll();
    assertEquals(StringConstants.OK, bl100Retour._second.getResultat());
    assertEquals(configflux.getDateDispo(), bl100Retour._first);

  }

  /**
   * PE0206_BL101_OIEligible_K0_001 return Retour KO /CAT4/FLUX_BIENTOT_DISPONIBLE
   *
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL101_OIEligible_K0_001() throws Exception
  {
    String numintervention = "numintervention"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    DemandeInfoMutation demandeinfo = __podam.manufacturePojo(DemandeInfoMutation.class);
    demandeinfo.setNumIntervention(numintervention);
    demandeinfo.setInstallateur("installateur"); //$NON-NLS-1$
    demandeinfo.setIdExterneRdv("IdExterneRdv"); //$NON-NLS-1$
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    accesRi.setCodeOI("codeOI"); //$NON-NLS-1$
    ConfigFluxOI configflux = __podam.manufacturePojo(ConfigFluxOI.class);
    configflux.setDisponible(false);
    configflux.setDateDispo("10/10/2018"); //$NON-NLS-1$
    mockParameterManager(configflux);
    PowerMock.replayAll();
    Pair<String, Retour> bl100Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL101_OIEligible, tracabilite, demandeinfo, accesRi);
    PowerMock.verifyAll();

    String expectlibelle = "Le flux OI_MUTATION sera disponible chez  codeOI à partir du 10/10/2018"; //$NON-NLS-1$
    assertEquals(StringConstants.NOK, bl100Retour._second.getResultat());
    assertEquals(IMegConsts.CAT4, bl100Retour._second.getCategorie());
    assertEquals(expectlibelle, bl100Retour._second.getLibelle());
    assertEquals(IMegSpiritConsts.FLUX_BIENTOT_DISPONIBLE, bl100Retour._second.getDiagnostic());
  }

  /**
   * PE0206_BL101_OIEligible_K0_001
   *
   *
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0206_BL101_OIEligible_K0_002() throws Exception
  {
    String numintervention = "numintervention"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    DemandeInfoMutation demandeinfo = __podam.manufacturePojo(DemandeInfoMutation.class);
    demandeinfo.setNumIntervention(numintervention);
    demandeinfo.setInstallateur("installateur"); //$NON-NLS-1$
    demandeinfo.setIdExterneRdv("IdExterneRdv"); //$NON-NLS-1$
    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    accesRi.setCodeOI("codeOI"); //$NON-NLS-1$
    ConfigFluxOI configflux = __podam.manufacturePojo(ConfigFluxOI.class);
    configflux.setDisponible(false);
    configflux.setDateDispo(null);
    mockParameterManager(configflux);
    PowerMock.replayAll();
    Pair<String, Retour> bl100Retour = Whitebox.invokeMethod(_processInstance, PE0206_BL101_OIEligible, tracabilite, demandeinfo, accesRi);
    PowerMock.verifyAll();

    String expectlibelle = "Le flux OI_MUTATION n'est pas encore disponible chez codeOI"; //$NON-NLS-1$
    assertEquals(StringConstants.NOK, bl100Retour._second.getResultat());
    assertEquals(IMegConsts.CAT4, bl100Retour._second.getCategorie());
    assertEquals(expectlibelle, bl100Retour._second.getLibelle());
    assertEquals(IMegSpiritConsts.FLUX_INDISPONIBLE, bl100Retour._second.getDiagnostic());
  }

  /**
   * PE0206_RessourcesEmutation BL001_VerifierDonneesInfoMutation KO
   *
   * @throws Throwable
   */
  @Test
  public void PE0206_RessourcesEmutation_K0_001() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    fillRequestHeaders(request, xProcess, xClientOperateur, xRequestId);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(IDEXTERNERDV, "idexternRdv")); //$NON-NLS-1$
    list.add(new Parameter(INSTALLATEUR, "installateur")); //$NON-NLS-1$
    list.add(new Parameter(NUMINTERVENTION, "numintervention")); //$NON-NLS-1$
    list.add(new Parameter(TYPEINTERVENTION, "RACCO")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    String jsonexpect = "{\"error\":\"NON_RESPECT_STI\",\"error_description\":\"Header X-Source null ou vide.\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);
    final Response expected = new Response(ErrorCode.KO_00400, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * PE0206_RessourcesEmutation_K0 BL100_FILTrerAcces KO pas de AccesRI trouve
   *
   * @throws Throwable
   */
  @Test
  public void PE0206_RessourcesEmutation_K0_003() throws Throwable
  {
    String numIdextern = "idexternRdv"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(IDEXTERNERDV, "idexternRdv")); //$NON-NLS-1$
    list.add(new Parameter(INSTALLATEUR, "PC30")); //$NON-NLS-1$
    list.add(new Parameter(NUMINTERVENTION, "numintervention")); //$NON-NLS-1$
    list.add(new Parameter(TYPEINTERVENTION, "RACCO")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    request.setOperation(INFO_MUTATION_ACTION);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RecupererInfosAccesResponse recupinfo = __podam.manufacturePojo(RecupererInfosAccesResponse.class);

    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    RecupererInfosAccesType recuperAccesType = new RecupererInfosAccesType();
    AccuseReception accuserReception = new AccuseReception();
    accuserReception.setTypeAr(TypeAr.OK);
    recuperAccesType.setAccuseReception(accuserReception);
    recuperAccesType.getListeAcces().add(accesRi);
    recupinfo.setRecupererInfosAcces(recuperAccesType);
    List<AccesRI> accesRI = new ArrayList<>(Arrays.asList(accesRi));

    mockOSSFAI_SI018(numIdextern, accesRI, RetourFactoryForTU.createOkRetour());
    createProcessManagerManagerMock();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    ReponseErreur reponserreur = new ReponseErreur();
    reponserreur.setError("DONNEE_INCONNUE"); //$NON-NLS-1$
    reponserreur.setErrorDescription("Aucun accès en cours de construction référencés avec ce numéro d'intervention numintervention pour l'installateur PC30"); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    ReponseErreur reponserreurExcpect = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);
    final Response expected = new Response(ErrorCode.KO_00404, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(reponserreur.getError(), reponserreurExcpect.getError());
    assertEquals(reponserreur.getErrorDescription(), reponserreurExcpect.getErrorDescription());
  }

  /**
   * PE0206_RessourcesEmutation_K0 BL100_FILTrerAcces KO plusieurs de AccesRI trouve
   *
   * @throws Throwable
   */
  @Test
  public void PE0206_RessourcesEmutation_K0_004() throws Throwable
  {
    String numIdextern = "idexternRdv"; //$NON-NLS-1$
    String numintervention1 = "numintervention1"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(IDEXTERNERDV, "idexternRdv")); //$NON-NLS-1$
    list.add(new Parameter(INSTALLATEUR, "PC30")); //$NON-NLS-1$
    list.add(new Parameter(NUMINTERVENTION, "numintervention1")); //$NON-NLS-1$
    list.add(new Parameter(TYPEINTERVENTION, "RACCO")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    request.setOperation(INFO_MUTATION_ACTION);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    AccesRI accesRi = __podam.manufacturePojoWithFullData(AccesRI.class);
    accesRi.setNumIntervention(numintervention1);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);

    AccesRI accesRi2 = __podam.manufacturePojoWithFullData(AccesRI.class);
    accesRi2.setNumIntervention(numintervention1);
    accesRi2.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    List<AccesRI> accesRI = new ArrayList<>(Arrays.asList(accesRi, accesRi2));

    ConfigFluxOI configflux = __podam.manufacturePojo(ConfigFluxOI.class);
    configflux.setDisponible(true);

    mockOSSFAI_SI018(numIdextern, accesRI, RetourFactoryForTU.createOkRetour());
    createProcessManagerManagerMock();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    ReponseErreur reponserreur = new ReponseErreur();
    reponserreur.setError("PLUS_QU_UNE_DONNEE"); //$NON-NLS-1$
    reponserreur.setErrorDescription("Il existe 2 accès en cours de construction référencés avec le même numéro d'intervention numintervention1"); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    ReponseErreur reponserreurExcpect = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);
    final Response expected = new Response(ErrorCode.KO_00404, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(reponserreur.getError(), reponserreurExcpect.getError());
    assertEquals(reponserreur.getErrorDescription(), reponserreurExcpect.getErrorDescription());
  }

  /**
   * PE0206_RessourcesEmutation_K0 BL100_FILTrerAcces
   *
   * TypeIntervention not RACCO and List<AccesRI> is empty
   *
   * @throws Throwable
   */
  @Test
  public void PE0206_RessourcesEmutation_K0_005() throws Throwable
  {
    String numIdextern = "idexternRdv"; //$NON-NLS-1$
    String numintervention = "numintervention"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(IDEXTERNERDV, "idexternRdv")); //$NON-NLS-1$
    list.add(new Parameter(INSTALLATEUR, "PC30")); //$NON-NLS-1$
    list.add(new Parameter(NUMINTERVENTION, "numintervention")); //$NON-NLS-1$
    list.add(new Parameter(TYPEINTERVENTION, "SAV")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    request.setOperation(INFO_MUTATION_ACTION);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    AccesRI accesRi = __podam.manufacturePojoWithFullData(AccesRI.class);
    accesRi.setNumIntervention(numintervention);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);
    List<AccesRI> accesRI = new ArrayList<>(Arrays.asList(accesRi));
    mockOSSFAI_SI018(numIdextern, accesRI, RetourFactoryForTU.createOkRetour());
    createProcessManagerManagerMock();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    ReponseErreur reponserreur = new ReponseErreur();
    reponserreur.setError("DONNEE_INCONNUE"); //$NON-NLS-1$
    reponserreur.setErrorDescription("Aucun accès à l'état construit référencé associé  à l'id idexternRdv"); //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);

    ReponseErreur reponserreurExcpect = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);
    final Response expected = new Response(ErrorCode.KO_00404, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(reponserreur.getError(), reponserreurExcpect.getError());
    assertEquals(reponserreur.getErrorDescription(), reponserreurExcpect.getErrorDescription());
  }

  /**
   * PE0206_RessourcesEmutation_Nominal cas OK TyPeIntervention RACCO
   *
   * @throws Throwable
   *           exception
   */

  @Test
  public void PE0206_RessourcesEmutation_Nominal_OK_001() throws Throwable
  {

    String numIdextern = "idexternRdv"; //$NON-NLS-1$
    String numintervention = "numintervention"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(IDEXTERNERDV, "idexternRdv")); //$NON-NLS-1$
    list.add(new Parameter(INSTALLATEUR, "PC30")); //$NON-NLS-1$
    list.add(new Parameter(NUMINTERVENTION, "numintervention")); //$NON-NLS-1$
    list.add(new Parameter(TYPEINTERVENTION, "RACCO")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    request.setOperation(INFO_MUTATION_ACTION);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setNumIntervention(numintervention);
    accesRi.setEtatAcces(EtatAccesRI.ENCOURSCONSTRUCTION);

    ConfigFluxOI configflux = __podam.manufacturePojo(ConfigFluxOI.class);
    configflux.setDisponible(true);
    List<AccesRI> listeAccesRI = new ArrayList<>(Arrays.asList(accesRi));

    mockOSSFAI_SI018(numIdextern, listeAccesRI, RetourFactoryForTU.createOkRetour());
    mockParameterManager(configflux);
    createProcessManagerManagerMock();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    PE0206_Retour reponseExcpect = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), PE0206_Retour.class);
    final Response expected = new Response(ErrorCode.OK_00200, response);
    PE0206_Retour peiretour = generatePE0226(accesRi);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(peiretour.getOi(), reponseExcpect.getOi());
    assertEquals(peiretour.getDateDispo(), reponseExcpect.getDateDispo());
    assertEquals(peiretour.getPriseExisante(), reponseExcpect.getPriseExisante());
    assertEquals(peiretour.getReferencePM(), reponseExcpect.getReferencePM());
    assertEquals(peiretour.getRefPrestationPrise(), reponseExcpect.getRefPrestationPrise());
    assertEquals(peiretour.getTypeIntervention(), reponseExcpect.getTypeIntervention());
    assertEquals(peiretour.getComplementAdresse().getBatiment(), reponseExcpect.getComplementAdresse().getBatiment());
    assertEquals(peiretour.getComplementAdresse().getEscalier(), reponseExcpect.getComplementAdresse().getEscalier());
    assertEquals(peiretour.getComplementAdresse().getEtage(), reponseExcpect.getComplementAdresse().getEtage());
    assertEquals(peiretour.getAdresse().getCodePostal(), reponseExcpect.getAdresse().getCodePostal());
    assertEquals(peiretour.getAdresse().getCommune(), reponseExcpect.getAdresse().getCommune());
    assertEquals(peiretour.getAdresse().getComplementNumero(), reponseExcpect.getAdresse().getComplementNumero());
    assertEquals(peiretour.getAdresse().getLibelleVoie(), reponseExcpect.getAdresse().getLibelleVoie());
    assertEquals(peiretour.getAdresse().getNumeroVoie(), reponseExcpect.getAdresse().getNumeroVoie());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getAdresseLibre(), reponseExcpect.getAdresse().getReferencesAdresse().getAdresseLibre());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getHexacle(), reponseExcpect.getAdresse().getReferencesAdresse().getHexacle());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getIdentifiantImeuble(), reponseExcpect.getAdresse().getReferencesAdresse().getIdentifiantImeuble());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getRivoli().getCodeInsee(), reponseExcpect.getAdresse().getReferencesAdresse().getRivoli().getCodeInsee());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getRivoli().getCodeRivoli(), reponseExcpect.getAdresse().getReferencesAdresse().getRivoli().getCodeRivoli());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getRivoli().getComplementNumeroVoie(), reponseExcpect.getAdresse().getReferencesAdresse().getRivoli().getComplementNumeroVoie());
    assertEquals(peiretour.getListeRouteOptique().size(), accesRi.getListeRouteOptique().getRouteOptiques().size());

  }

  /**
   * PE0206_RessourcesEmutation_Nominal cas OK TyPeIntervention not RACCO here (SAV)
   *
   * @throws Throwable
   *           exception
   */

  @Test
  public void PE0206_RessourcesEmutation_Nominal_OK_002() throws Throwable
  {

    String numIdextern = "idexternRdv"; //$NON-NLS-1$
    String numintervention = "numintervention"; //$NON-NLS-1$
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(IDEXTERNERDV, "idexternRdv")); //$NON-NLS-1$
    list.add(new Parameter(INSTALLATEUR, "PC30")); //$NON-NLS-1$
    list.add(new Parameter(NUMINTERVENTION, "numintervention")); //$NON-NLS-1$
    list.add(new Parameter(TYPEINTERVENTION, "SAV")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    request.setOperation(INFO_MUTATION_ACTION);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    ConfigFluxOI configflux = __podam.manufacturePojo(ConfigFluxOI.class);
    configflux.setDisponible(true);

    AccesRI accesRi = __podam.manufacturePojo(AccesRI.class);
    accesRi.setNumIntervention(numintervention);
    accesRi.setEtatAcces(EtatAccesRI.CONSTRUIT);
    List<AccesRI> accesRI = new ArrayList<>(Arrays.asList(accesRi));

    mockOSSFAI_SI018(numIdextern, accesRI, RetourFactoryForTU.createOkRetour());
    mockParameterManager(configflux);
    createProcessManagerManagerMock();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    PE0206_Retour reponseExcpect = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), PE0206_Retour.class);
    final Response expected = new Response(ErrorCode.OK_00200, response);
    PE0206_Retour peiretour = generatePE0226(accesRi);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(peiretour.getOi(), reponseExcpect.getOi());
    assertEquals(peiretour.getDateDispo(), reponseExcpect.getDateDispo());
    assertEquals(peiretour.getPriseExisante(), reponseExcpect.getPriseExisante());
    assertEquals(peiretour.getReferencePM(), reponseExcpect.getReferencePM());
    assertEquals(peiretour.getRefPrestationPrise(), reponseExcpect.getRefPrestationPrise());
    assertEquals(peiretour.getTypeIntervention(), reponseExcpect.getTypeIntervention());
    assertEquals(peiretour.getComplementAdresse().getBatiment(), reponseExcpect.getComplementAdresse().getBatiment());
    assertEquals(peiretour.getComplementAdresse().getEscalier(), reponseExcpect.getComplementAdresse().getEscalier());
    assertEquals(peiretour.getComplementAdresse().getEtage(), reponseExcpect.getComplementAdresse().getEtage());
    assertEquals(peiretour.getAdresse().getCodePostal(), reponseExcpect.getAdresse().getCodePostal());
    assertEquals(peiretour.getAdresse().getCommune(), reponseExcpect.getAdresse().getCommune());
    assertEquals(peiretour.getAdresse().getComplementNumero(), reponseExcpect.getAdresse().getComplementNumero());
    assertEquals(peiretour.getAdresse().getLibelleVoie(), reponseExcpect.getAdresse().getLibelleVoie());
    assertEquals(peiretour.getAdresse().getNumeroVoie(), reponseExcpect.getAdresse().getNumeroVoie());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getAdresseLibre(), reponseExcpect.getAdresse().getReferencesAdresse().getAdresseLibre());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getHexacle(), reponseExcpect.getAdresse().getReferencesAdresse().getHexacle());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getIdentifiantImeuble(), reponseExcpect.getAdresse().getReferencesAdresse().getIdentifiantImeuble());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getRivoli().getCodeInsee(), reponseExcpect.getAdresse().getReferencesAdresse().getRivoli().getCodeInsee());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getRivoli().getCodeRivoli(), reponseExcpect.getAdresse().getReferencesAdresse().getRivoli().getCodeRivoli());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getRivoli().getComplementNumeroVoie(), reponseExcpect.getAdresse().getReferencesAdresse().getRivoli().getComplementNumeroVoie());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getHexacleVoie().getCodeHexacleVoie(), reponseExcpect.getAdresse().getReferencesAdresse().getHexacleVoie().getCodeHexacleVoie());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getHexacleVoie().getComplementNumeroVoie(), reponseExcpect.getAdresse().getReferencesAdresse().getHexacleVoie().getComplementNumeroVoie());
    assertEquals(peiretour.getAdresse().getReferencesAdresse().getHexacleVoie().getNumeroVoie(), reponseExcpect.getAdresse().getReferencesAdresse().getHexacleVoie().getNumeroVoie());

  }

  /**
   * Retour KO (CAT4/FLUX_BIENTOT_DISPONIBLE)
   *
   * @throws Throwable
   */
  @Test
  public void PE0206_RessourcesEmutation_Nominal_OK_003() throws Throwable
  {
    String numIdextern = "idexternRdv"; //$NON-NLS-1$
    String numintervention = "numintervention"; //$NON-NLS-1$
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    fillRequestHeaders(request, xProcess, xClientOperateur, xSource, xRequestId);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(IDEXTERNERDV, "idexternRdv")); //$NON-NLS-1$
    list.add(new Parameter(INSTALLATEUR, "PC30")); //$NON-NLS-1$
    list.add(new Parameter(NUMINTERVENTION, "numintervention")); //$NON-NLS-1$
    list.add(new Parameter(TYPEINTERVENTION, "RACCO")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    request.setOperation(INFO_MUTATION_ACTION);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    AccesRI accesRi = __podam.manufacturePojoWithFullData(AccesRI.class);
    accesRi.setNumIntervention(numintervention);
    accesRi.setEtatAcces(EtatAccesRI.CONSTRUIT);

    List<AccesRI> accesRI = new ArrayList<>(Arrays.asList(accesRi));

    ConfigFluxOI configflux = __podam.manufacturePojo(ConfigFluxOI.class);
    configflux.setDisponible(false);
    configflux.setDateDispo(null);

    mockOSSFAI_SI018(numIdextern, accesRI, RetourFactoryForTU.createOkRetour());
    mockParameterManager(configflux);
    createProcessManagerManagerMock();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    PE0206_Retour reponseExcpect = GsonTools.getIso8601Ms().fromJson(request.getResponse().getGenericResponse().getResult(), PE0206_Retour.class);
    final Response expected = new Response(ErrorCode.OK_00200, response);
    PE0206_Retour peiretour = new PE0206_Retour();
    peiretour.setOi(accesRi.getCodeOI());
    peiretour.setMutationPossible(false);

    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(peiretour.getOi(), reponseExcpect.getOi());
    assertEquals(peiretour.getDateDispo(), reponseExcpect.getDateDispo());
    assertEquals(peiretour.isMutationPossible(), reponseExcpect.isMutationPossible());

  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * @param connector_p
   *          connector
   * @param tracabilite_p
   *          tracabilite
   * @param idServiceClient_p
   *          idservice
   * @throws RavelException
   *           ravelexception
   */
  private void createPadawanConnector(ConnectorResponse<RecupererInfosAccesResponse, Retour> connector_p, Tracabilite tracabilite_p, String idServiceClient_p) throws RavelException
  {

    EasyMock.expect(PadawanFTTHConnectorProxy.getInstance()).andReturn(_padawnFtthProxy);
    EasyMock.expect(_padawnFtthProxy.recupererInfosAccesFTTH(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idServiceClient_p))).andReturn(connector_p);
  }

  /**
   * Create ProcessManager mock
   *
   * @param processParams
   *          Process parameters
   */
  private void createProcessManagerManagerMock()
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    processParams.put("", new HashMap<String, String>()); //$NON-NLS-1$
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_pmMock).anyTimes();
    EasyMock.expect(_pmMock.getProcessParams()).andReturn(processParams).anyTimes();

  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * generatePE0226
   *
   * @param accesRi_p
   *          accesRI
   * @return PE0206_Retour
   */
  private PE0206_Retour generatePE0226(AccesRI accesRi_p)
  {
    PE0206_Adresse adresse = null;
    PE0206_ComplementAdresse complementAdresse = null;
    PE0206_Retour pe206 = new PE0206_Retour();
    pe206.setOi(accesRi_p.getCodeOI());
    pe206.setMutationPossible(true);
    pe206.setRefPrestationPrise(accesRi_p.getReferencePrestationPrise());
    AdresseRI adresseri = accesRi_p.getAdresse();
    if (adresseri != null)
    {
      adresse = new PE0206_Adresse();
      adresse.setCodePostal(adresseri.getCodePostal());
      adresse.setCommune(adresseri.getCommune());
      Integer num = adresseri.getNumeroVoie();
      adresse.setLibelleVoie(adresseri.getLibelleVoie());
      adresse.setNumeroVoie(num.toString());
      adresse.setComplementNumero(adresseri.getComplementNumeroVoie());
      if (adresseri.getReferencesAdresse() != null)
      {
        PE0206_ReferenceAdresse reference = new PE0206_ReferenceAdresse();
        ReferenceAdresseRI referAdressRi = adresseri.getReferencesAdresse();
        reference.setHexacle(referAdressRi.getHexacle());
        PE0206_HexacleVoie hexaclevoie = new PE0206_HexacleVoie();
        hexaclevoie.setCodeHexacleVoie(referAdressRi.getHexacle());
        QuadrupletRivoliRI quadruprivoliRI = referAdressRi.getRivoli();
        if (quadruprivoliRI != null)
        {
          PE0206_QuadrupletRivoli quadruprivoli = new PE0206_QuadrupletRivoli();
          quadruprivoli.setCodeInsee(quadruprivoliRI.getCodeInsee());
          quadruprivoli.setCodeRivoli(quadruprivoliRI.getCodeRivoli());
          quadruprivoli.setComplementNumeroVoie(quadruprivoliRI.getComplementNumeroVoie());
          quadruprivoli.setNumeroVoie(quadruprivoliRI.getNumeroVoie());
          reference.setRivoli(quadruprivoli);
          hexaclevoie.setNumeroVoie(quadruprivoliRI.getNumeroVoie());
          hexaclevoie.setComplementNumeroVoie(quadruprivoliRI.getComplementNumeroVoie());

        }
        reference.setHexacleVoie(hexaclevoie);
        adresse.setReferencesAdresse(reference);
      }
      complementAdresse = new PE0206_ComplementAdresse();
      complementAdresse.setBatiment(adresseri.getBatiment());
      complementAdresse.setEscalier(adresseri.getEscalier());
      complementAdresse.setEtage(adresseri.getEtage());
    }

    List<PE0206_RouteOptique> listroutOptique = null;
    ListeRouteOptique listRouteOptique = accesRi_p.getListeRouteOptique();
    if (listRouteOptique != null)
    {
      List<RouteOptiqueRI> listroute = listRouteOptique.getRouteOptiques();
      listroutOptique = new ArrayList<>();
      for (RouteOptiqueRI routeOptique : listroute)
      {
        PE0206_PositionPMType positonPMType = new PE0206_PositionPMType();
        positonPMType.setInfoFibreModulePM(routeOptique.getInformationFibrePM());
        positonPMType.setInfoTubeModulePM(routeOptique.getInformationTubePM());
        positonPMType.setNomModulePM(routeOptique.getNomModulePM());
        positonPMType.setPositionModulePM(routeOptique.getPositionModulePM());
        positonPMType.setReferenceCableModulePM(routeOptique.getReferenceCablePM());
        Fibre fibre = new Fibre(StringConstants.EMPTY_STRING, routeOptique.getReferenceCablePBO(), routeOptique.getInformationTubePBO(), routeOptique.getInformationFibrePBO(), StringConstants.EMPTY_STRING, accesRi_p.getReferencePrise());
        PE0206_RouteOptique peirouteOptique = new PE0206_RouteOptique();
        peirouteOptique.setConnecteurPriseCouleur(routeOptique.getCouleurPriseConnecteur());
        peirouteOptique.setConnecteurPriseNumero(routeOptique.getNumPriseConnecteur());
        peirouteOptique.setOc(routeOptique.getCodeOC());
        peirouteOptique.setFibre(fibre);
        peirouteOptique.setPositionPM(positonPMType);
        listroutOptique.add(peirouteOptique);
      }
    }

    pe206.setListeRouteOptique(listroutOptique);
    pe206.setAdresse(adresse);
    pe206.setComplementAdresse(complementAdresse);
    pe206.setReferencePM(accesRi_p.getReferencePM());
    pe206.setReferencePBO(accesRi_p.getReferencePBO());
    pe206.setPriseExisante(accesRi_p.isPrisePosee());

    return pe206;
  }

  /**
   * @param oi_p
   *          the oi
   * @param refPrestationprise_p
   *          the refPrestationprise
   * @param retour_p
   *          the retour
   * @param pbos_p
   *          the pbos
   * @throws Exception
   *           in case of error
   */
  private void mockOSSFAI_SI018(String idServiceClient_p, List<AccesRI> listAcces_p, Retour retour_p) throws Exception
  {
    PowerMock.expectNew(OSSFAI_SI018_RecupererInfosAccesFTTHBuilder.class).andReturn(_si018BuilderMock);
    EasyMock.expect(_si018BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_si018BuilderMock);
    EasyMock.expect(_si018BuilderMock.idServiceClient(idServiceClient_p)).andReturn(_si018BuilderMock);
    EasyMock.expect(_si018BuilderMock.build()).andReturn(_si018Mock);
    EasyMock.expect(_si018Mock.execute(_processInstance)).andReturn(listAcces_p);
    EasyMock.expect(_si018Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * createParamManager
   *
   * @param configx_p
   *          config
   */
  private void mockParameterManager(ConfigFluxOI configx_p)
  {
    EasyMock.expect(ParameterManager.getInstance()).andReturn(_paramManag);
    EasyMock.expect(_paramManag.findOne(EasyMock.anyObject(String.class), EasyMock.anyObject(ConfigFluxOIFilter.class))).andReturn(configx_p);

  }

}
