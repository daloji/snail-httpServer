/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0215;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentMap;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail.BL3700_RecupererPfiParMailBuilder;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective.BL5100_CreerActionCorrectiveBuilder;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechnique;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionServiceTechniqueMail;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.TypeAction;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesIdentificationSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesProvisionneesSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.TypeServiceMail;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.processes.SpiritProcessSkeleton;
import com.bytel.spirit.common.shared.misc.ressources.Consts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.TypeObjetCommercial;
import com.bytel.spirit.common.shared.saab.cmd.StatutCommercialAttendu;
import com.bytel.spirit.common.shared.saab.rpg.PA;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAcces;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeCompteAccesSecondaire;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.TypePA;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail.PE0215_BL001Return;
import com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail.PE0215_BL100Return;
import com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail.PE0215_BL200Return;
import com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail.PE0215_BL201Return;
import com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail.PE0215_BL300Return;
import com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail.PE0215_BL301Return;
import com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail.PE0215_BL400Return;
import com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail.PE0215_DiagnosticServiceMailContext;
import com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail.SourceDonne;
import com.bytel.spirit.fiat.shared.types.json.Audit;
import com.bytel.spirit.fiat.shared.types.json.Audit.Diagnostic;
import com.bytel.spirit.fiat.shared.types.json.Erreur;
import com.bytel.spirit.fiat.shared.types.json.Erreur.TypeError;
import com.bytel.spirit.fiat.shared.types.json.PFS;
import com.bytel.spirit.fiat.shared.types.json.PFS.TypePfs;
import com.bytel.spirit.fiat.shared.types.json.Referentiel;
import com.bytel.spirit.fiat.shared.types.json.Referentiel.EtatProvisioning;
import com.bytel.spirit.fiat.shared.types.json.Ressource;
import com.bytel.spirit.fiat.shared.types.json.Ressource.EtatAllocation;
import com.bytel.spirit.fiat.shared.types.json.Ressource.EtatRessource;
import com.bytel.spirit.fiat.shared.types.json.Ressource.TypeRessource;
import com.bytel.spirit.fiat.shared.types.json.response.ReponseFonctionnellePI0150C;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jjoly
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0215_DiagnosticServiceMail.class, ReponseFonctionnellePI0150C.class, BL3700_RecupererPfiParMail.class, BL3700_RecupererPfiParMailBuilder.class, BL5100_CreerActionCorrective.class, BL5100_CreerActionCorrectiveBuilder.class, PROV_SI002_ExecuterProcessus.class, PROV_SI002_ExecuterProcessusBuilder.class, RPGProxy.class, RSTProxy.class })
public final class PE0215_DiagnosticServiceMailTest
{
  /**
   *
   */
  private static final String PEI0229_URI = "/actions-correctives"; //$NON-NLS-1$
  /**
   *
   */
  private static final String REQUEST_ID = "some-id"; //$NON-NLS-1$

  /**
   * bean Factory generation
   */
  private static PodamFactory __podam;

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * Mock de {@Code PROV_SI002_ExecuterProcessus}
   */
  @MockStrict
  protected PROV_SI002_ExecuterProcessus _provSI002Mock;

  /**
   * Mock de {@Code BL3700_RecupererPfiParMail}
   */
  @MockStrict
  protected BL3700_RecupererPfiParMail _bl3700Mock;

  /**
   * Mock de {@Code BL5100_CreerActionCorrective}
   */
  @MockStrict
  protected BL5100_CreerActionCorrective _bl5100Mock;

  /**
   * Mock de {@Code ResponseConnector}
   */
  @MockStrict
  protected ResponseConnector _responseConnectorMock;

  /**
   * Mock de {@Code ReponseFonctionnellePI0150C}
   */
  @MockStrict
  protected ReponseFonctionnellePI0150C _reponseFonctionnellePI0150CMock;

  /**
   * Mock de {@Code RPGProxy}
   */
  @MockStrict
  protected RPGProxy _rpgMock;

  /**
   * Mock de {@Code RSTProxy}
   */
  @MockStrict
  protected RSTProxy _rstMock;

  /**
   * Mock de {@link SpiritProcessSkeleton}
   */
  @MockNice
  private SpiritProcessSkeleton _activityCallerMock;

  /**
   * The mock object {@code PE0215_DiagnosticServiceMailContext}
   */
  @MockStrict
  private PE0215_DiagnosticServiceMailContext _contextMock;

  /**
   * Instance to evaluate
   */
  @MockNice("getConfigParameter")
  private PE0215_DiagnosticServiceMail _instance;

  /**
   * Exception has been thrown
   */
  private boolean _exception;

  /**
   * Tracabilite
   */
  Tracabilite _tracabilite;

  /**
   *
   * @throws Exception
   *           On errors Thrown in case of error during switch in attributes of parent class
   */
  @Before
  public void setUp() throws Exception
  {
    _exception = false;
    _instance = new PE0215_DiagnosticServiceMail();
    _instance.initializeContext();
    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Whitebox.setInternalState(_instance, "_tracabilite", Tracabilite.class.cast(null)); //$NON-NLS-1$

    PowerMock.resetAll();

    PowerMock.mockStaticStrict(RPGProxy.class);
    PowerMock.mockStaticStrict(RSTProxy.class);
  }

  /**
   * Method that does the needed clean up.<br/>
   *
   * <b>Entrées:</b> N/A for this test method. <br/>
   * <b>Attendu:</b> Clean up of some of our data.
   *
   */
  @After
  public void tearDown()
  {
    _instance = null;
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> Not headers & no parameters <br/>
   * <b>Attendu:</b> Error NOK, CAT-3, NON_RESPECT_STI <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_001() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): X-Client-Operateur, Attribut(s) obligatoire(s) manquant(s): X-Source, Attribut(s) obligatoire(s) manquant(s): X-Process, Attribut(s) obligatoire(s) manquant(s): X-Request-Id")); //$NON-NLS-1$

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();
      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour().getCategorie(), actual.getRetour().getCategorie());
      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
      assertEquals(expected.getRetour().getDiagnostic(), actual.getRetour().getDiagnostic());
    }
  }

  /**
   * /** Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> Only header "X-Client-Operateur" is set & no parameters <br/>
   * <b>Attendu:</b> Error NOK, CAT-3, NON_RESPECT_STI <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_002() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): X-Source, Attribut(s) obligatoire(s) manquant(s): X-Process, Attribut(s) obligatoire(s) manquant(s): X-Request-Id")); //$NON-NLS-1$

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur));

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour().getCategorie(), actual.getRetour().getCategorie());
      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
      assertEquals(expected.getRetour().getDiagnostic(), actual.getRetour().getDiagnostic());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> Only header "X-Client-Operateur" and "Source" are set & no parameters <br/>
   * <b>Attendu:</b> Error NOK, CAT-3, NON_RESPECT_STI <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_003() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): X-Process, Attribut(s) obligatoire(s) manquant(s): X-Request-Id")); //$NON-NLS-1$

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource));

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour().getCategorie(), actual.getRetour().getCategorie());
      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
      assertEquals(expected.getRetour().getDiagnostic(), actual.getRetour().getDiagnostic());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> All headers are set & no parameters <br/>
   * <b>Attendu:</b> Error NOK, CAT-3, NON_RESPECT_STI <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_004() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): X-Request-Id")); //$NON-NLS-1$

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xProcess = new RequestHeader();
    xProcess.setName(IHttpHeadersConsts.X_PROCESS);
    xProcess.setValue(__podam.manufacturePojo(String.class));

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource, xProcess));

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour().getCategorie(), actual.getRetour().getCategorie());
      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
      assertEquals(expected.getRetour().getDiagnostic(), actual.getRetour().getDiagnostic());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> All headers are set & no parameters <br/>
   * <b>Attendu:</b> Error NOK, CAT-3, NON_RESPECT_STI <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_005() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0215.BL001.MandatoryError"))); //$NON-NLS-1$

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xProcess = new RequestHeader();
    xProcess.setName(IHttpHeadersConsts.X_PROCESS);
    xProcess.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
    xRequestId.setValue(__podam.manufacturePojo(String.class));

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource, xProcess));

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour().getCategorie(), actual.getRetour().getCategorie());
      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
      assertEquals(expected.getRetour().getDiagnostic(), actual.getRetour().getDiagnostic());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> All headers are set & only parameters "audit" is set <br/>
   * <b>Attendu:</b> Error NOK, CAT-3, NON_RESPECT_STI <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_006() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setAudit(__podam.manufacturePojo(Boolean.class));
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0215.BL001.MandatoryError"))); //$NON-NLS-1$

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xProcess = new RequestHeader();
    xProcess.setName(IHttpHeadersConsts.X_PROCESS);
    xProcess.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
    xRequestId.setValue(__podam.manufacturePojo(String.class));

    UrlParameters urlParameters = new UrlParameters();
    List<Parameter> urlParams = urlParameters.getUrlParameters();
    urlParams.add(new Parameter("audit", expected.getAudit().toString()));

    urlParameters.setUrlParameters(urlParams);

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource, xProcess, xRequestId));
    request.setUrlParameters(urlParameters);

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour().getCategorie(), actual.getRetour().getCategorie());
      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
      assertEquals(expected.getRetour().getDiagnostic(), actual.getRetour().getDiagnostic());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> All headers are set & only parameters "audit" is correctly set, but "sourceDonnee" not <br/>
   * <b>Attendu:</b> Error NOK, CAT-3, NON_RESPECT_STI <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_007() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setSourceDonnee(EnumSet.noneOf(SourceDonne.class));
    expected.setAudit(true);
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0215.BL001.MandatoryError"))); //$NON-NLS-1$

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xProcess = new RequestHeader();
    xProcess.setName(IHttpHeadersConsts.X_PROCESS);
    xProcess.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
    xRequestId.setValue(__podam.manufacturePojo(String.class));

    UrlParameters urlParameters = new UrlParameters();
    List<Parameter> urlParams = urlParameters.getUrlParameters();
    urlParams.add(new Parameter("audit", expected.getAudit().toString()));

    urlParameters.setUrlParameters(urlParams);

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource, xProcess, xRequestId));
    request.setUrlParameters(urlParameters);

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();
      assertEquals(expected.getRetour().getCategorie(), actual.getRetour().getCategorie());
      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
      assertEquals(expected.getRetour().getDiagnostic(), actual.getRetour().getDiagnostic());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> All headers are set & only parameters "audit" is correctly set, "sourceDonnee" is set to PFS only
   * but "loginMail" is wrongly set <br/>
   * <b>Attendu:</b> Error NOK, CAT-3, NON_RESPECT_STI <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_008() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setLoginMail(__podam.manufacturePojo(String.class));

    EnumSet<SourceDonne> setSD = EnumSet.noneOf(SourceDonne.class);
    setSD.add(SourceDonne.PFS);
    expected.setSourceDonnee(setSD);

    expected.setAudit(true);
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0215.BL001.MandatoryError"))); //$NON-NLS-1$

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xProcess = new RequestHeader();
    xProcess.setName(IHttpHeadersConsts.X_PROCESS);
    xProcess.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
    xRequestId.setValue(__podam.manufacturePojo(String.class));

    UrlParameters urlParameters = new UrlParameters();
    List<Parameter> urlParams = urlParameters.getUrlParameters();
    urlParams.add(new Parameter("loginMail", expected.getLoginMail()));
    urlParams.add(new Parameter("sourceDonnee", expected.getSourceDonnee().toString()));
    urlParams.add(new Parameter("audit", expected.getAudit().toString()));

    urlParameters.setUrlParameters(urlParams);

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource, xProcess, xRequestId));
    request.setUrlParameters(urlParameters);

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour().getCategorie(), actual.getRetour().getCategorie());
      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
      assertEquals(expected.getRetour().getDiagnostic(), actual.getRetour().getDiagnostic());
    }
  }

  /**
   * nn Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> All headers are set & only parameters "audit" is correctly set, "sourceDonnee" is set to PFS only
   * and "loginMail" is correctly set <br/>
   * <b>Attendu:</b> NOK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_009() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setLoginMail(__podam.manufacturePojo(String.class));
    EnumSet<SourceDonne> setSD = EnumSet.noneOf(SourceDonne.class);
    setSD.add(SourceDonne.PFS);
    expected.setSourceDonnee(setSD);

    expected.setAudit(false);
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0215.BL001.MandatoryError"))); //$NON-NLS-1$

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xProcess = new RequestHeader();
    xProcess.setName(IHttpHeadersConsts.X_PROCESS);
    xProcess.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
    xRequestId.setValue(__podam.manufacturePojo(String.class));

    final Pair<String, String> loginMail = new Pair<>("loginMail", expected.getLoginMail()); //$NON-NLS-1$
    final Pair<String, String> sourceDonnee = new Pair<>("sourceDonnee", expected.getSourceDonnee().toString()); //$NON-NLS-1$
    final Pair<String, String> audit = new Pair<>("audit", expected.getAudit().toString()); //$NON-NLS-1$

    UrlParameters urlParameters = new UrlParameters();
    List<Parameter> urlParams = urlParameters.getUrlParameters();
    urlParams.add(new Parameter("loginMail", expected.getLoginMail()));
    urlParams.add(new Parameter("sourceDonnee", expected.getSourceDonnee().toString()));
    urlParams.add(new Parameter("audit", expected.getAudit().toString()));

    urlParameters.setUrlParameters(urlParams);

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource, xProcess, xRequestId));
    request.setUrlParameters(urlParameters);

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();
      assertEquals(expected.getRetour().getCategorie(), actual.getRetour().getCategorie());
      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
      assertEquals(expected.getRetour().getDiagnostic(), actual.getRetour().getDiagnostic());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> All headers are set & only parameters "audit" is correctly set, "sourceDonnee" is set to
   * REFERENTIEL only and loginMail is correctly set <br/>
   * <b>Attendu:</b> NOK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_010() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setIdentifiantFonctionnelPa(__podam.manufacturePojo(String.class));
    expected.setNoCompte(__podam.manufacturePojo(String.class));
    EnumSet<SourceDonne> setSD = EnumSet.noneOf(SourceDonne.class);
    setSD.add(SourceDonne.REFERENTIEL);
    expected.setSourceDonnee(setSD);
    expected.setAudit(false);
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0215.BL001.MandatoryError"))); //$NON-NLS-1$

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xProcess = new RequestHeader();
    xProcess.setName(IHttpHeadersConsts.X_PROCESS);
    xProcess.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
    xRequestId.setValue(__podam.manufacturePojo(String.class));

    UrlParameters urlParameters = new UrlParameters();
    List<Parameter> urlParams = urlParameters.getUrlParameters();
    urlParams.add(new Parameter("idFonctionnelPa", expected.getIdentifiantFonctionnelPa()));
    urlParams.add(new Parameter("noCompte", expected.getNoCompte()));
    urlParams.add(new Parameter("sourceDonnee", expected.getSourceDonnee().toString()));
    urlParams.add(new Parameter("audit", expected.getAudit().toString()));
    urlParameters.setUrlParameters(urlParams);

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource, xProcess, xRequestId));
    request.setUrlParameters(urlParameters);

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour().getCategorie(), actual.getRetour().getCategorie());
      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
      assertEquals(expected.getRetour().getDiagnostic(), actual.getRetour().getDiagnostic());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> All headers are set & only parameters "loginmail" is not set, "sourceDonnee" is set to
   * REFERENTIEL,PFS, "noCompte" and "idFonctionnelPa" are set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_011() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setIdentifiantFonctionnelPa(__podam.manufacturePojo(String.class));
    expected.setNoCompte(__podam.manufacturePojo(String.class));
    EnumSet<SourceDonne> setSD = EnumSet.allOf(SourceDonne.class);
    expected.setSourceDonnee(setSD);

    expected.setAudit(false);
    expected.setRetour(RetourFactoryForTU.createOkRetour());
    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xProcess = new RequestHeader();
    xProcess.setName(IHttpHeadersConsts.X_PROCESS);
    xProcess.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
    xRequestId.setValue(__podam.manufacturePojo(String.class));

    final Pair<String, String> idFonctionnelPa = new Pair<>("idFonctionnelPa", expected.getIdentifiantFonctionnelPa()); //$NON-NLS-1$
    final Pair<String, String> noCompte = new Pair<>("noCompte", expected.getNoCompte()); //$NON-NLS-1$
    final Pair<String, String> sourceDonnee = new Pair<>("sourceDonnee", "REFERENTIEL,PFS"); //$NON-NLS-1$ //$NON-NLS-2$
    final Pair<String, String> audit = new Pair<>("audit", expected.getAudit().toString()); //$NON-NLS-1$

    UrlParameters urlParameters = new UrlParameters();
    List<Parameter> urlParams = urlParameters.getUrlParameters();
    urlParams.add(new Parameter("idFonctionnelPa", expected.getIdentifiantFonctionnelPa()));
    urlParams.add(new Parameter("noCompte", expected.getNoCompte()));
    urlParams.add(new Parameter("sourceDonnee", "REFERENTIEL,PFS"));
    urlParams.add(new Parameter("audit", expected.getAudit().toString()));
    urlParameters.setUrlParameters(urlParams);

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource, xProcess, xRequestId));
    request.setUrlParameters(urlParameters);

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> All headers are set & parameters "sourceDonnee" is set to PFS,REFERENTIEL, "audit", "noCompte" and
   * "idFonctionnelPa" are set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_012() throws Exception
  {
    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setIdentifiantFonctionnelPa(__podam.manufacturePojo(String.class));
    expected.setNoCompte(__podam.manufacturePojo(String.class));
    EnumSet<SourceDonne> setSD = EnumSet.allOf(SourceDonne.class);

    expected.setSourceDonnee(setSD);
    expected.setAudit(false);
    expected.setRetour(RetourFactoryForTU.createOkRetour());

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xProcess = new RequestHeader();
    xProcess.setName(IHttpHeadersConsts.X_PROCESS);
    xProcess.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName(IHttpHeadersConsts.X_REQUEST_ID);
    xRequestId.setValue(__podam.manufacturePojo(String.class));

    final Pair<String, String> idFonctionnelPa = new Pair<>("idFonctionnelPa", expected.getIdentifiantFonctionnelPa()); //$NON-NLS-1$
    final Pair<String, String> noCompte = new Pair<>("noCompte", expected.getNoCompte()); //$NON-NLS-1$
    final Pair<String, String> sourceDonnee = new Pair<>("sourceDonnee", "REFERENTIEL,PFS"); //$NON-NLS-1$ //$NON-NLS-2$
    final Pair<String, String> audit = new Pair<>("audit", expected.getAudit().toString()); //$NON-NLS-1$

    UrlParameters urlParameters = new UrlParameters();
    List<Parameter> urlParams = urlParameters.getUrlParameters();
    urlParams.add(new Parameter("idFonctionnelPa", expected.getIdentifiantFonctionnelPa()));
    urlParams.add(new Parameter("noCompte", expected.getNoCompte()));
    urlParams.add(new Parameter("sourceDonnee", "REFERENTIEL,PFS"));
    urlParams.add(new Parameter("audit", expected.getAudit().toString()));
    urlParameters.setUrlParameters(urlParams);

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource, xProcess, xRequestId));
    request.setUrlParameters(urlParameters);

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour().getResultat(), actual.getRetour().getResultat());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL001_VerifierDonnees}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to PFS,REFERENTIEL
   * and "loginMail" are set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL001_VerifierDonnees_013() throws Exception
  {

    final PE0215_BL001Return expected = new PE0215_BL001Return(null);
    expected.setClientOperateur(__podam.manufacturePojo(String.class));
    expected.setIdentifiantFonctionnelPa(__podam.manufacturePojo(String.class));
    expected.setLoginMail("teste.mailxxxx"); //$NON-NLS-1$

    EnumSet<SourceDonne> setSD = EnumSet.allOf(SourceDonne.class);

    expected.setSourceDonnee(setSD);

    expected.setAudit(false);
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("Validation.RequiredField"), IHttpHeadersConsts.X_REQUEST_ID))); //$NON-NLS-1$

    final RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    xClientOperateur.setValue(expected.getClientOperateur());

    final RequestHeader xSource = new RequestHeader();
    xSource.setName(IHttpHeadersConsts.X_SOURCE);
    xSource.setValue(__podam.manufacturePojo(String.class));

    final RequestHeader xProcess = new RequestHeader();
    xProcess.setName(IHttpHeadersConsts.X_PROCESS);
    xProcess.setValue(__podam.manufacturePojo(String.class));

    UrlParameters urlParameters = new UrlParameters();
    List<Parameter> urlParams = urlParameters.getUrlParameters();
    urlParams.add(new Parameter("loginMail", expected.getLoginMail()));
    urlParams.add(new Parameter("sourceDonnee", "PFS,REFERENTIEL"));
    urlParams.add(new Parameter("audit", expected.getAudit().toString()));
    urlParams.add(new Parameter("idFonctionnelPa", "id"));
    urlParams.add(new Parameter("noCompte", "noCompte"));
    urlParameters.setUrlParameters(urlParams);

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.getRequestHeader().addAll(Arrays.asList(xClientOperateur, xSource, xProcess));
    request.setUrlParameters(urlParameters);

    PE0215_BL001Return actual = new PE0215_BL001Return(RetourFactoryForTU.createOkRetour());

    try
    {
      final BL3700_RecupererPfiParMailBuilder builder = new BL3700_RecupererPfiParMailBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _bl3700Mock); //$NON-NLS-1$
      PowerMock.expectNew(BL3700_RecupererPfiParMailBuilder.class).andReturn(builder).once();
      _bl3700Mock.setTracabilite(_tracabilite);
      EasyMock.expectLastCall().once();
      _bl3700Mock.setMail(expected.getLoginMail());
      EasyMock.expectLastCall().once();

      EasyMock.expect(_bl3700Mock.getTracabilite()).andReturn(_tracabilite).once();
      EasyMock.expect(_bl3700Mock.getMail()).andReturn(expected.getLoginMail()).once();

      EasyMock.expect(_bl3700Mock.execute(EasyMock.anyObject(PE0215_DiagnosticServiceMail.class))).andReturn(null).once();
      EasyMock.expect(_bl3700Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "!Validation.RequiredField!")).times(3);//$NON-NLS-1$

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All parameters are set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_001() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = __podam.manufacturePojo(String.class);
    final String loginMail = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$

    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.PFS);

    final List<String> listLoginMail = new ArrayList<>();
    listLoginMail.add(loginMail);

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createOkRetour());

    PE0215_BL100Return actual = null;

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_002() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = __podam.manufacturePojo(String.class);
    final String loginMail = null;
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);
    final List<String> listLoginMail = new ArrayList<>();

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_COMPTE_INCONNU, MessageFormat.format(Messages.getString("PE0215.BL100.noCompteIconnu"), noCompte))); //$NON-NLS-1$

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, null), null)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_003() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = __podam.manufacturePojo(String.class);
    final String loginMail = null;
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);
    final List<String> listLoginMail = new ArrayList<>();

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, null));

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, null), null)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_004() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = __podam.manufacturePojo(String.class);
    final String loginMail = null;
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);
    final List<String> listLoginMail = new ArrayList<>();
    final PFI pfi = __podam.manufacturePojo(PFI.class); // manufacturePojoWithFullData

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ID_PA_INCONNU, Messages.getString("PE0215.BL100.noPAactif"))); //$NON-NLS-1$

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pfi)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_005() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = __podam.manufacturePojo(String.class);
    final String loginMail = null;
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);
    final List<String> listLoginMail = new ArrayList<>();
    final PA pa = new PA(null, TypePA.COMPTE_ACCES.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(new PaTypeCompteAcces(__podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"))); //$NON-NLS-1$
    final List<PA> listPA = new ArrayList<>();
    listPA.add(pa);
    final PFI pfi = new PFI();
    pfi.setPa(listPA);

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ID_PA_INCONNU, MessageFormat.format(Messages.getString("PE0215.BL100.idPAIconnu"), identifiantFonctionnelPa))); //$NON-NLS-1$

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pfi)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_006() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = __podam.manufacturePojo(String.class);
    final String loginMail = null;
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);

    final List<String> listLoginMail = new ArrayList<>();
    listLoginMail.add(__podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr")); //$NON-NLS-1$
    final PA pa = new PA(identifiantFonctionnelPa, TypePA.COMPTE_ACCES.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(new PaTypeCompteAcces(listLoginMail.get(0)));
    final List<PA> listPA = new ArrayList<>();
    listPA.add(pa);
    final PFI pfi = new PFI();
    pfi.setPa(listPA);

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createOkRetour());

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pfi)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_007() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = __podam.manufacturePojo(String.class);
    final String loginMail = null;
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);

    final List<String> listLoginMail = new ArrayList<>();
    listLoginMail.add(__podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr")); //$NON-NLS-1$
    final PA pa = new PA(identifiantFonctionnelPa, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAccesSecondaire(new PaTypeCompteAccesSecondaire(listLoginMail.get(0)));
    final List<PA> listPA = new ArrayList<>();
    listPA.add(pa);
    final PFI pfi = new PFI();
    pfi.setPa(listPA);

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createOkRetour());

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pfi)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_008() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = null;
    final String loginMail = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);

    final List<String> listLoginMail = new ArrayList<>();
    final PA pa = new PA(identifiantFonctionnelPa, TypePA.COMPTE_ACCES.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(new PaTypeCompteAcces(__podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"))); //$NON-NLS-1$
    final List<PA> listPA = new ArrayList<>();
    listPA.add(pa);
    final PFI pfi = new PFI();
    pfi.setPa(listPA);

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.LOGIN_MAIL_INCONNU, MessageFormat.format(Messages.getString("PE0215.BL100.loginMailIconnu"), loginMail))); //$NON-NLS-1$

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pfi)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_009() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = null;
    final String loginMail = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);

    final List<String> listLoginMail = new ArrayList<>();
    listLoginMail.add(loginMail);
    final PA pa = new PA(identifiantFonctionnelPa, TypePA.COMPTE_ACCES.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(new PaTypeCompteAcces(loginMail));
    final List<PA> listPA = new ArrayList<>();
    listPA.add(pa);
    final PFI pfi = new PFI();
    pfi.setPa(listPA);

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createOkRetour());

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pfi)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_010() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = null;
    final String loginMail = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);

    final List<String> listLoginMail = new ArrayList<>();
    listLoginMail.add(loginMail);
    final PA pa = new PA(identifiantFonctionnelPa, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAccesSecondaire(new PaTypeCompteAccesSecondaire(loginMail));
    final List<PA> listPA = new ArrayList<>();
    listPA.add(pa);
    final PFI pfi = new PFI();
    pfi.setPa(listPA);

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createOkRetour());

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pfi)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_011() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = null;
    final String loginMail = null;
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);

    final List<String> listLoginMail = new ArrayList<>();
    listLoginMail.add(loginMail);
    final PA pa = new PA(identifiantFonctionnelPa, TypePA.COMPTE_ACCES.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAcces(new PaTypeCompteAcces(loginMail));
    final List<PA> listPA = new ArrayList<>();
    listPA.add(pa);
    final PFI pfi = new PFI();
    pfi.setPa(listPA);

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createOkRetour());

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pfi)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL100_RechercheListLoginMail}.
   * <b>Entrées:</b> All headers are set & parameters "audit" is correctly set, "sourceDonnee" is set to REFERENTIEL,
   * and "loginMail" are not set <br/>
   * <b>Attendu:</b> OK <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL100_RechercheListLoginMail_012() throws Exception
  {
    final String xClientOperateur = __podam.manufacturePojo(String.class);
    final String noCompte = __podam.manufacturePojo(String.class);
    final String identifiantFonctionnelPa = null;
    final String loginMail = null;
    EnumSet<SourceDonne> sourceDonnee = EnumSet.of(SourceDonne.REFERENTIEL);

    final List<String> listLoginMail = new ArrayList<>();
    listLoginMail.add(loginMail);
    final PA pa = new PA(identifiantFonctionnelPa, TypePA.COMPTE_ACCES_SECONDAIRE.name(), Statut.ACTIF, null, null);
    pa.setPaTypeCompteAccesSecondaire(new PaTypeCompteAccesSecondaire(loginMail));
    final List<PA> listPA = new ArrayList<>();
    listPA.add(pa);
    final PFI pfi = new PFI();
    pfi.setPa(listPA);

    final PE0215_BL100Return expected = new PE0215_BL100Return(null);
    expected.setListeLoginMail(listLoginMail);
    expected.setRetour(RetourFactoryForTU.createOkRetour());

    PE0215_BL100Return actual = null;

    try
    {
      EasyMock.expect(RPGProxy.getInstance()).andReturn(_rpgMock).once();
      EasyMock.expect(_rpgMock.pfiLireUn(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(xClientOperateur), EasyMock.eq(noCompte))).andReturn(new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), pfi)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL100_RechercheListLoginMail", _tracabilite, xClientOperateur, noCompte, identifiantFonctionnelPa, loginMail, sourceDonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertEquals(expected, actual);
    }
  }

  /**
   * Test for PE0215_BL200_ConstruireVueReferentiel
   *
   * Donnes de entree;
   *
   * NoCompte = "noCompte" ClientOperateur = "clientOperateur" Liste de LoginMail = "loginmail1"
   *
   * RTSProxy call returns a empty list of serviceTechniques AND Retour NOK CAT4 DONNES_INCONNU
   *
   *
   * @throws Exception
   *           Exception
   *
   */

  @Test
  public void testPE0215_BL200_ConstruireVueReferentiel_001() throws Exception
  {

    String noCompte = "noCompte"; //$NON-NLS-1$
    String clientOperateur = "clientOperateur"; //$NON-NLS-1$
    List<String> listeLoginMail = new ArrayList<>();
    listeLoginMail.add("loginmail1"); //$NON-NLS-1$

    EnumSet<SourceDonne> sourceDonnee = EnumSet.allOf(SourceDonne.class);

    ConnectorResponse<Retour, List<ServiceTechnique>> lireTousParPfi = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, null), null);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstMock).times(1);
    EasyMock.expect(_rstMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur, noCompte, null, null)).andReturn(lireTousParPfi).times(1);

    PowerMock.replayAll();

    PE0215_BL200Return bl200retour = Whitebox.invokeMethod(_instance, "PE0215_BL200_ConstruireVueReferentiel", _tracabilite, noCompte, clientOperateur, listeLoginMail, sourceDonnee); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(lireTousParPfi._first, bl200retour.getRetour());
  }

  /**
   * Test for PE0215_BL200_ConstruireVueReferentiel
   *
   * Donnes de entree;
   *
   * NoCompte = "noCompte" ClientOperateur = "clientOperateur" Liste de LoginMail = "loginmail1"
   *
   * RTSProxy call returns a empty list of serviceTechniques AND Retour NOK CAT4 DONNES_INCONNU
   *
   *
   * @throws Exception
   *           Exception
   *
   *
   */

  @Test
  public void testPE0215_BL200_ConstruireVueReferentiel_002() throws Exception
  {

    String noCompte = "noCompte"; //$NON-NLS-1$
    String clientOperateur = "clientOperateur"; //$NON-NLS-1$
    List<String> listeLoginMail = new ArrayList<>();
    listeLoginMail.add("loginmail1"); //$NON-NLS-1$

    EnumSet<SourceDonne> sourceDonnee = EnumSet.allOf(SourceDonne.class);

    ConnectorResponse<Retour, List<ServiceTechnique>> lireTousParPfi = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, null), null);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstMock).times(1);
    EasyMock.expect(_rstMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur, noCompte, null, null)).andReturn(lireTousParPfi).times(1);

    Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    Referentiel expectedReferentiel = new Referentiel("MAIL", "loginmail1", null); //$NON-NLS-1$ //$NON-NLS-2$
    expectedReferentiel.setEtatProvisioning(EtatProvisioning.EN_COURS.toString());

    Ressource ressource = new Ressource();
    ressource.setTypeRessource(TypeRessource.ADRESSE_MAIL.toString());
    ressource.setEtatRessource(EtatRessource.ALLOUE.toString());
    ressource.setEtatAllocation(EtatAllocation.EN_COURS.toString());
    List<Ressource> listRes = new ArrayList<>();
    listRes.add(ressource);
    expectedReferentiel.setRessources(listRes);

    List<Referentiel> expectedListReferentiel = new ArrayList<>();
    expectedListReferentiel.add(expectedReferentiel);

    PowerMock.replayAll();

    PE0215_BL200Return bl200retour = Whitebox.invokeMethod(_instance, "PE0215_BL200_ConstruireVueReferentiel", _tracabilite, noCompte, clientOperateur, listeLoginMail, sourceDonnee); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expectedListReferentiel, bl200retour.getListeReferentiel());
    assertEquals(expectedRetour, bl200retour.getRetour());

  }

  /**
   * Test for PE0215_BL200_ConstruireVueReferentiel
   *
   * Donnes de entree;
   *
   * NoCompte = "noCompte" ClientOperateur = "clientOperateur" Liste de LoginMail = "loginmail1"
   *
   * RTSProxy call returns a list of serviceTechniques
   *
   * Retour OK ; Referenciel not null
   *
   * @throws Exception
   *           Exception
   *
   *
   */

  @Test
  public void testPE0215_BL200_ConstruireVueReferentiel_003() throws Exception
  {

    String noCompte = "noCompte"; //$NON-NLS-1$
    String clientOperateur = "clientOperateur"; //$NON-NLS-1$
    List<String> listeLoginMail = new ArrayList<>();
    listeLoginMail.add("loginmail1"); //$NON-NLS-1$

    EnumSet<SourceDonne> sourceDonnee = EnumSet.allOf(SourceDonne.class);

    List<ServiceTechnique> listSTPFI = new ArrayList<>();
    listSTPFI = createListServiceTechnique();
    ConnectorResponse<Retour, List<ServiceTechnique>> lireTousParPfi = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listSTPFI);

    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstMock).times(1);
    EasyMock.expect(_rstMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur, noCompte, null, null)).andReturn(lireTousParPfi).times(1);

    Retour expectedRetour = RetourFactoryForTU.createOkRetour();

    Referentiel expectedReferentiel = new Referentiel("MAIL", "loginmail1", null); //$NON-NLS-1$ //$NON-NLS-2$
    expectedReferentiel.setEtatProvisioning(EtatProvisioning.ECHEC.toString());
    expectedReferentiel.setTaillePieceJointe(0L);
    expectedReferentiel.setVolumeBoite(0L);

    Ressource ressource = new Ressource();
    ressource.setTypeRessource(TypeRessource.ADRESSE_MAIL.toString());
    ressource.setEtatRessource(EtatRessource.ALLOUE.toString());
    ressource.setEtatAllocation(EtatAllocation.ECHEC.toString());
    List<Ressource> listRes = new ArrayList<>();
    listRes.add(ressource);
    expectedReferentiel.setRessources(listRes);

    List<Referentiel> expectedListReferentiel = new ArrayList<>();
    expectedListReferentiel.add(expectedReferentiel);

    PowerMock.replayAll();

    PE0215_BL200Return bl200retour = Whitebox.invokeMethod(_instance, "PE0215_BL200_ConstruireVueReferentiel", _tracabilite, noCompte, clientOperateur, listeLoginMail, sourceDonnee); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expectedListReferentiel.get(0).getIdStPfs(), bl200retour.getListeReferentiel().get(0).getIdStPfs());
    assertEquals(expectedListReferentiel.get(0).getTypeService(), bl200retour.getListeReferentiel().get(0).getTypeService());
    assertEquals(expectedListReferentiel.get(0).getLoginMail(), bl200retour.getListeReferentiel().get(0).getLoginMail());
    assertEquals(expectedListReferentiel.get(0).getRessources().size(), bl200retour.getListeReferentiel().get(0).getRessources().size());
    assertEquals(expectedListReferentiel.get(0).getNoCompte(), bl200retour.getListeReferentiel().get(0).getNoCompte());
    assertEquals(expectedListReferentiel.get(0).getClientOperateur(), bl200retour.getListeReferentiel().get(0).getClientOperateur());
    assertEquals(expectedListReferentiel.get(0).getAudits(), bl200retour.getListeReferentiel().get(0).getAudits());
    assertEquals(expectedListReferentiel.get(0).getErreurs(), bl200retour.getListeReferentiel().get(0).getErreurs());

    assertEquals(expectedRetour, bl200retour.getRetour());

  }

  /**
   * Test for PE0215_BL201_CreerObjectReferentiel
   *
   * Donnes de entree;
   *
   * Login = "login" ServiceTechnique StPfsMail = null; ServiceTechnique StLAC = null;
   *
   * Resultat OK;
   *
   * @throws Exception
   *           Exception
   *
   *
   *
   */

  @Test
  public void testPE0215_BL201_CreerObjectReferentiel_001() throws Exception
  {

    ServiceTechnique StPfsMail = null;
    ServiceTechnique StLAC = null;

    Referentiel expectedRef = new Referentiel("MAIL", "login", null); //$NON-NLS-1$ //$NON-NLS-2$
    Ressource expectedRes = new Ressource();
    expectedRes.setTypeRessource(TypeRessource.ADRESSE_MAIL.toString());
    expectedRes.setEtatRessource(EtatRessource.ALLOUE.toString());
    expectedRes.setEtatAllocation(EtatAllocation.EN_COURS.toString());

    List<Ressource> listRes = new ArrayList<>();
    listRes.add(expectedRes);
    expectedRef.setRessources(listRes);
    expectedRef.setEtatProvisioning(EtatProvisioning.EN_COURS.toString());

    Pair<Retour, Referentiel> expectedRetour = new Pair<>(RetourFactoryForTU.createOkRetour(), expectedRef);

    PowerMock.replayAll();

    PE0215_BL201Return bl201retour = Whitebox.invokeMethod(_instance, "PE0215_BL201_CreerObjectReferentiel", _tracabilite, "login", StPfsMail, StLAC); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verify();

    assertEquals(expectedRetour._first, bl201retour.getRetour());
    assertEquals(expectedRetour._second, bl201retour.getReferentiel());

  }

  /**
   * Test for PE0215_BL201_CreerObjectReferentiel ;
   *
   * Donnes de entree;
   *
   * Login = "login" ; ServiceTechnique stLac = not null AND StLienAllocationCommercial not null ; ServiceTechnique
   * stPfsMail = not null;
   *
   *
   * Resultat OK
   *
   * @throws Exception
   *           Exception
   *
   *
   *
   *
   */

  @Test
  public void testPE0215_BL201_CreerObjectReferentiel_002() throws Exception
  {
    DonneesIdentificationSTPfsMail d = new DonneesIdentificationSTPfsMail(null, null);
    ServiceTechnique stPfsMail = new StPfsMail(null, null, null, null, d);
    ServiceTechnique stLac = new StLienAllocationCommercial("idST", "ACTIF", "clienOp", "nocompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", com.bytel.spirit.common.shared.saab.res.TypeRessource.ADRESSE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    Referentiel expectedRef = new Referentiel("MAIL", "login", null); //$NON-NLS-1$ //$NON-NLS-2$
    expectedRef.setTaillePieceJointe(new Long(0));
    expectedRef.setVolumeBoite(new Long(0));
    Ressource expectedRes = new Ressource();
    expectedRes.setTypeRessource(TypeRessource.ADRESSE_MAIL.toString());
    expectedRes.setEtatRessource(EtatRessource.ALLOUE.toString());

    expectedRes.setEtatAllocation(EtatAllocation.EN_COURS.toString());

    List<Ressource> listRes = new ArrayList<>();
    listRes.add(expectedRes);
    expectedRef.setRessources(listRes);

    expectedRef.setEtatProvisioning(EtatProvisioning.EN_COURS.toString());

    Pair<Retour, Referentiel> expectedRetour = new Pair<>(RetourFactoryForTU.createOkRetour(), expectedRef);

    PowerMock.replayAll();

    PE0215_BL201Return bl201retour = Whitebox.invokeMethod(_instance, "PE0215_BL201_CreerObjectReferentiel", _tracabilite, "login", stPfsMail, stLac); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verify();

    assertEquals(expectedRetour._first, bl201retour.getRetour());
    assertEquals(expectedRetour._second.getIdStPfs(), bl201retour.getReferentiel().getIdStPfs());
    assertEquals(expectedRetour._second.getTypeService(), bl201retour.getReferentiel().getTypeService());
    assertEquals(expectedRetour._second.getLoginMail(), bl201retour.getReferentiel().getLoginMail());
    assertEquals(expectedRetour._second.getRessources().size(), bl201retour.getReferentiel().getRessources().size());
    assertEquals(expectedRetour._second.getEtatProvisioning(), bl201retour.getReferentiel().getEtatProvisioning());
    assertEquals(expectedRetour._second.getTypeServiceMail(), bl201retour.getReferentiel().getTypeServiceMail());
    assertEquals(expectedRetour._second.getTaillePieceJointe(), bl201retour.getReferentiel().getTaillePieceJointe());
    assertEquals(expectedRetour._second.getVolumeBoite(), bl201retour.getReferentiel().getVolumeBoite());
    assertEquals(expectedRetour._second.getNiveauRestriction(), bl201retour.getReferentiel().getNiveauRestriction());
    assertEquals(expectedRetour._second.getNoCompte(), bl201retour.getReferentiel().getNoCompte());
    assertEquals(expectedRetour._second.getClientOperateur(), bl201retour.getReferentiel().getClientOperateur());
    assertEquals(expectedRetour._second.getAudits(), bl201retour.getReferentiel().getAudits());
    assertEquals(expectedRetour._second.getErreurs(), bl201retour.getReferentiel().getErreurs());

  }

  /**
   * Test for PE0215_BL201_CreerObjectReferentiel ;
   *
   * Donnes de entree;
   *
   * Login = "login" ; ServiceTechnique stLac = not null AND StLienAllocationCommercial not null and Statut = Active ;
   * ServiceTechnique stPfsMail = not null and Statut = Active;
   *
   *
   * Resultat OK
   *
   * @throws Exception
   *           exception
   *
   *
   */

  @Test
  public void testPE0215_BL201_CreerObjectReferentiel_003() throws Exception
  {
    DonneesIdentificationSTPfsMail d = new DonneesIdentificationSTPfsMail(null, null);
    ServiceTechnique stPfsMail = new StPfsMail(null, null, null, null, d);

    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idST", "ACTIF", "clienOp", "nocompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", com.bytel.spirit.common.shared.saab.res.TypeRessource.ADRESSE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stPfsMail.setStatut(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString());
    stLAC.setStatut(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString());

    Referentiel expectedRef = new Referentiel("MAIL", "login", null); //$NON-NLS-1$ //$NON-NLS-2$
    expectedRef.setTaillePieceJointe(new Long(0));
    expectedRef.setVolumeBoite(new Long(0));
    Ressource expectedRes = new Ressource();
    expectedRes.setTypeRessource(TypeRessource.ADRESSE_MAIL.toString());
    expectedRes.setEtatRessource(EtatRessource.ALLOUE.toString());

    expectedRes.setEtatAllocation(EtatAllocation.REALISE.toString());

    List<Ressource> listRes = new ArrayList<>();
    listRes.add(expectedRes);
    expectedRef.setRessources(listRes);

    expectedRef.setEtatProvisioning(EtatProvisioning.REALISE.toString());

    Pair<Retour, Referentiel> expectedRetour = new Pair<>(RetourFactoryForTU.createOkRetour(), expectedRef);

    PowerMock.replayAll();

    PE0215_BL201Return bl201retour = Whitebox.invokeMethod(_instance, "PE0215_BL201_CreerObjectReferentiel", _tracabilite, "login", stPfsMail, stLAC); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verify();

    assertEquals(expectedRetour._first, bl201retour.getRetour());
    assertEquals(expectedRetour._second.getIdStPfs(), bl201retour.getReferentiel().getIdStPfs());
    assertEquals(expectedRetour._second.getTypeService(), bl201retour.getReferentiel().getTypeService());
    assertEquals(expectedRetour._second.getLoginMail(), bl201retour.getReferentiel().getLoginMail());
    assertEquals(expectedRetour._second.getRessources().size(), bl201retour.getReferentiel().getRessources().size());
    assertEquals(expectedRetour._second.getEtatProvisioning(), bl201retour.getReferentiel().getEtatProvisioning());
    assertEquals(expectedRetour._second.getTypeServiceMail(), bl201retour.getReferentiel().getTypeServiceMail());
    assertEquals(expectedRetour._second.getTaillePieceJointe(), bl201retour.getReferentiel().getTaillePieceJointe());
    assertEquals(expectedRetour._second.getVolumeBoite(), bl201retour.getReferentiel().getVolumeBoite());
    assertEquals(expectedRetour._second.getNiveauRestriction(), bl201retour.getReferentiel().getNiveauRestriction());
    assertEquals(expectedRetour._second.getNoCompte(), bl201retour.getReferentiel().getNoCompte());
    assertEquals(expectedRetour._second.getClientOperateur(), bl201retour.getReferentiel().getClientOperateur());
    assertEquals(expectedRetour._second.getAudits(), bl201retour.getReferentiel().getAudits());
    assertEquals(expectedRetour._second.getErreurs(), bl201retour.getReferentiel().getErreurs());

  }

  /**
   * Test for PE0215_BL201_CreerObjectReferentiel ;
   *
   * Donnes de entree;
   *
   * Login = "login" ; ServiceTechnique stLac = not null AND StLienAllocationCommercial not null and Statut = ECHEC ;
   * ServiceTechnique stPfsMail = not null and Statut = ECHEC;
   *
   *
   * Resultat OK
   *
   * @throws Exception
   *           Exception
   *
   *
   *
   */

  @Test
  public void testPE0215_BL201_CreerObjectReferentiel_004() throws Exception
  {
    DonneesIdentificationSTPfsMail d = new DonneesIdentificationSTPfsMail(null, null);
    ServiceTechnique stPfsMail = new StPfsMail(null, null, null, null, d);
    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idST", "ACTIF", "clienOp", "nocompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", com.bytel.spirit.common.shared.saab.res.TypeRessource.ADRESSE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    stPfsMail.setStatut(com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString());
    stLAC.setStatut(com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString());

    Referentiel expectedRef = new Referentiel("MAIL", "login", null); //$NON-NLS-1$ //$NON-NLS-2$
    expectedRef.setTaillePieceJointe(new Long(0));
    expectedRef.setVolumeBoite(new Long(0));
    Ressource expectedRes = new Ressource();
    expectedRes.setTypeRessource(TypeRessource.ADRESSE_MAIL.toString());
    expectedRes.setEtatRessource(EtatRessource.ALLOUE.toString());

    expectedRes.setEtatAllocation(EtatAllocation.ECHEC.toString());

    List<Ressource> listRes = new ArrayList<>();
    listRes.add(expectedRes);
    expectedRef.setRessources(listRes);

    expectedRef.setEtatProvisioning(EtatProvisioning.ECHEC.toString());

    Pair<Retour, Referentiel> expectedRetour = new Pair<>(RetourFactoryForTU.createOkRetour(), expectedRef);

    PowerMock.replayAll();

    PE0215_BL201Return bl201retour = Whitebox.invokeMethod(_instance, "PE0215_BL201_CreerObjectReferentiel", _tracabilite, "login", stPfsMail, stLAC); //$NON-NLS-1$ //$NON-NLS-2$
    PowerMock.verify();

    assertEquals(expectedRetour._first, bl201retour.getRetour());
    assertEquals(expectedRetour._second.getIdStPfs(), bl201retour.getReferentiel().getIdStPfs());
    assertEquals(expectedRetour._second.getTypeService(), bl201retour.getReferentiel().getTypeService());
    assertEquals(expectedRetour._second.getLoginMail(), bl201retour.getReferentiel().getLoginMail());
    assertEquals(expectedRetour._second.getRessources().size(), bl201retour.getReferentiel().getRessources().size());
    assertEquals(expectedRetour._second.getEtatProvisioning(), bl201retour.getReferentiel().getEtatProvisioning());
    assertEquals(expectedRetour._second.getTypeServiceMail(), bl201retour.getReferentiel().getTypeServiceMail());
    assertEquals(expectedRetour._second.getTaillePieceJointe(), bl201retour.getReferentiel().getTaillePieceJointe());
    assertEquals(expectedRetour._second.getVolumeBoite(), bl201retour.getReferentiel().getVolumeBoite());
    assertEquals(expectedRetour._second.getNiveauRestriction(), bl201retour.getReferentiel().getNiveauRestriction());
    assertEquals(expectedRetour._second.getNoCompte(), bl201retour.getReferentiel().getNoCompte());
    assertEquals(expectedRetour._second.getClientOperateur(), bl201retour.getReferentiel().getClientOperateur());
    assertEquals(expectedRetour._second.getAudits(), bl201retour.getReferentiel().getAudits());
    assertEquals(expectedRetour._second.getErreurs(), bl201retour.getReferentiel().getErreurs());

  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL300_ConstruireVuePfs}.
   * <b>Entrées:</b> No parameters set<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL300_ConstruireVuePfs_001() throws Exception
  {
    final String loginMail = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    final List<String> listLoginMail = new ArrayList<>();
    listLoginMail.add(loginMail);
    final PFS pfs = new PFS();
    pfs.setLoginMail(loginMail);
    pfs.setTypePfs(TypePfs.ROMA.toString());
    pfs.setTaillePieceJointe(__podam.manufacturePojo(Long.class));
    pfs.setVolumeBoite(__podam.manufacturePojo(Long.class));
    pfs.setNiveauRestriction(__podam.manufacturePojo(String.class));
    pfs.setAntivirus(__podam.manufacturePojo(Boolean.class));
    pfs.setAntispam(__podam.manufacturePojo(Boolean.class));
    pfs.setDateCreationCompte(__podam.manufacturePojo(LocalDate.class));
    pfs.setDateModificationCompte(__podam.manufacturePojo(LocalDate.class));

    EnumSet<SourceDonne> sourcedonnee = EnumSet.of(SourceDonne.PFS);

    final PE0215_BL300Return expected = new PE0215_BL300Return(null);
    expected.setRetour(RetourFactoryForTU.createOkRetour());
    expected.setListePfs(Arrays.asList(pfs));

    PE0215_BL300Return actual = new PE0215_BL300Return(RetourFactoryForTU.createOkRetour());

    try
    {
      final PROV_SI002_ExecuterProcessusBuilder builder = new PROV_SI002_ExecuterProcessusBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _provSI002Mock); //$NON-NLS-1$
      PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(builder).once();

      _provSI002Mock.setTracabilite(null);
      EasyMock.expectLastCall().once();
      _provSI002Mock.setPriorite(10);
      EasyMock.expectLastCall().once();
      _provSI002Mock.setProcessus("PI0150C_ConsulterROMA"); //$NON-NLS-1$
      EasyMock.expectLastCall().once();
      _provSI002Mock.setNoms(Arrays.asList("nomDomaine", "adresseMail")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expectLastCall().once();
      _provSI002Mock.setValeurs(Arrays.asList("bbox.fr", loginMail)); //$NON-NLS-1$
      EasyMock.expectLastCall().once();

      EasyMock.expect(_provSI002Mock.getTracabilite()).andReturn(_tracabilite).once(); // For validation only
      EasyMock.expect(_provSI002Mock.getProcessus()).andReturn("PI0150C_ConsulterROMA").once(); //$NON-NLS-1$
      EasyMock.expect(_provSI002Mock.getPriorite()).andReturn(10).once();
      EasyMock.expect(_provSI002Mock.getListeParametres()).andReturn(null).once();
      EasyMock.expect(_provSI002Mock.getNoms()).andReturn(Arrays.asList("nomDomaine", "adresseMail")).once(); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_provSI002Mock.getValeurs()).andReturn(Arrays.asList("bbox.fr", loginMail)).once(); //$NON-NLS-1$

      EasyMock.expect(_provSI002Mock.execute(EasyMock.anyObject(PE0215_DiagnosticServiceMail.class))).andReturn(_responseConnectorMock).once();
      EasyMock.expect(_responseConnectorMock.getFunctionalResponse(ReponseFonctionnellePI0150C.class, GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ssZ))).andReturn(_reponseFonctionnellePI0150CMock).once();
      EasyMock.expect(_provSI002Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).once();

      EasyMock.expect(_reponseFonctionnellePI0150CMock.getIdCompteMail()).andReturn(pfs.getIdCompteMail()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getIdCompteMailPrincipal()).andReturn(pfs.getIdCompteMailPrincipal()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getTypeServiceMail()).andReturn(pfs.getTypeServiceMail()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getLoginMail()).andReturn(pfs.getLoginMail()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getTaillePieceJointe()).andReturn(pfs.getTaillePieceJointe()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getVolumeBoite()).andReturn(pfs.getVolumeBoite()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getNiveauRestriction()).andReturn(pfs.getNiveauRestriction()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getAntivirus()).andReturn(pfs.getAntivirus()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getAntispam()).andReturn(pfs.getAntispam()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getDateCreationCompte()).andReturn(pfs.getDateCreationCompte()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getDateModificationCompte()).andReturn(pfs.getDateModificationCompte()).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL300_ConstruireVuePfs", _tracabilite, listLoginMail, sourcedonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected.getRetour(), actual.getRetour());

    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL300_ConstruireVuePfs(java.util.List)}
   * . <b>Entrées:</b> No parameters set<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL300_ConstruireVuePfs_002() throws Exception
  {
    final String loginMail1 = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    final String loginMail2 = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    final List<String> listLoginMail = new ArrayList<>();
    String erreurLibelle = "KPSA indisponible"; //$NON-NLS-1$
    listLoginMail.add(loginMail1);
    listLoginMail.add(loginMail2);
    final PFS pfs1 = new PFS();
    pfs1.setLoginMail(loginMail1);
    pfs1.setTypePfs(TypePfs.ROMA.toString());
    pfs1.addErreur(new Erreur(IMegConsts.ERREUR_TECHNIQUE, erreurLibelle));
    final PFS pfs2 = new PFS();
    pfs2.setLoginMail(loginMail2);
    pfs2.setTypePfs(TypePfs.ROMA.toString());
    pfs2.addErreur(new Erreur(IMegConsts.ERREUR_TECHNIQUE, erreurLibelle));

    EnumSet<SourceDonne> sourcedonnee = EnumSet.of(SourceDonne.PFS);

    final PE0215_BL300Return expected = new PE0215_BL300Return(null);
    expected.setRetour(RetourFactoryForTU.createOkRetour());
    expected.setListePfs(Arrays.asList(pfs1, pfs2));

    PE0215_BL300Return actual = null;

    try
    {
      final PROV_SI002_ExecuterProcessusBuilder builder = new PROV_SI002_ExecuterProcessusBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _provSI002Mock); //$NON-NLS-1$
      PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(builder).once();

      _provSI002Mock.setTracabilite(null);
      EasyMock.expectLastCall().once();
      _provSI002Mock.setPriorite(10);
      EasyMock.expectLastCall().once();
      _provSI002Mock.setProcessus("PI0150C_ConsulterROMA"); //$NON-NLS-1$
      EasyMock.expectLastCall().once();
      _provSI002Mock.setNoms(Arrays.asList("nomDomaine", "adresseMail")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expectLastCall().once();
      _provSI002Mock.setValeurs(Arrays.asList("bbox.fr", loginMail1)); //$NON-NLS-1$
      EasyMock.expectLastCall().once();

      EasyMock.expect(_provSI002Mock.getTracabilite()).andReturn(_tracabilite).once(); // For validation only
      EasyMock.expect(_provSI002Mock.getProcessus()).andReturn("PI0150C_ConsulterROMA").once(); //$NON-NLS-1$
      EasyMock.expect(_provSI002Mock.getPriorite()).andReturn(10).once();
      EasyMock.expect(_provSI002Mock.getListeParametres()).andReturn(null).once();
      EasyMock.expect(_provSI002Mock.getNoms()).andReturn(Arrays.asList("nomDomaine", "adresseMail")).once(); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_provSI002Mock.getValeurs()).andReturn(Arrays.asList("bbox.fr", loginMail1)).once(); //$NON-NLS-1$

      EasyMock.expect(_provSI002Mock.execute(EasyMock.anyObject(PE0215_DiagnosticServiceMail.class))).andReturn(_responseConnectorMock).once();
      EasyMock.expect(_responseConnectorMock.getFunctionalResponse(ReponseFonctionnellePI0150C.class)).andReturn(_reponseFonctionnellePI0150CMock).once();
      EasyMock.expect(_provSI002Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, erreurLibelle)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL300_ConstruireVuePfs", _tracabilite, listLoginMail, sourcedonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL300_ConstruireVuePfs}.
   * <b>Entrées:</b> No parameters set<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL300_ConstruireVuePfs_003() throws Exception
  {
    final String loginMail1 = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    final String loginMail2 = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    final List<String> listLoginMail = new ArrayList<>();
    listLoginMail.add(loginMail1);
    listLoginMail.add(loginMail2);
    final PFS pfs1 = new PFS();
    pfs1.setLoginMail(loginMail1);
    pfs1.setTypePfs(TypePfs.ROMA.toString());
    pfs1.setTypeServiceMail("PRINCIPAL"); //$NON-NLS-1$
    pfs1.setTaillePieceJointe(__podam.manufacturePojo(Long.class));
    pfs1.setVolumeBoite(__podam.manufacturePojo(Long.class));
    pfs1.setNiveauRestriction(__podam.manufacturePojo(String.class));
    pfs1.setAntivirus(__podam.manufacturePojo(Boolean.class));
    pfs1.setAntispam(__podam.manufacturePojo(Boolean.class));
    pfs1.setDateCreationCompte(__podam.manufacturePojo(LocalDate.class));
    pfs1.setDateModificationCompte(__podam.manufacturePojo(LocalDate.class));
    final PFS pfs2 = new PFS();
    pfs2.setLoginMail(loginMail2);
    pfs2.setTypePfs(TypePfs.ROMA.toString());
    String erreurLibelle = "Erreur KPSA"; //$NON-NLS-1$
    pfs2.addErreur(new Erreur(IMegConsts.ERREUR_TECHNIQUE, erreurLibelle));

    EnumSet<SourceDonne> sourcedonnee = EnumSet.of(SourceDonne.PFS);

    final PE0215_BL300Return expected = new PE0215_BL300Return(null);
    expected.setRetour(RetourFactoryForTU.createOkRetour());
    expected.setListePfs(Arrays.asList(pfs1, pfs2));

    PE0215_BL300Return actual = null;

    try
    {
      final PROV_SI002_ExecuterProcessusBuilder builder = new PROV_SI002_ExecuterProcessusBuilder();
      Whitebox.setInternalState(builder, "_toBuild", _provSI002Mock); //$NON-NLS-1$
      PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(builder).times(2);

      _provSI002Mock.setTracabilite(null);
      EasyMock.expectLastCall().once();
      _provSI002Mock.setPriorite(10);
      EasyMock.expectLastCall().once();
      _provSI002Mock.setProcessus("PI0150C_ConsulterROMA"); //$NON-NLS-1$
      EasyMock.expectLastCall().once();
      _provSI002Mock.setNoms(Arrays.asList("nomDomaine", "adresseMail")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expectLastCall().once();
      _provSI002Mock.setValeurs(Arrays.asList("bbox.fr", loginMail1)); //$NON-NLS-1$
      EasyMock.expectLastCall().once();

      EasyMock.expect(_provSI002Mock.getTracabilite()).andReturn(__podam.manufacturePojo(Tracabilite.class)).once(); // For validation only
      EasyMock.expect(_provSI002Mock.getProcessus()).andReturn("PI0150C_ConsulterROMA").once(); //$NON-NLS-1$
      EasyMock.expect(_provSI002Mock.getPriorite()).andReturn(10).once();
      EasyMock.expect(_provSI002Mock.getListeParametres()).andReturn(null).once();
      EasyMock.expect(_provSI002Mock.getNoms()).andReturn(Arrays.asList("nomDomaine", "adresseMail")).once(); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_provSI002Mock.getValeurs()).andReturn(Arrays.asList("bbox.f", loginMail1)).once(); //$NON-NLS-1$

      EasyMock.expect(_provSI002Mock.execute(EasyMock.anyObject(PE0215_DiagnosticServiceMail.class))).andReturn(_responseConnectorMock).once();
      EasyMock.expect(_responseConnectorMock.getFunctionalResponse(ReponseFonctionnellePI0150C.class, GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ssZ))).andReturn(_reponseFonctionnellePI0150CMock).once();
      EasyMock.expect(_provSI002Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).once();

      EasyMock.expect(_reponseFonctionnellePI0150CMock.getIdCompteMail()).andReturn(pfs1.getIdCompteMail()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getIdCompteMailPrincipal()).andReturn(pfs1.getIdCompteMailPrincipal()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getTypeServiceMail()).andReturn(pfs1.getTypeServiceMail()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getLoginMail()).andReturn(pfs1.getLoginMail()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getTaillePieceJointe()).andReturn(pfs1.getTaillePieceJointe()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getVolumeBoite()).andReturn(pfs1.getVolumeBoite()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getNiveauRestriction()).andReturn(pfs1.getNiveauRestriction()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getAntivirus()).andReturn(pfs1.getAntivirus()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getAntispam()).andReturn(pfs1.getAntispam()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getDateCreationCompte()).andReturn(pfs1.getDateCreationCompte()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getDateModificationCompte()).andReturn(pfs1.getDateModificationCompte()).once();

      _provSI002Mock.setTracabilite(null);
      EasyMock.expectLastCall().once();
      _provSI002Mock.setPriorite(10);
      EasyMock.expectLastCall().once();
      _provSI002Mock.setProcessus("PI0150C_ConsulterROMA"); //$NON-NLS-1$
      EasyMock.expectLastCall().once();
      _provSI002Mock.setNoms(Arrays.asList("nomDomaine", "adresseMail")); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expectLastCall().once();
      _provSI002Mock.setValeurs(Arrays.asList("bbox.fr", loginMail2)); //$NON-NLS-1$
      EasyMock.expectLastCall().once();

      EasyMock.expect(_provSI002Mock.getTracabilite()).andReturn(__podam.manufacturePojo(Tracabilite.class)).once(); // For validation only
      EasyMock.expect(_provSI002Mock.getProcessus()).andReturn("PI0150C_ConsulterROMA").once(); //$NON-NLS-1$
      EasyMock.expect(_provSI002Mock.getPriorite()).andReturn(10).once();
      EasyMock.expect(_provSI002Mock.getListeParametres()).andReturn(null).once();
      EasyMock.expect(_provSI002Mock.getNoms()).andReturn(Arrays.asList("nomDomaine", "adresseMail")).once(); //$NON-NLS-1$ //$NON-NLS-2$
      EasyMock.expect(_provSI002Mock.getValeurs()).andReturn(Arrays.asList("bbox.fr", loginMail2)).once(); //$NON-NLS-1$

      EasyMock.expect(_provSI002Mock.execute(EasyMock.anyObject(PE0215_DiagnosticServiceMail.class))).andReturn(_responseConnectorMock).once();
      EasyMock.expect(_responseConnectorMock.getFunctionalResponse(ReponseFonctionnellePI0150C.class)).andReturn(_reponseFonctionnellePI0150CMock).once();
      EasyMock.expect(_provSI002Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, erreurLibelle)).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL300_ConstruireVuePfs", _tracabilite, listLoginMail, sourcedonnee); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertEquals(expected, actual);
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL301_CreerObjetPfs}.
   * <b>Entrées:</b> No parameters set<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL301_CreerObjetPfs_001() throws Exception
  {
    final String loginMail = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    final PFS pfs = new PFS();
    pfs.setLoginMail(loginMail);
    pfs.setTypePfs(TypePfs.ROMA.toString());
    pfs.addAudit(new Audit("SERVICE_NON_PROVISIONNE", "Service non provisionne sur la PFS ")); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, null);
    final PE0215_BL301Return expected = new PE0215_BL301Return(RetourFactoryForTU.createOkRetour());
    expected.setPfs(pfs);

    PE0215_BL301Return actual = null;

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL301_CreerObjetPfs", _tracabilite, loginMail, retour, _reponseFonctionnellePI0150CMock); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(actual);
      assertEquals(expected, actual);

    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL301_CreerObjetPfs}.
   * <b>Entrées:</b> No parameters set<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL301_CreerObjetPfs_002() throws Exception
  {
    final String loginMail = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    final PFS pfs = new PFS();
    pfs.setLoginMail(loginMail);
    pfs.setTypePfs(TypePfs.ROMA.toString());
    pfs.addErreur(new Erreur("PFS_INDISPONIBLE", MessageFormat.format(Messages.getString("PE0215.BL301.PFSNonDisponible"), TypePfs.ROMA.toString()))); //$NON-NLS-1$ //$NON-NLS-2$
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, null);
    final PE0215_BL301Return expected = new PE0215_BL301Return(null);
    expected.setRetour(RetourFactoryForTU.createOkRetour());
    expected.setPfs(pfs);

    PE0215_BL301Return actual = null;

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL301_CreerObjetPfs", _tracabilite, loginMail, retour, _reponseFonctionnellePI0150CMock); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(actual);
      assertEquals(expected, actual);

    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL301_CreerObjetPfs}.
   * <b>Entrées:</b> No parameters set<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL301_CreerObjetPfs_003() throws Exception
  {
    final String libelle = __podam.manufacturePojo(String.class);
    final String loginMail = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    final PFS pfs = new PFS();
    pfs.setLoginMail(loginMail);
    pfs.setTypePfs(TypePfs.ROMA.toString());
    pfs.addErreur(new Erreur(IMegConsts.ERREUR_TECHNIQUE, libelle));
    final Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, libelle);
    final PE0215_BL301Return expected = new PE0215_BL301Return(null);
    expected.setRetour(RetourFactoryForTU.createOkRetour());
    expected.setPfs(pfs);

    PE0215_BL301Return actual = null;

    try
    {
      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL301_CreerObjetPfs", _tracabilite, loginMail, retour, _reponseFonctionnellePI0150CMock); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(actual);
      assertEquals(expected, actual);

    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#PE0215_BL301_CreerObjetPfs}.
   * <b>Entrées:</b> No parameters set<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testPE0215_BL301_CreerObjetPfs_004() throws Exception
  {
    final String loginMail = __podam.manufacturePojo(String.class).concat("@bouyguestelecom.fr"); //$NON-NLS-1$
    final PFS pfs = new PFS();
    pfs.setLoginMail(loginMail);
    pfs.setTypeServiceMail("PRINCIPAL"); //$NON-NLS-1$
    pfs.setTypePfs(TypePfs.ROMA.toString());
    pfs.setTaillePieceJointe(__podam.manufacturePojo(Long.class));
    pfs.setVolumeBoite(__podam.manufacturePojo(Long.class));
    pfs.setNiveauRestriction(__podam.manufacturePojo(String.class));
    pfs.setAntivirus(__podam.manufacturePojo(Boolean.class));
    pfs.setAntispam(__podam.manufacturePojo(Boolean.class));
    pfs.setDateCreationCompte(__podam.manufacturePojo(LocalDate.class));
    pfs.setDateModificationCompte(__podam.manufacturePojo(LocalDate.class));
    final Retour retour = RetourFactoryForTU.createOkRetour();
    final PE0215_BL301Return expected = new PE0215_BL301Return(null);
    expected.setRetour(RetourFactoryForTU.createOkRetour());
    expected.setPfs(pfs);

    PE0215_BL301Return actual = null;

    try
    {
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getIdCompteMail()).andReturn(pfs.getIdCompteMail()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getIdCompteMailPrincipal()).andReturn(pfs.getIdCompteMailPrincipal()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getTypeServiceMail()).andReturn(pfs.getTypeServiceMail()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getLoginMail()).andReturn(pfs.getLoginMail()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getTaillePieceJointe()).andReturn(pfs.getTaillePieceJointe()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getVolumeBoite()).andReturn(pfs.getVolumeBoite()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getNiveauRestriction()).andReturn(pfs.getNiveauRestriction()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getAntivirus()).andReturn(pfs.getAntivirus()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getAntispam()).andReturn(pfs.getAntispam()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getDateCreationCompte()).andReturn(pfs.getDateCreationCompte()).once();
      EasyMock.expect(_reponseFonctionnellePI0150CMock.getDateModificationCompte()).andReturn(pfs.getDateModificationCompte()).once();

      PowerMock.replayAll();

      actual = Whitebox.invokeMethod(_instance, "PE0215_BL301_CreerObjetPfs", _tracabilite, loginMail, retour, _reponseFonctionnellePI0150CMock); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(actual);
      assertEquals(expected, actual);
    }
  }

  /**
   * Test for PE0215_BL400_ComparerVues ;
   *
   * Donnes de entree;
   *
   * Liste de Referentiel , Liste de Pfs , Set SourceDonne with size 2 , Boolean Audit = true , Object PFI;
   *
   * Call of process PEI0229 Returns OK
   *
   * Liste de Referentiel , List de PFS with IdActionCorrective , return Ok ,
   *
   * @throws Exception
   *           Exception
   *
   *
   */

  @Test
  public void testPE0215_BL400_PE0215_BL400_ComparerVues_001() throws Exception
  {
    EasyMock.expect(_contextMock.getIdRequest()).andReturn(REQUEST_ID);
    Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$

    EnumSet<SourceDonne> sourcedonnes = EnumSet.allOf(SourceDonne.class);

    Boolean audit = true;

    PFI pfi = createPFI();

    List<Referentiel> listRef = new ArrayList<>();
    listRef = createListReferentiel();

    List<com.bytel.spirit.fiat.shared.types.json.PFS> listPFS = new ArrayList<>();

    PFS pfs1 = new PFS(TypePFS.MAIL.name(), "login1"); //$NON-NLS-1$
    pfs1.setTaillePieceJointe(1L);
    pfs1.setVolumeBoite(1L);
    pfs1.setNiveauRestriction("1"); //$NON-NLS-1$
    pfs1.setIdCompteMailPrincipal("1"); //$NON-NLS-1$

    PFS pfs2 = new PFS(TypePFS.MAIL.name(), "login2"); //$NON-NLS-1$

    Erreur erreur = new Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), "error"); //$NON-NLS-1$
    List<Erreur> listErreurs = new ArrayList<>();
    listErreurs.add(erreur);
    pfs2.setErreurs(listErreurs);

    listPFS.add(pfs1);
    listPFS.add(pfs2);

    List<com.bytel.spirit.fiat.shared.types.json.PFS> listPFSExpected = new ArrayList<>();

    PFS pfs1expected = new PFS(TypePFS.MAIL.name(), "login1"); //$NON-NLS-1$
    pfs1expected.setTaillePieceJointe(1L);
    pfs1expected.setVolumeBoite(1L);
    pfs1expected.setNiveauRestriction("1"); //$NON-NLS-1$
    pfs1expected.setIdCompteMailPrincipal("1"); //$NON-NLS-1$
    pfs1expected.setIdActionCorrective("idActionCorrective123"); //$NON-NLS-1$

    PFS pfs2expected = new PFS(TypePFS.MAIL.name(), "login2"); //$NON-NLS-1$

    Erreur erreurexpected = new Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), "error"); //$NON-NLS-1$
    List<Erreur> listErreursexpected = new ArrayList<>();
    listErreursexpected.add(erreurexpected);
    pfs2expected.setErreurs(listErreursexpected);

    listPFSExpected.add(pfs1expected);
    listPFSExpected.add(pfs2expected);

    final BL5100_CreerActionCorrectiveBuilder builder = new BL5100_CreerActionCorrectiveBuilder();
    Whitebox.setInternalState(builder, "_toBuild", _bl5100Mock); //$NON-NLS-1$
    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(builder).once();

    _bl5100Mock.setIdExterne(REQUEST_ID + "login1"); //$NON-NLS-1$
    EasyMock.expectLastCall().once();

    ActionServiceTechnique ast = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), TypeST.PFS.name(), "ACTIF", DateTimeManager.getInstance().now());
    ast.setIdSt("idSt1"); //$NON-NLS-1$
    List<ActionServiceTechnique> stList = Arrays.asList(ast);

    ActionCorrective actionCorrective = new ActionCorrective("clientOperateur1", "noCompte1");//$NON-NLS-1$ //$NON-NLS-2$
    actionCorrective.setActionsServicesTechniques(stList);

    _bl5100Mock.setActionCorrective(actionCorrective);
    EasyMock.expectLastCall().once();

    _bl5100Mock.setTracabilite(_tracabilite);
    EasyMock.expectLastCall().once();
    EasyMock.expect(_bl5100Mock.getTracabilite()).andReturn(_tracabilite).once();
    EasyMock.expect(_bl5100Mock.getIdExterne()).andReturn(REQUEST_ID + "login1").once();//$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.getActionCorrective()).andReturn(actionCorrective).once();

    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0215_DiagnosticServiceMail.class))).andReturn("idActionCorrective123").once(); //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).once();

    PowerMock.replayAll();

    PE0215_BL400Return bl400retour = Whitebox.invokeMethod(_instance, "PE0215_BL400_ComparerVues", _tracabilite, listRef, listPFS, sourcedonnes, audit, pfi); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(RetourFactoryForTU.createOkRetour(), bl400retour.getRetour());

    assertEquals(3, bl400retour.getListeReferentiel().size());
    assertEquals(2, bl400retour.getListePFS().size());
    assertEquals(listPFSExpected.get(0).getIdCompteMailPrincipal(), bl400retour.getListePFS().get(0).getIdCompteMailPrincipal());

  }

  /**
   * Test for PE0215_BL400_ComparerVues ;
   *
   * Donnes de entree;
   *
   * Liste de Referentiel , Liste de Pfs avec Audit, Set SourceDonne with size 2 , Boolean Audit = true , Objec PFI;
   *
   * Call of process PEI0229 Returns OK
   *
   * Liste de Referentiel , List de PFS with IdActionCorrective , return Ok ,
   *
   *
   * @throws Exception
   *           Exception
   *
   *
   */

  @Test
  public void testPE0215_BL400_PE0215_BL400_ComparerVues_002() throws Exception
  {

    EnumSet<SourceDonne> sourcedonnes = EnumSet.allOf(SourceDonne.class);

    Boolean audit = true;

    PFI pfi = createPFI();

    List<Referentiel> listRef = new ArrayList<>();
    listRef = createListReferentiel();

    List<com.bytel.spirit.fiat.shared.types.json.PFS> listPFS = new ArrayList<>();

    PFS pfs1 = new PFS(TypePFS.MAIL.name(), "login1"); //$NON-NLS-1$

    Audit audit1 = new Audit(Diagnostic.SERVICE_NON_PROVISIONNE.name(), ""); //$NON-NLS-1$
    List<Audit> auditList = new ArrayList<>();
    auditList.add(audit1);
    pfs1.setAudits(auditList);

    PFS pfs2 = new PFS(TypePFS.MAIL.name(), "login2"); //$NON-NLS-1$

    Erreur erreur = new Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), "error"); //$NON-NLS-1$
    List<Erreur> listErreurs = new ArrayList<>();
    listErreurs.add(erreur);
    pfs2.setErreurs(listErreurs);

    listPFS.add(pfs1);
    listPFS.add(pfs2);

    List<com.bytel.spirit.fiat.shared.types.json.PFS> listPFSExpected = new ArrayList<>();

    PFS pfs1expected = new PFS(TypePFS.MAIL.name(), "login1"); //$NON-NLS-1$
    pfs1expected.setTaillePieceJointe(1L);
    pfs1expected.setVolumeBoite(1L);
    pfs1expected.setNiveauRestriction("1"); //$NON-NLS-1$
    pfs1expected.setIdCompteMailPrincipal("1"); //$NON-NLS-1$
    pfs1expected.setIdActionCorrective("teste"); //$NON-NLS-1$

    PFS pfs2expected = new PFS(TypePFS.MAIL.name(), "login2"); //$NON-NLS-1$

    Erreur erreurexpected = new Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), "error"); //$NON-NLS-1$
    List<Erreur> listErreursexpected = new ArrayList<>();
    listErreursexpected.add(erreurexpected);
    pfs2expected.setErreurs(listErreursexpected);

    listPFSExpected.add(pfs1expected);
    listPFSExpected.add(pfs2expected);

    EasyMock.expect(_contextMock.getIdRequest()).andReturn(REQUEST_ID).once();
    Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$

    final BL5100_CreerActionCorrectiveBuilder builder = new BL5100_CreerActionCorrectiveBuilder();
    Whitebox.setInternalState(builder, "_toBuild", _bl5100Mock); //$NON-NLS-1$
    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(builder).once();

    _bl5100Mock.setIdExterne(REQUEST_ID + "login1"); //$NON-NLS-1$
    EasyMock.expectLastCall().once();

    ActionServiceTechnique ast = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), TypeST.PFS.name(), "INACTIF", DateTimeManager.getInstance().now());
    ast.setIdSt("idSt1"); //$NON-NLS-1$
    List<ActionServiceTechnique> stList = Arrays.asList(ast);

    ActionCorrective actionCorrective = new ActionCorrective("clientOperateur1", "noCompte1");//$NON-NLS-1$ //$NON-NLS-2$
    actionCorrective.setActionsServicesTechniques(stList);

    _bl5100Mock.setActionCorrective(actionCorrective);
    EasyMock.expectLastCall().once();

    _bl5100Mock.setTracabilite(_tracabilite);
    EasyMock.expectLastCall().once();
    EasyMock.expect(_bl5100Mock.getTracabilite()).andReturn(_tracabilite).once();
    EasyMock.expect(_bl5100Mock.getIdExterne()).andReturn(REQUEST_ID + "login1").once();//$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.getActionCorrective()).andReturn(actionCorrective).once();

    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0215_DiagnosticServiceMail.class))).andReturn("teste").once(); //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour()).once();

    PowerMock.replayAll();

    PE0215_BL400Return bl400retour = Whitebox.invokeMethod(_instance, "PE0215_BL400_ComparerVues", _tracabilite, listRef, listPFS, sourcedonnes, audit, pfi); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(RetourFactoryForTU.createOkRetour(), bl400retour.getRetour());
    assertEquals(3, bl400retour.getListeReferentiel().size());
    assertEquals(2, bl400retour.getListePFS().size());
    assertEquals(com.bytel.spirit.fiat.shared.types.json.Referentiel.NiveauRestriction.NON_RESTREINT.toString(), bl400retour.getListeReferentiel().get(0).getNiveauRestriction());

  }

  /**
   * Test for PE0215_BL400_ComparerVues ;
   *
   * Donnes de entree;
   *
   * Liste de Referentiel , Liste de Pfs avec Audit, Set SourceDonne with size 2 , Boolean Audit = true , Objec PFI;
   *
   * Call of process PEI0229 Returns NOK
   *
   * Liste de Referentiel , List de PFS with Erreur , return Ok ,
   *
   *
   * @throws Exception
   *           Exception
   *
   *
   */
  @Test
  public void testPE0215_BL400_PE0215_BL400_ComparerVues_003() throws Exception
  {
    EasyMock.expect(_contextMock.getIdRequest()).andReturn(REQUEST_ID);
    Whitebox.setInternalState(_instance, "_processContext", _contextMock); //$NON-NLS-1$

    EnumSet<SourceDonne> sourcedonnes = EnumSet.allOf(SourceDonne.class);

    Boolean audit = true;

    PFI pfi = createPFI();

    List<Referentiel> listRef = new ArrayList<>();
    listRef = createListReferentiel();

    List<com.bytel.spirit.fiat.shared.types.json.PFS> listPFS = new ArrayList<>();

    PFS pfs1 = new PFS(TypePFS.MAIL.name(), "login1"); //$NON-NLS-1$

    Audit audit1 = new Audit(Diagnostic.SERVICE_NON_PROVISIONNE.name(), ""); //$NON-NLS-1$
    List<Audit> auditList = new ArrayList<>();
    auditList.add(audit1);
    pfs1.setAudits(auditList);

    PFS pfs2 = new PFS(TypePFS.MAIL.name(), "login2"); //$NON-NLS-1$

    Erreur erreur = new Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), "error"); //$NON-NLS-1$
    List<Erreur> listErreurs = new ArrayList<>();
    listErreurs.add(erreur);
    pfs2.setErreurs(listErreurs);

    listPFS.add(pfs1);
    listPFS.add(pfs2);

    List<com.bytel.spirit.fiat.shared.types.json.PFS> listPFSExpected = new ArrayList<>();

    PFS pfs1expected = new PFS(TypePFS.MAIL.name(), "login1"); //$NON-NLS-1$

    pfs1expected.setTaillePieceJointe(1L);
    pfs1expected.setVolumeBoite(1L);
    pfs1expected.setNiveauRestriction("1"); //$NON-NLS-1$
    pfs1expected.setIdCompteMailPrincipal("1"); //$NON-NLS-1$

    Erreur erreurexpected1 = new Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), "service indisponible"); //$NON-NLS-1$
    List<Erreur> listErreursexpected1 = new ArrayList<>();
    listErreursexpected1.add(erreurexpected1);
    pfs1expected.setErreurs(listErreursexpected1);

    PFS pfs2expected = new PFS(TypePFS.MAIL.name(), "login2"); //$NON-NLS-1$

    Erreur erreurexpected2 = new Erreur(TypeError.ECHEC_ACTION_CORRECTIVE.name(), "service indisponible"); //$NON-NLS-1$
    List<Erreur> listErreursexpected2 = new ArrayList<>();
    listErreursexpected2.add(erreurexpected2);
    pfs2expected.setErreurs(listErreursexpected2);

    listPFSExpected.add(pfs1expected);
    listPFSExpected.add(pfs2expected);

    final BL5100_CreerActionCorrectiveBuilder builder = new BL5100_CreerActionCorrectiveBuilder();
    Whitebox.setInternalState(builder, "_toBuild", _bl5100Mock); //$NON-NLS-1$
    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(builder).once();

    _bl5100Mock.setIdExterne(REQUEST_ID + "login1"); //$NON-NLS-1$
    EasyMock.expectLastCall().once();

    ActionServiceTechnique ast = new ActionServiceTechniqueMail(TypeAction.MODIFICATION.name(), TypeST.PFS.name(), "INACTIF", DateTimeManager.getInstance().now());
    ast.setIdSt("idSt1"); //$NON-NLS-1$
    List<ActionServiceTechnique> stList = Arrays.asList(ast);

    ActionCorrective actionCorrective = new ActionCorrective("clientOperateur1", "noCompte1");//$NON-NLS-1$ //$NON-NLS-2$
    actionCorrective.setActionsServicesTechniques(stList);

    _bl5100Mock.setActionCorrective(actionCorrective);
    EasyMock.expectLastCall().once();

    _bl5100Mock.setTracabilite(_tracabilite);
    EasyMock.expectLastCall().once();
    EasyMock.expect(_bl5100Mock.getTracabilite()).andReturn(_tracabilite).once();
    EasyMock.expect(_bl5100Mock.getIdExterne()).andReturn(REQUEST_ID + "login1").once();//$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.getActionCorrective()).andReturn(actionCorrective).once();

    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0215_DiagnosticServiceMail.class))).andReturn("teste").once(); //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(RetourFactoryForTU.createNOK(IMegConsts.CAT2, Consts.SERVICE_INDISPONIBLE.name(), "service indisponible")).once(); //$NON-NLS-1$

    PowerMock.replayAll();

    PE0215_BL400Return bl400retour = Whitebox.invokeMethod(_instance, "PE0215_BL400_ComparerVues", _tracabilite, listRef, listPFS, sourcedonnes, audit, pfi); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(RetourFactoryForTU.createOkRetour(), bl400retour.getRetour());
    assertEquals(3, bl400retour.getListeReferentiel().size());
    assertEquals(2, bl400retour.getListePFS().size());
    assertEquals(listPFSExpected.get(0).getErreurs().get(0).getError(), bl400retour.getListePFS().get(1).getErreurs().get(0).getError());

  }

  /**
   * <b>Scenario:</b> Tests PE0215 non nominal case. BL001 NOK BL100 <br>
   * <b>Input:</b> Request without headers and parameters <br>
   * <b>Result:</b> Response {ErrorCode: 404, Result:{"error":"MAIL_INCONNU","error_description":"Mail charles.rock non
   * connu pour le Pfi 3594886"}}<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void testPE0215_DiagnosticServiceMail_001() throws Throwable
  {

    final Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    PowerMock.replayAll();

    _instance.run(request);
    PowerMock.verify();

    Response response = (Response) request.getResponse();

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());

  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#getProcessConfigParameters}.
   * <b>Entrées:</b> No parameters set<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testProcessConfigParameters_001() throws Exception
  {

    EnumSet<SourceDonne> expected = EnumSet.allOf(SourceDonne.class);

    final PE0215_DiagnosticServiceMailContext context = Whitebox.getInternalState(_instance, "_processContext"); //$NON-NLS-1$
    final ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    final Map<String, String> map = new HashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, map);

    try
    {
      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "getProcessConfigParameters", _tracabilite); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(context.getAuditViews());
      assertEquals(Boolean.FALSE, context.getAuditViews());

      assertNotNull(context.getSourceDonnes());
      assertEquals(expected, context.getSourceDonnes());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#getProcessConfigParameters}.
   * <b>Entrées:</b> only XXX set as null<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testProcessConfigParameters_002() throws Exception
  {

    EnumSet<SourceDonne> expected = EnumSet.allOf(SourceDonne.class);

    final PE0215_DiagnosticServiceMailContext context = Whitebox.getInternalState(_instance, "_processContext"); //$NON-NLS-1$
    final ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    final Map<String, String> map = new HashMap<>();
    map.put("XXX", null); //$NON-NLS-1$
    processParams.put(StringConstants.EMPTY_STRING, map);

    try
    {
      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "getProcessConfigParameters", _tracabilite); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(context.getAuditViews());
      assertEquals(Boolean.FALSE, context.getAuditViews());

      assertNotNull(context.getSourceDonnes());
      assertEquals(expected, context.getSourceDonnes());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#getProcessConfigParameters}.
   * <b>Entrées:</b> only "auditVues" set as null<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testProcessConfigParameters_003() throws Exception
  {

    EnumSet<SourceDonne> expected = EnumSet.allOf(SourceDonne.class);

    final PE0215_DiagnosticServiceMailContext context = Whitebox.getInternalState(_instance, "_processContext"); //$NON-NLS-1$
    final ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    final Map<String, String> map = new HashMap<>();
    map.put("auditVues", null); //$NON-NLS-1$
    processParams.put(StringConstants.EMPTY_STRING, map);

    try
    {
      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "getProcessConfigParameters", _tracabilite); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(context.getAuditViews());
      assertEquals(Boolean.FALSE, context.getAuditViews());

      assertNotNull(context.getSourceDonnes());
      assertEquals(expected, context.getSourceDonnes());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#getProcessConfigParameters}.
   * <b>Entrées:</b> only "auditVues" set as false and "sourceDonneeAutorise" as null<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testProcessConfigParameters_004() throws Exception
  {
    Set<SourceDonne> expected = new TreeSet<>();
    expected.add(SourceDonne.PFS);
    expected.add(SourceDonne.REFERENTIEL);

    final PE0215_DiagnosticServiceMailContext context = Whitebox.getInternalState(_instance, "_processContext"); //$NON-NLS-1$
    final ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    final Map<String, String> map = new HashMap<>();
    map.put("auditVues", "false"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("sourceDonneeAutorise", null); //$NON-NLS-1$
    processParams.put(StringConstants.EMPTY_STRING, map);

    try
    {
      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "getProcessConfigParameters", _tracabilite); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(context.getAuditViews());
      assertEquals(Boolean.FALSE, context.getAuditViews());

      assertNotNull(context.getSourceDonnes());
      assertEquals(expected, context.getSourceDonnes());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#getProcessConfigParameters}.
   * <b>Entrées:</b> only "auditVues" set as true and "sourceDonneeAutorise" as "XXX"<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testProcessConfigParameters_005() throws Exception
  {
    //final Set<String> expected = new TreeSet<>();
    //expected.add("REFERENTIEL"); //$NON-NLS-1$
    //expected.add("PFS"); //$NON-NLS-1$

    EnumSet<SourceDonne> expected = EnumSet.allOf(SourceDonne.class);

    final PE0215_DiagnosticServiceMailContext context = Whitebox.getInternalState(_instance, "_processContext"); //$NON-NLS-1$
    final ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    final Map<String, String> map = new HashMap<>();
    map.put("auditVues", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("sourceDonneeAutorise", "XXX"); //$NON-NLS-1$ //$NON-NLS-2$
    processParams.put(StringConstants.EMPTY_STRING, map);

    PowerMock.replayAll();

    Whitebox.invokeMethod(_instance, "getProcessConfigParameters", _tracabilite); //$NON-NLS-1$

    //PowerMock.verify();

    assertNotNull(context.getAuditViews());
    assertEquals(Boolean.TRUE, context.getAuditViews());

    assertNotNull(context.getSourceDonnes());
    assertEquals(expected, context.getSourceDonnes());

  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#getProcessConfigParameters}.
   * <b>Entrées:</b> only "auditVues" set as true and "sourceDonneeAutorise" as "PFS"<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testProcessConfigParameters_006() throws Exception
  {
    EnumSet<SourceDonne> expected = EnumSet.noneOf(SourceDonne.class);
    expected.add(SourceDonne.PFS);

    final PE0215_DiagnosticServiceMailContext context = Whitebox.getInternalState(_instance, "_processContext"); //$NON-NLS-1$
    final ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    final Map<String, String> map = new HashMap<>();
    map.put("auditVues", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("sourceDonneeParDefaut", "PFS"); //$NON-NLS-1$ //$NON-NLS-2$
    processParams.put(StringConstants.EMPTY_STRING, map);

    try
    {
      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "getProcessConfigParameters", _tracabilite); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(context.getAuditViews());
      assertEquals(Boolean.TRUE, context.getAuditViews());

      assertNotNull(context.getSourceDonnes());
      assertEquals(expected, context.getSourceDonnes());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#getProcessConfigParameters}.
   * <b>Entrées:</b> only "auditVues" set as true and "sourceDonneeAutorise" as "REFERENTIEL"<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testProcessConfigParameters_007() throws Exception
  {
    EnumSet<SourceDonne> expected = EnumSet.noneOf(SourceDonne.class);
    expected.add(SourceDonne.REFERENTIEL);

    final PE0215_DiagnosticServiceMailContext context = Whitebox.getInternalState(_instance, "_processContext"); //$NON-NLS-1$
    final ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    final Map<String, String> map = new HashMap<>();
    map.put("auditVues", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("sourceDonneeParDefaut", "REFERENTIEL"); //$NON-NLS-1$ //$NON-NLS-2$
    processParams.put(StringConstants.EMPTY_STRING, map);

    try
    {
      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "getProcessConfigParameters", _tracabilite); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(context.getAuditViews());
      assertEquals(Boolean.TRUE, context.getAuditViews());

      assertNotNull(context.getSourceDonnes());
      assertEquals(expected, context.getSourceDonnes());
    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#getProcessConfigParameters}.
   * <b>Entrées:</b> only "auditVues" set as true and "sourceDonneeAutorise" as "REFERENTIEL,PFS"<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testProcessConfigParameters_008() throws Exception
  {
    EnumSet<SourceDonne> expected = EnumSet.noneOf(SourceDonne.class);
    expected.add(SourceDonne.PFS);
    expected.add(SourceDonne.REFERENTIEL);

    final PE0215_DiagnosticServiceMailContext context = Whitebox.getInternalState(_instance, "_processContext"); //$NON-NLS-1$
    final ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    final Map<String, String> map = new HashMap<>();
    map.put("auditVues", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("sourceDonneeAutorise", "REFERENTIEL,PFS"); //$NON-NLS-1$ //$NON-NLS-2$
    processParams.put(StringConstants.EMPTY_STRING, map);

    try
    {
      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "getProcessConfigParameters", _tracabilite); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(context.getAuditViews());
      assertEquals(Boolean.TRUE, context.getAuditViews());

      assertNotNull(context.getSourceDonnes());
      assertEquals(expected, context.getSourceDonnes());

    }
  }

  /**
   * Test method for
   * {@link com.bytel.spirit.fiat.processes.PE0215.PE0215_DiagnosticServiceMail#getProcessConfigParameters}.
   * <b>Entrées:</b> only "auditVues" set as true and "sourceDonneeAutorise" as "PFS,REFERENTIEL"<br/>
   * <b>Attendu:</b> Default values <br/>
   *
   * @throws Exception
   *           On errors On errors
   */
  @Test
  public void testProcessConfigParameters_009() throws Exception
  {
    EnumSet<SourceDonne> expected = EnumSet.noneOf(SourceDonne.class);
    expected.add(SourceDonne.PFS);
    expected.add(SourceDonne.REFERENTIEL);

    final PE0215_DiagnosticServiceMailContext context = Whitebox.getInternalState(_instance, "_processContext"); //$NON-NLS-1$
    final ConcurrentMap<String, Map<String, String>> processParams = ProcessManager.getInstance().getProcessParams();
    final Map<String, String> map = new HashMap<>();
    map.put("auditVues", "true"); //$NON-NLS-1$ //$NON-NLS-2$
    map.put("sourceDonneeAutorise", "REFERENTIEL,PFS"); //$NON-NLS-1$ //$NON-NLS-2$
    processParams.put(StringConstants.EMPTY_STRING, map);

    try
    {
      PowerMock.replayAll();

      Whitebox.invokeMethod(_instance, "getProcessConfigParameters", _tracabilite); //$NON-NLS-1$
    }
    catch (final RavelException e)
    {
      _exception = true;
    }
    finally
    {
      PowerMock.verify();

      assertFalse(_exception);

      assertNotNull(context.getAuditViews());
      assertEquals(Boolean.TRUE, context.getAuditViews());

      assertNotNull(context.getSourceDonnes());
      assertEquals(expected, context.getSourceDonnes());

    }
  }

  /**
   * @return The list of referentiels
   */
  private List<Referentiel> createListReferentiel()
  {
    Referentiel ref1 = new Referentiel(null, "login1", null); //$NON-NLS-1$
    ref1.setTypeServiceMail(com.bytel.spirit.fiat.shared.types.json.Referentiel.TypeServiceMail.PRINCIPAL.toString());
    ref1.setTaillePieceJointe(1L);
    ref1.setVolumeBoite(1L);
    ref1.setNiveauRestriction(com.bytel.spirit.fiat.shared.types.json.Referentiel.NiveauRestriction.NON_RESTREINT.toString());

    List<ServiceTechnique> listST = new ArrayList<>();

    DonneesIdentificationSTPfsMail donnesIdentificationSTPfsMail = new DonneesIdentificationSTPfsMail(TypeServiceMail.PRINCIPAL.name(), "idCompteMail"); //$NON-NLS-1$
    DonneesProvisionneesSTPfsMail donnesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail("loginmail1", 0, 0, "2");//$NON-NLS-1$ //$NON-NLS-2$
    donnesProvisionneesSTPfsMail.setIdCompteMailPrincipal("2");//$NON-NLS-1$

    ServiceTechnique st1 = __podam.manufacturePojoWithFullData(StPfsMail.class);
    st1.setIdSt("idSt1"); //$NON-NLS-1$
    st1.setTypeServiceTechnique(TypeST.PFS.name());
    StPfsMail.class.cast(st1).setTypePfs(TypePFS.MAIL.name());
    StPfsMail.class.cast(st1).setDonneesIdentificationStPfsMail(donnesIdentificationSTPfsMail);
    StPfsMail.class.cast(st1).setDonneesProvisionneesStPfsMail(donnesProvisionneesSTPfsMail);

    listST.add(st1);

    ServiceTechnique st2 = __podam.manufacturePojoWithFullData(StLienAllocationCommercial.class);// new ServiceTechnique("idSt2", TypeST.LAC.name(), com.bytel.spirit.common.saab.rst.types.Statut.ACTIF.name(), "clientOperateur2", "noCompte2");
    st2.setIdSt("idSt2"); //$NON-NLS-1$
    st2.setTypeServiceTechnique(TypeST.LAC.name());
    st2.setStatut("ACTIF");
    st2.setClientOperateur("clientOperateur2"); //$NON-NLS-1$
    st2.setNoCompte("noCompte2"); //$NON-NLS-1$

    listST.add(st2);

    ref1.setServicetechniques(listST);

    Referentiel ref2 = new Referentiel(null, "login1", null); //$NON-NLS-1$
    ref2.setTypeServiceMail(com.bytel.spirit.fiat.shared.types.json.Referentiel.TypeServiceMail.PRINCIPAL.toString());
    ref2.setTaillePieceJointe(1L);
    ref2.setVolumeBoite(1L);
    ref2.setNiveauRestriction(com.bytel.spirit.fiat.shared.types.json.Referentiel.NiveauRestriction.NON_RESTREINT.toString());

    Referentiel ref3 = new Referentiel(null, "login3", null); //$NON-NLS-1$
    ref3.setTypeServiceMail(com.bytel.spirit.fiat.shared.types.json.Referentiel.TypeServiceMail.PRINCIPAL.toString());
    ref3.setTaillePieceJointe(1L);
    ref3.setVolumeBoite(1L);
    ref3.setNiveauRestriction(com.bytel.spirit.fiat.shared.types.json.Referentiel.NiveauRestriction.NON_RESTREINT.toString());

    return Arrays.asList(ref1, ref2, ref3);
  }

  /**
   * @return List ServiceTechnique
   */
  private List<ServiceTechnique> createListServiceTechnique()
  {
    ServiceTechnique stPfsMail = __podam.manufacturePojoWithFullData(StPfsMail.class);
    stPfsMail.setTypeServiceTechnique(TypeST.PFS.name());
    StPfsMail.class.cast(stPfsMail).setTypePfs(TypePFS.MAIL.name());
    stPfsMail.setStatut(com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString());

    StLienAllocationCommercial stLAC = new StLienAllocationCommercial("idST", "ECHEC", "cliOpe", "noCompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", "idRessource", TypeRessource.ADRESSE_MAIL.name()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$

    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();
    listServiceTechnique.add(stLAC);
    listServiceTechnique.add(stPfsMail);

    return listServiceTechnique;
  }

  /**
   * @return PFI
   */
  private PFI createPFI()
  {
    PFI pfi = new PFI("clientOperateur", "noCompte", null, null, null, null, null); //$NON-NLS-1$ //$NON-NLS-2$

    PA pa1 = __podam.manufacturePojo(PA.class);
    PaTypeCompteAcces paca1 = __podam.manufacturePojo(PaTypeCompteAcces.class);
    paca1.setEmailLogin("login1"); //$NON-NLS-1$
    pa1.setPaTypeCompteAcces(paca1);
    pa1.setTypePA(TypePA.COMPTE_ACCES.name());
    pa1.setStatut(Statut.ACTIF);

    PA pa2 = __podam.manufacturePojo(PA.class);
    PaTypeCompteAcces paca2 = __podam.manufacturePojo(PaTypeCompteAcces.class);
    paca2.setEmailLogin("login2"); //$NON-NLS-1$
    pa2.setPaTypeCompteAcces(paca2);
    pa2.setTypePA(TypePA.COMPTE_ACCES.name());
    pa2.setStatut(Statut.ACTIF);

    PA pa3 = __podam.manufacturePojo(PA.class);
    PaTypeCompteAccesSecondaire paca3 = __podam.manufacturePojo(PaTypeCompteAccesSecondaire.class);
    paca3.setLoginEmail("login3"); //$NON-NLS-1$
    pa3.setPaTypeCompteAccesSecondaire(paca3);
    pa3.setTypePA(TypePA.COMPTE_ACCES_SECONDAIRE.name());
    pa3.setStatut(Statut.ACTIF);

    PA pa4 = __podam.manufacturePojo(PA.class);
    PaTypeCompteAccesSecondaire paca4 = __podam.manufacturePojo(PaTypeCompteAccesSecondaire.class);
    paca4.setLoginEmail("login4"); //$NON-NLS-1$
    pa4.setPaTypeCompteAccesSecondaire(paca4);
    pa4.setTypePA(TypePA.COMPTE_ACCES_SECONDAIRE.name());
    pa4.setStatut(Statut.ACTIF);

    pfi.setPa(Arrays.asList(pa1, pa2, pa3, pa4));

    return pfi;
  }

  /**
   * Builds a ModificationCommerciale objetct
   *
   * @param clientOperateur_p
   *          The client operateur
   * @param noCompte_p
   *          The noCompte
   * @param identifiantFonctionnelPA_p
   *          The identifiantFonctionnelPA
   * @return The ModificationCommerciale
   */
  private com.bytel.spirit.common.shared.types.json.ModificationCommerciale prepareModificationCommerciale(final String clientOperateur_p, final String noCompte_p, final String identifiantFonctionnelPA_p)
  {
    com.bytel.spirit.common.shared.types.json.ModificationCommerciale modComm = new com.bytel.spirit.common.shared.types.json.ModificationCommerciale();
    modComm.setStatut(com.bytel.spirit.common.shared.saab.cmd.Statut.EN_COURS.name());
    modComm.setStatutCommercialAttendu(StatutCommercialAttendu.ACTIF.name());
    modComm.setIdentifiantFonctionnelPA(identifiantFonctionnelPA_p);
    modComm.setTypeObjetCommercial(TypeObjetCommercial.PA.name());
    modComm.setClientOperateur(clientOperateur_p);
    modComm.setNoCompte(noCompte_p);
    return modComm;
  }

}
