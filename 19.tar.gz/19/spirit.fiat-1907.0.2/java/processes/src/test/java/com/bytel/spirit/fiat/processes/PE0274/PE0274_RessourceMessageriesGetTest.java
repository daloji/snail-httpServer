/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.npbt.NPBT_SI037_RecupererNoContratParNoTelephone;
import com.bytel.spirit.common.activities.npbt.NPBT_SI037_RecupererNoContratParNoTelephone.NPBT_SI037_RecupererNoContratParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.npbt.NPBT_SI038_RecupererTypeVms;
import com.bytel.spirit.common.activities.npbt.NPBT_SI038_RecupererTypeVms.NPBT_SI038_RecupererTypeVmsBuilder;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail;
import com.bytel.spirit.common.activities.shared.BL3700_RecupererPfiParMail.BL3700_RecupererPfiParMailBuilder;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.BL5280_RecupererTypeAccesNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5280_RecupererTypeAccesNoTelephone.BL5280_RecupererTypeAccesNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.BL5290_RecupererTypeVms;
import com.bytel.spirit.common.activities.shared.BL5290_RecupererTypeVms.BL5290_RecupererTypeVmsBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL3700_Return;
import com.bytel.spirit.common.activities.shared.structs.BL5270_Return;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelleParameterizedType;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.ink.generated.Dataset;
import com.bytel.spirit.common.connectors.ink.generated.DatasetParam;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderDataResponse;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderResponse;
import com.bytel.spirit.common.connectors.str.structs.ResultContratEtPartition;
import com.bytel.spirit.common.shared.functional.types.json.AppelantInterdit;
import com.bytel.spirit.common.shared.functional.types.json.AppelantsInterditsPfs;
import com.bytel.spirit.common.shared.functional.types.json.Destinataire;
import com.bytel.spirit.common.shared.functional.types.json.DroitAccesADistancePfs;
import com.bytel.spirit.common.shared.functional.types.json.MessageriePfs;
import com.bytel.spirit.common.shared.functional.types.json.NotificationEmail;
import com.bytel.spirit.common.shared.functional.types.json.NotificationEmailPfs;
import com.bytel.spirit.common.shared.functional.types.json.NotificationSMS;
import com.bytel.spirit.common.shared.functional.types.json.NotificationSmsPfs;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.PE0274.PE0274_RessourceMessageries.QueryParameters;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL100GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL201GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL202GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL203GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_BL204GetReponse;
import com.bytel.spirit.fiat.processes.PE0274.sti.RessourceMessageries;
import com.bytel.spirit.fiat.processes.structs.XAction;
import com.bytel.spirit.fiat.processes.structs.XLink;

import io.netty.util.internal.StringUtil;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ ProcessManager.class, PE0274_RessourceMessageries.class, BL5290_RecupererTypeVmsBuilder.class, BL5290_RecupererTypeVms.class, BL5280_RecupererTypeAccesNoTelephone.class, BL5280_RecupererTypeAccesNoTelephoneBuilder.class, BL5270_RecupererPfiParNoTelephone.class, BL5270_RecupererPfiParNoTelephoneBuilder.class, PROV_SI002_ExecuterProcessusBuilder.class, NPBT_SI038_RecupererTypeVmsBuilder.class, NPBT_SI038_RecupererTypeVms.class, NPBT_SI037_RecupererNoContratParNoTelephone.class, NPBT_SI037_RecupererNoContratParNoTelephoneBuilder.class, BL3700_RecupererPfiParMail.class, BL3700_RecupererPfiParMailBuilder.class, PROV_SI002_ExecuterProcessus.class })
public class PE0274_RessourceMessageriesGetTest
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0274_RessourceMessageries"; //$NON-NLS-1$

  /**
   * Configuration path Param
   */
  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * The default value for the idMessagerie
   */
  private static final String DEFAULT_ID_MESSAGERIE = "10000530160#idMessageriePfs#VOIX#typePfs"; //$NON-NLS-1$

  /**
   * The default value for the noContrat
   */
  private static final String DEFAULT_NO_CONTRAT = "10000530160"; //$NON-NLS-1$

  /**
   * The default value for the noContrat
   */
  private static final String DEFAULT_NO_PARTION = "GP"; //$NON-NLS-1$

  /**
   * The default value for the noTelephone
   */
  private static final String DEFAULT_NO_TELEPHONE = "0123456789"; //$NON-NLS-1$

  /**
   * The default value for the adresseMail
   */
  private static final String DEFAULT_ADRESSE_MAIL = "someone@mail.com"; //$NON-NLS-1$

  /**
   * Default value for listeContrat
   */
  private static final String DEFAULT_LISTE_CONTRAT = "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"; //$NON-NLS-1$

  /**
   * VOIX
   */
  private static final String VOIX = "VOIX"; //$NON-NLS-1$

  /**
   * FAX
   */
  private static final String FAX = "FAX"; //$NON-NLS-1$

  /**
   * MAIL
   */
  private static final String MAIL = "MAIL"; //$NON-NLS-1$

  /**
   * FIXE
   */
  private static final String FIXE = "FIXE"; //$NON-NLS-1$

  /**
   * MOBILE
   */
  private static final String MOBILE = "MOBILE"; //$NON-NLS-1$

  /**
   * noTelephone
   */
  private static final String NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   * STW
   */
  private static final String STW = "STW"; //$NON-NLS-1$

  /**
   * nomDomaine
   */
  private static final String NOM_DOMAINE = "nomDomaine"; //$NON-NLS-1$

  /**
   * loginMail
   */
  private static final String ADRESSE_MAIL = "adresseMail"; //$NON-NLS-1$

  /**
   * ConfigurationPE0274
   */
  private static final String CONFIGURATION_PE0274_XML = "ConfigurationPE0274.xml"; //$NON-NLS-1$

  /**
   * noCompte
   */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   * clientOperateur
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * interdictions-depot-messages
   */
  private static final String INTERDICTIONS_DEPOT_MESSAGES = "interdictions-depot-messages"; //$NON-NLS-1$

  /**
   * notifications-email
   */
  private static final String NOTIFICATIONS_EMAIL = "notifications-email"; //$NON-NLS-1$

  /**
   * notifications-sms
   */
  private static final String NOTIFICATIONS_SMS = "notifications-sms"; //$NON-NLS-1$

  /**
   * messageries-a-distance
   */
  private static final String MESSAGERIES_A_DISTANCE = "messageries-a-distance"; //$NON-NLS-1$

  /**
   * messageries
   */
  private static final String MESSAGERIES = "messageries"; //$NON-NLS-1$

  /**
   * typePfs
   */
  private static final String TYPE_PFS = "typePfs"; //$NON-NLS-1$

  /**
   * idMessageriePfs
   */
  private static final String ID_MESSAGERIE_PFS = "idMessageriePfs"; //$NON-NLS-1$

  /**
   * MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE
   */
  private static final String MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE = "Service momentanement indisponible"; //$NON-NLS-1$

  /**
   * LIBELLE
   */
  private static final String LIBELLE = "libelle"; //$NON-NLS-1$

  /**
   * URL_LIGNES_TEL
   */
  private static final String URL_LIGNES_TEL = "/lignes-tel/"; //$NON-NLS-1$

  /**
   * URL_COMPTES_MAIL
   */
  private static final String URL_COMPTES_MAIL = "/comptes-mail/"; //$NON-NLS-1$

  /**
   * URL_INTERDICTIONS_DEPOT_MESSAGES
   */
  private static final String URL_INTERDICTIONS_DEPOT_MESSAGES = "/interdictions-depot-messages"; //$NON-NLS-1$

  /**
   * URL_MESSAGERIES_A_DISTANCE
   */
  private static final String URL_MESSAGERIES_A_DISTANCE = "/messageries-a-distance"; //$NON-NLS-1$

  /**
   * URL_NOTIFICATIONS_EMAIL
   */
  private static final String URL_NOTIFICATIONS_EMAIL = "/notifications-email"; //$NON-NLS-1$

  /**
   * URL_NOTIFICATIONS_SMS
   */
  private static final String URL_NOTIFICATIONS_SMS = "/notifications-sms"; //$NON-NLS-1$

  /**
   * URL_MESSAGERIES
   */
  private static final String URL_MESSAGERIES = "/messageries/"; //$NON-NLS-1$

  /**
   * URL_DEMAND_FAX
   */
  private static final String URL_DEMAND_FAX = "/demande-envoyer-fax"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_NOTIFICATION_EMAIL
   */
  private static final String PROCESS_CONSULTER_NOTIFICATION_EMAIL = "consulterNotificationEmail"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_NOTIFICATION_SMS
   */
  private static final String PROCESS_CONSULTER_NOTIFICATION_SMS = "consulterNotificationSMS"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_INTERDICTION_DEPOT
   */
  private static final String PROCESS_CONSULTER_INTERDICTION_DEPOT = "consulterInterdictionDepot"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_MESSAGERIE_VMS_PFS
   */
  private static final String PROCESS_CONSULTER_MESSAGERIE_VMS_PFS = "consulterMessagerieVmsPfs"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_MESSAGERIE_MAIL_PFS
   */
  private static final String PROCESS_CONSULTER_MESSAGERIE_MAIL_PFS = "consulterMessagerieMailPfs"; //$NON-NLS-1$

  /**
   * PROCESS_CONSULTER_MESSAGERIE_A_DISTANCE
   */
  private static final String PROCESS_CONSULTER_MESSAGERIE_A_DISTANCE = "consulterMessagerieADistance"; //$NON-NLS-1$

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    Parameter parameter = new Parameter();

    parameter.setName(name_p);
    parameter.setValue(value_p);

    return parameter;
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    try
    {
      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager is now initialized")); //$NON-NLS-1$
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager instance is already initialized")); //$NON-NLS-1$
    }

  }

  /**
   * Instance of {@link PE0274_RessourceMessageries}
   */
  private PE0274_RessourceMessageries _processInstance;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  ProcessManager _processManager;

  /**
   * Mock de {@link BL5280_RecupererTypeAccesNoTelephone}
   */
  @MockStrict
  BL5280_RecupererTypeAccesNoTelephone _bl5280Mock;

  /**
   * Mock de {@link BL5280_RecupererTypeAccesNoTelephoneBuilder}
   */
  @MockStrict
  BL5280_RecupererTypeAccesNoTelephoneBuilder _bl5280BuilderMock;

  /**
   * Mock de {@link BL5290_RecupererTypeVms}
   */
  @MockStrict
  BL5290_RecupererTypeVms _bl5290Mock;

  /**
   * Mock de {@link BL5290_RecupererTypeVmsBuilder}
   */
  @MockStrict
  BL5290_RecupererTypeVmsBuilder _bl5290BuilderMock;

  /**
   * Mock de {@link BL5270_RecupererPfiParNoTelephone}
   */
  @MockStrict
  BL5270_RecupererPfiParNoTelephone _bl5270Mock;

  /**
   * Mock de {@link BL5270_RecupererPfiParNoTelephoneBuilder}
   */
  @MockStrict
  BL5270_RecupererPfiParNoTelephoneBuilder _bl5270BuilderMock;

  /**
   * Mock de {@link NPBT_SI037_RecupererNoContratParNoTelephone}
   */
  @MockStrict
  NPBT_SI037_RecupererNoContratParNoTelephone _si037Mock;

  /**
   * Mock de {@link NPBT_SI037_RecupererNoContratParNoTelephoneBuilder}
   */
  @MockStrict
  NPBT_SI037_RecupererNoContratParNoTelephoneBuilder _si037BuilderMock;

  /**
   * Mock de {@link NPBT_SI038_RecupererTypeVms}
   */
  @MockStrict
  NPBT_SI038_RecupererTypeVms _si038Mock;

  /**
   * Mock de {@link NPBT_SI038_RecupererTypeVmsBuilder}
   */
  @MockStrict
  NPBT_SI038_RecupererTypeVmsBuilder _si038BuilderMock;

  /**
   * Mock de {@link BL3700_RecupererPfiParMail}
   */
  @MockStrict
  BL3700_RecupererPfiParMail _bl3700Mock;

  /**
   * Mock de {@link BL3700_RecupererPfiParMailBuilder}
   */
  @MockStrict
  BL3700_RecupererPfiParMailBuilder _bl3700BuilderMock;

  /**
   * PROV_SI002_ExecuterProcessusBuilder
   */
  @MockStrict
  PROV_SI002_ExecuterProcessusBuilder _si002BuilderMock;

  /**
   * PROV_SI002_ExecuterProcessus
   */
  @MockStrict
  PROV_SI002_ExecuterProcessus _si002Mock;

  /**
   * Missing config files.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesConsultation_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(null, null);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(3);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).times(3);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegConsts.CONFIGURATION_INVALIDE);
    responseErreeurExpected.setErrorDescription("Cannot find param FILE_PATH in process configuration"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Configuration File error.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesConsultation_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "someFile"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegConsts.CONFIGURATION_INVALIDE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertTrue("Description does not start with <Fichier de configuration en erreur...>", reponseactual.getErrorDescription().startsWith("Fichier de configuration en erreur")); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertTrue("Description does not end with <...java" + File.separator + "processes" + File.separator + "target" + File.separator + "test-classes" + File.separator + "someFile>", reponseactual.getErrorDescription().endsWith("java" + File.separator + "processes" + File.separator + "target" + File.separator + "test-classes" + File.separator + "someFile")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$

  }

  /**
   * No X_REQUEST_ID Header.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesConsultation_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);
    //remove X_REQUEST_ID header
    request.getRequestHeader().remove(createHeader(IHttpHeadersConsts.X_REQUEST_ID, _tracabilite.getIdCorrelationByTel()));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Header X-Request-Id null ou vide."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Case listerMessagerie(VOIX), no noTelephone.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesConsultation_KO_004() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("QueryParameter is missing."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Case listerMessagerie(VOIX), empty noTelephone.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesConsultation_KO_005() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), StringConstants.EMPTY_STRING);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter noTelephone is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Case listerMessagerie(MAIL), no adresseMail.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesConsultation_KO_006() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("QueryParameter is missing."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Case listerMessagerie(MAIL), empty adresseMail.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesConsultation_KO_007() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.ADRESSE_MAIL.getParamName(), StringConstants.EMPTY_STRING);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter adresseMail is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Case lireInterdictionDepotMessage, no idMessagerie.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesConsultation_KO_008() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter idMessagerie is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Case lireNotificationEmail, no idMessagerie.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesConsultation_KO_009() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter idMessagerie is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Case lireMessagerieADistance, no idMessagerie.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesConsultation_KO_010() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter idMessagerie is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX BL5280 returns KO.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);

    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, LIBELLE);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(ko, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Numero Telephone " + DEFAULT_NO_TELEPHONE + " non conforme"); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX BL5270 returns KO|CAT4|DONNEE_INCONNUE.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);

    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, LIBELLE);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), FIXE);
    expectBL5270(ko, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NO_TELEPHONE_INCONNU);
    responseErreeurExpected.setErrorDescription("le numero telephone " + DEFAULT_NO_TELEPHONE + " est inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX SI037 returns KO|CAT1.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, DEFAULT_NO_TELEPHONE, null);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);

    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, LIBELLE);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), MOBILE);
    expectSI037(ko, null, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case MAIL BL3700 returns KO|CAT4|DONNEE_INCONNUE.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_004() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.ADRESSE_MAIL.getParamName(), DEFAULT_ADRESSE_MAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, LIBELLE);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL3700(ko, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ADRESSE_MAIL_INCONNU);
    responseErreeurExpected.setErrorDescription("l'adresseMail " + DEFAULT_ADRESSE_MAIL + " est inconnue"); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case MAIL BL3700 returns KO|CAT1|.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_005() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.ADRESSE_MAIL.getParamName(), DEFAULT_ADRESSE_MAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, LIBELLE);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL3700(ko, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case MAIL.<br/>
   * adresseMailOauth = null.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = null.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_006() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.ADRESSE_MAIL.getParamName(), DEFAULT_ADRESSE_MAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL3700(RetourFactoryForTU.createOkRetour(), new BL3700_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT)); //)

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreeurExpected.setErrorDescription("Accès refuse"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case MAIL.<br/>
   * adresseMailOauth = other@mail.com.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * BL3700 returns noContrat=noContrat (not in listeContratOauth)
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_007() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.getRequestHeader().add(createHeader(IHttpHeadersConsts.X_OAUTH2_LOGIN, "other@mail.fr")); //$NON-NLS-1$
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.ADRESSE_MAIL.getParamName(), DEFAULT_ADRESSE_MAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL3700(RetourFactoryForTU.createOkRetour(), new BL3700_Return(CLIENT_OPERATEUR, NO_COMPTE, "noContrat")); //); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreeurExpected.setErrorDescription("Accès refuse"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case MAIL.<br/>
   * adresseMailOauth = other@mail.com.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * BL3700 returns OK-("clientOperateur", "noCompte", "10000530160").<br/>
   * SI002 returns KO|CAT1.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_008() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.getRequestHeader().add(createHeader(IHttpHeadersConsts.X_OAUTH2_LOGIN, "other@bbox.fr")); //$NON-NLS-1$
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.ADRESSE_MAIL.getParamName(), DEFAULT_ADRESSE_MAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL3700(RetourFactoryForTU.createOkRetour(), new BL3700_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT));

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ADRESSE_MAIL, "other"); //$NON-NLS-1$
    listeParametres.add(NOM_DOMAINE, "bbox.fr"); //$NON-NLS-1$

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_MAIL_PFS, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, LIBELLE), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns KO|CAT2.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_009() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, DEFAULT_NO_TELEPHONE, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), FIXE);
    expectBL5270(RetourFactoryForTU.createOkRetour(), new BL5270_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT));

    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, LIBELLE);
    expectBL5290(ko, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns KO|CAT3.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_010() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, DEFAULT_NO_TELEPHONE, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), FIXE);
    expectBL5270(RetourFactoryForTU.createOkRetour(), new BL5270_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT));

    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, LIBELLE);
    expectBL5290(ko, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns KO|CAT2.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_011() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, DEFAULT_NO_TELEPHONE, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), FIXE);
    expectBL5270(RetourFactoryForTU.createOkRetour(), new BL5270_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT));
    expectBL5290(RetourFactoryForTU.createOkRetour(), "STW"); //$NON-NLS-1$

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(NO_TELEPHONE, DEFAULT_NO_TELEPHONE);
    listeParametres.add(TYPE_PFS, STW);

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_VMS_PFS, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT2, StringConstants.EMPTY_STRING, LIBELLE), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreeurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns KO|CAT3.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_012() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, DEFAULT_NO_TELEPHONE, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), FIXE);
    expectBL5270(RetourFactoryForTU.createOkRetour(), new BL5270_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT));
    expectBL5290(RetourFactoryForTU.createOkRetour(), "STW"); //$NON-NLS-1$

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(NO_TELEPHONE, DEFAULT_NO_TELEPHONE);
    listeParametres.add(TYPE_PFS, STW);

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_VMS_PFS, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, LIBELLE), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.DONNEE_INVALIDE);
    responseErreeurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns KO|CAT3. BL5290 returns CAT-4 with DONNEE_INCONNUE
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_KO_013() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, DEFAULT_NO_TELEPHONE, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), FIXE);
    expectBL5270(RetourFactoryForTU.createOkRetour(), new BL5270_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT));

    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, LIBELLE);
    expectBL5290(ko, null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NO_TELEPHONE_INCONNU);
    responseErreeurExpected.setErrorDescription("le numero telephone " + DEFAULT_NO_TELEPHONE + " est inconnu"); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * BL5280 returns FIXE.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), FIXE);
    expectBL5270(RetourFactoryForTU.createOkRetour(), new BL5270_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT));
    expectBL5290(RetourFactoryForTU.createOkRetour(), "STW"); //$NON-NLS-1$

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(NO_TELEPHONE, DEFAULT_NO_TELEPHONE);
    listeParametres.add(TYPE_PFS, STW);

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_VMS_PFS, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorMessagerie(VOIX));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    RessourceMessageries ressourceMessageries1 = new RessourceMessageries(createMessageriePfs(1, VOIX));
    ressourceMessageries1.setIdMessagerie(PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs1#VOIX#typePfs")); //$NON-NLS-1$
    RessourceMessageries ressourceMessageries2 = new RessourceMessageries(createMessageriePfs(2, VOIX));
    ressourceMessageries2.setIdMessagerie(PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs2#VOIX#typePfs")); //$NON-NLS-1$
    PE0274_BL100GetReponse expectedResponse = new PE0274_BL100GetReponse();
    expectedResponse.setItems(Arrays.asList(ressourceMessageries1, ressourceMessageries2));
    expectedResponse.setResultsCount(2);
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL100GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * BL5280 returns MOBILE.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_OK_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), MOBILE);
    expectSI037(RetourFactoryForTU.createOkRetour(), DEFAULT_NO_CONTRAT, DEFAULT_NO_PARTION);
    expectSI038(RetourFactoryForTU.createOkRetour(), STW);

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(NO_TELEPHONE, DEFAULT_NO_TELEPHONE);
    listeParametres.add(TYPE_PFS, STW);

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_VMS_PFS, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorMessagerie(VOIX));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    RessourceMessageries ressourceMessageries1 = new RessourceMessageries(createMessageriePfs(1, VOIX));
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs1#VOIX#typePfs"); //$NON-NLS-1$
    ressourceMessageries1.setIdMessagerie(encryptedIdMessagerie);
    ressourceMessageries1.putLink("lireAnnoncesAccueil", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/annonces-accueil/caracteristiques")); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries1.putLink("lireNotificationsEmail", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_EMAIL)); //$NON-NLS-1$
    ressourceMessageries1.putLink("lireMessages", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/messages")); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries1.putLink("lireInterdictionsDepot", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_INTERDICTIONS_DEPOT_MESSAGES)); //$NON-NLS-1$
    ressourceMessageries1.putLink("lireMessageriesADistance", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_MESSAGERIES_A_DISTANCE)); //$NON-NLS-1$
    ressourceMessageries1.putAction("modifierStatutsMessagerie", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + "/statut", MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries1.putLink(XLink.SELF, new XLink(URL_LIGNES_TEL + DEFAULT_NO_TELEPHONE + "/messageries")); //$NON-NLS-1$

    RessourceMessageries ressourceMessageries2 = new RessourceMessageries(createMessageriePfs(2, VOIX));
    encryptedIdMessagerie = PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs2#VOIX#typePfs"); //$NON-NLS-1$
    ressourceMessageries2.setIdMessagerie(encryptedIdMessagerie);
    ressourceMessageries2.putLink("lireAnnoncesAccueil", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/annonces-accueil/caracteristiques")); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries2.putLink("lireNotificationsEmail", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_EMAIL)); //$NON-NLS-1$
    ressourceMessageries2.putLink("lireMessages", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/messages")); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries2.putLink("lireInterdictionsDepot", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_INTERDICTIONS_DEPOT_MESSAGES)); //$NON-NLS-1$
    ressourceMessageries2.putLink("lireMessageriesADistance", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_MESSAGERIES_A_DISTANCE)); //$NON-NLS-1$
    ressourceMessageries2.putAction("modifierStatutsMessagerie", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + "/statut", MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries2.putLink(XLink.SELF, new XLink(URL_LIGNES_TEL + DEFAULT_NO_TELEPHONE + "/messageries")); //$NON-NLS-1$
    PE0274_BL100GetReponse expectedResponse = new PE0274_BL100GetReponse();
    expectedResponse.setItems(Arrays.asList(ressourceMessageries1, ressourceMessageries2));
    expectedResponse.setResultsCount(2);
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL100GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL100_ListerMessagerie case VOIX.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * BL5280 returns MOBILE.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_OK_002Bis() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), MOBILE);
    expectSI037(RetourFactoryForTU.createOkRetour(), DEFAULT_NO_CONTRAT, DEFAULT_NO_PARTION);
    expectSI038(RetourFactoryForTU.createOkRetour(), "CVG"); //$NON-NLS-1$

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(NO_TELEPHONE, DEFAULT_NO_TELEPHONE);
    listeParametres.add(TYPE_PFS, "CVG"); //$NON-NLS-1$

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_VMS_PFS, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorMessagerie(VOIX));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    RessourceMessageries ressourceMessageries1 = new RessourceMessageries(createMessageriePfs(1, VOIX));
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs1#VOIX#typePfs"); //$NON-NLS-1$
    ressourceMessageries1.setIdMessagerie(encryptedIdMessagerie);
    ressourceMessageries1.putLink("lireAnnoncesAccueil", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/annonces-accueil/caracteristiques")); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries1.putLink("lireNotificationsEmail", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_EMAIL)); //$NON-NLS-1$
    ressourceMessageries1.putLink("lireMessages", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/messages")); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries1.putLink("lireInterdictionsDepot", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_INTERDICTIONS_DEPOT_MESSAGES)); //$NON-NLS-1$
    ressourceMessageries1.putLink("lireMessageriesADistance", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_MESSAGERIES_A_DISTANCE)); //$NON-NLS-1$
    ressourceMessageries1.putAction("reinitialiserCodePin", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + "/pin?action=reinitialiserCodePin", MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries1.putAction("modifierStatutsMessagerie", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + "/statut", MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries1.putLink(XLink.SELF, new XLink(URL_LIGNES_TEL + DEFAULT_NO_TELEPHONE + "/messageries")); //$NON-NLS-1$

    RessourceMessageries ressourceMessageries2 = new RessourceMessageries(createMessageriePfs(2, VOIX));
    encryptedIdMessagerie = PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs2#VOIX#typePfs"); //$NON-NLS-1$
    ressourceMessageries2.setIdMessagerie(encryptedIdMessagerie);
    ressourceMessageries2.putLink("lireAnnoncesAccueil", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/annonces-accueil/caracteristiques")); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries2.putLink("lireNotificationsEmail", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_EMAIL)); //$NON-NLS-1$
    ressourceMessageries2.putLink("lireMessages", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/messages")); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries2.putLink("lireInterdictionsDepot", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_INTERDICTIONS_DEPOT_MESSAGES)); //$NON-NLS-1$
    ressourceMessageries2.putLink("lireMessageriesADistance", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_MESSAGERIES_A_DISTANCE)); //$NON-NLS-1$
    ressourceMessageries2.putAction("reinitialiserCodePin", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + "/pin?action=reinitialiserCodePin", MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries2.putAction("modifierStatutsMessagerie", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + "/statut", MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries2.putLink(XLink.SELF, new XLink(URL_LIGNES_TEL + DEFAULT_NO_TELEPHONE + "/messageries")); //$NON-NLS-1$
    PE0274_BL100GetReponse expectedResponse = new PE0274_BL100GetReponse();
    expectedResponse.setItems(Arrays.asList(ressourceMessageries1, ressourceMessageries2));
    expectedResponse.setResultsCount(2);
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL100GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL100_ListerMessagerie case MAIL.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_OK_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.ADRESSE_MAIL.getParamName(), DEFAULT_ADRESSE_MAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL3700(RetourFactoryForTU.createOkRetour(), new BL3700_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT));

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ADRESSE_MAIL, "someone"); //$NON-NLS-1$
    listeParametres.add(NOM_DOMAINE, "mail.com"); //$NON-NLS-1$

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_MAIL_PFS, //
        listeParametres, RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorMessagerie(MAIL));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    RessourceMessageries ressourceMessageries1 = new RessourceMessageries(createMessageriePfs(1, MAIL));
    ressourceMessageries1.setIdMessagerie(PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs1#MAIL#typePfs")); //$NON-NLS-1$
    RessourceMessageries ressourceMessageries2 = new RessourceMessageries(createMessageriePfs(2, MAIL));
    ressourceMessageries2.setIdMessagerie(PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs2#MAIL#typePfs")); //$NON-NLS-1$
    PE0274_BL100GetReponse expectedResponse = new PE0274_BL100GetReponse();
    expectedResponse.setItems(Arrays.asList(ressourceMessageries1, ressourceMessageries2));
    expectedResponse.setResultsCount(2);
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL100GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL100_ListerMessagerie case MAIL.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_OK_004() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.ADRESSE_MAIL.getParamName(), DEFAULT_ADRESSE_MAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL3700(RetourFactoryForTU.createOkRetour(), new BL3700_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT));

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ADRESSE_MAIL, "someone"); //$NON-NLS-1$
    listeParametres.add(NOM_DOMAINE, "mail.com"); //$NON-NLS-1$

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_MAIL_PFS, //
        listeParametres, RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorMessagerie(MAIL));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    RessourceMessageries ressourceMessageries1 = new RessourceMessageries(createMessageriePfs(1, MAIL));
    ressourceMessageries1.setIdMessagerie(PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs1#MAIL#typePfs")); //$NON-NLS-1$
    ressourceMessageries1.putLink(XLink.SELF, new XLink(URL_COMPTES_MAIL + DEFAULT_ADRESSE_MAIL + "/messageries")); //$NON-NLS-1$
    RessourceMessageries ressourceMessageries2 = new RessourceMessageries(createMessageriePfs(2, MAIL));
    ressourceMessageries2.setIdMessagerie(PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs2#MAIL#typePfs")); //$NON-NLS-1$
    ressourceMessageries2.putLink(XLink.SELF, new XLink(URL_COMPTES_MAIL + DEFAULT_ADRESSE_MAIL + "/messageries")); //$NON-NLS-1$
    PE0274_BL100GetReponse expectedResponse = new PE0274_BL100GetReponse();
    expectedResponse.setItems(Arrays.asList(ressourceMessageries1, ressourceMessageries2));
    expectedResponse.setResultsCount(2);
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL100GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL100_ListerMessagerie case FAX.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL100_OK_005() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES);
    setQueryParam(request, QueryParameters.NO_TELEPHONE.getParamName(), DEFAULT_NO_TELEPHONE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    expectBL5280(RetourFactoryForTU.createOkRetour(), FIXE);
    expectBL5270(RetourFactoryForTU.createOkRetour(), new BL5270_Return(CLIENT_OPERATEUR, NO_COMPTE, DEFAULT_NO_CONTRAT));
    expectBL5290(RetourFactoryForTU.createOkRetour(), "STW"); //$NON-NLS-1$

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(NO_TELEPHONE, DEFAULT_NO_TELEPHONE);
    listeParametres.add(TYPE_PFS, STW);

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_VMS_PFS, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorMessagerie(FAX));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    RessourceMessageries ressourceMessageries1 = new RessourceMessageries(createMessageriePfs(1, FAX));
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs1#FAX#typePfs"); //$NON-NLS-1$
    ressourceMessageries1.setIdMessagerie(encryptedIdMessagerie);
    ressourceMessageries1.putLink("lireNotificationsEmail", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_EMAIL)); //$NON-NLS-1$
    ressourceMessageries1.putLink("lireNotificationsSMS", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_SMS)); //$NON-NLS-1$
    ressourceMessageries1.putLink("lireMessages", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/messages")); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries1.putAction("demandeEnvoyerFax", new XAction(URL_DEMAND_FAX, MediaType.APPLICATION_JSON, HttpConstants.POST_METHOD)); //$NON-NLS-1$
    ressourceMessageries1.putLink(XLink.SELF, new XLink(URL_LIGNES_TEL + DEFAULT_NO_TELEPHONE + "/messageries")); //$NON-NLS-1$

    RessourceMessageries ressourceMessageries2 = new RessourceMessageries(createMessageriePfs(2, FAX));
    encryptedIdMessagerie = PasswordEncrypter.encryptForURL("10000530160#idMessageriePfs2#FAX#typePfs"); //$NON-NLS-1$
    ressourceMessageries2.setIdMessagerie(encryptedIdMessagerie);
    ressourceMessageries2.putLink("lireNotificationsEmail", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_EMAIL)); //$NON-NLS-1$
    ressourceMessageries2.putLink("lireNotificationsSMS", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_SMS)); //$NON-NLS-1$
    ressourceMessageries2.putLink("lireMessages", new XLink(URL_MESSAGERIES + encryptedIdMessagerie + "/messages")); //$NON-NLS-1$ //$NON-NLS-2$
    ressourceMessageries2.putAction("demandeEnvoyerFax", new XAction(URL_DEMAND_FAX, MediaType.APPLICATION_JSON, HttpConstants.POST_METHOD)); //$NON-NLS-1$
    ressourceMessageries2.putLink(XLink.SELF, new XLink(URL_LIGNES_TEL + DEFAULT_NO_TELEPHONE + "/messageries")); //$NON-NLS-1$

    PE0274_BL100GetReponse expectedResponse = new PE0274_BL100GetReponse();
    expectedResponse.setItems(Arrays.asList(ressourceMessageries1, ressourceMessageries2));
    expectedResponse.setResultsCount(2);
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL100GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL200_LireOptionsMessagerie.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * invalid idMessagerie.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL200_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, "randomString", DEFAULT_LISTE_CONTRAT); //$NON-NLS-1$
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ID_MESSAGERIE_INCONNU);
    responseErreeurExpected.setErrorDescription("l'id Messagerie randomString est inconnu."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL200_LireOptionsMessagerie.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = null.<br/>
   * invalid idMessagerie (parametresMessagerie.length == 5)
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL200_KO_002() throws Throwable
  {
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL("10000530140#idMessageriePfs#MAIL#typePfs#asd"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedIdMessagerie, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ID_MESSAGERIE_INCONNU);
    responseErreeurExpected.setErrorDescription("l'id Messagerie " + encryptedIdMessagerie + " est inconnu."); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL200_LireOptionsMessagerie.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = null.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL200_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreeurExpected.setErrorDescription("Accès refuse"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL200_LireOptionsMessagerie.<br/>
   * modeAppel=B2R.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL200_KO_004() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL("10000530140#idMessageriePfs#typeMessagerie#typePfs"), DEFAULT_LISTE_CONTRAT); //$NON-NLS-1$
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreeurExpected.setErrorDescription("Accès refuse"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL200_LireOptionsMessagerie.<br/>
   * modeAppel=DIRECT.<br/>
   * autorisation == null.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL200_KO_005() throws Throwable
  {
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL("10000530140#idMessageriePfs#typeMessagerie#typePfs"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedIdMessagerie, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Operation non Autorisée sur la messagerie " + encryptedIdMessagerie); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL201_LireOptionMessagerieADistance.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-1
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL201_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_A_DISTANCE, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL201_LireOptionMessagerieADistance.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-2
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL201_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_A_DISTANCE, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT2, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL201_LireOptionMessagerieADistance.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-3|DONNEE_INVALIDE|libelle
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL201_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_A_DISTANCE, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, LIBELLE), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.DONNEE_INVALIDE);
    responseErreeurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL201_LireOptionMessagerieADistance.<br/>
   * modeAppel=DIRECT.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL201_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_A_DISTANCE, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorDroitAccesADistancePfs());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Destinataire destinataire = new Destinataire(DEFAULT_NO_TELEPHONE);
    Destinataire destinataire2 = new Destinataire(DEFAULT_NO_TELEPHONE + "2"); //$NON-NLS-1$

    PE0274_BL201GetReponse expectedResponse = new PE0274_BL201GetReponse();
    expectedResponse.setDestinataires(Arrays.asList(destinataire, destinataire2));
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL201GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL201_LireOptionMessagerieADistance.<br/>
   * modeAppel=B2R.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL201_OK_002() throws Throwable
  {
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE);
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedIdMessagerie, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_MESSAGERIE_A_DISTANCE, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorDroitAccesADistancePfs());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Destinataire destinataire = new Destinataire(DEFAULT_NO_TELEPHONE);
    Destinataire destinataire2 = new Destinataire(DEFAULT_NO_TELEPHONE + "2"); //$NON-NLS-1$

    PE0274_BL201GetReponse expectedResponse = new PE0274_BL201GetReponse();
    expectedResponse.setDestinataires(Arrays.asList(destinataire, destinataire2));
    expectedResponse.putLink(XLink.SELF, new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_MESSAGERIES_A_DISTANCE));
    expectedResponse.putAction("modifierConsultationADistance", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + URL_MESSAGERIES_A_DISTANCE, MediaType.APPLICATION_JSON, HttpMethod.PUT)); //$NON-NLS-1$
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL201GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL202_LireOptionInterdictionDepotMessage.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-1
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL202_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_INTERDICTION_DEPOT, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL202_LireOptionInterdictionDepotMessage.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-2
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL202_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_INTERDICTION_DEPOT, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT2, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL202_LireOptionInterdictionDepotMessage.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-3|DONNEE_INVALIDE|libelle
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL202_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_INTERDICTION_DEPOT, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, LIBELLE), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.DONNEE_INVALIDE);
    responseErreeurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL202_LireOptionInterdictionDepotMessage.<br/>
   * modeAppel=DIRECT.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL202_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_INTERDICTION_DEPOT, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorAppelantsInterditsPfs());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    AppelantInterdit appelantInterdit = new AppelantInterdit(DEFAULT_NO_TELEPHONE, "nom1"); //$NON-NLS-1$
    AppelantInterdit appelantInterdit2 = new AppelantInterdit(DEFAULT_NO_TELEPHONE + "2", "nom2"); //$NON-NLS-1$ //$NON-NLS-2$

    PE0274_BL202GetReponse expectedResponse = new PE0274_BL202GetReponse();
    expectedResponse.setAppelantsInterdits(Arrays.asList(appelantInterdit, appelantInterdit2));
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL202GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL202_LireOptionInterdictionDepotMessage.<br/>
   * modeAppel=B2R.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL202_OK_002() throws Throwable
  {
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE);
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedIdMessagerie, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_INTERDICTION_DEPOT, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorAppelantsInterditsPfs());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    AppelantInterdit appelantInterdit = new AppelantInterdit(DEFAULT_NO_TELEPHONE, "nom1"); //$NON-NLS-1$
    AppelantInterdit appelantInterdit2 = new AppelantInterdit(DEFAULT_NO_TELEPHONE + "2", "nom2"); //$NON-NLS-1$ //$NON-NLS-2$

    PE0274_BL202GetReponse expectedResponse = new PE0274_BL202GetReponse();
    expectedResponse.setAppelantsInterdits(Arrays.asList(appelantInterdit, appelantInterdit2));
    expectedResponse.putLink(XLink.SELF, new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_INTERDICTIONS_DEPOT_MESSAGES));
    expectedResponse.putAction("modifierInterdictionsDepotMessages", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + URL_INTERDICTIONS_DEPOT_MESSAGES, MediaType.APPLICATION_JSON, HttpMethod.PUT)); //$NON-NLS-1$
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL202GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL203_LireOptionNotificationEmail.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-1
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL203_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_NOTIFICATION_EMAIL, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL203_LireOptionNotificationEmail.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-2
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL203_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_NOTIFICATION_EMAIL, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT2, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL203_LireOptionNotificationEmail.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-3|DONNEE_INVALIDE|libelle
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL203_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_NOTIFICATION_EMAIL, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, LIBELLE), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.DONNEE_INVALIDE);
    responseErreeurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL203_LireOptionNotificationEmail.<br/>
   * modeAppel=DIRECT.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL203_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_NOTIFICATION_EMAIL, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorNotificationEmailPfs());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    NotificationEmail notificationEmail = new NotificationEmail("email1", true, true); //$NON-NLS-1$
    NotificationEmail notificationEmail2 = new NotificationEmail("email2", false, false); //$NON-NLS-1$

    PE0274_BL203GetReponse expectedResponse = new PE0274_BL203GetReponse();
    expectedResponse.setStatutNotificationsEmail("ACTIF"); //$NON-NLS-1$
    expectedResponse.setNotificationsEmail(Arrays.asList(notificationEmail, notificationEmail2));
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL203GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL203_LireOptionNotificationEmail.<br/>
   * modeAppel=B2R.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL203_OK_002() throws Throwable
  {
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE);
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedIdMessagerie, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_NOTIFICATION_EMAIL, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorNotificationEmailPfs());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    NotificationEmail notificationEmail = new NotificationEmail("email1", true, true); //$NON-NLS-1$
    NotificationEmail notificationEmail2 = new NotificationEmail("email2", false, false); //$NON-NLS-1$

    PE0274_BL203GetReponse expectedResponse = new PE0274_BL203GetReponse();
    expectedResponse.setStatutNotificationsEmail("ACTIF"); //$NON-NLS-1$
    expectedResponse.setNotificationsEmail(Arrays.asList(notificationEmail, notificationEmail2));
    expectedResponse.putLink(XLink.SELF, new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_EMAIL));
    expectedResponse.putAction("modifierNotificationsEmail", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_EMAIL, MediaType.APPLICATION_JSON, HttpMethod.PUT)); //$NON-NLS-1$
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL203GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL204_ LireOptionNotificationSMS.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-1
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL204_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_SMS);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_NOTIFICATION_SMS, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL204_ LireOptionNotificationSMS.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-2
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL204_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_SMS);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_NOTIFICATION_SMS, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT2, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL204_ LireOptionNotificationSMS.<br/>
   * modeAppel=DIRECT.<br/>
   * listeContratOauth_o = DEFAULT_LISTE_CONTRAT.<br/>
   * SI002 returns NOK|CAT-3|DONNEE_INVALIDE|libelle
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL204_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_SMS);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_NOTIFICATION_SMS, //
        listeParametres, //
        RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.DONNEE_INVALIDE, LIBELLE), //
        null);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.DONNEE_INVALIDE);
    responseErreeurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0274_BL204_ LireOptionNotificationSMS.<br/>
   * modeAppel=DIRECT.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL204_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_SMS);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_NOTIFICATION_SMS, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorNotificationSmsPfs());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    NotificationSMS notificationSMS = new NotificationSMS("noTel"); //$NON-NLS-1$
    NotificationSMS notificationSMS2 = new NotificationSMS("noTel2"); //$NON-NLS-1$

    PE0274_BL204GetReponse expectedResponse = new PE0274_BL204GetReponse();
    expectedResponse.setStatutNotificationsSMS("ACTIF"); //$NON-NLS-1$
    expectedResponse.setNotificationsSMS(Arrays.asList(notificationSMS, notificationSMS2));
    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL204GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * PE0274_BL204_ LireOptionNotificationSMS.<br/>
   * modeAppel=B2R.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL204_OK_002() throws Throwable
  {
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE);
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedIdMessagerie, DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_SMS);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(PROCESS_CONSULTER_NOTIFICATION_SMS, //
        listeParametres, //
        RetourFactoryForTU.createOkRetour(), //
        createResponseConnectorNotificationSmsPfs());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    NotificationSMS notificationSMS = new NotificationSMS("noTel"); //$NON-NLS-1$
    NotificationSMS notificationSMS2 = new NotificationSMS("noTel2"); //$NON-NLS-1$

    PE0274_BL204GetReponse expectedResponse = new PE0274_BL204GetReponse();
    expectedResponse.setStatutNotificationsSMS("ACTIF"); //$NON-NLS-1$
    expectedResponse.setNotificationsSMS(Arrays.asList(notificationSMS, notificationSMS2));
    expectedResponse.putAction("modifierStatutMessagerie", new XAction(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_SMS, MediaType.APPLICATION_JSON, HttpConstants.PUT_METHOD)); //$NON-NLS-1$
    expectedResponse.putLink(XLink.SELF, new XLink(URL_MESSAGERIES + encryptedIdMessagerie + URL_NOTIFICATIONS_SMS));

    Assert.assertEquals(expectedResponse, RavelJsonTools.getInstance().fromJson(response.getGenericResponse().getResult(), PE0274_BL204GetReponse.class));

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PE0274_RessourceMessageries();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setNomProcessus(DEFAULT_PROCESSNAME);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStaticStrict(BL5290_RecupererTypeVms.class);
    PowerMock.mockStaticStrict(BL5290_RecupererTypeVmsBuilder.class);
    PowerMock.mockStaticStrict(BL5280_RecupererTypeAccesNoTelephone.class);
    PowerMock.mockStaticStrict(BL5280_RecupererTypeAccesNoTelephoneBuilder.class);
    PowerMock.mockStaticStrict(BL5270_RecupererPfiParNoTelephone.class);
    PowerMock.mockStaticStrict(BL5270_RecupererPfiParNoTelephoneBuilder.class);
    PowerMock.mockStaticStrict(NPBT_SI037_RecupererNoContratParNoTelephone.class);
    PowerMock.mockStaticStrict(NPBT_SI037_RecupererNoContratParNoTelephoneBuilder.class);
    PowerMock.mockStaticStrict(NPBT_SI038_RecupererTypeVms.class);
    PowerMock.mockStaticStrict(NPBT_SI038_RecupererTypeVmsBuilder.class);
    PowerMock.mockStaticStrict(BL3700_RecupererPfiParMail.class);
    PowerMock.mockStaticStrict(BL3700_RecupererPfiParMailBuilder.class);
    PowerMock.mockStaticStrict(PROV_SI002_ExecuterProcessus.class);
    PowerMock.mockStaticStrict(PROV_SI002_ExecuterProcessusBuilder.class);
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   *
   *
   * @param listeContract_p
   *          listeContract
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p, String listeContract_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("ClientOperateur"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
    hdr.setValue("Authorization : bearer XXXX"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue(listeContract_p);
    requestHeader_p.add(hdr);
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Create a messageriePfs Object
   *
   * @param index_p
   *          number used for creation of several objects
   * @param typeMessagerie_p
   *          typeMessagerie
   * @return {@link MessageriePfs}
   */
  private MessageriePfs createMessageriePfs(int index_p, String typeMessagerie_p)
  {
    MessageriePfs messageriePfs = new MessageriePfs();
    messageriePfs.setIdMessageriePfs(ID_MESSAGERIE_PFS + index_p);
    messageriePfs.setTypePfs(TYPE_PFS);
    messageriePfs.setTypeMessagerie(typeMessagerie_p);
    messageriePfs.setNombreMessagesNonLus(1);
    messageriePfs.setStatutMessagerie("ACTIF"); //$NON-NLS-1$
    if (VOIX.equals(typeMessagerie_p))
    {
      messageriePfs.setDureeMaximaleMessageAccueil("PT01H00M10S"); //$NON-NLS-1$
      messageriePfs.setDureeMaximaleMessageDepose("PT01H00M10S"); //$NON-NLS-1$
      messageriePfs.setNombreMaximalMessageAutorise(10);
      messageriePfs.setDureeMaximaleSauvegardeMessagesNonLus("PT01H00M10S"); //$NON-NLS-1$
      messageriePfs.setDureeMaximaleSauvegardeMessagesLus("PT01H00M10S"); //$NON-NLS-1$
    }
    return messageriePfs;
  }

  /**
   * @param key_p
   *          The key
   * @param value_p
   *          The value
   * @return process params
   */
  private ConcurrentHashMap<String, Map<String, String>> createProcessParams(String key_p, String value_p)
  {
    File classpath = new File(PE0274_RessourceMessageriesGetTest.class.getResource("/").getFile()); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    if (!StringUtil.isNullOrEmpty(key_p))
    {
      map.put(key_p, classpath + "/" + value_p); //$NON-NLS-1$
    }

    processParams.put(StringConstants.EMPTY_STRING, map);
    return processParams;
  }

  /**
   * Create Response connector with list type AppelantsInterditsPfs
   *
   * @return ResponseConnector
   * @throws RavelException
   *           on error
   */
  private ResponseConnector createResponseConnectorAppelantsInterditsPfs() throws RavelException
  {
    ReponseFonctionnelle<AppelantsInterditsPfs> reponseFonctionnelle = new ReponseFonctionnelle<>();
    reponseFonctionnelle.setItems( //
        Arrays.asList(new AppelantsInterditsPfs( //
            Arrays.asList( //
                new AppelantInterdit(DEFAULT_NO_TELEPHONE, "nom1"), //$NON-NLS-1$
                new AppelantInterdit(DEFAULT_NO_TELEPHONE + "2", "nom2"))))); //$NON-NLS-1$ //$NON-NLS-2$
    reponseFonctionnelle.setResultsCount(1);

    String result = RavelJsonTools.getInstance().toJson(reponseFonctionnelle, new ReponseFonctionnelleParameterizedType<>(AppelantsInterditsPfs.class));

    com.bytel.spirit.common.connectors.ink.generated.Response res = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ServiceOrderResponse sor = new ServiceOrderResponse();
    ServiceOrderDataResponse sod = new ServiceOrderDataResponse();
    Dataset dso = new Dataset();
    DatasetParam ds = new DatasetParam();
    ds.setIndex(0);
    ds.setName("reponseFonctionnelle"); //$NON-NLS-1$
    ds.setValue(result);
    dso.getParams().add(ds);
    sod.setDataset(dso);
    sor.setSod(sod);
    res.setSo(sor);
    return new ResponseConnector(res, null);
  }

  /**
   * Create Response connector with list type DroitAccesADistancePfs
   *
   * @return ResponseConnector
   * @throws RavelException
   *           on error
   */
  private ResponseConnector createResponseConnectorDroitAccesADistancePfs() throws RavelException
  {
    ReponseFonctionnelle<DroitAccesADistancePfs> reponseFonctionnelle = new ReponseFonctionnelle<>();
    reponseFonctionnelle.setItems( //
        Arrays.asList(new DroitAccesADistancePfs( //
            Arrays.asList( //
                new Destinataire(DEFAULT_NO_TELEPHONE), //
                new Destinataire(DEFAULT_NO_TELEPHONE + "2"))))); //$NON-NLS-1$
    reponseFonctionnelle.setResultsCount(1);

    String result = RavelJsonTools.getInstance().toJson(reponseFonctionnelle, new ReponseFonctionnelleParameterizedType<>(DroitAccesADistancePfs.class));

    com.bytel.spirit.common.connectors.ink.generated.Response res = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ServiceOrderResponse sor = new ServiceOrderResponse();
    ServiceOrderDataResponse sod = new ServiceOrderDataResponse();
    Dataset dso = new Dataset();
    DatasetParam ds = new DatasetParam();
    ds.setIndex(0);
    ds.setName("reponseFonctionnelle"); //$NON-NLS-1$
    ds.setValue(result);
    dso.getParams().add(ds);
    sod.setDataset(dso);
    sor.setSod(sod);
    res.setSo(sor);
    return new ResponseConnector(res, null);
  }

  /**
   * Create Response connector with list type MessageriePfs
   *
   * @param typeMessagerie_p
   *          typeMessagerie
   * @return ResponseConnector
   * @throws RavelException
   *           on error
   */
  private ResponseConnector createResponseConnectorMessagerie(String typeMessagerie_p) throws RavelException
  {
    ReponseFonctionnelle<MessageriePfs> reponseFonctionnelle = new ReponseFonctionnelle<>();
    reponseFonctionnelle.setItems(Arrays.asList(createMessageriePfs(1, typeMessagerie_p), createMessageriePfs(2, typeMessagerie_p)));
    reponseFonctionnelle.setResultsCount(2);

    String result = RavelJsonTools.getInstance().toJson(reponseFonctionnelle, new ReponseFonctionnelleParameterizedType<>(MessageriePfs.class));

    com.bytel.spirit.common.connectors.ink.generated.Response res = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ServiceOrderResponse sor = new ServiceOrderResponse();
    ServiceOrderDataResponse sod = new ServiceOrderDataResponse();
    Dataset dso = new Dataset();
    DatasetParam ds = new DatasetParam();
    ds.setIndex(0);
    ds.setName("reponseFonctionnelle"); //$NON-NLS-1$
    ds.setValue(result);
    dso.getParams().add(ds);
    sod.setDataset(dso);
    sor.setSod(sod);
    res.setSo(sor);
    return new ResponseConnector(res, null);
  }

  /**
   * Create Response connector with list type NotificationEmailPfs
   *
   * @return ResponseConnector
   * @throws RavelException
   *           on error
   */
  private ResponseConnector createResponseConnectorNotificationEmailPfs() throws RavelException
  {
    ReponseFonctionnelle<NotificationEmailPfs> reponseFonctionnelle = new ReponseFonctionnelle<>();
    reponseFonctionnelle.setItems( //
        Arrays.asList( //
            new NotificationEmailPfs("ACTIF", //$NON-NLS-1$
                Arrays.asList( //
                    new NotificationEmail("email1", true, true), //$NON-NLS-1$
                    new NotificationEmail("email2", false, false))))); //$NON-NLS-1$
    reponseFonctionnelle.setResultsCount(1);

    String result = RavelJsonTools.getInstance().toJson(reponseFonctionnelle, new ReponseFonctionnelleParameterizedType<>(NotificationEmailPfs.class));

    com.bytel.spirit.common.connectors.ink.generated.Response res = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ServiceOrderResponse sor = new ServiceOrderResponse();
    ServiceOrderDataResponse sod = new ServiceOrderDataResponse();
    Dataset dso = new Dataset();
    DatasetParam ds = new DatasetParam();
    ds.setIndex(0);
    ds.setName("reponseFonctionnelle"); //$NON-NLS-1$
    ds.setValue(result);
    dso.getParams().add(ds);
    sod.setDataset(dso);
    sor.setSod(sod);
    res.setSo(sor);
    return new ResponseConnector(res, null);
  }

  /**
   * Create Response connector with list type NotificationSmsPfs
   *
   * @return ResponseConnector
   * @throws RavelException
   *           on error
   */
  private ResponseConnector createResponseConnectorNotificationSmsPfs() throws RavelException
  {
    ReponseFonctionnelle<NotificationSmsPfs> reponseFonctionnelle = new ReponseFonctionnelle<>();
    reponseFonctionnelle.setItems( //
        Arrays.asList( //
            new NotificationSmsPfs("ACTIF", //$NON-NLS-1$
                Arrays.asList( //
                    new NotificationSMS("noTel"), //$NON-NLS-1$
                    new NotificationSMS("noTel2"))))); //$NON-NLS-1$
    reponseFonctionnelle.setResultsCount(1);

    String result = RavelJsonTools.getInstance().toJson(reponseFonctionnelle, new ReponseFonctionnelleParameterizedType<>(NotificationSmsPfs.class));

    com.bytel.spirit.common.connectors.ink.generated.Response res = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ServiceOrderResponse sor = new ServiceOrderResponse();
    ServiceOrderDataResponse sod = new ServiceOrderDataResponse();
    Dataset dso = new Dataset();
    DatasetParam ds = new DatasetParam();
    ds.setIndex(0);
    ds.setName("reponseFonctionnelle"); //$NON-NLS-1$
    ds.setValue(result);
    dso.getParams().add(ds);
    sod.setDataset(dso);
    sor.setSod(sod);
    res.setSo(sor);
    return new ResponseConnector(res, null);
  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess(Request request_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * Mock call to BL5270
   *
   * @param retour_p
   *          expected retour
   * @param bl3700Return_p
   *          expected response
   * @throws Exception
   *           On error
   */
  private void expectBL3700(Retour retour_p, BL3700_Return bl3700Return_p) throws Exception
  {
    String loginEmail = DEFAULT_ADRESSE_MAIL.split("@")[0]; //$NON-NLS-1$
    PowerMock.expectNew(BL3700_RecupererPfiParMailBuilder.class).andReturn(_bl3700BuilderMock);
    EasyMock.expect(_bl3700BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl3700BuilderMock);
    EasyMock.expect(_bl3700BuilderMock.mail(loginEmail)).andReturn(_bl3700BuilderMock);
    EasyMock.expect(_bl3700BuilderMock.build()).andReturn(_bl3700Mock);
    EasyMock.expect(_bl3700Mock.execute(_processInstance)).andReturn(bl3700Return_p);
    EasyMock.expect(_bl3700Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Mock call to BL5270
   *
   * @param retour_p
   *          expected retour
   * @param bl5270Return_p
   *          expected response
   * @throws Exception
   *           On error
   */
  private void expectBL5270(Retour retour_p, BL5270_Return bl5270Return_p) throws Exception
  {
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(DEFAULT_NO_TELEPHONE)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(_processInstance)).andReturn(bl5270Return_p);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Mock call to BL5280
   *
   * @param retour_p
   *          expected retour
   * @param typeAcces_p
   *          expected response
   * @throws Exception
   *           On error
   */
  private void expectBL5280(Retour retour_p, String typeAcces_p) throws Exception
  {
    PowerMock.expectNew(BL5280_RecupererTypeAccesNoTelephoneBuilder.class).andReturn(_bl5280BuilderMock);
    EasyMock.expect(_bl5280BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5280BuilderMock);
    EasyMock.expect(_bl5280BuilderMock.noTelephone(DEFAULT_NO_TELEPHONE)).andReturn(_bl5280BuilderMock);
    EasyMock.expect(_bl5280BuilderMock.build()).andReturn(_bl5280Mock);
    EasyMock.expect(_bl5280Mock.execute(_processInstance)).andReturn(typeAcces_p);
    EasyMock.expect(_bl5280Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Mock call to BL5290
   *
   * @param retour_p
   *          expected retour
   * @param typeVms_p
   *          expected response
   * @throws Exception
   *           On error
   */
  private void expectBL5290(Retour retour_p, String typeVms_p) throws Exception
  {
    PowerMock.expectNew(BL5290_RecupererTypeVmsBuilder.class).andReturn(_bl5290BuilderMock);
    EasyMock.expect(_bl5290BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5290BuilderMock);
    EasyMock.expect(_bl5290BuilderMock.noTelephone(DEFAULT_NO_TELEPHONE)).andReturn(_bl5290BuilderMock);
    EasyMock.expect(_bl5290BuilderMock.noCompte(EasyMock.anyObject(String.class))).andReturn(_bl5290BuilderMock);
    EasyMock.expect(_bl5290BuilderMock.clientOperateur(EasyMock.anyObject(String.class))).andReturn(_bl5290BuilderMock);
    EasyMock.expect(_bl5290BuilderMock.build()).andReturn(_bl5290Mock);
    EasyMock.expect(_bl5290Mock.execute(_processInstance)).andReturn(typeVms_p);
    EasyMock.expect(_bl5290Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Mock call to SI002
   *
   * @param processus_p
   *          processus
   * @param listeParametres_p
   *          listeParametres
   * @param retour_p
   *          expected retour
   * @param reponseConnector_p
   *          expected response
   * @throws Exception
   *           On error
   */
  private void expectSI002(String processus_p, ListeParametre listeParametres_p, Retour retour_p, ResponseConnector reponseConnector_p) throws Exception
  {
    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.processus(processus_p)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.listeParametres(listeParametres_p)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.priorite(10)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.build()).andReturn(_si002Mock);
    EasyMock.expect(_si002Mock.execute(_processInstance)).andReturn(reponseConnector_p);
    EasyMock.expect(_si002Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * Mock call to SI037
   *
   * @param retour_p
   *          expected retour
   * @param noContrat_p
   *          expected response
   * @param partition_p
   *          partition
   * @throws Exception
   *           On error
   */
  private void expectSI037(Retour retour_p, String noContrat_p, String partition_p) throws Exception
  {
    PowerMock.expectNew(NPBT_SI037_RecupererNoContratParNoTelephoneBuilder.class).andReturn(_si037BuilderMock);
    EasyMock.expect(_si037BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si037BuilderMock);
    EasyMock.expect(_si037BuilderMock.noTelephone(DEFAULT_NO_TELEPHONE)).andReturn(_si037BuilderMock);
    EasyMock.expect(_si037BuilderMock.build()).andReturn(_si037Mock);
    EasyMock.expect(_si037Mock.execute(_processInstance)).andReturn(new Pair<>(retour_p, new ResultContratEtPartition(noContrat_p, partition_p)));
  }

  /**
   * Mock call to SI038
   *
   * @param retour_p
   *          expected retour
   * @param typeVms_p
   *          expected response
   * @throws Exception
   *           On error
   */
  private void expectSI038(Retour retour_p, String typeVms_p) throws Exception
  {
    PowerMock.expectNew(NPBT_SI038_RecupererTypeVmsBuilder.class).andReturn(_si038BuilderMock);
    EasyMock.expect(_si038BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si038BuilderMock);
    EasyMock.expect(_si038BuilderMock.noTelephone(DEFAULT_NO_TELEPHONE)).andReturn(_si038BuilderMock);
    EasyMock.expect(_si038BuilderMock.build()).andReturn(_si038Mock);
    EasyMock.expect(_si038Mock.execute(_processInstance)).andReturn(new Pair<>(retour_p, typeVms_p));
  }

  /**
   * prepareGetRequest
   *
   * @param tracabilite_p
   *          tracabilite
   * @param methode_p
   *          method
   * @param urlDynamicParameters_p
   *          idMessagerie / idAnnonce
   * @param listeContact_p
   *          listeContact
   * @return Request
   * @throws RavelException
   *           exception
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String methode_p, String urlDynamicParameters_p, String listeContact_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    addXHeaders(request.getRequestHeader(), tracabilite_p, listeContact_p);

    if (urlDynamicParameters_p != null)
    {
      request.setUrlDynamicParameters(urlDynamicParameters_p);
    }

    return request;
  }

  /**
   * Set query param (noTelephone/adresseMail)
   *
   * @param request_p
   *          request
   * @param paramName_p
   *          parameter name
   * @param paramValue_p
   *          parameter value
   */
  private void setQueryParam(Request request_p, String paramName_p, String paramValue_p)
  {
    UrlParameters urlParameters = new UrlParameters();
    List<Parameter> urlParams = urlParameters.getUrlParameters();
    urlParams.add(createParameter(paramName_p, paramValue_p));
    urlParameters.setUrlParameters(urlParams);
    request_p.setUrlParameters(urlParameters);
  }
}