/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0274;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.shared.functional.types.json.AppelantInterdit;
import com.bytel.spirit.common.shared.functional.types.json.Destinataire;
import com.bytel.spirit.common.shared.functional.types.json.NotificationEmail;
import com.bytel.spirit.common.shared.functional.types.json.NotificationSMS;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestAppelantsInterdits;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestCodePin;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestDestinataires;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestNotificationsEmail;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestNotificationsSMS;
import com.bytel.spirit.fiat.processes.PE0274.sti.PE0274_PutRequestStatutMessagerie;
import com.bytel.spirit.fiat.processes.PE0274.structs.OperationMessageries;

import io.netty.util.internal.StringUtil;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0274_RessourceMessageries.class, ProcessManager.class, PROV_SI002_ExecuterProcessusBuilder.class, PROV_SI002_ExecuterProcessus.class })
public class PE0274_RessourceMessageriesPutTest
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0274_RessourceMessageries"; //$NON-NLS-1$

  /**
   * Configuration path Param
   */
  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * The default value for the idMessagerie
   */
  private static final String DEFAULT_ID_MESSAGERIE = "10000530160#idMessageriePfs#VOIX#typePfs"; //$NON-NLS-1$

  /**
   * Default value for listeContrat
   */
  private static final String DEFAULT_LISTE_CONTRAT = "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"; //$NON-NLS-1$

  /**
   * INVALID_BODY
   */
  private static final String INVALID_BODY = "invalidBody"; //$NON-NLS-1$

  /**
   * ConfigurationPE0274
   */
  private static final String CONFIGURATION_PE0274_XML = "ConfigurationPE0274.xml"; //$NON-NLS-1$

  /**
   * interdictions-depot-messages
   */
  private static final String INTERDICTIONS_DEPOT_MESSAGES = "interdictions-depot-messages"; //$NON-NLS-1$

  /**
   * notifications-email
   */
  private static final String NOTIFICATIONS_EMAIL = "notifications-email"; //$NON-NLS-1$
  /**
   * notifications-sms
   */
  private static final String NOTIFICATIONS_SMS = "notifications-sms"; //$NON-NLS-1$

  /**
   * messageries-a-distance
   */
  private static final String MESSAGERIES_A_DISTANCE = "messageries-a-distance"; //$NON-NLS-1$

  /**
   * statut
   */
  private static final String STATUT = "statut"; //$NON-NLS-1$

  /**
   * STATUT_MESSAGERIE
   */
  private static final String STATUT_MESSAGERIE = "statutMessagerie"; //$NON-NLS-1$

  /**
   * typePfs
   */
  private static final String TYPE_PFS = "typePfs"; //$NON-NLS-1$

  /**
   * idMessageriePfs
   */
  private static final String ID_MESSAGERIE_PFS = "idMessageriePfs"; //$NON-NLS-1$

  /**
   * LIBELLE
   */
  private static final String LIBELLE = "libelle"; //$NON-NLS-1$

  /**
   * MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE
   */
  private static final String MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE = "Service momentanement indisponible"; //$NON-NLS-1$

  /**
   * RESPONSE_SHOULD_BE_EMPTY
   */
  private static final String RESPONSE_SHOULD_BE_EMPTY = "response should be empty"; //$NON-NLS-1$

  /**
   * noTelephone
   */
  private static final String NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   * nom
   */
  private static final String NOM = "nom"; //$NON-NLS-1$

  /**
   * PIN
   */
  private static final String PIN = "pin"; //$NON-NLS-1$

  /**
   * ACTION
   */
  private static final String ACTION = "action"; //$NON-NLS-1$

  /**
   * CODE_PIN
   */
  private static final String CODE_PIN = "codePin"; //$NON-NLS-1$

  /**
   * ACTION_MODIFIER_CODE_PIN
   */
  private static final String ACTION_MODIFIER_CODE_PIN = "modifierCodePin"; //$NON-NLS-1$

  /**
   * ACTION_REINITIALIZER_CODE_PIN
   */
  private static final String ACTION_REINITIALIZER_CODE_PIN = "reinitialiserCodePin"; //$NON-NLS-1$

  /**
   * ADRESSE_MAIL
   */
  private static final String ADRESSE_MAIL = "adresseMail"; //$NON-NLS-1$

  /**
   * ADRESSE_EMAIL
   */
  private static final String ADRESSE_EMAIL = "adresseEmail"; //$NON-NLS-1$

  /**
   * EMAIL_TECHNIQUE
   */
  private static final String EMAIL_TECHNIQUE = "emailTechnique"; //$NON-NLS-1$

  /**
   * PIECE_JOINTE
   */
  private static final String PIECE_JOINTE = "pieceJointe"; //$NON-NLS-1$

  /**
   * STATUT_NOTIFICATIONS_EMAIL
   */
  private static final String STATUT_NOTIFICATIONS_EMAIL = "statutNotificationsEmail"; //$NON-NLS-1$

  private static final String STATUT_NOTIFICATIONS_SMS = "statutNotificationsSMS";

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    Parameter parameter = new Parameter();

    parameter.setName(name_p);
    parameter.setValue(value_p);

    return parameter;
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    try
    {
      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager is now initialized")); //$NON-NLS-1$
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager instance is already initialized")); //$NON-NLS-1$
    }
  }

  /**
   * Instance of {@link PE0274_RessourceMessageries}
   */
  private PE0274_RessourceMessageries _processInstance;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  ProcessManager _processManager;

  /**
   * PROV_SI002_ExecuterProcessusBuilder
   */
  @MockStrict
  PROV_SI002_ExecuterProcessusBuilder _si002BuilderMock;

  /**
   * PROV_SI002_ExecuterProcessus
   */
  @MockStrict
  PROV_SI002_ExecuterProcessus _si002Mock;

  /**
   * Missing config files.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesModification_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, null, null);
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(null, null);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(3);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).times(3);

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegConsts.CONFIGURATION_INVALIDE);
    responseErreurExpected.setErrorDescription("Cannot find param FILE_PATH in process configuration"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * Configuration File error.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesModification_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, null, null);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "someFile"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegConsts.CONFIGURATION_INVALIDE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertTrue("Description does not start with <Fichier de configuration en erreur...>", reponseActual.getErrorDescription().startsWith("Fichier de configuration en erreur")); //$NON-NLS-1$ //$NON-NLS-2$
    Assert.assertTrue("Description does not end with <...java" + File.separator + "processes" + File.separator + "target" + File.separator + "test-classes" + File.separator + "someFile>", reponseActual.getErrorDescription().endsWith("java" + File.separator + "processes" + File.separator + "target" + File.separator + "test-classes" + File.separator + "someFile")); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$
  }

  /**
   * No X_REQUEST_ID Header.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesModification_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, null, null);
    //remove X_REQUEST_ID header
    request.getRequestHeader().remove(createHeader(IHttpHeadersConsts.X_REQUEST_ID, _tracabilite.getIdCorrelationByTel()));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Header X-Request-Id null ou vide."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * no Metadata.CANAL.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesModification_KO_004() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, null, null);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Metadata.CANAL is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * no idMessagerie.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesModification_KO_005() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, null, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Parameter idMessagerie is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * null sous-ressource.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesModification_KO_006() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, DEFAULT_ID_MESSAGERIE, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("SOUS-RESSOURCE null non autorisée"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * invalid sous-ressource.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesModification_KO_007() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, DEFAULT_ID_MESSAGERIE, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INVALID_BODY);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("SOUS-RESSOURCE invalidBody non autorisée"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * no body.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesModification_KO_008() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, DEFAULT_ID_MESSAGERIE, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Body is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * invalid body.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL001_VerifierDonneesModification_KO_009() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, DEFAULT_ID_MESSAGERIE, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    request.setPayload(INVALID_BODY);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.TRAITEMENT_ARRETE);
    responseErreurExpected.setErrorDescription("Body is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertTrue(reponseActual.getErrorDescription().contains("malformed JSON")); //$NON-NLS-1$
  }

  /**
   * invalid idMessagerie.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL300_PreparerModifierMessagerie_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, INVALID_BODY, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    PE0274_PutRequestStatutMessagerie body = new PE0274_PutRequestStatutMessagerie();
    body.setStatutMessagerie(STATUT_MESSAGERIE);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestStatutMessagerie.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.ID_MESSAGERIE_INCONNU);
    responseErreurExpected.setErrorDescription("l'id Messagerie invalidBody est inconnu."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * invalid idMessagerie.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL300_PreparerModifierMessagerie_KO_002() throws Throwable
  {
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE + "#5"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, encryptedIdMessagerie, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    PE0274_PutRequestStatutMessagerie body = new PE0274_PutRequestStatutMessagerie();
    body.setStatutMessagerie(STATUT_MESSAGERIE);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestStatutMessagerie.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.ID_MESSAGERIE_INCONNU);
    responseErreurExpected.setErrorDescription("l'id Messagerie " + encryptedIdMessagerie + " est inconnu."); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * invalid typeMessagerie in idMessagerie.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL300_PreparerModifierMessagerie_KO_003() throws Throwable
  {
    String encryptedIdMessagerie = PasswordEncrypter.encryptForURL("10000530140#idMessageriePfs#typeMessagerie#typePfs"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, encryptedIdMessagerie, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    PE0274_PutRequestStatutMessagerie body = new PE0274_PutRequestStatutMessagerie();
    body.setStatutMessagerie(STATUT_MESSAGERIE);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestStatutMessagerie.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Operation non Autorisée sur la messagerie " + encryptedIdMessagerie); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * CANAL=B2R, X_OAUTH2_IDCONTRATS = null.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL300_PreparerModifierMessagerie_KO_004() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    PE0274_PutRequestStatutMessagerie body = new PE0274_PutRequestStatutMessagerie();
    body.setStatutMessagerie(STATUT_MESSAGERIE);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestStatutMessagerie.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreurExpected.setErrorDescription("Accès refuse"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * CANAL=B2R, X_OAUTH2_IDCONTRATS does not contain noContrat.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL300_PreparerModifierMessagerie_KO_005() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL("10000530140#idMessageriePfs#VOIX#typePfs"), DEFAULT_LISTE_CONTRAT); //$NON-NLS-1$
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    PE0274_PutRequestStatutMessagerie body = new PE0274_PutRequestStatutMessagerie();
    body.setStatutMessagerie(STATUT_MESSAGERIE);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestStatutMessagerie.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreurExpected.setErrorDescription("Accès refuse"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT1
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL301_ModifierStatutMessagerie_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    PE0274_PutRequestStatutMessagerie body = new PE0274_PutRequestStatutMessagerie();
    body.setStatutMessagerie(STATUT_MESSAGERIE);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestStatutMessagerie.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(STATUT_MESSAGERIE, STATUT_MESSAGERIE);

    expectSI002(OperationMessageries.MODIFIER_STATUT_MESSAGERIE.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT2
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL301_ModifierStatutMessagerie_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    PE0274_PutRequestStatutMessagerie body = new PE0274_PutRequestStatutMessagerie();
    body.setStatutMessagerie(STATUT_MESSAGERIE);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestStatutMessagerie.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(STATUT_MESSAGERIE, STATUT_MESSAGERIE);

    expectSI002(OperationMessageries.MODIFIER_STATUT_MESSAGERIE.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT2, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT3|DONNEE_INVALIDE|libelle
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL301_ModifierStatutMessagerie_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    PE0274_PutRequestStatutMessagerie body = new PE0274_PutRequestStatutMessagerie();
    body.setStatutMessagerie(STATUT_MESSAGERIE);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestStatutMessagerie.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(STATUT_MESSAGERIE, STATUT_MESSAGERIE);

    expectSI002(OperationMessageries.MODIFIER_STATUT_MESSAGERIE.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INVALIDE, LIBELLE));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.DONNEE_INVALIDE);
    responseErreurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * BL301 OK.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL301_ModifierStatutMessagerie_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    PE0274_PutRequestStatutMessagerie body = new PE0274_PutRequestStatutMessagerie();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestStatutMessagerie.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(OperationMessageries.MODIFIER_STATUT_MESSAGERIE.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * BL301 B2R OK.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL301_ModifierStatutMessagerie_OK_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, STATUT);
    PE0274_PutRequestStatutMessagerie body = new PE0274_PutRequestStatutMessagerie();
    body.setStatutMessagerie(STATUT_MESSAGERIE);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestStatutMessagerie.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(STATUT_MESSAGERIE, STATUT_MESSAGERIE);

    expectSI002(OperationMessageries.MODIFIER_STATUT_MESSAGERIE.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * PROV_SI002 returns CAT1
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL302_ModifierInterdictionsDepotMessages_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);
    PE0274_PutRequestAppelantsInterdits body = new PE0274_PutRequestAppelantsInterdits();
    body.setAppelantsInterdits(Arrays.asList(new AppelantInterdit(NO_TELEPHONE, NOM)));
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestAppelantsInterdits.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(NO_TELEPHONE, NO_TELEPHONE);
    listeParametres.add(NOM, NOM);

    expectSI002(OperationMessageries.MODIFIER_INTERDICTIONS_DEPOT_MESSAGES.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * BL302 OK.<br/>
   * empty body list.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL302_ModifierStatutMessagerie_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);
    PE0274_PutRequestAppelantsInterdits body = new PE0274_PutRequestAppelantsInterdits();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestAppelantsInterdits.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Body is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT2
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL302_ModifierStatutMessagerie_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);
    PE0274_PutRequestAppelantsInterdits body = new PE0274_PutRequestAppelantsInterdits();
    body.setAppelantsInterdits(Arrays.asList(new AppelantInterdit(NO_TELEPHONE, NOM)));
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestAppelantsInterdits.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(NO_TELEPHONE, NO_TELEPHONE);
    listeParametres.add(NOM, NOM);

    expectSI002(OperationMessageries.MODIFIER_INTERDICTIONS_DEPOT_MESSAGES.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT2, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT3|DONNEE_INVALIDE|libelle
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL302_ModifierStatutMessagerie_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);
    PE0274_PutRequestAppelantsInterdits body = new PE0274_PutRequestAppelantsInterdits();
    body.setAppelantsInterdits(Arrays.asList(new AppelantInterdit(NO_TELEPHONE, NOM)));
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestAppelantsInterdits.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(NO_TELEPHONE, NO_TELEPHONE);
    listeParametres.add(NOM, NOM);

    expectSI002(OperationMessageries.MODIFIER_INTERDICTIONS_DEPOT_MESSAGES.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INVALIDE, LIBELLE));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.DONNEE_INVALIDE);
    responseErreurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * BL302 OK.<br/>
   * body with noTelephone only.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL302_ModifierStatutMessagerie_OK_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);
    PE0274_PutRequestAppelantsInterdits body = new PE0274_PutRequestAppelantsInterdits();
    body.setAppelantsInterdits(Arrays.asList(new AppelantInterdit(NO_TELEPHONE, null)));
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestAppelantsInterdits.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(NO_TELEPHONE, NO_TELEPHONE);

    expectSI002(OperationMessageries.MODIFIER_INTERDICTIONS_DEPOT_MESSAGES.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * BL302 B2R OK.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL302_ModifierStatutMessagerie_OK_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, INTERDICTIONS_DEPOT_MESSAGES);
    PE0274_PutRequestAppelantsInterdits body = new PE0274_PutRequestAppelantsInterdits();
    body.setAppelantsInterdits(Arrays.asList(new AppelantInterdit(NO_TELEPHONE, NOM)));
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestAppelantsInterdits.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(NO_TELEPHONE, NO_TELEPHONE);
    listeParametres.add(NOM, NOM);

    expectSI002(OperationMessageries.MODIFIER_INTERDICTIONS_DEPOT_MESSAGES.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * no action parameter.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL303_ModifierCodePin_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, DEFAULT_ID_MESSAGERIE, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, PIN);
    PE0274_PutRequestCodePin body = new PE0274_PutRequestCodePin();
    body.setCodePin(PIN);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestCodePin.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Parameter action is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * UrlParameter is not adresseMail, noTelephone or Action.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL303_ModifierCodePin_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, DEFAULT_ID_MESSAGERIE, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, PIN);
    PE0274_PutRequestCodePin body = new PE0274_PutRequestCodePin();
    body.setCodePin(PIN);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestCodePin.class));
    setQueryParam(request, INVALID_BODY, INVALID_BODY);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Parameter action is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * Action parameter is empty.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL303_ModifierCodePin_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, DEFAULT_ID_MESSAGERIE, null);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, PIN);
    PE0274_PutRequestCodePin body = new PE0274_PutRequestCodePin();
    body.setCodePin(PIN);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestCodePin.class));
    setQueryParam(request, ACTION, StringConstants.EMPTY_STRING);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Parameter action is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT1
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL303_ModifierCodePin_KO_004() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, PIN);
    PE0274_PutRequestCodePin body = new PE0274_PutRequestCodePin();
    body.setCodePin(PIN);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestCodePin.class));
    setQueryParam(request, ACTION, ACTION_MODIFIER_CODE_PIN);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(ACTION, ACTION_MODIFIER_CODE_PIN);
    listeParametres.add(CODE_PIN, PIN);

    expectSI002(OperationMessageries.MODIFIER_CODE_PIN.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT2
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL303_ModifierCodePin_KO_005() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, PIN);
    PE0274_PutRequestCodePin body = new PE0274_PutRequestCodePin();
    body.setCodePin(PIN);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestCodePin.class));
    setQueryParam(request, ACTION, ACTION_MODIFIER_CODE_PIN);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(ACTION, ACTION_MODIFIER_CODE_PIN);
    listeParametres.add(CODE_PIN, PIN);

    expectSI002(OperationMessageries.MODIFIER_CODE_PIN.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT2, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT3|DONNEE_INVALIDE|libelle
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL303_ModifierCodePin_KO_006() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, PIN);
    PE0274_PutRequestCodePin body = new PE0274_PutRequestCodePin();
    body.setCodePin(PIN);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestCodePin.class));
    setQueryParam(request, ACTION, ACTION_MODIFIER_CODE_PIN);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(ACTION, ACTION_MODIFIER_CODE_PIN);
    listeParametres.add(CODE_PIN, PIN);

    expectSI002(OperationMessageries.MODIFIER_CODE_PIN.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INVALIDE, LIBELLE));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.DONNEE_INVALIDE);
    responseErreurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * BL303 OK.<br/>
   * action=modifierCodePin.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL303_ModifierCodePin_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, PIN);
    PE0274_PutRequestCodePin body = new PE0274_PutRequestCodePin();
    body.setCodePin(PIN);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestCodePin.class));
    setQueryParam(request, ACTION, ACTION_MODIFIER_CODE_PIN);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(ACTION, ACTION_MODIFIER_CODE_PIN);
    listeParametres.add(CODE_PIN, PIN);

    expectSI002(OperationMessageries.MODIFIER_CODE_PIN.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * BL303 B2R OK.<br/>
   * Action = reinitializerCodePin.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL303_ModifierCodePin_OK_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, PIN);
    PE0274_PutRequestCodePin body = new PE0274_PutRequestCodePin();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestCodePin.class));
    setQueryParam(request, ACTION, ACTION_REINITIALIZER_CODE_PIN);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(ACTION, ACTION_REINITIALIZER_CODE_PIN);

    expectSI002(OperationMessageries.MODIFIER_CODE_PIN.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * PROV_SI002 returns CAT1
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL304_ModifierNotificationsEmail_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);
    PE0274_PutRequestNotificationsEmail body = new PE0274_PutRequestNotificationsEmail();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestNotificationsEmail.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(OperationMessageries.MODIFIER_NOTIFICATIONS_EMAIL.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT2
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL304_ModifierNotificationsEmail_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);
    PE0274_PutRequestNotificationsEmail body = new PE0274_PutRequestNotificationsEmail();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestNotificationsEmail.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(OperationMessageries.MODIFIER_NOTIFICATIONS_EMAIL.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT2, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT3|DONNEE_INVALIDE|libelle
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL304_ModifierNotificationsEmail_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);
    PE0274_PutRequestNotificationsEmail body = new PE0274_PutRequestNotificationsEmail();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestNotificationsEmail.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(OperationMessageries.MODIFIER_NOTIFICATIONS_EMAIL.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INVALIDE, LIBELLE));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.DONNEE_INVALIDE);
    responseErreurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * BL304 OK.<br/>
   * empty body list.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL304_ModifierNotificationsEmail_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);
    PE0274_PutRequestNotificationsEmail body = new PE0274_PutRequestNotificationsEmail();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestNotificationsEmail.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(OperationMessageries.MODIFIER_NOTIFICATIONS_EMAIL.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * BL304 B2R OK.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL304_ModifierNotificationsEmail_OK_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_EMAIL);
    PE0274_PutRequestNotificationsEmail body = new PE0274_PutRequestNotificationsEmail();
    body.setStatutNotificationsEmail(STATUT);
    body.setNotificationsEmail(Arrays.asList(new NotificationEmail(ADRESSE_MAIL, true, false)));
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestNotificationsEmail.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(STATUT_NOTIFICATIONS_EMAIL, STATUT);
    listeParametres.add(ADRESSE_EMAIL, ADRESSE_MAIL);
    listeParametres.add(EMAIL_TECHNIQUE, Boolean.toString(true));
    listeParametres.add(PIECE_JOINTE, Boolean.toString(false));

    expectSI002(OperationMessageries.MODIFIER_NOTIFICATIONS_EMAIL.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * PROV_SI002 returns CAT1
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL305_ModifierMessageriesADistance_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);
    PE0274_PutRequestDestinataires body = new PE0274_PutRequestDestinataires();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestDestinataires.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(OperationMessageries.MODIFIER_MESSAGERIES_A_DISTANCE.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT1, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT2
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL305_ModifierMessageriesADistance_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);
    PE0274_PutRequestDestinataires body = new PE0274_PutRequestDestinataires();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestDestinataires.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(OperationMessageries.MODIFIER_MESSAGERIES_A_DISTANCE.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT2, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreurExpected.setErrorDescription(MESSAGE_SERVICE_MOMENTANEMENT_INDISPONIBLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * PROV_SI002 returns CAT3|DONNEE_INVALIDE|libelle
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL305_ModifierMessageriesADistance_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);
    PE0274_PutRequestDestinataires body = new PE0274_PutRequestDestinataires();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestDestinataires.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(OperationMessageries.MODIFIER_MESSAGERIES_A_DISTANCE.getValue(), //
        listeParametres, //
        RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INVALIDE, LIBELLE));

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.DONNEE_INVALIDE);
    responseErreurExpected.setErrorDescription(LIBELLE);
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * BL305 OK.<br/>
   * empty body list.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL305_ModifierMessageriesADistance_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);
    PE0274_PutRequestDestinataires body = new PE0274_PutRequestDestinataires();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestDestinataires.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);

    expectSI002(OperationMessageries.MODIFIER_MESSAGERIES_A_DISTANCE.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * BL305 B2R OK.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL305_ModifierMessageriesADistance_OK_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, MESSAGERIES_A_DISTANCE);
    PE0274_PutRequestDestinataires body = new PE0274_PutRequestDestinataires();
    body.setDestinataires(Arrays.asList(new Destinataire(NO_TELEPHONE)));
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestDestinataires.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(NO_TELEPHONE, NO_TELEPHONE);

    expectSI002(OperationMessageries.MODIFIER_MESSAGERIES_A_DISTANCE.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * BL306 OK.<br/>
   * no action
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL306_gestionVVM_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, "vvm");

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Parameter action is null or empty.");
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * BL306 OK.<br/>
   * action=desativer.
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL306_gestionVVM_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    String desativer = "desactiver";
    setQueryParam(request, ACTION, desativer);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, "vvm");

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(ACTION, desativer);

    expectSI002(OperationMessageries.GESTION_VVM.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * BL307 OK.<br/>
   * No telephone
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  @Ignore
  public void PE0274_RessourceMessageries_BL307_Notifier_SMS_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_SMS);
    PE0274_PutRequestNotificationsSMS body = new PE0274_PutRequestNotificationsSMS();
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestNotificationsSMS.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Parameter noTelephone is null or empty.");
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * BL307 OK.<br/>
   * Number of notificationsSMS > 1
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL307_Notifier_SMS_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_SMS);
    PE0274_PutRequestNotificationsSMS body = new PE0274_PutRequestNotificationsSMS();
    body.setNotificationsSMS(Arrays.asList(new NotificationSMS("123456789"), new NotificationSMS("123456780")));
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestNotificationsSMS.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    ReponseErreur responseErreurExpected = new ReponseErreur();
    responseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreurExpected.setErrorDescription("Non respect du format d''entrée de la STI.");
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseActual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreurExpected.getError(), reponseActual.getError());
    Assert.assertEquals(responseErreurExpected.getErrorDescription(), reponseActual.getErrorDescription());
  }

  /**
   * BL307 OK.<br/>
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0274_RessourceMessageries_BL307_Notifier_SMS_OK_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, PasswordEncrypter.encryptForURL(DEFAULT_ID_MESSAGERIE), DEFAULT_LISTE_CONTRAT);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_DIRECT);
    request.addMetadata(IMetadata.SOUS_RESSOURCE, NOTIFICATIONS_SMS);
    PE0274_PutRequestNotificationsSMS body = new PE0274_PutRequestNotificationsSMS();
    List<NotificationSMS> notificationSMSs = new ArrayList<>();
    NotificationSMS notificationSMS = new NotificationSMS(NO_TELEPHONE);
    notificationSMSs.add(notificationSMS);
    body.setNotificationsSMS(notificationSMSs);
    request.setPayload(RavelJsonTools.getInstance().toJson(body, PE0274_PutRequestNotificationsSMS.class));

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, CONFIGURATION_PE0274_XML);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ListeParametre listeParametres = new ListeParametre();
    listeParametres.add(ID_MESSAGERIE_PFS, ID_MESSAGERIE_PFS);
    listeParametres.add(TYPE_PFS, TYPE_PFS);
    listeParametres.add(STATUT_NOTIFICATIONS_SMS, null);
    listeParametres.add(NO_TELEPHONE, NO_TELEPHONE);

    expectSI002(OperationMessageries.MODIFIER_NOTIFICATIONS_SMS.getValue(), //
        listeParametres, //
        RetourFactory.createOkRetour());

    PowerMock.replayAll();
    Response response = executeStartProcess(request);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    Assert.assertNull(RESPONSE_SHOULD_BE_EMPTY, response.getResult());
  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PE0274_RessourceMessageries();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setNomProcessus(DEFAULT_PROCESSNAME);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStaticStrict(PROV_SI002_ExecuterProcessus.class);
    PowerMock.mockStaticStrict(PROV_SI002_ExecuterProcessusBuilder.class);
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   *
   *
   * @param listeContract_p
   *          listeContract
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p, String listeContract_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("ClientOperateur"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
    hdr.setValue("Authorization : bearer XXXX"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue(listeContract_p);
    requestHeader_p.add(hdr);
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * @param key_p
   *          The key
   * @param value_p
   *          The value
   * @return process params
   */
  private ConcurrentHashMap<String, Map<String, String>> createProcessParams(String key_p, String value_p)
  {
    File classpath = new File(PE0274_RessourceMessageriesGetTest.class.getResource("/").getFile()); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    if (!StringUtil.isNullOrEmpty(key_p))
    {
      map.put(key_p, classpath + "/" + value_p); //$NON-NLS-1$
    }

    processParams.put(StringConstants.EMPTY_STRING, map);
    return processParams;
  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess(Request request_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(DEFAULT_PROCESSNAME);
    _processInstance.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * Mock call to SI002
   *
   * @param processus_p
   *          processus
   * @param listeParametres_p
   *          listeParametres
   * @param retour_p
   *          expected retour
   * @throws Exception
   *           On error
   */
  private void expectSI002(String processus_p, ListeParametre listeParametres_p, Retour retour_p) throws Exception
  {
    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.processus(processus_p)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.listeParametres(listeParametres_p)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.priorite(10)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.build()).andReturn(_si002Mock);
    EasyMock.expect(_si002Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_si002Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * prepareGetRequest
   *
   * @param tracabilite_p
   *          tracabilite
   * @param urlDynamicParameters_p
   *          idMessagerie / idAnnonce
   * @param listeContact_p
   *          listeContact
   * @return Request
   * @throws RavelException
   *           exception
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String urlDynamicParameters_p, String listeContact_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(HttpMethod.PUT);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    addXHeaders(request.getRequestHeader(), tracabilite_p, listeContact_p);

    if (urlDynamicParameters_p != null)
    {
      request.setUrlDynamicParameters(urlDynamicParameters_p);
    }

    return request;
  }

  /**
   * Set query param action
   *
   * @param request_p
   *          request
   * @param paramName_p
   *          parameter name
   * @param paramValue_p
   *          parameter value
   */
  private void setQueryParam(Request request_p, String paramName_p, String paramValue_p)
  {
    UrlParameters urlParameters = new UrlParameters();
    List<Parameter> urlParams = urlParameters.getUrlParameters();
    urlParams.add(createParameter(paramName_p, paramValue_p));
    urlParameters.setUrlParameters(urlParams);
    request_p.setUrlParameters(urlParameters);
  }
}
