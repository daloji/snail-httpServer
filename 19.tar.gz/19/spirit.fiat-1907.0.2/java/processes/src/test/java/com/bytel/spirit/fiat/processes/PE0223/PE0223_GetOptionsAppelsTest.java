package com.bytel.spirit.fiat.processes.PE0223;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.BL5280_RecupererTypeAccesNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5280_RecupererTypeAccesNoTelephone.BL5280_RecupererTypeAccesNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL5270_Return;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.ink.generated.Dataset;
import com.bytel.spirit.common.connectors.ink.generated.DatasetParam;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderDataResponse;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderResponse;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.shared.functional.types.json.OptionAppelPfs;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0223.PE0223_OptionsAppels.PE0223_OptionsAppelsContext;
import com.bytel.spirit.fiat.processes.PE0223.structs.PE0223_ResponseFonctionnelle;
import com.bytel.spirit.fiat.processes.PE0223.structs.get.PE0223_BL001GetReturn;
import com.bytel.spirit.fiat.processes.PE0223.structs.get.PE0223_BL002GetReturn;
import com.bytel.spirit.fiat.processes.PE0223.structs.get.PE0223_BL100GetRetour;
import com.bytel.spirit.fiat.processes.PE0223.structs.get.PE0223_GetResponse;
import com.bytel.spirit.fiat.processes.PE0223.structs.types.OptionAppel;
import com.bytel.spirit.fiat.processes.structs.XAction;
import com.bytel.spirit.fiat.processes.structs.XLink;
import com.google.gson.Gson;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jiantila
 * @version ($Revision: 10004 $ $Date: 2018-09-11 10:45:43 +0200 (Tue, 11 Sep 2018) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ BL5280_RecupererTypeAccesNoTelephone.class, BL5280_RecupererTypeAccesNoTelephoneBuilder.class, PE0223_OptionsAppels.class, //
    RPGProxy.class, PROV_SI002_ExecuterProcessusBuilder.class, PROV_SI002_ExecuterProcessus.class, BL1700_AjouterRefFoncBuilder.class, //
    BL1700_AjouterRefFonc.class, BL5270_RecupererPfiParNoTelephone.class, BL5270_RecupererPfiParNoTelephoneBuilder.class, PasswordDecrypter.class })
public class PE0223_GetOptionsAppelsTest
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
  *
  */
  private static final String PE0223_BL100_LISTER_OPTIONS_APPEL = "PE0223_BL100_ListerOptionsAppel"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PE0223_BL002_FORMATER_REPONSE_CONSULTATION = "PE0223_BL002_FormaterReponseConsultation"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0223_OptionsAppels"; //$NON-NLS-1$

  /**
   * Creation of a parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */

  /**
   * The constant for BL100.noTelephoneInvalide message
   */
  private static final String MESSAGE_NO_TELEPHONE_INVALIDE = Messages.getString("PE0223.BL100.noTelephoneInvalide"); //$NON-NLS-1$

  /**
   * The type FIXE constant
   */
  private static final String TYPE_FIXE = "FIXE"; //$NON-NLS-1$

  /**
   * The type TYPE_OTHER constant
   */
  private static final String TYPE_OTHER = "type"; //$NON-NLS-1$

  /**
   * The type MODE_APPEL constant
   */
  private static final String MODE_APPEL = "modeAppel"; //$NON-NLS-1$

  /**
   * The constant for BL100.serviceIndisponible message
   */
  private static final String MESSAGE_SERVICE_INDISPONIBLE = Messages.getString("PE0223.BL100.serviceIndisponible"); //$NON-NLS-1$

  /**
   * The constant for BL100.noTelephoneInconnu message
   */
  private static final String MESSAGE_NO_TELEPHONE_INCONNU = Messages.getString("PE0223.BL100.noTelephoneInconnu"); //$NON-NLS-1$

  /**
   * The constant for the reponseFonctionnelle
   */
  private static final String FUNCTIONAL_RESPONSE_PARAM_NAME = "reponseFonctionnelle"; //$NON-NLS-1$

  /**
   * OPERATION
   */
  private static final String OPERATION = "/options-appels/"; //$NON-NLS-1$

  /**
   * PUT
   */
  private static final String PUT = "PUT"; //$NON-NLS-1$

  /**
   * listeModeAppel B2R parameter name
   */
  private static final String LISTE_MODE_APPEL_B2R = "listeModeAppel.B2R"; //$NON-NLS-1$

  /**
   * The phone number
   */
  private final static String NO_TELEPHONE = "+33123123123"; //$NON-NLS-1$

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    Parameter parameter = new Parameter();

    parameter.setName(name_p);
    parameter.setValue(value_p);

    return parameter;
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * The BL5280 activity builder mock
   */
  @MockStrict
  BL5280_RecupererTypeAccesNoTelephoneBuilder _bl5280BuilderMock;

  /**
   * The BL5270 activity builder mock
   */
  @MockStrict
  BL5270_RecupererPfiParNoTelephoneBuilder _bl5270BuilderMock;

  /**
   * The BL5270 activity mock
   */
  @MockStrict
  BL5270_RecupererPfiParNoTelephone _bl5270Mock;

  /**
   * The BL5280 activity mock
   */
  @MockStrict
  BL5280_RecupererTypeAccesNoTelephone _bl5280Mock;

  /**
   * BL1700_AjouterRefFoncBuilder
   */
  @MockStrict
  BL1700_AjouterRefFoncBuilder _bl1700Builder_mock;

  /**
   * BL1700_AjouterRefFonc
   */
  @MockStrict
  BL1700_AjouterRefFonc _bl1700_mock;

  /**
   * PROV_SI002_ExecuterProcessusBuilder
   */
  @MockStrict
  PROV_SI002_ExecuterProcessusBuilder _si002_mockbuilder;

  /**
   * PROV_SI002_ExecuterProcessus
   */
  @MockStrict
  PROV_SI002_ExecuterProcessus _si002_mock;

  /**
   * RPG PRoxy
   */
  @MockStrict
  private RPGProxy _rpgProxy;

  /**
   * Instance of {@link PE0223_OptionsAppels}
   */
  private PE0223_OptionsAppels _processInstance;

  /**
   * The process context
   */
  PE0223_OptionsAppelsContext _context;

  /**
   * retour KO
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL002_FormaterReponseConsultation_KO_001() throws Exception
  {
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.ACCES_NON_AUTORISE, "", "PE0223_BL100_PreparerConsultOptionsAppels"); //$NON-NLS-1$//$NON-NLS-2$
    ReponseErreur reponseErreur = new ReponseErreur();
    reponseErreur.setError(IMegConsts.ACCES_NON_AUTORISE);
    reponseErreur.setErrorDescription(""); //$NON-NLS-1$

    // Call method
    Pair<ReponseErreur, PE0223_BL002GetReturn> bl002Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL002_FORMATER_REPONSE_CONSULTATION, _tracabilite, retourKo, null);

    // Assertions
    Assert.assertEquals(retourKo, bl002Retour._first);
    Assert.assertEquals(reponseErreur.getError(), bl002Retour._second.getReponseErreur().getError());
    Assert.assertEquals(reponseErreur.getErrorDescription(), bl002Retour._second.getReponseErreur().getErrorDescription());
  }

  /**
   * retour KO
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL002_FormaterReponseConsultation_OK_001() throws Exception
  {
    Retour retouroK = RetourFactory.createOkRetour();
    PE0223_GetResponse reponseConnector = new PE0223_GetResponse();

    // Call method
    Pair<Retour, PE0223_BL002GetReturn> bl002Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL002_FORMATER_REPONSE_CONSULTATION, _tracabilite, retouroK, reponseConnector);

    // Assertions
    Assert.assertEquals(retouroK, bl002Retour._first);
    Assert.assertNotNull(bl002Retour._second);
  }

  /**
   * BL5280 return KO retour
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL100_ListerOptionsAppel_KO_001() throws Exception
  {
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.ACCES_NON_AUTORISE, "", "PE0223_BL100_PreparerConsultOptionsAppels"); //$NON-NLS-1$//$NON-NLS-2$
    String noTelephone = StringConstants.NUMTELFIXE;
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_NO_TELEPHONE_INVALIDE, noTelephone));

    // Set BL5280
    prepareBL5280_Mock(retourKo, noTelephone, TYPE_OTHER);
    PowerMock.replayAll();

    // Method parameters
    PE0223_BL001GetReturn bl001GetReturn = new PE0223_BL001GetReturn();
    bl001GetReturn.setNoTelephone(noTelephone);
    bl001GetReturn.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001GetReturn.setListeContratOauth(new ArrayList<>());

    Pair<Retour, PE0223_BL100GetRetour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL100_LISTER_OPTIONS_APPEL, _tracabilite, bl001GetReturn);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl001Retour._first);
  }

  /**
   * BL5280 return OK and type telephone not FIXE
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL100_ListerOptionsAppel_KO_002() throws Exception
  {
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    String noTelephone = StringConstants.NUMTELFIXE;
    prepareBL5280_Mock(retourOk, noTelephone, TYPE_OTHER);
    PowerMock.replayAll();

    // Method parameters
    PE0223_BL001GetReturn bl001GetReturn = new PE0223_BL001GetReturn();
    bl001GetReturn.setNoTelephone(noTelephone);
    bl001GetReturn.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001GetReturn.setListeContratOauth(new ArrayList<>());

    Pair<Retour, PE0223_BL100GetRetour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL100_LISTER_OPTIONS_APPEL, _tracabilite, bl001GetReturn);
    PowerMock.verifyAll();
    Retour retourKo = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_NO_TELEPHONE_INVALIDE, noTelephone));
    Assert.assertEquals(retourKo, bl001Retour._first);
  }

  /**
   * BL5280 returns OK and type telephone is FIXE<br>
   * BL5270 return KO
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL100_ListerOptionsAppel_KO_003() throws Exception
  {
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.ACCES_NON_AUTORISE, "", "PE0223_BL100_PreparerConsultOptionsAppels"); //$NON-NLS-1$//$NON-NLS-2$
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE);
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    BL5270_Return out = new BL5270_Return();
    String noTelephone = StringConstants.NUMTELFIXE;
    prepareBL5280_Mock(retourOk, noTelephone, TYPE_FIXE);
    prepareBL5270_Mock(retourKo, noTelephone, out);
    PowerMock.replayAll();

    // Method parameters
    PE0223_BL001GetReturn bl001GetReturn = new PE0223_BL001GetReturn();
    bl001GetReturn.setNoTelephone(noTelephone);
    bl001GetReturn.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001GetReturn.setListeContratOauth(new ArrayList<>());

    Pair<Retour, PE0223_BL100GetRetour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL100_LISTER_OPTIONS_APPEL, _tracabilite, bl001GetReturn);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl001Retour._first);
  }

  /**
   * BL5280 returns OK and type telephone is FIXE<br>
   * BL5270 return KO, CAT4, DONNEE_INCONNUE
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL100_ListerOptionsAppel_KO_004() throws Exception
  {
    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", "PE0223_BL100_PreparerConsultOptionsAppels"); //$NON-NLS-1$//$NON-NLS-2$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    BL5270_Return out = new BL5270_Return();
    String noTelephone = StringConstants.NUMTELFIXE;
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_INCONNU, MessageFormat.format(MESSAGE_NO_TELEPHONE_INCONNU, noTelephone));
    prepareBL5280_Mock(retourOk, noTelephone, TYPE_FIXE);
    prepareBL5270_Mock(retourKo, noTelephone, out);
    PowerMock.replayAll();

    // Method parameters
    PE0223_BL001GetReturn bl001GetReturn = new PE0223_BL001GetReturn();
    bl001GetReturn.setNoTelephone(noTelephone);
    bl001GetReturn.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001GetReturn.setListeContratOauth(new ArrayList<>());

    Pair<Retour, PE0223_BL100GetRetour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL100_LISTER_OPTIONS_APPEL, _tracabilite, bl001GetReturn);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl001Retour._first);
  }

  /**
   * BL5280 returns OK and type telephone is FIXE<br>
   * BL5270 return OK <br>
   * ModeAppel is valid and listeContratAuth is empty
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL100_ListerOptionsAppel_KO_005() throws Exception
  {
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "Acces refuse"); //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    BL5270_Return out = new BL5270_Return();
    String noTelephone = NO_TELEPHONE;

    initializeProcessParams();
    prepareBL5280_Mock(retourOk, noTelephone, TYPE_FIXE);
    prepareBL5270_Mock(retourOk, noTelephone, out);

    PowerMock.replayAll();

    // Method parameters
    PE0223_BL001GetReturn bl001GetReturn = new PE0223_BL001GetReturn();
    bl001GetReturn.setNoTelephone(noTelephone);
    bl001GetReturn.setModeAppel(IMetadata.CANAL_B2R);
    bl001GetReturn.setListeContratOauth(new ArrayList<>());

    Pair<Retour, PE0223_BL100GetRetour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL100_LISTER_OPTIONS_APPEL, _tracabilite, bl001GetReturn);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl001Retour._first);
  }

  /**
   * BL5280 returns OK and type telephone is FIXE<br>
   * BL5270 return OK <br>
   * ModeAppel is valid and listeContratAuth is not valid
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL100_ListerOptionsAppel_KO_006() throws Exception
  {
    PE0223_OptionsAppelsContext context = new PE0223_OptionsAppelsContext();
    context.setModeAppel(MODE_APPEL);
    //context.setListeContratAuth(TYPE_OTHER);
    Whitebox.setInternalState(_processInstance, "_processContext", context); //$NON-NLS-1$

    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "Acces refuse"); //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    BL5270_Return out = new BL5270_Return();
    out.setNoContrat(TYPE_FIXE);
    String noTelephone = NO_TELEPHONE;

    initializeProcessParams();
    prepareBL5280_Mock(retourOk, noTelephone, TYPE_FIXE);
    prepareBL5270_Mock(retourOk, noTelephone, out);

    // Method parameters
    PE0223_BL001GetReturn bl001GetReturn = new PE0223_BL001GetReturn();
    bl001GetReturn.setNoTelephone(noTelephone);
    bl001GetReturn.setModeAppel(IMetadata.CANAL_B2R);
    bl001GetReturn.setListeContratOauth(new ArrayList<>());

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL100GetRetour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL100_LISTER_OPTIONS_APPEL, _tracabilite, bl001GetReturn);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl001Retour._first);
  }

  /**
   * BL5280 returns OK and type telephone is FIXE<br>
   * BL5270 return OK <br>
   * ModeAppel is valid and listeContratAuth is valid <br>
   * SI019 returns OK SI002 returns KO CAT4
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL100_ListerOptionsAppel_KO_007() throws Exception
  {
    PE0223_OptionsAppelsContext context = new PE0223_OptionsAppelsContext();
    context.setModeAppel(MODE_APPEL);
    //context.setListeContratAuth(TYPE_OTHER + "," + TYPE_FIXE); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_processContext", context); //$NON-NLS-1$

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "", "PE0223_BL100_PreparerConsultOptionsAppels"); //$NON-NLS-1$//$NON-NLS-2$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    BL5270_Return out = new BL5270_Return();
    out.setNoContrat(TYPE_FIXE);
    String noTelephone = NO_TELEPHONE;

    PE0223_ResponseFonctionnelle rf = new PE0223_ResponseFonctionnelle();
    List<OptionAppelPfs> optionList = new ArrayList<>();
    OptionAppelPfs optionAppel = new OptionAppelPfs();
    optionAppel.setModeRenvoi("MODE_RENVOI"); //$NON-NLS-1$
    optionList.add(optionAppel);
    rf.setItems(optionList);

    String json = GsonTools.getIso8601Ms().toJson(rf);

    ResponseConnector responseConnector = new ResponseConnector(createConnectorResponse(json), null);

    initializeProcessParams();
    prepareBL5280_Mock(retourOk, noTelephone, TYPE_FIXE);
    prepareBL5270_Mock(retourOk, noTelephone, out);
    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", noTelephone); //$NON-NLS-1$
    prepareProv_SI002(retourKo, "consulterOptionsAppelsPfs", listparams, responseConnector); //$NON-NLS-1$

    // Method parameters
    PE0223_BL001GetReturn bl001GetReturn = new PE0223_BL001GetReturn();
    bl001GetReturn.setNoTelephone(noTelephone);
    bl001GetReturn.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001GetReturn.setListeContratOauth(new ArrayList<>());

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL100GetRetour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL100_LISTER_OPTIONS_APPEL, _tracabilite, bl001GetReturn);
    PowerMock.verifyAll();
    Assert.assertEquals(retourKo, bl001Retour._first);
  }

  /**
   * BL5280 returns OK and type telephone is FIXE<br>
   * BL5270 return OK <br>
   * ModeAppel is valid and listeContratAuth is valid <br>
   * SI019 returns OK SI002 returns KO CAT1
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL100_ListerOptionsAppel_KO_008() throws Exception
  {
    PE0223_OptionsAppelsContext context = new PE0223_OptionsAppelsContext();
    context.setModeAppel(MODE_APPEL);
    //context.setListeContratAuth(TYPE_OTHER + "," + TYPE_FIXE); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_processContext", context); //$NON-NLS-1$

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.DONNEE_INCONNUE, "", "PE0223_BL100_PreparerConsultOptionsAppels"); //$NON-NLS-1$//$NON-NLS-2$
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPONIBLE);
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    BL5270_Return out = new BL5270_Return();
    out.setNoContrat(TYPE_FIXE);
    String noTelephone = NO_TELEPHONE;

    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", noTelephone); //$NON-NLS-1$

    PE0223_ResponseFonctionnelle rf = new PE0223_ResponseFonctionnelle();
    List<OptionAppelPfs> optionList = new ArrayList<>();
    OptionAppelPfs optionAppel = new OptionAppelPfs();
    optionAppel.setModeRenvoi("MODE_RENVOI"); //$NON-NLS-1$
    optionList.add(optionAppel);
    rf.setItems(optionList);

    String json = GsonTools.getIso8601Ms().toJson(rf);

    ResponseConnector responseConnector = new ResponseConnector(createConnectorResponse(json), null);

    initializeProcessParams();
    prepareBL5280_Mock(retourOk, noTelephone, TYPE_FIXE);
    prepareBL5270_Mock(retourOk, noTelephone, out);
    prepareProv_SI002(retourKo, "consulterOptionsAppelsPfs", listparams, responseConnector); //$NON-NLS-1$

    // Method parameters
    PE0223_BL001GetReturn bl001GetReturn = new PE0223_BL001GetReturn();
    bl001GetReturn.setNoTelephone(noTelephone);
    bl001GetReturn.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001GetReturn.setListeContratOauth(new ArrayList<>());

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL100GetRetour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL100_LISTER_OPTIONS_APPEL, _tracabilite, bl001GetReturn);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl001Retour._first);
  }

  /**
   * BL5280 returns OK and type telephone is FIXE<br>
   * BL5270 return OK <br>
   * ModeAppel is valid and listeContratAuth is valid <br>
   * SI019 returns OK SI002 returns KO CAT2
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL100_ListerOptionsAppel_KO_009() throws Exception
  {
    PE0223_OptionsAppelsContext context = new PE0223_OptionsAppelsContext();
    context.setModeAppel(MODE_APPEL);
    //context.setListeContratAuth(TYPE_OTHER + "," + TYPE_FIXE); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_processContext", context); //$NON-NLS-1$

    Retour retourKo = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.DONNEE_INCONNUE, "", "PE0223_BL100_PreparerConsultOptionsAppels"); //$NON-NLS-1$//$NON-NLS-2$
    Retour expectedRetour = RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPONIBLE);
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    BL5270_Return out = new BL5270_Return();
    out.setNoContrat(TYPE_FIXE);
    String noTelephone = NO_TELEPHONE;

    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", noTelephone); //$NON-NLS-1$

    PE0223_ResponseFonctionnelle rf = new PE0223_ResponseFonctionnelle();
    List<OptionAppelPfs> optionList = new ArrayList<>();
    OptionAppelPfs optionAppel = new OptionAppelPfs();
    optionAppel.setModeRenvoi("MODE_RENVOI"); //$NON-NLS-1$
    optionList.add(optionAppel);
    rf.setItems(optionList);

    String json = GsonTools.getIso8601Ms().toJson(rf);

    ResponseConnector responseConnector = new ResponseConnector(createConnectorResponse(json), null);

    initializeProcessParams();
    prepareBL5280_Mock(retourOk, noTelephone, TYPE_FIXE);
    prepareBL5270_Mock(retourOk, noTelephone, out);
    prepareProv_SI002(retourKo, "consulterOptionsAppelsPfs", listparams, responseConnector); //$NON-NLS-1$

    // Method parameters
    PE0223_BL001GetReturn bl001GetReturn = new PE0223_BL001GetReturn();
    bl001GetReturn.setNoTelephone(noTelephone);
    bl001GetReturn.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001GetReturn.setListeContratOauth(new ArrayList<>());

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL100GetRetour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL100_LISTER_OPTIONS_APPEL, _tracabilite, bl001GetReturn);
    PowerMock.verifyAll();
    Assert.assertEquals(expectedRetour, bl001Retour._first);
  }

  /**
   * Nominal BL100 test case.
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0223_BL100_ListerOptionsAppel_OK_000() throws Exception
  {
    PE0223_OptionsAppelsContext context = new PE0223_OptionsAppelsContext();
    context.setModeAppel(MODE_APPEL);
    //context.setListeContratAuth(TYPE_OTHER + "," + TYPE_FIXE); //$NON-NLS-1$
    Whitebox.setInternalState(_processInstance, "_processContext", context); //$NON-NLS-1$

    Retour retourOk = RetourFactoryForTU.createOkRetour();
    BL5270_Return out = new BL5270_Return();
    out.setNoContrat(TYPE_FIXE);
    String noTelephone = NO_TELEPHONE;

    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", noTelephone); //$NON-NLS-1$

    PE0223_ResponseFonctionnelle rf = new PE0223_ResponseFonctionnelle();
    List<OptionAppelPfs> optionList = new ArrayList<>();
    OptionAppelPfs optionAppelPfs = new OptionAppelPfs();
    optionAppelPfs.setModeRenvoi("MODE_RENVOI"); //$NON-NLS-1$
    optionList.add(optionAppelPfs);
    rf.setItems(optionList);
    rf.setResultsCount(1);

    PE0223_GetResponse reponse = new PE0223_GetResponse();
    List<OptionAppel> optionAppelList = new ArrayList<>();
    for (OptionAppelPfs option : rf.getItems())
    {
      OptionAppel optionAppel = new OptionAppel();
      String id = out.getNoContrat() + "#" + noTelephone + "#" + option.getType(); //$NON-NLS-1$ //$NON-NLS-2$
      String encryptedId = PasswordEncrypter.encryptForURL(id);
      optionAppel.setIdOptionAppel(encryptedId);

      optionAppel.setNoTelephone(noTelephone);
      optionAppel.setStatut(option.getStatut());
      optionAppel.setType(option.getType());
      optionAppel.setModeRenvoi(option.getModeRenvoi());
      optionAppel.setNombreSonneries(option.getNombreSonneries());
      optionAppel.setNumeroRenvoi(option.getNumeroRenvoi());

      optionAppelList.add(optionAppel);
    }
    reponse.setResultsCount(rf.getResultsCount());
    reponse.setItems(optionAppelList);

    String json = GsonTools.getIso8601Ms().toJson(rf);

    ResponseConnector responseConnector = new ResponseConnector(createConnectorResponse(json), null);

    initializeProcessParams();
    prepareBL5280_Mock(retourOk, noTelephone, TYPE_FIXE);
    prepareBL5270_Mock(retourOk, noTelephone, out);
    prepareProv_SI002(retourOk, "consulterOptionsAppelsPfs", listparams, responseConnector); //$NON-NLS-1$

    // Method parameters
    PE0223_BL001GetReturn bl001GetReturn = new PE0223_BL001GetReturn();
    bl001GetReturn.setNoTelephone(noTelephone);
    bl001GetReturn.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001GetReturn.setListeContratOauth(new ArrayList<>());

    PowerMock.replayAll();
    Pair<Retour, PE0223_GetResponse> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0223_BL100_LISTER_OPTIONS_APPEL, _tracabilite, bl001GetReturn);
    PowerMock.verifyAll();
    Assert.assertEquals(retourOk, bl001Retour._first);
    Assert.assertEquals(reponse.getItems(), bl001Retour._second.getItems());
    Assert.assertEquals(reponse.getLinks(), bl001Retour._second.getLinks());
    Assert.assertEquals(reponse.getResultsCount(), bl001Retour._second.getResultsCount());
  }

  /**
   * Connecteur RPG pfiLireUn KO
   *
   * case if Header X-Request-Id null ou vide.
   *
   * @throws Throwable
   *           exception
   *
   * @throws Exception
   *           exception
   */

  @Test
  public void PE0223_OptionsAppels_BL001_VerifierDonneesConsultation_KO_001() throws Throwable
  {
    String method = "GET"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Request request = prepareRequest(tracabilite, method, NO_TELEPHONE);
    request.getRequestHeader().remove(0);

    initializeProcessParams();
    PowerMock.replayAll();
    //Prepare mock
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Header X-Request-Id null ou vide."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PFI PAS VOIP
   *
   * @throws Throwable
   *           exception
   *
   * @throws Exception
   *           exception
   */

  @Test
  public void PE0223_OptionsAppels_BL001_VerifierDonneesConsultation_KO_004() throws Throwable
  {
    String method = "GET"; //$NON-NLS-1$
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);
    Request request = prepareRequest(tracabilite, method, null);

    initializeProcessParams();
    PowerMock.replayAll();
    //Prepare mock
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verifyAll();
    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter noTelephone is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * BL100_PreparerConsultOptionsAppels_K0 when calling PROV_SI002 (KO Retour)
   *
   * @throws Throwable
   *           exception
   *
   * @throws Exception
   *           exception
   */

  @Test
  public void PE0223_OptionsAppels_Nominal_001() throws Throwable
  {
    String method = "GET"; //$NON-NLS-1$
    Retour retourOk = RetourFactoryForTU.createOkRetour();
    BL5270_Return out = new BL5270_Return();
    out.setNoContrat("10000530150"); //$NON-NLS-1$
    String noTelephone = NO_TELEPHONE;

    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", noTelephone); //$NON-NLS-1$

    PE0223_ResponseFonctionnelle rf = new PE0223_ResponseFonctionnelle();
    List<OptionAppelPfs> optionList = new ArrayList<>();
    OptionAppelPfs optionAppelPfs = new OptionAppelPfs();
    optionAppelPfs.setModeRenvoi("MODE_RENVOI"); //$NON-NLS-1$
    optionList.add(optionAppelPfs);
    rf.setItems(optionList);
    rf.setResultsCount(1);

    PE0223_GetResponse reponse = new PE0223_GetResponse();
    List<OptionAppel> optionAppelList = new ArrayList<>();
    for (OptionAppelPfs option : rf.getItems())
    {
      OptionAppel optionAppel = new OptionAppel();
      String id = out.getNoContrat() + "#" + noTelephone + "#" + option.getType(); //$NON-NLS-1$ //$NON-NLS-2$
      String encryptedId = PasswordEncrypter.encryptForURL(id);
      optionAppel.setIdOptionAppel(encryptedId);

      XAction modifierOptionsAppel = new XAction();
      modifierOptionsAppel.setAction(OPERATION + encryptedId);
      modifierOptionsAppel.setType(MediaType.APPLICATION_JSON);
      modifierOptionsAppel.setMethod(PUT);
      optionAppel.putAction("modifierOptionsAppel", modifierOptionsAppel); //$NON-NLS-1$

      optionAppelList.add(optionAppel);
    }
    reponse.setResultsCount(rf.getResultsCount());
    reponse.setItems(optionAppelList);
    reponse.putLink(XLink.SELF, new XLink("")); //$NON-NLS-1$

    String json = GsonTools.getIso8601Ms().toJson(rf);

    Request request = prepareRequest(_tracabilite, method, NO_TELEPHONE);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    ResponseConnector responseConnector = new ResponseConnector(createConnectorResponse(json), null);

    initializeProcessParams();
    prepareB1700Mock();
    prepareBL5280_Mock(retourOk, noTelephone, TYPE_FIXE);
    prepareBL5270_Mock(retourOk, noTelephone, out);
    prepareProv_SI002(retourOk, "consulterOptionsAppelsPfs", listparams, responseConnector); //$NON-NLS-1$

    PowerMock.replayAll();
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();
    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());

  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PE0223_OptionsAppels();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    PowerMock.mockStatic(BL1700_AjouterRefFoncBuilder.class);
    PowerMock.mockStatic(BL1700_AjouterRefFonc.class);
    PowerMock.mockStatic(BL5280_RecupererTypeAccesNoTelephone.class);
    PowerMock.mockStatic(BL5280_RecupererTypeAccesNoTelephoneBuilder.class);
    PowerMock.mockStatic(BL5270_RecupererPfiParNoTelephone.class);
    PowerMock.mockStatic(BL5270_RecupererPfiParNoTelephoneBuilder.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessus.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessusBuilder.class);
    PowerMock.mockStatic(RPGProxy.class);

  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue("idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    requestHeader_p.add(hdr);
  }

  /**
   * @param json_p
   *          the json to add
   * @return Response
   */
  private com.bytel.spirit.common.connectors.ink.generated.Response createConnectorResponse(String json_p)
  {
    com.bytel.spirit.common.connectors.ink.generated.Response response = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ServiceOrderResponse sor = new ServiceOrderResponse();
    ServiceOrderDataResponse sodr = new ServiceOrderDataResponse();
    Dataset ds = new Dataset();
    DatasetParam dsp = new DatasetParam();

    sor.setOrderId("orderId"); //$NON-NLS-1$
    dsp.setIndex(0);
    dsp.setName(FUNCTIONAL_RESPONSE_PARAM_NAME);
    dsp.setValue(json_p);
    ds.getParams().add(dsp);
    sodr.setDataset(ds);
    sor.setSod(sodr);
    response.setSo(sor);

    return response;
  }

  /**
   * Method used to reset the process configuraton parameters
   */
  private void deleteProcessParams()
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    Map<String, String> params = new HashMap<>();
    processParams.put(StringConstants.EMPTY_STRING, params);
    Whitebox.setInternalState(ProcessManager.getInstance(), "_processParams", processParams); //$NON-NLS-1$
  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _processInstance.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * Method to create the process configuration parameters
   */
  private void initializeProcessParams()
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    Map<String, String> params = new HashMap<>();
    params.put(LISTE_MODE_APPEL_B2R, MODE_APPEL);
    processParams.put(StringConstants.EMPTY_STRING, params);
    Whitebox.setInternalState(ProcessManager.getInstance(), "_processParams", processParams); //$NON-NLS-1$
  }

  /**
   * prepareB1700Mock
   *
   * @throws Exception
   *           exception
   */
  private void prepareB1700Mock() throws Exception
  {
    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700Builder_mock);
    EasyMock.expect(_bl1700Builder_mock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700Builder_mock);
    EasyMock.expect(_bl1700Builder_mock.refFonc(EasyMock.anyObject())).andReturn(_bl1700Builder_mock);
    EasyMock.expect(_bl1700Builder_mock.build()).andReturn(_bl1700_mock);
    EasyMock.expect(_bl1700_mock.execute(EasyMock.anyObject(PE0223_OptionsAppels.class))).andReturn(null);
  }

  /**
   * @param retour_p
   *          retour
   * @param noTelephone_p
   *          The telephone number
   * @param out_p
   *          The mocked output
   * @throws Exception
   *           probleme exception
   */
  private void prepareBL5270_Mock(Retour retour_p, String noTelephone_p, BL5270_Return out_p) throws Exception
  {
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(noTelephone_p)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(_processInstance)).andReturn(out_p);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * @param retour_p
   *          retour
   * @param noTelephone_p
   *          The telephone number
   * @param out_p
   *          The mocked output
   * @throws Exception
   *           probleme exception
   */
  private void prepareBL5280_Mock(Retour retour_p, String noTelephone_p, String out_p) throws Exception
  {
    PowerMock.expectNew(BL5280_RecupererTypeAccesNoTelephoneBuilder.class).andReturn(_bl5280BuilderMock);
    EasyMock.expect(_bl5280BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5280BuilderMock);
    EasyMock.expect(_bl5280BuilderMock.noTelephone(noTelephone_p)).andReturn(_bl5280BuilderMock);
    EasyMock.expect(_bl5280BuilderMock.build()).andReturn(_bl5280Mock);
    EasyMock.expect(_bl5280Mock.execute(_processInstance)).andReturn(out_p);
    EasyMock.expect(_bl5280Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * prepareProv_SI002
   *
   * @param retour_p
   *          retour
   * @param processus_p
   *          The process name
   * @param listParams_p
   *          liste parametres
   * @param reponseConnector_p
   *          reponseconnector
   * @throws Exception
   *           excetpion
   */
  private void prepareProv_SI002(Retour retour_p, String processus_p, ListeParametre listParams_p, ResponseConnector reponseConnector_p) throws Exception
  {
    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.processus(processus_p)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.listeParametres(listParams_p)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.priorite(10)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.build()).andReturn(_si002_mock);
    EasyMock.expect(_si002_mock.execute(_processInstance)).andReturn(reponseConnector_p);
    EasyMock.expect(_si002_mock.getRetour()).andReturn(retour_p);
  }

  /**
   * prepareGetRequest
   *
   * @param tracabilite_p
   *          tracabilite
   * @param methode_p
   *          method
   * @param noTelephone_p
   *          The no telephone
   * @return Request
   * @throws RavelException
   *           exception
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String methode_p, String noTelephone_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    request.setUrlDynamicParameters(noTelephone_p);
    addXHeaders(request.getRequestHeader(), tracabilite_p);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParams = urlParametersType.getUrlParameters();
    urlParams.add(new Parameter("noTelephone", noTelephone_p)); //$NON-NLS-1$
    urlParametersType.setUrlParameters(urlParams);
    request.setUrlParameters(urlParametersType);
    return request;
  }
}