/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0277;

import static org.junit.Assert.assertEquals;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.oi.OI_SI003_PBO;
import com.bytel.spirit.common.activities.oi.OI_SI003_PBO.OI_SI003_PBOBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.PBOs;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0277.structs.PE0277_BL001_VerifierDonneesPboReturn;
import com.bytel.spirit.fiat.processes.PE0277.structs.PE0277_Retour;
import com.bytel.spirit.fiat.shared.types.json.PBO;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author rrosa
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PrepareForTest({ ProcessManager.class, PE0277_RessourcePBO.class, OI_SI003_PBO.class, OI_SI003_PBOBuilder.class })
public class PE0277_RessourcePBOTest extends EasyMockSupport
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
  *
  */
  private static final String PE0277_BL001_VERIFIER_DONNEES_PBO = "PE0277_BL001_VerifierDonnesPbo"; //$NON-NLS-1$

  /**
  *
  */
  private static final String PE0277_BL002_FORMATER_RESPONSE_PBO = "PE0277_BL002_FormaterReponsePbo"; //$NON-NLS-1$

  /**
   * Podam instance
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  static
  {
    __podam = new PodamFactoryImpl();
  }

  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void beforeClassSetup() throws RavelException
  {
    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
  *
  */
  @MockStrict
  private OI_SI003_PBO _oiSi003Mock;

  /**
   *
   */
  @MockStrict
  private OI_SI003_PBOBuilder _oiSi003BuilderMock;
  /**
  *
  */
  @MockStrict
  private ProcessManager _pmMock;

  /**
   * Instance of {@link PE0277_RessourcePBO}
   */
  private PE0277_RessourcePBO _processInstance;

  /**
   * Initialization of tests
   *
   */
  @Before
  public void init()
  {
    // context initialization
    _processInstance = new PE0277_RessourcePBO();
    _processInstance.initializeContext();

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(null);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    PowerMock.resetAll();
    PowerMock.mockStatic(ProcessManager.class);
    PowerMock.mockStatic(OI_SI003_PBO.class);
    PowerMock.mockStatic(OI_SI003_PBOBuilder.class);

  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field X-Source is not set<br>
   * <b>Result:</b> Header X-Source null ou vide.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0277_BL001_VerifierDonnes_Test_KO_01() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$

    fillRequestHeaders(request, xRequestId, xProcess);

    PE0277_BL001_VerifierDonneesPboReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0277_BL001_VERIFIER_DONNEES_PBO, _tracabilite, request);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0277.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_SOURCE), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field X-Request-Id is not set<br>
   * <b>Result:</b> Header X-Request-Id null ou vide.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0277_BL001_VerifierDonnes_Test_KO_02() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$

    fillRequestHeaders(request, xSource, xProcess);

    PE0277_BL001_VerifierDonneesPboReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0277_BL001_VERIFIER_DONNEES_PBO, _tracabilite, request);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0277.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field X-Process is not set<br>
   * <b>Result:</b> Header X-Process null ou vide.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0277_BL001_VerifierDonnes_Test_KO_03() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "X-SOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xSource, xRequestId);

    PE0277_BL001_VerifierDonneesPboReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0277_BL001_VERIFIER_DONNEES_PBO, _tracabilite, request);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0277.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_PROCESS), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The parameter OI is not set<br>
   * <b>Result:</b> Paramètre OI null.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0277_BL001_VerifierDonnes_Test_KO_04() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$

    fillRequestHeaders(request, xSource, xRequestId, xProcess);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PE0277_BL001_VerifierDonneesPboReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0277_BL001_VERIFIER_DONNEES_PBO, _tracabilite, request);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0277.BL001.ParametersNullOrEmpty"), PE0277_RessourcePBO.IRequestParameters.OI), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The parameter refPrestationPrise is not set<br>
   * <b>Result:</b> Paramètre refPrestationPrise null.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0277_BL001_VerifierDonnes_Test_KO_05() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$

    fillRequestHeaders(request, xSource, xRequestId, xProcess);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PE0277_BL001_VerifierDonneesPboReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0277_BL001_VERIFIER_DONNEES_PBO, _tracabilite, request);

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0277.BL001.ParametersNullOrEmpty"), PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE), null); //$NON-NLS-1$

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b>Assert that validation errors does not exist.<br>
   * <b>Input:</b> All parameters are set.<br>
   * <b>Result:</b> OK.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0277_BL001_VerifierDonnes_Test_OK() throws Exception
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$

    fillRequestHeaders(request, xSource, xRequestId, xProcess);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PE0277_BL001_VerifierDonneesPboReturn bl001Retour = Whitebox.invokeMethod(_processInstance, PE0277_BL001_VERIFIER_DONNEES_PBO, _tracabilite, request);

    Retour retourExpected = RetourFactory.createOkRetour();
    assertEquals(retourExpected, bl001Retour.getRetour());
    assertEquals("FTEL", bl001Retour.getOi()); //$NON-NLS-1$
    assertEquals("refPP1234", bl001Retour.getRefPrestationPrise()); //$NON-NLS-1$
  }

  /**
   * PE0277_BL002_FormaterReponsePbo KO
   *
   * Retour KO (CAT3/NON_RESPECT_STI)
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0277_BL002_FormaterReponsePbo_KO_001() throws Exception
  {
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0277.BL001.ParametersNullOrEmpty"), PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE), null); //$NON-NLS-1$
    ReponseErreur responseErreur = new ReponseErreur();
    responseErreur.setError(retour.getDiagnostic());
    responseErreur.setErrorDescription(retour.getLibelle());

    Pair<ReponseErreur, PE0277_Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0277_BL002_FORMATER_RESPONSE_PBO, retour, null);

    assertEquals(responseErreur, bl001Retour._first);
  }

  /**
   * <b>Scenario:</b>Assert that validation errors does not exist.<br>
   * <b>Input:</b> All parameters are set.<br>
   * <b>Result:</b> OK.<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0277_BL002_FormaterReponsePbo_OK() throws Exception
  {
    Integer nombreFibres = 1;
    Retour retour = RetourFactory.createOkRetour();

    com.bytel.spirit.common.connector.oi.emutation.structs.ReferencesAdresse ra1 = new com.bytel.spirit.common.connector.oi.emutation.structs.ReferencesAdresse(null, null, null, null, null, "adresse"); //$NON-NLS-1$
    com.bytel.spirit.common.connector.oi.emutation.structs.Adresse a1 = new com.bytel.spirit.common.connector.oi.emutation.structs.Adresse(ra1, null, null, null, null, null, null);
    com.bytel.spirit.common.connector.oi.emutation.structs.ComplementAdresse ca1 = new com.bytel.spirit.common.connector.oi.emutation.structs.ComplementAdresse("batiment", "escalier", "etage"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<com.bytel.spirit.common.connector.oi.emutation.structs.PBO> listePbos = new ArrayList<>();
    com.bytel.spirit.common.connector.oi.emutation.structs.PBO pbo1 = new com.bytel.spirit.common.connector.oi.emutation.structs.PBO("referencePM1", "referencePBO1", a1, ca1, nombreFibres, "naturePBO1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    listePbos.add(pbo1);
    PBOs pbosIn = new PBOs(listePbos);

    Pair<ReponseErreur, PE0277_Retour> bl002Retour = Whitebox.invokeMethod(_processInstance, PE0277_BL002_FORMATER_RESPONSE_PBO, retour, pbosIn);

    assertEquals(null, bl002Retour._first);
    assertEquals(a1.getReferencesAdresse().getAdresseLibre(), bl002Retour._second.getItems().get(0).getAdressePBO().getReferencesAdresse().getAdresseLibre());
    assertEquals(1, bl002Retour._second.getItems().size());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field X-Source is not set<br>
   * <b>Result:</b> ErrorCode.KO_00400.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_K0_001() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    fillRequestHeaders(request, xProcess, xRequestId);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    String jsonexpect = "{\"error\":\"NON_RESPECT_STI\",\"error_description\":\"Header X-Source null ou vide.\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);
    final Response expected = new Response(ErrorCode.KO_00400, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field X-Request-Id is not set<br>
   * <b>Result:</b> ErrorCode.KO_00400.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_K0_002() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xProcess);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    String jsonexpect = "{\"error\":\"NON_RESPECT_STI\",\"error_description\":\"Header X-Request-Id null ou vide.\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);
    final Response expected = new Response(ErrorCode.KO_00400, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field X-Process is not set<br>
   * <b>Result:</b> ErrorCode.KO_00400.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_K0_003() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xRequestId);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    String jsonexpect = "{\"error\":\"NON_RESPECT_STI\",\"error_description\":\"Header X-Process null ou vide.\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);
    final Response expected = new Response(ErrorCode.KO_00400, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The parameter OI is not set<br>
   * <b>Result:</b> ErrorCode.KO_00400.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_K0_004() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xRequestId, xProcess);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);
    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    String jsonexpect = "{\"error\":\"NON_RESPECT_STI\",\"error_description\":\"Paramètre OI null\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);
    final Response expected = new Response(ErrorCode.KO_00400, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The parameter refPrestationPrise is not set<br>
   * <b>Result:</b> ErrorCode.KO_00400.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_K0_005() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xRequestId, xProcess);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    String jsonexpect = "{\"error\":\"NON_RESPECT_STI\",\"error_description\":\"Paramètre refPrestationPrise null\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);
    final Response expected = new Response(ErrorCode.KO_00400, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> OSI_003 returns KO PRESTATION_PRISE_INCONNUE<br>
   * <b>Result:</b> ErrorCode.KO_00404.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_KO_006() throws Throwable
  {
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PRESTATION_PRISE_INCONNUE, "inconnue"); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xRequestId, xProcess);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PBOs pbosIn = null;

    mockOISI003("FTEL", "refPP1234", ko, pbosIn); //$NON-NLS-1$ //$NON-NLS-2$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat("KO"); //$NON-NLS-1$
    PE0277_Retour pe0277Ret = new PE0277_Retour();
    pe0277Ret.setItems(null);

    String jsonexpect = "{\"error\":\"PRESTATION_PRISE_INCONNUE\",\"error_description\":\"La référence de la prestation prise refPP1234 est inconnue\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);

    final Response expected = new Response(ErrorCode.KO_00404, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> OSI_003 returns KO ECHEC_PARTENAIRE<br>
   * <b>Result:</b> ErrorCode.KO_00404.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_KO_007() throws Throwable
  {
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ECHEC_PARTENAIRE, ""); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xRequestId, xProcess);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PBOs pbosIn = null;

    mockOISI003("FTEL", "refPP1234", ko, pbosIn); //$NON-NLS-1$ //$NON-NLS-2$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat("KO"); //$NON-NLS-1$
    PE0277_Retour pe0277Ret = new PE0277_Retour();
    pe0277Ret.setItems(null);

    String jsonexpect = "{\"error\":\"ECHEC_PARTENAIRE\",\"error_description\":\"\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);

    final Response expected = new Response(ErrorCode.KO_00404, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> OSI_003 returns KO SERVICE_TIERS_INDISPONIBLE<br>
   * <b>Result:</b> ErrorCode.KO_00503.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_KO_008() throws Throwable
  {
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.SERVICE_TIERS_INDISPONIBLE, ""); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xRequestId, xProcess);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PBOs pbosIn = null;

    mockOISI003("FTEL", "refPP1234", ko, pbosIn); //$NON-NLS-1$ //$NON-NLS-2$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat("KO"); //$NON-NLS-1$
    PE0277_Retour pe0277Ret = new PE0277_Retour();
    pe0277Ret.setItems(null);

    String jsonexpect = "{\"error\":\"SERVICE_TIERS_INDISPONIBLE\",\"error_description\":\"\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);

    final Response expected = new Response(ErrorCode.KO_00503, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> OSI_003 returns KO OTHER<br>
   * <b>Result:</b> ErrorCode.KO_00500.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_KO_009() throws Throwable
  {
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT4, "OTHER", ""); //$NON-NLS-1$ //$NON-NLS-2$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xRequestId, xProcess);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PBOs pbosIn = null;

    mockOISI003("FTEL", "refPP1234", ko, pbosIn); //$NON-NLS-1$ //$NON-NLS-2$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat("KO"); //$NON-NLS-1$
    PE0277_Retour pe0277Ret = new PE0277_Retour();
    pe0277Ret.setItems(null);

    String jsonexpect = "{\"error\":\"OTHER\",\"error_description\":\"\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);

    final Response expected = new Response(ErrorCode.KO_00500, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> OSI_003 returns KO FLUX_BIENTOT_DISPONIBLE<br>
   * <b>Result:</b> ErrorCode.KO_00503.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_KO_010() throws Throwable
  {
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.FLUX_BIENTOT_DISPONIBLE, ""); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xRequestId, xProcess);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PBOs pbosIn = null;

    mockOISI003("FTEL", "refPP1234", ko, pbosIn); //$NON-NLS-1$ //$NON-NLS-2$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat("KO"); //$NON-NLS-1$
    PE0277_Retour pe0277Ret = new PE0277_Retour();
    pe0277Ret.setItems(null);

    String jsonexpect = "{\"error\":\"FLUX_BIENTOT_DISPONIBLE\",\"error_description\":\"\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);

    final Response expected = new Response(ErrorCode.KO_00503, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> OSI_003 returns KO FLUX_INDISPONIBLE<br>
   * <b>Result:</b> ErrorCode.KO_00503.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_KO_011() throws Throwable
  {
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.FLUX_INDISPONIBLE, ""); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xRequestId, xProcess);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PBOs pbosIn = null;

    mockOISI003("FTEL", "refPP1234", ko, pbosIn); //$NON-NLS-1$ //$NON-NLS-2$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat("KO"); //$NON-NLS-1$
    PE0277_Retour pe0277Ret = new PE0277_Retour();
    pe0277Ret.setItems(null);

    String jsonexpect = "{\"error\":\"FLUX_INDISPONIBLE\",\"error_description\":\"\"}"; //$NON-NLS-1$
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);

    final Response expected = new Response(ErrorCode.KO_00503, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The parameter refPrestationPrise is not set<br>
   * <b>Result:</b> ErrorCode.KO_00400.<br>
   *
   * @throws Throwable
   *           in case of error
   *
   */
  @Test
  public void PE0277_RessourcesEmutation_OK() throws Throwable
  {
    Retour ok = RetourFactoryForTU.createOkRetour();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_PBO_VOISINS"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource, xRequestId, xProcess);
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.OI, "FTEL")); //$NON-NLS-1$
    list.add(new Parameter(PE0277_RessourcePBO.IRequestParameters.REF_PRESTATION_PRISE, "refPP1234")); //$NON-NLS-1$
    urlParametersType.setUrlParameters(list);
    request.setUrlParameters(urlParametersType);

    PBOs pbosIn = createPBOs();

    mockOISI003("FTEL", "refPP1234", ok, pbosIn); //$NON-NLS-1$ //$NON-NLS-2$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    List<PBO> listePbo = new ArrayList<>();
    PBO pbo = new PBO(pbosIn.getPbos().get(0));
    listePbo.add(pbo);

    com.bytel.ravel.types.Retour retour = new com.bytel.ravel.types.Retour();
    retour.setResultat("OK"); //$NON-NLS-1$
    PE0277_Retour pe0277Ret = new PE0277_Retour();
    pe0277Ret.setItems(listePbo);

    String jsonexpect = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0277Ret);
    IRavelResponse response = RavelResponseFactory.getInstance().createResponse();
    response.setDataType(HttpConstants.CONTENT_TYPE_JSON);
    response.setResult(jsonexpect);

    final Response expected = new Response(ErrorCode.OK_00200, response);
    assertEquals(expected.getErrorCode(), request.getResponse().getErrorCode());
    assertEquals(expected.getMarshalledResponseJson(), request.getResponse().getMarshalledResponseJson());
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * @return {@link PBOs}}
   */
  private PBOs createPBOs()
  {
    Integer nombreFibres = 1;
    com.bytel.spirit.common.connector.oi.emutation.structs.ComplementAdresse ca1 = new com.bytel.spirit.common.connector.oi.emutation.structs.ComplementAdresse("batiment", "escalier", "etage"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    List<com.bytel.spirit.common.connector.oi.emutation.structs.PBO> listePbos = new ArrayList<>();
    com.bytel.spirit.common.connector.oi.emutation.structs.ReferencesAdresse ra1 = new com.bytel.spirit.common.connector.oi.emutation.structs.ReferencesAdresse(null, null, null, null, null, "adresse"); //$NON-NLS-1$
    com.bytel.spirit.common.connector.oi.emutation.structs.Adresse a1 = new com.bytel.spirit.common.connector.oi.emutation.structs.Adresse(ra1, null, null, null, null, null, null);
    com.bytel.spirit.common.connector.oi.emutation.structs.PBO pbo1 = new com.bytel.spirit.common.connector.oi.emutation.structs.PBO("referencePM1", "referencePBO1", a1, ca1, nombreFibres, "naturePBO1"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    listePbos.add(pbo1);
    PBOs pbosIn = new PBOs(listePbos);
    return pbosIn;
  }

  /**
   * Create ProcessManager mock
   */
  private void createProcessManagerManagerMock()
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<String, Map<String, String>>();
    processParams.put("", new HashMap<String, String>()); //$NON-NLS-1$
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_pmMock).anyTimes();
    EasyMock.expect(_pmMock.getProcessParams()).andReturn(processParams).anyTimes();

  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * @param oi_p
   *          the oi
   * @param refPrestationprise_p
   *          the refPrestationprise
   * @param retour_p
   *          the retour
   * @param pbos_p
   *          the pbos
   * @throws Exception
   *           in case of error
   */
  private void mockOISI003(String oi_p, String refPrestationprise_p, Retour retour_p, PBOs pbos_p) throws Exception
  {
    PowerMock.expectNew(OI_SI003_PBOBuilder.class).andReturn(_oiSi003BuilderMock);
    EasyMock.expect(_oiSi003BuilderMock.tracabilite(EasyMock.anyObject())).andReturn(_oiSi003BuilderMock);
    EasyMock.expect(_oiSi003BuilderMock.codeOi(oi_p)).andReturn(_oiSi003BuilderMock);
    EasyMock.expect(_oiSi003BuilderMock.refPrestationprise(refPrestationprise_p)).andReturn(_oiSi003BuilderMock);
    EasyMock.expect(_oiSi003BuilderMock.build()).andReturn(_oiSi003Mock);
    EasyMock.expect(_oiSi003Mock.execute(_processInstance)).andReturn(pbos_p);
    EasyMock.expect(_oiSi003Mock.getRetour()).andReturn(retour_p);
  }

}
