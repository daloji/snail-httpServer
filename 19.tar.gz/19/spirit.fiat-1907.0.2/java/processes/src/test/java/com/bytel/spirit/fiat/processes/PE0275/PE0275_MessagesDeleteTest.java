/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0275;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.ink.generated.Dataset;
import com.bytel.spirit.common.connectors.ink.generated.DatasetParam;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderDataResponse;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderResponse;
import com.bytel.spirit.common.shared.functional.types.json.MessagePfsVoix;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;

import io.netty.util.internal.StringUtil;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0275_Messages.class, ProcessManager.class, PROV_SI002_ExecuterProcessusBuilder.class, PROV_SI002_ExecuterProcessus.class })
public class PE0275_MessagesDeleteTest
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * LISTER_OPERATION
   */
  private static final String SUPPRIMER_OPERATION = "PE0275_Messages"; //$NON-NLS-1$

  /**
   * Configuration path Param
   */
  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   *
   */
  private static final String PARAM_FRONT_ADRESSE = "FRONT_ADRESSE"; //$NON-NLS-1$

  /**
   * The X_REQUEST_ID_VALUE
   */
  private static final String X_REQUEST_ID_VALUE = "125667889000877"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0275_Messages"; //$NON-NLS-1$

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    Parameter parameter = new Parameter();

    parameter.setName(name_p);
    parameter.setValue(value_p);

    return parameter;
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    try
    {
      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager is now initialized")); //$NON-NLS-1$
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager instance is already initialized")); //$NON-NLS-1$
    }

  }

  /**
   * Instance of {@link PE0275_Messages}
   */
  private PE0275_Messages _processInstance;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  ProcessManager _processManager;

  /**
   * PROV_SI002_ExecuterProcessusBuilder
   */
  @MockStrict
  PROV_SI002_ExecuterProcessusBuilder _si002_mockbuilder;

  /**
   * PROV_SI002_ExecuterProcessus
   */
  @MockStrict
  PROV_SI002_ExecuterProcessus _si002_mock;

  /**
   * PE0275_BL100_SupprimerMessagePfs error decryptage
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_SupprimerListeMessagePfs_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, "T1Ivr8FTvyIJfosxu4gRwzYMZKt+pWECPm945m+WgrQgsoOMyJ3uHw=", null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, SUPPRIMER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ID_MESSAGE_INCONNU);
    responseErreeurExpected.setErrorDescription("L'id Message T1Ivr8FTvyIJfosxu4gRwzYMZKt+pWECPm945m+WgrQgsoOMyJ3uHw= est inconnu."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_SupprimerMessagePfs operation not autorised for message type
   *
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_SupprimerListeMessagePfs_KO_002() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#+33123456789#messageriePfs#typePfs#idMessagePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, encryptedUrlParameter, null);

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, SUPPRIMER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Operation non Autorisee pour le message " + encryptedUrlParameter + " de type typePfs."); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_SupprimerMessagePfs noContrat null or empty
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_SupprimerListeMessagePfs_KO_003() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("#typePfs#idMessageriePfs#VOIX#idMessagePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    Response response = executeStartProcess(request, SUPPRIMER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreeurExpected.setErrorDescription("Acces refuse."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_SupprimerMessagePfs acess refused
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_SupprimerListeMessagePfs_KO_004() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#typePfs#idMessageriePfs#VOIX#idMessagePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    Response response = executeStartProcess(request, SUPPRIMER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreeurExpected.setErrorDescription("Acces refuse."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_SupprimerMessagePfs error calling KPSA CAT1
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_SupprimerListeMessagePfs_KO_005() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#typePfs#idMessageriePfs#VOIX#idMessagePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.DONNEE_INCONNUE, "libelle"); //$NON-NLS-1$
    prepareProcessParameters();

    prepareProv_SI002(ko, null);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, SUPPRIMER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_SupprimerListeMessagePfs error calling KPSA CAT2
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_SupprimerListeMessagePfs_KO_006() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#typePfs#idMessageriePfs#VOIX#idMessagePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.DONNEE_INCONNUE, "libelle"); //$NON-NLS-1$
    prepareProcessParameters();

    prepareProv_SI002(ko, null);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, SUPPRIMER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_SupprimerListeMessagePfs error calling KPSA not CAT1/CAT2
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_SupprimerListeMessagePfs_KO_007() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#typePfs#idMessageriePfs#VOIX#idMessagePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "libelle"); //$NON-NLS-1$
    prepareProcessParameters();

    prepareProv_SI002(ko, null);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, SUPPRIMER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegConsts.DONNEE_INCONNUE);
    responseErreeurExpected.setErrorDescription("libelle"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_SupprimerListeMessagePfs error URL parameters are not completed
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_SupprimerListeMessagePfs_KO_008() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#typePfs#idMessageriePfs#VOIX"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, SUPPRIMER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ID_MESSAGE_INCONNU);
    responseErreeurExpected.setErrorDescription("L'id Message " + encryptedUrlParameter + " est inconnu."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Missing config files
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_BL001_VerifierDonneesSuppression_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, null, null);
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(null, null);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(3);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).times(3);

    PowerMock.replayAll();

    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegConsts.CONFIGURATION_INVALIDE);
    responseErreeurExpected.setErrorDescription("Cannot find param FRONT_ADRESSE in process configuration"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Missing idMessage
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_BL001_VerifierDonneesSuppression_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, null, null);

    prepareProcessParameters();

    PowerMock.replayAll();

    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter idMessage is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Nominal for ListerAnnonce
   *
   * Status Code = 204
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_SupprimerListeMessagePfs_nominal() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#typePfs#idMessageriePfs#VOIX#idMessagePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.DEL_METHOD, encryptedUrlParameter, "idc=144104,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    prepareProcessParameters();

    ResponseConnector reponseConnector = createResponseConnector();
    prepareProv_SI002(RetourFactory.createOkRetour(), reponseConnector);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    Response response = executeStartProcess(request, SUPPRIMER_OPERATION);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00204, response.getErrorCode());
  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PE0275_Messages();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setNomProcessus(DEFAULT_PROCESSNAME);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessus.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessusBuilder.class);
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   *
   *
   * @param listeContract_p
   *          listeContract
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p, String listeContract_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("ClientOperateur"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
    hdr.setValue("Authorization : bearer XXXX"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue(listeContract_p);
    requestHeader_p.add(hdr);
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * @param key_p
   *          The key
   * @param value_p
   *          The value
   * @return process params
   */
  private ConcurrentHashMap<String, Map<String, String>> createProcessParams(String key_p, String value_p)
  {
    File classpath = new File(PE0275_MessagesDeleteTest.class.getResource("/").getFile()); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    if (!StringUtil.isNullOrEmpty(key_p))
    {
      map.put(key_p, classpath + "/" + value_p); //$NON-NLS-1$
    }

    processParams.put(StringConstants.EMPTY_STRING, map);
    return processParams;
  }

  /**
   * Create Response connector
   *
   * @return ResponseConnector
   */
  private ResponseConnector createResponseConnector()
  {
    com.bytel.spirit.common.connectors.ink.generated.Response response = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector reponseConnector = __podam.manufacturePojo(ResponseConnector.class);
    ReponseFonctionnelle reponsefonctionnel = new ReponseFonctionnelle();
    reponsefonctionnel.setResultsCount(1);
    List<MessagePfsVoix> items_p = new ArrayList<>();
    MessagePfsVoix messagesPfs = new MessagePfsVoix();
    messagesPfs.setIdMessagePfs("idMessagePfs_p"); //$NON-NLS-1$
    messagesPfs.setStatutLecture("statutLecture_p"); //$NON-NLS-1$
    messagesPfs.setTypeMessage("typeMessage_p"); //$NON-NLS-1$
    items_p.add(messagesPfs);
    reponsefonctionnel.setItems(items_p);
    String result = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss).toJson(reponsefonctionnel);
    Dataset dataset = new Dataset();
    List<DatasetParam> listdata = new ArrayList<>();
    DatasetParam datasetparam = new DatasetParam();
    datasetparam.setIndex(1);
    datasetparam.setName("reponseFonctionnelle"); //$NON-NLS-1$
    datasetparam.setValue(result);
    listdata.add(datasetparam);
    dataset.getParams().add(datasetparam);
    ServiceOrderDataResponse serviceData = new ServiceOrderDataResponse();
    serviceData.setDataset(dataset);
    ServiceOrderResponse so = new ServiceOrderResponse();
    so.setSod(serviceData);
    response.setSo(so);
    reponseConnector.setResponse(response);
    return reponseConnector;

  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _processInstance.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * Fills all the request headers
   *
   * @param request_p
   *          The request
   */
  private void fillAllRequestHeaders(Request request_p)
  {
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, X_REQUEST_ID_VALUE);
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    //RequestHeader xOauth2Idcontracts = createHeader(IHttpHeadersConsts.X_OAUTH2_IDCONTRACTS, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    fillRequestHeaders(request_p, xClientOperateur, xRequestId, xSource, xProcess);
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   *
   */
  private void prepareProcessParameters()
  {

    File classpath = new File(PE0275_MessagesPostTest.class.getResource("/").getFile()); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    map.put(PARAM_FRONT_ADRESSE, "localhost:8000"); //$NON-NLS-1$
    map.put(PARAM_CONFIG_PATH, classpath + "/" + "ConfigurationPE0275.xml");
    processParams.put(StringConstants.EMPTY_STRING, map);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();
  }

  /**
   * prepareProv_SI002
   *
   * @param retour_p
   *          retour
   * @param reponseConnector_p
   *          reponseconnector
   * @throws Exception
   *           excetpion
   */
  private void prepareProv_SI002(Retour retour_p, ResponseConnector reponseConnector_p) throws Exception
  {
    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.cles(EasyMock.anyObject())).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.priorite(10)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.processus(EasyMock.anyObject())).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.listeParametres(EasyMock.anyObject())).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.build()).andReturn(_si002_mock);
    EasyMock.expect(_si002_mock.execute(_processInstance)).andReturn(reponseConnector_p);
    EasyMock.expect(_si002_mock.getRetour()).andReturn(retour_p);
  }

  /**
   * prepareGetRequest
   *
   * @param tracabilite_p
   *          tracabilite
   * @param methode_p
   *          method
   * @param parameter_p
   *          idMessagerie / idMessage
   * @param listeContact_p
   *          listeContact
   * @return Request
   * @throws RavelException
   *           exception
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String methode_p, String parameter_p, String listeContact_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    addXHeaders(request.getRequestHeader(), tracabilite_p, listeContact_p);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParams = urlParametersType.getUrlParameters();

    if (parameter_p != null)
    {
      urlParams.add(createParameter("idMessages", parameter_p));
    }

    urlParametersType.setUrlParameters(urlParams);
    request.setUrlParameters(urlParametersType);

    return request;
  }
}