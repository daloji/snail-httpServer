/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PI0311;

import static org.junit.Assert.assertEquals;

import java.nio.file.Files;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI034_PersonnaliserAnnonceAccueil;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI034_PersonnaliserAnnonceAccueil.VMSCVM_SI034_PersonnaliserAnnonceAccueilBuilder;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI101_ImporterMessage;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI101_ImporterMessage.VMSCVM_SI101_ImporterMessageBuilder;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI101_ExporterMessages;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI101_ExporterMessages.VMSSTW_SI101_ExporterMessagesBuilder;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI102_ExporterAnnonces;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI102_ExporterAnnonces.VMSSTW_SI102_ExporterAnnoncesBuilder;
import com.bytel.spirit.common.connectors.streamwide.StreamWideProxy;
import com.bytel.spirit.common.shared.functional.types.Annonce;
import com.bytel.spirit.common.shared.functional.types.Message;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PI0311.structs.PI0311_BL001Return;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ Files.class, PI0311_MigrerMessagerie.class, VMSCVM_SI034_PersonnaliserAnnonceAccueil.class, VMSCVM_SI034_PersonnaliserAnnonceAccueilBuilder.class, VMSSTW_SI102_ExporterAnnonces.class, VMSSTW_SI102_ExporterAnnoncesBuilder.class, VMSCVM_SI101_ImporterMessage.class, VMSCVM_SI101_ImporterMessageBuilder.class, StreamWideProxy.class, VMSSTW_SI101_ExporterMessages.class, VMSSTW_SI101_ExporterMessagesBuilder.class })
public class PI0311_MigrerMessagerieTest
{

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;
  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PI0311_MigrerMessagerie"; //$NON-NLS-1$

  /**
   *
   */
  private static final String NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   *
   */
  private static final String ID_VMSSTW = "idVmsStw"; //$NON-NLS-1$

  /**
   * method
   */
  private static String _method = "POST"; //$NON-NLS-1$

  /**
   * Temp folder to store message/annonce files.
   */
  private static final String TEMP_FOLFER = "/tmp/"; //$NON-NLS-1$

  /**
   * Initialize before all tests
   *
   * @throws Exception
   *           On errors Exception to be thrown in case of failure
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam = new PodamFactoryImpl();
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(__podam);
  }

  /**
   * VMSCVM_SI034_PersonnaliserAnnonceAccueilBuilder
   */
  @MockStrict
  private VMSCVM_SI034_PersonnaliserAnnonceAccueilBuilder _personnaliserAABuilderMock;

  /**
   * VMSCVM_SI034_PersonnaliserAnnonceAccueil
   */
  @MockStrict
  private VMSCVM_SI034_PersonnaliserAnnonceAccueil _personnaliserAAMock;

  /**
   * VMSSTW_SI102_exporterAnnoncesBuilder
   */
  @MockStrict
  private VMSSTW_SI102_ExporterAnnoncesBuilder _exporterAnnoncesBuilderMock;

  /**
   * VMSSTW_SI102_exporterAnnonces
   */
  @MockStrict
  private VMSSTW_SI102_ExporterAnnonces _exporterAnnoncesMock;

  /**
   * StreamWideProxy
   */
  @MockStrict
  private StreamWideProxy _streamWideProxyMock;

  /**
   * VMSSTW_SI101_ExporterMessagesBuilder
   */
  @MockStrict
  private VMSSTW_SI101_ExporterMessagesBuilder _exporterMessagesBuilderMock;

  /**
   * VMSSTW_SI101_ExporterMessages
   */
  @MockStrict
  private VMSSTW_SI101_ExporterMessages _exporterMessagesMock;

  /**
   * VMSCVM_SI101_ImporterMessageBuilder
   */
  @MockStrict
  private VMSCVM_SI101_ImporterMessageBuilder _importerMessageBuilderMock;

  /**
   * VMSCVM_SI101_ImporterMessage
   */
  @MockStrict
  private VMSCVM_SI101_ImporterMessage _importerMessageMock;

  /**
   * Instance to evaluate
   */
  private PI0311_MigrerMessagerie _processInstance;

  /**
   * Test KO Metadata.noTelehone not set
   *
   * @throws Throwable
   *
   */
  @Test
  public void PI0311_BL001_VerifierDonnees_NOK_001() throws Throwable
  {

    String noTelephone = null;
    String idVmsStw = "789324g32uiedg"; //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, idVmsStw, _method);

    fillRequestHeaders(request, xSource, xProcess, xRequestId, xMessageId, xActionId);

    String msg = MessageFormat.format(Messages.getString("PI0311.BL001.MissingParameter"), NO_TELEPHONE); //$NON-NLS-1$
    PI0311_BL001Return retourBl001Expected = new PI0311_BL001Return(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, msg));

    _processInstance.run(request);
    Response response = (Response) request.getResponse();

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    com.bytel.ravel.types.Retour retour = RavelJsonTools.getInstance().fromJson(response.getResult(), com.bytel.ravel.types.Retour.class);
    assertEquals(retourBl001Expected.getRetour().getResultat(), retour.getResultat());
    assertEquals(retourBl001Expected.getRetour().getCategorie(), retour.getCategorie());
    assertEquals(retourBl001Expected.getRetour().getDiagnostic(), retour.getDiagnostic());
    assertEquals(retourBl001Expected.getRetour().getLibelle(), retour.getLibelle());
  }

  /**
   * Test KO Metadata.idVmsStw not set
   *
   * @throws Throwable
   *
   */
  @Test
  public void PI0311_BL001_VerifierDonnees_NOK_002() throws Throwable
  {

    String noTelephone = "+33761562748"; //$NON-NLS-1$
    String idVmsStw = null;

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, idVmsStw, _method);

    fillRequestHeaders(request, xSource, xProcess, xRequestId, xMessageId, xActionId);

    String msg = MessageFormat.format(Messages.getString("PI0311.BL001.MissingParameter"), ID_VMSSTW); //$NON-NLS-1$
    PI0311_BL001Return retourBl001Expected = new PI0311_BL001Return(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, msg));

    _processInstance.run(request);
    Response response = (Response) request.getResponse();

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    com.bytel.ravel.types.Retour retour = RavelJsonTools.getInstance().fromJson(response.getResult(), com.bytel.ravel.types.Retour.class);
    assertEquals(retourBl001Expected.getRetour().getResultat(), retour.getResultat());
    assertEquals(retourBl001Expected.getRetour().getCategorie(), retour.getCategorie());
    assertEquals(retourBl001Expected.getRetour().getDiagnostic(), retour.getDiagnostic());
    assertEquals(retourBl001Expected.getRetour().getLibelle(), retour.getLibelle());
  }

  /**
   * Test KO Metadata.noTelephone invalid format(without "+")
   *
   * @throws Throwable
   *
   */
  @Test
  public void PI0311_BL001_VerifierDonnees_NOK_003() throws Throwable
  {

    String noTelephone = "127615798978"; //$NON-NLS-1$
    String idVmsStw = "789324g32uiedg"; //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, idVmsStw, _method);

    fillRequestHeaders(request, xSource, xProcess, xRequestId, xMessageId, xActionId);

    String msg = MessageFormat.format(Messages.getString("PI0311.BL001.NoTelephoneInvalide"), noTelephone); //$NON-NLS-1$
    PI0311_BL001Return retourBl001Expected = new PI0311_BL001Return(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, msg));

    _processInstance.run(request);
    Response response = (Response) request.getResponse();

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    com.bytel.ravel.types.Retour retour = RavelJsonTools.getInstance().fromJson(response.getResult(), com.bytel.ravel.types.Retour.class);
    assertEquals(retourBl001Expected.getRetour().getResultat(), retour.getResultat());
    assertEquals(retourBl001Expected.getRetour().getCategorie(), retour.getCategorie());
    assertEquals(retourBl001Expected.getRetour().getDiagnostic(), retour.getDiagnostic());
    assertEquals(retourBl001Expected.getRetour().getLibelle(), retour.getLibelle());
  }

  /**
   * Test KO Metadata.noTelephone invalid format(more than 15 digits)
   *
   * @throws Throwable
   *
   */
  @Test
  public void PI0311_BL001_VerifierDonnees_NOK_004() throws Throwable
  {

    String noTelephone = "+3312761579897861"; //$NON-NLS-1$
    String idVmsStw = "789324g32uiedg"; //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, idVmsStw, _method);

    fillRequestHeaders(request, xSource, xProcess, xRequestId, xMessageId, xActionId);

    String msg = MessageFormat.format(Messages.getString("PI0311.BL001.NoTelephoneInvalide"), noTelephone); //$NON-NLS-1$
    PI0311_BL001Return retourBl001Expected = new PI0311_BL001Return(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, msg));

    _processInstance.run(request);
    Response response = (Response) request.getResponse();

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    com.bytel.ravel.types.Retour retour = RavelJsonTools.getInstance().fromJson(response.getResult(), com.bytel.ravel.types.Retour.class);
    assertEquals(retourBl001Expected.getRetour().getResultat(), retour.getResultat());
    assertEquals(retourBl001Expected.getRetour().getCategorie(), retour.getCategorie());
    assertEquals(retourBl001Expected.getRetour().getDiagnostic(), retour.getDiagnostic());
    assertEquals(retourBl001Expected.getRetour().getLibelle(), retour.getLibelle());
  }

  /**
   * Test KO Metadata.idVmsStw invalid (not present in the configuration)
   *
   * @throws Throwable
   *
   */
  @Test
  public void PI0311_BL001_VerifierDonnees_NOK_005() throws Throwable
  {

    String noTelephone = "+33761562748"; //$NON-NLS-1$
    String idVmsStw = "789324g32uiedg"; //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, idVmsStw, _method);

    fillRequestHeaders(request, xSource, xProcess, xRequestId, xMessageId, xActionId);

    EasyMock.expect(StreamWideProxy.getInstance()).andReturn(_streamWideProxyMock).once();
    EasyMock.expect(_streamWideProxyMock.isIdVmsStwInConfigTable(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idVmsStw))).andReturn(new ConnectorResponse<>(false, null));

    PowerMock.replayAll();

    String msg = MessageFormat.format(Messages.getString("PI0311.BL001.IdVmsStwConfigAbsent"), idVmsStw); //$NON-NLS-1$
    PI0311_BL001Return retourBl001Expected = new PI0311_BL001Return(RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, msg));

    _processInstance.run(request);

    PowerMock.verify();

    Response response = (Response) request.getResponse();

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    com.bytel.ravel.types.Retour retour = RavelJsonTools.getInstance().fromJson(response.getResult(), com.bytel.ravel.types.Retour.class);
    assertEquals(retourBl001Expected.getRetour().getResultat(), retour.getResultat());
    assertEquals(retourBl001Expected.getRetour().getCategorie(), retour.getCategorie());
    assertEquals(retourBl001Expected.getRetour().getDiagnostic(), retour.getDiagnostic());
    assertEquals(retourBl001Expected.getRetour().getLibelle(), retour.getLibelle());
  }

  /**
   * <b>Scenario:</b> Test nominal export Messages with erreur NO_TELEPHONE_INCONNU.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK
   *
   * @throws Throwable
   */
  @Test
  public void PI0311_Nominal_Test_NOK_01() throws Throwable
  {
    String noTelephone = "+33761562748"; //$NON-NLS-1$
    String idVmsStw = "789324g32uiedg"; //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, idVmsStw, _method);

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    EasyMock.expect(StreamWideProxy.getInstance()).andReturn(_streamWideProxyMock).atLeastOnce();
    EasyMock.expect(_streamWideProxyMock.isIdVmsStwInConfigTable(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idVmsStw))).andReturn(new ConnectorResponse<>(true, null));

    List<Message> messages = new ArrayList<>();
    Message message = __podam.manufacturePojoWithFullData(Message.class);
    messages.add(message);
    String libelle = "la boite de messagerie est inconnue de la PFS"; //$NON-NLS-1$
    prepareVMSSTW_SI101_ExporterMessages(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_INCONNU, libelle), messages, idVmsStw, noTelephone);

    prepareVMSCVM_SI101_ImporterMessage(RetourFactoryForTU.createOkRetour(), message, noTelephone);

    List<Annonce> annonces = new ArrayList<>();
    Annonce annonce = __podam.manufacturePojoWithFullData(Annonce.class);
    annonces.add(annonce);
    prepareVMSSTW_SI102_ExporterAnnonces(RetourFactoryForTU.createOkRetour(), annonces, idVmsStw, noTelephone);

    prepareVMSCVM_SI034_PersonnaliserAnnonceAccueil(RetourFactoryForTU.createOkRetour(), annonce, noTelephone);

    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verify();

    Response response = (Response) request.getResponse();

    PI0311_BL001Return retourBl001Expected = new PI0311_BL001Return(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.BOITE_INCONNUE, libelle));

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    com.bytel.ravel.types.Retour retour = RavelJsonTools.getInstance().fromJson(response.getResult(), com.bytel.ravel.types.Retour.class);
    assertEquals(retourBl001Expected.getRetour().getResultat(), retour.getResultat());
    assertEquals(retourBl001Expected.getRetour().getCategorie(), retour.getCategorie());
    assertEquals(retourBl001Expected.getRetour().getDiagnostic(), retour.getDiagnostic());
    assertEquals(retourBl001Expected.getRetour().getLibelle(), retour.getLibelle());

  }

  /**
   * <b>Scenario:</b> Test nominal export Messages with erreur SERVICE_TIERS_INDISPONIBLE.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK
   *
   * @throws Throwable
   */
  @Test
  public void PI0311_Nominal_Test_NOK_02() throws Throwable
  {
    String noTelephone = "+33761562748"; //$NON-NLS-1$
    String idVmsStw = "789324g32uiedg"; //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, idVmsStw, _method);

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    EasyMock.expect(StreamWideProxy.getInstance()).andReturn(_streamWideProxyMock).atLeastOnce();
    EasyMock.expect(_streamWideProxyMock.isIdVmsStwInConfigTable(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idVmsStw))).andReturn(new ConnectorResponse<>(true, null));

    List<Message> messages = new ArrayList<>();
    Message message = __podam.manufacturePojoWithFullData(Message.class);
    messages.add(message);
    String libelle = "la boite de messagerie est inconnue de la PFS"; //$NON-NLS-1$
    prepareVMSSTW_SI101_ExporterMessages(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.KO_PFS, libelle), messages, idVmsStw, noTelephone);

    prepareVMSCVM_SI101_ImporterMessage(RetourFactoryForTU.createOkRetour(), message, noTelephone);

    List<Annonce> annonces = new ArrayList<>();
    Annonce annonce = __podam.manufacturePojoWithFullData(Annonce.class);
    annonces.add(annonce);
    prepareVMSSTW_SI102_ExporterAnnonces(RetourFactoryForTU.createOkRetour(), annonces, idVmsStw, noTelephone);

    prepareVMSCVM_SI034_PersonnaliserAnnonceAccueil(RetourFactoryForTU.createOkRetour(), annonce, noTelephone);

    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verify();

    Response response = (Response) request.getResponse();

    PI0311_BL001Return retourBl001Expected = new PI0311_BL001Return(RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, libelle));

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    com.bytel.ravel.types.Retour retour = RavelJsonTools.getInstance().fromJson(response.getResult(), com.bytel.ravel.types.Retour.class);
    assertEquals(retourBl001Expected.getRetour().getResultat(), retour.getResultat());
    assertEquals(retourBl001Expected.getRetour().getCategorie(), retour.getCategorie());
    assertEquals(retourBl001Expected.getRetour().getDiagnostic(), retour.getDiagnostic());
    assertEquals(retourBl001Expected.getRetour().getLibelle(), retour.getLibelle());

  }

  /**
   * <b>Scenario:</b> Test nominal export Messages with erreur TRAITEMENT_ARRETE.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK
   *
   * @throws Throwable
   */
  @Test
  public void PI0311_Nominal_Test_NOK_03() throws Throwable
  {
    String noTelephone = "+33761562748"; //$NON-NLS-1$
    String idVmsStw = "789324g32uiedg"; //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, idVmsStw, _method);

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    EasyMock.expect(StreamWideProxy.getInstance()).andReturn(_streamWideProxyMock).atLeastOnce();
    EasyMock.expect(_streamWideProxyMock.isIdVmsStwInConfigTable(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idVmsStw))).andReturn(new ConnectorResponse<>(true, null));

    List<Message> messages = new ArrayList<>();
    Message message = __podam.manufacturePojoWithFullData(Message.class);
    messages.add(message);
    String libelle = "Unexpected Erreur"; //$NON-NLS-1$
    PowerMock.expectNew(VMSSTW_SI101_ExporterMessagesBuilder.class).andThrow(new RavelException(ExceptionType.UNEXPECTED, ErrorCode.KO_00500, libelle));
    prepareVMSCVM_SI101_ImporterMessage(RetourFactoryForTU.createOkRetour(), message, noTelephone);

    List<Annonce> annonces = new ArrayList<>();
    Annonce annonce = __podam.manufacturePojoWithFullData(Annonce.class);
    annonces.add(annonce);
    prepareVMSSTW_SI102_ExporterAnnonces(RetourFactoryForTU.createOkRetour(), annonces, idVmsStw, noTelephone);

    prepareVMSCVM_SI034_PersonnaliserAnnonceAccueil(RetourFactoryForTU.createOkRetour(), annonce, noTelephone);

    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verify();

    Response response = (Response) request.getResponse();

    PI0311_BL001Return retourBl001Expected = new PI0311_BL001Return(RetourFactoryForTU.createNOK(IMegConsts.CAT10, IMegConsts.TRAITEMENT_ARRETE, libelle));

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    com.bytel.ravel.types.Retour retour = RavelJsonTools.getInstance().fromJson(response.getResult(), com.bytel.ravel.types.Retour.class);
    assertEquals(retourBl001Expected.getRetour().getResultat(), retour.getResultat());
    assertEquals(retourBl001Expected.getRetour().getCategorie(), retour.getCategorie());
    assertEquals(retourBl001Expected.getRetour().getDiagnostic(), retour.getDiagnostic());
    assertEquals(retourBl001Expected.getRetour().getLibelle(), retour.getLibelle());

  }

  /**
   * <b>Scenario:</b> Test nominal case.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour OK
   *
   * @throws Throwable
   */
  @Test
  public void PI0311_Nominal_Test_OK_01() throws Throwable
  {
    String noTelephone = "+33761562748"; //$NON-NLS-1$
    String idVmsStw = "789324g32uiedg"; //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, idVmsStw, _method);

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    EasyMock.expect(StreamWideProxy.getInstance()).andReturn(_streamWideProxyMock).atLeastOnce();
    EasyMock.expect(_streamWideProxyMock.isIdVmsStwInConfigTable(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idVmsStw))).andReturn(new ConnectorResponse<>(true, null));

    List<Message> messages = new ArrayList<>();
    Message message = __podam.manufacturePojoWithFullData(Message.class);
    messages.add(message);
    prepareVMSSTW_SI101_ExporterMessages(RetourFactoryForTU.createOkRetour(), messages, idVmsStw, noTelephone);

    prepareVMSCVM_SI101_ImporterMessage(RetourFactoryForTU.createOkRetour(), message, noTelephone);

    List<Annonce> annonces = new ArrayList<>();
    Annonce annonce = __podam.manufacturePojoWithFullData(Annonce.class);
    annonces.add(annonce);
    prepareVMSSTW_SI102_ExporterAnnonces(RetourFactoryForTU.createOkRetour(), annonces, idVmsStw, noTelephone);

    prepareVMSCVM_SI034_PersonnaliserAnnonceAccueil(RetourFactoryForTU.createOkRetour(), annonce, noTelephone);

    byte[] content = "content".getBytes(); //$NON-NLS-1$
    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject())).andReturn(content).anyTimes();

    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verify();

    Response response = (Response) request.getResponse();
    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
  }

  /**
   * <b>Scenario:</b> Test nominal case (No Messages nether Annonces).<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour OK
   *
   * @throws Throwable
   */
  @Test
  public void PI0311_Nominal_Test_OK_02() throws Throwable
  {
    String noTelephone = "+33761562748"; //$NON-NLS-1$
    String idVmsStw = "789324g32uiedg"; //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, idVmsStw, _method);

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    EasyMock.expect(StreamWideProxy.getInstance()).andReturn(_streamWideProxyMock).atLeastOnce();
    EasyMock.expect(_streamWideProxyMock.isIdVmsStwInConfigTable(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(idVmsStw))).andReturn(new ConnectorResponse<>(true, null));

    prepareVMSSTW_SI101_ExporterMessages(RetourFactoryForTU.createOkRetour(), Collections.emptyList(), idVmsStw, noTelephone);

    prepareVMSSTW_SI102_ExporterAnnonces(RetourFactoryForTU.createOkRetour(), Collections.emptyList(), idVmsStw, noTelephone);

    byte[] content = "content".getBytes(); //$NON-NLS-1$
    EasyMock.expect(Files.readAllBytes(EasyMock.anyObject())).andReturn(content).anyTimes();

    PowerMock.replayAll();

    _processInstance.run(request);

    PowerMock.verify();

    Response response = (Response) request.getResponse();
    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PI0311_MigrerMessagerie();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setNomProcessus(DEFAULT_PROCESSNAME);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests

    PowerMock.resetAll();
    PowerMock.mockStaticStrict(StreamWideProxy.class);
    PowerMock.mockStaticStrict(VMSSTW_SI101_ExporterMessages.class);
    PowerMock.mockStaticStrict(VMSSTW_SI101_ExporterMessagesBuilder.class);
    PowerMock.mockStaticStrict(VMSCVM_SI101_ImporterMessage.class);
    PowerMock.mockStaticStrict(VMSCVM_SI101_ImporterMessageBuilder.class);
    PowerMock.mockStaticStrict(VMSSTW_SI102_ExporterAnnonces.class);
    PowerMock.mockStaticStrict(VMSSTW_SI102_ExporterAnnoncesBuilder.class);
    PowerMock.mockStaticStrict(VMSCVM_SI034_PersonnaliserAnnonceAccueil.class);
    PowerMock.mockStaticStrict(VMSCVM_SI034_PersonnaliserAnnonceAccueilBuilder.class);
    PowerMock.mockStaticStrict(Files.class);
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   *
   *
   * @param listeContract_p
   *          listeContract
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p, String listeContract_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("ClientOperateur"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
    hdr.setValue("Authorization : bearer XXXX"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue(listeContract_p);
    requestHeader_p.add(hdr);
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * Create a Generic Request to call PE0221_JournalAppels
   *
   * @param tracabilite_p
   *          tracabilite
   * @param noTelephone_p
   *          Numero noTelephone to add to the urlParameters
   * @param idVmsStw_p
   *          The idVmsStw to add to the urlParameters
   * @param methode_p
   *          The method
   * @return GenericRequest to call PI0311_MigrerMessagerie
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String noTelephone_p, String idVmsStw_p, String methode_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);

    addXHeaders(request.getRequestHeader(), tracabilite_p, "listeContact_p"); //$NON-NLS-1$

    if (noTelephone_p != null)
    {
      request.addMetadata("NO_TELEPHONE", noTelephone_p); //$NON-NLS-1$
    }
    if (idVmsStw_p != null)
    {
      request.addMetadata("ID_VMS_STW", idVmsStw_p); //$NON-NLS-1$
    }

    return request;
  }

  /**
   * @param retour_p
   * @param annonce_p
   * @param idMessageriePfs_p
   * @throws Exception
   */
  private void prepareVMSCVM_SI034_PersonnaliserAnnonceAccueil(Retour retour_p, Annonce annonce_p, String idMessageriePfs_p) throws Exception
  {
    PowerMock.expectNew(VMSCVM_SI034_PersonnaliserAnnonceAccueilBuilder.class).andReturn(_personnaliserAABuilderMock);
    EasyMock.expect(_personnaliserAABuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_personnaliserAABuilderMock);
    EasyMock.expect(_personnaliserAABuilderMock.idMessageriePfs(EasyMock.eq(idMessageriePfs_p))).andReturn(_personnaliserAABuilderMock);
    EasyMock.expect(_personnaliserAABuilderMock.annonce(EasyMock.eq(annonce_p))).andReturn(_personnaliserAABuilderMock);
    EasyMock.expect(_personnaliserAABuilderMock.build()).andReturn(_personnaliserAAMock);
    EasyMock.expect(_personnaliserAAMock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_personnaliserAAMock.getRetour()).andReturn(retour_p);
  }

  /**
   * @param createOkRetour_p
   * @param message_p
   * @param idMessageriePfs_p
   * @throws Exception
   */
  private void prepareVMSCVM_SI101_ImporterMessage(Retour retour_p, Message message_p, String idMessageriePfs_p) throws Exception
  {
    PowerMock.expectNew(VMSCVM_SI101_ImporterMessageBuilder.class).andReturn(_importerMessageBuilderMock);
    EasyMock.expect(_importerMessageBuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_importerMessageBuilderMock);
    EasyMock.expect(_importerMessageBuilderMock.idMessageriePfs(EasyMock.eq(idMessageriePfs_p))).andReturn(_importerMessageBuilderMock);
    EasyMock.expect(_importerMessageBuilderMock.message(EasyMock.eq(message_p))).andReturn(_importerMessageBuilderMock);
    EasyMock.expect(_importerMessageBuilderMock.build()).andReturn(_importerMessageMock);
    EasyMock.expect(_importerMessageMock.execute(_processInstance)).andReturn(String.valueOf(idMessageriePfs_p));
    EasyMock.expect(_importerMessageMock.getRetour()).andReturn(retour_p);
  }

  /**
   * @param retour_p
   * @param messages_p
   * @param idVmsStw_p
   * @param noTelephone_p
   * @throws Exception
   */
  private void prepareVMSSTW_SI101_ExporterMessages(Retour retour_p, List<Message> messages_p, String idVmsStw_p, String noTelephone_p) throws Exception
  {
    PowerMock.expectNew(VMSSTW_SI101_ExporterMessagesBuilder.class).andReturn(_exporterMessagesBuilderMock);
    EasyMock.expect(_exporterMessagesBuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_exporterMessagesBuilderMock);
    EasyMock.expect(_exporterMessagesBuilderMock.tempFolder(EasyMock.eq(TEMP_FOLFER))).andReturn(_exporterMessagesBuilderMock);
    EasyMock.expect(_exporterMessagesBuilderMock.idVmsStw(EasyMock.eq(idVmsStw_p))).andReturn(_exporterMessagesBuilderMock);
    EasyMock.expect(_exporterMessagesBuilderMock.noTelephone(EasyMock.eq(noTelephone_p))).andReturn(_exporterMessagesBuilderMock);
    EasyMock.expect(_exporterMessagesBuilderMock.build()).andReturn(_exporterMessagesMock);
    EasyMock.expect(_exporterMessagesMock.execute(_processInstance)).andReturn(messages_p);
    EasyMock.expect(_exporterMessagesMock.getRetour()).andReturn(retour_p);
  }

  /**
   * @param retour_p
   * @param annonces_p
   * @param idVmsStw_p
   * @param noTelephone_p
   * @throws Exception
   */
  private void prepareVMSSTW_SI102_ExporterAnnonces(Retour retour_p, List<Annonce> annonces_p, String idVmsStw_p, String noTelephone_p) throws Exception
  {
    PowerMock.expectNew(VMSSTW_SI102_ExporterAnnoncesBuilder.class).andReturn(_exporterAnnoncesBuilderMock);
    EasyMock.expect(_exporterAnnoncesBuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_exporterAnnoncesBuilderMock);
    EasyMock.expect(_exporterAnnoncesBuilderMock.tempFolder(EasyMock.eq(TEMP_FOLFER))).andReturn(_exporterAnnoncesBuilderMock);
    EasyMock.expect(_exporterAnnoncesBuilderMock.idVmsStw(EasyMock.eq(idVmsStw_p))).andReturn(_exporterAnnoncesBuilderMock);
    EasyMock.expect(_exporterAnnoncesBuilderMock.noTelephone(EasyMock.eq(noTelephone_p))).andReturn(_exporterAnnoncesBuilderMock);
    EasyMock.expect(_exporterAnnoncesBuilderMock.build()).andReturn(_exporterAnnoncesMock);
    EasyMock.expect(_exporterAnnoncesMock.execute(_processInstance)).andReturn(annonces_p);
    EasyMock.expect(_exporterAnnoncesMock.getRetour()).andReturn(retour_p);
  }
}
