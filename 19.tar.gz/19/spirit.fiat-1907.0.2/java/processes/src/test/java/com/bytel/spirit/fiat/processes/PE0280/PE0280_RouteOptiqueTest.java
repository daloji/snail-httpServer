/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0280;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.oi.OI_SI005_MAJRouteOptique;
import com.bytel.spirit.common.activities.oi.OI_SI005_MAJRouteOptique.OI_SI005_MAJRouteOptiqueBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptiqueResponse;
import com.bytel.spirit.common.connector.oi.emutation.structs.MAJRouteOptiqueResponse.MAJRouteOptiqueResponseBuilder;
import com.bytel.spirit.common.connector.oi.emutation.structs.PositionPM;
import com.bytel.spirit.common.connector.oi.emutation.structs.RouteOptique;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_Fibre;
import com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_PositionPM;
import com.bytel.spirit.fiat.processes.PE0280.structs.PE0280_BL001_VerifierDonneesRouteOptiqueRetour;
import com.bytel.spirit.fiat.processes.PE0280.structs.PE0280_Request;
import com.bytel.spirit.fiat.processes.PE0280.structs.PE0280_Retour;
import com.bytel.spirit.fiat.shared.types.json.ComplementAdresse;
import com.bytel.spirit.fiat.shared.types.json.CoordonneesGeo;
import com.bytel.spirit.fiat.shared.types.json.HexacleVoie;
import com.bytel.spirit.fiat.shared.types.json.QuadrupletRivoli;
import com.bytel.spirit.fiat.shared.types.json.ReferencesAdresse;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author bferreir
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0280_RouteOptique.class, ProcessManager.class, OI_SI005_MAJRouteOptiqueBuilder.class, OI_SI005_MAJRouteOptique.class })
public class PE0280_RouteOptiqueTest
{
  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  /**
   *
   */
  private static final String PE0280_BL001_VerifierDonneesRouteOptique = "PE0280_BL001_VerifierDonneesRouteOptique"; //$NON-NLS-1$

  /**
   *
   */
  private static final String OI = "OI"; //$NON-NLS-1$

  /**
   * PE0280_BL001_VerifierDonneesRouteOptique
   *
   */
  private static final String REFPRESTATIONPRISE = "refPrestationPrise"; //$NON-NLS-1$

  /**
   * Podam instance
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  static
  {
    __podam = new PodamFactoryImpl();
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void beforeClassSetup() throws RavelException
  {
    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Run before tests
   *
   * @throws Exception
   *           throw exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   *
   */

  @MockStrict
  private OI_SI005_MAJRouteOptiqueBuilder _si005BuilderMock;
  /**
  *
  */
  @MockStrict
  private OI_SI005_MAJRouteOptique _si005Mock;

  /**
  *
  */
  @MockStrict
  private ProcessManager _pmMock;

  /**
   * PE0279_RessourceEmutation
   */
  private PE0280_RouteOptique _processInstance;

  /**
   *
   */
  private Tracabilite _tracabilite;

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           On error
   */
  @Before
  public void init() throws RavelException
  {
    //  context initialization
    _processInstance = new PE0280_RouteOptique();
    _processInstance.initializeContext();

    PowerMock.resetAll();
    PowerMock.mockStatic(ProcessManager.class);
    PowerMock.mockStatic(OI_SI005_MAJRouteOptiqueBuilder.class);
    PowerMock.mockStatic(OI_SI005_MAJRouteOptique.class);

  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0280_BL001_KO_VerifierHeader_001() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    fillRequestHeaders(request, xSource);

    Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0280_BL001_VerifierDonneesRouteOptique, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals("Header X-Process null ou vide.", bl001Retour._second.getLibelle()); //$NON-NLS-1$

  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0280_BL001_KO_VerifierHeader_002() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$

    fillRequestHeaders(request, xSource, xProcess);

    Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0280_BL001_VerifierDonneesRouteOptique, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals("Header X-Request-Id null ou vide.", bl001Retour._second.getLibelle()); //$NON-NLS-1$
  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0280_BL001_KO_VerifierHeader_003() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, null);
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xSource, xProcess, xRequestId);

    Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0280_BL001_VerifierDonneesRouteOptique, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals("Header X-Source null ou vide.", bl001Retour._second.getLibelle()); //$NON-NLS-1$
  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0280_BL001_KO_VerifierHeader_004() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, null);
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xSource, xProcess, xRequestId);

    Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0280_BL001_VerifierDonneesRouteOptique, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals("Header X-Process null ou vide.", bl001Retour._second.getLibelle()); //$NON-NLS-1$
  }

  /**
   * Non respect de la STI
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0280_BL001_KO_VerifierHeader_005() throws Exception
  {
    Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHM_EMUTATION");//$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, null);

    fillRequestHeaders(request, xSource, xProcess, xRequestId);

    Pair<PE0280_BL001_VerifierDonneesRouteOptiqueRetour, Retour> bl001Retour = Whitebox.invokeMethod(_processInstance, PE0280_BL001_VerifierDonneesRouteOptique, tracabilite, request);
    assertEquals(StringConstants.NOK, bl001Retour._second.getResultat());
    assertEquals(IMegConsts.CAT3, bl001Retour._second.getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, bl001Retour._second.getDiagnostic());
    assertEquals("Header X-Request-Id null ou vide.", bl001Retour._second.getLibelle()); //$NON-NLS-1$
  }

  /**
   * Test Nominal. return KO JASON pour CodeHexacleVoie <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_CodeHexacleVoie_016() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.getReferencesAdresse().getHexacleVoie().setCodeHexacleVoie(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) obligatoire(s) manquant(s): [_referencesAdresse._hexacleVoie._codeHexacleVoie]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JASON pour CodeInsee <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_CodeInsee_013() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.getReferencesAdresse().getRivoli().setCodeInsee(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) obligatoire(s) manquant(s): [_referencesAdresse._rivoli._codeInsee]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());

  }

  /**
   * Test Nominal. return KO JASON pour CodeRivoli <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_CodeRivoli_014() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.getReferencesAdresse().getRivoli().setCodeRivoli(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) obligatoire(s) manquant(s): [_referencesAdresse._rivoli._codeRivoli]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());

  }

  /**
   * Test Nominal. return KO JASON pour coordonneesX <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_CoordonneesX_019() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.getReferencesAdresse().getReferenceGeo().setCoordonneesX(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) obligatoire(s) manquant(s): [_referencesAdresse._referenceGeo._coordonneesX]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JASON pour coordonneesY<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_CoordonneesY_020() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.getReferencesAdresse().getReferenceGeo().setCoordonneesY(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) obligatoire(s) manquant(s): [_referencesAdresse._referenceGeo._coordonneesY]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return OK with no empty list<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_EXCEPTION_005() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$

    request.setPayload("12345"); //$NON-NLS-1$
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.KO_00400, response.getErrorCode());

  }

  /**
   * Test Nominal. return KO JASON pour IdentifiantFibre <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_IdentifiantFibre_006() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setIdentifiantFibre(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) obligatoire(s) manquant(s): [_identifiantFibre]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());

  }

  /**
   * Test Nominal. return KO JSON _motifMutation = null <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_MotifMutation_007() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) obligatoire(s) manquant(s): [_motifMutation]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());

  }

  /**
   * Test Nominal. return KO JSON for invalid _motifMutation <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_MotifMutation_008() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("INVALIDE MOTIF"); //$NON-NLS-1$

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Format d\u0027attribut(s) non respecté(s): [_motifMutation]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());

  }

  /**
   * Test Nominal. return KO JASON pour NumeroVoie dedans QuadrupletRivoli<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_NumeroVoie_015() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.getReferencesAdresse().getRivoli().setNumeroVoie(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) obligatoire(s) manquant(s): [_referencesAdresse._rivoli._numeroVoie]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());

  }

  /**
   * Test Nominal. return KO JASON pour NumeroVoie dedans HexacleVoie <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_NumeroVoie_017() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.getReferencesAdresse().getHexacleVoie().setNumeroVoie(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) obligatoire(s) manquant(s): [_referencesAdresse._hexacleVoie._numeroVoie]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JASON pour typeProjection <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_JSON_TypeProjection_018() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.getReferencesAdresse().getReferenceGeo().setTypeProjection(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) obligatoire(s) manquant(s): [_referencesAdresse._referenceGeo._typeProjection]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JSON for _referencesAdresse = null and _motifMutation = "Adresse client erron\u00e9e" <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_MotifMutation_ADRESSE_CLIENT_ERRONÉE_01() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("Adresse client erron\u00e9e"); //$NON-NLS-1$
    pe0280Request.setReferencesAdresse(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_referencesAdresse]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JSON for _complementAdresseCmd = null and _motifMutation = "Adresse client erron\u00e9e"
   * <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_MotifMutation_ADRESSE_CLIENT_ERRONÉE_02() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("Adresse client erron\u00e9e"); //$NON-NLS-1$
    pe0280Request.setComplementAdresseCmd(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_complementAdresseCmd]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JSON for _complementAdresseCmd = null and _motifMutation = "B\u00e2timent client
   * erron\u00e9" <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_MotifMutation_BÂTIMENT_CLIENT_ERRONÉ_01() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("B\u00e2timent client erron\u00e9"); //$NON-NLS-1$
    pe0280Request.setComplementAdresseCmd(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_complementAdresseCmd]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JSON for _complementAdresseCmd = null and _motifMutation = "Escalier client erron\u00e9"
   * <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_MotifMutation_ESCALIER_CLIENT_ERRONÉ_01() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("Escalier client erron\u00e9"); //$NON-NLS-1$
    pe0280Request.setComplementAdresseCmd(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_complementAdresseCmd]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JSON for _complementAdresseCmd = null and _motifMutation = "Etage client erron\u00e9" <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_MotifMutation_ETAGE_CLIENT_ERRONÉ_01() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("Etage client erron\u00e9"); //$NON-NLS-1$
    pe0280Request.setComplementAdresseCmd(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();
    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_complementAdresseCmd]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO Activity <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_OI_SI005_MAJRouteOptiqueBuilder_008() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    //Mock Activity
    PowerMock.expectNew(OI_SI005_MAJRouteOptiqueBuilder.class).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.codeOi(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.complementAdresseCmd(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.complementAdresseTerrain(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.identifiantFibre(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.motifMutation(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.porte(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.referencePrise(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.referencesAdresse(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si005BuilderMock);

    //Build Activity
    EasyMock.expect(_si005BuilderMock.build()).andReturn(_si005Mock);

    //Execute
    EasyMock.expect(_si005Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_si005Mock.getRetour()).andReturn(RetourFactoryForTU.createKO(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, "Error", "OI_SI005_MAJRouteOptique")); //$NON-NLS-1$ //$NON-NLS-2$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();

    //Expected
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    reponseErreurExpected.setErrorDescription("Error"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());

  }

  /**
   * Test Nominal. return KO JASON pour IdentifiantFibre <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_OI_SI005_MAJRouteOptiqueBuilder_Exceptiuon_009() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    //Mock Activity
    PowerMock.expectNew(OI_SI005_MAJRouteOptiqueBuilder.class).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.codeOi(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.complementAdresseCmd(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.complementAdresseTerrain(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.identifiantFibre(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.motifMutation(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.porte(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.referencePrise(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.referencesAdresse(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si005BuilderMock);

    //Build Activity
    EasyMock.expect(_si005BuilderMock.build()).andReturn(_si005Mock);

    //Execute
    EasyMock.expect(_si005Mock.execute(_processInstance)).andThrow(new RavelException(ExceptionType.UNEXPECTED, ErrorCode.KO_00500, "Error")); //$NON-NLS-1$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Obtenu
    IRavelResponse response = request.getResponse();

    //Expected
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    reponseErreurExpected.setErrorDescription("Error"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());

  }

  /**
   * Test Nominal. return KO JSON for _referencePrise = null and _motifMutation = "Adresse client erron\u00e9e" <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_ReferencePrise_ADRESSE_CLIENT_ERRONÉE_01() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("Adresse client erron\u00e9e"); //$NON-NLS-1$
    pe0280Request.setReferencePrise(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_referencePrise]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JSON for _referencePrise = null and _motifMutation = "B\u00e2timent client erron\u00e9"
   * <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_ReferencePrise_BÂTIMENT_CLIENT_ERRONÉ_01() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("B\u00e2timent client erron\u00e9"); //$NON-NLS-1$
    pe0280Request.setReferencePrise(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_referencePrise]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JSON for _referencePrise = null and _motifMutation = "Commande HOTLINE" <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_ReferencePrise_COMMANDE_HOTLINE_01() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("Commande HOTLINE"); //$NON-NLS-1$
    pe0280Request.setReferencePrise(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_referencePrise]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JSON for _referencePrise = null and _motifMutation = "Escalier client erron\u00e9" <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_ReferencePrise_ESCALIER_CLIENT_ERRONÉ_01() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("Escalier client erron\u00e9"); //$NON-NLS-1$
    pe0280Request.setReferencePrise(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_referencePrise]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JSON for _referencePrise = null and _motifMutation = "Etage client erron\u00e9" <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_ReferencePrise_ETAGE_CLIENT_ERRONÉ_01() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("Etage client erron\u00e9"); //$NON-NLS-1$
    pe0280Request.setReferencePrise(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_referencePrise]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return KO JSON for _referencePrise = null and _motifMutation = "PTO \u00e0 construire alors que PTO
   * existante dans la commande OC" <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_ReferencePrise_PTO_À_CONSTRUIRE_ALORS_QUE_PTO_EXISTANTE_DANS_LA_COMMANDE_OC_01() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    //Provoke Error
    pe0280Request.setMotifMutation("PTO \u00e0 construire alors que PTO existante dans la commande OC"); //$NON-NLS-1$
    pe0280Request.setReferencePrise(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription("Attribut(s) conditionnel(s) manquant(s): [_referencePrise]"); //$NON-NLS-1$

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * Test Nominal. return OK with no empty list<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_URLParameter_OI_010() throws Throwable
  {

    //Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, null);
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
  }

  /**
   * Test Nominal. return OK with no empty list<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_KO_URLParameter_OI_012() throws Throwable
  {

    //Tracabilite tracabilite = __podam.manufacturePojo(Tracabilite.class);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, null);
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    request.setUrlParameters(urlParametersType);

    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    IRavelResponse response = request.getResponse();
    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
  }

  /**
   * Test Nominal. return KO JASON pour IdentifiantFibre <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_OK_011() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    //Mock Activity
    PowerMock.expectNew(OI_SI005_MAJRouteOptiqueBuilder.class).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.codeOi(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.complementAdresseCmd(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.complementAdresseTerrain(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.identifiantFibre(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.motifMutation(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.porte(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.referencePrise(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.referencesAdresse(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si005BuilderMock);

    //Build Activity
    EasyMock.expect(_si005BuilderMock.build()).andReturn(_si005Mock);

    PositionPM positionPM = new PositionPM("ModulePM", "PositionModulePM", "referenceCableModule", "infoTubeModulePM", "infoFibleModulePM"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    RouteOptique routeOptique = new RouteOptique("OC", positionPM, "XXX", "YYY", "ZZZZ", 33, "Vert"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    ArrayList<RouteOptique> listOI = new ArrayList<RouteOptique>();
    listOI.add(routeOptique);
    MAJRouteOptiqueResponse majRouteOptiqueResponse = new MAJRouteOptiqueResponseBuilder()//
        .numeroDecharge("86435UI098")// //$NON-NLS-1$
        .referencePrise("FI-0026-6752")// //$NON-NLS-1$
        .referencePM("SHL-42163-LPAA")// //$NON-NLS-1$
        .referencePMT("PMT-42163-LPAA")// //$NON-NLS-1$
        .referencePBO("PBO1244") //$NON-NLS-1$
        .routesOptiques(listOI) //
        .build();

    //Execute
    EasyMock.expect(_si005Mock.execute(_processInstance)).andReturn(majRouteOptiqueResponse);
    EasyMock.expect(_si005Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Obtenu
    IRavelResponse response = request.getResponse();

    //Expected
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    PE0280_Retour pe0280Retour = new PE0280_Retour();

    ArrayList<com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_StiRouteOptique> listRouteOptiqueProfType = new ArrayList<com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_StiRouteOptique>();

    PE0280_PositionPM positionPMProfType = new PE0280_PositionPM("ModulePM", "PositionModulePM", "referenceCableModule", "infoTubeModulePM", "infoFibleModulePM"); //$NON-NLS-1$ //$NON-NLS-2$
    PE0280_Fibre fibre = new PE0280_Fibre(StringConstants.EMPTY_STRING, routeOptique.getReferenceCablePBO(), routeOptique.getInformationTubePBO(), routeOptique.getInformationFibrePBO(), StringConstants.EMPTY_STRING, "FI-0026-6752");

    com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_StiRouteOptique routeOptiqueProfTypes = new com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_StiRouteOptique("OC", positionPMProfType, fibre, 33, "Vert"); //$NON-NLS-1$ //$NON-NLS-2$

    listRouteOptiqueProfType.add(routeOptiqueProfTypes);

    pe0280Retour.setNumeroDecharge("86435UI098"); //$NON-NLS-1$
    pe0280Retour.setRoutesOptiques(listRouteOptiqueProfType);
    pe0280Retour.setReferencePM("SHL-42163-LPAA"); //$NON-NLS-1$
    pe0280Retour.setReferencePMT("PMT-42163-LPAA"); //$NON-NLS-1$
    pe0280Retour.setReferencePBO("PBO1244"); //$NON-NLS-1$
    pe0280Retour.setRoutesOptiques(listRouteOptiqueProfType);

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0280Retour));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());

  }

  /**
   * Test Nominal. return OK for referencesAdress = null and motifMutation = "Escalier client erroné" <br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0280_Nominal_OK_012() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "IHN_EMUTATION"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "LISTAGE_FIBRES"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> list = new ArrayList<>();
    Parameter oi = new Parameter(OI, "FTEL"); //$NON-NLS-1$
    list.add(oi);
    Parameter listEtat = new Parameter(REFPRESTATIONPRISE, "refPP1234");//$NON-NLS-1$
    list.add(listEtat);
    urlParametersType.setUrlParameters(list);

    //Fill JSON
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    PE0280_Request pe0280Request = buildValidPE0280Request();
    pe0280Request.setReferencesAdresse(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0280Request, PE0280_Request.class);

    request.setPayload(jSonRequest);
    request.setUrlParameters(urlParametersType);

    //Mock Activity
    PowerMock.expectNew(OI_SI005_MAJRouteOptiqueBuilder.class).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.codeOi(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.complementAdresseCmd(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.complementAdresseTerrain(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.identifiantFibre(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.motifMutation(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.porte(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.referencePrise(EasyMock.anyString())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.referencesAdresse(EasyMock.anyObject())).andReturn(_si005BuilderMock);
    EasyMock.expect(_si005BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si005BuilderMock);

    //Build Activity
    EasyMock.expect(_si005BuilderMock.build()).andReturn(_si005Mock);

    PositionPM positionPM = new PositionPM("ModulePM", "PositionModulePM", "referenceCableModule", "infoTubeModulePM", "infoFibleModulePM"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    RouteOptique routeOptique = new RouteOptique("OC", positionPM, "XXX", "YYY", "ZZZZ", 33, "Vert"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    ArrayList<RouteOptique> listOI = new ArrayList<RouteOptique>();
    listOI.add(routeOptique);
    MAJRouteOptiqueResponse majRouteOptiqueResponse = new MAJRouteOptiqueResponseBuilder()//
        .numeroDecharge("86435UI098")// //$NON-NLS-1$
        .referencePrise("FI-0026-6752")// //$NON-NLS-1$
        .referencePM("SHL-42163-LPAA")// //$NON-NLS-1$
        .referencePMT("PMT-42163-LPAA")// //$NON-NLS-1$
        .referencePBO("PBO1244") //$NON-NLS-1$
        .routesOptiques(listOI) //
        .build();

    //Execute
    EasyMock.expect(_si005Mock.execute(_processInstance)).andReturn(majRouteOptiqueResponse);
    EasyMock.expect(_si005Mock.getRetour()).andReturn(RetourFactoryForTU.createOkRetour());

    createProcessManagerManagerMock();
    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    //Obtenu
    IRavelResponse response = request.getResponse();

    //Expected
    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();

    PE0280_Retour pe0280Retour = new PE0280_Retour();

    ArrayList<com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_StiRouteOptique> listRouteOptiqueProfType = new ArrayList<com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_StiRouteOptique>();

    PE0280_PositionPM positionPMProfType = new PE0280_PositionPM("ModulePM", "PositionModulePM", "referenceCableModule", "infoTubeModulePM", "infoFibleModulePM"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$
    PE0280_Fibre fibre = new PE0280_Fibre(StringConstants.EMPTY_STRING, routeOptique.getReferenceCablePBO(), routeOptique.getInformationTubePBO(), routeOptique.getInformationFibrePBO(), StringConstants.EMPTY_STRING, "FI-0026-6752");

    com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_StiRouteOptique routeOptiqueProfTypes = new com.bytel.spirit.fiat.processes.PE0280.sti.PE0280_StiRouteOptique("OC", positionPMProfType, fibre, 33, "Vert"); //$NON-NLS-1$ //$NON-NLS-2$

    listRouteOptiqueProfType.add(routeOptiqueProfTypes);

    pe0280Retour.setNumeroDecharge("86435UI098"); //$NON-NLS-1$
    pe0280Retour.setRoutesOptiques(listRouteOptiqueProfType);
    pe0280Retour.setReferencePM("SHL-42163-LPAA"); //$NON-NLS-1$
    pe0280Retour.setReferencePMT("PMT-42163-LPAA"); //$NON-NLS-1$
    pe0280Retour.setReferencePBO("PBO1244"); //$NON-NLS-1$
    pe0280Retour.setRoutesOptiques(listRouteOptiqueProfType);

    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(pe0280Retour));

    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());

  }

  /**
   * Builds a valid {@link PE0280 request} object
   *
   * @return {@link E0280 request}
   */
  @SuppressWarnings("javadoc")
  private PE0280_Request buildValidPE0280Request()
  {
    PE0280_Request pe0280Request = new PE0280_Request();

    pe0280Request.setReferencePrise("FI-0026-6752"); //$NON-NLS-1$
    pe0280Request.setIdentifiantFibre("Fibre 143865"); //$NON-NLS-1$
    pe0280Request.setMotifMutation("Escalier client erroné"); //$NON-NLS-1$

    ReferencesAdresse referencesAdresse = new ReferencesAdresse();

    QuadrupletRivoli rivoli = new QuadrupletRivoli();
    rivoli.setCodeInsee("12345"); //$NON-NLS-1$
    rivoli.setCodeRivoli("1234"); //$NON-NLS-1$
    rivoli.setNumeroVoie(1);

    HexacleVoie hexacleVoie = new HexacleVoie();
    hexacleVoie.setCodeHexacleVoie("1234567890"); //$NON-NLS-1$
    hexacleVoie.setNumeroVoie(1);

    CoordonneesGeo referenceGeographique = new CoordonneesGeo();
    referenceGeographique.setTypeProjection("1234567890"); //$NON-NLS-1$
    referenceGeographique.setCoordonneesX("324234"); //$NON-NLS-1$
    referenceGeographique.setCoordonneesY("353535"); //$NON-NLS-1$

    referencesAdresse.setHexacle("3155722NG3"); //$NON-NLS-1$
    referencesAdresse.setRivoli(rivoli);
    referencesAdresse.setHexacleVoie(hexacleVoie);
    referencesAdresse.setReferenceGeo(referenceGeographique);
    referencesAdresse.setIdentifiantImeuble("ABC"); //$NON-NLS-1$
    referencesAdresse.setAdresseLibre("Rue XXX"); //$NON-NLS-1$

    ComplementAdresse complementeAdressCmd = new ComplementAdresse();
    complementeAdressCmd.setBatiment("A"); //$NON-NLS-1$
    complementeAdressCmd.setEscalier("1"); //$NON-NLS-1$
    complementeAdressCmd.setEtage("3"); //$NON-NLS-1$

    ComplementAdresse complementeAdressTerrain = new ComplementAdresse();
    complementeAdressTerrain.setBatiment("A"); //$NON-NLS-1$
    complementeAdressTerrain.setEscalier("1"); //$NON-NLS-1$
    complementeAdressTerrain.setEtage("3"); //$NON-NLS-1$

    pe0280Request.setReferencesAdresse(referencesAdresse);
    pe0280Request.setComplementAdresseCmd(complementeAdressCmd);
    pe0280Request.setComplementAdresseTerrain(complementeAdressTerrain);

    return pe0280Request;
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Create ProcessManager mock
   */
  private void createProcessManagerManagerMock()
  {
    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<String, Map<String, String>>();
    processParams.put("", new HashMap<String, String>()); //$NON-NLS-1$
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_pmMock).anyTimes();
    EasyMock.expect(_pmMock.getProcessParams()).andReturn(processParams).anyTimes();

  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }
}
