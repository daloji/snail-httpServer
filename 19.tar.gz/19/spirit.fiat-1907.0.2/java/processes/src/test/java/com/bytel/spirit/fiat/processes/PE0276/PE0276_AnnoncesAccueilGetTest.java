/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0276;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomUtils;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI015_TelechargerAnnonceAccueil;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI015_TelechargerAnnonceAccueil.VMSCVM_SI015_TelechargerAnnonceAccueilBuilder;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI031_TelechargerAnnonceAccueil;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI031_TelechargerAnnonceAccueil.VMSSTW_SI031_TelechargerAnnonceAccueilBuilder;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelleParameterizedType;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.ink.generated.Dataset;
import com.bytel.spirit.common.connectors.ink.generated.DatasetParam;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderDataResponse;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderResponse;
import com.bytel.spirit.common.shared.functional.types.json.AnnonceAccueilPfs;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.PE0276.structs.AnnoncesAccueil;
import com.bytel.spirit.fiat.processes.PE0276.structs.PE0276_BL100Reponse;
import com.bytel.spirit.fiat.processes.structs.XAction;
import com.bytel.spirit.fiat.processes.structs.XLink;
import com.google.gson.Gson;

import io.netty.util.internal.StringUtil;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author pescudei
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0276_AnnoncesAccueils.class, ProcessManager.class, PROV_SI002_ExecuterProcessusBuilder.class, PROV_SI002_ExecuterProcessus.class, VMSCVM_SI015_TelechargerAnnonceAccueilBuilder.class, VMSCVM_SI015_TelechargerAnnonceAccueil.class, VMSSTW_SI031_TelechargerAnnonceAccueilBuilder.class, VMSSTW_SI031_TelechargerAnnonceAccueil.class })
public class PE0276_AnnoncesAccueilGetTest
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * LISTER_OPERATION
   */
  private static final String LISTER_OPERATION = "PE0276_AnnoncesAccueilsLister"; //$NON-NLS-1$

  /**
   * Configuration path Param
   */
  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   * The X_REQUEST_ID_VALUE
   */
  private static final String X_REQUEST_ID_VALUE = "125667889000877"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0276_AnnoncesAccueils"; //$NON-NLS-1$

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    Parameter parameter = new Parameter();

    parameter.setName(name_p);
    parameter.setValue(value_p);

    return parameter;
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    try
    {
      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager is now initialized")); //$NON-NLS-1$
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager instance is already initialized")); //$NON-NLS-1$
    }

  }

  /**
   * Instance of {@link PE0276_AnnoncesAccueils}
   */
  private PE0276_AnnoncesAccueils _processInstance;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  ProcessManager _processManager;

  /**
   * PROV_SI002_ExecuterProcessusBuilder
   */
  @MockStrict
  PROV_SI002_ExecuterProcessusBuilder _si002_mockbuilder;

  /**
   * PROV_SI002_ExecuterProcessus
   */
  @MockStrict
  PROV_SI002_ExecuterProcessus _si002_mock;

  /**
   * VMSSTW_SI031_TelechargerAnnonceAccueilBuilder
   */
  @MockStrict
  VMSSTW_SI031_TelechargerAnnonceAccueilBuilder _si031BuilderMock;

  /**
   * VMSSTW_SI031_TelechargerAnnonceAccueil
   */
  @MockStrict
  VMSSTW_SI031_TelechargerAnnonceAccueil _si031Builder;

  /**
   * VMSCVM_SI015_TelechargerAnnonceAccueilBuilder
   */
  @MockStrict
  VMSCVM_SI015_TelechargerAnnonceAccueilBuilder _si015BuilderMock;

  /**
   * VMSCVM_SI015_TelechargerAnnonceAccueil
   */
  @MockStrict
  VMSCVM_SI015_TelechargerAnnonceAccueil _si015Mock;

  /**
   * Missing config files
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_AnnoncesAccueils_BL001_VerifierDonneesConsultation_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(null, null);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(3);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).times(3);

    PowerMock.replayAll();

    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegConsts.CONFIGURATION_INVALIDE);
    responseErreeurExpected.setErrorDescription(""); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
  }

  /**
   * Case Lister Annonce, missing idMessagerie
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_AnnoncesAccueils_BL001_VerifierDonneesConsultation_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();

    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter idMessagerie is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Case telecharger, missing idAnnonce
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_AnnoncesAccueils_BL001_VerifierDonneesConsultation_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();
    PowerMock.replayAll();

    Response response = executeStartProcess(request, "telecharger"); //$NON-NLS-1$
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter idAnnonce is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0276_BL100_ListerAnnonce error decryptage
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_ListerAnnonce_BL100_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, "T1Ivr8FTvyIJfosxu4gRwzYMZKt+pWECPm945m+WgrQgsoOMyJ3uHw=", null); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ID_MESSAGERIE_INCONNU);
    responseErreeurExpected.setErrorDescription("L id Messagerie T1Ivr8FTvyIJfosxu4gRwzYMZKt+pWECPm945m+WgrQgsoOMyJ3uHw= est inconnu."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0276_BL100_ListerAnnonce operation not autorised for message type
   *
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_ListerAnnonce_BL100_KO_002() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#+33123456789#typeMessagerie#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, null);

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Operation non Autorisee sur la messagerie " + encryptedUrlParameter + "."); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0276_BL100_ListerAnnonce acess refused
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_ListerAnnonce_BL100_KO_003() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#+33123456789#VOIX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreeurExpected.setErrorDescription("Acces refuse"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0276_BL100_ListerAnnonce error calling KPSA CAT1
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_ListerAnnonce_BL100_KO_004() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#+33123456789#VOIX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.DONNEE_INCONNUE, "libelle"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    prepareProv_SI002(ko, null);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0276_BL100_ListerAnnonce error calling KPSA CAT2
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_ListerAnnonce_BL100_KO_005() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#+33123456789#VOIX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.DONNEE_INCONNUE, "libelle"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    prepareProv_SI002(ko, null);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0276_BL100_ListerAnnonce error calling KPSA not CAT1/CAT2
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_ListerAnnonce_BL100_KO_006() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#+33123456789#VOIX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "libelle"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    prepareProv_SI002(ko, null);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegConsts.DONNEE_INCONNUE);
    responseErreeurExpected.setErrorDescription("libelle"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Nominal for ListerAnnonce
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_ListerAnnonce_Nominal() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#+33123456789#VOIX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    ResponseConnector reponseConnector = createResponseConnector();
    prepareProv_SI002(RetourFactory.createOkRetour(), reponseConnector);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String reponseJson = response.getGenericResponse().getResult();
    PE0276_BL100Reponse bl100Response = RavelJsonTools.getInstance().fromJson(reponseJson, PE0276_BL100Reponse.class);

    //Validate response object
    Assert.assertNotNull(bl100Response);
    Assert.assertEquals(new Integer(1), bl100Response.getResultsCount());

    //Validate self link
    Assert.assertNotNull(bl100Response.getLinks());
    Assert.assertNotNull(bl100Response.getLinks().get(XLink.SELF));
    Assert.assertEquals("/annonces-accueil/" + encryptedUrlParameter + "/annonces-accueil?format=metadata", bl100Response.getLinks().get(XLink.SELF).getHref()); //$NON-NLS-1$ //$NON-NLS-2$

    //Validate Items List
    Assert.assertNotNull(bl100Response.getItems());
    Assert.assertEquals(1, bl100Response.getItems().size());

    //Validate item
    AnnoncesAccueil item = bl100Response.getItems().get(0);
    Assert.assertNotNull(item);
    Assert.assertEquals("mVlAe2zymjk0Dl11CQ2fqZJSXRQxP2u5rDFViSN606wML5TOWO1B2LI09b1HHGFc", item.getIdAnnonce()); //$NON-NLS-1$
    Assert.assertEquals(encryptedUrlParameter, item.getIdMessagerie());
    Assert.assertEquals("typeAnnonce_p", item.getTypeAnnonce()); //$NON-NLS-1$
    Assert.assertEquals("statutAnnonce_p", item.getStatutAnnonce()); //$NON-NLS-1$

    //Validate item link
    Assert.assertNotNull(item.getLinks());
    Assert.assertNotNull(item.getLinks().get("telechargerAnnonceAccueil"));
    Assert.assertEquals("/annonces-accueil/mVlAe2zymjk0Dl11CQ2fqZJSXRQxP2u5rDFViSN606wML5TOWO1B2LI09b1HHGFc/contenu", item.getLinks().get("telechargerAnnonceAccueil").getHref()); //$NON-NLS-1$

    //Validate item action
    Assert.assertNotNull(item.getActions());
    XAction modifierAnnonceAccueil = item.getActions().get("modifierAnnonceAccueil");
    Assert.assertNotNull(modifierAnnonceAccueil);
    Assert.assertEquals(MediaType.MULTIPART_FORM_DATA, modifierAnnonceAccueil.getType());
    Assert.assertEquals(HttpConstants.PUT_METHOD, modifierAnnonceAccueil.getMethod());
    Assert.assertEquals("/annonces-accueil/mVlAe2zymjk0Dl11CQ2fqZJSXRQxP2u5rDFViSN606wML5TOWO1B2LI09b1HHGFc", modifierAnnonceAccueil.getAction()); //$NON-NLS-1$
  }

  /**
   * PE0276_BL200_TelechargerAnnonce error decryptage
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_TelechargerAnnonce_BL200_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, "RhyesyKnRJrjjYgdCUD9+HsGWAF6ZkJGWZmdfyOgvuqpVe5uuFN55hjbdD+pB1w", null); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, "telecharer"); //$NON-NLS-1$
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ID_ANNONCE_INCONNU);
    responseErreeurExpected.setErrorDescription("L'id Annonce RhyesyKnRJrjjYgdCUD9+HsGWAF6ZkJGWZmdfyOgvuqpVe5uuFN55hjbdD+pB1w est inconnu."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());

  }

  /**
   * PE0276_BL200_TelechargerAnnonce operation not autorised for annonce type
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_TelechargerAnnonce_BL200_KO_002() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#typePfs#33123456789#invalid"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, "telecharger"); //$NON-NLS-1$
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Operation non Autorisee pour l annonce " + encryptedUrlParameter + " de type invalid."); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());

  }

  /**
   * PE0276_TelechargerAnnonce acess refused
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_TelechargerAnnonce_BL200_KO_003() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("1000053016#typePfs#33123456789#PERSONNALISEE"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    Response response = executeStartProcess(request, "modifier"); //$NON-NLS-1$
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreeurExpected.setErrorDescription("Acces refuse"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = new Gson().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0276_TelechargerAnnonce acess refused
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_TelechargerAnnonce_Nominal() throws Throwable
  {
    byte[] contenuMediaSent = RandomUtils.nextBytes(128);

    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#STW#33123456789#PERSONNALISEE"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    prepare_SI031Mock(RetourFactory.createOkRetour(), contenuMediaSent);

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, "modifier"); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertArrayEquals(contenuMediaSent, IOUtils.toByteArray(response.getGenericResponse().getBinaryResult()));
  }

  /**
   * PE0276_TelechargerAnnonce CVG
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0276_TelechargerAnnonce_Nominal2() throws Throwable
  {
    byte[] contenuMediaSent = RandomUtils.nextBytes(128);

    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#CVG#33123456789#PERSONNALISEE"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(PARAM_CONFIG_PATH, "ConfigurationPE0276.xml"); //$NON-NLS-1$

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();

    prepare_SI015Mock(RetourFactory.createOkRetour(), contenuMediaSent);

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, "modifier"); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertArrayEquals(contenuMediaSent, IOUtils.toByteArray(response.getGenericResponse().getBinaryResult()));
  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PE0276_AnnoncesAccueils();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setNomProcessus(DEFAULT_PROCESSNAME);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessus.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessusBuilder.class);
    PowerMock.mockStatic(VMSSTW_SI031_TelechargerAnnonceAccueilBuilder.class);
    PowerMock.mockStatic(VMSSTW_SI031_TelechargerAnnonceAccueil.class);
    PowerMock.mockStatic(VMSCVM_SI015_TelechargerAnnonceAccueilBuilder.class);
    PowerMock.mockStatic(VMSCVM_SI015_TelechargerAnnonceAccueil.class);
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   *
   *
   * @param listeContract_p
   *          listeContract
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p, String listeContract_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("ClientOperateur"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
    hdr.setValue("Authorization : bearer XXXX"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue(listeContract_p);
    requestHeader_p.add(hdr);
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * @param key_p
   *          The key
   * @param value_p
   *          The value
   * @return process params
   */
  private ConcurrentHashMap<String, Map<String, String>> createProcessParams(String key_p, String value_p)
  {
    File classpath = new File(PE0276_AnnoncesAccueilGetTest.class.getResource("/").getFile()); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    if (!StringUtil.isNullOrEmpty(key_p))
    {
      map.put(key_p, classpath + "/" + value_p); //$NON-NLS-1$
    }

    processParams.put(StringConstants.EMPTY_STRING, map);
    return processParams;
  }

  /**
   * Create Response connector
   *
   * @return ResponseConnector
   */
  private ResponseConnector createResponseConnector() throws RavelException
  {
    ReponseFonctionnelle<AnnonceAccueilPfs> reponseFonctionnelle = new ReponseFonctionnelle<>();
    List<AnnonceAccueilPfs> items_p = new ArrayList<>();
    AnnonceAccueilPfs annonceAccueilPfs = new AnnonceAccueilPfs();
    annonceAccueilPfs.setIdAnnoncePfs("idAnnoncePfs_p"); //$NON-NLS-1$
    annonceAccueilPfs.setStatutAnnonce("statutAnnonce_p"); //$NON-NLS-1$
    annonceAccueilPfs.setTypeAnnonce("typeAnnonce_p"); //$NON-NLS-1$
    items_p.add(annonceAccueilPfs);
    reponseFonctionnelle.setItems(items_p); //$NON-NLS-1$
    reponseFonctionnelle.setResultsCount(1);

    String result = RavelJsonTools.getInstance().toJson(reponseFonctionnelle, new ReponseFonctionnelleParameterizedType<>(AnnonceAccueilPfs.class));

    com.bytel.spirit.common.connectors.ink.generated.Response res = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ServiceOrderResponse sor = new ServiceOrderResponse();
    ServiceOrderDataResponse sod = new ServiceOrderDataResponse();
    Dataset dso = new Dataset();
    DatasetParam ds = new DatasetParam();
    ds.setIndex(0);
    ds.setName("reponseFonctionnelle"); //$NON-NLS-1$
    ds.setValue(result);
    dso.getParams().add(ds);
    sod.setDataset(dso);
    sor.setSod(sod);
    res.setSo(sor);

    return new ResponseConnector(res, null);

  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _processInstance.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * Fills all the request headers
   *
   * @param request_p
   *          The request
   */
  private void fillAllRequestHeaders(Request request_p)
  {
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, X_REQUEST_ID_VALUE);
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    //RequestHeader xOauth2Idcontracts = createHeader(IHttpHeadersConsts.X_OAUTH2_IDCONTRACTS, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    fillRequestHeaders(request_p, xClientOperateur, xRequestId, xSource, xProcess);
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * @param retour_p
   *          retour
   * @param contenuMedia_p
   *          contenuMedia
   * @throws Exception
   *           probleme exception
   */
  private void prepare_SI015Mock(Retour retour_p, byte[] contenuMedia_p) throws Exception
  {
    PowerMock.expectNew(VMSCVM_SI015_TelechargerAnnonceAccueilBuilder.class).andReturn(_si015BuilderMock);
    EasyMock.expect(_si015BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si015BuilderMock);
    EasyMock.expect(_si015BuilderMock.idMessageriePfs(EasyMock.anyString())).andReturn(_si015BuilderMock);
    EasyMock.expect(_si015BuilderMock.typeAnnonce(EasyMock.anyString())).andReturn(_si015BuilderMock);
    EasyMock.expect(_si015BuilderMock.build()).andReturn(_si015Mock);
    EasyMock.expect(_si015Mock.execute(_processInstance)).andReturn(contenuMedia_p);
    EasyMock.expect(_si015Mock.getRetour()).andReturn(retour_p);

  }

  /**
   * @param retour_p
   *          retour
   * @param contenuMedia_p
   *          contenuMedia
   * @throws Exception
   *           probleme exception
   */
  private void prepare_SI031Mock(Retour retour_p, byte[] contenuMedia_p) throws Exception
  {
    PowerMock.expectNew(VMSSTW_SI031_TelechargerAnnonceAccueilBuilder.class).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.idMessageriePfs(EasyMock.anyString())).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.typeAnnonce(EasyMock.anyString())).andReturn(_si031BuilderMock);
    EasyMock.expect(_si031BuilderMock.build()).andReturn(_si031Builder);
    EasyMock.expect(_si031Builder.execute(_processInstance)).andReturn(contenuMedia_p);
    EasyMock.expect(_si031Builder.getRetour()).andReturn(retour_p);

  }

  /**
   * prepareProv_SI002
   *
   * @param retour_p
   *          retour
   * @param reponseConnector_p
   *          reponseconnector
   * @throws Exception
   *           excetpion
   */
  private void prepareProv_SI002(Retour retour_p, ResponseConnector reponseConnector_p) throws Exception
  {
    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.cles(EasyMock.anyObject())).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.priorite(10)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.processus(EasyMock.anyObject())).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.listeParametres(EasyMock.anyObject())).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.build()).andReturn(_si002_mock);
    EasyMock.expect(_si002_mock.execute(_processInstance)).andReturn(reponseConnector_p);
    EasyMock.expect(_si002_mock.getRetour()).andReturn(retour_p);
  }

  /**
   * prepareGetRequest
   *
   * @param tracabilite_p
   *          tracabilite
   * @param methode_p
   *          method
   * @param urlDynamicParameters_p
   *          idMessagerie / idAnnonce
   * @param listeContact_p
   *          listeContact
   * @return Request
   * @throws RavelException
   *           exception
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String methode_p, String urlDynamicParameters_p, String listeContact_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    addXHeaders(request.getRequestHeader(), tracabilite_p, listeContact_p);

    if (urlDynamicParameters_p != null)
    {
      request.setUrlDynamicParameters(urlDynamicParameters_p);
    }

    return request;
  }
}