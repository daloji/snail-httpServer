/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0275;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.core.MediaType;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.RandomUtils;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.json.RavelJson;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI025_TelechargeMessage;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI025_TelechargeMessage.VMSCVM_SI025_TelechargeMessageBuilder;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI028_TelechargeMessage;
import com.bytel.spirit.common.activities.vmsstw.VMSSTW_SI028_TelechargeMessage.VMSSTW_SI028_TelechargeMessageBuilder;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelleParameterizedType;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.ink.generated.Dataset;
import com.bytel.spirit.common.connectors.ink.generated.DatasetParam;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderDataResponse;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderResponse;
import com.bytel.spirit.common.shared.functional.types.json.MessagePfsFax;
import com.bytel.spirit.common.shared.functional.types.json.MessagePfsVoix;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_GetBL100Reponse;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_MessagesPFS;
import com.bytel.spirit.fiat.processes.structs.XAction;
import com.bytel.spirit.fiat.processes.structs.XLink;

import io.netty.util.internal.StringUtil;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author vloureir
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0275_Messages.class, ProcessManager.class, PROV_SI002_ExecuterProcessusBuilder.class, PROV_SI002_ExecuterProcessus.class, VMSSTW_SI028_TelechargeMessageBuilder.class, VMSSTW_SI028_TelechargeMessage.class, VMSCVM_SI025_TelechargeMessage.class, VMSCVM_SI025_TelechargeMessageBuilder.class })
public class PE0275_MessagesGetTest
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * LISTER_OPERATION
   */
  private static final String LISTER_OPERATION = "PE0275_Messages"; //$NON-NLS-1$

  /**
   * Configuration path Param
   */
  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
  *
  */
  private static final String PARAM_FRONT_ADRESSE = "FRONT_ADRESSE"; //$NON-NLS-1$

  /**
   * The X_REQUEST_ID_VALUE
   */
  private static final String X_REQUEST_ID_VALUE = "125667889000877"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0275_Messages"; //$NON-NLS-1$

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    Parameter parameter = new Parameter();

    parameter.setName(name_p);
    parameter.setValue(value_p);

    return parameter;
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    try
    {
      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager is now initialized")); //$NON-NLS-1$
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager instance is already initialized")); //$NON-NLS-1$
    }

  }

  /**
   * Instance of {@link PE0275_Messages}
   */
  private PE0275_Messages _processInstance;

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  ProcessManager _processManager;

  /**
   * PROV_SI002_ExecuterProcessusBuilder
   */
  @MockStrict
  PROV_SI002_ExecuterProcessusBuilder _si002_mockbuilder;

  /**
   * PROV_SI002_ExecuterProcessus
   */
  @MockStrict
  PROV_SI002_ExecuterProcessus _si002_mock;

  /**
   * VMSSTW_SI028_TelechargeMessageBuilder
   */
  @MockStrict
  VMSSTW_SI028_TelechargeMessageBuilder _si028BuilderMock;

  /**
   * VMSSTW_SI028_TelechargeMessage
   */
  @MockStrict
  VMSSTW_SI028_TelechargeMessage _si028Mock;

  /**
   * VMSSTW_SI028_TelechargeMessageBuilder
   */
  @MockStrict
  VMSCVM_SI025_TelechargeMessageBuilder _si025BuilderMock;

  /**
   * VMSSTW_SI028_TelechargeMessage
   */
  @MockStrict
  VMSCVM_SI025_TelechargeMessage _si025Mock;

  /**
   * PE0275_BL100_ListerMessagePfs error decryptage
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_ListerMessagePfs_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, "T1Ivr8FTvyIJfosxu4gRwzYMZKt+pWECPm945m+WgrQgsoOMyJ3uHw=", null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ID_MESSAGERIE_INCONNU);
    responseErreeurExpected.setErrorDescription("L id Messagerie T1Ivr8FTvyIJfosxu4gRwzYMZKt+pWECPm945m+WgrQgsoOMyJ3uHw= est inconnu."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();

    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_ListerMessagePfs operation not autorised for message type
   *
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_ListerMessagePfs_KO_002() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#+33123456789#typeMessagerie#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, null);

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Operation non Autorisee sur la messagerie " + encryptedUrlParameter + "."); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_ListerMessagePfs acess refused
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_ListerMessagePfs_KO_003() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#+33123456789#VOIX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreeurExpected.setErrorDescription("Acces refuse."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_ListerMessagePfs error calling KPSA CAT1
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_ListerMessagePfs_KO_004() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#+33123456789#VOIX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.DONNEE_INCONNUE, "libelle"); //$NON-NLS-1$
    prepareProcessParameters();

    prepareProv_SI002(ko, null);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ERREUR_INTERNE);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_ListerMessagePfs error calling KPSA CAT2
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_ListerMessagePfs_KO_005() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#+33123456789#VOIX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.DONNEE_INCONNUE, "libelle"); //$NON-NLS-1$
    prepareProcessParameters();

    prepareProv_SI002(ko, null);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.PFS_INDISPO);
    responseErreeurExpected.setErrorDescription("Service momentanement indisponible."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00503, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_ListerMessagePfs error calling KPSA not CAT1/CAT2
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_ListerMessagePfs_KO_006() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#+33123456789#VOIX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    Retour ko = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "libelle"); //$NON-NLS-1$
    prepareProcessParameters();

    prepareProv_SI002(ko, null);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegConsts.DONNEE_INCONNUE);
    responseErreeurExpected.setErrorDescription("libelle"); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL100_ListerMessagePfs error calling KPSA not CAT1/CAT2
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL100_ListerMessagePfs_KO_007() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#+33123456789#VOIX"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    prepareProcessParameters();
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ID_MESSAGERIE_INCONNU);
    responseErreeurExpected.setErrorDescription("L id Messagerie mVlAe2zymjmLNABDSWnE6awxVYkjetOsIbAup0vaN8k- est inconnu."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL200_TelechargerMessagePfs error decryptage
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL200_TelechargerMessagePfs_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, "RhyesyKnRJrjjYgdCUD9+HsGWAF6ZkJGWZmdfyOgvuqpVe5uuFN55hjbdD+pB1w", null); //$NON-NLS-1$

    prepareProcessParameters();
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, "telecharer"); //$NON-NLS-1$
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ID_MESSAGE_INCONNU);
    responseErreeurExpected.setErrorDescription("L'id Message RhyesyKnRJrjjYgdCUD9+HsGWAF6ZkJGWZmdfyOgvuqpVe5uuFN55hjbdD+pB1w est inconnu."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    //Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());//TODO: Validate if on syncGetResponse should have a error for id_Message_Inconnu
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());

  }

  /**
   * PE0275_BL200_TelechargerMessagePfs operation not autorised for annonce type
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL200_TelechargerMessagePfs_KO_002() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#+123456789#typeMessagerie#invalid#8876"); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    prepareProcessParameters();
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, "telecharger"); //$NON-NLS-1$
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Operation non Autorisee pour le message " + encryptedUrlParameter + " de type invalid."); //$NON-NLS-1$ //$NON-NLS-2$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());

  }

  /**
   * PE0275_BL200_TelechargerMessagePfs acess refused
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_BL200_TelechargerMessagePfs_KO_003() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("#+123456789#typeMessagerie#VOIX#8876"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    Response response = executeStartProcess(request, "modifier"); //$NON-NLS-1$
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.ACCES_REFUSE);
    responseErreeurExpected.setErrorDescription("Acces refuse."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Nominal for ListerAnnonce with typeMessage = FAX
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_ListerMessagePfs_Nominal_FAX() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#+33123456789#FAX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    prepareProcessParameters();

    ResponseConnector reponseConnector = createResponseConnectorFAX();
    prepareProv_SI002(RetourFactory.createOkRetour(), reponseConnector);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String reponseJson = response.getGenericResponse().getResult();

    PE0275_GetBL100Reponse bl100Response = RavelJsonTools.getInstance().fromJson(reponseJson, PE0275_GetBL100Reponse.class);

    //Validate response object
    Assert.assertNotNull(bl100Response);
    Assert.assertEquals(new Integer(1), bl100Response.getResultsCount());

    //Validate self link
    Assert.assertNotNull(bl100Response.getLinks());
    Assert.assertNotNull(bl100Response.getLinks().get(XLink.SELF));
    Assert.assertEquals("/messageries/" + encryptedUrlParameter + "/messages?format=metadata", bl100Response.getLinks().get(XLink.SELF).getHref()); //$NON-NLS-1$ //$NON-NLS-2$

    //Validate Items List
    Assert.assertNotNull(bl100Response.getItems());
    Assert.assertEquals(1, bl100Response.getItems().size());

    //Validate item
    PE0275_MessagesPFS item = bl100Response.getItems().get(0);
    Assert.assertNotNull(item);
    Assert.assertEquals("mVlAe2zymjmLNABDSWnE6awxVYkjetOs.X.HnS_yGLI08dHXchw2Jw--", item.getIdMessagerie()); //$NON-NLS-1$
    Assert.assertEquals(encryptedUrlParameter, item.getIdMessagerie());
    Assert.assertEquals("FAX", item.getTypeMessage()); //$NON-NLS-1$
    Assert.assertEquals("RECU", item.getStatut()); //$NON-NLS-1$
    Assert.assertEquals("mVlAe2zymjk0Dl11CQ2fqZJSXRQxP2u5rDFViSN606xcF8lZIr7Lai4XW99EJRKq", item.getIdMessage()); //$NON-NLS-1$
    Assert.assertEquals("+33978000001", item.getExpediteur()); //$NON-NLS-1$
    Assert.assertEquals("idCorrelation", item.getIdCorrelation()); //$NON-NLS-1$
    Assert.assertEquals(new Integer(1), item.getNbPages());
    Assert.assertEquals("+33978000011", item.getDestinataire()); //$NON-NLS-1$

    //Validate item link
    Assert.assertNotNull(item.getLinks());
    Assert.assertNotNull(item.getLinks().get("telechargerMessage"));
    Assert.assertEquals("/messages/mVlAe2zymjk0Dl11CQ2fqZJSXRQxP2u5rDFViSN606xcF8lZIr7Lai4XW99EJRKq/contenu", item.getLinks().get("telechargerMessage").getHref()); //$NON-NLS-1$

    //Validate item action
    Assert.assertNotNull(item.getActions());

    XAction supprimerMessagePfs = item.getActions().get("supprimerMessage");
    Assert.assertNotNull(supprimerMessagePfs);
    Assert.assertEquals(MediaType.APPLICATION_JSON, supprimerMessagePfs.getType());
    Assert.assertEquals(HttpConstants.DEL_METHOD, supprimerMessagePfs.getMethod());
    Assert.assertEquals("/messages/mVlAe2zymjk0Dl11CQ2fqZJSXRQxP2u5rDFViSN606xcF8lZIr7Lai4XW99EJRKq", supprimerMessagePfs.getAction()); //$NON-NLS-1$
  }

  /**
   * Nominal for ListerAnnonce with typeMessage = VOIX
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_ListerMessagePfs_Nominal_VOIX() throws Throwable
  {
    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("10000530160#+33123456789#VOIX#typePfs"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    prepareProcessParameters();
    ResponseConnector reponseConnector = createResponseConnectorVOIX();
    prepareProv_SI002(RetourFactory.createOkRetour(), reponseConnector);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String reponseJson = response.getGenericResponse().getResult();

    PE0275_GetBL100Reponse bl100Response = RavelJsonTools.getInstance().fromJson(reponseJson, PE0275_GetBL100Reponse.class);

    //Validate response object
    Assert.assertNotNull(bl100Response);
    Assert.assertEquals(new Integer(1), bl100Response.getResultsCount());

    //Validate self link
    Assert.assertNotNull(bl100Response.getLinks());
    Assert.assertNotNull(bl100Response.getLinks().get(XLink.SELF).getHref());
    Assert.assertEquals("/messageries/" + encryptedUrlParameter + "/messages?format=metadata", bl100Response.getLinks().get(XLink.SELF).getHref()); //$NON-NLS-1$ //$NON-NLS-2$

    //Validate Items List
    Assert.assertNotNull(bl100Response.getItems());
    Assert.assertEquals(1, bl100Response.getItems().size());

    //Validate item
    PE0275_MessagesPFS item = bl100Response.getItems().get(0);
    Assert.assertNotNull(item);
    Assert.assertEquals("mVlAe2zymjmLNABDSWnE6awxVYkjetOsXZwtjqQsJEYLhTZMmya4LA--", item.getIdMessagerie()); //$NON-NLS-1$
    Assert.assertEquals(encryptedUrlParameter, item.getIdMessagerie());
    Assert.assertEquals("VOIX", item.getTypeMessage()); //$NON-NLS-1$
    Assert.assertEquals("RECU", item.getStatut()); //$NON-NLS-1$
    Assert.assertEquals("mVlAe2zymjk0Dl11CQ2fqZJSXRQxP2u5rDFViSN606wXtyxzc9Ed14xCuJb4.j8D", item.getIdMessage()); //$NON-NLS-1$
    Assert.assertEquals("PT1S", item.getDuree()); //$NON-NLS-1$
    Assert.assertEquals("+33978000001", item.getExpediteur()); //$NON-NLS-1$
    Assert.assertEquals("NON_LU", item.getSuivi().getStatutLecture()); //$NON-NLS-1$

    //Validate item link
    Assert.assertNotNull(item.getLinks());
    Assert.assertNotNull(item.getLinks().get("telechargerMessage"));
    Assert.assertEquals("/messages/mVlAe2zymjk0Dl11CQ2fqZJSXRQxP2u5rDFViSN606wXtyxzc9Ed14xCuJb4.j8D/contenu", item.getLinks().get("telechargerMessage").getHref()); //$NON-NLS-1$

    //Validate item action
    Assert.assertNotNull(item.getActions());

    XAction supprimerMessagePfs = item.getActions().get("supprimerMessage");
    Assert.assertNotNull(supprimerMessagePfs);
    Assert.assertEquals(MediaType.APPLICATION_JSON, supprimerMessagePfs.getType());
    Assert.assertEquals(HttpConstants.DEL_METHOD, supprimerMessagePfs.getMethod());
    Assert.assertEquals("/messages/mVlAe2zymjk0Dl11CQ2fqZJSXRQxP2u5rDFViSN606wXtyxzc9Ed14xCuJb4.j8D", supprimerMessagePfs.getAction()); //$NON-NLS-1$

    //Validate item ModifierStatutMessage
    XAction modifierStatutMessage = item.getActions().get("modifierStatutsMessage");
    Assert.assertNotNull(modifierStatutMessage);
    Assert.assertEquals(MediaType.APPLICATION_JSON, modifierStatutMessage.getType());
    Assert.assertEquals(HttpConstants.PUT_METHOD, modifierStatutMessage.getMethod());
    Assert.assertEquals("/messages/mVlAe2zymjk0Dl11CQ2fqZJSXRQxP2u5rDFViSN606wXtyxzc9Ed14xCuJb4.j8D/suivi", modifierStatutMessage.getAction()); //$NON-NLS-1$
  }

  /**
   * Missing config files
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_BL001_VerifierDonneesConsultation_KO_001() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);
    ConcurrentHashMap<String, Map<String, String>> processParams = createProcessParams(null, null);

    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).times(3);
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).times(3);

    PowerMock.replayAll();

    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegConsts.CONFIGURATION_INVALIDE);
    responseErreeurExpected.setErrorDescription(""); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
  }

  /**
   * Case Lister Annonce, missing idMessagerie
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_BL001_VerifierDonneesConsultation_KO_002() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);

    prepareProcessParameters();
    PowerMock.replayAll();

    Response response = executeStartProcess(request, LISTER_OPERATION);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter idMessagerie is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * Case telecharger, missing idMessage
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_BL001_VerifierDonneesConsultation_KO_003() throws Throwable
  {
    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, null, null);

    prepareProcessParameters();
    PowerMock.replayAll();

    Response response = executeStartProcess(request, "telecharger"); //$NON-NLS-1$
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter idMessage is null or empty."); //$NON-NLS-1$
    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected.getError(), reponseactual.getError());
    Assert.assertEquals(responseErreeurExpected.getErrorDescription(), reponseactual.getErrorDescription());
  }

  /**
   * PE0275_BL200_TelechargerMessagePfs Nominal for typePFS CVG
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_TelechargerMessagePfs_Nominal_CVG() throws Throwable
  {
    byte[] contenuMediaSent = RandomUtils.nextBytes(128);

    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#CVG#typeMessagerie#VOIX#8876"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    prepareProcessParameters();
    prepare_SI025Mock(RetourFactory.createOkRetour(), contenuMediaSent);

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, "modifier"); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertArrayEquals(contenuMediaSent, IOUtils.toByteArray(response.getGenericResponse().getBinaryResult()));
  }

  /**
   * PE0275_BL200_TelechargerMessagePfs Nominal for typePFS SWT
   *
   * Status Code = 500
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_TelechargerMessagePfs_Nominal_STW() throws Throwable
  {
    byte[] contenuMediaSent = RandomUtils.nextBytes(128);

    String encryptedUrlParameter = PasswordEncrypter.encryptForURL("144104#STW#typeMessagerie#VOIX#8876"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, HttpConstants.GET_METHOD, encryptedUrlParameter, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    prepareProcessParameters();

    prepare_SI028Mock(RetourFactory.createOkRetour(), contenuMediaSent);

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, "modifier"); //$NON-NLS-1$
    PowerMock.verifyAll();

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    Assert.assertArrayEquals(contenuMediaSent, IOUtils.toByteArray(response.getGenericResponse().getBinaryResult()));
  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PE0275_Messages();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setNomProcessus(DEFAULT_PROCESSNAME);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessus.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessusBuilder.class);
    PowerMock.mockStatic(VMSSTW_SI028_TelechargeMessageBuilder.class);
    PowerMock.mockStatic(VMSSTW_SI028_TelechargeMessage.class);
    PowerMock.mockStatic(VMSCVM_SI025_TelechargeMessageBuilder.class);
    PowerMock.mockStatic(VMSCVM_SI025_TelechargeMessage.class);
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   *
   *
   * @param listeContract_p
   *          listeContract
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p, String listeContract_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("ClientOperateur"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
    hdr.setValue("Authorization : bearer XXXX"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue(listeContract_p);
    requestHeader_p.add(hdr);
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * @param key_p
   *          The key
   * @param value_p
   *          The value
   * @return process params
   */
  private ConcurrentHashMap<String, Map<String, String>> createProcessParams(String key_p, String value_p)
  {
    File classpath = new File(PE0275_MessagesGetTest.class.getResource("/").getFile()); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    if (!StringUtil.isNullOrEmpty(key_p))
    {
      map.put(key_p, classpath + "/" + value_p); //$NON-NLS-1$
    }

    processParams.put(StringConstants.EMPTY_STRING, map);
    return processParams;
  }

  /**
   * Create Response connector FAX
   *
   * @return ResponseConnector
   */
  private ResponseConnector createResponseConnectorFAX() throws RavelException
  {
    com.bytel.spirit.common.connectors.ink.generated.Response response = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector reponseConnector = __podam.manufacturePojo(ResponseConnector.class);
    ReponseFonctionnelle reponsefonctionnel = new ReponseFonctionnelle();
    reponsefonctionnel.setResultsCount(1);
    List<MessagePfsFax> items_p = new ArrayList<>();
    MessagePfsFax messagesPfs = new MessagePfsFax();
    messagesPfs.setIdMessagePfs("vru290lm"); //$NON-NLS-1$
    messagesPfs.setExpediteur("+33978000001"); //$NON-NLS-1$
    messagesPfs.setStatutLecture("statutLecture_p"); //$NON-NLS-1$
    messagesPfs.setTypeMessage("FAX"); //$NON-NLS-1$
    messagesPfs.setStatutLecture("NON_LU");
    messagesPfs.setIdCorrelation("idCorrelation");
    messagesPfs.setNbPages(1);
    messagesPfs.setDestinataires(new String[] { "+33978000011", "+33978000012", "+33978000013" });
    messagesPfs.setStatutTransfert("EMISSION");
    items_p.add(messagesPfs);
    reponsefonctionnel.setItems(items_p);
    String result = new RavelJson.RavelJsonBuilder()//
        .build()//
        .<ReponseFonctionnelle<MessagePfsFax>> adapter(new ReponseFonctionnelleParameterizedType<>(MessagePfsFax.class))//
        .toJson(reponsefonctionnel);//;
    Dataset dataset = new Dataset();
    List<DatasetParam> listdata = new ArrayList<>();
    DatasetParam datasetparam = new DatasetParam();
    datasetparam.setIndex(1);
    datasetparam.setName("reponseFonctionnelle"); //$NON-NLS-1$
    datasetparam.setValue(result);
    listdata.add(datasetparam);
    dataset.getParams().add(datasetparam);
    ServiceOrderDataResponse serviceData = new ServiceOrderDataResponse();
    serviceData.setDataset(dataset);
    ServiceOrderResponse so = new ServiceOrderResponse();
    so.setSod(serviceData);
    response.setSo(so);
    reponseConnector.setResponse(response);
    return reponseConnector;

  }

  /**
   * Create Response connector VOIX
   *
   * @return ResponseConnector
   */
  private ResponseConnector createResponseConnectorVOIX() throws RavelException
  {
    com.bytel.spirit.common.connectors.ink.generated.Response response = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector reponseConnector = __podam.manufacturePojo(ResponseConnector.class);
    ReponseFonctionnelle reponsefonctionnel = new ReponseFonctionnelle();
    reponsefonctionnel.setResultsCount(1);
    List<MessagePfsVoix> items_p = new ArrayList<>();
    MessagePfsVoix messagesPfs = new MessagePfsVoix();
    messagesPfs.setIdMessagePfs("vru290lm"); //$NON-NLS-1$
    messagesPfs.setDuree(1);
    messagesPfs.setExpediteur("+33978000001"); //$NON-NLS-1$
    messagesPfs.setStatutLecture("statutLecture_p"); //$NON-NLS-1$
    messagesPfs.setTypeMessage("VOIX"); //$NON-NLS-1$
    messagesPfs.setStatutLecture("NON_LU");
    items_p.add(messagesPfs);
    reponsefonctionnel.setItems(items_p);
    String result = new RavelJson.RavelJsonBuilder()//
        .build()//
        .<ReponseFonctionnelle<MessagePfsVoix>> adapter(new ReponseFonctionnelleParameterizedType<>(MessagePfsVoix.class))//
        .toJson(reponsefonctionnel);//;
    Dataset dataset = new Dataset();
    List<DatasetParam> listdata = new ArrayList<>();
    DatasetParam datasetparam = new DatasetParam();
    datasetparam.setIndex(1);
    datasetparam.setName("reponseFonctionnelle"); //$NON-NLS-1$
    datasetparam.setValue(result);
    listdata.add(datasetparam);
    dataset.getParams().add(datasetparam);
    ServiceOrderDataResponse serviceData = new ServiceOrderDataResponse();
    serviceData.setDataset(dataset);
    ServiceOrderResponse so = new ServiceOrderResponse();
    so.setSod(serviceData);
    response.setSo(so);
    reponseConnector.setResponse(response);
    return reponseConnector;

  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _processInstance.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * Fills all the request headers
   *
   * @param request_p
   *          The request
   */
  private void fillAllRequestHeaders(Request request_p)
  {
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, X_REQUEST_ID_VALUE);
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    //RequestHeader xOauth2Idcontracts = createHeader(IHttpHeadersConsts.X_OAUTH2_IDCONTRACTS, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    fillRequestHeaders(request_p, xClientOperateur, xRequestId, xSource, xProcess);
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * @param retour_p
   *          retour
   * @param contenuMedia_p
   *          contenuMedia
   * @throws Exception
   *           probleme exception
   */
  private void prepare_SI025Mock(Retour retour_p, byte[] contenuMedia_p) throws Exception
  {
    PowerMock.expectNew(VMSCVM_SI025_TelechargeMessageBuilder.class).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.idMessagePfs(EasyMock.anyString())).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.idMessageriePfs(EasyMock.anyString())).andReturn(_si025BuilderMock);
    EasyMock.expect(_si025BuilderMock.build()).andReturn(_si025Mock);
    EasyMock.expect(_si025Mock.execute(_processInstance)).andReturn(contenuMedia_p);
    EasyMock.expect(_si025Mock.getRetour()).andReturn(retour_p);

  }

  /**
   * @param retour_p
   *          retour
   * @param contenuMedia_p
   *          contenuMedia
   * @throws Exception
   *           probleme exception
   */
  private void prepare_SI028Mock(Retour retour_p, byte[] contenuMedia_p) throws Exception
  {
    PowerMock.expectNew(VMSSTW_SI028_TelechargeMessageBuilder.class).andReturn(_si028BuilderMock);
    EasyMock.expect(_si028BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si028BuilderMock);
    EasyMock.expect(_si028BuilderMock.idMessagePfs(EasyMock.anyString())).andReturn(_si028BuilderMock);
    EasyMock.expect(_si028BuilderMock.typeMessage(EasyMock.anyString())).andReturn(_si028BuilderMock);
    EasyMock.expect(_si028BuilderMock.build()).andReturn(_si028Mock);
    EasyMock.expect(_si028Mock.execute(_processInstance)).andReturn(contenuMedia_p);
    EasyMock.expect(_si028Mock.getRetour()).andReturn(retour_p);

  }

  /**
  *
  */
  private void prepareProcessParameters()
  {

    File classpath = new File(PE0275_MessagesPostTest.class.getResource("/").getFile()); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    map.put(PARAM_FRONT_ADRESSE, "localhost:8000"); //$NON-NLS-1$
    map.put(PARAM_CONFIG_PATH, classpath + "/" + "ConfigurationPE0275.xml");
    processParams.put(StringConstants.EMPTY_STRING, map);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();
  }

  /**
   * prepareProv_SI002
   *
   * @param retour_p
   *          retour
   * @param reponseConnector_p
   *          reponseconnector
   * @throws Exception
   *           excetpion
   */
  private void prepareProv_SI002(Retour retour_p, ResponseConnector reponseConnector_p) throws Exception
  {
    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.cles(EasyMock.anyObject())).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.priorite(10)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.processus(EasyMock.anyObject())).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.listeParametres(EasyMock.anyObject())).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.build()).andReturn(_si002_mock);
    EasyMock.expect(_si002_mock.execute(_processInstance)).andReturn(reponseConnector_p);
    EasyMock.expect(_si002_mock.getRetour()).andReturn(retour_p);
  }

  /**
   * prepareGetRequest
   *
   * @param tracabilite_p
   *          tracabilite
   * @param methode_p
   *          method
   * @param urlDynamicParameters_p
   *          idMessagerie / idMessage
   * @param listeContact_p
   *          listeContact
   * @return Request
   * @throws RavelException
   *           exception
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String methode_p, String urlDynamicParameters_p, String listeContact_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    addXHeaders(request.getRequestHeader(), tracabilite_p, listeContact_p);

    if (urlDynamicParameters_p != null)
    {
      request.setUrlDynamicParameters(urlDynamicParameters_p);
    }

    return request;
  }
}