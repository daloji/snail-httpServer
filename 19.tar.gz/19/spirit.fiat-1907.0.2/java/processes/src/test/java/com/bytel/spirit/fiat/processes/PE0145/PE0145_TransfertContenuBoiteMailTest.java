/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0145;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.easymock.EasyMockSupport;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.Mock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.factory.response.RavelResponseFactory;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.JavaTimeManufacturer;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.DonneesProvisionneesSTPfsMail;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.mail.StPfsMail;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.Statut;
import com.bytel.spirit.common.shared.types.json.request.ServiceMailRequest;
import com.bytel.spirit.common.shared.types.json.request.ServiceMailTransfertRequest;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0145.structs.PE0145_BL001_VerifierDonneesReturn;
import com.bytel.spirit.fiat.processes.PE0145.structs.PE0145_BL100_PreparerTransfertContenuBoiteMailReturn;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0145_TransfertContenuBoiteMail.class, RSTProxy.class, PROV_SI002_ExecuterProcessus.class, PROV_SI002_ExecuterProcessusBuilder.class, })
public class PE0145_TransfertContenuBoiteMailTest extends EasyMockSupport
{
  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;
  /*
   * Tracabilite
   */
  private static Tracabilite _tracabilite;
  /**
   * The MAIL_INCONNU message
   */
  private static final String MESSAGE_MAIL_INCONNU = Messages.getString("PE0145.BL100.UnknownAddressMail"); //$NON-NLS-1$

  /**
   * Factory to generate beans
   */
  private static PodamFactory _podam = new PodamFactoryImpl();

  /**
   * Run before tests
   *
   * @throws Exception
   *           throw exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$

    _podam.getStrategy().setMemoization(false);
    _podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
    JavaTimeManufacturer.registerPodamFactory(_podam);

  }

  /**
   * Instance of {@link PE0145_TransfertContenuBoiteMail}
   */
  private PE0145_TransfertContenuBoiteMail _processInstance;

  /**
   * _RSTProxy Mock
   */
  @Mock
  private RSTProxy _RSTProxyMock;

  /**
   * The SI002 activity mock
   */
  @MockStrict
  PROV_SI002_ExecuterProcessus _si002Mock;

  /**
   * The SI002 activity builder mock
   */
  @MockStrict
  PROV_SI002_ExecuterProcessusBuilder _si002BuilderMock;

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field modeTransfert is not set<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_modeTransfert]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_KO_01() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_modeTransfert]", null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    mailRequest.setModeTransfert(null); //cause validation error

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PE0145_BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field identifiantAccessCible.loginMail is in a bad format<br>
   * <b>Result:</b> Format d'attribut(s) non respecté(s): [_identifiantAccesCible._loginMail]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_KO_02() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Format d'attribut(s) non respecté(s): [_identifiantAccesCible._loginMail]", null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    mailRequest.getIdentifiantAccesCible().setLoginMail("Charles(rock"); //$NON-NLS-1$

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PE0145_BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field portefeuilleServicesSource is not set<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_portefeuilleServicesSource]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_KO_03() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_portefeuilleServicesSource]", null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    mailRequest.setPortefeuilleServicesSource(null); // cause validation error

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PE0145_BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field identifiantAccessSource.loginMail is not set<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_identifiantAccesSource._loginMail]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_KO_04() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_identifiantAccesSource._loginMail]", null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    mailRequest.getIdentifiantAccesSource().setLoginMail(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PE0145_BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field portefeuilleServicesCible.noCompte is not set<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_portefeuilleServicesCible._noCompte]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_KO_05() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Attribut(s) obligatoire(s) manquant(s): [_portefeuilleServicesCible._noCompte]", null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    mailRequest.getPortefeuilleServicesCible().setNoCompte(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PE0145_BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. Assert that validation errors exist.<br>
   * <b>Input:</b> The required fields portefeuilleServicesCible.noCompte and _portefeuilleServicesSource._noCompte are
   * not set<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s):
   * [_portefeuilleServicesCible._noCompte][_portefeuilleServicesSource._noCompte]
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_KO_06() throws Exception
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    mailRequest.getPortefeuilleServicesCible().setNoCompte(null);
    mailRequest.getPortefeuilleServicesSource().setNoCompte(null);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PE0145_BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(IMegConsts.CAT3, retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, retour.getRetour().getDiagnostic());
    assertTrue(retour.getRetour().getLibelle().contains("_portefeuilleServicesCible._noCompte")); //$NON-NLS-1$
    assertTrue(retour.getRetour().getLibelle().contains("_portefeuilleServicesSource._noCompte")); //$NON-NLS-1$
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required header X-Client-Operateur is not set.<br>
   * <b>Input:</b> "X-Client-Operateur" not set in headers<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Header X-Client-Operateur null ou vide.,
   * PE0145_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_KO_07() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_CLIENT_OPERATEUR), null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xRequestId, xProcess, xSource);

    PE0145_BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required header X-Source is not set.<br>
   * <b>Input:</b> "X-Source" not set in headers<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Header X-Source null ou vide., PE0145_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_KO_08() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_SOURCE), null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xRequestId, xProcess);

    PE0145_BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required header X-Process is not set.<br>
   * <b>Input:</b> "X-Process" not set in headers<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Header X-Process null ou vide., PE0145_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_KO_09() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_PROCESS), null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xRequestId, xSource);

    PE0145_BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$

    assertEquals(retourExpected, retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. The required header X-Request-Id is not set.<br>
   * <b>Input:</b> "X-Request-Id" not set in headers<br>
   * <b>Result:</b> Retour {KO, CAT-3, NON_RESPECT_STI, Header X-Request-Id null ou vide., PE0145_BL001_VerifierDonnees}
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_KO_10() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID), null); //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);

    request.setPayload(jSonRequest);

    PE0145_BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retourExpected, bl001Retour.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests nominal case without an activation <br>
   * <b>Input:</b> All valid inputs<br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnees_Test_OK() throws Exception
  {
    Retour retourOK = RetourFactoryForTU.createOkRetour();

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);

    PE0145_BL001_VerifierDonneesReturn bl001Retour = Whitebox.invokeMethod(_processInstance, "PE0145_BL001_VerifierDonnees", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retourOK, bl001Retour.getRetour());
  }

  /**
   *
   * <b>Scenario:</b> Tests non nominal case. BL002 receives a previous KO Retour<br>
   * <b>Input:</b> KORetour "NON_RESPECT_STI" from BL001<br>
   * <b>Result:</b> Pair<ReponseErreur, Retour> where ReponseError is not null and built from BL001Retour and Retour
   * KO<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL002_FormaterReponse_Test_KO_01() throws Exception
  {

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_PROCESS), null); //$NON-NLS-1$

    //RetourKO produced by BL001
    String libelleErreur = MessageFormat.format(Messages.getString("PE0145.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_PROCESS); //$NON-NLS-1$
    Retour bl001retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, libelleErreur, null);

    Pair<ReponseErreur, Retour> bl002result = Whitebox.invokeMethod(_processInstance, "PE0145_BL002_FormaterReponse", _tracabilite, bl001retour); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retourExpected.getDiagnostic(), bl002result._first.getError());
    assertEquals(retourExpected.getLibelle(), bl002result._first.getErrorDescription());
    assertEquals(retourExpected, bl002result._second);
  }

  /**
   *
   * <b>Scenario:</b> Tests nominal case.<br>
   * <b>Input:</b> RetourOK <br>
   * <b>Result:</b> Pair<ReponseErreur, Retour> where ReponseError is null and Retour is OK<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL002_FormaterReponse_Test_OK() throws Exception
  {
    Retour retourExpected = RetourFactoryForTU.createOkRetour();

    Pair<ReponseErreur, Retour> bl002result = Whitebox.invokeMethod(_processInstance, "PE0145_BL002_FormaterReponse", _tracabilite, RetourFactoryForTU.createOkRetour()); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(null, bl002result._first);
    assertEquals(retourExpected, bl002result._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. RST returns KO while getting ST PFS MAIL list for PfiSource<br>
   * <b>Result:</b> Retour {NOK; CAT-4; MAIL_INCONNU; Mail adresseMailSourceMock non connu pour le Pfi
   * noCompteSourceMock}<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL100_PreparerTransfertContenuBoiteMail_Test_KO_01() throws Exception
  {
    String adresseMailSource_p = "adresseMailSourceMock"; //$NON-NLS-1$
    String noCompteSource_p = "noCompteSourceMock"; //$NON-NLS-1$
    String clientOperateur_p = "clientOperateurMock"; //$NON-NLS-1$
    String noCompteCible_p = "noCompteCibleMock"; //$NON-NLS-1$
    String adresseMailCible_p = "adresseMailCibleMock"; //$NON-NLS-1$

    //Create Expected Retour
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PE0145.BL100.UnknownAddressMail"), adresseMailSource_p, noCompteSource_p), null); //$NON-NLS-1$
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100ExpectedResult = new PE0145_BL100_PreparerTransfertContenuBoiteMailReturn(retourExpected);

    //Prepare RSTConnector Mock Response
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "MOCK Error from RSTConnector", null), null); //$NON-NLS-1$

    //Call RSTConnector Mock
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    //Call PE0145_BL100_PreparerTransfertContenuBoiteMail
    PowerMock.replayAll();
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0145_BL100_PreparerTransfertContenuBoiteMail", _tracabilite, clientOperateur_p, noCompteSource_p, adresseMailSource_p, noCompteCible_p, adresseMailCible_p); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(bl100ExpectedResult.getRetour(), bl100Result.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. RST returns OK, but serviceTechnique returned does not contain any
   * StPfsMail with adresseMail = adresseMailSource<br>
   * <b>Input:</b> adresseMailSource not contained in RSTConnector Response<br>
   * <b>Result:</b> Retour {NOK; CAT-4; MAIL_INCONNU; Mail adresseMailSourceMock non connu pour le Pfi
   * noCompteSourceMock}<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL100_PreparerTransfertContenuBoiteMail_Test_KO_02() throws Exception
  {
    String adresseMailSource_p = "adresseMailSourceMock"; //$NON-NLS-1$
    String noCompteSource_p = "noCompteSourceMock"; //$NON-NLS-1$
    String clientOperateur_p = "clientOperateurMock"; //$NON-NLS-1$
    String noCompteCible_p = "noCompteCibleMock"; //$NON-NLS-1$
    String adresseMailCible_p = "adresseMailCibleMock"; //$NON-NLS-1$

    //Create Expected Retour
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PE0145.BL100.UnknownAddressMail"), adresseMailSource_p, noCompteSource_p), null); //$NON-NLS-1$
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100ExpectedResult = new PE0145_BL100_PreparerTransfertContenuBoiteMailReturn(retourExpected);

    //Prepare RSTConnector Mock Response
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail("invalidAdresseMail", 0, 1, null); //$NON-NLS-1$
    donneesProvisionneesSTPfsMail.setIdCompteMailPrincipal("idCompteMailMock"); //$NON-NLS-1$

    ServiceTechnique serviceTechniqueMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock.setNoCompte(noCompteSource_p);
    serviceTechniqueMock.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMock).setDonneesProvisionneesStPfsMail(donneesProvisionneesSTPfsMail);

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Call RSTConnector Mock
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    //Call PE0145_BL100_PreparerTransfertContenuBoiteMail
    PowerMock.replayAll();
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0145_BL100_PreparerTransfertContenuBoiteMail", _tracabilite, clientOperateur_p, noCompteSource_p, adresseMailSource_p, noCompteCible_p, adresseMailCible_p); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(bl100ExpectedResult.getRetour(), bl100Result.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. RST returns OK, but serviceTechnique returned does not have "ACTIF"
   * statut<br>
   * <b>Input:</b> ServiceTechnique returned by RSTConnector has statut "RESILIE"<br>
   * <b>Result:</b> Retour {NOK; CAT-4; MAIL_INCONNU; Mail adresseMailSourceMock non activé sur la PFS ROMA.}<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL100_PreparerTransfertContenuBoiteMail_Test_KO_03() throws Exception
  {
    String adresseMailSource_p = "adresseMailSourceMock"; //$NON-NLS-1$
    String noCompteSource_p = "noCompteSourceMock"; //$NON-NLS-1$
    String clientOperateur_p = "clientOperateurMock"; //$NON-NLS-1$
    String noCompteCible_p = "noCompteCibleMock"; //$NON-NLS-1$
    String adresseMailCible_p = "adresseMailCibleMock"; //$NON-NLS-1$

    //Create Expected Retour
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PE0145.BL100.InactiveAddressMail"), adresseMailSource_p), null); //$NON-NLS-1$
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100ExpectedResult = new PE0145_BL100_PreparerTransfertContenuBoiteMailReturn(retourExpected);

    //Prepare RSTConnector Mock Response
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail(adresseMailSource_p, 0, 1, null);
    donneesProvisionneesSTPfsMail.setIdCompteMailPrincipal("idCompteMailMock"); //$NON-NLS-1$

    ServiceTechnique serviceTechniqueMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock.setNoCompte(noCompteSource_p);
    serviceTechniqueMock.setStatut(Statut.INACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMock).setDonneesProvisionneesStPfsMail(donneesProvisionneesSTPfsMail);

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Call RSTConnector Mock
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    //Call PE0145_BL100_PreparerTransfertContenuBoiteMail
    PowerMock.replayAll();
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0145_BL100_PreparerTransfertContenuBoiteMail", _tracabilite, clientOperateur_p, noCompteSource_p, adresseMailSource_p, noCompteCible_p, adresseMailCible_p); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(bl100ExpectedResult.getRetour(), bl100Result.getRetour());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. RST returns OK for Pfi Source but returns KO for Pfi Cible<br>
   * <b>Result:</b> Retour {NOK; CAT-4; MAIL_INCONNU; Mail adresseMailCibleMock non connu pour le Pfi
   * noCompteCibleMock}<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL100_PreparerTransfertContenuBoiteMail_Test_KO_04() throws Exception
  {
    String adresseMailSource_p = "adresseMailSourceMock"; //$NON-NLS-1$
    String noCompteSource_p = "noCompteSourceMock"; //$NON-NLS-1$
    String clientOperateur_p = "clientOperateurMock"; //$NON-NLS-1$
    String noCompteCible_p = "noCompteCibleMock"; //$NON-NLS-1$
    String adresseMailCible_p = "adresseMailCibleMock"; //$NON-NLS-1$

    String idCompteMailSource_p = "idCompteMailSourceMock"; //$NON-NLS-1$

    //Create Expected Retour
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PE0145.BL100.UnknownAddressMail"), adresseMailCible_p, noCompteCible_p), null); //$NON-NLS-1$
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100ExpectedResult = new PE0145_BL100_PreparerTransfertContenuBoiteMailReturn(retourExpected);
    bl100ExpectedResult.setIdCompteMailSource(idCompteMailSource_p);

    //Prepare RSTConnector Mock Response for Pfi Source
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail(adresseMailSource_p, 0, 1, null);
    ServiceTechnique serviceTechniqueMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock.setNoCompte(noCompteSource_p);
    serviceTechniqueMock.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMock).setDonneesProvisionneesStPfsMail(donneesProvisionneesSTPfsMail);
    StPfsMail.class.cast(serviceTechniqueMock).getDonneesIdentificationStPfsMail().setIdCompteMail(idCompteMailSource_p);

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Prepare RSTConnector Mock Response for Pfi Cible
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse2 = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "MOCK Error from RSTConnector", null), null); //$NON-NLS-1$

    //Call RSTConnector Mock for Pfi Source
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    //Call RSTConnector Mock for Pfi Cible
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteCible_p, "PFS", "MAIL")).andReturn(rstResponse2); //$NON-NLS-1$ //$NON-NLS-2$

    //Call PE0145_BL100_PreparerTransfertContenuBoiteMail
    PowerMock.replayAll();
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0145_BL100_PreparerTransfertContenuBoiteMail", _tracabilite, clientOperateur_p, noCompteSource_p, adresseMailSource_p, noCompteCible_p, adresseMailCible_p); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(bl100ExpectedResult.getRetour(), bl100Result.getRetour());
    assertEquals(idCompteMailSource_p, bl100Result.getIdCompteMailSource());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. RST returns OK for Pfi Source and Pfi Cible but serviceTechnique returned
   * does not contain any StPfsMail with adresseMail = adresseMailCible<br>
   * <b>Input:</b> adresseMailCible not contained in RSTConnector Response<br>
   * <b>Result:</b> Retour {NOK; CAT-4; MAIL_INCONNU; Mail adresseMailCibleMock non connu pour le Pfi
   * noCompteCibleMock}<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL100_PreparerTransfertContenuBoiteMail_Test_KO_05() throws Exception
  {
    String adresseMailSource_p = "adresseMailSourceMock"; //$NON-NLS-1$
    String noCompteSource_p = "noCompteSourceMock"; //$NON-NLS-1$
    String clientOperateur_p = "clientOperateurMock"; //$NON-NLS-1$
    String noCompteCible_p = "noCompteCibleMock"; //$NON-NLS-1$
    String adresseMailCible_p = "adresseMailCibleMock"; //$NON-NLS-1$

    String idCompteMailSource_p = "idCompteMailSourceMock"; //$NON-NLS-1$

    //Create Expected Retour
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PE0145.BL100.UnknownAddressMail"), adresseMailCible_p, noCompteCible_p), null); //$NON-NLS-1$
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100ExpectedResult = new PE0145_BL100_PreparerTransfertContenuBoiteMailReturn(retourExpected);
    bl100ExpectedResult.setIdCompteMailSource(idCompteMailSource_p);

    //Prepare RSTConnector Mock Response for Pfi Source
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail(adresseMailSource_p, 0, 1, null);

    ServiceTechnique serviceTechniqueMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock.setNoCompte(noCompteSource_p);
    serviceTechniqueMock.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMock).setDonneesProvisionneesStPfsMail(donneesProvisionneesSTPfsMail);
    StPfsMail.class.cast(serviceTechniqueMock).getDonneesIdentificationStPfsMail().setIdCompteMail(idCompteMailSource_p);

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Prepare RSTConnector Mock Response for Pfi Cible
    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse2 = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Call RSTConnector Mock for Pfi Source
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    //Call RSTConnector Mock for Pfi Cible
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteCible_p, "PFS", "MAIL")).andReturn(rstResponse2); //$NON-NLS-1$ //$NON-NLS-2$

    //Call PE0145_BL100_PreparerTransfertContenuBoiteMail
    PowerMock.replayAll();
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0145_BL100_PreparerTransfertContenuBoiteMail", _tracabilite, clientOperateur_p, noCompteSource_p, adresseMailSource_p, noCompteCible_p, adresseMailCible_p); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(bl100ExpectedResult.getRetour(), bl100Result.getRetour());
    assertEquals(idCompteMailSource_p, bl100Result.getIdCompteMailSource());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. RST returns OK for Pfi Source and Pfi Cible but serviceTechique returned
   * by RST does not have statut "ACTIF"<br>
   * <b>Input:</b> ServiceTechnique returned by RSTConnector has statut "RESILIE"<br>
   * <b>Result:</b> Retour {NOK; CAT-4; MAIL_INCONNU; Mail adresseMailCibleMock non activé sur la PFS ROMA.}<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL100_PreparerTransfertContenuBoiteMail_Test_KO_06() throws Exception
  {
    String adresseMailSource_p = "adresseMailSourceMock"; //$NON-NLS-1$
    String noCompteSource_p = "noCompteSourceMock"; //$NON-NLS-1$
    String clientOperateur_p = "clientOperateurMock"; //$NON-NLS-1$
    String noCompteCible_p = "noCompteCibleMock"; //$NON-NLS-1$
    String adresseMailCible_p = "adresseMailCibleMock"; //$NON-NLS-1$

    String idCompteMailSource_p = "idCompteMailSourceMock"; //$NON-NLS-1$
    String idCompteMailCible_p = "idCompteMailCibleMock"; //$NON-NLS-1$

    //Create Expected Retour
    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.MAIL_INCONNU, MessageFormat.format(Messages.getString("PE0145.BL100.InactiveAddressMail"), adresseMailCible_p), null); //$NON-NLS-1$
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100ExpectedResult = new PE0145_BL100_PreparerTransfertContenuBoiteMailReturn(retourExpected);
    bl100ExpectedResult.setIdCompteMailSource(idCompteMailSource_p);

    //Prepare RSTConnector Mock Response for Pfi Source
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail(adresseMailSource_p, 0, 1, null);
    ServiceTechnique serviceTechniqueMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock.setNoCompte(noCompteSource_p);
    serviceTechniqueMock.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMock).setDonneesProvisionneesStPfsMail(donneesProvisionneesSTPfsMail);
    StPfsMail.class.cast(serviceTechniqueMock).getDonneesIdentificationStPfsMail().setIdCompteMail(idCompteMailSource_p);

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Prepare RSTConnector Mock Response for Pfi Cible
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMailCible = new DonneesProvisionneesSTPfsMail(adresseMailCible_p, 0, 1, null);
    ServiceTechnique serviceTechniqueMock2 = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock2.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock2.setNoCompte(noCompteCible_p);
    serviceTechniqueMock2.setStatut(Statut.INACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMock2).setDonneesProvisionneesStPfsMail(donneesProvisionneesSTPfsMailCible);
    StPfsMail.class.cast(serviceTechniqueMock2).getDonneesIdentificationStPfsMail().setIdCompteMail(idCompteMailCible_p);
    List<ServiceTechnique> listServiceTechniqueMock2 = new ArrayList<>();
    listServiceTechniqueMock2.add(serviceTechniqueMock2);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse2 = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock2);

    //Call RSTConnector Mock for Pfi Source
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    //Call RSTConnector Mock for Pfi Cible
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteCible_p, "PFS", "MAIL")).andReturn(rstResponse2); //$NON-NLS-1$ //$NON-NLS-2$

    //Call PE0145_BL100_PreparerTransfertContenuBoiteMail
    PowerMock.replayAll();
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0145_BL100_PreparerTransfertContenuBoiteMail", _tracabilite, clientOperateur_p, noCompteSource_p, adresseMailSource_p, noCompteCible_p, adresseMailCible_p); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(bl100ExpectedResult.getRetour(), bl100Result.getRetour());
    assertEquals(idCompteMailSource_p, bl100Result.getIdCompteMailSource());
  }

  /**
   * <b>Scenario:</b> Tests BL100 nominal case. RST returns OK for Pfi Source. RST returns OK for Pfi Cible<br>
   * <b>Result:</b> Retour {OK; null; null; null}<br>
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL100_PreparerTransfertContenuBoiteMail_Test_OK() throws Exception
  {
    String adresseMailSource_p = "adresseMailSourceMock"; //$NON-NLS-1$
    String noCompteSource_p = "noCompteSourceMock"; //$NON-NLS-1$
    String clientOperateur_p = "clientOperateurMock"; //$NON-NLS-1$
    String noCompteCible_p = "noCompteCibleMock"; //$NON-NLS-1$
    String adresseMailCible_p = "adresseMailCibleMock"; //$NON-NLS-1$

    String idCompteMailSource_p = "idCompteMailSourceMock"; //$NON-NLS-1$
    String idCompteMailCible_p = "idCompteMailCibleMock"; //$NON-NLS-1$

    //Create Expected Retour
    Retour retourExpected = RetourFactoryForTU.createOkRetour();
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100ExpectedResult = new PE0145_BL100_PreparerTransfertContenuBoiteMailReturn(retourExpected);
    bl100ExpectedResult.setIdCompteMailSource(idCompteMailSource_p);
    bl100ExpectedResult.setIdCompteMailCible(idCompteMailCible_p);

    //Prepare RSTConnector Mock Response for Pfi Source
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail(adresseMailSource_p, 0, 1, null);
    ServiceTechnique serviceTechniqueMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock.setNoCompte(noCompteSource_p);
    serviceTechniqueMock.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMock).setDonneesProvisionneesStPfsMail(donneesProvisionneesSTPfsMail);
    StPfsMail.class.cast(serviceTechniqueMock).getDonneesIdentificationStPfsMail().setIdCompteMail(idCompteMailSource_p);

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Prepare RSTConnector Mock Response for Pfi Cible
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMailCible = new DonneesProvisionneesSTPfsMail(adresseMailCible_p, 0, 1, null);
    ServiceTechnique serviceTechniqueCibleMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueCibleMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueCibleMock.setNoCompte(noCompteSource_p);
    serviceTechniqueCibleMock.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueCibleMock).setDonneesProvisionneesStPfsMail(donneesProvisionneesSTPfsMailCible);
    StPfsMail.class.cast(serviceTechniqueCibleMock).getDonneesIdentificationStPfsMail().setIdCompteMail(idCompteMailCible_p);

    List<ServiceTechnique> listServiceTechniqueMock2 = new ArrayList<>();
    listServiceTechniqueMock2.add(serviceTechniqueCibleMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse2 = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock2);

    //Call RSTConnector Mock for Pfi Source
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    //Call RSTConnector Mock for Pfi Cible
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteCible_p, "PFS", "MAIL")).andReturn(rstResponse2); //$NON-NLS-1$ //$NON-NLS-2$

    //Call PE0145_BL100_PreparerTransfertContenuBoiteMail
    PowerMock.replayAll();
    PE0145_BL100_PreparerTransfertContenuBoiteMailReturn bl100Result = Whitebox.invokeMethod(_processInstance, "PE0145_BL100_PreparerTransfertContenuBoiteMail", _tracabilite, clientOperateur_p, noCompteSource_p, adresseMailSource_p, noCompteCible_p, adresseMailCible_p); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(bl100ExpectedResult.getRetour(), bl100Result.getRetour());
    assertEquals(idCompteMailSource_p, bl100Result.getIdCompteMailSource());
    assertEquals(idCompteMailCible_p, bl100Result.getIdCompteMailCible());
  }

  /**
   * <b>Scenario:</b> Tests PE0145_TransfertContenuTransfertBoiteMail non nominal case. BL001 OK. BL100 OK.<br>
   * <b>Input:</b> ServiceTechnique contains null StPfsMail <br>
   * <b>Result:</b> Response {ErrorCode: 404, Result:{"error":"MAIL_INCONNU","error_description":"Mail charles.rock non
   * connu pour le Pfi 3594886"}}<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_TransfertContenuTransfertBoiteMail_Test_KO_01() throws Throwable
  {
    String noCompteSource_p = "3594886"; //$NON-NLS-1$
    String clientOperateur_p = "BSS_GP"; //$NON-NLS-1$
    String noCompteCible_p = "76398756589"; //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, clientOperateur_p);
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "PROCESSUS TAKEOVER"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xSource, xProcess, xRequestId, xMessageId);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);

    //Replicate BL1700
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur_p);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompteCible_p);
    Map<String, String> tracabiliteRefFonc = _tracabilite.getRefFonc();
    tracabiliteRefFonc.putAll(refFonc);
    _tracabilite.setRefFonc(tracabiliteRefFonc);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    //Prepare RSTConnector Mock Response for Pfi Source
    ServiceTechnique serviceTechniqueCibleMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueCibleMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueCibleMock.setNoCompte(noCompteSource_p);
    serviceTechniqueCibleMock.setStatut(Statut.ACTIF.name());

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueCibleMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Call RSTConnector Mock for Pfi Source
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.initializeContext();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals("{\"error\":\"MAIL_INCONNU\",\"error_description\":\"Mail charles.rock non connu pour le Pfi 3594886\"}", response.getGenericResponse().getResult()); //$NON-NLS-1$
  }

  /**
   * <b>Scenario:</b> Tests PE0145_TransfertContenuTransfertBoiteMail non nominal case. BL001 OK. BL100 OK.<br>
   * <b>Input:</b> ServiceTechnique contains null StPfs <br>
   * <b>Result:</b> Response {ErrorCode: 404, Result:{"error":"MAIL_INCONNU","error_description":"Mail charles.rock non
   * connu pour le Pfi 3594886"}}<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_TransfertContenuTransfertBoiteMail_Test_KO_02() throws Throwable
  {
    String noCompteSource = "3594886"; //$NON-NLS-1$
    String clientOperateur = "BSS_GP"; //$NON-NLS-1$
    String noCompteCible = "76398756589"; //$NON-NLS-1$

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, clientOperateur);
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "PROCESSUS TAKEOVER"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xSource, xProcess, xRequestId, xMessageId);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);

    //Replicate BL1700
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompteCible);
    Map<String, String> tracabiliteRefFonc = _tracabilite.getRefFonc();
    tracabiliteRefFonc.putAll(refFonc);
    _tracabilite.setRefFonc(tracabiliteRefFonc);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    //Prepare RSTConnector Mock Response for Pfi Source
    ServiceTechnique serviceTechniqueMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock.setClientOperateur(clientOperateur);
    serviceTechniqueMock.setNoCompte(noCompteSource);
    serviceTechniqueMock.setStatut(Statut.ACTIF.name());

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Call RSTConnector Mock for Pfi Source
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur, noCompteSource, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.initializeContext();
    _processInstance.run(request);
    PowerMock.verify();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.MAIL_INCONNU);
    reponseErreurExpected.setErrorDescription(MessageFormat.format(MESSAGE_MAIL_INCONNU, mailRequest.getIdentifiantAccesSource().getLoginMail(), noCompteSource));

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case for all the process. Assert that validation errors exist.<br>
   * <b>Input:</b> The required field modeTransfert is not set<br>
   * <b>Result:</b> Attribut(s) obligatoire(s) manquant(s): [_modeTransfert]
   *
   * @throws Throwable
   *           on errors
   */
  @Test
  public void PE0145_TransfertContenuTransfertBoiteMail_Test_KO_03() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    fillAllRequestHeaders(request);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$
    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    mailRequest.setModeTransfert(null); //cause validation error

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PowerMock.replayAll();
    _processInstance.initializeContext();
    _processInstance.run(request);
    PowerMock.verify();

    ReponseErreur reponseErreurExpected = new ReponseErreur();
    reponseErreurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    reponseErreurExpected.setErrorDescription(MessageFormat.format(Messages.getString("Validation.RequiredField"), "[_modeTransfert]")); //$NON-NLS-1$ //$NON-NLS-2$

    IRavelResponse response = request.getResponse();

    IRavelResponse ravelResponse = RavelResponseFactory.getInstance().createResponse();
    ravelResponse.setDataType("application/json"); //$NON-NLS-1$
    ravelResponse.setResult(GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSS).toJson(reponseErreurExpected));

    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    assertEquals(ravelResponse.getResult(), response.getGenericResponse().getResult());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case. RST returns KO while getting ST PFS MAIL list for PfiSource<br>
   * <b>Result:</b> Retour {NOK; CAT-4; MAIL_INCONNU; Mail adresseMailSourceMock non connu pour le Pfi
   * noCompteSourceMock}<br>
   *
   * @throws Throwable
   */
  @Test
  public void PE0145_TransfertContenuTransfertBoiteMail_Test_KO_04() throws Throwable
  {
    Retour retourKO = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.PFS_INDISPO, StringConstants.EMPTY_STRING, null);

    String adresseMailSource_p = "charles.rock"; //$NON-NLS-1$
    String noCompteSource_p = "3594886"; //$NON-NLS-1$
    String clientOperateur_p = "BSS_GP"; //$NON-NLS-1$
    String noCompteCible_p = "76398756589"; //$NON-NLS-1$
    String adresseMailCible_p = "bernard.chevallier"; //$NON-NLS-1$

    String idCompteMailSource_p = "idCompteMailSourceMock"; //$NON-NLS-1$
    String idCompteMailCible_p = "idCompteMailCibleMock"; //$NON-NLS-1$

    //ServiceMailTransfertRequest serviceMailTransfertRequest = __podam.manufacturePojo(ServiceMailTransfertRequest.class);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, clientOperateur_p);
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "PROCESSUS TAKEOVER"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xSource, xProcess, xRequestId, xMessageId);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);

    //Replicate BL1700
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur_p);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompteCible_p);
    Map<String, String> tracabiliteRefFonc = _tracabilite.getRefFonc();
    tracabiliteRefFonc.putAll(refFonc);
    _tracabilite.setRefFonc(tracabiliteRefFonc);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    //Prepare RSTConnector Mock Response for Pfi Source
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail(adresseMailSource_p, 0, 1, null);
    donneesProvisionneesSTPfsMail.setIdCompteMailPrincipal(idCompteMailSource_p);

    ServiceTechnique serviceTechniqueMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock.setNoCompte(noCompteSource_p);
    serviceTechniqueMock.setStatut(Statut.ACTIF.name());

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(retourKO, listServiceTechniqueMock);

    //Call RSTConnector Mock for Pfi Source
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    _processInstance.initializeContext();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.KO_00503, response.getErrorCode());
  }

  /**
   * <b>Scenario:</b> Tests PE0145_TransfertContenuTransfertBoiteMail nominal case. BL001 OK. BL100 OK. SI002 OK. BL002
   * OK.<br>
   * <b>Result:</b> Retour {OK; null; null; null}<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_TransfertContenuTransfertBoiteMail_Test_OK() throws Throwable
  {
    Retour ok = RetourFactoryForTU.createOkRetour();

    String adresseMailSource_p = "charles.rock"; //$NON-NLS-1$
    String noCompteSource_p = "3594886"; //$NON-NLS-1$
    String clientOperateur_p = "BSS_GP"; //$NON-NLS-1$
    String noCompteCible_p = "76398756589"; //$NON-NLS-1$
    String adresseMailCible_p = "bernard.chevallier"; //$NON-NLS-1$

    String idCompteMailSource_p = "idCompteMailSourceMock"; //$NON-NLS-1$
    String idCompteMailCible_p = "idCompteMailCibleMock"; //$NON-NLS-1$

    //ServiceMailTransfertRequest serviceMailTransfertRequest = __podam.manufacturePojo(ServiceMailTransfertRequest.class);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, clientOperateur_p);
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "PROCESSUS TAKEOVER"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xSource, xProcess, xRequestId, xMessageId);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);

    //Replicate BL1700
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur_p);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompteCible_p);
    Map<String, String> tracabiliteRefFonc = _tracabilite.getRefFonc();
    tracabiliteRefFonc.putAll(refFonc);
    _tracabilite.setRefFonc(tracabiliteRefFonc);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    //Prepare RSTConnector Mock Response for Pfi Source
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail(adresseMailSource_p, 0, 1, null);
    ServiceTechnique serviceTechniqueMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock.setNoCompte(noCompteSource_p);
    serviceTechniqueMock.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMock).setDonneesProvisionneesStPfsMail(donneesProvisionneesSTPfsMail);
    StPfsMail.class.cast(serviceTechniqueMock).getDonneesIdentificationStPfsMail().setIdCompteMail(idCompteMailSource_p);

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueMock);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Prepare RSTConnector Mock Response for Pfi Cible
    DonneesProvisionneesSTPfsMail donneesProvisionneesSTPfsMailCible = new DonneesProvisionneesSTPfsMail(adresseMailCible_p, 0, 1, null);
    ServiceTechnique serviceTechniqueMockCible = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMockCible.setClientOperateur(clientOperateur_p);
    serviceTechniqueMockCible.setNoCompte(noCompteCible_p);
    serviceTechniqueMockCible.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMockCible).setDonneesProvisionneesStPfsMail(donneesProvisionneesSTPfsMailCible);
    StPfsMail.class.cast(serviceTechniqueMockCible).getDonneesIdentificationStPfsMail().setIdCompteMail(idCompteMailCible_p);

    List<ServiceTechnique> listServiceTechniqueMock2 = new ArrayList<>();
    listServiceTechniqueMock2.add(serviceTechniqueMockCible);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse2 = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock2);

    //Call RSTConnector Mock for Pfi Source
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    //Call RSTConnector Mock for Pfi Cible
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteCible_p, "PFS", "MAIL")).andReturn(rstResponse2); //$NON-NLS-1$ //$NON-NLS-2$

    //Prepare PROV_SI002_LancerOrchestrateur Mock Call and Response
    List<String> noms = new ArrayList<>();
    noms.add("nomDomaine"); //$NON-NLS-1$
    noms.add("adresseMailSource"); //$NON-NLS-1$
    noms.add("idCompteMailSource"); //$NON-NLS-1$
    noms.add("adresseMailCible"); //$NON-NLS-1$
    noms.add("idCompteMailCible"); //$NON-NLS-1$
    noms.add("mode"); //$NON-NLS-1$

    List<String> valeurs = new ArrayList<>();
    valeurs.add("bbox.fr"); //$NON-NLS-1$
    valeurs.add(adresseMailSource_p);
    valeurs.add(idCompteMailSource_p);
    valeurs.add(adresseMailCible_p);
    valeurs.add(idCompteMailCible_p);
    valeurs.add(ServiceMailTransfertRequest.ModeTransfert.COPIE.name());

    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.tracabilite(_tracabilite)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.cles(Collections.emptyList())).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.priorite(10)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.processus("PI0150B_TransfererCopierROMA")).andReturn(_si002BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_si002BuilderMock.noms(noms)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.valeurs(valeurs)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.build()).andReturn(_si002Mock);

    //Call SI002
    EasyMock.expect(_si002Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_si002Mock.getRetour()).andReturn(ok);

    PowerMock.replayAll();
    _processInstance.initializeContext();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    assertEquals("", response.getGenericResponse().getResult()); //$NON-NLS-1$
  }

  /**
   * <b>Scenario:</b> replicate JIRA-972: IdCompteMail Source/Cible Erronée. Plusieures PFS MAIL sources /cibles. <br>
   * <b>Result:</b> Retour {OK; null; null; null}<br>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_TransfertContenuTransfertBoiteMail_Test_OK_02() throws Throwable
  {
    Retour ok = RetourFactoryForTU.createOkRetour();

    String adresseMailSource_p = "charles.rock"; //$NON-NLS-1$
    String noCompteSource_p = "3594886"; //$NON-NLS-1$
    String clientOperateur_p = "BSS_GP"; //$NON-NLS-1$
    String noCompteCible_p = "76398756589"; //$NON-NLS-1$
    String adresseMailCible_p = "bernard.chevallier"; //$NON-NLS-1$

    String idCompteMailSource_p = "idCompteMailSourceMock"; //$NON-NLS-1$
    String idCompteMailCible_p = "idCompteMailCibleMock"; //$NON-NLS-1$

    //ServiceMailTransfertRequest serviceMailTransfertRequest = __podam.manufacturePojo(ServiceMailTransfertRequest.class);
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, clientOperateur_p);
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "PROCESSUS TAKEOVER"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request, xClientOperateur, xSource, xProcess, xRequestId, xMessageId);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);

    //Replicate BL1700
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.CLI_OPE, clientOperateur_p);
    refFonc.put(IRefFoncConstants.NO_COMPTE, noCompteCible_p);
    Map<String, String> tracabiliteRefFonc = _tracabilite.getRefFonc();
    tracabiliteRefFonc.putAll(refFonc);
    _tracabilite.setRefFonc(tracabiliteRefFonc);
    _tracabilite.setIdCorrelationByTel("125667889000877"); //$NON-NLS-1$

    //Prepare RSTConnector Mock Response for Pfi Source
    DonneesProvisionneesSTPfsMail donnesProvisionneesSTPfsMail = new DonneesProvisionneesSTPfsMail(adresseMailSource_p, 0, 1, null);
    ServiceTechnique serviceTechniqueMock = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock.setNoCompte(noCompteSource_p);
    serviceTechniqueMock.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMock).setDonneesProvisionneesStPfsMail(donnesProvisionneesSTPfsMail);
    StPfsMail.class.cast(serviceTechniqueMock).getDonneesIdentificationStPfsMail().setIdCompteMail(idCompteMailSource_p);

    //Build another PFS mail source to replicate ano SPIRIT-972

    DonneesProvisionneesSTPfsMail donnesProvisionneesSTPfsMail2 = new DonneesProvisionneesSTPfsMail("chareles.rock2", 0, 1, null); //$NON-NLS-1$
    ServiceTechnique serviceTechniqueMock2 = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMock2.setClientOperateur(clientOperateur_p);
    serviceTechniqueMock2.setNoCompte("noCompteSrc123");
    serviceTechniqueMock2.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMock2).setDonneesProvisionneesStPfsMail(donnesProvisionneesSTPfsMail2);
    StPfsMail.class.cast(serviceTechniqueMock2).getDonneesIdentificationStPfsMail().setIdCompteMail("xpto123"); //$NON-NLS-1$

    List<ServiceTechnique> listServiceTechniqueMock = new ArrayList<>();
    listServiceTechniqueMock.add(serviceTechniqueMock);
    listServiceTechniqueMock.add(serviceTechniqueMock2);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock);

    //Prepare RSTConnector Mock Response for Pfi Cible
    DonneesProvisionneesSTPfsMail donnesProvisionneesSTPfsMailCible = new DonneesProvisionneesSTPfsMail(adresseMailCible_p, 0, 1, null);
    ServiceTechnique serviceTechniqueMockCible = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMockCible.setClientOperateur(clientOperateur_p);
    serviceTechniqueMockCible.setNoCompte(noCompteCible_p);
    serviceTechniqueMockCible.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMockCible).setDonneesProvisionneesStPfsMail(donnesProvisionneesSTPfsMailCible);
    StPfsMail.class.cast(serviceTechniqueMockCible).getDonneesIdentificationStPfsMail().setIdCompteMail(idCompteMailCible_p);

    //Build another ST PFS MAIL cible  to replicate ano SPIRIT-972
    DonneesProvisionneesSTPfsMail donnesProvisionneesSTPfsMailCible2 = new DonneesProvisionneesSTPfsMail("cible.123", 0, 1, null); //$NON-NLS-1$
    ServiceTechnique serviceTechniqueMockCible2 = _podam.manufacturePojoWithFullData(StPfsMail.class);
    serviceTechniqueMockCible2.setClientOperateur(clientOperateur_p);
    serviceTechniqueMockCible2.setNoCompte("noCompteCible123"); //$NON-NLS-1$
    serviceTechniqueMockCible2.setStatut(Statut.ACTIF.name());
    StPfsMail.class.cast(serviceTechniqueMockCible2).setDonneesProvisionneesStPfsMail(donnesProvisionneesSTPfsMailCible2);
    StPfsMail.class.cast(serviceTechniqueMockCible2).getDonneesIdentificationStPfsMail().setIdCompteMail("idCompteMailCible123"); //$NON-NLS-1$

    List<ServiceTechnique> listServiceTechniqueMock2 = new ArrayList<>();
    listServiceTechniqueMock2.add(serviceTechniqueMockCible);
    listServiceTechniqueMock2.add(serviceTechniqueMockCible2);

    ConnectorResponse<Retour, List<ServiceTechnique>> rstResponse2 = new ConnectorResponse<>(RetourFactoryForTU.createOkRetour(), listServiceTechniqueMock2);

    //Call RSTConnector Mock for Pfi Source
    PowerMock.mockStatic(RSTProxy.class);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteSource_p, "PFS", "MAIL")).andReturn(rstResponse); //$NON-NLS-1$ //$NON-NLS-2$

    //Call RSTConnector Mock for Pfi Cible
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_RSTProxyMock);
    EasyMock.expect(_RSTProxyMock.serviceTechniqueLireTousParPfi(_tracabilite, clientOperateur_p, noCompteCible_p, "PFS", "MAIL")).andReturn(rstResponse2); //$NON-NLS-1$ //$NON-NLS-2$

    //Prepare PROV_SI002_LancerOrchestrateur Mock Call and Response
    List<String> noms = new ArrayList<>();
    noms.add("nomDomaine"); //$NON-NLS-1$
    noms.add("adresseMailSource"); //$NON-NLS-1$
    noms.add("idCompteMailSource"); //$NON-NLS-1$
    noms.add("adresseMailCible"); //$NON-NLS-1$
    noms.add("idCompteMailCible"); //$NON-NLS-1$
    noms.add("mode"); //$NON-NLS-1$

    List<String> valeurs = new ArrayList<>();
    valeurs.add("bbox.fr"); //$NON-NLS-1$
    valeurs.add(adresseMailSource_p);
    valeurs.add(idCompteMailSource_p);
    valeurs.add(adresseMailCible_p);
    valeurs.add(idCompteMailCible_p);
    valeurs.add(ServiceMailTransfertRequest.ModeTransfert.COPIE.name());

    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.tracabilite(_tracabilite)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.cles(Collections.emptyList())).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.priorite(10)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.processus("PI0150B_TransfererCopierROMA")).andReturn(_si002BuilderMock); //$NON-NLS-1$
    EasyMock.expect(_si002BuilderMock.noms(noms)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.valeurs(valeurs)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.build()).andReturn(_si002Mock);

    //Call SI002
    EasyMock.expect(_si002Mock.execute(_processInstance)).andReturn(null);
    EasyMock.expect(_si002Mock.getRetour()).andReturn(ok);

    PowerMock.replayAll();
    _processInstance.initializeContext();
    _processInstance.run(request);
    PowerMock.verify();

    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    assertEquals("", response.getGenericResponse().getResult()); //$NON-NLS-1$
  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PE0145_TransfertContenuBoiteMail();
    _processInstance.initializeContext();

    _processInstance.setMessageId("MSGID123"); //$NON-NLS-1$

    _tracabilite = new Tracabilite();
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setIdCorrelationSpirit(null);
    _tracabilite.setIdCorrelationByTel(StringConstants.EMPTY_STRING);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    PowerMock.resetAll();
    PowerMock.mockStatic(RSTProxy.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessus.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessusBuilder.class);
  }

  /**
   * Builds a valid {@link ServiceMailRequest} object
   *
   * @return {@link ServiceMailRequest}
   */
  private ServiceMailTransfertRequest buildValidServiceMailTransfertRequest()
  {
    ServiceMailTransfertRequest mailRequest = new ServiceMailTransfertRequest();

    ServiceMailTransfertRequest.IdentifiantAcces identifiantAccesSouce = new ServiceMailTransfertRequest.IdentifiantAcces();
    identifiantAccesSouce.setLoginMail("charles.rock"); //$NON-NLS-1$
    mailRequest.setIdentifiantAccesSource(identifiantAccesSouce);

    ServiceMailTransfertRequest.IdentifiantAcces identifiantAccesCible = new ServiceMailTransfertRequest.IdentifiantAcces();
    identifiantAccesCible.setLoginMail("bernard.chevallier"); //$NON-NLS-1$
    mailRequest.setIdentifiantAccesCible(identifiantAccesCible);

    ServiceMailTransfertRequest.PortefeuilleServices portefeuilleSource = new ServiceMailTransfertRequest.PortefeuilleServices();
    portefeuilleSource.setNoCompte("3594886"); //$NON-NLS-1$
    mailRequest.setPortefeuilleServicesSource(portefeuilleSource);
    ServiceMailTransfertRequest.PortefeuilleServices portefeuilleCible = new ServiceMailTransfertRequest.PortefeuilleServices();
    portefeuilleCible.setNoCompte("76398756589"); //$NON-NLS-1$
    mailRequest.setPortefeuilleServicesCible(portefeuilleCible);
    mailRequest.setModeTransfert(ServiceMailTransfertRequest.ModeTransfert.COPIE.name());

    return mailRequest;
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Fills all the request headers
   *
   * @param request_p
   *          The request
   */
  private void fillAllRequestHeaders(Request request_p)
  {
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "msgID123"); //$NON-NLS-1$

    fillRequestHeaders(request_p, xClientOperateur, xSource, xProcess, xRequestId, xMessageId);
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }
}
