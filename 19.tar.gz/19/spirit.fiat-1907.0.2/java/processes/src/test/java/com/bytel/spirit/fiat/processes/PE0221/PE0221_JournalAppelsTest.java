package com.bytel.spirit.fiat.processes.PE0221;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.easymock.Mock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.conf.generated.Param;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL5270_Return;
import com.bytel.spirit.common.connectors.air.AIRProxy;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.ink.generated.Dataset;
import com.bytel.spirit.common.connectors.ink.generated.DatasetParam;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderDataResponse;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderResponse;
import com.bytel.spirit.common.connectors.rpg.RPGProxy;
import com.bytel.spirit.common.connectors.voip.VoipConnectorProxy;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.air.IndexRecherchePfi;
import com.bytel.spirit.common.shared.saab.rpg.PFI;
import com.bytel.spirit.common.shared.saab.rpg.PaTypeVoip;
import com.bytel.spirit.common.shared.saab.rpg.Statut;
import com.bytel.spirit.common.shared.saab.rpg.Titulaire;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0221.structs.PE0221_BL001Return;
import com.bytel.spirit.fiat.processes.PE0221.structs.PE0221_BL002Return;
import com.bytel.spirit.fiat.processes.PE0221.structs.PE0221_GetResponse;
import com.bytel.spirit.fiat.processes.PE0221.structs.PE0221_ReponseFonctionnelle;
import com.bytel.spirit.fiat.processes.PE0221.structs.types.AppelPfs;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author mbaptist
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0221_JournalAppels.class, RPGProxy.class, BL1700_AjouterRefFoncBuilder.class, BL1700_AjouterRefFonc.class, //
    PROV_SI002_ExecuterProcessusBuilder.class, PROV_SI002_ExecuterProcessus.class, AIRProxy.class, BL5270_RecupererPfiParNoTelephone.class, //
    BL5270_RecupererPfiParNoTelephoneBuilder.class, VoipConnectorProxy.class })
public class PE0221_JournalAppelsTest
{
  /**
   *
   */
  private static final String NO_CONTRAT = "noContrat"; //$NON-NLS-1$

  /**
   *
   */
  private static final String NO_COMPTE = "noCompte"; //$NON-NLS-1$

  /**
   *
   */
  private static final String CLIENT_OPERATEUR = "clientOperateur"; //$NON-NLS-1$

  /**
   * The current timestamp
   */
  private static LocalDateTime __now;

  /**
   * method
   */
  private static String _method = "GET"; //$NON-NLS-1$

  /**
  *
  */
  private static final String PE0221_JOURNAL_APPELS = "PE0221_JournalAppels"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * The constant for BL100.TelephoneInvalide message
   */
  private static final String MESSAGE_SERVICE_INDISPO = Messages.getString("PE0221.BL100.ServiceIndisponible"); //$NON-NLS-1$

  /**
   * The constant for BL100.TelephoneInvalide message
   */
  private static final String MESSAGE_INVALID_PHONE_NUMBER = Messages.getString("PE0221.BL100.TelephoneInvalide"); //$NON-NLS-1$

  /**
   * The constant for BL100.TelephoneInvalide message
   */
  private static final String MESSAGE_UNKNOWN_PHONE_NUMBER = Messages.getString("PE0221.BL100.TelephoneInconnu"); //$NON-NLS-1$

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * PROV_SI002_ExecuterProcessusBuilder
   */
  @MockStrict
  PROV_SI002_ExecuterProcessusBuilder _si002_mockbuilder;

  /**
   * PROV_SI002_ExecuterProcessus
   */
  @MockStrict
  PROV_SI002_ExecuterProcessus _si002_mock;

  /**
   * BL1700_AjouterRefFoncBuilder
   */
  @MockStrict
  BL1700_AjouterRefFoncBuilder _bl1700Builder_mock;

  /**
   * BL1700_AjouterRefFonc
   */
  @MockStrict
  BL1700_AjouterRefFonc _bl1700_mock;

  /**
   * Voip Proxy
   */
  @Mock
  private VoipConnectorProxy _voipProxy;

  /**
   * Instance of {@link PE0221_JournalAppels}
   */
  private PE0221_JournalAppels _processInstance;

  /**
   * RPG Proxy
   */
  @MockStrict
  private RPGProxy _rpgProxy;

  /**
   * BL5270_RecupererPfiParNoTelephoneBuilder
   */
  @MockStrict
  private BL5270_RecupererPfiParNoTelephoneBuilder _bl5270RecupererPfiParNoTelephoneBuilder;

  /**
   *
   */
  @MockStrict
  private BL5270_RecupererPfiParNoTelephone _bl5270RecupererPfiParNoTelephone;

  /**
   * AIR Proxy
   */
  @MockStrict
  private AIRProxy _airProxyMock;

  /**
   * Mock de {@Code Tracabilite}
   */
  protected Tracabilite _tracabilite;

  /**
   * @return ReponseFonctionnellePE0221
   */
  public PE0221_ReponseFonctionnelle createReponseFonctionnelePI0222A()
  {
    PE0221_ReponseFonctionnelle reponseFonctionnele = new PE0221_ReponseFonctionnelle();
    List<AppelPfs> listeAppelPfs = new ArrayList<>();
    AppelPfs appelPfsEnAbsence = __podam.manufacturePojo(AppelPfs.class);
    appelPfsEnAbsence.setTypologieAppel("EN_ABSENCE"); //$NON-NLS-1$
    AppelPfs appelPfsEmis = __podam.manufacturePojo(AppelPfs.class);
    appelPfsEmis.setTypologieAppel("SORTANT"); //$NON-NLS-1$
    AppelPfs appelPfsRecu = __podam.manufacturePojo(AppelPfs.class);
    appelPfsRecu.setTypologieAppel("ENTRANT"); //$NON-NLS-1$

    listeAppelPfs.add(appelPfsEnAbsence);
    listeAppelPfs.add(appelPfsEmis);
    listeAppelPfs.add(appelPfsEmis);
    listeAppelPfs.add(appelPfsRecu);
    listeAppelPfs.add(appelPfsRecu);
    listeAppelPfs.add(appelPfsRecu);

    reponseFonctionnele.setResultsCount("6"); //$NON-NLS-1$
    reponseFonctionnele.setItems(listeAppelPfs);

    return reponseFonctionnele;
  }

  /**
   * <b>Scenario:</b> Tests non nominal case.<br>
   * <b>Input:</b> All required headers and fields are set, but not the noTelephone<br>
   * <b>Result:</b> Retour NOK NON_RESPECT_STI. Paramètre noTelephone null ou vide dans la requête
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL001_VerifierDonneesConsultation_Test_KO_01() throws Exception
  {
    String noTelephone = null;
    String idFonctionnelPa_p = null;
    String noCompte = "234432"; //$NON-NLS-1$
    String noJours = "2"; //$NON-NLS-1$
    Integer limit = 1;
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$
    Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "Paramètre [noTelephone] null ou vide dans la requête."); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, noTelephone, _method, idFonctionnelPa_p, noCompte, noJours, limit, clientOperateur);

    EasyMock.expect(LocalDateTime.now()).andReturn(__now);
    EasyMock.expect(__now.minusDays(2)).andReturn(__now);

    PowerMock.replayAll();
    Pair<Retour, PE0221_BL001Return> bl001Retour = Whitebox.invokeMethod(_processInstance, "PE0221_BL001_VerifierDonneesConsultation", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, bl001Retour._first);
    assertNull(bl001Retour._second);
  }

  /**
   * <b>Scenario:</b> Test nominal case.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL001_VerifierDonneesConsultation_Test_OK_01() throws Exception
  {
    String noTelephone = "969878759"; //$NON-NLS-1$
    String idFonctionnelPa = "123124"; //$NON-NLS-1$
    String noCompte = "234432"; //$NON-NLS-1$
    String noJours = "2"; //$NON-NLS-1$
    Integer limit = 1;
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$
    List<String> listeContrat = new ArrayList<>();
    listeContrat.add("10000530160"); //$NON-NLS-1$
    listeContrat.add("10000530150"); //$NON-NLS-1$
    PFI pfi = __podam.manufacturePojo(PFI.class);
    pfi.getPa().get(2).setIdentifiantFonctionnelPA("123124"); //$NON-NLS-1$
    pfi.getPa().get(2).setStatut(Statut.ACTIF);
    pfi.getPa().get(2).setTypePA("VOIP"); //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, _method, idFonctionnelPa, noCompte, noJours, limit, clientOperateur);
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);

    EasyMock.expect(LocalDateTime.now()).andReturn(__now);
    EasyMock.expect(__now.minusDays(2)).andReturn(__now);

    PE0221_BL001Return retourBl001Expected = new PE0221_BL001Return(noTelephone, limit, __now, null, listeContrat);

    PowerMock.replayAll();
    Pair<Retour, PE0221_BL001Return> bl001Retour = Whitebox.invokeMethod(_processInstance, "PE0221_BL001_VerifierDonneesConsultation", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(RetourFactoryForTU.createOkRetour(), bl001Retour._first);
    assertEquals(retourBl001Expected.getLimit(), bl001Retour._second.getLimit());
    assertEquals(noTelephone, bl001Retour._second.getNoTelephone());
    assertEquals(listeContrat, bl001Retour._second.getListeContratOauth());
    assertEquals(IMetadata.CANAL_B2R, bl001Retour._second.getModeAppel());
  }

  /**
   * <b>Scenario:</b> Tests non nominal case.<br>
   * <b>Input:</b> All required headers and fields are set. The parameter retour is NOK<br>
   * <b>Result:</b> Retour NOK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL002_FormaterReponse_Test_KO_1() throws Exception
  {
    Retour retour = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "noTelephone n'est pas de type VOIP"); //$NON-NLS-1$
    Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, "noTelephone n'est pas de type VOIP"); //$NON-NLS-1$

    EasyMock.expect(LocalDateTime.now()).andReturn(__now);
    EasyMock.expect(__now.minusDays(2)).andReturn(__now);

    PowerMock.replayAll();
    Pair<Retour, PE0221_BL002Return> retourBL002 = Whitebox.invokeMethod(_processInstance, "PE0221_BL002_FormaterReponseConsultation", _tracabilite, retour, new PE0221_GetResponse()); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, retourBL002._first);
  }

  /**
   * <b>Scenario:</b> Tests nominal case.<br>
   * <b>Input:</b> All required headers and fields are set. Limit parameter is 2<br>
   * <b>Result:</b> Retour OK
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL002_FormaterReponse_Test_OK() throws Exception
  {
    Retour retour = RetourFactoryForTU.createOkRetour();
    PE0221_GetResponse pe0221GetResponse = new PE0221_GetResponse();
    Retour expected = RetourFactoryForTU.createOkRetour();

    PowerMock.replayAll();
    Pair<Retour, PE0221_BL002Return> retourBL002 = Whitebox.invokeMethod(_processInstance, "PE0221_BL002_FormaterReponseConsultation", _tracabilite, retour, pe0221GetResponse); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, retourBL002._first);
    assertEquals(retourBL002._second.getPe0221RetourGET(), pe0221GetResponse);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case for PE0221_BL100_ConsulterJournauxAppels.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK : typeAcces != FIXE
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL100_ConsulterJournauxAppels_Test_KO_01() throws Exception
  {
    String noTelephone = "+33669878759"; //$NON-NLS-1$
    Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PHONE_NUMBER, noTelephone));

    PowerMock.replayAll();
    Pair<Retour, PE0221_GetResponse> retourBL100 = Whitebox.invokeMethod(_processInstance, "PE0221_BL100_ConsulterJournauxAppels", _tracabilite, new PE0221_BL001Return(noTelephone, 1, __now, null, new ArrayList<>())); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * <b>Scenario:</b> PE0221_BL100_ConsulterJournauxAppels KO because of typeAcces null (wrong number format)<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK :
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL100_ConsulterJournauxAppels_Test_KO_02() throws Exception
  {
    String noTelephone = "969878759"; //$NON-NLS-1$
    Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(MESSAGE_INVALID_PHONE_NUMBER, noTelephone));

    PowerMock.replayAll();
    Pair<Retour, PE0221_GetResponse> retourBL100 = Whitebox.invokeMethod(_processInstance, "PE0221_BL100_ConsulterJournauxAppels", _tracabilite, new PE0221_BL001Return(noTelephone, 1, __now, null, new ArrayList<>())); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * <b>Scenario:</b>PE0221_BL100_ConsulterJournauxAppels KO : BL5270 KO CAT4 DONNEES_INCONNU<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK : returns KO
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL100_ConsulterJournauxAppels_Test_KO_03() throws Exception
  {
    String noTelephone = "+33969878759"; //$NON-NLS-1$
    Retour retourBL5270 = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, "donnee inconnue"); //$NON-NLS-1$

    prepareBL5270_Mock(retourBL5270, noTelephone, null);

    PowerMock.replayAll();
    Pair<Retour, PE0221_GetResponse> retourBL100 = Whitebox.invokeMethod(_processInstance, "PE0221_BL100_ConsulterJournauxAppels", _tracabilite, new PE0221_BL001Return(noTelephone, 1, __now, null, new ArrayList<>())); //$NON-NLS-1$
    PowerMock.verifyAll();

    Retour expected = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_INCONNU, MessageFormat.format(MESSAGE_UNKNOWN_PHONE_NUMBER, noTelephone));
    assertEquals(expected, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * <b>Scenario:</b>PE0221_BL100_ConsulterJournauxAppels KO : modeAppel = B2R and listeContratOauth null<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK : returns KO
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  //  @Test
  public void PE0221_BL100_ConsulterJournauxAppels_Test_KO_04() throws Exception
  {
    String noTelephone = "+33969878759"; //$NON-NLS-1$
    PFI pfi = __podam.manufacturePojo(PFI.class);
    pfi.getPa().get(2).setIdentifiantFonctionnelPA("123124"); //$NON-NLS-1$
    pfi.getPa().get(2).setStatut(Statut.ACTIF);
    pfi.getPa().get(2).setTypePA("VOIP"); //$NON-NLS-1$
    PaTypeVoip paTypeVoip = new PaTypeVoip(noTelephone, pfi.getPa().get(2).getPaTypeVoip().getCodeRio(), pfi.getPa().get(2).getPaTypeVoip().getNumeroPortTelephonique());
    pfi.getPa().get(2).setPaTypeVoip(paTypeVoip);

    List<IndexRecherchePfi> listeIndexRecherchePfi = new ArrayList<>();
    IndexRecherchePfi indexRecherchePfi = __podam.manufacturePojo(IndexRecherchePfi.class);
    listeIndexRecherchePfi.add(indexRecherchePfi);

    Retour retourOK = RetourFactoryForTU.createOkRetour();

    BL5270_Return out = new BL5270_Return();
    out.setClientOperateur(CLIENT_OPERATEUR);
    out.setNoCompte(NO_COMPTE);
    out.setNoContrat(NO_CONTRAT);

    prepareBL5270_Mock(retourOK, noTelephone, out);

    PowerMock.replayAll();
    Pair<Retour, PE0221_GetResponse> retourBL100 = Whitebox.invokeMethod(_processInstance, "PE0221_BL100_ConsulterJournauxAppels", _tracabilite, new PE0221_BL001Return(noTelephone, 1, __now, null, new ArrayList<>())); //$NON-NLS-1$
    PowerMock.verify();

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPO);
    assertEquals(retourExpected, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case for PE0221_BL100_ConsulterJournauxAppels.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK : PROV_SI002 returns KO CAT-1
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL100_ConsulterJournauxAppels_Test_KO_05() throws Exception
  {
    String noTelephone = "+33969878759"; //$NON-NLS-1$
    PFI pfi = __podam.manufacturePojo(PFI.class);
    pfi.getPa().get(2).setIdentifiantFonctionnelPA("123124"); //$NON-NLS-1$
    pfi.getPa().get(2).setStatut(Statut.ACTIF);
    pfi.getPa().get(2).setTypePA("VOIP"); //$NON-NLS-1$
    PaTypeVoip paTypeVoip = new PaTypeVoip(noTelephone, pfi.getPa().get(2).getPaTypeVoip().getCodeRio(), pfi.getPa().get(2).getPaTypeVoip().getNumeroPortTelephonique());
    pfi.getPa().get(2).setPaTypeVoip(paTypeVoip);

    List<IndexRecherchePfi> listeIndexRecherchePfi = new ArrayList<>();
    IndexRecherchePfi indexRecherchePfi = __podam.manufacturePojo(IndexRecherchePfi.class);
    listeIndexRecherchePfi.add(indexRecherchePfi);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourProvSI002 = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegConsts.ERREUR_TECHNIQUE, "ERREUR_TECHNIQUE"); //$NON-NLS-1$
    BL5270_Return out = new BL5270_Return();
    out.setClientOperateur(CLIENT_OPERATEUR);
    out.setNoCompte(NO_COMPTE);
    out.setNoContrat(NO_CONTRAT);

    prepareBL5270_Mock(retourOK, noTelephone, out);
    prepareProv_SI002(retourProvSI002, null, __now);

    PowerMock.replayAll();
    Pair<Retour, PE0221_GetResponse> retourBL100 = Whitebox.invokeMethod(_processInstance, "PE0221_BL100_ConsulterJournauxAppels", _tracabilite, new PE0221_BL001Return(noTelephone, 1, __now, null, new ArrayList<>())); //$NON-NLS-1$
    PowerMock.verify();

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, MESSAGE_SERVICE_INDISPO);
    assertEquals(retourExpected, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case for PE0221_BL100_ConsulterJournauxAppels.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK : PROV_SI002 returns KO CAT-2
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL100_ConsulterJournauxAppels_Test_KO_06() throws Exception
  {
    String noTelephone = "+33969878759"; //$NON-NLS-1$
    PFI pfi = __podam.manufacturePojo(PFI.class);
    pfi.getPa().get(2).setIdentifiantFonctionnelPA("123124"); //$NON-NLS-1$
    pfi.getPa().get(2).setStatut(Statut.ACTIF);
    pfi.getPa().get(2).setTypePA("VOIP"); //$NON-NLS-1$
    PaTypeVoip paTypeVoip = new PaTypeVoip(noTelephone, pfi.getPa().get(2).getPaTypeVoip().getCodeRio(), pfi.getPa().get(2).getPaTypeVoip().getNumeroPortTelephonique());
    pfi.getPa().get(2).setPaTypeVoip(paTypeVoip);

    List<IndexRecherchePfi> listeIndexRecherchePfi = new ArrayList<>();
    IndexRecherchePfi indexRecherchePfi = __podam.manufacturePojo(IndexRecherchePfi.class);
    listeIndexRecherchePfi.add(indexRecherchePfi);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourProvSI002 = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.ERREUR_TECHNIQUE, "ERREUR_TECHNIQUE"); //$NON-NLS-1$

    BL5270_Return out = new BL5270_Return();
    out.setClientOperateur(CLIENT_OPERATEUR);
    out.setNoCompte(NO_COMPTE);
    out.setNoContrat(NO_CONTRAT);

    prepareBL5270_Mock(retourOK, noTelephone, out);
    prepareProv_SI002(retourProvSI002, null, __now);

    PowerMock.replayAll();
    Pair<Retour, PE0221_GetResponse> retourBL100 = Whitebox.invokeMethod(_processInstance, "PE0221_BL100_ConsulterJournauxAppels", _tracabilite, new PE0221_BL001Return(noTelephone, 1, __now, null, new ArrayList<>())); //$NON-NLS-1$
    PowerMock.verify();

    Retour retourExpected = RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, MESSAGE_SERVICE_INDISPO);
    assertEquals(retourExpected, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case for PE0221_BL100_ConsulterJournauxAppels.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK : PROV_SI002 returns KO CAT-3
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL100_ConsulterJournauxAppels_Test_KO_07() throws Exception
  {

    String noTelephone = "+33969878759"; //$NON-NLS-1$
    PFI pfi = __podam.manufacturePojo(PFI.class);
    pfi.getPa().get(2).setIdentifiantFonctionnelPA("123124"); //$NON-NLS-1$
    pfi.getPa().get(2).setStatut(Statut.ACTIF);
    pfi.getPa().get(2).setTypePA("VOIP"); //$NON-NLS-1$
    PaTypeVoip paTypeVoip = new PaTypeVoip(noTelephone, pfi.getPa().get(2).getPaTypeVoip().getCodeRio(), pfi.getPa().get(2).getPaTypeVoip().getNumeroPortTelephonique());
    pfi.getPa().get(2).setPaTypeVoip(paTypeVoip);

    List<IndexRecherchePfi> listeIndexRecherchePfi = new ArrayList<>();
    IndexRecherchePfi indexRecherchePfi = __podam.manufacturePojo(IndexRecherchePfi.class);
    listeIndexRecherchePfi.add(indexRecherchePfi);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourProvSI002 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "ERREUR_TECHNIQUE"); //$NON-NLS-1$

    BL5270_Return out = new BL5270_Return();
    out.setClientOperateur(CLIENT_OPERATEUR);
    out.setNoCompte(NO_COMPTE);
    out.setNoContrat(NO_CONTRAT);

    prepareBL5270_Mock(retourOK, noTelephone, out);
    prepareProv_SI002(retourProvSI002, null, __now);

    PowerMock.replayAll();
    Pair<Retour, PE0221_GetResponse> retourBL100 = Whitebox.invokeMethod(_processInstance, "PE0221_BL100_ConsulterJournauxAppels", _tracabilite, new PE0221_BL001Return(noTelephone, 1, __now, null, new ArrayList<>())); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retourProvSI002, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case for PE0221_BL100_ConsulterJournauxAppels.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK : PROV_SI002 returns KO CAT-3
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL100_ConsulterJournauxAppels_Test_KO_08() throws Exception
  {
    String noTelephone = "+33969878759"; //$NON-NLS-1$
    PFI pfi = __podam.manufacturePojo(PFI.class);
    pfi.getPa().get(2).setIdentifiantFonctionnelPA("123124"); //$NON-NLS-1$
    pfi.getPa().get(2).setStatut(Statut.ACTIF);
    pfi.getPa().get(2).setTypePA("VOIP"); //$NON-NLS-1$
    PaTypeVoip paTypeVoip = new PaTypeVoip(noTelephone, pfi.getPa().get(2).getPaTypeVoip().getCodeRio(), pfi.getPa().get(2).getPaTypeVoip().getNumeroPortTelephonique());
    pfi.getPa().get(2).setPaTypeVoip(paTypeVoip);

    List<IndexRecherchePfi> listeIndexRecherchePfi = new ArrayList<>();
    IndexRecherchePfi indexRecherchePfi = __podam.manufacturePojo(IndexRecherchePfi.class);
    listeIndexRecherchePfi.add(indexRecherchePfi);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    Retour retourProvSI002 = RetourFactoryForTU.createNOK(IMegConsts.CAT3, IMegConsts.ERREUR_TECHNIQUE, "ERREUR_TECHNIQUE"); //$NON-NLS-1$

    BL5270_Return out = new BL5270_Return();
    out.setClientOperateur(CLIENT_OPERATEUR);
    out.setNoCompte(NO_COMPTE);
    out.setNoContrat(NO_CONTRAT);

    prepareBL5270_Mock(retourOK, noTelephone, out);
    prepareProv_SI002(retourProvSI002, null, __now);

    PowerMock.replayAll();
    Pair<Retour, PE0221_GetResponse> retourBL100 = Whitebox.invokeMethod(_processInstance, "PE0221_BL100_ConsulterJournauxAppels", _tracabilite, new PE0221_BL001Return(noTelephone, 1, __now, null, new ArrayList<>())); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retourProvSI002, retourBL100._first);
    assertNull(retourBL100._second);
  }

  /**
   * <b>Scenario:</b> Tests non nominal case for PE0221_BL100_ConsulterJournauxAppels.<br>
   * <b>Input:</b> All required headers and fields are set<br>
   * <b>Result:</b> Retour NOK : PROV_SI002 returns KO CAT-3
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0221_BL100_ConsulterJournauxAppels_Test_OK_01() throws Exception
  {
    String noTelephone = "+33969878759"; //$NON-NLS-1$
    PFI pfi = __podam.manufacturePojo(PFI.class);
    pfi.getPa().get(2).setIdentifiantFonctionnelPA("123124"); //$NON-NLS-1$
    pfi.getPa().get(2).setStatut(Statut.ACTIF);
    pfi.getPa().get(2).setTypePA("VOIP"); //$NON-NLS-1$
    PaTypeVoip paTypeVoip = new PaTypeVoip(noTelephone, pfi.getPa().get(2).getPaTypeVoip().getCodeRio(), pfi.getPa().get(2).getPaTypeVoip().getNumeroPortTelephonique());
    pfi.getPa().get(2).setPaTypeVoip(paTypeVoip);

    IndexRecherchePfi indexRecherchePfi = __podam.manufacturePojo(IndexRecherchePfi.class);
    List<IndexRecherchePfi> listeIndexRecherchePfi = new ArrayList<>();
    listeIndexRecherchePfi.add(indexRecherchePfi);

    Retour retourOK = RetourFactoryForTU.createOkRetour();

    AppelPfs appelPfsEnAbsence = __podam.manufacturePojo(AppelPfs.class);
    appelPfsEnAbsence.setTypologieAppel("EN_ABSENCE"); //$NON-NLS-1$
    AppelPfs appelPfsEmis = __podam.manufacturePojo(AppelPfs.class);
    appelPfsEmis.setTypologieAppel("SORTANT"); //$NON-NLS-1$
    AppelPfs appelPfsRecu = __podam.manufacturePojo(AppelPfs.class);
    appelPfsRecu.setTypologieAppel("ENTRANT"); //$NON-NLS-1$

    List<AppelPfs> listeAppelPfs = new ArrayList<>();
    listeAppelPfs.add(appelPfsEnAbsence);
    listeAppelPfs.add(appelPfsEmis);
    listeAppelPfs.add(appelPfsEmis);
    listeAppelPfs.add(appelPfsRecu);
    listeAppelPfs.add(appelPfsRecu);
    listeAppelPfs.add(appelPfsRecu);

    PE0221_ReponseFonctionnelle PE0221ReponseFonctionnelle = new PE0221_ReponseFonctionnelle();
    PE0221ReponseFonctionnelle.setItems(listeAppelPfs);
    PE0221ReponseFonctionnelle.setResultsCount(String.valueOf(listeAppelPfs.size()));
    ResponseConnector responseConnector = createResponseConnector(PE0221ReponseFonctionnelle);

    BL5270_Return out = new BL5270_Return();
    out.setClientOperateur(CLIENT_OPERATEUR);
    out.setNoCompte(NO_COMPTE);
    out.setNoContrat(NO_CONTRAT);

    prepareBL5270_Mock(retourOK, noTelephone, out);
    prepareProv_SI002(retourOK, responseConnector, __now);

    PowerMock.replayAll();

    Pair<Retour, PE0221_GetResponse> retourBL100 = Whitebox.invokeMethod(_processInstance, "PE0221_BL100_ConsulterJournauxAppels", _tracabilite, new PE0221_BL001Return(noTelephone, 2, __now, null, new ArrayList<>())); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(retourOK, retourBL100._first);
    assertEquals(1, retourBL100._second.getNombreAppelsEnAbsence());
    assertEquals(2, retourBL100._second.getNombreAppelsEmis());
    assertEquals(3, retourBL100._second.getNombreAppelsRecu());
    //    assertEquals(listeAppelPfs, retourBL100._second.getAppels());
  }

  /**
   * BL100_PreparerConsultOptionsAppels_K0 when calling PROV_SI002 (KO Retour)
   *
   * @throws Throwable
   *           exception
   *
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0221_OptionsAppels_Nominal_001() throws Throwable
  {
    // verifier donnés
    String noTelephone = "+33969878759"; //$NON-NLS-1$
    String idFonctionnelPa_p = "123124"; //$NON-NLS-1$
    String noCompte = "234432"; //$NON-NLS-1$
    String noJours = "2"; //$NON-NLS-1$
    Integer limit = 1;
    String clientOperateur = "BSS_ENT"; //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, noTelephone, _method, idFonctionnelPa_p, noCompte, noJours, limit, clientOperateur);

    //fillAllRequestHeaders(request);

    // prepare mocks
    PFI pfi = __podam.manufacturePojo(PFI.class);
    pfi.getPa().get(2).setIdentifiantFonctionnelPA("123124"); //$NON-NLS-1$
    pfi.getPa().get(2).setStatut(Statut.ACTIF);
    pfi.getPa().get(2).setTypePA("VOIP"); //$NON-NLS-1$
    Titulaire titulaire = new Titulaire(pfi.getTitulaire().getTypeTitulaire(), "10000530160", pfi.getTitulaire().getDateCreation(), pfi.getTitulaire().getDateModification()); //$NON-NLS-1$
    pfi.setTitulaire(titulaire);
    PaTypeVoip paTypeVoip = new PaTypeVoip(noTelephone, pfi.getPa().get(2).getPaTypeVoip().getCodeRio(), pfi.getPa().get(2).getPaTypeVoip().getNumeroPortTelephonique());
    pfi.getPa().get(2).setPaTypeVoip(paTypeVoip);

    List<IndexRecherchePfi> listeIndexRecherchePfi = new ArrayList<>();
    IndexRecherchePfi indexRecherchePfi = __podam.manufacturePojo(IndexRecherchePfi.class);
    listeIndexRecherchePfi.add(indexRecherchePfi);

    Retour retourOK = RetourFactoryForTU.createOkRetour();

    EasyMock.expect(LocalDateTime.now()).andReturn(__now);
    EasyMock.expect(__now.minusDays(2)).andReturn(__now);

    List<AppelPfs> listeAppelPfs = new ArrayList<>();
    listeAppelPfs.add(__podam.manufacturePojo(AppelPfs.class));
    listeAppelPfs.add(__podam.manufacturePojo(AppelPfs.class));

    PE0221_ReponseFonctionnelle PE0221ReponseFonctionnelle = new PE0221_ReponseFonctionnelle();
    PE0221ReponseFonctionnelle.setItems(listeAppelPfs);
    PE0221ReponseFonctionnelle.setResultsCount(String.valueOf(listeAppelPfs.size()));
    ResponseConnector responseConnector = createResponseConnector(PE0221ReponseFonctionnelle);

    //Enrichissement objet oTracabilite
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, request.getIdClient());
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, noTelephone);
    _tracabilite.setRefFonc(refFonc);

    BL5270_Return out = new BL5270_Return();
    out.setClientOperateur(CLIENT_OPERATEUR);
    out.setNoCompte(NO_COMPTE);
    out.setNoContrat(NO_CONTRAT);

    prepareBL5270_Mock(retourOK, noTelephone, out);
    prepareProv_SI002(retourOK, responseConnector, __now);

    EasyMock.expect(LocalDateTime.now()).andReturn(__now);
    PowerMock.replayAll();

    Response response = executeStartProcess(request, PE0221_JOURNAL_APPELS);
    //On demande à PowerMock de vérifier la stack d'appel en fonction du scénario
    PowerMock.verify();

    Assert.assertEquals(ErrorCode.OK_00200, response.getErrorCode());

  }

  /**
   * Sets the test
   */
  @Before
  public void setUp()
  {
    _processInstance = new PE0221_JournalAppels();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojoWithFullData(Tracabilite.class);
    _tracabilite.setNomProcessus(StringConstants.EMPTY_STRING);
    _tracabilite.setNomSysteme(null);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());

    ProcessManager.getInstance().getProcessParams().clear();

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();

    PowerMock.mockStaticStrict(LocalDateTime.class);
    PowerMock.mockStatic(BL1700_AjouterRefFoncBuilder.class);
    PowerMock.mockStatic(RPGProxy.class);
    PowerMock.mockStatic(AIRProxy.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessus.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessusBuilder.class);
    PowerMock.mockStatic(BL5270_RecupererPfiParNoTelephone.class);
    PowerMock.mockStatic(BL5270_RecupererPfiParNoTelephoneBuilder.class);
    PowerMock.mockStatic(VoipConnectorProxy.class);

    Param p = new Param();
    p.setName("BL5280_REGEX_MOBILE"); //$NON-NLS-1$
    p.setValue("((\\+336)|((\\+337)[3-9]))[0-9]*"); //$NON-NLS-1$
    ProcessManager.getInstance().getGlobalParameters().getParam().add(p);

    Param p1 = new Param();
    p1.setName("BL5280_REGEX_FIXE"); //$NON-NLS-1$
    p1.setValue("(((\\+33)[1-5])|(\\+339))[0-9]*"); //$NON-NLS-1$
    ProcessManager.getInstance().getGlobalParameters().getParam().add(p1);
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("BSS_ENT"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue("idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$
    requestHeader_p.add(hdr);
  }

  /**
   * Create Response connector
   *
   * @return ResponseConnector
   */
  private ResponseConnector createResponseConnector(PE0221_ReponseFonctionnelle PE0221ReponseFonctionnelle_p)
  {
    com.bytel.spirit.common.connectors.ink.generated.Response response = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector reponseConnector = __podam.manufacturePojo(ResponseConnector.class);
    String result = GsonTools.getGson(DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_ddTHH_colon_mm_colon_ssZ).toJson(PE0221ReponseFonctionnelle_p);
    Dataset dataset = new Dataset();
    List<DatasetParam> listdata = new ArrayList<>();
    DatasetParam datasetparam = new DatasetParam();
    datasetparam.setIndex(1);
    datasetparam.setName("reponseFonctionnelle"); //$NON-NLS-1$
    datasetparam.setValue(result);
    listdata.add(datasetparam);
    dataset.getParams().add(datasetparam);
    ServiceOrderDataResponse serviceData = new ServiceOrderDataResponse();
    serviceData.setDataset(dataset);
    ServiceOrderResponse so = new ServiceOrderResponse();
    so.setSod(serviceData);
    response.setSo(so);
    reponseConnector.setResponse(response);
    return reponseConnector;
  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _processInstance.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * @param retour_p
   *          retour
   * @param noTelephone_p
   *          The telephone number
   * @param out_p
   *          The mocked output
   * @throws Exception
   *           probleme exception
   */
  private void prepareBL5270_Mock(Retour retour_p, String noTelephone_p, BL5270_Return out_p) throws Exception
  {
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270RecupererPfiParNoTelephoneBuilder);
    EasyMock.expect(_bl5270RecupererPfiParNoTelephoneBuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270RecupererPfiParNoTelephoneBuilder);
    EasyMock.expect(_bl5270RecupererPfiParNoTelephoneBuilder.noTelephone(noTelephone_p)).andReturn(_bl5270RecupererPfiParNoTelephoneBuilder);
    EasyMock.expect(_bl5270RecupererPfiParNoTelephoneBuilder.build()).andReturn(_bl5270RecupererPfiParNoTelephone);
    EasyMock.expect(_bl5270RecupererPfiParNoTelephone.execute(_processInstance)).andReturn(out_p);
    EasyMock.expect(_bl5270RecupererPfiParNoTelephone.getRetour()).andReturn(retour_p);
  }

  /**
   * prepareProv_SI002
   *
   * @param retour_p
   *          retour
   * @param reponseConnector_p
   *          reponseconnector
   * @param date_p
   *          date
   * @throws Exception
   *           excetpion
   */
  private void prepareProv_SI002(Retour retour_p, ResponseConnector reponseConnector_p, LocalDateTime date_p) throws Exception
  {
    ListeParametre listeParams = new ListeParametre();
    listeParams.add("noTelephone", "+33969878759"); //$NON-NLS-1$ //$NON-NLS-2$
    String date = null;
    if (date_p != null)
    {
      date = DateTimeTools.DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ.format(date_p);
    }
    listeParams.add("dateDebutRecherche", date); //$NON-NLS-1$

    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.tracabilite(_tracabilite)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.processus("consulterAppelsPfs")).andReturn(_si002_mockbuilder); //$NON-NLS-1$
    EasyMock.expect(_si002_mockbuilder.priorite(10)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.listeParametres(listeParams)).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.build()).andReturn(_si002_mock);
    EasyMock.expect(_si002_mock.execute(_processInstance)).andReturn(reponseConnector_p);
    EasyMock.expect(_si002_mock.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * Create a Generic Request to call PE0221_JournalAppels
   *
   * @param tracabilite_p
   *          tracabilite
   * @param idFonctionnelPa_p
   *          Identifiant fonctionnel to add to the urlParameters
   * @param noCompte_p
   *          The noCompte to add to the urlParameters
   * @param noTelephone_p
   *          The noTelephone to add to the urlParameters
   * @param methode_p
   *          The method
   * @param noJours_p
   *          The noJours to add to the urlParameters
   * @param limit_p
   *          The limite to add to the urlParameters
   * @return GenericRequest to call PE0221_JournalAppels
   * @throws RavelException
   *           on error
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String noTelephone_p, String methode_p, String idFonctionnelPa_p, String noCompte_p, String noJours_p, Integer limit_p, String clientOperateur_p) throws RavelException
  {
    Request request = new Request(PE0221_JOURNAL_APPELS, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    request.setUrlDynamicParameters(noTelephone_p); // Not used

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParams = urlParametersType.getUrlParameters();
    addXHeaders(request.getRequestHeader(), tracabilite_p);
    if (clientOperateur_p != null)
    {
      urlParams.add(new Parameter(CLIENT_OPERATEUR, clientOperateur_p));
    }
    if (idFonctionnelPa_p != null)
    {
      urlParams.add(new Parameter("idFonctionnelPa", idFonctionnelPa_p)); //$NON-NLS-1$
    }
    if (noCompte_p != null)
    {
      urlParams.add(new Parameter(NO_COMPTE, noCompte_p));
    }
    if (noJours_p != null)
    {
      urlParams.add(new Parameter("noJours", noJours_p)); //$NON-NLS-1$
    }
    if (limit_p != null)
    {
      urlParams.add(new Parameter("limite", String.valueOf(limit_p))); //$NON-NLS-1$
    }
    if (noTelephone_p != null)
    {
      urlParams.add(new Parameter("noTelephone", noTelephone_p)); //$NON-NLS-1$
    }
    urlParametersType.setUrlParameters(urlParams);

    request.setUrlParameters(urlParametersType);

    return request;
  }
}
