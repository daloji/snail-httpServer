/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0145;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import com.bytel.spirit.common.shared.types.json.request.ServiceMailRequest;
import com.bytel.spirit.common.shared.types.json.request.ServiceMailTransfertRequest;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.reflect.Whitebox;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.factory.response.IRavelResponse;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.utils.ACManagerUtil;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.PE0145.PE0145_TransfertContenuBoiteMailBouchon.BL001_VerifierDonneesReturn;

/**
 *
 * @author jgregori
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest(PE0145_TransfertContenuBoiteMailBouchon.class)
public class PE0145_TransfertContenuBoiteMailBouchonTest
{
  /**
   * SPRING context
   */
  private static ClassPathXmlApplicationContext __context;

  /**
   * Run before tests
   *
   * @throws Exception
   *           throw exception
   */
  @BeforeClass
  public static void setUpBeforeClass() throws Exception
  {
    ACManagerUtil.resetACManager();
    __context = new ClassPathXmlApplicationContext("classpath:BeansProcessTestMocks.xml"); //$NON-NLS-1$
  }

  /**
   * Tests non nominal case. The required field modeTransfert is not set. Assert that validation errors exist.
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnes_Test_KO_01() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue("BSS_GP"); //$NON-NLS-1$
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue("354545435");
    tracabilite.setIdCorrelationByTel("354545435"); //$NON-NLS-1$
    headers.add(xRequestId);
    RequestHeader source = new RequestHeader();
    source.setName("X-Source"); //$NON-NLS-1$
    source.setValue("source"); //$NON-NLS-1$
    headers.add(source);
    RequestHeader process = new RequestHeader();
    process.setName("X-Process"); //$NON-NLS-1$
    process.setValue("process"); //$NON-NLS-1$
    headers.add(process);
    request.getRequestHeader().addAll(headers);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    mailRequest.setModeTransfert(null); //cause validation error
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PE0145_TransfertContenuBoiteMailBouchon pe0145 = new PE0145_TransfertContenuBoiteMailBouchon();
    pe0145.initializeContext();

    BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(pe0145, "PE0145_BL001_VerifierDonnes", request, tracabilite); //$NON-NLS-1$

    assertEquals(IMegConsts.CAT3, retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, retour.getRetour().getDiagnostic());
    assertEquals("Attribut(s) obligatoire(s) manquant(s): [_modeTransfert]", retour.getRetour().getLibelle()); //$NON-NLS-1$

    assertEquals(xRequestId.getValue(), tracabilite.getIdCorrelationByTel());
    assertEquals(xClientOperateur.getValue(), tracabilite.getRefFonc().get(IRefFoncConstants.CLI_OPE));
  }

  /**
   * Tests non nominal case. The required field portefeuilleServicesSource is not set. Assert that validation errors
   * exist.
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnes_Test_KO_02() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue("BSS_GP"); //$NON-NLS-1$
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue("354545435");
    tracabilite.setIdCorrelationByTel("354545435"); //$NON-NLS-1$
    headers.add(xRequestId);
    RequestHeader source = new RequestHeader();
    source.setName("X-Source"); //$NON-NLS-1$
    source.setValue("source"); //$NON-NLS-1$
    headers.add(source);
    RequestHeader process = new RequestHeader();
    process.setName("X-Process"); //$NON-NLS-1$
    process.setValue("process"); //$NON-NLS-1$
    headers.add(process);
    request.getRequestHeader().addAll(headers);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    mailRequest.setPortefeuilleServicesSource(null); // cause validation error

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PE0145_TransfertContenuBoiteMailBouchon pe0145 = new PE0145_TransfertContenuBoiteMailBouchon();
    pe0145.initializeContext();

    BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(pe0145, "PE0145_BL001_VerifierDonnes", request, tracabilite); //$NON-NLS-1$

    assertEquals(IMegConsts.CAT3, retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, retour.getRetour().getDiagnostic());
    assertEquals("Attribut(s) obligatoire(s) manquant(s): [_portefeuilleServicesSource]", retour.getRetour().getLibelle()); //$NON-NLS-1$

    assertEquals(xRequestId.getValue(), tracabilite.getIdCorrelationByTel());
    assertEquals(xClientOperateur.getValue(), tracabilite.getRefFonc().get(IRefFoncConstants.CLI_OPE));
  }

  /**
   * Tests non nominal case. The field is not set. Assert that validation errors exist.
   *
   * @throws Exception
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0145_BL001_VerifierDonnes_Test_KO_03() throws Exception
  {
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue("BSS_GP"); //$NON-NLS-1$
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue("354545435");
    tracabilite.setIdCorrelationByTel("354545435"); //$NON-NLS-1$
    headers.add(xRequestId);
    RequestHeader source = new RequestHeader();
    source.setName("X-Source"); //$NON-NLS-1$
    source.setValue("source"); //$NON-NLS-1$
    headers.add(source);
    RequestHeader process = new RequestHeader();
    process.setName("X-Process"); //$NON-NLS-1$
    process.setValue("process"); //$NON-NLS-1$
    headers.add(process);
    request.getRequestHeader().addAll(headers);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    mailRequest.getIdentifiantAccesCible().setLoginMail("Charles.rock§"); //$NON-NLS-1$

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PE0145_TransfertContenuBoiteMailBouchon pe0145 = new PE0145_TransfertContenuBoiteMailBouchon();
    pe0145.initializeContext();

    BL001_VerifierDonneesReturn retour = Whitebox.invokeMethod(pe0145, "PE0145_BL001_VerifierDonnes", request, tracabilite); //$NON-NLS-1$

    assertEquals(IMegConsts.CAT3, retour.getRetour().getCategorie());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI, retour.getRetour().getDiagnostic());
    assertEquals("Format d'attribut(s) non respecté(s): [_identifiantAccesCible._loginMail]", retour.getRetour().getLibelle()); //$NON-NLS-1$

    assertEquals(xRequestId.getValue(), tracabilite.getIdCorrelationByTel());
    assertEquals(xClientOperateur.getValue(), tracabilite.getRefFonc().get(IRefFoncConstants.CLI_OPE));
  }

  /**
   * Test PE0145_CreerCommandeTransfertBoiteMail_Test_OK nominal case. Assert that tracabilite is well filled with
   * request headers. Assert that validation is OK. * @throws Throwable
   */
  @Test
  public void PE0145_CreerCommandeTransfertBoiteMail_Test_OK() throws Throwable
  {
    Tracabilite tracabilite = new Tracabilite();
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);

    List<RequestHeader> headers = new ArrayList<>();
    RequestHeader xClientOperateur = new RequestHeader();
    xClientOperateur.setName("X-Client-Operateur"); //$NON-NLS-1$
    xClientOperateur.setValue("BSS_GP"); //$NON-NLS-1$
    headers.add(xClientOperateur);
    RequestHeader xRequestId = new RequestHeader();
    xRequestId.setName("X-Request-Id"); //$NON-NLS-1$
    xRequestId.setValue("354545435"); //$NON-NLS-1$
    tracabilite.setIdCorrelationByTel("354545435"); //$NON-NLS-1$
    headers.add(xRequestId);
    RequestHeader source = new RequestHeader();
    source.setName("X-Source"); //$NON-NLS-1$
    source.setValue("source"); //$NON-NLS-1$
    headers.add(source);
    RequestHeader process = new RequestHeader();
    process.setName("X-Process"); //$NON-NLS-1$
    process.setValue("process"); //$NON-NLS-1$
    headers.add(process);
    request.getRequestHeader().addAll(headers);

    request.setHttpMethod("POST"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$
    ServiceMailTransfertRequest mailRequest = buildValidServiceMailTransfertRequest();
    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(mailRequest, ServiceMailTransfertRequest.class);

    request.setPayload(jSonRequest);
    PE0145_TransfertContenuBoiteMailBouchon pe0145 = new PE0145_TransfertContenuBoiteMailBouchon();
    pe0145.initializeContext();
    pe0145.run(request);
    IRavelResponse response = request.getResponse();

    assertEquals(ErrorCode.OK_00204, response.getErrorCode());
    assertEquals("", response.getGenericResponse().getResult()); //$NON-NLS-1$

  }

  /**
   * Builds a valid {@link ServiceMailRequest} object
   *
   * @return {@link ServiceMailTransfertRequest}
   */
  private ServiceMailTransfertRequest buildValidServiceMailTransfertRequest()
  {
    ServiceMailTransfertRequest mailRequest = new ServiceMailTransfertRequest();

    ServiceMailTransfertRequest.IdentifiantAcces identifiantAccesSouce = new ServiceMailTransfertRequest.IdentifiantAcces();
    identifiantAccesSouce.setLoginMail("charles123!#$%&'*+-/=?^_`.{|}~"); //$NON-NLS-1$
    mailRequest.setIdentifiantAccesSource(identifiantAccesSouce);

    ServiceMailTransfertRequest.IdentifiantAcces identifiantAccesCible = new ServiceMailTransfertRequest.IdentifiantAcces();
    identifiantAccesCible.setLoginMail("bernard123!#$%&'*+-/=?^_`.{|}~"); //$NON-NLS-1$
    mailRequest.setIdentifiantAccesCible(identifiantAccesCible);

    ServiceMailTransfertRequest.PortefeuilleServices portefeuilleSource = new ServiceMailTransfertRequest.PortefeuilleServices();
    portefeuilleSource.setNoCompte("3594886"); //$NON-NLS-1$
    mailRequest.setPortefeuilleServicesSource(portefeuilleSource);
    ServiceMailTransfertRequest.PortefeuilleServices portefeuilleCible = new ServiceMailTransfertRequest.PortefeuilleServices();
    portefeuilleCible.setNoCompte("76398756589"); //$NON-NLS-1$
    mailRequest.setPortefeuilleServicesCible(portefeuilleCible);
    mailRequest.setModeTransfert(ServiceMailTransfertRequest.ModeTransfert.COPIE.name());

    return mailRequest;

  }
}
