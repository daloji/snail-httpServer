/*
 *                                                             ___o.__
 *                                                         ,oH8888888888o._
 *                                                       dP',88888P'''`8888o.
 *   ____                                              ,8',888888      888888o
 *  |  _ \                                            d8,d888888b    ,d8888888b
 *  | |_) | ___  _   _ _   _  __ _ _   _  ___  ___   ,8PPY8888888boo8888PPPP"'`b
 *  |  _ < / _ \| | | | | | |/ _` | | | |/ _ \/ __|  d8o_                     d8
 *  | |_) | (_) | |_| | |_| | (_| | |_| |  __/\__ \' d888bo.             _ooP d8'
 *  |____/ \___/ \__,_|\__, |\__, |\__,_|\___||___/  d8888888P     ,ooo88888P d8
 *                      __/ | ___/_                  `8M8888P     ,88888888P ,8P
 *                     |___/ |__ |  _  |  _  _  _ __  Y88Y88'    ,888888888' dP
 *                               | (/_ | (/_(_ (_)|||  `8b8P    d8888888888,dP
 *                                                      Y8,   d88888888888P'
 *                                                        `Y=8888888888P'
 *                                                            `''`'''
 *
 *  Systeme $system
 *
 *  (C) Copyright Bouygues Telecom 2018.
 *
 *  Utilisation, reproduction et divulgation interdites
 *  sans autorisation ecrite de Bouygues Telecom.
 *
 *  Projet  : 814_837_RessourceMessage
 *  Package : com.bytel.spirit.fiat.processes.PE0275
 *  Classe  : PE0275_RessourceMessagePutTest
 *  Auteur  : sdiop
 *
 */
package com.bytel.spirit.fiat.processes.PE0275;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.activation.DataHandler;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.cxf.attachment.ByteDataSource;
import org.apache.cxf.jaxrs.ext.multipart.AttachmentBuilder;
import org.easymock.EasyMock;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.data.exchange.generated.RavelResponse.ResponseHeader;
import com.bytel.ravel.common.datetime.DateTimeManager;
import com.bytel.ravel.common.encryption.PasswordEncrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.RavelMultipartBody;
import com.bytel.ravel.common.log.LogSeverity;
import com.bytel.ravel.common.log.RavelLogger;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.Mode;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.HttpConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI024_DeposerMessage;
import com.bytel.spirit.common.activities.vmscvm.VMSCVM_SI042_EnvoyerFax;
import com.bytel.spirit.common.shared.functional.types.json.MessagePfsFax;
import com.bytel.spirit.common.shared.functional.types.json.MessagePfsVoix;
import com.bytel.spirit.common.shared.functional.types.json.MessagesPfs;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.log.SpiritLogEvent;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_PostRequest;
import com.bytel.spirit.fiat.processes.PE0275.sti.PE0275_SuiviPost;

import io.netty.util.internal.StringUtil;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author sdiop
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0275_Messages.class, ProcessManager.class, BL1700_AjouterRefFonc.class, BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder.class, VMSCVM_SI024_DeposerMessage.class, VMSCVM_SI024_DeposerMessage.VMSCVM_SI024_DeposerMessageBuilder.class, VMSCVM_SI042_EnvoyerFax.class, VMSCVM_SI042_EnvoyerFax.VMSCVM_SI042_EnvoyerFaxBuilder.class })
public class PE0275_MessagesPostTest
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * The X_REQUEST_ID_VALUE
   */
  private static final String X_REQUEST_ID_VALUE = "125667889000877"; //$NON-NLS-1$

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0275_Messages"; //$NON-NLS-1$

  /**
   * Configuration path Param
   */
  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  private static final String PARAM_FRONT_ADRESSE = "FRONT_ADRESSE";

  private static final byte[] FAX_BYTES = "bytes from fax".getBytes();

  private static final byte[] VOIX_BYTES = "bytes from wav".getBytes();

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    Parameter parameter = new Parameter();

    parameter.setName(name_p);
    parameter.setValue(value_p);

    return parameter;
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());

    try
    {
      DateTimeManager.getInstance().initialize(Mode.FIXED);
      DateTimeManager.getInstance().setFixedClockAt(DateTimeManager.getInstance().now());
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager is now initialized")); //$NON-NLS-1$
    }
    catch (Exception exception)
    {
      RavelLogger.log(new SpiritLogEvent(LogSeverity.DEBUG, "DateTimeManager instance is already initialized")); //$NON-NLS-1$
    }

  }

  /**
   * Mock de {@link ProcessManager}
   */
  @MockStrict
  ProcessManager _processManager;

  /**
   * Instance of {@link PE0275_Messages}
   */
  private PE0275_Messages _processInstance;

  /**
   * No expediteur
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_001() throws Throwable
  {
    final String expediteur = "";
    final String nomExpediteur = "nomExpediteur";
    String idMessageriePFS = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#VOIX#XXX", idMessageriePFS));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "VOIX", idMessagerie, Arrays.asList("dest1", "dest2"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, "audio sample".getBytes(), null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter expediteur is null or empty."); //$NON-NLS-1$

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * No typeMessagerie
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_002() throws Throwable
  {
    final String expediteur = "expediteur";
    final String nomExpediteur = "nomExpediteur";
    String idMessageriePFS = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#VOIX#XXX", idMessageriePFS));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "", idMessagerie, Arrays.asList("dest1", "dest2"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, "audio sample".getBytes(), null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter typeMessagerie is null or empty."); //$NON-NLS-1$

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * No typeMessagerie
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_003() throws Throwable
  {
    final String expediteur = "expediteur";
    final String nomExpediteur = "nomExpediteur";
    String idMessagerie = "";
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "VOIX", idMessagerie, Arrays.asList("dest1", "dest2"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, "audio sample".getBytes(), null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter idMessagerie is null or empty."); //$NON-NLS-1$

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * No destinatairs
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_004() throws Throwable
  {
    final String expediteur = "expediteur";
    final String nomExpediteur = "nomExpediteur";
    String idMessageriePFS = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#VOIX#XXX", idMessageriePFS));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "VOIX", idMessagerie, Collections.emptyList(), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, "audio sample".getBytes(), null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter destinatairs is null or empty."); //$NON-NLS-1$

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * No destinatair
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_005() throws Throwable
  {
    final String expediteur = "expediteur";
    final String nomExpediteur = "nomExpediteur";
    String idMessageriePFS = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#VOIX#XXX", idMessageriePFS));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "VOIX", idMessagerie, Collections.singletonList(""), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, "audio sample".getBytes(), null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter destinatair is null or empty."); //$NON-NLS-1$

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * No streamContenu
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_006() throws Throwable
  {
    final String expediteur = "expediteur";
    final String nomExpediteur = "nomExpediteur";
    String idMessageriePFS = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#VOIX#XXX", idMessageriePFS));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "VOIX", idMessagerie, Collections.singletonList("dest1"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, null, null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter streamContenu is null or empty."); //$NON-NLS-1$

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * No suivi
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_007() throws Throwable
  {
    final String expediteur = "expediteur";
    final String nomExpediteur = "nomExpediteur";
    String idMessageriePFS = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#VOIX#XXX", idMessageriePFS));

    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "VOIX", idMessagerie, Collections.singletonList("dest1"), 2, "emailNotification", "emailcopieFax", null);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, "sanple".getBytes(), null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.KO_PFS);
    responseErreeurExpected.setErrorDescription("Plateforme de service VMS indisponible"); //$NON-NLS-1$

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * No statutLecture
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_008() throws Throwable
  {
    final String expediteur = "expediteur";
    final String nomExpediteur = "nomExpediteur";
    String idMessageriePFS = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#VOIX#XXX", idMessageriePFS));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("---");

    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "VOIX", idMessagerie, Collections.singletonList("dest1"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, "sanple".getBytes(), null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter statutLecture is null or empty."); //$NON-NLS-1$

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * No statutArchivage
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_009() throws Throwable
  {
    final String expediteur = "expediteur";
    final String nomExpediteur = "nomExpediteur";
    String idMessageriePFS = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#VOIX#XXX", idMessageriePFS));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("xxx");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "VOIX", idMessagerie, Collections.singletonList("dest1"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, "sanple".getBytes(), null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter statutArchivage is null or empty."); //$NON-NLS-1$

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * NOk voix
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_010() throws Throwable
  {
    final String expediteur = "expediteur";
    final String nomExpediteur = "nomExpediteur";
    String idMessageriePFS = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#VOIX#XXX", idMessageriePFS));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    MessagePfsVoix messagePfsVoix = new MessagePfsVoix();
    messagePfsVoix.setTypeMessage("VOIX");
    messagePfsVoix.setStatutTransfert("RECEPTION");
    messagePfsVoix.setStatut("RECU");
    messagePfsVoix.setExpediteur(expediteur);
    messagePfsVoix.setNomExpediteur(nomExpediteur);
    messagePfsVoix.setContenu(VOIX_BYTES);

    final Retour nok = RetourFactory.createNOK("nok-on-deposer-message", "", "");
    prepareDeposerMessage(idMessageriePFS, messagePfsVoix, nok);
    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "VOIX", idMessagerie, Arrays.asList("dest1", "dest2"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, "audio sample".getBytes(), null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError("");
    responseErreeurExpected.setErrorDescription(""); //$NON-NLS-1$

    Assert.assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * KO PFS fax
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_011() throws Throwable
  {
    String idMessageriePfs = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#FAX#XXX", idMessageriePfs));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    String dest1 = "dest1";
    PE0275_PostRequest postRequest = new PE0275_PostRequest("expediteur", "nomExpediteur", "Fax", idMessagerie, Arrays.asList(dest1, "dest2"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, null, "audio sample".getBytes()); //$NON-NLS-1$

    prepareProcessParameters();
    MessagePfsFax messagePfsFax = new MessagePfsFax();
    messagePfsFax.setDestinataires(new String[] { dest1 });

    prepareEnvoyerFax(idMessageriePfs, RetourFactory.createOkRetour());
    final Retour nok = RetourFactory.createNOK("nok-on-envoyer-fax", "", "");
    prepareEnvoyerFax(idMessageriePfs, nok);

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError("KO_PFS");
    responseErreeurExpected.setErrorDescription("Echec demande envoi FAX. 1 demande(s) prise(s) en compte sur 2. Consultez la liste des FAX envoyes pour plus d'information."); //$NON-NLS-1$

    Assert.assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * invalid typePfs invalide
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_012() throws Throwable
  {
    String idMessageriePfs = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#xxx#STW", idMessageriePfs));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    String dest1 = "dest1";
    PE0275_PostRequest postRequest = new PE0275_PostRequest("expediteur", "nomExpediteur", "Fax", idMessagerie, Arrays.asList(dest1, "dest2"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, null, "audio sample".getBytes()); //$NON-NLS-1$

    prepareProcessParameters();
    MessagePfsFax messagePfsFax = new MessagePfsFax();
    messagePfsFax.setDestinataires(new String[] { dest1 });

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError("NON_RESPECT_STI");
    responseErreeurExpected.setErrorDescription("Operation non Autorisee sur typePfs=STW"); //$NON-NLS-1$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * typeMessagerie invalide
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_013() throws Throwable
  {
    String idMessageriePfs = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("aaa#%s#xxx#xxx", idMessageriePfs));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    String dest1 = "dest1";
    PE0275_PostRequest postRequest = new PE0275_PostRequest("expediteur", "nomExpediteur", "Fax", idMessagerie, Arrays.asList(dest1, "dest2"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, null, "audio sample".getBytes()); //$NON-NLS-1$

    prepareProcessParameters();
    MessagePfsFax messagePfsFax = new MessagePfsFax();
    messagePfsFax.setDestinataires(new String[] { dest1 });

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError("NON_RESPECT_STI");
    responseErreeurExpected.setErrorDescription("Operation non Autorisee pour le message +123456789 de type xxx."); //$NON-NLS-1$

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * Acces refuse
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_014() throws Throwable
  {
    String idMessageriePfs = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("aaa#%s#FAX#xxx", idMessageriePfs));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    String dest1 = "dest1";
    PE0275_PostRequest postRequest = new PE0275_PostRequest("expediteur", "nomExpediteur", "Fax", idMessagerie, Arrays.asList(dest1, "dest2"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, null, "audio sample".getBytes()); //$NON-NLS-1$
    request.addMetadata(IMetadata.METADATA_CANAL, "B2R");

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);
    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError("ACCES_REFUSE");
    responseErreeurExpected.setErrorDescription("Acces refuse."); //$NON-NLS-1$

    Assert.assertEquals(ErrorCode.KO_00403, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * No data
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_KO_015() throws Throwable
  {
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", null, null, null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    ReponseErreur responseErreeurExpected = new ReponseErreur();
    responseErreeurExpected.setError(IMegSpiritConsts.NON_RESPECT_STI);
    responseErreeurExpected.setErrorDescription("Parameter data is null or empty."); //$NON-NLS-1$

    String resp = response.getGenericResponse().getResult();
    ReponseErreur reponseactual = RavelJsonTools.getInstance().fromJson(resp, ReponseErreur.class);

    Assert.assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    Assert.assertEquals(responseErreeurExpected, reponseactual);
  }

  /**
   * Ok fax
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_OK_001() throws Throwable
  {
    String idMessageriePfs = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#FAX#XXX", idMessageriePfs));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    String dest1 = "dest1";
    PE0275_PostRequest postRequest = new PE0275_PostRequest("expediteur", "nomExpediteur", "Fax", idMessagerie, Arrays.asList(dest1, "dest2"), 2, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, null, "audio sample".getBytes()); //$NON-NLS-1$

    prepareProcessParameters();
    MessagePfsFax messagePfsFax = new MessagePfsFax();
    messagePfsFax.setDestinataires(new String[] { dest1 });

    prepareEnvoyerFax(idMessageriePfs, RetourFactory.createOkRetour());
    prepareEnvoyerFax(idMessageriePfs, RetourFactory.createOkRetour());

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();
    List<ResponseHeader> listResponse = response.getResponseHeader();

    ResponseHeader responseHeader = listResponse.get(0);
    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
    Assert.assertEquals(responseHeader.getName(), "Location");
    Assert.assertEquals(responseHeader.getValue(), "http://localhost:8000/messages/T1Ivr8FTvyKwdFbWoZ2QMaM0MaJXbYzQWs3IcJVhG6s-");

  }

  /**
   * Ok voix
   *
   * @throws Throwable
   *           exception
   * @throws Exception
   *           exception
   */
  @Test
  public void PE0275_Messages_OK_002() throws Throwable
  {
    final String expediteur = "expediteur";
    final String nomExpediteur = "nomExpediteur";
    String idMessageriePFS = "+123456789";
    String idMessagerie = PasswordEncrypter.encryptForURL(String.format("144104#%s#VOIX#XXX", idMessageriePFS));
    PE0275_SuiviPost pe0275_suiviPost = new PE0275_SuiviPost();
    pe0275_suiviPost.setStatutArchivage("NON_ARCHIVE");
    pe0275_suiviPost.setStatutLecture("NON_LU");

    MessagePfsVoix messagePfsVoix = new MessagePfsVoix();
    messagePfsVoix.setTypeMessage("VOIX");
    messagePfsVoix.setStatutTransfert("RECEPTION");
    messagePfsVoix.setStatut("RECU");
    messagePfsVoix.setExpediteur(expediteur);
    messagePfsVoix.setNomExpediteur(nomExpediteur);
    messagePfsVoix.setContenu(VOIX_BYTES);

    prepareDeposerMessage(idMessageriePFS, messagePfsVoix, RetourFactory.createOkRetour());
    PE0275_PostRequest postRequest = new PE0275_PostRequest(expediteur, nomExpediteur, "VOIX", idMessagerie, Arrays.asList("dest1", "dest2"), null, "emailNotification", "emailcopieFax", pe0275_suiviPost);
    Request request = prepareRequest(_tracabilite, HttpConstants.POST_METHOD, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU", postRequest, "audio sample".getBytes(), null); //$NON-NLS-1$

    prepareProcessParameters();

    PowerMock.replayAll();

    fillAllRequestHeaders(request);
    Response response = executeStartProcess(request, DEFAULT_PROCESSNAME);
    PowerMock.verifyAll();

    List<ResponseHeader> listResponse = response.getResponseHeader();

    ResponseHeader responseHeader = listResponse.get(0);
    Assert.assertEquals(ErrorCode.OK_00201, response.getErrorCode());
    Assert.assertEquals(responseHeader.getName(), "Location");
    Assert.assertEquals(responseHeader.getValue(), "http://localhost:8000/messages/T1Ivr8FTvyKwdFbWoZ2QMZWiv6rnCXp30kAQHbSU9mw-");
  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PE0275_Messages();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setNomProcessus(DEFAULT_PROCESSNAME);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(ProcessManager.class);
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   *
   *
   * @param listeContract_p
   *          listeContract
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p, String listeContract_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("ClientOperateur"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
    hdr.setValue("Authorization : bearer XXXX");
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue(listeContract_p);
    requestHeader_p.add(hdr);
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * @param key_p
   *          The key
   * @param value_p
   *          The value
   * @return process params
   */
  private ConcurrentHashMap<String, Map<String, String>> createProcessParams(String key_p, String value_p)
  {
    File classpath = new File(PE0275_MessagesPostTest.class.getResource("/").getFile()); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    if (!StringUtil.isNullOrEmpty(key_p))
    {
      map.put(key_p, classpath + "/" + value_p);
    }

    processParams.put(StringConstants.EMPTY_STRING, map);
    return processParams;
  }

  /**
   * Execute start process.
   *
   * @param request_p
   *          The input request.
   * @param processName_p
   *          The process name.
   * @return The response.
   * @throws Throwable
   *           The throwable.
   */
  private Response executeStartProcess(Request request_p, String processName_p) throws Throwable
  {
    Response ret = null;
    request_p.setOperation(processName_p);
    _processInstance.run(request_p);
    ret = (Response) request_p.getResponse();
    return ret;
  }

  /**
   * Fills all the request headers
   *
   * @param request_p
   *          The request
   */
  private void fillAllRequestHeaders(Request request_p)
  {
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, X_REQUEST_ID_VALUE);
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$
    //RequestHeader xOauth2Idcontracts = createHeader(IHttpHeadersConsts.X_OAUTH2_IDCONTRACTS, "idc=10000530160,idu=20000530160,rol=U;idc=10000530150,idu=10000530180,rol=TU"); //$NON-NLS-1$

    fillRequestHeaders(request_p, xClientOperateur, xRequestId, xSource, xProcess);
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  private void prepareDeposerMessage(String idMessageriePfs_p, MessagesPfs messagesPfs_p, Retour retour_p) throws Exception
  {
    VMSCVM_SI024_DeposerMessage.VMSCVM_SI024_DeposerMessageBuilder builder = PowerMock.createMockAndExpectNew(VMSCVM_SI024_DeposerMessage.VMSCVM_SI024_DeposerMessageBuilder.class);
    VMSCVM_SI024_DeposerMessage bl = PowerMock.createMock(VMSCVM_SI024_DeposerMessage.class);
    EasyMock.expect(builder.messagePfs(messagesPfs_p)).andReturn(builder);
    EasyMock.expect(builder.idMessageriePfs(idMessageriePfs_p)).andReturn(builder);
    EasyMock.expect(builder.tracabilite(EasyMock.anyObject())).andReturn(builder);
    EasyMock.expect(builder.build()).andReturn(bl);
    EasyMock.expect(bl.execute(_processInstance)).andReturn(null);
    EasyMock.expect(bl.getRetour()).andReturn(retour_p);
  }

  private void prepareEnvoyerFax(String idMessageriePfs_p, Retour retour_p) throws Exception
  {
    VMSCVM_SI042_EnvoyerFax.VMSCVM_SI042_EnvoyerFaxBuilder builder = PowerMock.createMockAndExpectNew(VMSCVM_SI042_EnvoyerFax.VMSCVM_SI042_EnvoyerFaxBuilder.class);
    VMSCVM_SI042_EnvoyerFax bl = PowerMock.createMock(VMSCVM_SI042_EnvoyerFax.class);
    EasyMock.expect(builder.idMessagerie(idMessageriePfs_p)).andReturn(builder);
    EasyMock.expect(builder.messagePfs(EasyMock.anyObject())).andReturn(builder);
    EasyMock.expect(builder.tracabilite(EasyMock.anyObject())).andReturn(builder);
    EasyMock.expect(builder.build()).andReturn(bl);

    EasyMock.expect(bl.execute(_processInstance)).andReturn(null);
    EasyMock.expect(bl.getRetour()).andReturn(retour_p);
  }

  private void prepareProcessParameters()
  {

    File classpath = new File(PE0275_MessagesPostTest.class.getResource("/").getFile()); //$NON-NLS-1$

    ConcurrentHashMap<String, Map<String, String>> processParams = new ConcurrentHashMap<>();
    HashMap<String, String> map = new HashMap<>();
    map.put(PARAM_FRONT_ADRESSE, "localhost:8000"); //$NON-NLS-1$
    map.put(PARAM_CONFIG_PATH, classpath + "/" + "ConfigurationPE0275.xml");
    processParams.put(StringConstants.EMPTY_STRING, map);
    EasyMock.expect(ProcessManager.getInstance()).andReturn(_processManager).anyTimes();
    EasyMock.expect(_processManager.getProcessParams()).andReturn(processParams).anyTimes();
  }

  /**
   * prepareGetRequest
   *
   * @param tracabilite_p
   *          tracabilite
   * @param methode_p
   *          method
   * @param listeContact_p
   *          listeContact
   * @return Request
   * @throws RavelException
   *           exception
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String methode_p, String listeContact_p, PE0275_PostRequest data_p, byte[] audio_p, byte[] pdf_p) throws RavelException, IllegalAccessException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    addXHeaders(request.getRequestHeader(), tracabilite_p, listeContact_p);

    RavelMultipartBody multipartBody = new RavelMultipartBody(MediaType.MULTIPART_FORM_DATA_TYPE);
    Object req = FieldUtils.readField(request, "_request", true);
    FieldUtils.writeField(req, "_multipartBody", multipartBody, true);

    if (data_p != null)
    {
      AttachmentBuilder attachmentBuilder = new AttachmentBuilder();
      attachmentBuilder.header("Content-ID", "data");
      String body = RavelJsonTools.getInstance().toJson(data_p, PE0275_PostRequest.class);
      DataHandler dataHandler = new DataHandler(new ByteDataSource(body.getBytes()));
      attachmentBuilder.dataHandler(dataHandler);
      multipartBody.getAttachments().add(attachmentBuilder.build());
    }
    if (audio_p != null)
    {
      AttachmentBuilder attachmentBuilder = new AttachmentBuilder();
      attachmentBuilder.header("Content-ID", "audio");
      DataHandler dataHandler = new DataHandler(new ByteDataSource(VOIX_BYTES));
      attachmentBuilder.dataHandler(dataHandler);
      multipartBody.getAttachments().add(attachmentBuilder.build());
    }
    if (pdf_p != null)
    {
      AttachmentBuilder attachmentBuilder = new AttachmentBuilder();
      attachmentBuilder.header("Content-ID", "fax");
      DataHandler dataHandler = new DataHandler(new ByteDataSource(FAX_BYTES));
      attachmentBuilder.dataHandler(dataHandler);
      multipartBody.getAttachments().add(attachmentBuilder.build());
    }
    return request;
  }
}