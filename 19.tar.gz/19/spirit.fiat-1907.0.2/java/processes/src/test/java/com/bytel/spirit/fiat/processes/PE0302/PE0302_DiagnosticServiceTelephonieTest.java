/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0302;

import static org.junit.Assert.assertEquals;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.RetourFactoryForTU;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.net.http.Response;
import com.bytel.ravel.services.connector.ConnectorResponse;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.ravel.services.utils.Test_Consts;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI026_LireRessourceNoTelephone;
import com.bytel.spirit.common.activities.ossfai.OSSFAI_SI026_LireRessourceNoTelephone.OSSFAI_SI026_LireRessourceNoTelephoneBuilder;
import com.bytel.spirit.common.activities.ossfai.structs.si026.OSSFAI_SI026_Return;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective;
import com.bytel.spirit.common.activities.shared.BL5100_CreerActionCorrective.BL5100_CreerActionCorrectiveBuilder;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL5270_Return;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelle;
import com.bytel.spirit.common.connectors.ink.ReponseFonctionnelleParameterizedType;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.connectors.ink.generated.Dataset;
import com.bytel.spirit.common.connectors.ink.generated.DatasetParam;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderDataResponse;
import com.bytel.spirit.common.connectors.ink.generated.ServiceOrderResponse;
import com.bytel.spirit.common.connectors.rst.RSTProxy;
import com.bytel.spirit.common.shared.functional.types.json.RavelJsonTools;
import com.bytel.spirit.common.shared.functional.types.json.ServiceTechniquePfsPcm;
import com.bytel.spirit.common.shared.functional.types.json.ServiceTechniquePfsSam;
import com.bytel.spirit.common.shared.functional.types.json.TypeUsage;
import com.bytel.spirit.common.shared.functional.types.json.action_corrective.ActionCorrective;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.TypePFS;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.clf.DonneesIdentificationStPfsClf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.clf.DonneesProvisionneesStPfsClf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.clf.StPfsClf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pnf.DonneesIdentificationStPfsPnf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.pnf.StPfsPnf;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.DonneesIdentificationStPfsSam;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.DonneesProvisionneesStPfsSam;
import com.bytel.spirit.common.shared.functional.types.json.st.pfs.sam.StPfsSam;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.common.shared.saab.TypeObjetCommercial;
import com.bytel.spirit.common.shared.saab.rst.ServiceTechnique;
import com.bytel.spirit.common.shared.saab.rst.StLienAllocationCommercial;
import com.bytel.spirit.common.shared.saab.rst.TypeST;
import com.bytel.spirit.fiat.processes.Messages;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author pramos
 * @version ($Revision$ $Date$)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class, OSSFAI_SI026_LireRessourceNoTelephone.class, PE0302_DiagnosticServiceTelephonie.class, RSTProxy.class, PROV_SI002_ExecuterProcessusBuilder.class, PROV_SI002_ExecuterProcessus.class, BL5270_RecupererPfiParNoTelephone.class, BL5270_RecupererPfiParNoTelephoneBuilder.class, BL5100_CreerActionCorrective.class, BL5100_CreerActionCorrectiveBuilder.class })
public class PE0302_DiagnosticServiceTelephonieTest
{

  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * The default process name.
   */
  public static final String DEFAULT_PROCESSNAME = "PE0302_DiagnosticServiceTelephonie"; //$NON-NLS-1$
  /**
   * Configuration path Param
   */
  protected static final String PARAM_CONFIG_PATH = "FILE_PATH"; //$NON-NLS-1$

  /**
   *
   */
  private static final String NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   *
   */
  private static final String SOURCE_DONNEE = "sourceDonnee"; //$NON-NLS-1$

  /**
   *
   */
  private static final String AUDIT = "audit"; //$NON-NLS-1$

  /**
   * Mock de {@Code BL5100_CreerActionCorrective}
   */
  @MockStrict
  protected BL5100_CreerActionCorrective _bl5100Mock;

  /**
   * Mock de {@Code BL5100_CreerActionCorrectiveBuilder}
   */
  @MockStrict
  protected BL5100_CreerActionCorrectiveBuilder _bl5100BuilderMock;

  /**
   * Instance to evaluate
   */
  private PE0302_DiagnosticServiceTelephonie _processInstance;

  /**
   * BL5270_RecupererPfiParNoTelephoneBuilder
   */
  @MockStrict
  private BL5270_RecupererPfiParNoTelephoneBuilder _bl5270BuilderMock;

  /**
   *
   */
  @MockStrict
  private BL5270_RecupererPfiParNoTelephone _bl5270Mock;

  /**
   * RST Proxy
   */
  @MockStrict
  private RSTProxy _rstProxy;

  /**
   * PROV_SI002_ExecuterProcessusBuilder
   */
  @MockStrict
  private PROV_SI002_ExecuterProcessusBuilder _si002_mockbuilder;

  /**
   * PROV_SI002_ExecuterProcessus
   */
  @MockStrict
  private PROV_SI002_ExecuterProcessus _si002_mock;

  /*
   * OSSFAI_SI026_LireRessourceNoTelephoneBuilder
   */
  @MockStrict
  private OSSFAI_SI026_LireRessourceNoTelephoneBuilder _si026_mockbuilder;

  /**
   * OSSFAI_SI026_LireRessourceNoTelephone
   */
  @MockStrict
  private OSSFAI_SI026_LireRessourceNoTelephone _si026_mock;

  /**
   * Test KO Header not set
   *
   * @throws Throwable
   *
   */
  @Test
  public void PE0302_BL001_VerifierDonnees_NOK_001() throws Throwable
  {
    String msg = MessageFormat.format(Messages.getString("Validation.RequiredField"), IHttpHeadersConsts.X_SOURCE);

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xRequestId, xMessageId, xActionId);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"error\":\"NON_RESPECT_STI\",\"error_description\":\"" + msg + "\"}";
    assertEquals(expectedResult, result);

  }

  /**
   * Test KO URL Parameter not set
   *
   * @throws Throwable
   *
   */
  @Test
  public void PE0302_BL001_VerifierDonnees_NOK_002() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"error\":\"NON_RESPECT_STI\",\"error_description\":\"Parameter noTelephone is null or empty.\"}";
    assertEquals(expectedResult, result);

  }

  /**
   * Test KO URL Parameter Source invalid
   *
   * @throws Throwable
   *
   */
  @Test
  public void PE0302_BL001_VerifierDonnees_NOK_003() throws Throwable
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIELXXX, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    String msg = MessageFormat.format(Messages.getString("PE0302.BL001.SourceDonneeInvalide"), sourceDonnee.getValue());

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.KO_00400, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"error\":\"NON_RESPECT_STI\",\"error_description\":\"" + msg + "\"}";
    assertEquals(expectedResult, result);

  }

  /**
   * Test KO : Number Telephone Inconnu
   *
   * @throws Throwable
   *
   */
  @Test
  public void PE0302_BL001_VerifierDonnees_NOK_004() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, null);
    //BL5270_RecupererPfiParNoTelephone mock
    BL5270_Return bl5270Return = new BL5270_Return();
    String clientOp = "CLIENT-OP";//$NON-NLS-1$
    String noCompte = "NoCompte";//$NON-NLS-1$
    String noContrat = "NoContrat";//$NON-NLS-1$
    bl5270Return.setClientOperateur(clientOp);
    bl5270Return.setNoCompte(noCompte);
    bl5270Return.setNoContrat(noContrat);
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(nTel)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(bl5270Return);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retourNOK).anyTimes();

    String msg = MessageFormat.format(Messages.getString("PE0302.BL001.TelephoneIconnu"), noTelephone.getValue());

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.KO_00404, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"error\":\"NO_TELEPHONE_INCONNU\",\"error_description\":\"" + msg + "\"}";
    assertEquals(expectedResult, result);

  }

  /**
   * Test KO : retour KO du RSTProxy.serviceTechniqueLireTousParPfi
   *
   * @throws Throwable
   */
  @Test
  public void PE0302_BL200_ConstruireVueReferentiel_NOK_001() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //BL5270_RecupererPfiParNoTelephone mock
    BL5270_Return bl5270Return = new BL5270_Return();
    String clientOp = "CLIENT-OP";//$NON-NLS-1$
    String noCompte = "NoCompte";//$NON-NLS-1$
    String noContrat = "NoContrat";//$NON-NLS-1$
    bl5270Return.setClientOperateur(clientOp);
    bl5270Return.setNoCompte(noCompte);
    bl5270Return.setNoContrat(noContrat);
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(nTel)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(bl5270Return);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retourOK).anyTimes();

    String niveauRestriction = "RestritionLevel";
    String nomCourt = "NomCourt";
    String codeInsee = "CODEINSEE";
    String optionTaxes = "OPTION_TAXES";
    List<ServiceTechnique> listST = createListServiceTechnique(nTel, nomCourt, codeInsee, niveauRestriction, optionTaxes, "VOIX");

    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INVALIDE, null), listST);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOp), EasyMock.eq(noCompte), EasyMock.eq(null), EasyMock.eq(null))).andReturn(expectedResponse);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.KO_00500, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"error\":\"DONNEE_INVALIDE\"}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);

  }

  /**
   * Test KO : return KO CAT-1 du Prov_SI002<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0302_BL300_ConstruireVuePfs_NOK_001() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //BL5270_RecupererPfiParNoTelephone mock
    BL5270_Return bl5270Return = new BL5270_Return();
    String clientOp = "CLIENT-OP";//$NON-NLS-1$
    String noCompte = "NoCompte";//$NON-NLS-1$
    String noContrat = "NoContrat";//$NON-NLS-1$
    bl5270Return.setClientOperateur(clientOp);
    bl5270Return.setNoCompte(noCompte);
    bl5270Return.setNoContrat(noContrat);
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(nTel)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(bl5270Return);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retourOK).anyTimes();

    String niveauRestriction = "RestritionLevel"; //$NON-NLS-1$
    String nomCourt = "NomCourt"; //$NON-NLS-1$
    String codeInsee = "CODEINSEE"; //$NON-NLS-1$
    String optionTaxes = "OPTION_TAXES";
    List<ServiceTechnique> listST = createListServiceTechnique(nTel, nomCourt, codeInsee, niveauRestriction, optionTaxes, "FAX");

    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourOK, listST);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOp), EasyMock.eq(noCompte), EasyMock.eq(null), EasyMock.eq(null))).andReturn(expectedResponse);

    PowerMock.expectNew(OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.noTelephone(nTel)).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.build()).andReturn(_si026_mock);
    OSSFAI_SI026_Return si026Return = new OSSFAI_SI026_Return("ALLOUE", "1234"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_si026_mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(si026Return);
    EasyMock.expect(_si026_mock.getRetour()).andReturn(retourOK).anyTimes();

    ReponseFonctionnelle<ServiceTechniquePfsSam> pe0302_ReponseFonctionnellePfsSam = new ReponseFonctionnelle();
    List<ServiceTechniquePfsSam> items = new ArrayList<>();
    ServiceTechniquePfsSam stPfsSam = new ServiceTechniquePfsSam();
    stPfsSam.setNiveauRestriction("NONE"); //$NON-NLS-1$
    stPfsSam.setEtatEnregistrement("ETAT_ENR"); //$NON-NLS-1$
    stPfsSam.setImpiFixe("impiFixe"); //$NON-NLS-1$
    stPfsSam.setTypeUsage(TypeUsage.FAX);

    items.add(stPfsSam);
    pe0302_ReponseFonctionnellePfsSam.setItems(items);
    pe0302_ReponseFonctionnellePfsSam.setResultsCount(items.size());
    ResponseConnector responseConnector = createResponseConnector(pe0302_ReponseFonctionnellePfsSam, ServiceTechniquePfsSam.class);
    prepareProv_SI002(RetourFactoryForTU.createNOK(IMegConsts.CAT1, null, null), responseConnector, nTel, "consulterServiceTechniquePfsSam"); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"pfs\":[{\"erreurs\":[{\"error\":\"ERREUR_INTERNE\",\"error_description\":\"Erreur d'appel sur le service en charge de la connexion a la PFS\"}],\"noTelephone\":\"03214467877\",\"typePfs\":\"SAM\"}],\"referentiels\":[{\"etatProvisioning\":\"ECHEC\",\"fax\":{\"impi\":[\"3432423@ims.bouyguestelecom.fr\"],\"impu\":[\"@ims.bouyguestelecom.fr\",\"3432423\"],\"typeReseau\":\"FIXE\"},\"noTelephone\":\"03214467877\",\"ressources\":[{\"etatAllocation\":\"ECHEC\",\"etatRessource\":\"ALLOUE\",\"typeRessource\":\"NUMERO_TELEPHONE\"}],\"typeService\":\"TELEPHONIE\",\"typeUsages\":[\"FAX\"]}]}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);
  }

  /**
   * Test KO : return KO CAT-2 du Prov_SI002<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0302_BL300_ConstruireVuePfs_NOK_002() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //BL5270_RecupererPfiParNoTelephone mock
    BL5270_Return bl5270Return = new BL5270_Return();
    String clientOp = "CLIENT-OP";//$NON-NLS-1$
    String noCompte = "NoCompte";//$NON-NLS-1$
    String noContrat = "NoContrat";//$NON-NLS-1$
    bl5270Return.setClientOperateur(clientOp);
    bl5270Return.setNoCompte(noCompte);
    bl5270Return.setNoContrat(noContrat);
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(nTel)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(bl5270Return);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retourOK).anyTimes();

    String niveauRestriction = "RestritionLevel"; //$NON-NLS-1$
    String nomCourt = "NomCourt"; //$NON-NLS-1$
    String codeInsee = "CODEINSEE"; //$NON-NLS-1$
    String optionTaxes = "OPTION_TAXES";
    List<ServiceTechnique> listST = createListServiceTechnique(nTel, nomCourt, codeInsee, niveauRestriction, optionTaxes, "VOIX");

    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourOK, listST);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOp), EasyMock.eq(noCompte), EasyMock.eq(null), EasyMock.eq(null))).andReturn(expectedResponse);

    PowerMock.expectNew(OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.noTelephone(nTel)).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.build()).andReturn(_si026_mock);
    OSSFAI_SI026_Return si026Return = new OSSFAI_SI026_Return("ALLOUE", "1234"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_si026_mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(si026Return);
    EasyMock.expect(_si026_mock.getRetour()).andReturn(retourOK).anyTimes();

    ReponseFonctionnelle<ServiceTechniquePfsSam> pe0302_ReponseFonctionnellePfsSam = new ReponseFonctionnelle();
    List<ServiceTechniquePfsSam> items = new ArrayList<>();
    ServiceTechniquePfsSam stPfsSam = new ServiceTechniquePfsSam();
    stPfsSam.setNiveauRestriction("NONE"); //$NON-NLS-1$
    stPfsSam.setEtatEnregistrement("ETAT_ENR"); //$NON-NLS-1$
    stPfsSam.setImpiFixe("impiFixe"); //$NON-NLS-1$
    stPfsSam.setTypeUsage(TypeUsage.VOIX);

    items.add(stPfsSam);
    pe0302_ReponseFonctionnellePfsSam.setItems(items);
    pe0302_ReponseFonctionnellePfsSam.setResultsCount(items.size());
    ResponseConnector responseConnector = createResponseConnector(pe0302_ReponseFonctionnellePfsSam, ServiceTechniquePfsSam.class);
    prepareProv_SI002(RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, null), responseConnector, nTel, "consulterServiceTechniquePfsSam"); //$NON-NLS-1$

    ReponseFonctionnelle<ServiceTechniquePfsPcm> reponseFonctionnellePfsPcm = new ReponseFonctionnelle<ServiceTechniquePfsPcm>();
    ServiceTechniquePfsPcm stPfsPcm = new ServiceTechniquePfsPcm();
    stPfsPcm.setNom("HEDER");
    stPfsPcm.setPrenom("ZITO");
    List<ServiceTechniquePfsPcm> listStPfsPcm = new ArrayList<>();
    listStPfsPcm.add(stPfsPcm);
    reponseFonctionnellePfsPcm.setItems(listStPfsPcm);
    reponseFonctionnellePfsPcm.setResultsCount(items.size());
    responseConnector = createResponseConnector(reponseFonctionnellePfsPcm, ServiceTechniquePfsPcm.class);
    prepareProv_SI002(retourOK, responseConnector, nTel, "consulterServiceTechniquePfsPcm"); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"pfs\":[{\"erreurs\":[{\"error\":\"PFS_INDISPONIBLE\",\"error_description\":\"PFS SAM Non Disponible\"}],\"noTelephone\":\"03214467877\",\"typePfs\":\"SAM\"},{\"ligneEnCommunication\":\"LIBRE\",\"noTelephone\":\"03214467877\",\"nom\":\"HEDER\",\"prenom\":\"ZITO\",\"typePfs\":\"PCM\"}],\"referentiels\":[{\"etatProvisioning\":\"ECHEC\",\"noTelephone\":\"03214467877\",\"ressources\":[{\"etatAllocation\":\"ECHEC\",\"etatRessource\":\"ALLOUE\",\"typeRessource\":\"NUMERO_TELEPHONE\"}],\"typeService\":\"TELEPHONIE\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"codeINSEE\":\"CODEINSEE\",\"impi\":[\"3432423@ims.bouyguestelecom.fr\"],\"impu\":[\"@ims.bouyguestelecom.fr\",\"3432423\"],\"niveauRestriction\":\"RestritionLevel\",\"nom\":\"ZITO\",\"nomPrenomCourt\":\"NomCourt\",\"optionAppelSurTaxes\":\"OPTION_TAXES\",\"prenom\":\"HEDER\",\"statut\":\"RESTREINT\",\"typeReseau\":\"FIXE\"}}]}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);
  }

  /**
   * Test KO : return KO CAT-4 du Prov_SI002<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0302_BL300_ConstruireVuePfs_NOK_003() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //BL5270_RecupererPfiParNoTelephone mock
    BL5270_Return bl5270Return = new BL5270_Return();
    String clientOp = "CLIENT-OP";//$NON-NLS-1$
    String noCompte = "NoCompte";//$NON-NLS-1$
    String noContrat = "NoContrat";//$NON-NLS-1$
    bl5270Return.setClientOperateur(clientOp);
    bl5270Return.setNoCompte(noCompte);
    bl5270Return.setNoContrat(noContrat);
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(nTel)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(bl5270Return);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retourOK).anyTimes();

    String niveauRestriction = "RestritionLevel"; //$NON-NLS-1$
    String nomCourt = "NomCourt"; //$NON-NLS-1$
    String codeInsee = "CODEINSEE"; //$NON-NLS-1$
    String optionTaxes = "OPTION_TAXES";
    List<ServiceTechnique> listST = createListServiceTechnique(nTel, nomCourt, codeInsee, niveauRestriction, optionTaxes, "VOIX");

    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourOK, listST);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOp), EasyMock.eq(noCompte), EasyMock.eq(null), EasyMock.eq(null))).andReturn(expectedResponse);

    PowerMock.expectNew(OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.noTelephone(nTel)).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.build()).andReturn(_si026_mock);
    OSSFAI_SI026_Return si026Return = new OSSFAI_SI026_Return("ALLOUE", "1234"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_si026_mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(si026Return);
    EasyMock.expect(_si026_mock.getRetour()).andReturn(retourOK).anyTimes();

    ReponseFonctionnelle<ServiceTechniquePfsSam> pe0302_ReponseFonctionnellePfsSam = new ReponseFonctionnelle();
    List<ServiceTechniquePfsSam> items = new ArrayList<>();
    ServiceTechniquePfsSam stPfsSam = new ServiceTechniquePfsSam();
    stPfsSam.setNiveauRestriction("NONE"); //$NON-NLS-1$
    stPfsSam.setEtatEnregistrement("ETAT_ENR"); //$NON-NLS-1$
    stPfsSam.setImpiFixe("impiFixe"); //$NON-NLS-1$
    stPfsSam.setTypeUsage(TypeUsage.VOIX);

    items.add(stPfsSam);
    pe0302_ReponseFonctionnellePfsSam.setItems(items);
    pe0302_ReponseFonctionnellePfsSam.setResultsCount(items.size());
    ResponseConnector responseConnector = createResponseConnector(pe0302_ReponseFonctionnellePfsSam, ServiceTechniquePfsSam.class);
    prepareProv_SI002(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, null), responseConnector, nTel, "consulterServiceTechniquePfsSam"); //$NON-NLS-1$

    ReponseFonctionnelle<ServiceTechniquePfsPcm> reponseFonctionnellePfsPcm = new ReponseFonctionnelle<ServiceTechniquePfsPcm>();
    ServiceTechniquePfsPcm stPfsPcm = new ServiceTechniquePfsPcm();
    stPfsPcm.setNom("HEDER");
    stPfsPcm.setPrenom("ZITO");
    List<ServiceTechniquePfsPcm> listStPfsPcm = new ArrayList<>();
    listStPfsPcm.add(stPfsPcm);
    reponseFonctionnellePfsPcm.setItems(listStPfsPcm);
    reponseFonctionnellePfsPcm.setResultsCount(items.size());
    responseConnector = createResponseConnector(reponseFonctionnellePfsPcm, ServiceTechniquePfsPcm.class);
    prepareProv_SI002(retourOK, responseConnector, nTel, "consulterServiceTechniquePfsPcm"); //$NON-NLS-1$

    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.idExterne(EasyMock.anyString())).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.actionCorrective(EasyMock.anyObject(ActionCorrective.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.build()).andReturn(_bl5100Mock);
    String idActionCorrective = "101010"; //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(idActionCorrective);
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(retourOK).anyTimes();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"idActionCorrective\":\"101010\",\"pfs\":[{\"audits\":[{\"diagnostic\":\"SERVICE_NON_PROVISIONNE\",\"libelle\":\"Service non provisionne sur la PFS \"}],\"noTelephone\":\"03214467877\",\"typePfs\":\"SAM\"},{\"ligneEnCommunication\":\"LIBRE\",\"noTelephone\":\"03214467877\",\"nom\":\"HEDER\",\"prenom\":\"ZITO\",\"typePfs\":\"PCM\"}],\"referentiels\":[{\"etatProvisioning\":\"ECHEC\",\"noTelephone\":\"03214467877\",\"ressources\":[{\"etatAllocation\":\"ECHEC\",\"etatRessource\":\"ALLOUE\",\"typeRessource\":\"NUMERO_TELEPHONE\"}],\"typeService\":\"TELEPHONIE\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"codeINSEE\":\"CODEINSEE\",\"impi\":[\"3432423@ims.bouyguestelecom.fr\"],\"impu\":[\"@ims.bouyguestelecom.fr\",\"3432423\"],\"niveauRestriction\":\"RestritionLevel\",\"nom\":\"ZITO\",\"nomPrenomCourt\":\"NomCourt\",\"optionAppelSurTaxes\":\"OPTION_TAXES\",\"prenom\":\"HEDER\",\"statut\":\"RESTREINT\",\"typeReseau\":\"FIXE\"}}]}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);
  }

  /**
   * Test KO : return KO CAT-1 du Prov_SI002 PCM<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0302_BL300_ConstruireVuePfs_NOK_006() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //BL5270_RecupererPfiParNoTelephone mock
    BL5270_Return bl5270Return = new BL5270_Return();
    String clientOp = "CLIENT-OP";//$NON-NLS-1$
    String noCompte = "NoCompte";//$NON-NLS-1$
    String noContrat = "NoContrat";//$NON-NLS-1$
    bl5270Return.setClientOperateur(clientOp);
    bl5270Return.setNoCompte(noCompte);
    bl5270Return.setNoContrat(noContrat);
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(nTel)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(bl5270Return);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retourOK).anyTimes();

    String niveauRestriction = "RestritionLevel"; //$NON-NLS-1$
    String nomCourt = "NomCourt"; //$NON-NLS-1$
    String codeInsee = "CODEINSEE"; //$NON-NLS-1$
    String optionTaxes = "OPTION_TAXES";
    List<ServiceTechnique> listST = createListServiceTechnique(nTel, nomCourt, codeInsee, niveauRestriction, optionTaxes, "VOIX");

    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourOK, listST);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOp), EasyMock.eq(noCompte), EasyMock.eq(null), EasyMock.eq(null))).andReturn(expectedResponse);

    PowerMock.expectNew(OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.noTelephone(nTel)).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.build()).andReturn(_si026_mock);
    OSSFAI_SI026_Return si026Return = new OSSFAI_SI026_Return("ALLOUE", "1234"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_si026_mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(si026Return);
    EasyMock.expect(_si026_mock.getRetour()).andReturn(retourOK).anyTimes();

    ReponseFonctionnelle<ServiceTechniquePfsSam> pe0302_ReponseFonctionnellePfsSam = new ReponseFonctionnelle<ServiceTechniquePfsSam>();
    List<ServiceTechniquePfsSam> items = new ArrayList<>();
    ServiceTechniquePfsSam stPfsSam = new ServiceTechniquePfsSam();
    stPfsSam.setNiveauRestriction("NONE"); //$NON-NLS-1$
    stPfsSam.setEtatEnregistrement("ETAT_ENR"); //$NON-NLS-1$
    stPfsSam.setImpiFixe("impiFixe"); //$NON-NLS-1$
    stPfsSam.setTypeUsage(TypeUsage.VOIX);

    items.add(stPfsSam);
    pe0302_ReponseFonctionnellePfsSam.setItems(items);
    pe0302_ReponseFonctionnellePfsSam.setResultsCount(items.size());
    ResponseConnector responseConnector = createResponseConnector(pe0302_ReponseFonctionnellePfsSam, ServiceTechniquePfsSam.class);
    prepareProv_SI002(retourOK, responseConnector, nTel, "consulterServiceTechniquePfsSam"); //$NON-NLS-1$

    ReponseFonctionnelle<ServiceTechniquePfsPcm> reponseFonctionnellePfsPcm = new ReponseFonctionnelle<ServiceTechniquePfsPcm>();
    ServiceTechniquePfsPcm stPfsPcm = new ServiceTechniquePfsPcm();
    stPfsPcm.setNom("HEDER"); //$NON-NLS-1$
    List<ServiceTechniquePfsPcm> listStPfsPcm = new ArrayList<>();
    listStPfsPcm.add(stPfsPcm);
    reponseFonctionnellePfsPcm.setItems(listStPfsPcm);
    reponseFonctionnellePfsPcm.setResultsCount(listStPfsPcm.size());
    responseConnector = createResponseConnector(reponseFonctionnellePfsPcm, ServiceTechniquePfsPcm.class);
    prepareProv_SI002(RetourFactoryForTU.createNOK(IMegConsts.CAT1, null, null), responseConnector, nTel, "consulterServiceTechniquePfsPcm"); //$NON-NLS-1$

    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.idExterne(EasyMock.anyString())).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.actionCorrective(EasyMock.anyObject(ActionCorrective.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.build()).andReturn(_bl5100Mock);
    String idActionCorrective = "101010"; //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(idActionCorrective);
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(retourOK).anyTimes();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"idActionCorrective\":\"101010\",\"pfs\":[{\"audits\":[{\"diagnostic\":\"DESYNCHRO_PFS\",\"libelle\":\"Désynchronisation sur les paramètres du service Telephonie\",\"parameters\":[\"niveauRestriction\"]}],\"noTelephone\":\"03214467877\",\"typePfs\":\"SAM\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"etatEnregistrement\":\"ETAT_ENR\",\"impi\":[\"impiFixe\"],\"niveauRestriction\":\"NONE\",\"statut\":\"RESTREINT\"}},{\"erreurs\":[{\"error\":\"ERREUR_INTERNE\",\"error_description\":\"Erreur d'appel sur le service en charge de la connexion a la PFS\"}],\"noTelephone\":\"03214467877\",\"typePfs\":\"PCM\"}],\"referentiels\":[{\"etatProvisioning\":\"ECHEC\",\"noTelephone\":\"03214467877\",\"ressources\":[{\"etatAllocation\":\"ECHEC\",\"etatRessource\":\"ALLOUE\",\"typeRessource\":\"NUMERO_TELEPHONE\"}],\"typeService\":\"TELEPHONIE\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"codeINSEE\":\"CODEINSEE\",\"impi\":[\"3432423@ims.bouyguestelecom.fr\"],\"impu\":[\"@ims.bouyguestelecom.fr\",\"3432423\"],\"niveauRestriction\":\"RestritionLevel\",\"nom\":\"ZITO\",\"nomPrenomCourt\":\"NomCourt\",\"optionAppelSurTaxes\":\"OPTION_TAXES\",\"prenom\":\"HEDER\",\"statut\":\"RESTREINT\",\"typeReseau\":\"FIXE\"}}]}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);
  }

  /**
   * Test KO : return KO CAT-2 du Prov_SI002 PCM<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0302_BL300_ConstruireVuePfs_NOK_007() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //BL5270_RecupererPfiParNoTelephone mock
    BL5270_Return bl5270Return = new BL5270_Return();
    String clientOp = "CLIENT-OP";//$NON-NLS-1$
    String noCompte = "NoCompte";//$NON-NLS-1$
    String noContrat = "NoContrat";//$NON-NLS-1$
    bl5270Return.setClientOperateur(clientOp);
    bl5270Return.setNoCompte(noCompte);
    bl5270Return.setNoContrat(noContrat);
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(nTel)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(bl5270Return);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retourOK).anyTimes();

    String niveauRestriction = "RestritionLevel"; //$NON-NLS-1$
    String nomCourt = "NomCourt"; //$NON-NLS-1$
    String codeInsee = "CODEINSEE"; //$NON-NLS-1$
    String optionTaxes = "OPTION_TAXES"; //$NON-NLS-1$
    List<ServiceTechnique> listST = createListServiceTechnique(nTel, nomCourt, codeInsee, niveauRestriction, optionTaxes, "VOIX");

    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourOK, listST);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOp), EasyMock.eq(noCompte), EasyMock.eq(null), EasyMock.eq(null))).andReturn(expectedResponse);

    PowerMock.expectNew(OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.noTelephone(nTel)).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.build()).andReturn(_si026_mock);
    OSSFAI_SI026_Return si026Return = new OSSFAI_SI026_Return("ALLOUE", "1234"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_si026_mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(si026Return);
    EasyMock.expect(_si026_mock.getRetour()).andReturn(retourOK).anyTimes();

    ReponseFonctionnelle<ServiceTechniquePfsSam> pe0302_ReponseFonctionnellePfsSam = new ReponseFonctionnelle();
    List<ServiceTechniquePfsSam> items = new ArrayList<>();
    ServiceTechniquePfsSam stPfsSam = new ServiceTechniquePfsSam();
    stPfsSam.setNiveauRestriction("NONE"); //$NON-NLS-1$
    stPfsSam.setEtatEnregistrement("ETAT_ENR"); //$NON-NLS-1$
    stPfsSam.setImpiFixe("impiFixe"); //$NON-NLS-1$
    stPfsSam.setTypeUsage(TypeUsage.VOIX);

    items.add(stPfsSam);
    pe0302_ReponseFonctionnellePfsSam.setItems(items);
    pe0302_ReponseFonctionnellePfsSam.setResultsCount(items.size());
    ResponseConnector responseConnector = createResponseConnector(pe0302_ReponseFonctionnellePfsSam, ServiceTechniquePfsSam.class);
    prepareProv_SI002(retourOK, responseConnector, nTel, "consulterServiceTechniquePfsSam"); //$NON-NLS-1$

    ReponseFonctionnelle<ServiceTechniquePfsPcm> reponseFonctionnellePfsPcm = new ReponseFonctionnelle<ServiceTechniquePfsPcm>();
    ServiceTechniquePfsPcm stPfsPcm = new ServiceTechniquePfsPcm();
    stPfsPcm.setNom("HEDER"); //$NON-NLS-1$
    List<ServiceTechniquePfsPcm> listStPfsPcm = new ArrayList<>();
    listStPfsPcm.add(stPfsPcm);
    reponseFonctionnellePfsPcm.setItems(listStPfsPcm);
    reponseFonctionnellePfsPcm.setResultsCount(listStPfsPcm.size());
    responseConnector = createResponseConnector(reponseFonctionnellePfsPcm, ServiceTechniquePfsPcm.class);
    prepareProv_SI002(RetourFactoryForTU.createNOK(IMegConsts.CAT2, IMegConsts.SERVICE_TIERS_INDISPONIBLE, null), responseConnector, nTel, "consulterServiceTechniquePfsPcm"); //$NON-NLS-1$

    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.idExterne(EasyMock.anyString())).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.actionCorrective(EasyMock.anyObject(ActionCorrective.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.build()).andReturn(_bl5100Mock);
    String idActionCorrective = "101010"; //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(idActionCorrective);
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(retourOK).anyTimes();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"idActionCorrective\":\"101010\",\"pfs\":[{\"audits\":[{\"diagnostic\":\"DESYNCHRO_PFS\",\"libelle\":\"Désynchronisation sur les paramètres du service Telephonie\",\"parameters\":[\"niveauRestriction\"]}],\"noTelephone\":\"03214467877\",\"typePfs\":\"SAM\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"etatEnregistrement\":\"ETAT_ENR\",\"impi\":[\"impiFixe\"],\"niveauRestriction\":\"NONE\",\"statut\":\"RESTREINT\"}},{\"erreurs\":[{\"error\":\"PFS_INDISPONIBLE\",\"error_description\":\"PFS PCM Non Disponible\"}],\"noTelephone\":\"03214467877\",\"typePfs\":\"PCM\"}],\"referentiels\":[{\"etatProvisioning\":\"ECHEC\",\"noTelephone\":\"03214467877\",\"ressources\":[{\"etatAllocation\":\"ECHEC\",\"etatRessource\":\"ALLOUE\",\"typeRessource\":\"NUMERO_TELEPHONE\"}],\"typeService\":\"TELEPHONIE\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"codeINSEE\":\"CODEINSEE\",\"impi\":[\"3432423@ims.bouyguestelecom.fr\"],\"impu\":[\"@ims.bouyguestelecom.fr\",\"3432423\"],\"niveauRestriction\":\"RestritionLevel\",\"nom\":\"ZITO\",\"nomPrenomCourt\":\"NomCourt\",\"optionAppelSurTaxes\":\"OPTION_TAXES\",\"prenom\":\"HEDER\",\"statut\":\"RESTREINT\",\"typeReseau\":\"FIXE\"}}]}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);
  }

  /**
   * Test KO : return KO CAT-4 du Prov_SI002 PCM<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0302_BL300_ConstruireVuePfs_NOK_008() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //BL5270_RecupererPfiParNoTelephone mock
    BL5270_Return bl5270Return = new BL5270_Return();
    String clientOp = "CLIENT-OP";//$NON-NLS-1$
    String noCompte = "NoCompte";//$NON-NLS-1$
    String noContrat = "NoContrat";//$NON-NLS-1$
    bl5270Return.setClientOperateur(clientOp);
    bl5270Return.setNoCompte(noCompte);
    bl5270Return.setNoContrat(noContrat);
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(nTel)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(bl5270Return);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retourOK).anyTimes();

    String niveauRestriction = "RestritionLevel"; //$NON-NLS-1$
    String nomCourt = "NomCourt"; //$NON-NLS-1$
    String codeInsee = "CODEINSEE"; //$NON-NLS-1$
    String optionTaxes = "OPTION_TAXES"; //$NON-NLS-1$
    List<ServiceTechnique> listST = createListServiceTechnique(nTel, nomCourt, codeInsee, niveauRestriction, optionTaxes, "VOIX");

    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourOK, listST);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOp), EasyMock.eq(noCompte), EasyMock.eq(null), EasyMock.eq(null))).andReturn(expectedResponse);

    PowerMock.expectNew(OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.noTelephone(nTel)).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.build()).andReturn(_si026_mock);
    OSSFAI_SI026_Return si026Return = new OSSFAI_SI026_Return("ALLOUE", "1234"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_si026_mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(si026Return);
    EasyMock.expect(_si026_mock.getRetour()).andReturn(retourOK).anyTimes();

    ReponseFonctionnelle<ServiceTechniquePfsSam> pe0302_ReponseFonctionnellePfsSam = new ReponseFonctionnelle();
    List<ServiceTechniquePfsSam> items = new ArrayList<>();
    ServiceTechniquePfsSam stPfsSam = new ServiceTechniquePfsSam();
    stPfsSam.setNiveauRestriction("NONE"); //$NON-NLS-1$
    stPfsSam.setEtatEnregistrement("ETAT_ENR"); //$NON-NLS-1$
    stPfsSam.setImpiFixe("impiFixe"); //$NON-NLS-1$
    stPfsSam.setTypeUsage(TypeUsage.VOIX);

    items.add(stPfsSam);
    pe0302_ReponseFonctionnellePfsSam.setItems(items);
    pe0302_ReponseFonctionnellePfsSam.setResultsCount(items.size());
    ResponseConnector responseConnector = createResponseConnector(pe0302_ReponseFonctionnellePfsSam, ServiceTechniquePfsSam.class);
    prepareProv_SI002(retourOK, responseConnector, nTel, "consulterServiceTechniquePfsSam"); //$NON-NLS-1$

    ReponseFonctionnelle<ServiceTechniquePfsPcm> reponseFonctionnellePfsPcm = new ReponseFonctionnelle<ServiceTechniquePfsPcm>();
    ServiceTechniquePfsPcm stPfsPcm = new ServiceTechniquePfsPcm();
    stPfsPcm.setNom("HEDER"); //$NON-NLS-1$
    List<ServiceTechniquePfsPcm> listStPfsPcm = new ArrayList<>();
    listStPfsPcm.add(stPfsPcm);
    reponseFonctionnellePfsPcm.setItems(listStPfsPcm);
    reponseFonctionnellePfsPcm.setResultsCount(listStPfsPcm.size());
    responseConnector = createResponseConnector(reponseFonctionnellePfsPcm, ServiceTechniquePfsPcm.class);
    prepareProv_SI002(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, null), responseConnector, nTel, "consulterServiceTechniquePfsPcm"); //$NON-NLS-1$

    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.idExterne(EasyMock.anyString())).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.actionCorrective(EasyMock.anyObject(ActionCorrective.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.build()).andReturn(_bl5100Mock);
    String idActionCorrective = "101010"; //$NON-NLS-1$
    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(idActionCorrective);
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(retourOK).anyTimes();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"idActionCorrective\":\"101010\",\"pfs\":[{\"audits\":[{\"diagnostic\":\"DESYNCHRO_PFS\",\"libelle\":\"Désynchronisation sur les paramètres du service Telephonie\",\"parameters\":[\"niveauRestriction\"]}],\"noTelephone\":\"03214467877\",\"typePfs\":\"SAM\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"etatEnregistrement\":\"ETAT_ENR\",\"impi\":[\"impiFixe\"],\"niveauRestriction\":\"NONE\",\"statut\":\"RESTREINT\"}},{\"audits\":[{\"diagnostic\":\"SERVICE_NON_PROVISIONNE\",\"libelle\":\"Service non provisionne sur la PFS \"}],\"noTelephone\":\"03214467877\",\"typePfs\":\"PCM\"}],\"referentiels\":[{\"etatProvisioning\":\"ECHEC\",\"noTelephone\":\"03214467877\",\"ressources\":[{\"etatAllocation\":\"ECHEC\",\"etatRessource\":\"ALLOUE\",\"typeRessource\":\"NUMERO_TELEPHONE\"}],\"typeService\":\"TELEPHONIE\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"codeINSEE\":\"CODEINSEE\",\"impi\":[\"3432423@ims.bouyguestelecom.fr\"],\"impu\":[\"@ims.bouyguestelecom.fr\",\"3432423\"],\"niveauRestriction\":\"RestritionLevel\",\"nom\":\"ZITO\",\"nomPrenomCourt\":\"NomCourt\",\"optionAppelSurTaxes\":\"OPTION_TAXES\",\"prenom\":\"HEDER\",\"statut\":\"RESTREINT\",\"typeReseau\":\"FIXE\"}}]}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);
  }

  /**
   * Test KO : return KO CAT-4 "COMMANDE_EXISTANTE" du BL5100_CreerActionCorrective<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0302_BL300_ConstruireVuePfs_NOK_009() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //BL5270_RecupererPfiParNoTelephone mock
    BL5270_Return bl5270Return = new BL5270_Return();
    String clientOp = "CLIENT-OP";//$NON-NLS-1$
    String noCompte = "NoCompte";//$NON-NLS-1$
    String noContrat = "NoContrat";//$NON-NLS-1$
    bl5270Return.setClientOperateur(clientOp);
    bl5270Return.setNoCompte(noCompte);
    bl5270Return.setNoContrat(noContrat);
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(nTel)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(bl5270Return);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retourOK).anyTimes();

    String niveauRestriction = "RestritionLevel"; //$NON-NLS-1$
    String nomCourt = "NomCourt"; //$NON-NLS-1$
    String codeInsee = "CODEINSEE"; //$NON-NLS-1$
    String optionTaxes = "OPTION_TAXES"; //$NON-NLS-1$
    List<ServiceTechnique> listST = createListServiceTechnique(nTel, nomCourt, codeInsee, niveauRestriction, optionTaxes, "VOIX");

    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourOK, listST);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOp), EasyMock.eq(noCompte), EasyMock.eq(null), EasyMock.eq(null))).andReturn(expectedResponse);

    PowerMock.expectNew(OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.noTelephone(nTel)).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.build()).andReturn(_si026_mock);
    OSSFAI_SI026_Return si026Return = new OSSFAI_SI026_Return("ALLOUE", "1234"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_si026_mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(si026Return);
    EasyMock.expect(_si026_mock.getRetour()).andReturn(retourOK).anyTimes();

    ReponseFonctionnelle<ServiceTechniquePfsSam> pe0302_ReponseFonctionnellePfsSam = new ReponseFonctionnelle();
    List<ServiceTechniquePfsSam> items = new ArrayList<>();
    ServiceTechniquePfsSam stPfsSam = new ServiceTechniquePfsSam();
    stPfsSam.setNiveauRestriction("NONE"); //$NON-NLS-1$
    stPfsSam.setEtatEnregistrement("ETAT_ENR"); //$NON-NLS-1$
    stPfsSam.setImpiFixe("impiFixe"); //$NON-NLS-1$
    stPfsSam.setTypeUsage(TypeUsage.VOIX);

    items.add(stPfsSam);
    pe0302_ReponseFonctionnellePfsSam.setItems(items);
    pe0302_ReponseFonctionnellePfsSam.setResultsCount(items.size());
    ResponseConnector responseConnector = createResponseConnector(pe0302_ReponseFonctionnellePfsSam, ServiceTechniquePfsSam.class);
    prepareProv_SI002(retourOK, responseConnector, nTel, "consulterServiceTechniquePfsSam"); //$NON-NLS-1$

    ReponseFonctionnelle<ServiceTechniquePfsPcm> reponseFonctionnellePfsPcm = new ReponseFonctionnelle<ServiceTechniquePfsPcm>();
    ServiceTechniquePfsPcm stPfsPcm = new ServiceTechniquePfsPcm();
    stPfsPcm.setNom("HEDER"); //$NON-NLS-1$
    List<ServiceTechniquePfsPcm> listStPfsPcm = new ArrayList<>();
    listStPfsPcm.add(stPfsPcm);
    reponseFonctionnellePfsPcm.setItems(listStPfsPcm);
    reponseFonctionnellePfsPcm.setResultsCount(listStPfsPcm.size());
    responseConnector = createResponseConnector(reponseFonctionnellePfsPcm, ServiceTechniquePfsPcm.class);
    prepareProv_SI002(RetourFactoryForTU.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, null), responseConnector, nTel, "consulterServiceTechniquePfsPcm"); //$NON-NLS-1$

    PowerMock.expectNew(BL5100_CreerActionCorrectiveBuilder.class).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.idExterne(EasyMock.anyString())).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.actionCorrective(EasyMock.anyObject(ActionCorrective.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5100BuilderMock);
    EasyMock.expect(_bl5100BuilderMock.build()).andReturn(_bl5100Mock);
    EasyMock.expect(_bl5100Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(null);
    Retour retourNOK = RetourFactoryForTU.createNOK(IMegConsts.CAT4, "COMMANDE_EXISTANTE", "Il existe dÃ©jÃ  une commande pour le quadruplet (clientOperateur: BSS_GP, noCompte: 911260342961, idExterne: abce8400-e29b-11d4-a916-44665544feda+33994671475, nature: ACTION_CORRECTIVE)");
    EasyMock.expect(_bl5100Mock.getRetour()).andReturn(retourNOK).anyTimes();

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"pfs\":[{\"audits\":[{\"diagnostic\":\"DESYNCHRO_PFS\",\"libelle\":\"Désynchronisation sur les paramètres du service Telephonie\",\"parameters\":[\"niveauRestriction\"]}],\"erreurs\":[{\"error\":\"ECHEC_ACTION_CORRECTIVE\",\"error_description\":\"Erreur Creation action corrective : COMMANDE_EXISTANTE\"}],\"noTelephone\":\"03214467877\",\"typePfs\":\"SAM\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"etatEnregistrement\":\"ETAT_ENR\",\"impi\":[\"impiFixe\"],\"niveauRestriction\":\"NONE\",\"statut\":\"RESTREINT\"}},{\"audits\":[{\"diagnostic\":\"SERVICE_NON_PROVISIONNE\",\"libelle\":\"Service non provisionne sur la PFS \"}],\"erreurs\":[{\"error\":\"ECHEC_ACTION_CORRECTIVE\",\"error_description\":\"Erreur Creation action corrective : COMMANDE_EXISTANTE\"}],\"noTelephone\":\"03214467877\",\"typePfs\":\"PCM\"}],\"referentiels\":[{\"etatProvisioning\":\"ECHEC\",\"noTelephone\":\"03214467877\",\"ressources\":[{\"etatAllocation\":\"ECHEC\",\"etatRessource\":\"ALLOUE\",\"typeRessource\":\"NUMERO_TELEPHONE\"}],\"typeService\":\"TELEPHONIE\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"codeINSEE\":\"CODEINSEE\",\"impi\":[\"3432423@ims.bouyguestelecom.fr\"],\"impu\":[\"@ims.bouyguestelecom.fr\",\"3432423\"],\"niveauRestriction\":\"RestritionLevel\",\"nom\":\"ZITO\",\"nomPrenomCourt\":\"NomCourt\",\"optionAppelSurTaxes\":\"OPTION_TAXES\",\"prenom\":\"HEDER\",\"statut\":\"RESTREINT\",\"typeReseau\":\"FIXE\"}}]}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);
  }

  /**
   * Test OK : Empty referentiel<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0302_BL300_ConstruireVuePfs_NOK_010() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourOK = RetourFactoryForTU.createOkRetour();

    ReponseFonctionnelle<ServiceTechniquePfsSam> pe0302_ReponseFonctionnellePfsSam = new ReponseFonctionnelle<ServiceTechniquePfsSam>();
    List<ServiceTechniquePfsSam> items = new ArrayList<>();
    ServiceTechniquePfsSam stPfsSam = new ServiceTechniquePfsSam();
    items.add(stPfsSam);
    pe0302_ReponseFonctionnellePfsSam.setItems(items);
    pe0302_ReponseFonctionnellePfsSam.setResultsCount(items.size());
    ResponseConnector responseConnector = createResponseConnector(pe0302_ReponseFonctionnellePfsSam, ServiceTechniquePfsSam.class);
    prepareProv_SI002(retourOK, responseConnector, nTel, "consulterServiceTechniquePfsSam"); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"pfs\":[{\"fax\":{\"impi\":[null],\"impu\":[null,null]},\"noTelephone\":\"03214467877\",\"typePfs\":\"SAM\"}]}"; //$NON-NLS-1$
    assertEquals(expectedResult, result);
  }

  /**
   * Test Nominal. return OK with no empty list<br/>
   *
   *
   * @throws Throwable
   *           On error
   */
  @Test
  public void PE0302_Nominal_OK_001() throws Throwable
  {

    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("GET"); //$NON-NLS-1$

    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "XSOURCE"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, "125667889000877"); //$NON-NLS-1$
    RequestHeader xMessageId = createHeader(IHttpHeadersConsts.X_MESSAGE_ID, "XMESSAGEID"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "XPROCESS"); //$NON-NLS-1$
    RequestHeader xActionId = createHeader(IHttpHeadersConsts.X_ACTION_ID, "DOMINGO"); //$NON-NLS-1$

    fillRequestHeaders(request, xProcess, xSource, xRequestId, xMessageId, xActionId);

    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParameters = urlParametersType.getUrlParameters();
    String nTel = "03214467877";//$NON-NLS-1$
    Parameter noTelephone = new Parameter(NO_TELEPHONE, nTel);
    urlParameters.add(noTelephone);
    Parameter sourceDonnee = new Parameter(SOURCE_DONNEE, "REFERENTIEL, PFS");//$NON-NLS-1$
    urlParameters.add(sourceDonnee);
    Parameter audit = new Parameter(AUDIT, "true");//$NON-NLS-1$
    urlParameters.add(audit);
    urlParametersType.setUrlParameters(urlParameters);
    request.setUrlParameters(urlParametersType);

    Retour retourOK = RetourFactoryForTU.createOkRetour();
    //BL5270_RecupererPfiParNoTelephone mock
    BL5270_Return bl5270Return = new BL5270_Return();
    String clientOp = "CLIENT-OP";//$NON-NLS-1$
    String noCompte = "NoCompte";//$NON-NLS-1$
    String noContrat = "NoContrat";//$NON-NLS-1$
    bl5270Return.setClientOperateur(clientOp);
    bl5270Return.setNoCompte(noCompte);
    bl5270Return.setNoContrat(noContrat);
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(nTel)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(bl5270Return);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retourOK).anyTimes();

    String niveauRestriction = "NONE";
    String nomCourt = "EDERZITO";
    String codeInsee = "CODEINSEE";
    String optionTaxes = "OPTION_TAXES";
    List<ServiceTechnique> listST = createListServiceTechnique(nTel, nomCourt, codeInsee, niveauRestriction, optionTaxes, "VOIX");

    ConnectorResponse<Retour, List<ServiceTechnique>> expectedResponse = new ConnectorResponse<>(retourOK, listST);
    EasyMock.expect(RSTProxy.getInstance()).andReturn(_rstProxy);
    EasyMock.expect(_rstProxy.serviceTechniqueLireTousParPfi(EasyMock.anyObject(Tracabilite.class), EasyMock.eq(clientOp), EasyMock.eq(noCompte), EasyMock.eq(null), EasyMock.eq(null))).andReturn(expectedResponse);

    PowerMock.expectNew(OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.noTelephone(nTel)).andReturn(_si026_mockbuilder);
    EasyMock.expect(_si026_mockbuilder.build()).andReturn(_si026_mock);
    OSSFAI_SI026_Return si026Return = new OSSFAI_SI026_Return("ALLOUE", "1234"); //$NON-NLS-1$//$NON-NLS-2$
    EasyMock.expect(_si026_mock.execute(EasyMock.anyObject(PE0302_DiagnosticServiceTelephonie.class))).andReturn(si026Return);
    EasyMock.expect(_si026_mock.getRetour()).andReturn(retourOK).anyTimes();

    ReponseFonctionnelle<ServiceTechniquePfsSam> reponseFonctionnellePfsSam = new ReponseFonctionnelle<ServiceTechniquePfsSam>();
    List<ServiceTechniquePfsSam> items = new ArrayList<>();
    ServiceTechniquePfsSam stPfsSam = new ServiceTechniquePfsSam();
    stPfsSam.setNiveauRestriction("NONE");
    stPfsSam.setEtatEnregistrement("ETAT_ENR");
    stPfsSam.setImpiFixe("impiFixe");
    stPfsSam.setTypeUsage(TypeUsage.VOIX);
    stPfsSam.setNomPrenomCourt("EDERZITO"); //$NON-NLS-1$
    stPfsSam.setOptionAppelSurTaxes("OPTION_TAXES");

    items.add(stPfsSam);
    reponseFonctionnellePfsSam.setItems(items);
    reponseFonctionnellePfsSam.setResultsCount(items.size());
    ResponseConnector responseConnector = createResponseConnector(reponseFonctionnellePfsSam, ServiceTechniquePfsSam.class);
    prepareProv_SI002(retourOK, responseConnector, nTel, "consulterServiceTechniquePfsSam"); //$NON-NLS-1$

    ReponseFonctionnelle<ServiceTechniquePfsPcm> reponseFonctionnellePfsPcm = new ReponseFonctionnelle<ServiceTechniquePfsPcm>();
    ServiceTechniquePfsPcm stPfsPcm = new ServiceTechniquePfsPcm();
    stPfsPcm.setNom("HEDER");
    stPfsPcm.setPrenom("ZITO");
    List<ServiceTechniquePfsPcm> listStPfsPcm = new ArrayList<>();
    listStPfsPcm.add(stPfsPcm);
    reponseFonctionnellePfsPcm.setItems(listStPfsPcm);
    reponseFonctionnellePfsPcm.setResultsCount(items.size());
    responseConnector = createResponseConnector(reponseFonctionnellePfsPcm, ServiceTechniquePfsPcm.class);
    prepareProv_SI002(retourOK, responseConnector, nTel, "consulterServiceTechniquePfsPcm"); //$NON-NLS-1$

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    Response response = (Response) request.getResponse();
    assertEquals(ErrorCode.OK_00200, response.getErrorCode());
    String result = response.getGenericResponse().getResult();
    String expectedResult = "{\"pfs\":[{\"noTelephone\":\"03214467877\",\"typePfs\":\"SAM\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"etatEnregistrement\":\"ETAT_ENR\",\"impi\":[\"impiFixe\"],\"niveauRestriction\":\"NONE\",\"nomPrenomCourt\":\"EDERZITO\",\"optionAppelSurTaxes\":\"OPTION_TAXES\",\"statut\":\"RESTREINT\"}},{\"ligneEnCommunication\":\"LIBRE\",\"noTelephone\":\"03214467877\",\"nom\":\"HEDER\",\"prenom\":\"ZITO\",\"typePfs\":\"PCM\"}],\"referentiels\":[{\"etatProvisioning\":\"ECHEC\",\"noTelephone\":\"03214467877\",\"ressources\":[{\"etatAllocation\":\"ECHEC\",\"etatRessource\":\"ALLOUE\",\"typeRessource\":\"NUMERO_TELEPHONE\"}],\"typeService\":\"TELEPHONIE\",\"typeUsages\":[\"VOIX\"],\"voix\":{\"codeINSEE\":\"CODEINSEE\",\"impi\":[\"3432423@ims.bouyguestelecom.fr\"],\"impu\":[\"@ims.bouyguestelecom.fr\",\"3432423\"],\"niveauRestriction\":\"NONE\",\"nom\":\"ZITO\",\"nomPrenomCourt\":\"EDERZITO\",\"optionAppelSurTaxes\":\"OPTION_TAXES\",\"prenom\":\"HEDER\",\"statut\":\"RESTREINT\",\"typeReseau\":\"FIXE\"}}]}";
    assertEquals(expectedResult, result);

  }

  /**
   * Initialization of tests
   *
   */
  @Before
  public void setUp()
  {
    // context initialization
    _processInstance = new PE0302_DiagnosticServiceTelephonie();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojo(Tracabilite.class);
    _tracabilite.setIdProcessusSpirit(_processInstance.getIdProcess());
    _tracabilite.setNomProcessus(DEFAULT_PROCESSNAME);
    _tracabilite.setNomSysteme(System.getenv("SERVICE")); //$NON-NLS-1$

    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests
    PowerMock.resetAll();
    PowerMock.mockStaticStrict(ProcessManager.class);
    PowerMock.mockStatic(BL5270_RecupererPfiParNoTelephone.class);
    PowerMock.mockStatic(BL5270_RecupererPfiParNoTelephoneBuilder.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessus.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessusBuilder.class);
    PowerMock.mockStatic(BL5100_CreerActionCorrective.class);
    PowerMock.mockStatic(BL5100_CreerActionCorrectiveBuilder.class);
    PowerMock.mockStatic(RSTProxy.class);
    PowerMock.mockStatic(OSSFAI_SI026_LireRessourceNoTelephoneBuilder.class);
    PowerMock.mockStatic(OSSFAI_SI026_LireRessourceNoTelephone.class);

  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   * @param tracabilite_p
   *          tracabilite
   *
   *
   * @param listeContract_p
   *          listeContract
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p, String listeContract_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("ClientOperateur"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
    hdr.setValue("Authorization : bearer XXXX"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue(listeContract_p);
    requestHeader_p.add(hdr);
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * @param nTel_p
   * @param nomCourtUtilisateur_p
   * @param codeInsee_p
   * @param niveauRestriction_p
   * @param optionAppelSurTaxes_p
   * @param typeUsage
   *          TODO
   * @return List ServiceTechnique
   */
  private List<ServiceTechnique> createListServiceTechnique(String nTel_p, String nomCourtUtilisateur_p, String codeInsee_p, String niveauRestriction_p, String optionAppelSurTaxes_p, String typeUsage)
  {
    List<ServiceTechnique> listServiceTechnique = new ArrayList<>();

    ServiceTechnique stPfsClf = __podam.manufacturePojoWithFullData(StPfsClf.class);
    stPfsClf.setTypeServiceTechnique(TypeST.PFS.name());
    StPfsClf.class.cast(stPfsClf).setTypePfs(TypePFS.CLF.name());
    stPfsClf.setStatut(com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString());
    String identifiantFonctionnelPa = "idPA"; //$NON-NLS-1$
    DonneesIdentificationStPfsClf donnesIdentificationStPfsClf = new DonneesIdentificationStPfsClf(identifiantFonctionnelPa);
    StPfsClf.class.cast(stPfsClf).setDonneesIdentificationStPfsClf(donnesIdentificationStPfsClf);
    ((DonneesProvisionneesStPfsClf) StPfsClf.class.cast(stPfsClf).getDonneesProvisionnees()).setCodeInsee(codeInsee_p);
    listServiceTechnique.add(stPfsClf);

    ServiceTechnique stPfsSam = __podam.manufacturePojoWithFullData(StPfsSam.class);
    stPfsSam.setTypeServiceTechnique(TypeST.PFS.name());
    StPfsSam.class.cast(stPfsSam).setTypePfs(TypePFS.SAM.name());
    stPfsSam.setStatut(com.bytel.spirit.common.shared.saab.rst.Statut.ACTIF.toString());
    DonneesIdentificationStPfsSam donnesIdentificationStPfsSam = new DonneesIdentificationStPfsSam(identifiantFonctionnelPa);
    StPfsSam.class.cast(stPfsSam).setDonneesIdentificationStPfsSam(donnesIdentificationStPfsSam);

    DonneesProvisionneesStPfsSam donneesProvSam = (DonneesProvisionneesStPfsSam) StPfsSam.class.cast(stPfsSam).getDonneesProvisionnees();
    donneesProvSam.setTypeUsage(typeUsage);
    donneesProvSam.setNomPrenomCourt(nomCourtUtilisateur_p);
    donneesProvSam.setNiveauRestriction(niveauRestriction_p);
    donneesProvSam.setOptionAppelSurTaxes(optionAppelSurTaxes_p);
    donneesProvSam.setImpiFixe("3432423@ims.bouyguestelecom.fr"); //$NON-NLS-1$
    donneesProvSam.setSipUri("@ims.bouyguestelecom.fr"); //$NON-NLS-1$
    donneesProvSam.setTelUri("3432423"); //$NON-NLS-1$
    donneesProvSam.setNom("ZITO"); //$NON-NLS-1$
    donneesProvSam.setPrenom("HEDER");//$NON-NLS-1$

    listServiceTechnique.add(stPfsSam);

    ServiceTechnique stPfsPnf = __podam.manufacturePojoWithFullData(StPfsPnf.class);
    stPfsPnf.setTypeServiceTechnique(TypeST.PFS.name());
    StPfsPnf.class.cast(stPfsPnf).setTypePfs(TypePFS.PNF.name());
    stPfsPnf.setStatut(com.bytel.spirit.common.shared.saab.rst.Statut.ECHEC.toString());
    DonneesIdentificationStPfsPnf donnesIdentificationStPfsPnf = new DonneesIdentificationStPfsPnf(identifiantFonctionnelPa);
    StPfsPnf.class.cast(stPfsPnf).setDonneesIdentificationStPfsPnf(donnesIdentificationStPfsPnf);
    listServiceTechnique.add(stPfsPnf);

    StLienAllocationCommercial stLAC1 = new StLienAllocationCommercial("idST", "ECHEC", "cliOpe", "noCompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", nTel_p, "NUMERO_TELEPHONE"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLAC1.setOcIdentifiantFonctionnelPA(identifiantFonctionnelPa);
    listServiceTechnique.add(stLAC1);

    StLienAllocationCommercial stLAC2 = new StLienAllocationCommercial("idST", "ECHEC", "cliOpe", "noCompte", TypeObjetCommercial.PA.name(), "BSS_GP", "ocNoCompte", nTel_p, "IMPI_FIXE"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    stLAC2.setOcIdentifiantFonctionnelPA(identifiantFonctionnelPa);
    listServiceTechnique.add(stLAC2);

    return listServiceTechnique;
  }

  /**
   * Create Response connector
   *
   * @param reponseFonctionnelle_p
   * @param class_p
   *
   * @return ResponseConnector
   * @throws RavelException
   */
  private ResponseConnector createResponseConnector(ReponseFonctionnelle<?> reponseFonctionnelle_p, Class<?> class_p) throws RavelException
  {
    com.bytel.spirit.common.connectors.ink.generated.Response response = new com.bytel.spirit.common.connectors.ink.generated.Response();
    ResponseConnector reponseConnector = __podam.manufacturePojo(ResponseConnector.class);
    String result = RavelJsonTools.getInstance().toJson(reponseFonctionnelle_p, new ReponseFonctionnelleParameterizedType<>(class_p));
    Dataset dataset = new Dataset();
    List<DatasetParam> listdata = new ArrayList<>();
    DatasetParam datasetparam = new DatasetParam();
    datasetparam.setIndex(1);
    datasetparam.setName("reponseFonctionnelle"); //$NON-NLS-1$
    datasetparam.setValue(result);
    listdata.add(datasetparam);
    dataset.getParams().add(datasetparam);
    ServiceOrderDataResponse serviceData = new ServiceOrderDataResponse();
    serviceData.setDataset(dataset);
    ServiceOrderResponse so = new ServiceOrderResponse();
    so.setSod(serviceData);
    response.setSo(so);
    reponseConnector.setResponse(response);
    return reponseConnector;
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * prepareProv_SI002
   *
   * @param retour_p
   *          retour
   * @param reponseConnector_p
   *          reponseconnector
   * @param nTel_p
   * @param processus_p
   * @throws Exception
   *           excetpion
   */
  private void prepareProv_SI002(Retour retour_p, ResponseConnector reponseConnector_p, String nTel_p, String processus_p) throws Exception
  {
    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.priorite(EasyMock.eq(10))).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.processus(EasyMock.eq(processus_p))).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.noms(Arrays.asList("noTelephone"))).andReturn(_si002_mockbuilder); //$NON-NLS-1$
    EasyMock.expect(_si002_mockbuilder.valeurs(Arrays.asList(nTel_p))).andReturn(_si002_mockbuilder);
    EasyMock.expect(_si002_mockbuilder.build()).andReturn(_si002_mock);
    EasyMock.expect(_si002_mock.execute(_processInstance)).andReturn(reponseConnector_p);
    EasyMock.expect(_si002_mock.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * prepareGetRequest
   *
   * @param tracabilite_p
   *          tracabilite
   * @param methode_p
   *          method
   * @param urlDynamicParameters_p
   *          idMessagerie / idAnnonce
   * @param listeContact_p
   *          listeContact
   * @return Request
   * @throws RavelException
   *           exception
   */
  private Request prepareRequest(Tracabilite tracabilite_p, String methode_p, String urlDynamicParameters_p, String listeContact_p) throws RavelException
  {
    Request request = new Request(DEFAULT_PROCESSNAME, "idProcess", "idClient"); //$NON-NLS-1$ //$NON-NLS-2$
    request.setHttpMethod(methode_p);
    request.setMsgId(Test_Consts.DEFAULT_MSGID);
    addXHeaders(request.getRequestHeader(), tracabilite_p, listeContact_p);

    if (urlDynamicParameters_p != null)
    {
      request.setUrlDynamicParameters(urlDynamicParameters_p);
    }

    return request;
  }
}
