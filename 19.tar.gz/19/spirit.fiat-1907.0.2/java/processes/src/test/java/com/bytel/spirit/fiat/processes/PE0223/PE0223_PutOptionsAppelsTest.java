/*******************************************************************************
* $Id: PE0223_PutOptionsAppelsTest.java 10060 2018-09-12 11:58:31Z pcarreir $
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.processes.PE0223;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.security.NoSuchAlgorithmException;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.easymock.PowerMock;
import org.powermock.api.easymock.annotation.MockNice;
import org.powermock.api.easymock.annotation.MockStrict;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PowerMockListener;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.testlisteners.FieldDefaulter;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.powermock.reflect.Whitebox;
import org.springframework.test.context.ContextConfiguration;

import com.bytel.ravel.common.business.generated.Retour;
import com.bytel.ravel.common.data.exchange.generated.RavelRequest.RequestHeader;
import com.bytel.ravel.common.encryption.PasswordDecrypter;
import com.bytel.ravel.common.exception.ErrorCode;
import com.bytel.ravel.common.exception.ExceptionType;
import com.bytel.ravel.common.exception.RavelException;
import com.bytel.ravel.common.factory.request.Parameter;
import com.bytel.ravel.common.factory.request.UrlParameters;
import com.bytel.ravel.common.gson.GsonTools;
import com.bytel.ravel.common.meg.IMegConsts;
import com.bytel.ravel.common.metadata.IMetadata;
import com.bytel.ravel.common.test.podam.PodamByTelClassInfosStrategy;
import com.bytel.ravel.common.test.podam.PodamBytelJUnit4ClassRunner;
import com.bytel.ravel.common.utils.DateTimeTools.DateTimeFormatPattern;
import com.bytel.ravel.common.utils.Pair;
import com.bytel.ravel.common.utils.RetourFactory;
import com.bytel.ravel.common.utils.StringConstants;
import com.bytel.ravel.net.http.Request;
import com.bytel.ravel.services.process.ProcessManager;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc;
import com.bytel.spirit.common.activities.shared.BL1700_AjouterRefFonc.BL1700_AjouterRefFoncBuilder;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone;
import com.bytel.spirit.common.activities.shared.BL5270_RecupererPfiParNoTelephone.BL5270_RecupererPfiParNoTelephoneBuilder;
import com.bytel.spirit.common.activities.shared.structs.BL5270_Return;
import com.bytel.spirit.common.connectors.ink.ListeParametre;
import com.bytel.spirit.common.connectors.ink.ResponseConnector;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus;
import com.bytel.spirit.common.connectors.ink.activities.PROV_SI002_ExecuterProcessus.PROV_SI002_ExecuterProcessusBuilder;
import com.bytel.spirit.common.shared.misc.connectors.IHttpHeadersConsts;
import com.bytel.spirit.common.shared.misc.error.ReponseErreur;
import com.bytel.spirit.common.shared.misc.meg.IMegSpiritConsts;
import com.bytel.spirit.common.shared.misc.tracabilite.IRefFoncConstants;
import com.bytel.spirit.common.shared.misc.tracabilite.Tracabilite;
import com.bytel.spirit.fiat.processes.Messages;
import com.bytel.spirit.fiat.processes.PE0223.structs.put.IOptionAppelConsts;
import com.bytel.spirit.fiat.processes.PE0223.structs.put.PE0223_BL001PutReturn;
import com.bytel.spirit.fiat.processes.PE0223.structs.put.PE0223_PutRequest;
import com.google.gson.Gson;

import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 *
 * @author pcarreir
 * @version ($Revision: 10060 $ $Date: 2018-09-12 13:58:31 +0200 (Wed, 12 Sep 2018) $)
 */
@RunWith(PowerMockRunner.class)
@PowerMockListener(FieldDefaulter.class)
@PowerMockRunnerDelegate(PodamBytelJUnit4ClassRunner.class)
@ContextConfiguration("classpath:BeansProcessTestMocks.xml")
@PowerMockIgnore({ "javax.crypto.*", "javax.security.auth.*" })
@PrepareForTest({ PE0223_OptionsAppels.class, PasswordDecrypter.class, //
    BL5270_RecupererPfiParNoTelephoneBuilder.class, BL5270_RecupererPfiParNoTelephone.class, //
    BL1700_AjouterRefFoncBuilder.class, BL1700_AjouterRefFonc.class, //
    PROV_SI002_ExecuterProcessusBuilder.class, PROV_SI002_ExecuterProcessus.class })
public final class PE0223_PutOptionsAppelsTest
{
  /**
   * Tracabilite
   */
  private static Tracabilite _tracabilite;

  /**
   * Factory de génération des beans
   */
  private static PodamFactory __podam = new PodamFactoryImpl();

  /**
   * PARAM_TYPE constant
   */
  private static final String PARAM_TYPE = "typeOptionAppel"; //$NON-NLS-1$

  /**
   * PARAM_NO_TELEPHONE constant
   */
  private static final String PARAM_NO_TELEPHONE = "noTelephone"; //$NON-NLS-1$

  /**
   * PARAM_STATUT constant
   */
  private static final String PARAM_STATUT = "statut"; //$NON-NLS-1$

  /**
   * PARAM_MODE_RENVOI constant
   */
  private static final String PARAM_MODE_RENVOI = "modeRenvoi"; //$NON-NLS-1$

  /**
   * PARAM_NUMERO_RENVOI constant
   */
  private static final String PARAM_NUMERO_RENVOI = "numeroRenvoi"; //$NON-NLS-1$

  /**
   * RENVOI_LIGNE_INDISPONIBLE constant
   */
  private static final String TYPE_RENVOI_LIGNE_INDISPONIBLE = "RENVOI_LIGNE_INDISPONIBLE"; //$NON-NLS-1$

  /**
   * DOUBLE_APPEL constant
   */
  private static final String TYPE_DOUBLE_APPEL = "DOUBLE_APPEL"; //$NON-NLS-1$

  /**
   * PARAM_NO_TELEPHONE constant
   */
  private static final String NO_TELEPHONE_INT = "+33123123123"; //$NON-NLS-1$

  /**
   * PARAM_NO_TELEPHONE constant
   */
  private static final String NO_TELEPHONE_NAC = "0123123123"; //$NON-NLS-1$

  /**
   * modifierOptionAppel action
   */
  private static final String PARAM_TYPE_OPERATION = "typeOperation"; //$NON-NLS-1$

  /**
   * modifierOptionAppel action
   */
  private static final String ACTION_MODIFIER_OPTION_APPEL = "modifierOptionAppel"; //$NON-NLS-1$

  /**
   * desactiverRenvoisAppels action
   */
  private static final String ACTION_DESACTIVER_RENVOIS_APPELS = "desactiverRenvoisAppels"; //$NON-NLS-1$

  /**
   * PARAM_ACTION constant
   */
  private static final String PARAM_ACTION = "action"; //$NON-NLS-1$

  /**
   * STATUT_ACTIF constant
   */
  private static final String STATUT_ACTIF = "ACTIF"; //$NON-NLS-1$

  /**
   * The X_REQUEST_ID_VALUE
   */
  private static final String X_REQUEST_ID_VALUE = "125667889000877"; //$NON-NLS-1$

  /**
   * Création d' un Parameter
   *
   * @param name_p
   *          The Name
   * @param value_p
   *          The value
   *
   * @return Parameter
   */
  public static Parameter createParameter(String name_p, String value_p)
  {
    Parameter parameter = new Parameter();

    parameter.setName(name_p);
    parameter.setValue(value_p);

    return parameter;
  }

  /**
   * Initialization method: Create: - spring context - connectors - service manager.
   *
   * @throws RavelException
   *           the exception
   */
  @BeforeClass
  public static void init() throws RavelException
  {
    // désactivation du cache podam
    __podam.getStrategy().setMemoization(false);
    __podam.setClassStrategy(PodamByTelClassInfosStrategy.getInstance());
  }

  /**
   * Instance of {@link PE0223_OptionsAppels}
   */
  private PE0223_OptionsAppels _processInstance;

  /**
   * The PasswordDecrypter mock
   */
  @MockNice
  PasswordDecrypter _passwordDecrypterMock;

  /**
   * BL1700_AjouterRefFoncBuilder
   */
  @MockStrict
  BL1700_AjouterRefFoncBuilder _bl1700BuilderMock;

  /**
   * BL1700_AjouterRefFonc
   */
  @MockStrict
  BL1700_AjouterRefFonc _bl1700Mock;

  /**
   * BL5270_RecupererPfiParNoTelephoneBuilder
   */
  @MockStrict
  BL5270_RecupererPfiParNoTelephoneBuilder _bl5270BuilderMock;

  /**
   * BL5270_RecupererPfiParNoTelephone
   */
  @MockStrict
  BL5270_RecupererPfiParNoTelephone _bl5270Mock;

  /**
   * PROV_SI002_ExecuterProcessusBuilder
   */
  @MockStrict
  PROV_SI002_ExecuterProcessusBuilder _si002BuilderMock;

  /**
   * PROV_SI002_ExecuterProcessus
   */
  @MockStrict
  PROV_SI002_ExecuterProcessus _si002Mock;

  /**
   * Initialization of tests
   *
   */
  @Before
  public void beforeTest()
  {
    // context initialization
    _processInstance = new PE0223_OptionsAppels();
    _processInstance.initializeContext();

    _tracabilite = __podam.manufacturePojo(Tracabilite.class);

    ProcessManager.getInstance().getProcessParams().clear();
    // on réinitialise tous les mocks afin de ne pas avoir d'interférence entre les tests

    PowerMock.resetAll();
    PowerMock.mockStatic(PasswordDecrypter.class);
    PowerMock.mockStatic(BL1700_AjouterRefFoncBuilder.class);
    PowerMock.mockStatic(BL1700_AjouterRefFonc.class);
    PowerMock.mockStatic(BL5270_RecupererPfiParNoTelephoneBuilder.class);
    PowerMock.mockStatic(BL5270_RecupererPfiParNoTelephone.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessusBuilder.class);
    PowerMock.mockStatic(PROV_SI002_ExecuterProcessus.class);
  }

  /**
   * <b>Scenario:</b> Error test case. payload is null<br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_001() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0223.BL001.HeaderNullOrEmpty"), IHttpHeadersConsts.X_REQUEST_ID)); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, null, null, null, null, null, null, null);
    request.getRequestHeader().clear();

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. payload is null<br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_002() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, Messages.getString("PE0223.BL100.emptyBody")); //$NON-NLS-1$
    Request request = prepareRequest(_tracabilite, null, null, null, null, null, null, null);

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. noTelephone is null<br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_003() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0223.BL100.invalidParameter"), PARAM_NO_TELEPHONE, null)); //$NON-NLS-1$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_ACTIF);
    pe0223Input.setModeRenvoi(null);
    pe0223Input.setNombreSonneries(null);
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, null, null, null, null, null, null);

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. action is null<br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_004() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0223.BL100.invalidParameter"), PARAM_TYPE_OPERATION, null)); //$NON-NLS-1$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_ACTIF);
    pe0223Input.setModeRenvoi(null);
    pe0223Input.setNombreSonneries(null);
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, null, NO_TELEPHONE_INT, null, null, null, null);

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. Password error</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_005() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_OPTION_APPEL_INCONNU, MessageFormat.format(Messages.getString("PE0223.BL001.idOptionInconnu"), "1nBLshtXB1G9W+XjHR4LnQ==")); //$NON-NLS-1$ //$NON-NLS-2$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_ACTIF);
    pe0223Input.setModeRenvoi(null);
    pe0223Input.setNombreSonneries(null);
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, null, null, null); //$NON-NLS-1$

    fillAllRequestHeaders(request);
    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, "Error in PasswordDecrypter.Decrypt(): NoSuchAlgorithmException !", new NoSuchAlgorithmException())); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. Password error</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_006() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_OPTION_APPEL_INCONNU, MessageFormat.format(Messages.getString("PE0223.BL001.idOptionInconnu"), "1nBLshtXB1G9W+XjHR4LnQ==")); //$NON-NLS-1$ //$NON-NLS-2$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_ACTIF);
    pe0223Input.setModeRenvoi(null);
    pe0223Input.setNombreSonneries(null);
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, null, null, null); //$NON-NLS-1$

    fillAllRequestHeaders(request);
    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andThrow(new RavelException(ExceptionType.INTERNAL_ERROR, ErrorCode.CNCTOR_00010, "Error in PasswordDecrypter.Decrypt(): NoSuchAlgorithmException !", new NoSuchAlgorithmException())); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. Invalid modeRenvoi <b>Input:</b> Valid request<br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_007() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0223.BL100.invalidParameter"), PARAM_STATUT, IOptionAppelConsts.STATUT_ACTIF)); //$NON-NLS-1$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_ACTIF);
    pe0223Input.setModeRenvoi(null);
    pe0223Input.setNombreSonneries(null);
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, null, NO_TELEPHONE_INT, ACTION_DESACTIVER_RENVOIS_APPELS, TYPE_RENVOI_LIGNE_INDISPONIBLE, null, null);

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verifyAll();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. modeRenvoi null</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_008() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.ID_OPTION_APPEL_INCONNU, MessageFormat.format(Messages.getString("PE0223.BL001.idOptionInconnu"), "1nBLshtXB1G9W+XjHR4LnQ==")); //$NON-NLS-1$ //$NON-NLS-2$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_ACTIF);
    pe0223Input.setModeRenvoi(null);
    pe0223Input.setNombreSonneries(null);
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, null, null, null); //$NON-NLS-1$

    fillAllRequestHeaders(request);
    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andReturn("144104#+33123456789#"); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. modeRenvoi unexpected</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_009() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0223.BL100.invalidParameter"), PARAM_MODE_RENVOI, "ERROR")); //$NON-NLS-1$ //$NON-NLS-2$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_ACTIF);
    pe0223Input.setModeRenvoi("ERROR"); //$NON-NLS-1$
    pe0223Input.setNombreSonneries(null);
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, null, null, null); //$NON-NLS-1$

    fillAllRequestHeaders(request);
    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andReturn("144104#+33123456789#RENVOI_LIGNE_OCCUPEE"); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. numeroRenvoi null</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_010() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0223.BL100.invalidParameter"), PARAM_NUMERO_RENVOI, null)); //$NON-NLS-1$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_ACTIF);
    pe0223Input.setModeRenvoi(IOptionAppelConsts.MODE_RENVOI_NUMERO);
    pe0223Input.setNombreSonneries(null);
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, null, null, null); //$NON-NLS-1$

    fillAllRequestHeaders(request);
    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andReturn("144104#+33123456789#RENVOI_NON_REPONSE"); //$NON-NLS-1$ //$NON-NLS-2$

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. numeroRenvoi null</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_012() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0223.BL100.invalidParameter"), PARAM_NUMERO_RENVOI, null)); //$NON-NLS-1$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_ACTIF);
    pe0223Input.setModeRenvoi(IOptionAppelConsts.MODE_RENVOI_NUMERO);
    pe0223Input.setNombreSonneries("2"); //$NON-NLS-1$
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, null, null, null); //$NON-NLS-1$
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, X_REQUEST_ID_VALUE);
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, NO_TELEPHONE_INT);

    fillAllRequestHeaders(request);
    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andReturn("144104#+33123456789#RENVOI_NON_REPONSE"); //$NON-NLS-1$ //$NON-NLS-2$
    prepareB1700Mock(refFonc);

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Error test case. status wrong</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_013() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT3, IMegSpiritConsts.NON_RESPECT_STI, MessageFormat.format(Messages.getString("PE0223.BL100.invalidParameter"), PARAM_STATUT, "INCONNU")); //$NON-NLS-1$ //$NON-NLS-2$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut("INCONNU"); //$NON-NLS-1$
    pe0223Input.setModeRenvoi(IOptionAppelConsts.TYPE_APPEL_INCOGNITO);
    pe0223Input.setNombreSonneries("2"); //$NON-NLS-1$
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, null, null, null); //$NON-NLS-1$
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, X_REQUEST_ID_VALUE);
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, NO_TELEPHONE_INT);

    fillAllRequestHeaders(request);
    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andReturn("144104#+33123456789#RENVOI_NON_REPONSE"); //$NON-NLS-1$ //$NON-NLS-2$
    prepareB1700Mock(refFonc);

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNull(actual._second);
  }

  /**
   * <b>Scenario:</b> Nominal test case.</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_014() throws Throwable
  {
    Retour expected = RetourFactory.createOkRetour();
    PE0223_BL001PutReturn secondary = new PE0223_BL001PutReturn();
    secondary.setNoTelephone("+33123456789"); //$NON-NLS-1$
    secondary.setIdOptionAppel("1nBLshtXB1G9W+XjHR4LnQ=="); //$NON-NLS-1$
    secondary.setTypeOperation(ACTION_MODIFIER_OPTION_APPEL);
    secondary.setTypeOptionAppel(IOptionAppelConsts.TYPE_APPEL_INCOGNITO);
    secondary.setStatutOptionAppel(IOptionAppelConsts.STATUT_INACTIF);
    secondary.setNoContrat("144104"); //$NON-NLS-1$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_INACTIF);
    pe0223Input.setModeRenvoi(null);
    pe0223Input.setNombreSonneries("2"); //$NON-NLS-1$
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, null, null, null); //$NON-NLS-1$
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, X_REQUEST_ID_VALUE);
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, NO_TELEPHONE_INT);

    fillAllRequestHeaders(request);
    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andReturn("144104#+33123456789#APPEL_INCOGNITO"); //$NON-NLS-1$ //$NON-NLS-2$
    prepareB1700Mock(refFonc);

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNotNull(actual._second);
    assertEquals(secondary, actual._second);
  }

  /**
   * <b>Scenario:</b> Nominal test case.</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL001_VerifierDonneesModification_Test_015() throws Throwable
  {
    Retour expected = RetourFactory.createOkRetour();
    PE0223_BL001PutReturn secondary = new PE0223_BL001PutReturn();
    secondary.setNoTelephone("+33123456789"); //$NON-NLS-1$
    secondary.setIdOptionAppel("1nBLshtXB1G9W+XjHR4LnQ=="); //$NON-NLS-1$
    secondary.setTypeOperation(ACTION_MODIFIER_OPTION_APPEL);
    secondary.setTypeOptionAppel(IOptionAppelConsts.TYPE_APPEL_INCOGNITO);
    secondary.setStatutOptionAppel(IOptionAppelConsts.STATUT_SUSPENDU);
    secondary.setNoContrat("144104"); //$NON-NLS-1$
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(IOptionAppelConsts.STATUT_SUSPENDU);
    pe0223Input.setModeRenvoi(null);
    pe0223Input.setNombreSonneries("2"); //$NON-NLS-1$
    pe0223Input.setNumeroRenvoi(null);
    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, null, null, null); //$NON-NLS-1$
    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, X_REQUEST_ID_VALUE);
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, NO_TELEPHONE_INT);

    fillAllRequestHeaders(request);
    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andReturn("144104#+33123456789#APPEL_INCOGNITO"); //$NON-NLS-1$ //$NON-NLS-2$
    prepareB1700Mock(refFonc);

    PowerMock.replayAll();
    Pair<Retour, PE0223_BL001PutReturn> actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL001_VerifierDonneesModification", _tracabilite, request); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual._first);
    assertNotNull(actual._second);
    assertEquals(secondary, actual._second);
  }

  /**
   * <b>Scenario:</b> B5270 test case. Error DONNE_INCONNU is reach</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL100_ModifierOptionAppel_Test_001() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.NO_TELEPHONE_EST_INCONNU, MessageFormat.format(Messages.getString("PE0223.BL100.noTelephoneInconnu"), "+33123456789")); //$NON-NLS-1$ //$NON-NLS-2$
    PE0223_BL001PutReturn bl001Return = new PE0223_BL001PutReturn();
    bl001Return.setNoTelephone("+33123456789"); //$NON-NLS-1$
    bl001Return.setIdOptionAppel(null);
    bl001Return.setTypeOperation(ACTION_MODIFIER_OPTION_APPEL);
    bl001Return.setTypeOptionAppel(IOptionAppelConsts.TYPE_APPEL_INCOGNITO);
    bl001Return.setStatutOptionAppel(IOptionAppelConsts.STATUT_SUSPENDU);
    bl001Return.setNoContrat("144104"); //$NON-NLS-1$
    bl001Return.setModeAppel(IMetadata.CANAL_B2R);
    BL5270_Return bl5270Return = new BL5270_Return();
    bl5270Return.setClientOperateur(__podam.manufacturePojo(String.class));
    bl5270Return.setNoCompte(__podam.manufacturePojo(String.class));
    bl5270Return.setNoContrat("144104"); //$NON-NLS-1$
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT4, IMegConsts.DONNEE_INCONNUE, null);

    prepareB5270Mock(retour, "+33123456789", bl5270Return); //$NON-NLS-1$

    PowerMock.replayAll();
    Retour actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL100_ModifierOptionAppel", _tracabilite, bl001Return); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual);
  }

  /**
   * <b>Scenario:</b> B5270 test case. Error DONNEE_INDISPONIBLE is reach</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL100_ModifierOptionAppel_Test_002() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, Messages.getString("PE0223.BL100.serviceIndisponible")); //$NON-NLS-1$
    PE0223_BL001PutReturn bl001Return = new PE0223_BL001PutReturn();
    bl001Return.setNoTelephone("+33123456789"); //$NON-NLS-1$
    bl001Return.setIdOptionAppel(null);
    bl001Return.setTypeOperation(ACTION_MODIFIER_OPTION_APPEL);
    bl001Return.setTypeOptionAppel(IOptionAppelConsts.TYPE_APPEL_INCOGNITO);
    bl001Return.setStatutOptionAppel(IOptionAppelConsts.STATUT_SUSPENDU);
    bl001Return.setNoContrat("144104"); //$NON-NLS-1$
    bl001Return.setModeAppel(IMetadata.CANAL_B2R);
    BL5270_Return bl5270Return = new BL5270_Return();
    bl5270Return.setClientOperateur(__podam.manufacturePojo(String.class));
    bl5270Return.setNoCompte(__podam.manufacturePojo(String.class));
    bl5270Return.setNoContrat("144104"); //$NON-NLS-1$
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT6, IMegSpiritConsts.DONNEE_INDISPONIBLE, MessageFormat.format(Messages.getString("BL5270_RecupererPfiParNoTelephone.aucunPFI"), "+33123456789")); //$NON-NLS-1$ //$NON-NLS-2$

    prepareB5270Mock(retour, "+33123456789", bl5270Return); //$NON-NLS-1$

    PowerMock.replayAll();
    Retour actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL100_ModifierOptionAppel", _tracabilite, bl001Return); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual);
  }

  /**
   * <b>Scenario:</b> KO test case. Error access denied is reach</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL100_ModifierOptionAppel_Test_003() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "acces refuse"); //$NON-NLS-1$
    PE0223_BL001PutReturn bl001Return = new PE0223_BL001PutReturn();
    bl001Return.setIdOptionAppel("1nBLshtXB1G9W+XjHR4LnQ=="); //$NON-NLS-1$
    bl001Return.setModeAppel(IMetadata.CANAL_B2R);

    PowerMock.replayAll();
    Retour actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL100_ModifierOptionAppel", _tracabilite, bl001Return); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual);
  }

  /**
   * <b>Scenario:</b> KO test case. Error access denied is reach</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL100_ModifierOptionAppel_Test_004() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT4, IMegSpiritConsts.ACCES_REFUSE, "acces refuse"); //$NON-NLS-1$
    PE0223_BL001PutReturn bl001Return = new PE0223_BL001PutReturn();
    bl001Return.setIdOptionAppel("1nBLshtXB1G9W+XjHR4LnQ=="); //$NON-NLS-1$
    bl001Return.setModeAppel(IMetadata.CANAL_B2R);

    PowerMock.replayAll();
    Retour actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL100_ModifierOptionAppel", _tracabilite, bl001Return); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual);
  }

  /**
   * <b>Scenario:</b> KO test case. Error SI002 has reach error CAT1</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL100_ModifierOptionAppel_Test_005() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT1, IMegSpiritConsts.ERREUR_INTERNE, Messages.getString("PE0223.BL100.serviceIndisponible")); //$NON-NLS-1$
    PE0223_BL001PutReturn bl001Return = new PE0223_BL001PutReturn();
    bl001Return.setNoTelephone("+33123456789"); //$NON-NLS-1$
    bl001Return.setIdOptionAppel("1nBLshtXB1G9W+XjHR4LnQ=="); //$NON-NLS-1$
    bl001Return.setTypeOperation(ACTION_DESACTIVER_RENVOIS_APPELS);
    bl001Return.setTypeOptionAppel(IOptionAppelConsts.TYPE_APPEL_INCOGNITO);
    bl001Return.setStatutOptionAppel(IOptionAppelConsts.STATUT_SUSPENDU);
    bl001Return.setNoContrat("144104"); //$NON-NLS-1$
    bl001Return.setModeAppel(IMetadata.CANAL_DIRECT);
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT1, null, null);

    //String autoriz = "Bearer"; //$NON-NLS-1$
    //String listContract = "idc=1234,idu=1234,rol=rol;idc=5456464,idu=1231231,rol=rol2"; //$NON-NLS-1$

    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", "+33123456789"); //$NON-NLS-1$ //$NON-NLS-2$
    listparams.add("statut", IOptionAppelConsts.STATUT_SUSPENDU); //$NON-NLS-1$

    prepareProv_SI002(retour, "desactiverRenvoisAppel", listparams, null); //$NON-NLS-1$

    PowerMock.replayAll();
    Retour actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL100_ModifierOptionAppel", _tracabilite, bl001Return); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual);
  }

  /**
   * <b>Scenario:</b> KO test case. Error SI002 has reach error CAT2</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL100_ModifierOptionAppel_Test_006() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT2, IMegSpiritConsts.PFS_INDISPO, Messages.getString("PE0223.BL100.serviceIndisponible")); //$NON-NLS-1$
    PE0223_BL001PutReturn bl001Return = new PE0223_BL001PutReturn();
    bl001Return.setNoTelephone("+33123456789"); //$NON-NLS-1$
    bl001Return.setIdOptionAppel("1nBLshtXB1G9W+XjHR4LnQ=="); //$NON-NLS-1$
    bl001Return.setTypeOperation(ACTION_MODIFIER_OPTION_APPEL);
    bl001Return.setTypeOptionAppel(IOptionAppelConsts.TYPE_APPEL_INCOGNITO);
    bl001Return.setStatutOptionAppel(IOptionAppelConsts.STATUT_SUSPENDU);
    bl001Return.setNoContrat("144104"); //$NON-NLS-1$
    bl001Return.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001Return.setModeRenvoi(IOptionAppelConsts.MODE_RENVOI_NUMERO);
    bl001Return.setNumeroRenvoi(NO_TELEPHONE_INT);
    bl001Return.setNombreSonneries("2"); //$NON-NLS-1$
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT2, null, null);

    //String autoriz = "Bearer"; //$NON-NLS-1$
    //String listContract = "idc=1234,idu=1234,rol=rol;idc=5456464,idu=1231231,rol=rol2"; //$NON-NLS-1$

    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", "+33123456789"); //$NON-NLS-1$ //$NON-NLS-2$
    listparams.add("statut", IOptionAppelConsts.STATUT_SUSPENDU); //$NON-NLS-1$
    listparams.add("typeOptionAppel", IOptionAppelConsts.TYPE_APPEL_INCOGNITO); //$NON-NLS-1$
    listparams.add("modeRenvoi", IOptionAppelConsts.MODE_RENVOI_NUMERO); //$NON-NLS-1$
    listparams.add("numeroRenvoi", NO_TELEPHONE_INT); //$NON-NLS-1$
    listparams.add("nombreSonneries", "2"); //$NON-NLS-1$ //$NON-NLS-2$

    prepareProv_SI002(retour, "modifierOptionAppel", listparams, null); //$NON-NLS-1$

    PowerMock.replayAll();
    Retour actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL100_ModifierOptionAppel", _tracabilite, bl001Return); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual);
  }

  /**
   * <b>Scenario:</b> KO test case. Error SI002 has reach error CAT10</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL100_ModifierOptionAppel_Test_007() throws Throwable
  {
    Retour expected = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.ERREUR_INTERNE, null);
    PE0223_BL001PutReturn bl001Return = new PE0223_BL001PutReturn();
    bl001Return.setNoTelephone("+33123456789"); //$NON-NLS-1$
    bl001Return.setIdOptionAppel("1nBLshtXB1G9W+XjHR4LnQ=="); //$NON-NLS-1$
    bl001Return.setTypeOperation(ACTION_MODIFIER_OPTION_APPEL);
    bl001Return.setTypeOptionAppel(IOptionAppelConsts.TYPE_APPEL_INCOGNITO);
    bl001Return.setStatutOptionAppel(IOptionAppelConsts.STATUT_SUSPENDU);
    bl001Return.setNoContrat("144104"); //$NON-NLS-1$
    bl001Return.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001Return.setModeRenvoi(IOptionAppelConsts.MODE_RENVOI_NUMERO);
    bl001Return.setNumeroRenvoi(NO_TELEPHONE_INT);
    bl001Return.setNombreSonneries("2"); //$NON-NLS-1$
    Retour retour = RetourFactory.createNOK(IMegConsts.CAT10, IMegSpiritConsts.ERREUR_INTERNE, null);

    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", "+33123456789"); //$NON-NLS-1$ //$NON-NLS-2$
    listparams.add("statut", IOptionAppelConsts.STATUT_SUSPENDU); //$NON-NLS-1$
    listparams.add("typeOptionAppel", IOptionAppelConsts.TYPE_APPEL_INCOGNITO); //$NON-NLS-1$
    listparams.add("modeRenvoi", IOptionAppelConsts.MODE_RENVOI_NUMERO); //$NON-NLS-1$
    listparams.add("numeroRenvoi", NO_TELEPHONE_INT); //$NON-NLS-1$
    listparams.add("nombreSonneries", "2"); //$NON-NLS-1$ //$NON-NLS-2$

    prepareProv_SI002(retour, "modifierOptionAppel", listparams, null); //$NON-NLS-1$

    PowerMock.replayAll();
    Retour actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL100_ModifierOptionAppel", _tracabilite, bl001Return); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual);
  }

  /**
   * <b>Scenario:</b> test nominal</br>
   * <b>Result:</b>
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_BL100_ModifierOptionAppel_Test_008() throws Throwable
  {
    Retour expected = RetourFactory.createOkRetour();
    PE0223_BL001PutReturn bl001Return = new PE0223_BL001PutReturn();
    bl001Return.setNoTelephone("+33123456789"); //$NON-NLS-1$
    bl001Return.setIdOptionAppel("1nBLshtXB1G9W+XjHR4LnQ=="); //$NON-NLS-1$
    bl001Return.setTypeOperation(ACTION_MODIFIER_OPTION_APPEL);
    bl001Return.setTypeOptionAppel(IOptionAppelConsts.TYPE_APPEL_INCOGNITO);
    bl001Return.setStatutOptionAppel(IOptionAppelConsts.STATUT_SUSPENDU);
    bl001Return.setNoContrat("144104"); //$NON-NLS-1$
    bl001Return.setModeAppel(IMetadata.CANAL_DIRECT);
    bl001Return.setModeRenvoi(IOptionAppelConsts.MODE_RENVOI_NUMERO);
    bl001Return.setNumeroRenvoi(NO_TELEPHONE_INT);
    bl001Return.setNombreSonneries("2"); //$NON-NLS-1$
    Retour retour = RetourFactory.createOkRetour();

    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", "+33123456789"); //$NON-NLS-1$ //$NON-NLS-2$
    listparams.add("statut", IOptionAppelConsts.STATUT_SUSPENDU); //$NON-NLS-1$
    listparams.add("typeOptionAppel", IOptionAppelConsts.TYPE_APPEL_INCOGNITO); //$NON-NLS-1$
    listparams.add("modeRenvoi", IOptionAppelConsts.MODE_RENVOI_NUMERO); //$NON-NLS-1$
    listparams.add("numeroRenvoi", NO_TELEPHONE_INT); //$NON-NLS-1$
    listparams.add("nombreSonneries", "2"); //$NON-NLS-1$ //$NON-NLS-2$

    prepareProv_SI002(retour, "modifierOptionAppel", listparams, null); //$NON-NLS-1$

    PowerMock.replayAll();
    Retour actual = Whitebox.invokeMethod(_processInstance, "PE0223_BL100_ModifierOptionAppel", _tracabilite, bl001Return); //$NON-NLS-1$
    PowerMock.verify();

    assertEquals(expected, actual);
  }

  /**
   * <b>Scenario:</b> Error test case. Invalid nombreSonneries <b>Input:</b> Valid request<br>
   * <b>Result:</b> {"error":"NON_RESPECT_STI","error_description":"Parameter noSonneries value null is not valid."}
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_PutOptionsAppels_Test_KO_02() throws Throwable
  {
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(STATUT_ACTIF);
    pe0223Input.setModeRenvoi("NUMERO"); //$NON-NLS-1$
    pe0223Input.setNombreSonneries(null);
    pe0223Input.setNumeroRenvoi(NO_TELEPHONE_NAC);

    Request request = prepareRequest(_tracabilite, pe0223Input, null, NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, IOptionAppelConsts.TYPE_RENVOI_NON_REPONSE, null, null);

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    ReponseErreur oResp = new Gson().fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI.toString(), oResp.getError());
    assertEquals(MessageFormat.format(Messages.getString("PE0223.BL100.invalidParameter"), "nombreSonneries", null), oResp.getErrorDescription()); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * <b>Scenario:</b> Error test case. Invalid modeRenvoi <b>Input:</b> Valid request<br>
   * <b>Result:</b> {"error":"NON_RESPECT_STI","error_description":"Parameter modeRenvoi value other is not valid."}
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_PutOptionsAppels_Test_KO_03() throws Throwable
  {
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(STATUT_ACTIF);
    pe0223Input.setModeRenvoi("other"); //$NON-NLS-1$
    pe0223Input.setNombreSonneries("2"); //$NON-NLS-1$
    pe0223Input.setNumeroRenvoi(NO_TELEPHONE_NAC);

    Request request = prepareRequest(_tracabilite, pe0223Input, null, NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, TYPE_RENVOI_LIGNE_INDISPONIBLE, null, null);

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    ReponseErreur oResp = new Gson().fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI.toString(), oResp.getError());
    assertEquals(MessageFormat.format(Messages.getString("PE0223.BL100.invalidParameter"), "modeRenvoi", "other"), oResp.getErrorDescription()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

  /**
   * <b>Scenario:</b> Error test case. Status actif should have a numeroRenvoi<br>
   * <b>Input:</b> Valid request<br>
   * <b>Result:</b> {"error":"NON_RESPECT_STI","error_description":"Parameter numeroRenvoi value other is not valid."}
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_PutOptionsAppels_Test_KO_04() throws Throwable
  {
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut(STATUT_ACTIF);
    pe0223Input.setModeRenvoi("NUMERO"); //$NON-NLS-1$
    pe0223Input.setNombreSonneries("2"); //$NON-NLS-1$
    pe0223Input.setNumeroRenvoi(null);

    Request request = prepareRequest(_tracabilite, pe0223Input, null, NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, TYPE_RENVOI_LIGNE_INDISPONIBLE, null, null);

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    ReponseErreur oResp = new Gson().fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);

    assertEquals(ErrorCode.KO_00400, request.getResponse().getErrorCode());
    assertEquals(IMegSpiritConsts.NON_RESPECT_STI.toString(), oResp.getError());
    assertEquals(MessageFormat.format(Messages.getString("PE0223.BL100.invalidParameter"), "numeroRenvoi", "null"), oResp.getErrorDescription()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

  /**
   * <b>Scenario:</b> Error test case. Error calling BL5270<br>
   * <b>Result:</b> KO_403
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_PutOptionsAppels_Test_KO_06() throws Throwable
  {
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut("ACTIF"); //$NON-NLS-1$
    pe0223Input.setModeRenvoi("VMS"); //$NON-NLS-1$
    pe0223Input.setNombreSonneries("2"); //$NON-NLS-1$
    pe0223Input.setNumeroRenvoi(NO_TELEPHONE_NAC);

    String libelle = "Unknown data."; //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, pe0223Input, null, NO_TELEPHONE_INT, ACTION_MODIFIER_OPTION_APPEL, IOptionAppelConsts.TYPE_RENVOI_NON_REPONSE, null, null);
    Retour ko = RetourFactory.createNOK(IMegConsts.CAT3, IMegConsts.DONNEE_INCONNUE, libelle);

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, X_REQUEST_ID_VALUE);
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, NO_TELEPHONE_INT);
    prepareB1700Mock(refFonc);

    prepareB5270Mock(ko, NO_TELEPHONE_INT, null);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    PowerMock.verifyAll();
    ReponseErreur oResp = new Gson().fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);

    assertEquals(ErrorCode.KO_00403, request.getResponse().getErrorCode());
    assertEquals(IMegSpiritConsts.ERREUR_INTERNE.toString(), oResp.getError());
    assertEquals(Messages.getString("PE0223.BL100.serviceIndisponible"), oResp.getErrorDescription()); //$NON-NLS-1$
  }

  /**
   * <b>Scenario:</b> Error test case. Contract Auth not found<br>
   * <b>Result:</b> KO_403
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_PutOptionsAppels_Test_KO_07() throws Throwable
  {
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut("ACTIF"); //$NON-NLS-1$
    pe0223Input.setModeRenvoi("NUMERO"); //$NON-NLS-1$
    pe0223Input.setNumeroRenvoi("2"); //$NON-NLS-1$
    pe0223Input.setNombreSonneries("2"); //$NON-NLS-1$
    String autoriz = "Bearer"; //$NON-NLS-1$
    String listContract = "idc=1234,idu=1234,rol=rol;idc=5456464,idu=1231231,rol=rol2"; //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_DESACTIVER_RENVOIS_APPELS, null, autoriz, listContract); //$NON-NLS-1$
    request.addMetadata(IMetadata.METADATA_CANAL, IMetadata.CANAL_B2R);
    RetourFactory.createOkRetour();

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, X_REQUEST_ID_VALUE);
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, NO_TELEPHONE_INT);

    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andReturn("144104#+33123456789#APPEL_INCOGNITO"); //$NON-NLS-1$ //$NON-NLS-2$

    prepareB1700Mock(refFonc);
    PowerMock.replayAll();

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    PowerMock.verifyAll();
    ReponseErreur oResp = new Gson().fromJson(request.getResponse().getGenericResponse().getResult(), ReponseErreur.class);

    assertEquals(ErrorCode.KO_00403, request.getResponse().getErrorCode());
    assertEquals(IMegSpiritConsts.ACCES_REFUSE.toString(), oResp.getError());
    assertEquals("acces refuse", oResp.getErrorDescription()); //$NON-NLS-1$
  }

  /**
   * <b>Scenario:</b> Nominal test case. UrlDynamicParameters with valid id<br>
   * <b>Input:</b> Valid request<br>
   * <b>Result:</b> OK_00204
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_PutOptionsAppels_Test_OK_00() throws Throwable
  {
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut("ACTIF"); //$NON-NLS-1$
    pe0223Input.setModeRenvoi("NUMERO"); //$NON-NLS-1$
    pe0223Input.setNumeroRenvoi("2"); //$NON-NLS-1$
    String autoriz = "Bearer"; //$NON-NLS-1$
    String listContract = "idc=14874104,idu=1234,rol=rol;idc=5456464,idu=1231231,rol=rol2"; //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, pe0223Input, "1nBLshtXB1G9W+XjHR4LnQ==", NO_TELEPHONE_INT, ACTION_DESACTIVER_RENVOIS_APPELS, null, autoriz, listContract); //$NON-NLS-1$
    Retour ok = RetourFactory.createOkRetour();

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, X_REQUEST_ID_VALUE);
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, NO_TELEPHONE_INT);

    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", "+33123456789"); //$NON-NLS-1$ //$NON-NLS-2$
    listparams.add("statut", IOptionAppelConsts.STATUT_ACTIF); //$NON-NLS-1$
    listparams.add("typeOptionAppel", IOptionAppelConsts.TYPE_APPEL_INCOGNITO); //$NON-NLS-1$
    listparams.add("modeRenvoi", null); //$NON-NLS-1$
    listparams.add("numeroRenvoi", null); //$NON-NLS-1$
    //listparams.add("nombreSonneries", null); //$NON-NLS-1$

    EasyMock.expect(PasswordDecrypter.decryptForURL("1nBLshtXB1G9W+XjHR4LnQ==")).andReturn("14874104#+33123456789#APPEL_INCOGNITO"); //$NON-NLS-1$ //$NON-NLS-2$
    prepareB1700Mock(refFonc);
    prepareProv_SI002(ok, "modifierOptionAppel", listparams, null); //$NON-NLS-1$
    PowerMock.replayAll();

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    PowerMock.verifyAll();

    assertEquals(ErrorCode.OK_00204, request.getResponse().getErrorCode());
  }

  /**
   * <b>Scenario:</b> Nominal test case. idOption == null. <b>Input:</b> Valid request<br>
   * <b>Result:</b> OK_00204
   *
   * @throws Throwable
   *           Can be thrown by the process execution or by PowerMock
   */
  @Test
  public void PE0223_PutOptionsAppels_Test_OK_01() throws Throwable
  {
    PE0223_PutRequest pe0223Input = new PE0223_PutRequest();
    pe0223Input.setStatut("INACTIF"); //$NON-NLS-1$
    pe0223Input.setModeRenvoi(null);
    pe0223Input.setNombreSonneries("2"); //$NON-NLS-1$
    pe0223Input.setNumeroRenvoi(null);
    String autoriz = "Bearer"; //$NON-NLS-1$
    String listContract = "idc=14874104,idu=1234,rol=rol;idc=5456464,idu=1231231,rol=rol2"; //$NON-NLS-1$

    Request request = prepareRequest(_tracabilite, pe0223Input, null, NO_TELEPHONE_INT, ACTION_DESACTIVER_RENVOIS_APPELS, TYPE_DOUBLE_APPEL, autoriz, listContract);
    Retour ok = RetourFactory.createOkRetour();

    Map<String, String> refFonc = new HashMap<>();
    refFonc.put(IRefFoncConstants.ID_EXTERNE, X_REQUEST_ID_VALUE);
    refFonc.put(IRefFoncConstants.NO_TELEPHONE, NO_TELEPHONE_INT);
    prepareB1700Mock(refFonc);

    BL5270_Return bl5270_Return = new BL5270_Return();
    bl5270_Return.setNoContrat("14874104"); //$NON-NLS-1$
    prepareB5270Mock(ok, NO_TELEPHONE_INT, bl5270_Return);

    ListeParametre listparams = new ListeParametre();
    listparams.add("noTelephone", NO_TELEPHONE_INT); //$NON-NLS-1$
    listparams.add("statut", "INACTIF"); //$NON-NLS-1$

    prepareProv_SI002(ok, "desactiverRenvoisAppel", listparams, null); //$NON-NLS-1$
    PowerMock.replayAll();

    fillAllRequestHeaders(request);

    PowerMock.replayAll();
    _processInstance.run(request);
    PowerMock.verifyAll();

    PowerMock.verifyAll();

    assertEquals(ErrorCode.OK_00204, request.getResponse().getErrorCode());
  }

  /**
   * Add custom headers
   *
   * @param requestHeader_p
   *          request
   *
   * @param authorization_p
   *          authorization
   *
   * @param listeContract_p
   *          listeContract
   * @param tracabilite_p
   *          _tracabilite
   */
  private void addXHeaders(List<RequestHeader> requestHeader_p, Tracabilite tracabilite_p, String authorization_p, String listeContract_p)
  {
    RequestHeader hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.CONTENT_TYPE);
    hdr.setValue(MediaType.APPLICATION_JSON);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID);
    hdr.setValue(tracabilite_p.getIdCorrelationByTel());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_REQUEST_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdCorrelationSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_SOURCE);
    hdr.setValue(tracabilite_p.getNomSysteme());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_PROCESS_ID_SPIRIT);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_MESSAGE_ID);
    hdr.setValue(tracabilite_p.getIdProcessusSpirit());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_ACTION_ID);
    hdr.setValue(tracabilite_p.getNomProcessus());
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_CLIENT_OPERATEUR);
    hdr.setValue("ClientOperateur"); //$NON-NLS-1$
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.AUTHORIZATION);
    hdr.setValue(authorization_p);
    requestHeader_p.add(hdr);

    hdr = new RequestHeader();
    hdr.setName(IHttpHeadersConsts.X_OAUTH2_IDCONTRATS);
    hdr.setValue(listeContract_p);
    requestHeader_p.add(hdr);
  }

  /**
   * Create a new request header
   *
   * @param name
   *          The request header name
   * @param value
   *          The request header value
   * @return the {@link RequestHeader}
   */
  private RequestHeader createHeader(String name, String value)
  {
    RequestHeader requestHeader = new RequestHeader();
    requestHeader.setName(name);
    requestHeader.setValue(value);

    return requestHeader;
  }

  /**
   * Fills all the request headers
   *
   * @param request_p
   *          The request
   */
  private void fillAllRequestHeaders(Request request_p)
  {
    RequestHeader xClientOperateur = createHeader(IHttpHeadersConsts.X_CLIENT_OPERATEUR, "BSS_GP"); //$NON-NLS-1$
    RequestHeader xRequestId = createHeader(IHttpHeadersConsts.X_REQUEST_ID, X_REQUEST_ID_VALUE);
    RequestHeader xSource = createHeader(IHttpHeadersConsts.X_SOURCE, "DOMINGO"); //$NON-NLS-1$
    RequestHeader xProcess = createHeader(IHttpHeadersConsts.X_PROCESS, "GESTION MAIL SECONDAIRE"); //$NON-NLS-1$

    fillRequestHeaders(request_p, xClientOperateur, xRequestId, xSource, xProcess);
  }

  /**
   * Fills the specified request headers
   *
   * @param request_p
   *          The request
   * @param headers_p
   *          the list of headers to add
   */
  private void fillRequestHeaders(Request request_p, RequestHeader... headers_p)
  {
    request_p.getRequestHeader().addAll(Arrays.asList(headers_p));
  }

  /**
   * prepareB1700Mock
   *
   * @param refFonc_p
   *          The refFonc to set
   *
   * @throws Exception
   *           exception
   */
  private void prepareB1700Mock(Map<String, String> refFonc_p) throws Exception
  {
    PowerMock.expectNew(BL1700_AjouterRefFoncBuilder.class).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.refFonc(EasyMock.eq(refFonc_p))).andReturn(_bl1700BuilderMock);
    EasyMock.expect(_bl1700BuilderMock.build()).andReturn(_bl1700Mock);
    EasyMock.expect(_bl1700Mock.execute(_processInstance)).andReturn(null);

  }

  /**
   * prepareB5270Mock
   *
   * @param telephoneNumber_p
   *          telephoneNumber
   * @param retour_p
   *          retour
   * @param retourBL5270_p
   *          retour
   *
   * @throws Exception
   *           exception
   */
  private void prepareB5270Mock(Retour retour_p, String telephoneNumber_p, BL5270_Return retourBL5270_p) throws Exception
  {
    PowerMock.expectNew(BL5270_RecupererPfiParNoTelephoneBuilder.class).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.noTelephone(telephoneNumber_p)).andReturn(_bl5270BuilderMock);
    EasyMock.expect(_bl5270BuilderMock.build()).andReturn(_bl5270Mock);
    EasyMock.expect(_bl5270Mock.execute(_processInstance)).andReturn(retourBL5270_p);
    EasyMock.expect(_bl5270Mock.getRetour()).andReturn(retour_p);
  }

  /**
   * prepareProv_SI002
   *
   * @param retour_p
   *          retour
   * @param processus_p
   *          Name of processus
   * @param listParams_p
   *          liste parametres
   * @param reponseConnector_p
   *          reponseConnector answer
   * @throws Exception
   *           excetpion
   */
  private void prepareProv_SI002(Retour retour_p, String processus_p, ListeParametre listParams_p, ResponseConnector reponseConnector_p) throws Exception
  {
    PowerMock.expectNew(PROV_SI002_ExecuterProcessusBuilder.class).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.tracabilite(EasyMock.anyObject(Tracabilite.class))).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.cles(EasyMock.anyObject())).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.priorite(10)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.processus(processus_p)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.listeParametres(listParams_p)).andReturn(_si002BuilderMock);
    EasyMock.expect(_si002BuilderMock.build()).andReturn(_si002Mock);
    EasyMock.expect(_si002Mock.execute(_processInstance)).andReturn(reponseConnector_p);
    EasyMock.expect(_si002Mock.getRetour()).andReturn(retour_p).anyTimes();
  }

  /**
   * This method prepares a request to send to the process
   *
   * @param tracabilite_p
   *          The object {@Code Tracabilite}
   * @param pe0223Input_p
   *          The pe0223 Input
   * @param urlDynamicParameters_p
   *          The Url dynamic parameters
   * @param noTelephone_p
   *          The telephone number
   * @param action_p
   *          The action
   * @param type_p
   *          The type
   * @param authorization_p
   *          authorization
   * @param listeContract_p
   *          listeContract
   * @return Request
   */
  private Request prepareRequest(Tracabilite tracabilite_p, PE0223_PutRequest pe0223Input_p, String urlDynamicParameters_p, String noTelephone_p, String action_p, String type_p, String authorization_p, String listeContract_p)
  {
    Request request = new Request(StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING, StringConstants.EMPTY_STRING);
    request.setHttpMethod("PUT"); //$NON-NLS-1$
    request.setContentType("application/json"); //$NON-NLS-1$

    addXHeaders(request.getRequestHeader(), tracabilite_p, authorization_p, listeContract_p);

    if (urlDynamicParameters_p != null)
    {
      request.setUrlDynamicParameters(urlDynamicParameters_p);
    }
    UrlParameters urlParametersType = new UrlParameters();
    List<Parameter> urlParams = urlParametersType.getUrlParameters();

    if (noTelephone_p != null)
    {
      urlParams.add(createParameter(PARAM_NO_TELEPHONE, noTelephone_p));
    }

    if (action_p != null)
    {
      urlParams.add(createParameter(PARAM_ACTION, action_p));
    }

    if (type_p != null)
    {
      urlParams.add(createParameter(PARAM_TYPE, type_p));
    }
    urlParametersType.setUrlParameters(urlParams);

    request.setUrlParameters(urlParametersType);

    String jSonRequest = GsonTools.getGson(DateTimeFormatPattern.yyyy_dash_MM_dash_dd_T_HH_colon_mm_colon_ss_dot_SSSZZZZZZ).toJson(pe0223Input_p, PE0223_PutRequest.class);
    request.setPayload(jSonRequest);

    return request;
  }
}
