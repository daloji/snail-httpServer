/*******************************************************************************
 * $Id: DESKey.java 35153 2017-04-11 08:20:23Z lchanyip $
 * (c) Copyright BouyguesTelecom
 *******************************************************************************/
package com.bytel.spirit.fiat.common.encryption;

import com.bytel.ravel.common.encryption.IPassPhrase;

/**
 * DES key used by the encryption tool.
 *
 * @author lchanyip
 * @version ($Revision: 35153 $ $Date: 2017-04-11 10:20:23 +0200 (mar., 11 avr. 2017) $)
 */
public class DESKey implements IPassPhrase
{
  /**
   * Default key phrase, change it !
   */
  private final static String DES_ENCRYPTION_PASS_PHRASE = "Bruce Lee is the best of the best of the best..."; //$NON-NLS-1$

  @Override
  public String getPassPhrase()
  {
    return DES_ENCRYPTION_PASS_PHRASE;
  }
}
