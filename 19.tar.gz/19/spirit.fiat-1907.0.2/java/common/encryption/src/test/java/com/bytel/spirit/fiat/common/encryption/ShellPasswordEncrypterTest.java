/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.common.encryption;

import javax.crypto.SecretKey;

import org.junit.Assert;
import org.junit.Test;

import com.bytel.ravel.common.encryption.DESEncrypter;
import com.bytel.ravel.common.encryption.DESKeyManager;

/**
 * ShellPasswordEncrypter test class
 *
 * @author lchanyip
 * @version ($Revision$ $Date$)
 */
public class ShellPasswordEncrypterTest
{

  /**
   * Encyption test OK
   *
   * @throws Exception
   *           On error
   *
   */
  @Test
  public void testEncrypt() throws Exception
  {
    SecretKey key = new DESKeyManager("com.bytel.spirit.fiat.common.encryption.DESKey").getSecretKey(); //$NON-NLS-1$
    Assert.assertEquals("MHndnhfjTSOsxxKKnPjCVA==", new DESEncrypter(key).encrypt("azertyqsdf")); //$NON-NLS-1$ //$NON-NLS-2$
  }
}
