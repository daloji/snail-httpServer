/*******************************************************************************
* $Id$
* (c) Copyright BouyguesTelecom
*******************************************************************************/
package com.bytel.spirit.fiat.common.encryption;

import org.junit.Assert;
import org.junit.Test;

/**
 * DESKey test class
 *
 * @author lchanyip
 * @version ($Revision$ $Date$)
 */
public class DESKeyTest
{
  /**
   * Test GetPassPhrase OK
   */
  @Test
  public void TestGetPassPhrase()
  {
    DESKey key = new DESKey();
    Assert.assertNotNull(key.getPassPhrase());
  }
}
