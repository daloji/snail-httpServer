 
INSERT INTO idx_ressource_by_ressource_lie ( 
		id_ressource,
		id_ressource_lie, 
		type_ressource)
	VALUES (
		'nomOlt12345-50-50-50',
		'12345',
		'PORT_P2P'
	);
	
INSERT INTO ressource_port_p2p ( 
		nom_olt,
		position_carte_p2p,
		position_cage_p2p,
		position_port_p2p,
		statut,
		id_ressource_lie, 
		id_st,
		date_creation,
		date_modification)
	VALUES (
		'nomOlt12345',
		50,
		50,
		50,
		'ALLOUE',
		'12345',
		'1',
		1525453180002,
		1525453180002);
		
INSERT INTO olt_composite ( 
		nom_olt, 
		nom_nr, 
		liste_nom_provider_edge, 
		constructeur, 
		modele, 
		ip, 
		version_interface_echange,
		statut_technique, 
		date_dernier_import, 
		date_creation, 
		date_modification)
	VALUES (
		'nomOlt12345',
		'nomNr12345',
		{'PE1', 'PE2'},
		'constructeur',
		'modele',
		'127.0.0.1',
		'versionInterfaceEchange',
		'statutTechnique',
		1525453180002,
		1525453180002,
		1525453180002);